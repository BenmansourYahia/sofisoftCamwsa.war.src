/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringApplicationBannerPrinter
/*     */ {
/*     */   static final String BANNER_LOCATION_PROPERTY = "spring.banner.location";
/*     */   static final String BANNER_IMAGE_LOCATION_PROPERTY = "spring.banner.image.location";
/*     */   static final String DEFAULT_BANNER_LOCATION = "banner.txt";
/*  45 */   static final String[] IMAGE_EXTENSION = new String[] { "gif", "jpg", "png" };
/*     */   
/*  47 */   private static final Banner DEFAULT_BANNER = new SpringBootBanner();
/*     */   
/*     */   private final ResourceLoader resourceLoader;
/*     */   
/*     */   private final Banner fallbackBanner;
/*     */   
/*     */   SpringApplicationBannerPrinter(ResourceLoader resourceLoader, Banner fallbackBanner) {
/*  54 */     this.resourceLoader = resourceLoader;
/*  55 */     this.fallbackBanner = fallbackBanner;
/*     */   }
/*     */   
/*     */   Banner print(Environment environment, Class<?> sourceClass, Log logger) {
/*  59 */     Banner banner = getBanner(environment);
/*     */     try {
/*  61 */       logger.info(createStringFromBanner(banner, environment, sourceClass));
/*     */     }
/*  63 */     catch (UnsupportedEncodingException ex) {
/*  64 */       logger.warn("Failed to create String for banner", ex);
/*     */     } 
/*  66 */     return new PrintedBanner(banner, sourceClass);
/*     */   }
/*     */   
/*     */   Banner print(Environment environment, Class<?> sourceClass, PrintStream out) {
/*  70 */     Banner banner = getBanner(environment);
/*  71 */     banner.printBanner(environment, sourceClass, out);
/*  72 */     return new PrintedBanner(banner, sourceClass);
/*     */   }
/*     */   
/*     */   private Banner getBanner(Environment environment) {
/*  76 */     Banners banners = new Banners();
/*  77 */     banners.addIfNotNull(getImageBanner(environment));
/*  78 */     banners.addIfNotNull(getTextBanner(environment));
/*  79 */     if (banners.hasAtLeastOneBanner()) {
/*  80 */       return banners;
/*     */     }
/*  82 */     if (this.fallbackBanner != null) {
/*  83 */       return this.fallbackBanner;
/*     */     }
/*  85 */     return DEFAULT_BANNER;
/*     */   }
/*     */   
/*     */   private Banner getTextBanner(Environment environment) {
/*  89 */     String location = environment.getProperty("spring.banner.location", "banner.txt");
/*  90 */     Resource resource = this.resourceLoader.getResource(location);
/*  91 */     if (resource.exists()) {
/*  92 */       return new ResourceBanner(resource);
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   private Banner getImageBanner(Environment environment) {
/*  98 */     String location = environment.getProperty("spring.banner.image.location");
/*  99 */     if (StringUtils.hasLength(location)) {
/* 100 */       Resource resource = this.resourceLoader.getResource(location);
/* 101 */       return resource.exists() ? new ImageBanner(resource) : null;
/*     */     } 
/* 103 */     for (String ext : IMAGE_EXTENSION) {
/* 104 */       Resource resource = this.resourceLoader.getResource("banner." + ext);
/* 105 */       if (resource.exists()) {
/* 106 */         return new ImageBanner(resource);
/*     */       }
/*     */     } 
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private String createStringFromBanner(Banner banner, Environment environment, Class<?> mainApplicationClass) throws UnsupportedEncodingException {
/* 114 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 115 */     banner.printBanner(environment, mainApplicationClass, new PrintStream(baos));
/* 116 */     String charset = environment.getProperty("spring.banner.charset", "UTF-8");
/* 117 */     return baos.toString(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Banners
/*     */     implements Banner
/*     */   {
/* 125 */     private final List<Banner> banners = new ArrayList<>();
/*     */     
/*     */     void addIfNotNull(Banner banner) {
/* 128 */       if (banner != null) {
/* 129 */         this.banners.add(banner);
/*     */       }
/*     */     }
/*     */     
/*     */     boolean hasAtLeastOneBanner() {
/* 134 */       return !this.banners.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) {
/* 139 */       for (Banner banner : this.banners) {
/* 140 */         banner.printBanner(environment, sourceClass, out);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private Banners() {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PrintedBanner
/*     */     implements Banner
/*     */   {
/*     */     private final Banner banner;
/*     */     
/*     */     private final Class<?> sourceClass;
/*     */     
/*     */     PrintedBanner(Banner banner, Class<?> sourceClass) {
/* 157 */       this.banner = banner;
/* 158 */       this.sourceClass = sourceClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) {
/* 163 */       sourceClass = (sourceClass != null) ? sourceClass : this.sourceClass;
/* 164 */       this.banner.printBanner(environment, sourceClass, out);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\SpringApplicationBannerPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.origin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Origin
/*    */ {
/*    */   static Origin from(Object source) {
/* 43 */     if (source instanceof Origin) {
/* 44 */       return (Origin)source;
/*    */     }
/* 46 */     Origin origin = null;
/* 47 */     if (source instanceof OriginProvider) {
/* 48 */       origin = ((OriginProvider)source).getOrigin();
/*    */     }
/* 50 */     if (origin == null && source instanceof Throwable) {
/* 51 */       return from(((Throwable)source).getCause());
/*    */     }
/* 53 */     return origin;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\origin\Origin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot.origin;

@FunctionalInterface
public interface OriginProvider {
  Origin getOrigin();
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\origin\OriginProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
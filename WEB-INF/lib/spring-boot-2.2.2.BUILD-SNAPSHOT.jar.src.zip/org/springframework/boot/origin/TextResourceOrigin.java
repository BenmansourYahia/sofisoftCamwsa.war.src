/*     */ package org.springframework.boot.origin;
/*     */ 
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextResourceOrigin
/*     */   implements Origin
/*     */ {
/*     */   private final Resource resource;
/*     */   private final Location location;
/*     */   
/*     */   public TextResourceOrigin(Resource resource, Location location) {
/*  37 */     this.resource = resource;
/*  38 */     this.location = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource getResource() {
/*  46 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/*  54 */     return this.location;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  59 */     if (this == obj) {
/*  60 */       return true;
/*     */     }
/*  62 */     if (obj == null) {
/*  63 */       return false;
/*     */     }
/*  65 */     if (obj instanceof TextResourceOrigin) {
/*  66 */       TextResourceOrigin other = (TextResourceOrigin)obj;
/*  67 */       boolean result = true;
/*  68 */       result = (result && ObjectUtils.nullSafeEquals(this.resource, other.resource));
/*  69 */       result = (result && ObjectUtils.nullSafeEquals(this.location, other.location));
/*  70 */       return result;
/*     */     } 
/*  72 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  77 */     int result = 1;
/*  78 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.resource);
/*  79 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.location);
/*  80 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  85 */     StringBuilder result = new StringBuilder();
/*  86 */     result.append((this.resource != null) ? this.resource.getDescription() : "unknown resource [?]");
/*  87 */     if (this.location != null) {
/*  88 */       result.append(":").append(this.location);
/*     */     }
/*  90 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Location
/*     */   {
/*     */     private final int line;
/*     */ 
/*     */ 
/*     */     
/*     */     private final int column;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Location(int line, int column) {
/* 108 */       this.line = line;
/* 109 */       this.column = column;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getLine() {
/* 117 */       return this.line;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getColumn() {
/* 125 */       return this.column;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 130 */       if (this == obj) {
/* 131 */         return true;
/*     */       }
/* 133 */       if (obj == null || getClass() != obj.getClass()) {
/* 134 */         return false;
/*     */       }
/* 136 */       Location other = (Location)obj;
/* 137 */       boolean result = true;
/* 138 */       result = (result && this.line == other.line);
/* 139 */       result = (result && this.column == other.column);
/* 140 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 145 */       return 31 * this.line + this.column;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 150 */       return (this.line + 1) + ":" + (this.column + 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\origin\TextResourceOrigin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.origin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface OriginLookup<K>
/*    */ {
/*    */   Origin getOrigin(K paramK);
/*    */   
/*    */   default boolean isImmutable() {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <K> Origin getOrigin(Object source, K key) {
/* 59 */     if (!(source instanceof OriginLookup)) {
/* 60 */       return null;
/*    */     }
/*    */     try {
/* 63 */       return ((OriginLookup<K>)source).getOrigin(key);
/*    */     }
/* 65 */     catch (Throwable ex) {
/* 66 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\origin\OriginLookup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.origin;
/*     */ 
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OriginTrackedValue
/*     */   implements OriginProvider
/*     */ {
/*     */   private final Object value;
/*     */   private final Origin origin;
/*     */   
/*     */   private OriginTrackedValue(Object value, Origin origin) {
/*  37 */     this.value = value;
/*  38 */     this.origin = origin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/*  46 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/*  51 */     return this.origin;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  56 */     if (obj == null || obj.getClass() != getClass()) {
/*  57 */       return false;
/*     */     }
/*  59 */     return ObjectUtils.nullSafeEquals(this.value, ((OriginTrackedValue)obj).value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  64 */     return ObjectUtils.nullSafeHashCode(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  69 */     return (this.value != null) ? this.value.toString() : null;
/*     */   }
/*     */   
/*     */   public static OriginTrackedValue of(Object value) {
/*  73 */     return of(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OriginTrackedValue of(Object value, Origin origin) {
/*  86 */     if (value == null) {
/*  87 */       return null;
/*     */     }
/*  89 */     if (value instanceof CharSequence) {
/*  90 */       return new OriginTrackedCharSequence((CharSequence)value, origin);
/*     */     }
/*  92 */     return new OriginTrackedValue(value, origin);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class OriginTrackedCharSequence
/*     */     extends OriginTrackedValue
/*     */     implements CharSequence
/*     */   {
/*     */     OriginTrackedCharSequence(CharSequence value, Origin origin) {
/* 101 */       super(value, origin);
/*     */     }
/*     */ 
/*     */     
/*     */     public int length() {
/* 106 */       return getValue().length();
/*     */     }
/*     */ 
/*     */     
/*     */     public char charAt(int index) {
/* 111 */       return getValue().charAt(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence subSequence(int start, int end) {
/* 116 */       return getValue().subSequence(start, end);
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence getValue() {
/* 121 */       return (CharSequence)super.getValue();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\origin\OriginTrackedValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
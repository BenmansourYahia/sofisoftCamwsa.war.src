/*     */ package org.springframework.boot.context;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.annotation.ComponentScan;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationWarningsApplicationContextInitializer
/*     */   implements ApplicationContextInitializer<ConfigurableApplicationContext>
/*     */ {
/*  55 */   private static final Log logger = LogFactory.getLog(ConfigurationWarningsApplicationContextInitializer.class);
/*     */ 
/*     */   
/*     */   public void initialize(ConfigurableApplicationContext context) {
/*  59 */     context.addBeanFactoryPostProcessor((BeanFactoryPostProcessor)new ConfigurationWarningsPostProcessor(getChecks()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Check[] getChecks() {
/*  67 */     return new Check[] { new ComponentScanPackageCheck() };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final class ConfigurationWarningsPostProcessor
/*     */     implements PriorityOrdered, BeanDefinitionRegistryPostProcessor
/*     */   {
/*     */     private ConfigurationWarningsApplicationContextInitializer.Check[] checks;
/*     */ 
/*     */     
/*     */     public ConfigurationWarningsPostProcessor(ConfigurationWarningsApplicationContextInitializer.Check[] checks) {
/*  79 */       this.checks = checks;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/*  84 */       return 2147483646;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */     
/*     */     public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/*  93 */       for (ConfigurationWarningsApplicationContextInitializer.Check check : this.checks) {
/*  94 */         String message = check.getWarning(registry);
/*  95 */         if (StringUtils.hasLength(message)) {
/*  96 */           warn(message);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void warn(String message) {
/* 103 */       if (ConfigurationWarningsApplicationContextInitializer.logger.isWarnEnabled()) {
/* 104 */         ConfigurationWarningsApplicationContextInitializer.logger.warn(String.format("%n%n** WARNING ** : %s%n%n", new Object[] { message }));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface Check
/*     */   {
/*     */     String getWarning(BeanDefinitionRegistry param1BeanDefinitionRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class ComponentScanPackageCheck
/*     */     implements Check
/*     */   {
/*     */     private static final Set<String> PROBLEM_PACKAGES;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/* 133 */       Set<String> packages = new HashSet<>();
/* 134 */       packages.add("org.springframework");
/* 135 */       packages.add("org");
/* 136 */       PROBLEM_PACKAGES = Collections.unmodifiableSet(packages);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getWarning(BeanDefinitionRegistry registry) {
/* 141 */       Set<String> scannedPackages = getComponentScanningPackages(registry);
/* 142 */       List<String> problematicPackages = getProblematicPackages(scannedPackages);
/* 143 */       if (problematicPackages.isEmpty()) {
/* 144 */         return null;
/*     */       }
/* 146 */       return "Your ApplicationContext is unlikely to start due to a @ComponentScan of " + 
/* 147 */         StringUtils.collectionToDelimitedString(problematicPackages, ", ") + ".";
/*     */     }
/*     */     
/*     */     protected Set<String> getComponentScanningPackages(BeanDefinitionRegistry registry) {
/* 151 */       Set<String> packages = new LinkedHashSet<>();
/* 152 */       String[] names = registry.getBeanDefinitionNames();
/* 153 */       for (String name : names) {
/* 154 */         BeanDefinition definition = registry.getBeanDefinition(name);
/* 155 */         if (definition instanceof AnnotatedBeanDefinition) {
/* 156 */           AnnotatedBeanDefinition annotatedDefinition = (AnnotatedBeanDefinition)definition;
/* 157 */           addComponentScanningPackages(packages, annotatedDefinition.getMetadata());
/*     */         } 
/*     */       } 
/* 160 */       return packages;
/*     */     }
/*     */ 
/*     */     
/*     */     private void addComponentScanningPackages(Set<String> packages, AnnotationMetadata metadata) {
/* 165 */       AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(ComponentScan.class.getName(), true));
/* 166 */       if (attributes != null) {
/* 167 */         addPackages(packages, attributes.getStringArray("value"));
/* 168 */         addPackages(packages, attributes.getStringArray("basePackages"));
/* 169 */         addClasses(packages, attributes.getStringArray("basePackageClasses"));
/* 170 */         if (packages.isEmpty()) {
/* 171 */           packages.add(ClassUtils.getPackageName(metadata.getClassName()));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private void addPackages(Set<String> packages, String[] values) {
/* 177 */       if (values != null) {
/* 178 */         Collections.addAll(packages, values);
/*     */       }
/*     */     }
/*     */     
/*     */     private void addClasses(Set<String> packages, String[] values) {
/* 183 */       if (values != null) {
/* 184 */         for (String value : values) {
/* 185 */           packages.add(ClassUtils.getPackageName(value));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private List<String> getProblematicPackages(Set<String> scannedPackages) {
/* 191 */       List<String> problematicPackages = new ArrayList<>();
/* 192 */       for (String scannedPackage : scannedPackages) {
/* 193 */         if (isProblematicPackage(scannedPackage)) {
/* 194 */           problematicPackages.add(getDisplayName(scannedPackage));
/*     */         }
/*     */       } 
/* 197 */       return problematicPackages;
/*     */     }
/*     */     
/*     */     private boolean isProblematicPackage(String scannedPackage) {
/* 201 */       if (scannedPackage == null || scannedPackage.isEmpty()) {
/* 202 */         return true;
/*     */       }
/* 204 */       return PROBLEM_PACKAGES.contains(scannedPackage);
/*     */     }
/*     */     
/*     */     private String getDisplayName(String scannedPackage) {
/* 208 */       if (scannedPackage == null || scannedPackage.isEmpty()) {
/* 209 */         return "the default package";
/*     */       }
/* 211 */       return "'" + scannedPackage + "'";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\ConfigurationWarningsApplicationContextInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
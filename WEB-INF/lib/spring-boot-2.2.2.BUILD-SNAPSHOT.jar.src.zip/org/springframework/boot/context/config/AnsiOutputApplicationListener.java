/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.springframework.boot.ansi.AnsiOutput;
/*    */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnsiOutputApplicationListener
/*    */   implements ApplicationListener<ApplicationEnvironmentPreparedEvent>, Ordered
/*    */ {
/*    */   public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
/* 41 */     ConfigurableEnvironment environment = event.getEnvironment();
/* 42 */     Binder.get((Environment)environment).bind("spring.output.ansi.enabled", AnsiOutput.Enabled.class)
/* 43 */       .ifBound(AnsiOutput::setEnabled);
/* 44 */     AnsiOutput.setConsoleAvailable((Boolean)environment.getProperty("spring.output.ansi.console-available", Boolean.class));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 50 */     return -2147483637;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\config\AnsiOutputApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
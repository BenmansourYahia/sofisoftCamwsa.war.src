/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingApplicationContextInitializer
/*     */   implements ApplicationContextInitializer<ConfigurableApplicationContext>, Ordered
/*     */ {
/*     */   private static final String PROPERTY_NAME = "context.initializer.classes";
/*  49 */   private int order = 0;
/*     */ 
/*     */   
/*     */   public void initialize(ConfigurableApplicationContext context) {
/*  53 */     ConfigurableEnvironment environment = context.getEnvironment();
/*  54 */     List<Class<?>> initializerClasses = getInitializerClasses(environment);
/*  55 */     if (!initializerClasses.isEmpty()) {
/*  56 */       applyInitializerClasses(context, initializerClasses);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Class<?>> getInitializerClasses(ConfigurableEnvironment env) {
/*  61 */     String classNames = env.getProperty("context.initializer.classes");
/*  62 */     List<Class<?>> classes = new ArrayList<>();
/*  63 */     if (StringUtils.hasLength(classNames)) {
/*  64 */       for (String className : StringUtils.tokenizeToStringArray(classNames, ",")) {
/*  65 */         classes.add(getInitializerClass(className));
/*     */       }
/*     */     }
/*  68 */     return classes;
/*     */   }
/*     */   
/*     */   private Class<?> getInitializerClass(String className) throws LinkageError {
/*     */     try {
/*  73 */       Class<?> initializerClass = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/*  74 */       Assert.isAssignable(ApplicationContextInitializer.class, initializerClass);
/*  75 */       return initializerClass;
/*     */     }
/*  77 */     catch (ClassNotFoundException ex) {
/*  78 */       throw new ApplicationContextException("Failed to load context initializer class [" + className + "]", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void applyInitializerClasses(ConfigurableApplicationContext context, List<Class<?>> initializerClasses) {
/*  83 */     Class<?> contextClass = context.getClass();
/*  84 */     List<ApplicationContextInitializer<?>> initializers = new ArrayList<>();
/*  85 */     for (Class<?> initializerClass : initializerClasses) {
/*  86 */       initializers.add(instantiateInitializer(contextClass, initializerClass));
/*     */     }
/*  88 */     applyInitializers(context, initializers);
/*     */   }
/*     */   
/*     */   private ApplicationContextInitializer<?> instantiateInitializer(Class<?> contextClass, Class<?> initializerClass) {
/*  92 */     Class<?> requireContextClass = GenericTypeResolver.resolveTypeArgument(initializerClass, ApplicationContextInitializer.class);
/*     */     
/*  94 */     Assert.isAssignable(requireContextClass, contextClass, 
/*  95 */         String.format("Could not add context initializer [%s] as its generic parameter [%s] is not assignable from the type of application context used by this context loader [%s]: ", new Object[] {
/*     */ 
/*     */             
/*  98 */             initializerClass.getName(), requireContextClass.getName(), contextClass.getName() }));
/*  99 */     return (ApplicationContextInitializer)BeanUtils.instantiateClass(initializerClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyInitializers(ConfigurableApplicationContext context, List<ApplicationContextInitializer<?>> initializers) {
/* 105 */     initializers.sort((Comparator<? super ApplicationContextInitializer<?>>)new AnnotationAwareOrderComparator());
/* 106 */     for (ApplicationContextInitializer<?> initializer : initializers) {
/* 107 */       initializer.initialize(context);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 112 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 117 */     return this.order;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\config\DelegatingApplicationContextInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
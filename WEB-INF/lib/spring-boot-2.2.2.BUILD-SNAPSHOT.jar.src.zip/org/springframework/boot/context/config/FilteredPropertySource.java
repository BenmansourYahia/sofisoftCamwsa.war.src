/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FilteredPropertySource
/*    */   extends PropertySource<PropertySource<?>>
/*    */ {
/*    */   private final Set<String> filteredProperties;
/*    */   
/*    */   FilteredPropertySource(PropertySource<?> original, Set<String> filteredProperties) {
/* 37 */     super(original.getName(), original);
/* 38 */     this.filteredProperties = filteredProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getProperty(String name) {
/* 43 */     if (this.filteredProperties.contains(name)) {
/* 44 */       return null;
/*    */     }
/* 46 */     return ((PropertySource)getSource()).getProperty(name);
/*    */   }
/*    */ 
/*    */   
/*    */   static void apply(ConfigurableEnvironment environment, String propertySourceName, Set<String> filteredProperties, Consumer<PropertySource<?>> operation) {
/* 51 */     MutablePropertySources propertySources = environment.getPropertySources();
/* 52 */     PropertySource<?> original = propertySources.get(propertySourceName);
/* 53 */     if (original == null) {
/* 54 */       operation.accept(null);
/*    */       return;
/*    */     } 
/* 57 */     propertySources.replace(propertySourceName, new FilteredPropertySource(original, filteredProperties));
/*    */     try {
/* 59 */       operation.accept(original);
/*    */     } finally {
/*    */       
/* 62 */       propertySources.replace(propertySourceName, original);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\config\FilteredPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
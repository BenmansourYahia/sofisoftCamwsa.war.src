/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationPreparedEvent;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.bind.PropertySourcesPlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*     */ import org.springframework.boot.env.EnvironmentPostProcessor;
/*     */ import org.springframework.boot.env.PropertySourceLoader;
/*     */ import org.springframework.boot.env.RandomValuePropertySource;
/*     */ import org.springframework.boot.logging.DeferredLog;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.SmartApplicationListener;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.Profiles;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigFileApplicationListener
/*     */   implements EnvironmentPostProcessor, SmartApplicationListener, Ordered
/*     */ {
/*     */   private static final String DEFAULT_PROPERTIES = "defaultProperties";
/*     */   private static final String DEFAULT_SEARCH_LOCATIONS = "classpath:/,classpath:/config/,file:./,file:./config/";
/*     */   private static final String DEFAULT_NAMES = "application";
/* 114 */   private static final Set<String> NO_SEARCH_NAMES = Collections.singleton(null);
/*     */   
/* 116 */   private static final Bindable<String[]> STRING_ARRAY = Bindable.of(String[].class);
/*     */   
/* 118 */   private static final Bindable<List<String>> STRING_LIST = Bindable.listOf(String.class);
/*     */   
/*     */   private static final Set<String> LOAD_FILTERED_PROPERTY;
/*     */   
/*     */   static {
/* 123 */     Set<String> filteredProperties = new HashSet<>();
/* 124 */     filteredProperties.add("spring.profiles.active");
/* 125 */     filteredProperties.add("spring.profiles.include");
/* 126 */     LOAD_FILTERED_PROPERTY = Collections.unmodifiableSet(filteredProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ACTIVE_PROFILES_PROPERTY = "spring.profiles.active";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String INCLUDE_PROFILES_PROPERTY = "spring.profiles.include";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONFIG_NAME_PROPERTY = "spring.config.name";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONFIG_LOCATION_PROPERTY = "spring.config.location";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONFIG_ADDITIONAL_LOCATION_PROPERTY = "spring.config.additional-location";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_ORDER = -2147483638;
/*     */ 
/*     */ 
/*     */   
/* 159 */   private final DeferredLog logger = new DeferredLog();
/*     */   
/*     */   private String searchLocations;
/*     */   
/*     */   private String names;
/*     */   
/* 165 */   private int order = -2147483638;
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType) {
/* 169 */     return (ApplicationEnvironmentPreparedEvent.class.isAssignableFrom(eventType) || ApplicationPreparedEvent.class
/* 170 */       .isAssignableFrom(eventType));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/* 175 */     if (event instanceof ApplicationEnvironmentPreparedEvent) {
/* 176 */       onApplicationEnvironmentPreparedEvent((ApplicationEnvironmentPreparedEvent)event);
/*     */     }
/* 178 */     if (event instanceof ApplicationPreparedEvent) {
/* 179 */       onApplicationPreparedEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationEnvironmentPreparedEvent(ApplicationEnvironmentPreparedEvent event) {
/* 184 */     List<EnvironmentPostProcessor> postProcessors = loadPostProcessors();
/* 185 */     postProcessors.add(this);
/* 186 */     AnnotationAwareOrderComparator.sort(postProcessors);
/* 187 */     for (EnvironmentPostProcessor postProcessor : postProcessors) {
/* 188 */       postProcessor.postProcessEnvironment(event.getEnvironment(), event.getSpringApplication());
/*     */     }
/*     */   }
/*     */   
/*     */   List<EnvironmentPostProcessor> loadPostProcessors() {
/* 193 */     return SpringFactoriesLoader.loadFactories(EnvironmentPostProcessor.class, getClass().getClassLoader());
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/* 198 */     addPropertySources(environment, application.getResourceLoader());
/*     */   }
/*     */   
/*     */   private void onApplicationPreparedEvent(ApplicationEvent event) {
/* 202 */     this.logger.switchTo(ConfigFileApplicationListener.class);
/* 203 */     addPostProcessors(((ApplicationPreparedEvent)event).getApplicationContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addPropertySources(ConfigurableEnvironment environment, ResourceLoader resourceLoader) {
/* 213 */     RandomValuePropertySource.addToEnvironment(environment);
/* 214 */     (new Loader(environment, resourceLoader)).load();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addPostProcessors(ConfigurableApplicationContext context) {
/* 222 */     context.addBeanFactoryPostProcessor(new PropertySourceOrderingPostProcessor(context));
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 226 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 231 */     return this.order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSearchLocations(String locations) {
/* 244 */     Assert.hasLength(locations, "Locations must not be empty");
/* 245 */     this.searchLocations = locations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSearchNames(String names) {
/* 254 */     Assert.hasLength(names, "Names must not be empty");
/* 255 */     this.names = names;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PropertySourceOrderingPostProcessor
/*     */     implements BeanFactoryPostProcessor, Ordered
/*     */   {
/*     */     private ConfigurableApplicationContext context;
/*     */ 
/*     */     
/*     */     PropertySourceOrderingPostProcessor(ConfigurableApplicationContext context) {
/* 267 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 272 */       return Integer.MIN_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/* 277 */       reorderSources(this.context.getEnvironment());
/*     */     }
/*     */     
/*     */     private void reorderSources(ConfigurableEnvironment environment) {
/* 281 */       PropertySource<?> defaultProperties = environment.getPropertySources().remove("defaultProperties");
/* 282 */       if (defaultProperties != null) {
/* 283 */         environment.getPropertySources().addLast(defaultProperties);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Loader
/*     */   {
/* 294 */     private final Log logger = (Log)ConfigFileApplicationListener.this.logger;
/*     */     
/*     */     private final ConfigurableEnvironment environment;
/*     */     
/*     */     private final PropertySourcesPlaceholdersResolver placeholdersResolver;
/*     */     
/*     */     private final ResourceLoader resourceLoader;
/*     */     
/*     */     private final List<PropertySourceLoader> propertySourceLoaders;
/*     */     
/*     */     private Deque<ConfigFileApplicationListener.Profile> profiles;
/*     */     
/*     */     private List<ConfigFileApplicationListener.Profile> processedProfiles;
/*     */     
/*     */     private boolean activatedProfiles;
/*     */     
/*     */     private Map<ConfigFileApplicationListener.Profile, MutablePropertySources> loaded;
/*     */     
/* 312 */     private Map<ConfigFileApplicationListener.DocumentsCacheKey, List<ConfigFileApplicationListener.Document>> loadDocumentsCache = new HashMap<>();
/*     */     
/*     */     Loader(ConfigurableEnvironment environment, ResourceLoader resourceLoader) {
/* 315 */       this.environment = environment;
/* 316 */       this.placeholdersResolver = new PropertySourcesPlaceholdersResolver((Environment)this.environment);
/* 317 */       this.resourceLoader = (resourceLoader != null) ? resourceLoader : (ResourceLoader)new DefaultResourceLoader();
/* 318 */       this.propertySourceLoaders = SpringFactoriesLoader.loadFactories(PropertySourceLoader.class, 
/* 319 */           getClass().getClassLoader());
/*     */     }
/*     */     
/*     */     void load() {
/* 323 */       FilteredPropertySource.apply(this.environment, "defaultProperties", ConfigFileApplicationListener.LOAD_FILTERED_PROPERTY, defaultProperties -> {
/*     */             this.profiles = new LinkedList<>();
/*     */             this.processedProfiles = new LinkedList<>();
/*     */             this.activatedProfiles = false;
/*     */             this.loaded = new LinkedHashMap<>();
/*     */             initializeProfiles();
/*     */             while (!this.profiles.isEmpty()) {
/*     */               ConfigFileApplicationListener.Profile profile = this.profiles.poll();
/*     */               if (isDefaultProfile(profile)) {
/*     */                 addProfileToEnvironment(profile.getName());
/*     */               }
/*     */               load(profile, this::getPositiveProfileFilter, addToLoaded(MutablePropertySources::addLast, false));
/*     */               this.processedProfiles.add(profile);
/*     */             } 
/*     */             load(null, this::getNegativeProfileFilter, addToLoaded(MutablePropertySources::addFirst, true));
/*     */             addLoadedPropertySources();
/*     */             applyActiveProfiles(defaultProperties);
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void initializeProfiles() {
/* 353 */       this.profiles.add((ConfigFileApplicationListener.Profile)null);
/* 354 */       Set<ConfigFileApplicationListener.Profile> activatedViaProperty = getProfilesFromProperty("spring.profiles.active");
/* 355 */       Set<ConfigFileApplicationListener.Profile> includedViaProperty = getProfilesFromProperty("spring.profiles.include");
/* 356 */       List<ConfigFileApplicationListener.Profile> otherActiveProfiles = getOtherActiveProfiles(activatedViaProperty, includedViaProperty);
/* 357 */       this.profiles.addAll(otherActiveProfiles);
/*     */ 
/*     */       
/* 360 */       this.profiles.addAll(includedViaProperty);
/* 361 */       addActiveProfiles(activatedViaProperty);
/* 362 */       if (this.profiles.size() == 1) {
/* 363 */         for (String defaultProfileName : this.environment.getDefaultProfiles()) {
/* 364 */           ConfigFileApplicationListener.Profile defaultProfile = new ConfigFileApplicationListener.Profile(defaultProfileName, true);
/* 365 */           this.profiles.add(defaultProfile);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private Set<ConfigFileApplicationListener.Profile> getProfilesFromProperty(String profilesProperty) {
/* 371 */       if (!this.environment.containsProperty(profilesProperty)) {
/* 372 */         return Collections.emptySet();
/*     */       }
/* 374 */       Binder binder = Binder.get((Environment)this.environment);
/* 375 */       Set<ConfigFileApplicationListener.Profile> profiles = getProfiles(binder, profilesProperty);
/* 376 */       return new LinkedHashSet<>(profiles);
/*     */     }
/*     */ 
/*     */     
/*     */     private List<ConfigFileApplicationListener.Profile> getOtherActiveProfiles(Set<ConfigFileApplicationListener.Profile> activatedViaProperty, Set<ConfigFileApplicationListener.Profile> includedViaProperty) {
/* 381 */       return (List<ConfigFileApplicationListener.Profile>)Arrays.<String>stream(this.environment.getActiveProfiles()).map(Profile::new).filter(profile -> 
/* 382 */           (!activatedViaProperty.contains(profile) && !includedViaProperty.contains(profile)))
/* 383 */         .collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     void addActiveProfiles(Set<ConfigFileApplicationListener.Profile> profiles) {
/* 387 */       if (profiles.isEmpty()) {
/*     */         return;
/*     */       }
/* 390 */       if (this.activatedProfiles) {
/* 391 */         if (this.logger.isDebugEnabled()) {
/* 392 */           this.logger.debug("Profiles already activated, '" + profiles + "' will not be applied");
/*     */         }
/*     */         return;
/*     */       } 
/* 396 */       this.profiles.addAll(profiles);
/* 397 */       if (this.logger.isDebugEnabled()) {
/* 398 */         this.logger.debug("Activated activeProfiles " + StringUtils.collectionToCommaDelimitedString(profiles));
/*     */       }
/* 400 */       this.activatedProfiles = true;
/* 401 */       removeUnprocessedDefaultProfiles();
/*     */     }
/*     */     
/*     */     private void removeUnprocessedDefaultProfiles() {
/* 405 */       this.profiles.removeIf(profile -> (profile != null && profile.isDefaultProfile()));
/*     */     }
/*     */     
/*     */     private ConfigFileApplicationListener.DocumentFilter getPositiveProfileFilter(ConfigFileApplicationListener.Profile profile) {
/* 409 */       return document -> (profile == null) ? ObjectUtils.isEmpty((Object[])document.getProfiles()) : (
/*     */ 
/*     */ 
/*     */         
/* 413 */         (ObjectUtils.containsElement((Object[])document.getProfiles(), profile.getName()) && this.environment.acceptsProfiles(Profiles.of(document.getProfiles()))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private ConfigFileApplicationListener.DocumentFilter getNegativeProfileFilter(ConfigFileApplicationListener.Profile profile) {
/* 419 */       return document -> (profile == null && !ObjectUtils.isEmpty((Object[])document.getProfiles()) && this.environment.acceptsProfiles(Profiles.of(document.getProfiles())));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private ConfigFileApplicationListener.DocumentConsumer addToLoaded(BiConsumer<MutablePropertySources, PropertySource<?>> addMethod, boolean checkForExisting) {
/* 425 */       return (profile, document) -> {
/*     */           if (checkForExisting) {
/*     */             for (MutablePropertySources mutablePropertySources : this.loaded.values()) {
/*     */               if (mutablePropertySources.contains(document.getPropertySource().getName())) {
/*     */                 return;
/*     */               }
/*     */             } 
/*     */           }
/*     */           MutablePropertySources merged = this.loaded.computeIfAbsent(profile, ());
/*     */           addMethod.accept(merged, document.getPropertySource());
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     private void load(ConfigFileApplicationListener.Profile profile, ConfigFileApplicationListener.DocumentFilterFactory filterFactory, ConfigFileApplicationListener.DocumentConsumer consumer) {
/* 440 */       getSearchLocations().forEach(location -> {
/*     */             boolean isFolder = location.endsWith("/");
/*     */             Set<String> names = isFolder ? getSearchNames() : ConfigFileApplicationListener.NO_SEARCH_NAMES;
/*     */             names.forEach(());
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     private void load(String location, String name, ConfigFileApplicationListener.Profile profile, ConfigFileApplicationListener.DocumentFilterFactory filterFactory, ConfigFileApplicationListener.DocumentConsumer consumer) {
/* 449 */       if (!StringUtils.hasText(name)) {
/* 450 */         for (PropertySourceLoader loader : this.propertySourceLoaders) {
/* 451 */           if (canLoadFileExtension(loader, location)) {
/* 452 */             load(loader, location, profile, filterFactory.getDocumentFilter(profile), consumer);
/*     */             return;
/*     */           } 
/*     */         } 
/* 456 */         throw new IllegalStateException("File extension of config file location '" + location + "' is not known to any PropertySourceLoader. If the location is meant to reference a directory, it must end in '/'");
/*     */       } 
/*     */ 
/*     */       
/* 460 */       Set<String> processed = new HashSet<>();
/* 461 */       for (PropertySourceLoader loader : this.propertySourceLoaders) {
/* 462 */         for (String fileExtension : loader.getFileExtensions()) {
/* 463 */           if (processed.add(fileExtension)) {
/* 464 */             loadForFileExtension(loader, location + name, "." + fileExtension, profile, filterFactory, consumer);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean canLoadFileExtension(PropertySourceLoader loader, String name) {
/* 472 */       return Arrays.<String>stream(loader.getFileExtensions())
/* 473 */         .anyMatch(fileExtension -> StringUtils.endsWithIgnoreCase(name, fileExtension));
/*     */     }
/*     */ 
/*     */     
/*     */     private void loadForFileExtension(PropertySourceLoader loader, String prefix, String fileExtension, ConfigFileApplicationListener.Profile profile, ConfigFileApplicationListener.DocumentFilterFactory filterFactory, ConfigFileApplicationListener.DocumentConsumer consumer) {
/* 478 */       ConfigFileApplicationListener.DocumentFilter defaultFilter = filterFactory.getDocumentFilter(null);
/* 479 */       ConfigFileApplicationListener.DocumentFilter profileFilter = filterFactory.getDocumentFilter(profile);
/* 480 */       if (profile != null) {
/*     */         
/* 482 */         String profileSpecificFile = prefix + "-" + profile + fileExtension;
/* 483 */         load(loader, profileSpecificFile, profile, defaultFilter, consumer);
/* 484 */         load(loader, profileSpecificFile, profile, profileFilter, consumer);
/*     */         
/* 486 */         for (ConfigFileApplicationListener.Profile processedProfile : this.processedProfiles) {
/* 487 */           if (processedProfile != null) {
/* 488 */             String previouslyLoaded = prefix + "-" + processedProfile + fileExtension;
/* 489 */             load(loader, previouslyLoaded, profile, profileFilter, consumer);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 494 */       load(loader, prefix + fileExtension, profile, profileFilter, consumer);
/*     */     }
/*     */ 
/*     */     
/*     */     private void load(PropertySourceLoader loader, String location, ConfigFileApplicationListener.Profile profile, ConfigFileApplicationListener.DocumentFilter filter, ConfigFileApplicationListener.DocumentConsumer consumer) {
/*     */       try {
/* 500 */         Resource resource = this.resourceLoader.getResource(location);
/* 501 */         if (resource == null || !resource.exists()) {
/* 502 */           if (this.logger.isTraceEnabled()) {
/* 503 */             StringBuilder description = getDescription("Skipped missing config ", location, resource, profile);
/*     */             
/* 505 */             this.logger.trace(description);
/*     */           } 
/*     */           return;
/*     */         } 
/* 509 */         if (!StringUtils.hasText(StringUtils.getFilenameExtension(resource.getFilename()))) {
/* 510 */           if (this.logger.isTraceEnabled()) {
/* 511 */             StringBuilder description = getDescription("Skipped empty config extension ", location, resource, profile);
/*     */             
/* 513 */             this.logger.trace(description);
/*     */           } 
/*     */           return;
/*     */         } 
/* 517 */         String name = "applicationConfig: [" + location + "]";
/* 518 */         List<ConfigFileApplicationListener.Document> documents = loadDocuments(loader, name, resource);
/* 519 */         if (CollectionUtils.isEmpty(documents)) {
/* 520 */           if (this.logger.isTraceEnabled()) {
/* 521 */             StringBuilder description = getDescription("Skipped unloaded config ", location, resource, profile);
/*     */             
/* 523 */             this.logger.trace(description);
/*     */           } 
/*     */           return;
/*     */         } 
/* 527 */         List<ConfigFileApplicationListener.Document> loaded = new ArrayList<>();
/* 528 */         for (ConfigFileApplicationListener.Document document : documents) {
/* 529 */           if (filter.match(document)) {
/* 530 */             addActiveProfiles(document.getActiveProfiles());
/* 531 */             addIncludedProfiles(document.getIncludeProfiles());
/* 532 */             loaded.add(document);
/*     */           } 
/*     */         } 
/* 535 */         Collections.reverse(loaded);
/* 536 */         if (!loaded.isEmpty()) {
/* 537 */           loaded.forEach(document -> consumer.accept(profile, document));
/* 538 */           if (this.logger.isDebugEnabled()) {
/* 539 */             StringBuilder description = getDescription("Loaded config file ", location, resource, profile);
/* 540 */             this.logger.debug(description);
/*     */           }
/*     */         
/*     */         } 
/* 544 */       } catch (Exception ex) {
/* 545 */         throw new IllegalStateException("Failed to load property source from location '" + location + "'", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void addIncludedProfiles(Set<ConfigFileApplicationListener.Profile> includeProfiles) {
/* 550 */       LinkedList<ConfigFileApplicationListener.Profile> existingProfiles = new LinkedList<>(this.profiles);
/* 551 */       this.profiles.clear();
/* 552 */       this.profiles.addAll(includeProfiles);
/* 553 */       this.profiles.removeAll(this.processedProfiles);
/* 554 */       this.profiles.addAll(existingProfiles);
/*     */     }
/*     */ 
/*     */     
/*     */     private List<ConfigFileApplicationListener.Document> loadDocuments(PropertySourceLoader loader, String name, Resource resource) throws IOException {
/* 559 */       ConfigFileApplicationListener.DocumentsCacheKey cacheKey = new ConfigFileApplicationListener.DocumentsCacheKey(loader, resource);
/* 560 */       List<ConfigFileApplicationListener.Document> documents = this.loadDocumentsCache.get(cacheKey);
/* 561 */       if (documents == null) {
/* 562 */         List<PropertySource<?>> loaded = loader.load(name, resource);
/* 563 */         documents = asDocuments(loaded);
/* 564 */         this.loadDocumentsCache.put(cacheKey, documents);
/*     */       } 
/* 566 */       return documents;
/*     */     }
/*     */     
/*     */     private List<ConfigFileApplicationListener.Document> asDocuments(List<PropertySource<?>> loaded) {
/* 570 */       if (loaded == null) {
/* 571 */         return Collections.emptyList();
/*     */       }
/* 573 */       return (List<ConfigFileApplicationListener.Document>)loaded.stream().map(propertySource -> {
/*     */             Binder binder = new Binder(ConfigurationPropertySources.from(propertySource), (PlaceholdersResolver)this.placeholdersResolver);
/*     */ 
/*     */             
/*     */             return new ConfigFileApplicationListener.Document(propertySource, (String[])binder.bind("spring.profiles", ConfigFileApplicationListener.STRING_ARRAY).orElse(null), getProfiles(binder, "spring.profiles.active"), getProfiles(binder, "spring.profiles.include"));
/* 578 */           }).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private StringBuilder getDescription(String prefix, String location, Resource resource, ConfigFileApplicationListener.Profile profile) {
/* 582 */       StringBuilder result = new StringBuilder(prefix);
/*     */       try {
/* 584 */         if (resource != null) {
/* 585 */           String uri = resource.getURI().toASCIIString();
/* 586 */           result.append("'");
/* 587 */           result.append(uri);
/* 588 */           result.append("' (");
/* 589 */           result.append(location);
/* 590 */           result.append(")");
/*     */         }
/*     */       
/* 593 */       } catch (IOException ex) {
/* 594 */         result.append(location);
/*     */       } 
/* 596 */       if (profile != null) {
/* 597 */         result.append(" for profile ");
/* 598 */         result.append(profile);
/*     */       } 
/* 600 */       return result;
/*     */     }
/*     */     
/*     */     private Set<ConfigFileApplicationListener.Profile> getProfiles(Binder binder, String name) {
/* 604 */       return (Set<ConfigFileApplicationListener.Profile>)binder.bind(name, ConfigFileApplicationListener.STRING_ARRAY).map(this::asProfileSet).orElse(Collections.emptySet());
/*     */     }
/*     */     
/*     */     private Set<ConfigFileApplicationListener.Profile> asProfileSet(String[] profileNames) {
/* 608 */       List<ConfigFileApplicationListener.Profile> profiles = new ArrayList<>();
/* 609 */       for (String profileName : profileNames) {
/* 610 */         profiles.add(new ConfigFileApplicationListener.Profile(profileName));
/*     */       }
/* 612 */       return new LinkedHashSet<>(profiles);
/*     */     }
/*     */     
/*     */     private void addProfileToEnvironment(String profile) {
/* 616 */       for (String activeProfile : this.environment.getActiveProfiles()) {
/* 617 */         if (activeProfile.equals(profile)) {
/*     */           return;
/*     */         }
/*     */       } 
/* 621 */       this.environment.addActiveProfile(profile);
/*     */     }
/*     */     
/*     */     private Set<String> getSearchLocations() {
/* 625 */       if (this.environment.containsProperty("spring.config.location")) {
/* 626 */         return getSearchLocations("spring.config.location");
/*     */       }
/* 628 */       Set<String> locations = getSearchLocations("spring.config.additional-location");
/* 629 */       locations.addAll(
/* 630 */           asResolvedSet(ConfigFileApplicationListener.this.searchLocations, "classpath:/,classpath:/config/,file:./,file:./config/"));
/* 631 */       return locations;
/*     */     }
/*     */     
/*     */     private Set<String> getSearchLocations(String propertyName) {
/* 635 */       Set<String> locations = new LinkedHashSet<>();
/* 636 */       if (this.environment.containsProperty(propertyName)) {
/* 637 */         for (String path : asResolvedSet(this.environment.getProperty(propertyName), null)) {
/* 638 */           if (!path.contains("$")) {
/* 639 */             path = StringUtils.cleanPath(path);
/* 640 */             if (!ResourceUtils.isUrl(path)) {
/* 641 */               path = "file:" + path;
/*     */             }
/*     */           } 
/* 644 */           locations.add(path);
/*     */         } 
/*     */       }
/* 647 */       return locations;
/*     */     }
/*     */     
/*     */     private Set<String> getSearchNames() {
/* 651 */       if (this.environment.containsProperty("spring.config.name")) {
/* 652 */         String property = this.environment.getProperty("spring.config.name");
/* 653 */         return asResolvedSet(property, null);
/*     */       } 
/* 655 */       return asResolvedSet(ConfigFileApplicationListener.this.names, "application");
/*     */     }
/*     */     
/*     */     private Set<String> asResolvedSet(String value, String fallback) {
/* 659 */       List<String> list = Arrays.asList(StringUtils.trimArrayElements(StringUtils.commaDelimitedListToStringArray((value != null) ? this.environment
/* 660 */               .resolvePlaceholders(value) : fallback)));
/* 661 */       Collections.reverse(list);
/* 662 */       return new LinkedHashSet<>(list);
/*     */     }
/*     */     
/*     */     private void addLoadedPropertySources() {
/* 666 */       MutablePropertySources destination = this.environment.getPropertySources();
/* 667 */       List<MutablePropertySources> loaded = new ArrayList<>(this.loaded.values());
/* 668 */       Collections.reverse(loaded);
/* 669 */       String lastAdded = null;
/* 670 */       Set<String> added = new HashSet<>();
/* 671 */       for (MutablePropertySources sources : loaded) {
/* 672 */         for (PropertySource<?> source : (Iterable<PropertySource<?>>)sources) {
/* 673 */           if (added.add(source.getName())) {
/* 674 */             addLoadedPropertySource(destination, lastAdded, source);
/* 675 */             lastAdded = source.getName();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void addLoadedPropertySource(MutablePropertySources destination, String lastAdded, PropertySource<?> source) {
/* 683 */       if (lastAdded == null) {
/* 684 */         if (destination.contains("defaultProperties")) {
/* 685 */           destination.addBefore("defaultProperties", source);
/*     */         } else {
/*     */           
/* 688 */           destination.addLast(source);
/*     */         } 
/*     */       } else {
/*     */         
/* 692 */         destination.addAfter(lastAdded, source);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void applyActiveProfiles(PropertySource<?> defaultProperties) {
/* 697 */       List<String> activeProfiles = new ArrayList<>();
/* 698 */       if (defaultProperties != null) {
/* 699 */         Binder binder = new Binder(ConfigurationPropertySources.from(defaultProperties), (PlaceholdersResolver)new PropertySourcesPlaceholdersResolver((Environment)this.environment));
/*     */         
/* 701 */         activeProfiles.addAll(getDefaultProfiles(binder, "spring.profiles.include"));
/* 702 */         if (!this.activatedProfiles) {
/* 703 */           activeProfiles.addAll(getDefaultProfiles(binder, "spring.profiles.active"));
/*     */         }
/*     */       } 
/* 706 */       this.processedProfiles.stream().filter(this::isDefaultProfile).map(ConfigFileApplicationListener.Profile::getName)
/* 707 */         .forEach(activeProfiles::add);
/* 708 */       this.environment.setActiveProfiles(activeProfiles.<String>toArray(new String[0]));
/*     */     }
/*     */     
/*     */     private boolean isDefaultProfile(ConfigFileApplicationListener.Profile profile) {
/* 712 */       return (profile != null && !profile.isDefaultProfile());
/*     */     }
/*     */     
/*     */     private List<String> getDefaultProfiles(Binder binder, String property) {
/* 716 */       return (List<String>)binder.bind(property, ConfigFileApplicationListener.STRING_LIST).orElse(Collections.emptyList());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Profile
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final boolean defaultProfile;
/*     */ 
/*     */     
/*     */     Profile(String name) {
/* 731 */       this(name, false);
/*     */     }
/*     */     
/*     */     Profile(String name, boolean defaultProfile) {
/* 735 */       Assert.notNull(name, "Name must not be null");
/* 736 */       this.name = name;
/* 737 */       this.defaultProfile = defaultProfile;
/*     */     }
/*     */     
/*     */     String getName() {
/* 741 */       return this.name;
/*     */     }
/*     */     
/*     */     boolean isDefaultProfile() {
/* 745 */       return this.defaultProfile;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 750 */       if (obj == this) {
/* 751 */         return true;
/*     */       }
/* 753 */       if (obj == null || obj.getClass() != getClass()) {
/* 754 */         return false;
/*     */       }
/* 756 */       return ((Profile)obj).name.equals(this.name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 761 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 766 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DocumentsCacheKey
/*     */   {
/*     */     private final PropertySourceLoader loader;
/*     */ 
/*     */     
/*     */     private final Resource resource;
/*     */ 
/*     */     
/*     */     DocumentsCacheKey(PropertySourceLoader loader, Resource resource) {
/* 781 */       this.loader = loader;
/* 782 */       this.resource = resource;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 787 */       if (this == obj) {
/* 788 */         return true;
/*     */       }
/* 790 */       if (obj == null || getClass() != obj.getClass()) {
/* 791 */         return false;
/*     */       }
/* 793 */       DocumentsCacheKey other = (DocumentsCacheKey)obj;
/* 794 */       return (this.loader.equals(other.loader) && this.resource.equals(other.resource));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 799 */       return this.loader.hashCode() * 31 + this.resource.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Document
/*     */   {
/*     */     private final PropertySource<?> propertySource;
/*     */ 
/*     */     
/*     */     private String[] profiles;
/*     */ 
/*     */     
/*     */     private final Set<ConfigFileApplicationListener.Profile> activeProfiles;
/*     */     
/*     */     private final Set<ConfigFileApplicationListener.Profile> includeProfiles;
/*     */ 
/*     */     
/*     */     Document(PropertySource<?> propertySource, String[] profiles, Set<ConfigFileApplicationListener.Profile> activeProfiles, Set<ConfigFileApplicationListener.Profile> includeProfiles) {
/* 819 */       this.propertySource = propertySource;
/* 820 */       this.profiles = profiles;
/* 821 */       this.activeProfiles = activeProfiles;
/* 822 */       this.includeProfiles = includeProfiles;
/*     */     }
/*     */     
/*     */     PropertySource<?> getPropertySource() {
/* 826 */       return this.propertySource;
/*     */     }
/*     */     
/*     */     String[] getProfiles() {
/* 830 */       return this.profiles;
/*     */     }
/*     */     
/*     */     Set<ConfigFileApplicationListener.Profile> getActiveProfiles() {
/* 834 */       return this.activeProfiles;
/*     */     }
/*     */     
/*     */     Set<ConfigFileApplicationListener.Profile> getIncludeProfiles() {
/* 838 */       return this.includeProfiles;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 843 */       return this.propertySource.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface DocumentFilterFactory {
/*     */     ConfigFileApplicationListener.DocumentFilter getDocumentFilter(ConfigFileApplicationListener.Profile param1Profile);
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface DocumentFilter {
/*     */     boolean match(ConfigFileApplicationListener.Document param1Document);
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface DocumentConsumer {
/*     */     void accept(ConfigFileApplicationListener.Profile param1Profile, ConfigFileApplicationListener.Document param1Document);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\config\ConfigFileApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
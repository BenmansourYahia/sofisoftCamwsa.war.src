/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingApplicationListener
/*     */   implements ApplicationListener<ApplicationEvent>, Ordered
/*     */ {
/*     */   private static final String PROPERTY_NAME = "context.listener.classes";
/*  50 */   private int order = 0;
/*     */   
/*     */   private SimpleApplicationEventMulticaster multicaster;
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/*  56 */     if (event instanceof ApplicationEnvironmentPreparedEvent) {
/*  57 */       List<ApplicationListener<ApplicationEvent>> delegates = getListeners(((ApplicationEnvironmentPreparedEvent)event)
/*  58 */           .getEnvironment());
/*  59 */       if (delegates.isEmpty()) {
/*     */         return;
/*     */       }
/*  62 */       this.multicaster = new SimpleApplicationEventMulticaster();
/*  63 */       for (ApplicationListener<ApplicationEvent> listener : delegates) {
/*  64 */         this.multicaster.addApplicationListener(listener);
/*     */       }
/*     */     } 
/*  67 */     if (this.multicaster != null) {
/*  68 */       this.multicaster.multicastEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ApplicationListener<ApplicationEvent>> getListeners(ConfigurableEnvironment environment) {
/*  74 */     if (environment == null) {
/*  75 */       return Collections.emptyList();
/*     */     }
/*  77 */     String classNames = environment.getProperty("context.listener.classes");
/*  78 */     List<ApplicationListener<ApplicationEvent>> listeners = new ArrayList<>();
/*  79 */     if (StringUtils.hasLength(classNames)) {
/*  80 */       for (String className : StringUtils.commaDelimitedListToSet(classNames)) {
/*     */         try {
/*  82 */           Class<?> clazz = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/*  83 */           Assert.isAssignable(ApplicationListener.class, clazz, "class [" + className + "] must implement ApplicationListener");
/*     */           
/*  85 */           listeners.add((ApplicationListener<ApplicationEvent>)BeanUtils.instantiateClass(clazz));
/*     */         }
/*  87 */         catch (Exception ex) {
/*  88 */           throw new ApplicationContextException("Failed to load context listener class [" + className + "]", ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*  93 */     AnnotationAwareOrderComparator.sort(listeners);
/*  94 */     return listeners;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  98 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 103 */     return this.order;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\config\DelegatingApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
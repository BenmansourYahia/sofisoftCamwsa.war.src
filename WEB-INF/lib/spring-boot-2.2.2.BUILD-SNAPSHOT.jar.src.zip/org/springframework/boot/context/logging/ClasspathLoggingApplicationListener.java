/*    */ package org.springframework.boot.context.logging;
/*    */ 
/*    */ import java.net.URLClassLoader;
/*    */ import java.util.Arrays;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*    */ import org.springframework.boot.context.event.ApplicationFailedEvent;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.event.GenericApplicationListener;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClasspathLoggingApplicationListener
/*    */   implements GenericApplicationListener
/*    */ {
/*    */   private static final int ORDER = -2147483627;
/* 45 */   private static final Log logger = LogFactory.getLog(ClasspathLoggingApplicationListener.class);
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(ApplicationEvent event) {
/* 49 */     if (logger.isDebugEnabled()) {
/* 50 */       if (event instanceof ApplicationEnvironmentPreparedEvent) {
/* 51 */         logger.debug("Application started with classpath: " + getClasspath());
/*    */       }
/* 53 */       else if (event instanceof ApplicationFailedEvent) {
/* 54 */         logger.debug("Application failed to start with classpath: " + getClasspath());
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 61 */     return -2147483627;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supportsEventType(ResolvableType resolvableType) {
/* 66 */     Class<?> type = resolvableType.getRawClass();
/* 67 */     if (type == null) {
/* 68 */       return false;
/*    */     }
/* 70 */     return (ApplicationEnvironmentPreparedEvent.class.isAssignableFrom(type) || ApplicationFailedEvent.class
/* 71 */       .isAssignableFrom(type));
/*    */   }
/*    */   
/*    */   private String getClasspath() {
/* 75 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 76 */     if (classLoader instanceof URLClassLoader) {
/* 77 */       return Arrays.toString((Object[])((URLClassLoader)classLoader).getURLs());
/*    */     }
/* 79 */     return "unknown";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\logging\ClasspathLoggingApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
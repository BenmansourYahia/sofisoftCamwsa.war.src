/*     */ package org.springframework.boot.context.logging;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationFailedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationStartingEvent;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggerGroup;
/*     */ import org.springframework.boot.logging.LoggerGroups;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.boot.logging.LoggingSystem;
/*     */ import org.springframework.boot.logging.LoggingSystemProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.event.ContextClosedEvent;
/*     */ import org.springframework.context.event.GenericApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingApplicationListener
/*     */   implements GenericApplicationListener
/*     */ {
/*  94 */   private static final ConfigurationPropertyName LOGGING_LEVEL = ConfigurationPropertyName.of("logging.level");
/*     */   
/*  96 */   private static final ConfigurationPropertyName LOGGING_GROUP = ConfigurationPropertyName.of("logging.group");
/*     */   
/*  98 */   private static final Bindable<Map<String, LogLevel>> STRING_LOGLEVEL_MAP = Bindable.mapOf(String.class, LogLevel.class);
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final Bindable<Map<String, List<String>>> STRING_STRINGS_MAP = Bindable.of(ResolvableType.forClassWithGenerics(MultiValueMap.class, new Class[] { String.class, String.class }).asMap());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_ORDER = -2147483628;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONFIG_PROPERTY = "logging.config";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String REGISTER_SHUTDOWN_HOOK_PROPERTY = "logging.register-shutdown-hook";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOGGING_SYSTEM_BEAN_NAME = "springBootLoggingSystem";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOG_FILE_BEAN_NAME = "springBootLogFile";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOGGER_GROUPS_BEAN_NAME = "springBootLoggerGroups";
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final String LOGFILE_BEAN_NAME = "springBootLogFile";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<String, List<String>> DEFAULT_GROUP_LOGGERS;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<LogLevel, List<String>> SPRING_BOOT_LOGGING_LOGGERS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 148 */     LinkedMultiValueMap linkedMultiValueMap2 = new LinkedMultiValueMap();
/* 149 */     linkedMultiValueMap2.add("web", "org.springframework.core.codec");
/* 150 */     linkedMultiValueMap2.add("web", "org.springframework.http");
/* 151 */     linkedMultiValueMap2.add("web", "org.springframework.web");
/* 152 */     linkedMultiValueMap2.add("web", "org.springframework.boot.actuate.endpoint.web");
/* 153 */     linkedMultiValueMap2.add("web", "org.springframework.boot.web.servlet.ServletContextInitializerBeans");
/* 154 */     linkedMultiValueMap2.add("sql", "org.springframework.jdbc.core");
/* 155 */     linkedMultiValueMap2.add("sql", "org.hibernate.SQL");
/* 156 */     linkedMultiValueMap2.add("sql", "org.jooq.tools.LoggerListener");
/* 157 */     DEFAULT_GROUP_LOGGERS = Collections.unmodifiableMap((Map<? extends String, ? extends List<String>>)linkedMultiValueMap2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     LinkedMultiValueMap linkedMultiValueMap1 = new LinkedMultiValueMap();
/* 163 */     linkedMultiValueMap1.add(LogLevel.DEBUG, "sql");
/* 164 */     linkedMultiValueMap1.add(LogLevel.DEBUG, "web");
/* 165 */     linkedMultiValueMap1.add(LogLevel.DEBUG, "org.springframework.boot");
/* 166 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.springframework");
/* 167 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.apache.tomcat");
/* 168 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.apache.catalina");
/* 169 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.eclipse.jetty");
/* 170 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.hibernate.tool.hbm2ddl");
/* 171 */     SPRING_BOOT_LOGGING_LOGGERS = Collections.unmodifiableMap((Map<? extends LogLevel, ? extends List<String>>)linkedMultiValueMap1);
/*     */   }
/*     */   
/* 174 */   private static final Class<?>[] EVENT_TYPES = new Class[] { ApplicationStartingEvent.class, ApplicationEnvironmentPreparedEvent.class, ApplicationPreparedEvent.class, ContextClosedEvent.class, ApplicationFailedEvent.class };
/*     */ 
/*     */ 
/*     */   
/* 178 */   private static final Class<?>[] SOURCE_TYPES = new Class[] { SpringApplication.class, ApplicationContext.class };
/*     */   
/* 180 */   private static final AtomicBoolean shutdownHookRegistered = new AtomicBoolean(false);
/*     */   
/* 182 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private LoggingSystem loggingSystem;
/*     */   
/*     */   private LogFile logFile;
/*     */   
/*     */   private LoggerGroups loggerGroups;
/*     */   
/* 190 */   private int order = -2147483628;
/*     */   
/*     */   private boolean parseArgs = true;
/*     */   
/* 194 */   private LogLevel springBootLogging = null;
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(ResolvableType resolvableType) {
/* 198 */     return isAssignableFrom(resolvableType.getRawClass(), EVENT_TYPES);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsSourceType(Class<?> sourceType) {
/* 203 */     return isAssignableFrom(sourceType, SOURCE_TYPES);
/*     */   }
/*     */   
/*     */   private boolean isAssignableFrom(Class<?> type, Class<?>... supportedTypes) {
/* 207 */     if (type != null) {
/* 208 */       for (Class<?> supportedType : supportedTypes) {
/* 209 */         if (supportedType.isAssignableFrom(type)) {
/* 210 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 214 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/* 219 */     if (event instanceof ApplicationStartingEvent) {
/* 220 */       onApplicationStartingEvent((ApplicationStartingEvent)event);
/*     */     }
/* 222 */     else if (event instanceof ApplicationEnvironmentPreparedEvent) {
/* 223 */       onApplicationEnvironmentPreparedEvent((ApplicationEnvironmentPreparedEvent)event);
/*     */     }
/* 225 */     else if (event instanceof ApplicationPreparedEvent) {
/* 226 */       onApplicationPreparedEvent((ApplicationPreparedEvent)event);
/*     */     }
/* 228 */     else if (event instanceof ContextClosedEvent && ((ContextClosedEvent)event)
/* 229 */       .getApplicationContext().getParent() == null) {
/* 230 */       onContextClosedEvent();
/*     */     }
/* 232 */     else if (event instanceof ApplicationFailedEvent) {
/* 233 */       onApplicationFailedEvent();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void onApplicationStartingEvent(ApplicationStartingEvent event) {
/* 238 */     this.loggingSystem = LoggingSystem.get(event.getSpringApplication().getClassLoader());
/* 239 */     this.loggingSystem.beforeInitialize();
/*     */   }
/*     */   
/*     */   private void onApplicationEnvironmentPreparedEvent(ApplicationEnvironmentPreparedEvent event) {
/* 243 */     if (this.loggingSystem == null) {
/* 244 */       this.loggingSystem = LoggingSystem.get(event.getSpringApplication().getClassLoader());
/*     */     }
/* 246 */     initialize(event.getEnvironment(), event.getSpringApplication().getClassLoader());
/*     */   }
/*     */   
/*     */   private void onApplicationPreparedEvent(ApplicationPreparedEvent event) {
/* 250 */     ConfigurableListableBeanFactory beanFactory = event.getApplicationContext().getBeanFactory();
/* 251 */     if (!beanFactory.containsBean("springBootLoggingSystem")) {
/* 252 */       beanFactory.registerSingleton("springBootLoggingSystem", this.loggingSystem);
/*     */     }
/* 254 */     if (this.logFile != null && !beanFactory.containsBean("springBootLogFile")) {
/* 255 */       beanFactory.registerSingleton("springBootLogFile", this.logFile);
/*     */     }
/* 257 */     if (this.loggerGroups != null && !beanFactory.containsBean("springBootLoggerGroups")) {
/* 258 */       beanFactory.registerSingleton("springBootLoggerGroups", this.loggerGroups);
/*     */     }
/*     */   }
/*     */   
/*     */   private void onContextClosedEvent() {
/* 263 */     if (this.loggingSystem != null) {
/* 264 */       this.loggingSystem.cleanUp();
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationFailedEvent() {
/* 269 */     if (this.loggingSystem != null) {
/* 270 */       this.loggingSystem.cleanUp();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(ConfigurableEnvironment environment, ClassLoader classLoader) {
/* 281 */     (new LoggingSystemProperties((Environment)environment)).apply();
/* 282 */     this.logFile = LogFile.get((PropertyResolver)environment);
/* 283 */     if (this.logFile != null) {
/* 284 */       this.logFile.applyToSystemProperties();
/*     */     }
/* 286 */     this.loggerGroups = new LoggerGroups(DEFAULT_GROUP_LOGGERS);
/* 287 */     initializeEarlyLoggingLevel(environment);
/* 288 */     initializeSystem(environment, this.loggingSystem, this.logFile);
/* 289 */     initializeFinalLoggingLevels(environment, this.loggingSystem);
/* 290 */     registerShutdownHookIfNecessary((Environment)environment, this.loggingSystem);
/*     */   }
/*     */   
/*     */   private void initializeEarlyLoggingLevel(ConfigurableEnvironment environment) {
/* 294 */     if (this.parseArgs && this.springBootLogging == null) {
/* 295 */       if (isSet(environment, "debug")) {
/* 296 */         this.springBootLogging = LogLevel.DEBUG;
/*     */       }
/* 298 */       if (isSet(environment, "trace")) {
/* 299 */         this.springBootLogging = LogLevel.TRACE;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isSet(ConfigurableEnvironment environment, String property) {
/* 305 */     String value = environment.getProperty(property);
/* 306 */     return (value != null && !value.equals("false"));
/*     */   }
/*     */   
/*     */   private void initializeSystem(ConfigurableEnvironment environment, LoggingSystem system, LogFile logFile) {
/* 310 */     LoggingInitializationContext initializationContext = new LoggingInitializationContext(environment);
/* 311 */     String logConfig = environment.getProperty("logging.config");
/* 312 */     if (ignoreLogConfig(logConfig)) {
/* 313 */       system.initialize(initializationContext, null, logFile);
/*     */     } else {
/*     */       
/*     */       try {
/* 317 */         ResourceUtils.getURL(logConfig).openStream().close();
/* 318 */         system.initialize(initializationContext, logConfig, logFile);
/*     */       }
/* 320 */       catch (Exception ex) {
/*     */         
/* 322 */         System.err.println("Logging system failed to initialize using configuration from '" + logConfig + "'");
/* 323 */         ex.printStackTrace(System.err);
/* 324 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean ignoreLogConfig(String logConfig) {
/* 330 */     return (!StringUtils.hasLength(logConfig) || logConfig.startsWith("-D"));
/*     */   }
/*     */   
/*     */   private void initializeFinalLoggingLevels(ConfigurableEnvironment environment, LoggingSystem system) {
/* 334 */     bindLoggerGroups(environment);
/* 335 */     if (this.springBootLogging != null) {
/* 336 */       initializeLogLevel(system, this.springBootLogging);
/*     */     }
/* 338 */     setLogLevels(system, environment);
/*     */   }
/*     */   
/*     */   private void bindLoggerGroups(ConfigurableEnvironment environment) {
/* 342 */     if (this.loggerGroups != null) {
/* 343 */       Binder binder = Binder.get((Environment)environment);
/* 344 */       binder.bind(LOGGING_GROUP, STRING_STRINGS_MAP).ifBound(this.loggerGroups::putAll);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void initializeLogLevel(LoggingSystem system, LogLevel springBootLogging) {
/* 358 */     initializeSpringBootLogging(system, springBootLogging);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initializeSpringBootLogging(LoggingSystem system, LogLevel springBootLogging) {
/* 370 */     BiConsumer<String, LogLevel> configurer = getLogLevelConfigurer(system);
/* 371 */     ((List)SPRING_BOOT_LOGGING_LOGGERS.getOrDefault(springBootLogging, Collections.emptyList()))
/* 372 */       .forEach(name -> configureLogLevel(name, springBootLogging, configurer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void setLogLevels(LoggingSystem system, Environment environment) {
/* 384 */     if (environment instanceof ConfigurableEnvironment) {
/* 385 */       setLogLevels(system, (ConfigurableEnvironment)environment);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLogLevels(LoggingSystem system, ConfigurableEnvironment environment) {
/* 396 */     BiConsumer<String, LogLevel> customizer = getLogLevelConfigurer(system);
/* 397 */     Binder binder = Binder.get((Environment)environment);
/* 398 */     Map<String, LogLevel> levels = (Map<String, LogLevel>)binder.bind(LOGGING_LEVEL, STRING_LOGLEVEL_MAP).orElseGet(Collections::emptyMap);
/* 399 */     levels.forEach((name, level) -> configureLogLevel(name, level, customizer));
/*     */   }
/*     */   
/*     */   private void configureLogLevel(String name, LogLevel level, BiConsumer<String, LogLevel> configurer) {
/* 403 */     if (this.loggerGroups != null) {
/* 404 */       LoggerGroup group = this.loggerGroups.get(name);
/* 405 */       if (group != null && group.hasMembers()) {
/* 406 */         group.configureLogLevel(level, configurer);
/*     */         return;
/*     */       } 
/*     */     } 
/* 410 */     configurer.accept(name, level);
/*     */   }
/*     */   
/*     */   private BiConsumer<String, LogLevel> getLogLevelConfigurer(LoggingSystem system) {
/* 414 */     return (name, level) -> {
/*     */         try {
/*     */           name = name.equalsIgnoreCase("ROOT") ? null : name;
/*     */           
/*     */           system.setLogLevel(name, level);
/* 419 */         } catch (RuntimeException ex) {
/*     */           this.logger.error(LogMessage.format("Cannot set level '%s' for '%s'", level, name));
/*     */         } 
/*     */       };
/*     */   }
/*     */   
/*     */   private void registerShutdownHookIfNecessary(Environment environment, LoggingSystem loggingSystem) {
/* 426 */     boolean registerShutdownHook = ((Boolean)environment.getProperty("logging.register-shutdown-hook", Boolean.class, Boolean.valueOf(false))).booleanValue();
/* 427 */     if (registerShutdownHook) {
/* 428 */       Runnable shutdownHandler = loggingSystem.getShutdownHandler();
/* 429 */       if (shutdownHandler != null && shutdownHookRegistered.compareAndSet(false, true)) {
/* 430 */         registerShutdownHook(new Thread(shutdownHandler));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   void registerShutdownHook(Thread shutdownHook) {
/* 436 */     Runtime.getRuntime().addShutdownHook(shutdownHook);
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 440 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 445 */     return this.order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpringBootLogging(LogLevel springBootLogging) {
/* 453 */     this.springBootLogging = springBootLogging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParseArgs(boolean parseArgs) {
/* 463 */     this.parseArgs = parseArgs;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\logging\LoggingApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
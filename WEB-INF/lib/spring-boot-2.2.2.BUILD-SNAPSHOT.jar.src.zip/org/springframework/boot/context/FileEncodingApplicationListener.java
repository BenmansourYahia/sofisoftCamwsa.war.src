/*    */ package org.springframework.boot.context;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileEncodingApplicationListener
/*    */   implements ApplicationListener<ApplicationEnvironmentPreparedEvent>, Ordered
/*    */ {
/* 51 */   private static final Log logger = LogFactory.getLog(FileEncodingApplicationListener.class);
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 55 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
/* 60 */     ConfigurableEnvironment environment = event.getEnvironment();
/* 61 */     if (!environment.containsProperty("spring.mandatory-file-encoding")) {
/*    */       return;
/*    */     }
/* 64 */     String encoding = System.getProperty("file.encoding");
/* 65 */     String desired = environment.getProperty("spring.mandatory-file-encoding");
/* 66 */     if (encoding != null && !desired.equalsIgnoreCase(encoding)) {
/* 67 */       if (logger.isErrorEnabled()) {
/* 68 */         logger.error("System property 'file.encoding' is currently '" + encoding + "'. It should be '" + desired + "' (as defined in 'spring.mandatoryFileEncoding').");
/*    */         
/* 70 */         logger.error("Environment variable LANG is '" + System.getenv("LANG") + "'. You could use a locale setting that matches encoding='" + desired + "'.");
/*    */         
/* 72 */         logger.error("Environment variable LC_ALL is '" + System.getenv("LC_ALL") + "'. You could use a locale setting that matches encoding='" + desired + "'.");
/*    */       } 
/*    */       
/* 75 */       throw new IllegalStateException("The Java Virtual Machine has not been configured to use the desired default character encoding (" + desired + ").");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\FileEncodingApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Configurations
/*     */ {
/*     */   private static final Comparator<Object> COMPARATOR;
/*     */   private final Set<Class<?>> classes;
/*     */   
/*     */   static {
/*  60 */     COMPARATOR = OrderComparator.INSTANCE.thenComparing(other -> other.getClass().getName());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Configurations(Collection<Class<?>> classes) {
/*  65 */     Assert.notNull(classes, "Classes must not be null");
/*  66 */     Collection<Class<?>> sorted = sort(classes);
/*  67 */     this.classes = Collections.unmodifiableSet(new LinkedHashSet<>(sorted));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Class<?>> sort(Collection<Class<?>> classes) {
/*  76 */     return classes;
/*     */   }
/*     */   
/*     */   protected final Set<Class<?>> getClasses() {
/*  80 */     return this.classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configurations merge(Configurations other) {
/*  90 */     Set<Class<?>> mergedClasses = new LinkedHashSet<>(getClasses());
/*  91 */     mergedClasses.addAll(other.getClasses());
/*  92 */     return merge(mergedClasses);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] getClasses(Configurations... configurations) {
/* 109 */     return getClasses(Arrays.asList(configurations));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] getClasses(Collection<Configurations> configurations) {
/* 119 */     List<Configurations> ordered = new ArrayList<>(configurations);
/* 120 */     ordered.sort(COMPARATOR);
/* 121 */     List<Configurations> collated = collate(ordered);
/*     */     
/* 123 */     LinkedHashSet<Class<?>> classes = (LinkedHashSet<Class<?>>)collated.stream().flatMap(Configurations::streamClasses).collect(Collectors.toCollection(LinkedHashSet::new));
/* 124 */     return ClassUtils.toClassArray(classes);
/*     */   }
/*     */   
/*     */   private static Stream<Class<?>> streamClasses(Configurations configurations) {
/* 128 */     return configurations.getClasses().stream();
/*     */   }
/*     */   
/*     */   private static List<Configurations> collate(List<Configurations> orderedConfigurations) {
/* 132 */     LinkedList<Configurations> collated = new LinkedList<>();
/* 133 */     for (Configurations item : orderedConfigurations) {
/* 134 */       if (collated.isEmpty() || ((Configurations)collated.getLast()).getClass() != item.getClass()) {
/* 135 */         collated.add(item);
/*     */         continue;
/*     */       } 
/* 138 */       collated.set(collated.size() - 1, ((Configurations)collated.getLast()).merge(item));
/*     */     } 
/*     */     
/* 141 */     return collated;
/*     */   }
/*     */   
/*     */   protected abstract Configurations merge(Set<Class<?>> paramSet);
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\annotation\Configurations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.annotation;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.PriorityOrdered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserConfigurations
/*    */   extends Configurations
/*    */   implements PriorityOrdered
/*    */ {
/*    */   protected UserConfigurations(Collection<Class<?>> classes) {
/* 36 */     super(classes);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 41 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   protected UserConfigurations merge(Set<Class<?>> mergedClasses) {
/* 46 */     return new UserConfigurations(mergedClasses);
/*    */   }
/*    */   
/*    */   public static UserConfigurations of(Class<?>... classes) {
/* 50 */     return new UserConfigurations(Arrays.asList(classes));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\annotation\UserConfigurations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot.context.annotation;

import java.util.Set;
import org.springframework.core.type.AnnotationMetadata;

@FunctionalInterface
public interface DeterminableImports {
  Set<Object> determineImports(AnnotationMetadata paramAnnotationMetadata);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\annotation\DeterminableImports.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
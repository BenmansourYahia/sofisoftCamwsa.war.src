/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationStartedEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableApplicationContext context;
/*    */   
/*    */   public ApplicationStartedEvent(SpringApplication application, String[] args, ConfigurableApplicationContext context) {
/* 45 */     super(application, args);
/* 46 */     this.context = context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurableApplicationContext getApplicationContext() {
/* 54 */     return this.context;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\event\ApplicationStartedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.event;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.SpringApplicationRunListener;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*     */ import org.springframework.context.support.AbstractApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventPublishingRunListener
/*     */   implements SpringApplicationRunListener, Ordered
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private final String[] args;
/*     */   private final SimpleApplicationEventMulticaster initialMulticaster;
/*     */   
/*     */   public EventPublishingRunListener(SpringApplication application, String[] args) {
/*  55 */     this.application = application;
/*  56 */     this.args = args;
/*  57 */     this.initialMulticaster = new SimpleApplicationEventMulticaster();
/*  58 */     for (ApplicationListener<?> listener : (Iterable<ApplicationListener<?>>)application.getListeners()) {
/*  59 */       this.initialMulticaster.addApplicationListener(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  65 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void starting() {
/*  70 */     this.initialMulticaster.multicastEvent(new ApplicationStartingEvent(this.application, this.args));
/*     */   }
/*     */ 
/*     */   
/*     */   public void environmentPrepared(ConfigurableEnvironment environment) {
/*  75 */     this.initialMulticaster
/*  76 */       .multicastEvent(new ApplicationEnvironmentPreparedEvent(this.application, this.args, environment));
/*     */   }
/*     */ 
/*     */   
/*     */   public void contextPrepared(ConfigurableApplicationContext context) {
/*  81 */     this.initialMulticaster
/*  82 */       .multicastEvent(new ApplicationContextInitializedEvent(this.application, this.args, context));
/*     */   }
/*     */ 
/*     */   
/*     */   public void contextLoaded(ConfigurableApplicationContext context) {
/*  87 */     for (ApplicationListener<?> listener : (Iterable<ApplicationListener<?>>)this.application.getListeners()) {
/*  88 */       if (listener instanceof ApplicationContextAware) {
/*  89 */         ((ApplicationContextAware)listener).setApplicationContext((ApplicationContext)context);
/*     */       }
/*  91 */       context.addApplicationListener(listener);
/*     */     } 
/*  93 */     this.initialMulticaster.multicastEvent(new ApplicationPreparedEvent(this.application, this.args, context));
/*     */   }
/*     */ 
/*     */   
/*     */   public void started(ConfigurableApplicationContext context) {
/*  98 */     context.publishEvent(new ApplicationStartedEvent(this.application, this.args, context));
/*     */   }
/*     */ 
/*     */   
/*     */   public void running(ConfigurableApplicationContext context) {
/* 103 */     context.publishEvent(new ApplicationReadyEvent(this.application, this.args, context));
/*     */   }
/*     */ 
/*     */   
/*     */   public void failed(ConfigurableApplicationContext context, Throwable exception) {
/* 108 */     ApplicationFailedEvent event = new ApplicationFailedEvent(this.application, this.args, context, exception);
/* 109 */     if (context != null && context.isActive()) {
/*     */ 
/*     */       
/* 112 */       context.publishEvent(event);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 117 */       if (context instanceof AbstractApplicationContext) {
/* 118 */         for (ApplicationListener<?> listener : (Iterable<ApplicationListener<?>>)((AbstractApplicationContext)context)
/* 119 */           .getApplicationListeners()) {
/* 120 */           this.initialMulticaster.addApplicationListener(listener);
/*     */         }
/*     */       }
/* 123 */       this.initialMulticaster.setErrorHandler(new LoggingErrorHandler());
/* 124 */       this.initialMulticaster.multicastEvent(event);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class LoggingErrorHandler
/*     */     implements ErrorHandler {
/* 130 */     private static final Log logger = LogFactory.getLog(EventPublishingRunListener.class);
/*     */     private LoggingErrorHandler() {}
/*     */     
/*     */     public void handleError(Throwable throwable) {
/* 134 */       logger.warn("Error calling ApplicationEventListener", throwable);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\event\EventPublishingRunListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SpringApplicationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private final String[] args;
/*    */   
/*    */   public SpringApplicationEvent(SpringApplication application, String[] args) {
/* 34 */     super(application);
/* 35 */     this.args = args;
/*    */   }
/*    */   
/*    */   public SpringApplication getSpringApplication() {
/* 39 */     return (SpringApplication)getSource();
/*    */   }
/*    */   
/*    */   public final String[] getArgs() {
/* 43 */     return this.args;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\event\SpringApplicationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
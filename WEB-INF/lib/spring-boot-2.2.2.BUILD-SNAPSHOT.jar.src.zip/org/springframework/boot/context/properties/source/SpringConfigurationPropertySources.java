/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringConfigurationPropertySources
/*     */   implements Iterable<ConfigurationPropertySource>
/*     */ {
/*     */   private final Iterable<PropertySource<?>> sources;
/*  44 */   private final Map<PropertySource<?>, ConfigurationPropertySource> cache = (Map<PropertySource<?>, ConfigurationPropertySource>)new ConcurrentReferenceHashMap(16, ConcurrentReferenceHashMap.ReferenceType.SOFT);
/*     */ 
/*     */   
/*     */   SpringConfigurationPropertySources(Iterable<PropertySource<?>> sources) {
/*  48 */     Assert.notNull(sources, "Sources must not be null");
/*  49 */     this.sources = sources;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ConfigurationPropertySource> iterator() {
/*  54 */     return new SourcesIterator(this.sources.iterator(), this::adapt);
/*     */   }
/*     */   
/*     */   private ConfigurationPropertySource adapt(PropertySource<?> source) {
/*  58 */     ConfigurationPropertySource result = this.cache.get(source);
/*     */ 
/*     */     
/*  61 */     if (result != null && result.getUnderlyingSource() == source) {
/*  62 */       return result;
/*     */     }
/*  64 */     result = SpringConfigurationPropertySource.from(source);
/*  65 */     this.cache.put(source, result);
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SourcesIterator
/*     */     implements Iterator<ConfigurationPropertySource>
/*     */   {
/*     */     private final Deque<Iterator<PropertySource<?>>> iterators;
/*     */     
/*     */     private ConfigurationPropertySource next;
/*     */     private final Function<PropertySource<?>, ConfigurationPropertySource> adapter;
/*     */     
/*     */     SourcesIterator(Iterator<PropertySource<?>> iterator, Function<PropertySource<?>, ConfigurationPropertySource> adapter) {
/*  79 */       this.iterators = new ArrayDeque<>(4);
/*  80 */       this.iterators.push(iterator);
/*  81 */       this.adapter = adapter;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  86 */       return (fetchNext() != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurationPropertySource next() {
/*  91 */       ConfigurationPropertySource next = fetchNext();
/*  92 */       if (next == null) {
/*  93 */         throw new NoSuchElementException();
/*     */       }
/*  95 */       this.next = null;
/*  96 */       return next;
/*     */     }
/*     */     
/*     */     private ConfigurationPropertySource fetchNext() {
/* 100 */       if (this.next == null) {
/* 101 */         if (this.iterators.isEmpty()) {
/* 102 */           return null;
/*     */         }
/* 104 */         if (!((Iterator)this.iterators.peek()).hasNext()) {
/* 105 */           this.iterators.pop();
/* 106 */           return fetchNext();
/*     */         } 
/* 108 */         PropertySource<?> candidate = ((Iterator<PropertySource>)this.iterators.peek()).next();
/* 109 */         if (candidate.getSource() instanceof ConfigurableEnvironment) {
/* 110 */           push((ConfigurableEnvironment)candidate.getSource());
/* 111 */           return fetchNext();
/*     */         } 
/* 113 */         if (isIgnored(candidate)) {
/* 114 */           return fetchNext();
/*     */         }
/* 116 */         this.next = this.adapter.apply(candidate);
/*     */       } 
/* 118 */       return this.next;
/*     */     }
/*     */     
/*     */     private void push(ConfigurableEnvironment environment) {
/* 122 */       this.iterators.push(environment.getPropertySources().iterator());
/*     */     }
/*     */     
/*     */     private boolean isIgnored(PropertySource<?> candidate) {
/* 126 */       return (candidate instanceof PropertySource.StubPropertySource || candidate instanceof ConfigurationPropertySourcesPropertySource);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\SpringConfigurationPropertySources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
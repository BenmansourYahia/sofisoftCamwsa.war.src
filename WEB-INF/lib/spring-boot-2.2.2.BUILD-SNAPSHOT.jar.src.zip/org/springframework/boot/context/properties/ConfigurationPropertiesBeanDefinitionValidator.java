/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanCreationException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigurationPropertiesBeanDefinitionValidator
/*    */   implements BeanFactoryPostProcessor, Ordered
/*    */ {
/* 38 */   private static final String BEAN_NAME = ConfigurationPropertiesBeanDefinitionValidator.class.getName();
/*    */ 
/*    */   
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/* 42 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 43 */       if (!beanFactory.containsSingleton(beanName) && !isValueObjectBeanDefinition(beanFactory, beanName)) {
/* 44 */         validate(beanFactory, beanName);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private boolean isValueObjectBeanDefinition(ConfigurableListableBeanFactory beanFactory, String beanName) {
/* 50 */     BeanDefinition definition = beanFactory.getBeanDefinition(beanName);
/* 51 */     return definition instanceof ConfigurationPropertiesValueObjectBeanDefinition;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 56 */     return Integer.MAX_VALUE;
/*    */   }
/*    */   
/*    */   private void validate(ConfigurableListableBeanFactory beanFactory, String beanName) {
/* 60 */     Class<?> beanClass = beanFactory.getType(beanName, false);
/* 61 */     if (beanClass != null && ConfigurationPropertiesBean.BindMethod.forType(beanClass) == ConfigurationPropertiesBean.BindMethod.VALUE_OBJECT) {
/* 62 */       throw new BeanCreationException(beanName, "@EnableConfigurationProperties or @ConfigurationPropertiesScan must be used to add @ConstructorBinding type " + beanClass
/*    */           
/* 64 */           .getName());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void register(BeanDefinitionRegistry registry) {
/* 74 */     Assert.notNull(registry, "Registry must not be null");
/* 75 */     if (!registry.containsBeanDefinition(BEAN_NAME)) {
/* 76 */       GenericBeanDefinition definition = new GenericBeanDefinition();
/* 77 */       definition.setBeanClass(ConfigurationPropertiesBeanDefinitionValidator.class);
/* 78 */       definition.setRole(2);
/* 79 */       registry.registerBeanDefinition(BEAN_NAME, (BeanDefinition)definition);
/*    */     } 
/* 81 */     ConfigurationPropertiesBinder.register(registry);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBeanDefinitionValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
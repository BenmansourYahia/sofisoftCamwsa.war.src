package org.springframework.boot.context.properties.bind;

import org.springframework.boot.context.properties.source.ConfigurationProperty;
import org.springframework.boot.context.properties.source.ConfigurationPropertySource;

public interface BindContext {
  Binder getBinder();
  
  int getDepth();
  
  Iterable<ConfigurationPropertySource> getSources();
  
  ConfigurationProperty getConfigurationProperty();
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\BindContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
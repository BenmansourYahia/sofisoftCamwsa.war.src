/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ import org.springframework.core.annotation.MergedAnnotation;
/*    */ import org.springframework.core.annotation.MergedAnnotations;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConfigurationPropertiesBeanRegistrar
/*    */ {
/*    */   private final BeanDefinitionRegistry registry;
/*    */   private final BeanFactory beanFactory;
/*    */   
/*    */   ConfigurationPropertiesBeanRegistrar(BeanDefinitionRegistry registry) {
/* 46 */     this.registry = registry;
/* 47 */     this.beanFactory = (BeanFactory)this.registry;
/*    */   }
/*    */ 
/*    */   
/*    */   void register(Class<?> type) {
/* 52 */     MergedAnnotation<ConfigurationProperties> annotation = MergedAnnotations.from(type, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(ConfigurationProperties.class);
/* 53 */     register(type, annotation);
/*    */   }
/*    */   
/*    */   void register(Class<?> type, MergedAnnotation<ConfigurationProperties> annotation) {
/* 57 */     String name = getName(type, annotation);
/* 58 */     if (!containsBeanDefinition(name)) {
/* 59 */       registerBeanDefinition(name, type, annotation);
/*    */     }
/*    */   }
/*    */   
/*    */   private String getName(Class<?> type, MergedAnnotation<ConfigurationProperties> annotation) {
/* 64 */     String prefix = annotation.isPresent() ? annotation.getString("prefix") : "";
/* 65 */     return StringUtils.hasText(prefix) ? (prefix + "-" + type.getName()) : type.getName();
/*    */   }
/*    */   
/*    */   private boolean containsBeanDefinition(String name) {
/* 69 */     return containsBeanDefinition(this.beanFactory, name);
/*    */   }
/*    */   
/*    */   private boolean containsBeanDefinition(BeanFactory beanFactory, String name) {
/* 73 */     if (beanFactory instanceof ListableBeanFactory && ((ListableBeanFactory)beanFactory)
/* 74 */       .containsBeanDefinition(name)) {
/* 75 */       return true;
/*    */     }
/* 77 */     if (beanFactory instanceof HierarchicalBeanFactory) {
/* 78 */       return containsBeanDefinition(((HierarchicalBeanFactory)beanFactory).getParentBeanFactory(), name);
/*    */     }
/* 80 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   private void registerBeanDefinition(String beanName, Class<?> type, MergedAnnotation<ConfigurationProperties> annotation) {
/* 85 */     Assert.state(annotation.isPresent(), () -> "No " + ConfigurationProperties.class.getSimpleName() + " annotation found on  '" + type.getName() + "'.");
/*    */     
/* 87 */     this.registry.registerBeanDefinition(beanName, createBeanDefinition(beanName, type));
/*    */   }
/*    */   
/*    */   private BeanDefinition createBeanDefinition(String beanName, Class<?> type) {
/* 91 */     if (ConfigurationPropertiesBean.BindMethod.forType(type) == ConfigurationPropertiesBean.BindMethod.VALUE_OBJECT) {
/* 92 */       return (BeanDefinition)new ConfigurationPropertiesValueObjectBeanDefinition(this.beanFactory, beanName, type);
/*    */     }
/* 94 */     GenericBeanDefinition definition = new GenericBeanDefinition();
/* 95 */     definition.setBeanClass(type);
/* 96 */     return (BeanDefinition)definition;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBeanRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
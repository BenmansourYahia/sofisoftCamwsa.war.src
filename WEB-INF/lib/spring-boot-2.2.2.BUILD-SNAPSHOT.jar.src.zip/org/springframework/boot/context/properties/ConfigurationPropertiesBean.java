/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationPropertiesBean
/*     */ {
/*     */   private final String name;
/*     */   private final Object instance;
/*     */   private final ConfigurationProperties annotation;
/*     */   private final Bindable<?> bindTarget;
/*     */   private final BindMethod bindMethod;
/*     */   
/*     */   private ConfigurationPropertiesBean(String name, Object instance, ConfigurationProperties annotation, Bindable<?> bindTarget) {
/*  74 */     this.name = name;
/*  75 */     this.instance = instance;
/*  76 */     this.annotation = annotation;
/*  77 */     this.bindTarget = bindTarget;
/*  78 */     this.bindMethod = BindMethod.forType(bindTarget.getType().resolve());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  86 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getInstance() {
/*  94 */     return this.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<?> getType() {
/* 102 */     return this.bindTarget.getType().resolve();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BindMethod getBindMethod() {
/* 110 */     return this.bindMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationProperties getAnnotation() {
/* 120 */     return this.annotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<?> asBindTarget() {
/* 129 */     return this.bindTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, ConfigurationPropertiesBean> getAll(ApplicationContext applicationContext) {
/* 141 */     Assert.notNull(applicationContext, "ApplicationContext must not be null");
/* 142 */     if (applicationContext instanceof ConfigurableApplicationContext) {
/* 143 */       return getAll((ConfigurableApplicationContext)applicationContext);
/*     */     }
/* 145 */     Map<String, ConfigurationPropertiesBean> propertiesBeans = new LinkedHashMap<>();
/* 146 */     applicationContext.getBeansWithAnnotation(ConfigurationProperties.class)
/* 147 */       .forEach((beanName, bean) -> (ConfigurationPropertiesBean)propertiesBeans.put(beanName, get(applicationContext, bean, beanName)));
/* 148 */     return propertiesBeans;
/*     */   }
/*     */   
/*     */   private static Map<String, ConfigurationPropertiesBean> getAll(ConfigurableApplicationContext applicationContext) {
/* 152 */     Map<String, ConfigurationPropertiesBean> propertiesBeans = new LinkedHashMap<>();
/* 153 */     ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();
/* 154 */     Iterator<String> beanNames = beanFactory.getBeanNamesIterator();
/* 155 */     while (beanNames.hasNext()) {
/* 156 */       String beanName = beanNames.next();
/* 157 */       if (isConfigurationPropertiesBean(beanFactory, beanName)) {
/*     */         try {
/* 159 */           Object bean = beanFactory.getBean(beanName);
/* 160 */           ConfigurationPropertiesBean propertiesBean = get((ApplicationContext)applicationContext, bean, beanName);
/* 161 */           propertiesBeans.put(beanName, propertiesBean);
/*     */         }
/* 163 */         catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */     
/* 167 */     return propertiesBeans;
/*     */   }
/*     */   
/*     */   private static boolean isConfigurationPropertiesBean(ConfigurableListableBeanFactory beanFactory, String beanName) {
/*     */     try {
/* 172 */       if (beanFactory.getBeanDefinition(beanName).isAbstract()) {
/* 173 */         return false;
/*     */       }
/* 175 */       if (beanFactory.findAnnotationOnBean(beanName, ConfigurationProperties.class) != null) {
/* 176 */         return true;
/*     */       }
/* 178 */       Method factoryMethod = findFactoryMethod(beanFactory, beanName);
/* 179 */       return findMergedAnnotation(factoryMethod, ConfigurationProperties.class).isPresent();
/*     */     }
/* 181 */     catch (NoSuchBeanDefinitionException ex) {
/* 182 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConfigurationPropertiesBean get(ApplicationContext applicationContext, Object bean, String beanName) {
/* 200 */     Method factoryMethod = findFactoryMethod(applicationContext, beanName);
/* 201 */     return create(beanName, bean, bean.getClass(), factoryMethod);
/*     */   }
/*     */   
/*     */   private static Method findFactoryMethod(ApplicationContext applicationContext, String beanName) {
/* 205 */     if (applicationContext instanceof ConfigurableApplicationContext) {
/* 206 */       return findFactoryMethod((ConfigurableApplicationContext)applicationContext, beanName);
/*     */     }
/* 208 */     return null;
/*     */   }
/*     */   
/*     */   private static Method findFactoryMethod(ConfigurableApplicationContext applicationContext, String beanName) {
/* 212 */     return findFactoryMethod(applicationContext.getBeanFactory(), beanName);
/*     */   }
/*     */   
/*     */   private static Method findFactoryMethod(ConfigurableListableBeanFactory beanFactory, String beanName) {
/* 216 */     if (beanFactory.containsBeanDefinition(beanName)) {
/* 217 */       BeanDefinition beanDefinition = beanFactory.getMergedBeanDefinition(beanName);
/* 218 */       if (beanDefinition instanceof RootBeanDefinition) {
/* 219 */         Method resolvedFactoryMethod = ((RootBeanDefinition)beanDefinition).getResolvedFactoryMethod();
/* 220 */         if (resolvedFactoryMethod != null) {
/* 221 */           return resolvedFactoryMethod;
/*     */         }
/*     */       } 
/* 224 */       return findFactoryMethodUsingReflection(beanFactory, beanDefinition);
/*     */     } 
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Method findFactoryMethodUsingReflection(ConfigurableListableBeanFactory beanFactory, BeanDefinition beanDefinition) {
/* 231 */     String factoryMethodName = beanDefinition.getFactoryMethodName();
/* 232 */     String factoryBeanName = beanDefinition.getFactoryBeanName();
/* 233 */     if (factoryMethodName == null || factoryBeanName == null) {
/* 234 */       return null;
/*     */     }
/* 236 */     Class<?> factoryType = beanFactory.getType(factoryBeanName);
/* 237 */     if (factoryType.getName().contains("$$")) {
/* 238 */       factoryType = factoryType.getSuperclass();
/*     */     }
/* 240 */     AtomicReference<Method> factoryMethod = new AtomicReference<>();
/* 241 */     ReflectionUtils.doWithMethods(factoryType, method -> {
/*     */           if (method.getName().equals(factoryMethodName)) {
/*     */             factoryMethod.set(method);
/*     */           }
/*     */         });
/* 246 */     return factoryMethod.get();
/*     */   }
/*     */   
/*     */   static ConfigurationPropertiesBean forValueObject(Class<?> beanClass, String beanName) {
/* 250 */     ConfigurationPropertiesBean propertiesBean = create(beanName, null, beanClass, null);
/* 251 */     Assert.state((propertiesBean != null && propertiesBean.getBindMethod() == BindMethod.VALUE_OBJECT), "Bean '" + beanName + "' is not a @ConfigurationProperties value object");
/*     */     
/* 253 */     return propertiesBean;
/*     */   }
/*     */   
/*     */   private static ConfigurationPropertiesBean create(String name, Object instance, Class<?> type, Method factory) {
/* 257 */     ConfigurationProperties annotation = findAnnotation(instance, type, factory, ConfigurationProperties.class);
/* 258 */     if (annotation == null) {
/* 259 */       return null;
/*     */     }
/* 261 */     Validated validated = findAnnotation(instance, type, factory, Validated.class);
/* 262 */     (new Annotation[2])[0] = annotation; (new Annotation[2])[1] = (Annotation)validated; (new Annotation[1])[0] = annotation; Annotation[] annotations = (validated != null) ? new Annotation[2] : new Annotation[1];
/*     */ 
/*     */     
/* 265 */     ResolvableType bindType = (factory != null) ? ResolvableType.forMethodReturnType(factory) : ResolvableType.forClass(type);
/* 266 */     Bindable<Object> bindTarget = Bindable.of(bindType).withAnnotations(annotations);
/* 267 */     if (instance != null) {
/* 268 */       bindTarget = bindTarget.withExistingValue(instance);
/*     */     }
/* 270 */     return new ConfigurationPropertiesBean(name, instance, annotation, bindTarget);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <A extends Annotation> A findAnnotation(Object instance, Class<?> type, Method factory, Class<A> annotationType) {
/* 275 */     MergedAnnotation<A> annotation = MergedAnnotation.missing();
/* 276 */     if (factory != null) {
/* 277 */       annotation = findMergedAnnotation(factory, annotationType);
/*     */     }
/* 279 */     if (!annotation.isPresent()) {
/* 280 */       annotation = findMergedAnnotation(type, annotationType);
/*     */     }
/* 282 */     if (!annotation.isPresent() && AopUtils.isAopProxy(instance))
/*     */     {
/* 284 */       annotation = MergedAnnotations.from(AopUtils.getTargetClass(instance), MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(annotationType);
/*     */     }
/* 286 */     return annotation.isPresent() ? (A)annotation.synthesize() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <A extends Annotation> MergedAnnotation<A> findMergedAnnotation(AnnotatedElement element, Class<A> annotationType) {
/* 291 */     return (element != null) ? MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(annotationType) : 
/* 292 */       MergedAnnotation.missing();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum BindMethod
/*     */   {
/* 303 */     JAVA_BEAN,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     VALUE_OBJECT;
/*     */     
/*     */     static BindMethod forType(Class<?> type) {
/* 311 */       return (ConfigurationPropertiesBindConstructorProvider.INSTANCE.getBindConstructor(type, false) != null) ? VALUE_OBJECT : JAVA_BEAN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AliasedIterableConfigurationPropertySource
/*    */   extends AliasedConfigurationPropertySource
/*    */   implements IterableConfigurationPropertySource
/*    */ {
/*    */   AliasedIterableConfigurationPropertySource(IterableConfigurationPropertySource source, ConfigurationPropertyNameAliases aliases) {
/* 35 */     super(source, aliases);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<ConfigurationPropertyName> stream() {
/* 40 */     return getSource().stream().flatMap(this::addAliases);
/*    */   }
/*    */   
/*    */   private Stream<ConfigurationPropertyName> addAliases(ConfigurationPropertyName name) {
/* 44 */     Stream<ConfigurationPropertyName> names = Stream.of(name);
/* 45 */     List<ConfigurationPropertyName> aliases = getAliases().getAliases(name);
/* 46 */     if (CollectionUtils.isEmpty(aliases)) {
/* 47 */       return names;
/*    */     }
/* 49 */     return Stream.concat(names, aliases.stream());
/*    */   }
/*    */ 
/*    */   
/*    */   protected IterableConfigurationPropertySource getSource() {
/* 54 */     return (IterableConfigurationPropertySource)super.getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\AliasedIterableConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
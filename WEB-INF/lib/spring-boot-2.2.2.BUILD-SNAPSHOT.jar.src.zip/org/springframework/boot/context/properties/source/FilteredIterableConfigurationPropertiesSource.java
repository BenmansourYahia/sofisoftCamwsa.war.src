/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FilteredIterableConfigurationPropertiesSource
/*    */   extends FilteredConfigurationPropertiesSource
/*    */   implements IterableConfigurationPropertySource
/*    */ {
/*    */   FilteredIterableConfigurationPropertiesSource(IterableConfigurationPropertySource source, Predicate<ConfigurationPropertyName> filter) {
/* 33 */     super(source, filter);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<ConfigurationPropertyName> stream() {
/* 38 */     return getSource().stream().filter(getFilter());
/*    */   }
/*    */ 
/*    */   
/*    */   protected IterableConfigurationPropertySource getSource() {
/* 43 */     return (IterableConfigurationPropertySource)super.getSource();
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 48 */     return ConfigurationPropertyState.search(this, name::isAncestorOf);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\FilteredIterableConfigurationPropertiesSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
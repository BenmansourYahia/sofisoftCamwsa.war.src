/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ConfigurationPropertyState
/*    */ {
/* 35 */   PRESENT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   ABSENT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   UNKNOWN;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> ConfigurationPropertyState search(Iterable<T> source, Predicate<T> predicate) {
/* 59 */     Assert.notNull(source, "Source must not be null");
/* 60 */     Assert.notNull(predicate, "Predicate must not be null");
/* 61 */     for (T item : source) {
/* 62 */       if (predicate.test(item)) {
/* 63 */         return PRESENT;
/*    */       }
/*    */     } 
/* 66 */     return ABSENT;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties.bind.handler;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.BindContext;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.UnboundConfigurationPropertiesException;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.IterableConfigurationPropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoUnboundElementsBindHandler
/*     */   extends AbstractBindHandler
/*     */ {
/*  44 */   private final Set<ConfigurationPropertyName> boundNames = new HashSet<>();
/*     */   
/*     */   private final Function<ConfigurationPropertySource, Boolean> filter;
/*     */   
/*     */   NoUnboundElementsBindHandler() {
/*  49 */     this(BindHandler.DEFAULT, configurationPropertySource -> Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */   public NoUnboundElementsBindHandler(BindHandler parent) {
/*  53 */     this(parent, configurationPropertySource -> Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */   public NoUnboundElementsBindHandler(BindHandler parent, Function<ConfigurationPropertySource, Boolean> filter) {
/*  57 */     super(parent);
/*  58 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/*  63 */     this.boundNames.add(name);
/*  64 */     return super.onSuccess(name, target, context, result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onFinish(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) throws Exception {
/*  70 */     if (context.getDepth() == 0) {
/*  71 */       checkNoUnboundElements(name, context);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkNoUnboundElements(ConfigurationPropertyName name, BindContext context) {
/*  76 */     Set<ConfigurationProperty> unbound = new TreeSet<>();
/*  77 */     for (ConfigurationPropertySource source : context.getSources()) {
/*  78 */       if (source instanceof IterableConfigurationPropertySource && ((Boolean)this.filter.apply(source)).booleanValue()) {
/*  79 */         collectUnbound(name, unbound, (IterableConfigurationPropertySource)source);
/*     */       }
/*     */     } 
/*  82 */     if (!unbound.isEmpty()) {
/*  83 */       throw new UnboundConfigurationPropertiesException(unbound);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void collectUnbound(ConfigurationPropertyName name, Set<ConfigurationProperty> unbound, IterableConfigurationPropertySource source) {
/*  89 */     IterableConfigurationPropertySource filtered = source.filter(candidate -> isUnbound(name, candidate));
/*  90 */     for (ConfigurationPropertyName unboundName : filtered) {
/*     */       try {
/*  92 */         unbound.add(source
/*  93 */             .filter(candidate -> isUnbound(name, candidate)).getConfigurationProperty(unboundName));
/*     */       }
/*  95 */       catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isUnbound(ConfigurationPropertyName name, ConfigurationPropertyName candidate) {
/* 101 */     if (name.isAncestorOf(candidate)) {
/* 102 */       return (!this.boundNames.contains(candidate) && !isOverriddenCollectionElement(candidate));
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isOverriddenCollectionElement(ConfigurationPropertyName candidate) {
/* 108 */     int lastIndex = candidate.getNumberOfElements() - 1;
/* 109 */     if (candidate.isNumericIndex(lastIndex)) {
/* 110 */       ConfigurationPropertyName propertyName = candidate.chop(lastIndex);
/* 111 */       return this.boundNames.contains(propertyName);
/*     */     } 
/* 113 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\handler\NoUnboundElementsBindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
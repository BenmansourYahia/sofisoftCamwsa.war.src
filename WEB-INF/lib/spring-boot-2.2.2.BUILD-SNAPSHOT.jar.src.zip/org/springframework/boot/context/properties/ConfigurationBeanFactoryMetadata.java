/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ConfigurationBeanFactoryMetadata
/*    */   implements ApplicationContextAware
/*    */ {
/* 49 */   public static final String BEAN_NAME = ConfigurationBeanFactoryMetadata.class.getName();
/*    */   
/*    */   private ConfigurableApplicationContext applicationContext;
/*    */   
/*    */   public <A extends java.lang.annotation.Annotation> Map<String, Object> getBeansWithFactoryAnnotation(Class<A> type) {
/* 54 */     Map<String, Object> result = new HashMap<>();
/* 55 */     for (String name : this.applicationContext.getBeanFactory().getBeanDefinitionNames()) {
/* 56 */       if (findFactoryAnnotation(name, type) != null) {
/* 57 */         result.put(name, this.applicationContext.getBean(name));
/*    */       }
/*    */     } 
/* 60 */     return result;
/*    */   }
/*    */   
/*    */   public <A extends java.lang.annotation.Annotation> A findFactoryAnnotation(String beanName, Class<A> type) {
/* 64 */     Method method = findFactoryMethod(beanName);
/* 65 */     return (method != null) ? (A)AnnotationUtils.findAnnotation(method, type) : null;
/*    */   }
/*    */   
/*    */   public Method findFactoryMethod(String beanName) {
/* 69 */     ConfigurableListableBeanFactory beanFactory = this.applicationContext.getBeanFactory();
/* 70 */     if (beanFactory.containsBeanDefinition(beanName)) {
/* 71 */       BeanDefinition beanDefinition = beanFactory.getMergedBeanDefinition(beanName);
/* 72 */       if (beanDefinition instanceof RootBeanDefinition) {
/* 73 */         return ((RootBeanDefinition)beanDefinition).getResolvedFactoryMethod();
/*    */       }
/*    */     } 
/* 76 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 81 */     this.applicationContext = (ConfigurableApplicationContext)applicationContext;
/*    */   }
/*    */   
/*    */   static void register(BeanDefinitionRegistry registry) {
/* 85 */     if (!registry.containsBeanDefinition(BEAN_NAME)) {
/* 86 */       GenericBeanDefinition definition = new GenericBeanDefinition();
/* 87 */       definition.setBeanClass(ConfigurationBeanFactoryMetadata.class);
/* 88 */       definition.setRole(2);
/* 89 */       registry.registerBeanDefinition(BEAN_NAME, (BeanDefinition)definition);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationBeanFactoryMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
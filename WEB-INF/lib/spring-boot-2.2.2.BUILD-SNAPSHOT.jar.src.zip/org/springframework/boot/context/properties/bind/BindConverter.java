/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BindConverter
/*     */ {
/*     */   private static final Set<Class<?>> EXCLUDED_EDITORS;
/*     */   private static BindConverter sharedInstance;
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   static {
/*  54 */     Set<Class<?>> excluded = new HashSet<>();
/*  55 */     excluded.add(FileEditor.class);
/*  56 */     EXCLUDED_EDITORS = Collections.unmodifiableSet(excluded);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BindConverter(ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer) {
/*  65 */     Assert.notNull(conversionService, "ConversionService must not be null");
/*  66 */     List<ConversionService> conversionServices = getConversionServices(conversionService, propertyEditorInitializer);
/*     */     
/*  68 */     this.conversionService = new CompositeConversionService(conversionServices);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ConversionService> getConversionServices(ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer) {
/*  73 */     List<ConversionService> services = new ArrayList<>();
/*  74 */     services.add(new TypeConverterConversionService(propertyEditorInitializer));
/*  75 */     services.add(conversionService);
/*  76 */     if (!(conversionService instanceof ApplicationConversionService)) {
/*  77 */       services.add(ApplicationConversionService.getSharedInstance());
/*     */     }
/*  79 */     return services;
/*     */   }
/*     */   
/*     */   boolean canConvert(Object value, ResolvableType type, Annotation... annotations) {
/*  83 */     return this.conversionService.canConvert(TypeDescriptor.forObject(value), new ResolvableTypeDescriptor(type, annotations));
/*     */   }
/*     */ 
/*     */   
/*     */   <T> T convert(Object result, Bindable<T> target) {
/*  88 */     return convert(result, target.getType(), target.getAnnotations());
/*     */   }
/*     */ 
/*     */   
/*     */   <T> T convert(Object value, ResolvableType type, Annotation... annotations) {
/*  93 */     if (value == null) {
/*  94 */       return null;
/*     */     }
/*  96 */     return (T)this.conversionService.convert(value, TypeDescriptor.forObject(value), new ResolvableTypeDescriptor(type, annotations));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static BindConverter get(ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer) {
/* 102 */     if (conversionService == ApplicationConversionService.getSharedInstance() && propertyEditorInitializer == null) {
/*     */       
/* 104 */       if (sharedInstance == null) {
/* 105 */         sharedInstance = new BindConverter(conversionService, propertyEditorInitializer);
/*     */       }
/* 107 */       return sharedInstance;
/*     */     } 
/* 109 */     return new BindConverter(conversionService, propertyEditorInitializer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ResolvableTypeDescriptor
/*     */     extends TypeDescriptor
/*     */   {
/*     */     ResolvableTypeDescriptor(ResolvableType resolvableType, Annotation[] annotations) {
/* 118 */       super(resolvableType, null, annotations);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CompositeConversionService
/*     */     implements ConversionService
/*     */   {
/*     */     private final List<ConversionService> delegates;
/*     */ 
/*     */     
/*     */     CompositeConversionService(List<ConversionService> delegates) {
/* 131 */       this.delegates = delegates;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canConvert(Class<?> sourceType, Class<?> targetType) {
/* 136 */       Assert.notNull(targetType, "Target type to convert to cannot be null");
/* 137 */       return canConvert((sourceType != null) ? TypeDescriptor.valueOf(sourceType) : null, 
/* 138 */           TypeDescriptor.valueOf(targetType));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 143 */       for (ConversionService service : this.delegates) {
/* 144 */         if (service.canConvert(sourceType, targetType)) {
/* 145 */           return true;
/*     */         }
/*     */       } 
/* 148 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> T convert(Object source, Class<T> targetType) {
/* 154 */       Assert.notNull(targetType, "Target type to convert to cannot be null");
/* 155 */       return (T)convert(source, TypeDescriptor.forObject(source), TypeDescriptor.valueOf(targetType));
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 160 */       for (int i = 0; i < this.delegates.size() - 1; i++) {
/*     */         try {
/* 162 */           ConversionService delegate = this.delegates.get(i);
/* 163 */           if (delegate.canConvert(sourceType, targetType)) {
/* 164 */             return delegate.convert(source, sourceType, targetType);
/*     */           }
/*     */         }
/* 167 */         catch (ConversionException conversionException) {}
/*     */       } 
/*     */       
/* 170 */       return ((ConversionService)this.delegates.get(this.delegates.size() - 1)).convert(source, sourceType, targetType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TypeConverterConversionService
/*     */     extends GenericConversionService
/*     */   {
/*     */     TypeConverterConversionService(Consumer<PropertyEditorRegistry> initializer) {
/* 183 */       addConverter((GenericConverter)new BindConverter.TypeConverterConverter(createTypeConverter(initializer)));
/* 184 */       ApplicationConversionService.addDelimitedStringConverters((ConverterRegistry)this);
/*     */     }
/*     */     
/*     */     private SimpleTypeConverter createTypeConverter(Consumer<PropertyEditorRegistry> initializer) {
/* 188 */       SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/* 189 */       if (initializer != null) {
/* 190 */         initializer.accept(typeConverter);
/*     */       }
/* 192 */       return typeConverter;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 198 */       if (targetType.isArray() && targetType.getElementTypeDescriptor().isPrimitive()) {
/* 199 */         return false;
/*     */       }
/* 201 */       return super.canConvert(sourceType, targetType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TypeConverterConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final SimpleTypeConverter typeConverter;
/*     */ 
/*     */     
/*     */     TypeConverterConverter(SimpleTypeConverter typeConverter) {
/* 214 */       this.typeConverter = typeConverter;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 219 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, Object.class));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 224 */       return (getPropertyEditor(targetType.getType()) != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 229 */       SimpleTypeConverter typeConverter = this.typeConverter;
/* 230 */       return typeConverter.convertIfNecessary(source, targetType.getType());
/*     */     }
/*     */     
/*     */     private PropertyEditor getPropertyEditor(Class<?> type) {
/* 234 */       if (type == null || type == Object.class || Collection.class.isAssignableFrom(type) || Map.class
/* 235 */         .isAssignableFrom(type)) {
/* 236 */         return null;
/*     */       }
/* 238 */       SimpleTypeConverter typeConverter = this.typeConverter;
/* 239 */       PropertyEditor editor = typeConverter.getDefaultEditor(type);
/* 240 */       if (editor == null) {
/* 241 */         editor = typeConverter.findCustomEditor(type, null);
/*     */       }
/* 243 */       if (editor == null && String.class != type) {
/* 244 */         editor = BeanUtils.findEditorByConvention(type);
/*     */       }
/* 246 */       if (editor == null || BindConverter.EXCLUDED_EDITORS.contains(editor.getClass())) {
/* 247 */         return null;
/*     */       }
/* 249 */       return editor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\BindConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
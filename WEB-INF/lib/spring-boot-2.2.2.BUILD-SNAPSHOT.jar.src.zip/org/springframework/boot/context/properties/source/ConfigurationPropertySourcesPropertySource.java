/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.boot.origin.OriginLookup;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigurationPropertySourcesPropertySource
/*    */   extends PropertySource<Iterable<ConfigurationPropertySource>>
/*    */   implements OriginLookup<String>
/*    */ {
/*    */   ConfigurationPropertySourcesPropertySource(String name, Iterable<ConfigurationPropertySource> source) {
/* 37 */     super(name, source);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getProperty(String name) {
/* 42 */     ConfigurationProperty configurationProperty = findConfigurationProperty(name);
/* 43 */     return (configurationProperty != null) ? configurationProperty.getValue() : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Origin getOrigin(String name) {
/* 48 */     return Origin.from(findConfigurationProperty(name));
/*    */   }
/*    */   
/*    */   private ConfigurationProperty findConfigurationProperty(String name) {
/*    */     try {
/* 53 */       return findConfigurationProperty(ConfigurationPropertyName.of(name, true));
/*    */     }
/* 55 */     catch (Exception ex) {
/* 56 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private ConfigurationProperty findConfigurationProperty(ConfigurationPropertyName name) {
/* 61 */     if (name == null) {
/* 62 */       return null;
/*    */     }
/* 64 */     for (ConfigurationPropertySource configurationPropertySource : getSource()) {
/* 65 */       ConfigurationProperty configurationProperty = configurationPropertySource.getConfigurationProperty(name);
/* 66 */       if (configurationProperty != null) {
/* 67 */         return configurationProperty;
/*    */       }
/*    */     } 
/* 70 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySourcesPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationPropertySources
/*     */ {
/*     */   private static final String ATTACHED_PROPERTY_SOURCE_NAME = "configurationProperties";
/*     */   
/*     */   public static boolean isAttachedConfigurationPropertySource(PropertySource<?> propertySource) {
/*  55 */     return "configurationProperties".equals(propertySource.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void attach(Environment environment) {
/*  72 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment);
/*  73 */     MutablePropertySources sources = ((ConfigurableEnvironment)environment).getPropertySources();
/*  74 */     PropertySource<?> attached = sources.get("configurationProperties");
/*  75 */     if (attached != null && attached.getSource() != sources) {
/*  76 */       sources.remove("configurationProperties");
/*  77 */       attached = null;
/*     */     } 
/*  79 */     if (attached == null) {
/*  80 */       sources.addFirst(new ConfigurationPropertySourcesPropertySource("configurationProperties", new SpringConfigurationPropertySources((Iterable<PropertySource<?>>)sources)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterable<ConfigurationPropertySource> get(Environment environment) {
/*  95 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment);
/*  96 */     MutablePropertySources sources = ((ConfigurableEnvironment)environment).getPropertySources();
/*     */     
/*  98 */     ConfigurationPropertySourcesPropertySource attached = (ConfigurationPropertySourcesPropertySource)sources.get("configurationProperties");
/*  99 */     if (attached == null) {
/* 100 */       return from((Iterable<PropertySource<?>>)sources);
/*     */     }
/* 102 */     return (Iterable<ConfigurationPropertySource>)attached.getSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterable<ConfigurationPropertySource> from(PropertySource<?> source) {
/* 113 */     return Collections.singleton(SpringConfigurationPropertySource.from(source));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterable<ConfigurationPropertySource> from(Iterable<PropertySource<?>> sources) {
/* 130 */     return new SpringConfigurationPropertySources(sources);
/*     */   }
/*     */   
/*     */   private static Stream<PropertySource<?>> streamPropertySources(PropertySources sources) {
/* 134 */     return sources.stream().flatMap(ConfigurationPropertySources::flatten)
/* 135 */       .filter(ConfigurationPropertySources::isIncluded);
/*     */   }
/*     */   
/*     */   private static Stream<PropertySource<?>> flatten(PropertySource<?> source) {
/* 139 */     if (source.getSource() instanceof ConfigurableEnvironment) {
/* 140 */       return streamPropertySources((PropertySources)((ConfigurableEnvironment)source.getSource()).getPropertySources());
/*     */     }
/* 142 */     return Stream.of(source);
/*     */   }
/*     */   
/*     */   private static boolean isIncluded(PropertySource<?> source) {
/* 146 */     return (!(source instanceof PropertySource.StubPropertySource) && !(source instanceof ConfigurationPropertySourcesPropertySource));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
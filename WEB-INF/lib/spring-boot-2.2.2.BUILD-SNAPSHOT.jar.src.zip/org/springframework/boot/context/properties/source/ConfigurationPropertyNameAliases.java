/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConfigurationPropertyNameAliases
/*    */   implements Iterable<ConfigurationPropertyName>
/*    */ {
/* 39 */   private final MultiValueMap<ConfigurationPropertyName, ConfigurationPropertyName> aliases = (MultiValueMap<ConfigurationPropertyName, ConfigurationPropertyName>)new LinkedMultiValueMap();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyNameAliases(String name, String... aliases) {
/* 45 */     addAliases(name, aliases);
/*    */   }
/*    */   
/*    */   public ConfigurationPropertyNameAliases(ConfigurationPropertyName name, ConfigurationPropertyName... aliases) {
/* 49 */     addAliases(name, aliases);
/*    */   }
/*    */   
/*    */   public void addAliases(String name, String... aliases) {
/* 53 */     Assert.notNull(name, "Name must not be null");
/* 54 */     Assert.notNull(aliases, "Aliases must not be null");
/* 55 */     addAliases(ConfigurationPropertyName.of(name), 
/* 56 */         (ConfigurationPropertyName[])Arrays.<String>stream(aliases).map(ConfigurationPropertyName::of).toArray(x$0 -> new ConfigurationPropertyName[x$0]));
/*    */   }
/*    */   
/*    */   public void addAliases(ConfigurationPropertyName name, ConfigurationPropertyName... aliases) {
/* 60 */     Assert.notNull(name, "Name must not be null");
/* 61 */     Assert.notNull(aliases, "Aliases must not be null");
/* 62 */     this.aliases.addAll(name, Arrays.asList(aliases));
/*    */   }
/*    */   
/*    */   public List<ConfigurationPropertyName> getAliases(ConfigurationPropertyName name) {
/* 66 */     return (List<ConfigurationPropertyName>)this.aliases.getOrDefault(name, Collections.emptyList());
/*    */   }
/*    */   
/*    */   public ConfigurationPropertyName getNameForAlias(ConfigurationPropertyName alias) {
/* 70 */     return this.aliases.entrySet().stream().filter(e -> ((List)e.getValue()).contains(alias)).map(Map.Entry::getKey)
/* 71 */       .findFirst().orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<ConfigurationPropertyName> iterator() {
/* 76 */     return this.aliases.keySet().iterator();
/*    */   }
/*    */   
/*    */   public ConfigurationPropertyNameAliases() {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyNameAliases.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IterableConfigurationPropertySource
/*    */   extends ConfigurationPropertySource, Iterable<ConfigurationPropertyName>
/*    */ {
/*    */   default Iterator<ConfigurationPropertyName> iterator() {
/* 51 */     return stream().iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 63 */     return ConfigurationPropertyState.search(this, name::isAncestorOf);
/*    */   }
/*    */ 
/*    */   
/*    */   default IterableConfigurationPropertySource filter(Predicate<ConfigurationPropertyName> filter) {
/* 68 */     return new FilteredIterableConfigurationPropertiesSource(this, filter);
/*    */   }
/*    */ 
/*    */   
/*    */   default IterableConfigurationPropertySource withAliases(ConfigurationPropertyNameAliases aliases) {
/* 73 */     return new AliasedIterableConfigurationPropertySource(this, aliases);
/*    */   }
/*    */   
/*    */   Stream<ConfigurationPropertyName> stream();
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\IterableConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PropertyMapper
/*     */ {
/*     */   private static final Predicate<?> ALWAYS = t -> true;
/*  60 */   private static final PropertyMapper INSTANCE = new PropertyMapper(null, null);
/*     */   
/*     */   private final PropertyMapper parent;
/*     */   
/*     */   private final SourceOperator sourceOperator;
/*     */   
/*     */   private PropertyMapper(PropertyMapper parent, SourceOperator sourceOperator) {
/*  67 */     this.parent = parent;
/*  68 */     this.sourceOperator = sourceOperator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMapper alwaysApplyingWhenNonNull() {
/*  77 */     return alwaysApplying(this::whenNonNull);
/*     */   }
/*     */   
/*     */   private <T> Source<T> whenNonNull(Source<T> source) {
/*  81 */     return source.whenNonNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMapper alwaysApplying(SourceOperator operator) {
/*  91 */     Assert.notNull(operator, "Operator must not be null");
/*  92 */     return new PropertyMapper(this, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Source<T> from(Supplier<T> supplier) {
/* 104 */     Assert.notNull(supplier, "Supplier must not be null");
/* 105 */     Source<T> source = getSource(supplier);
/* 106 */     if (this.sourceOperator != null) {
/* 107 */       source = this.sourceOperator.apply(source);
/*     */     }
/* 109 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Source<T> from(T value) {
/* 120 */     return from(() -> value);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Source<T> getSource(Supplier<T> supplier) {
/* 125 */     if (this.parent != null) {
/* 126 */       return this.parent.from(supplier);
/*     */     }
/* 128 */     return new Source<>(new CachingSupplier<>(supplier), ALWAYS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyMapper get() {
/* 136 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CachingSupplier<T>
/*     */     implements Supplier<T>
/*     */   {
/*     */     private final Supplier<T> supplier;
/*     */     
/*     */     private boolean hasResult;
/*     */     
/*     */     private T result;
/*     */ 
/*     */     
/*     */     CachingSupplier(Supplier<T> supplier) {
/* 151 */       this.supplier = supplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get() {
/* 156 */       if (!this.hasResult) {
/* 157 */         this.result = this.supplier.get();
/* 158 */         this.hasResult = true;
/*     */       } 
/* 160 */       return this.result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface SourceOperator
/*     */   {
/*     */     <T> PropertyMapper.Source<T> apply(PropertyMapper.Source<T> param1Source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Source<T>
/*     */   {
/*     */     private final Supplier<T> supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Predicate<T> predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Source(Supplier<T> supplier, Predicate<T> predicate) {
/* 193 */       Assert.notNull(predicate, "Predicate must not be null");
/* 194 */       this.supplier = supplier;
/* 195 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R extends Number> Source<Integer> asInt(Function<T, R> adapter) {
/* 205 */       return as(adapter).as(Number::intValue);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> Source<R> as(Function<T, R> adapter) {
/* 215 */       Assert.notNull(adapter, "Adapter must not be null");
/* 216 */       Supplier<Boolean> test = () -> Boolean.valueOf(this.predicate.test(this.supplier.get()));
/* 217 */       Predicate<R> predicate = t -> ((Boolean)test.get()).booleanValue();
/* 218 */       Supplier<R> supplier = () -> ((Boolean)test.get()).booleanValue() ? adapter.apply(this.supplier.get()) : null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 224 */       return new Source(supplier, predicate);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenNonNull() {
/* 233 */       return new Source(new PropertyMapper.NullPointerExceptionSafeSupplier<>(this.supplier), Objects::nonNull);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenTrue() {
/* 242 */       return when(Boolean.TRUE::equals);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenFalse() {
/* 251 */       return when(Boolean.FALSE::equals);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenHasText() {
/* 260 */       return when(value -> StringUtils.hasText(Objects.toString(value, null)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenEqualTo(Object object) {
/* 270 */       return when(object::equals);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R extends T> Source<R> whenInstanceOf(Class<R> target) {
/* 281 */       return when(target::isInstance).as(target::cast);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenNot(Predicate<T> predicate) {
/* 291 */       Assert.notNull(predicate, "Predicate must not be null");
/* 292 */       return when(predicate.negate());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> when(Predicate<T> predicate) {
/* 302 */       Assert.notNull(predicate, "Predicate must not be null");
/* 303 */       return new Source(this.supplier, (this.predicate != null) ? this.predicate.and(predicate) : predicate);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void to(Consumer<T> consumer) {
/* 313 */       Assert.notNull(consumer, "Consumer must not be null");
/* 314 */       T value = this.supplier.get();
/* 315 */       if (this.predicate.test(value)) {
/* 316 */         consumer.accept(value);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> R toInstance(Function<T, R> factory) {
/* 328 */       Assert.notNull(factory, "Factory must not be null");
/* 329 */       T value = this.supplier.get();
/* 330 */       if (!this.predicate.test(value)) {
/* 331 */         throw new NoSuchElementException("No value present");
/*     */       }
/* 333 */       return factory.apply(value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void toCall(Runnable runnable) {
/* 342 */       Assert.notNull(runnable, "Runnable must not be null");
/* 343 */       T value = this.supplier.get();
/* 344 */       if (this.predicate.test(value)) {
/* 345 */         runnable.run();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NullPointerExceptionSafeSupplier<T>
/*     */     implements Supplier<T>
/*     */   {
/*     */     private final Supplier<T> supplier;
/*     */ 
/*     */     
/*     */     NullPointerExceptionSafeSupplier(Supplier<T> supplier) {
/* 359 */       this.supplier = supplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get() {
/*     */       try {
/* 365 */         return this.supplier.get();
/*     */       }
/* 367 */       catch (NullPointerException ex) {
/* 368 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\PropertyMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
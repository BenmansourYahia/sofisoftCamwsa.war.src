/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginProvider;
/*     */ import org.springframework.boot.origin.OriginTrackedValue;
/*     */ import org.springframework.core.style.ToStringCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationProperty
/*     */   implements OriginProvider, Comparable<ConfigurationProperty>
/*     */ {
/*     */   private final ConfigurationPropertyName name;
/*     */   private final Object value;
/*     */   private final Origin origin;
/*     */   
/*     */   public ConfigurationProperty(ConfigurationPropertyName name, Object value, Origin origin) {
/*  44 */     Assert.notNull(name, "Name must not be null");
/*  45 */     Assert.notNull(value, "Value must not be null");
/*  46 */     this.name = name;
/*  47 */     this.value = value;
/*  48 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public ConfigurationPropertyName getName() {
/*  52 */     return this.name;
/*     */   }
/*     */   
/*     */   public Object getValue() {
/*  56 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/*  61 */     return this.origin;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  66 */     if (this == obj) {
/*  67 */       return true;
/*     */     }
/*  69 */     if (obj == null || getClass() != obj.getClass()) {
/*  70 */       return false;
/*     */     }
/*  72 */     ConfigurationProperty other = (ConfigurationProperty)obj;
/*  73 */     boolean result = true;
/*  74 */     result = (result && ObjectUtils.nullSafeEquals(this.name, other.name));
/*  75 */     result = (result && ObjectUtils.nullSafeEquals(this.value, other.value));
/*  76 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  81 */     int result = ObjectUtils.nullSafeHashCode(this.name);
/*  82 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.value);
/*  83 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     return (new ToStringCreator(this)).append("name", this.name).append("value", this.value)
/*  89 */       .append("origin", this.origin).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ConfigurationProperty other) {
/*  94 */     return this.name.compareTo(other.name);
/*     */   }
/*     */   
/*     */   static ConfigurationProperty of(ConfigurationPropertyName name, OriginTrackedValue value) {
/*  98 */     if (value == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     return new ConfigurationProperty(name, value.getValue(), value.getOrigin());
/*     */   }
/*     */   
/*     */   static ConfigurationProperty of(ConfigurationPropertyName name, Object value, Origin origin) {
/* 105 */     if (value == null) {
/* 106 */       return null;
/*     */     }
/* 108 */     return new ConfigurationProperty(name, value, origin);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\ConfigurationProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties.bind.validation;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.validation.ObjectError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BindValidationException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final ValidationErrors validationErrors;
/*    */   
/*    */   BindValidationException(ValidationErrors validationErrors) {
/* 35 */     super(getMessage(validationErrors));
/* 36 */     Assert.notNull(validationErrors, "ValidationErrors must not be null");
/* 37 */     this.validationErrors = validationErrors;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ValidationErrors getValidationErrors() {
/* 45 */     return this.validationErrors;
/*    */   }
/*    */   
/*    */   private static String getMessage(ValidationErrors errors) {
/* 49 */     StringBuilder message = new StringBuilder("Binding validation errors");
/* 50 */     if (errors != null) {
/* 51 */       message.append(" on ").append(errors.getName());
/* 52 */       errors.getAllErrors().forEach(error -> message.append(String.format("%n   - %s", new Object[] { error })));
/*    */     } 
/* 54 */     return message.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\validation\BindValidationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ValueObjectBinder
/*     */   implements DataObjectBinder
/*     */ {
/*     */   private final BindConstructorProvider constructorProvider;
/*     */   
/*     */   ValueObjectBinder(BindConstructorProvider constructorProvider) {
/*  50 */     this.constructorProvider = constructorProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bind(ConfigurationPropertyName name, Bindable<T> target, Binder.Context context, DataObjectPropertyBinder propertyBinder) {
/*  56 */     ValueObject<T> valueObject = ValueObject.get(target, this.constructorProvider, context);
/*  57 */     if (valueObject == null) {
/*  58 */       return null;
/*     */     }
/*  60 */     context.pushConstructorBoundTypes(target.getType().resolve());
/*  61 */     List<ConstructorParameter> parameters = valueObject.getConstructorParameters();
/*  62 */     List<Object> args = new ArrayList(parameters.size());
/*  63 */     boolean bound = false;
/*  64 */     for (ConstructorParameter parameter : parameters) {
/*  65 */       Object arg = parameter.bind(propertyBinder);
/*  66 */       bound = (bound || arg != null);
/*  67 */       arg = (arg != null) ? arg : parameter.getDefaultValue(context.getConverter());
/*  68 */       args.add(arg);
/*     */     } 
/*  70 */     context.clearConfigurationProperty();
/*  71 */     context.popConstructorBoundTypes();
/*  72 */     return bound ? valueObject.instantiate(args) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T create(Bindable<T> target, Binder.Context context) {
/*  77 */     ValueObject<T> valueObject = ValueObject.get(target, this.constructorProvider, context);
/*  78 */     if (valueObject == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     List<ConstructorParameter> parameters = valueObject.getConstructorParameters();
/*  82 */     List<Object> args = new ArrayList(parameters.size());
/*  83 */     for (ConstructorParameter parameter : parameters) {
/*  84 */       args.add(parameter.getDefaultValue(context.getConverter()));
/*     */     }
/*  86 */     return valueObject.instantiate(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static abstract class ValueObject<T>
/*     */   {
/*     */     private final Constructor<T> constructor;
/*     */ 
/*     */ 
/*     */     
/*     */     protected ValueObject(Constructor<T> constructor) {
/*  99 */       this.constructor = constructor;
/*     */     }
/*     */     
/*     */     T instantiate(List<Object> args) {
/* 103 */       return (T)BeanUtils.instantiateClass(this.constructor, args.toArray());
/*     */     }
/*     */ 
/*     */     
/*     */     abstract List<ValueObjectBinder.ConstructorParameter> getConstructorParameters();
/*     */ 
/*     */     
/*     */     static <T> ValueObject<T> get(Bindable<T> bindable, BindConstructorProvider constructorProvider, Binder.Context context) {
/* 111 */       Class<T> type = bindable.getType().resolve();
/* 112 */       if (type == null || type.isEnum() || Modifier.isAbstract(type.getModifiers())) {
/* 113 */         return null;
/*     */       }
/* 115 */       Constructor<?> bindConstructor = constructorProvider.getBindConstructor(bindable, context
/* 116 */           .isNestedConstructorBinding());
/* 117 */       if (bindConstructor == null) {
/* 118 */         return null;
/*     */       }
/* 120 */       if (KotlinDetector.isKotlinType(type)) {
/* 121 */         return ValueObjectBinder.KotlinValueObject.get((Constructor)bindConstructor);
/*     */       }
/* 123 */       return ValueObjectBinder.DefaultValueObject.get(bindConstructor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class KotlinValueObject<T>
/*     */     extends ValueObject<T>
/*     */   {
/*     */     private final List<ValueObjectBinder.ConstructorParameter> constructorParameters;
/*     */ 
/*     */     
/*     */     private KotlinValueObject(Constructor<T> primaryConstructor, KFunction<T> kotlinConstructor) {
/* 136 */       super(primaryConstructor);
/* 137 */       this.constructorParameters = parseConstructorParameters(kotlinConstructor);
/*     */     }
/*     */     
/*     */     private List<ValueObjectBinder.ConstructorParameter> parseConstructorParameters(KFunction<T> kotlinConstructor) {
/* 141 */       List<KParameter> parameters = kotlinConstructor.getParameters();
/* 142 */       List<ValueObjectBinder.ConstructorParameter> result = new ArrayList<>(parameters.size());
/* 143 */       for (KParameter parameter : parameters) {
/* 144 */         String name = parameter.getName();
/* 145 */         ResolvableType type = ResolvableType.forType(ReflectJvmMapping.getJavaType(parameter.getType()));
/* 146 */         Annotation[] annotations = (Annotation[])parameter.getAnnotations().toArray((Object[])new Annotation[0]);
/* 147 */         result.add(new ValueObjectBinder.ConstructorParameter(name, type, annotations));
/*     */       } 
/* 149 */       return Collections.unmodifiableList(result);
/*     */     }
/*     */ 
/*     */     
/*     */     List<ValueObjectBinder.ConstructorParameter> getConstructorParameters() {
/* 154 */       return this.constructorParameters;
/*     */     }
/*     */     
/*     */     static <T> ValueObjectBinder.ValueObject<T> get(Constructor<T> bindConstructor) {
/* 158 */       KFunction<T> kotlinConstructor = ReflectJvmMapping.getKotlinFunction(bindConstructor);
/* 159 */       if (kotlinConstructor != null) {
/* 160 */         return new KotlinValueObject<>(bindConstructor, kotlinConstructor);
/*     */       }
/* 162 */       return ValueObjectBinder.DefaultValueObject.get(bindConstructor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DefaultValueObject<T>
/*     */     extends ValueObject<T>
/*     */   {
/* 173 */     private static final ParameterNameDiscoverer PARAMETER_NAME_DISCOVERER = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*     */     
/*     */     private final List<ValueObjectBinder.ConstructorParameter> constructorParameters;
/*     */     
/*     */     private DefaultValueObject(Constructor<T> constructor) {
/* 178 */       super(constructor);
/* 179 */       this.constructorParameters = parseConstructorParameters(constructor);
/*     */     }
/*     */     
/*     */     private static List<ValueObjectBinder.ConstructorParameter> parseConstructorParameters(Constructor<?> constructor) {
/* 183 */       String[] names = PARAMETER_NAME_DISCOVERER.getParameterNames(constructor);
/* 184 */       Assert.state((names != null), () -> "Failed to extract parameter names for " + constructor);
/* 185 */       Parameter[] parameters = constructor.getParameters();
/* 186 */       List<ValueObjectBinder.ConstructorParameter> result = new ArrayList<>(parameters.length);
/* 187 */       for (int i = 0; i < parameters.length; i++) {
/* 188 */         String name = names[i];
/* 189 */         ResolvableType type = ResolvableType.forConstructorParameter(constructor, i);
/* 190 */         Annotation[] annotations = parameters[i].getDeclaredAnnotations();
/* 191 */         result.add(new ValueObjectBinder.ConstructorParameter(name, type, annotations));
/*     */       } 
/* 193 */       return Collections.unmodifiableList(result);
/*     */     }
/*     */ 
/*     */     
/*     */     List<ValueObjectBinder.ConstructorParameter> getConstructorParameters() {
/* 198 */       return this.constructorParameters;
/*     */     }
/*     */ 
/*     */     
/*     */     static <T> ValueObjectBinder.ValueObject<T> get(Constructor<?> bindConstructor) {
/* 203 */       return new DefaultValueObject<>((Constructor)bindConstructor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConstructorParameter
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final ResolvableType type;
/*     */     
/*     */     private final Annotation[] annotations;
/*     */ 
/*     */     
/*     */     ConstructorParameter(String name, ResolvableType type, Annotation[] annotations) {
/* 220 */       this.name = DataObjectPropertyName.toDashedForm(name);
/* 221 */       this.type = type;
/* 222 */       this.annotations = annotations;
/*     */     }
/*     */     
/*     */     Object getDefaultValue(BindConverter converter) {
/* 226 */       for (Annotation annotation : this.annotations) {
/* 227 */         if (annotation instanceof DefaultValue) {
/* 228 */           return converter.convert(((DefaultValue)annotation).value(), this.type, this.annotations);
/*     */         }
/*     */       } 
/* 231 */       return null;
/*     */     }
/*     */     
/*     */     Object bind(DataObjectPropertyBinder propertyBinder) {
/* 235 */       return propertyBinder.bindProperty(this.name, Bindable.of(this.type).withAnnotations(this.annotations));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\ValueObjectBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.core.KotlinDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultBindConstructorProvider
/*    */   implements BindConstructorProvider
/*    */ {
/*    */   public Constructor<?> getBindConstructor(Bindable<?> bindable, boolean isNestedConstructorBinding) {
/* 34 */     Class<?> type = bindable.getType().resolve();
/* 35 */     if (bindable.getValue() != null || type == null) {
/* 36 */       return null;
/*    */     }
/* 38 */     if (KotlinDetector.isKotlinPresent() && KotlinDetector.isKotlinType(type)) {
/* 39 */       return getDeducedKotlinConstructor(type);
/*    */     }
/* 41 */     Constructor[] arrayOfConstructor = (Constructor[])type.getDeclaredConstructors();
/* 42 */     if (arrayOfConstructor.length == 1 && arrayOfConstructor[0].getParameterCount() > 0) {
/* 43 */       return arrayOfConstructor[0];
/*    */     }
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   private Constructor<?> getDeducedKotlinConstructor(Class<?> type) {
/* 49 */     Constructor<?> primaryConstructor = BeanUtils.findPrimaryConstructor(type);
/* 50 */     if (primaryConstructor != null && primaryConstructor.getParameterCount() > 0) {
/* 51 */       return primaryConstructor;
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\DefaultBindConstructorProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.BindResult;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.bind.PropertySourcesPlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.bind.handler.IgnoreErrorsBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.handler.IgnoreTopLevelConverterNotFoundBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.handler.NoUnboundElementsBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.validation.ValidationBindHandler;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*     */ import org.springframework.boot.context.properties.source.UnboundElementsSourceFilter;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertiesBinder
/*     */ {
/*     */   private static final String BEAN_NAME = "org.springframework.boot.context.internalConfigurationPropertiesBinder";
/*     */   private static final String FACTORY_BEAN_NAME = "org.springframework.boot.context.internalConfigurationPropertiesBinderFactory";
/*     */   private static final String VALIDATOR_BEAN_NAME = "configurationPropertiesValidator";
/*     */   private final ApplicationContext applicationContext;
/*     */   private final PropertySources propertySources;
/*     */   private final Validator configurationPropertiesValidator;
/*     */   private final boolean jsr303Present;
/*     */   private volatile Validator jsr303Validator;
/*     */   private volatile Binder binder;
/*     */   
/*     */   ConfigurationPropertiesBinder(ApplicationContext applicationContext) {
/*  79 */     this.applicationContext = applicationContext;
/*  80 */     this.propertySources = (new PropertySourcesDeducer(applicationContext)).getPropertySources();
/*  81 */     this.configurationPropertiesValidator = getConfigurationPropertiesValidator(applicationContext);
/*  82 */     this.jsr303Present = ConfigurationPropertiesJsr303Validator.isJsr303Present(applicationContext);
/*     */   }
/*     */   
/*     */   BindResult<?> bind(ConfigurationPropertiesBean propertiesBean) {
/*  86 */     Bindable<?> target = propertiesBean.asBindTarget();
/*  87 */     ConfigurationProperties annotation = propertiesBean.getAnnotation();
/*  88 */     BindHandler bindHandler = getBindHandler(target, annotation);
/*  89 */     return getBinder().bind(annotation.prefix(), target, bindHandler);
/*     */   }
/*     */   
/*     */   Object bindOrCreate(ConfigurationPropertiesBean propertiesBean) {
/*  93 */     Bindable<?> target = propertiesBean.asBindTarget();
/*  94 */     ConfigurationProperties annotation = propertiesBean.getAnnotation();
/*  95 */     BindHandler bindHandler = getBindHandler(target, annotation);
/*  96 */     return getBinder().bindOrCreate(annotation.prefix(), target, bindHandler);
/*     */   }
/*     */   
/*     */   private Validator getConfigurationPropertiesValidator(ApplicationContext applicationContext) {
/* 100 */     if (applicationContext.containsBean("configurationPropertiesValidator")) {
/* 101 */       return (Validator)applicationContext.getBean("configurationPropertiesValidator", Validator.class);
/*     */     }
/* 103 */     return null; } private <T> BindHandler getBindHandler(Bindable<T> target, ConfigurationProperties annotation) { IgnoreErrorsBindHandler ignoreErrorsBindHandler;
/*     */     NoUnboundElementsBindHandler noUnboundElementsBindHandler;
/*     */     ValidationBindHandler validationBindHandler;
/*     */     BindHandler bindHandler;
/* 107 */     List<Validator> validators = getValidators(target);
/* 108 */     IgnoreTopLevelConverterNotFoundBindHandler ignoreTopLevelConverterNotFoundBindHandler = new IgnoreTopLevelConverterNotFoundBindHandler();
/* 109 */     if (annotation.ignoreInvalidFields()) {
/* 110 */       ignoreErrorsBindHandler = new IgnoreErrorsBindHandler((BindHandler)ignoreTopLevelConverterNotFoundBindHandler);
/*     */     }
/* 112 */     if (!annotation.ignoreUnknownFields()) {
/* 113 */       UnboundElementsSourceFilter filter = new UnboundElementsSourceFilter();
/* 114 */       noUnboundElementsBindHandler = new NoUnboundElementsBindHandler((BindHandler)ignoreErrorsBindHandler, (Function)filter);
/*     */     } 
/* 116 */     if (!validators.isEmpty()) {
/* 117 */       validationBindHandler = new ValidationBindHandler((BindHandler)noUnboundElementsBindHandler, validators.<Validator>toArray(new Validator[0]));
/*     */     }
/* 119 */     for (ConfigurationPropertiesBindHandlerAdvisor advisor : getBindHandlerAdvisors()) {
/* 120 */       bindHandler = advisor.apply((BindHandler)validationBindHandler);
/*     */     }
/* 122 */     return bindHandler; }
/*     */ 
/*     */   
/*     */   private List<Validator> getValidators(Bindable<?> target) {
/* 126 */     List<Validator> validators = new ArrayList<>(3);
/* 127 */     if (this.configurationPropertiesValidator != null) {
/* 128 */       validators.add(this.configurationPropertiesValidator);
/*     */     }
/* 130 */     if (this.jsr303Present && target.getAnnotation(Validated.class) != null) {
/* 131 */       validators.add(getJsr303Validator());
/*     */     }
/* 133 */     if (target.getValue() != null && target.getValue().get() instanceof Validator) {
/* 134 */       validators.add(target.getValue().get());
/*     */     }
/* 136 */     return validators;
/*     */   }
/*     */   
/*     */   private Validator getJsr303Validator() {
/* 140 */     if (this.jsr303Validator == null) {
/* 141 */       this.jsr303Validator = new ConfigurationPropertiesJsr303Validator(this.applicationContext);
/*     */     }
/* 143 */     return this.jsr303Validator;
/*     */   }
/*     */   
/*     */   private List<ConfigurationPropertiesBindHandlerAdvisor> getBindHandlerAdvisors() {
/* 147 */     return (List<ConfigurationPropertiesBindHandlerAdvisor>)this.applicationContext.getBeanProvider(ConfigurationPropertiesBindHandlerAdvisor.class).orderedStream()
/* 148 */       .collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   private Binder getBinder() {
/* 152 */     if (this.binder == null) {
/* 153 */       this
/* 154 */         .binder = new Binder(getConfigurationPropertySources(), (PlaceholdersResolver)getPropertySourcesPlaceholdersResolver(), getConversionService(), getPropertyEditorInitializer(), null, ConfigurationPropertiesBindConstructorProvider.INSTANCE);
/*     */     }
/*     */     
/* 157 */     return this.binder;
/*     */   }
/*     */   
/*     */   private Iterable<ConfigurationPropertySource> getConfigurationPropertySources() {
/* 161 */     return ConfigurationPropertySources.from((Iterable)this.propertySources);
/*     */   }
/*     */   
/*     */   private PropertySourcesPlaceholdersResolver getPropertySourcesPlaceholdersResolver() {
/* 165 */     return new PropertySourcesPlaceholdersResolver((Iterable)this.propertySources);
/*     */   }
/*     */   
/*     */   private ConversionService getConversionService() {
/* 169 */     return (new ConversionServiceDeducer(this.applicationContext)).getConversionService();
/*     */   }
/*     */   
/*     */   private Consumer<PropertyEditorRegistry> getPropertyEditorInitializer() {
/* 173 */     if (this.applicationContext instanceof ConfigurableApplicationContext) {
/* 174 */       return ((ConfigurableApplicationContext)this.applicationContext).getBeanFactory()::copyRegisteredEditorsTo;
/*     */     }
/* 176 */     return null;
/*     */   }
/*     */   
/*     */   static void register(BeanDefinitionRegistry registry) {
/* 180 */     if (!registry.containsBeanDefinition("org.springframework.boot.context.internalConfigurationPropertiesBinderFactory")) {
/* 181 */       GenericBeanDefinition definition = new GenericBeanDefinition();
/* 182 */       definition.setBeanClass(Factory.class);
/* 183 */       definition.setRole(2);
/* 184 */       registry.registerBeanDefinition("org.springframework.boot.context.internalConfigurationPropertiesBinderFactory", (BeanDefinition)definition);
/*     */     } 
/* 186 */     if (!registry.containsBeanDefinition("org.springframework.boot.context.internalConfigurationPropertiesBinder")) {
/* 187 */       GenericBeanDefinition definition = new GenericBeanDefinition();
/* 188 */       definition.setBeanClass(ConfigurationPropertiesBinder.class);
/* 189 */       definition.setRole(2);
/* 190 */       definition.setFactoryBeanName("org.springframework.boot.context.internalConfigurationPropertiesBinderFactory");
/* 191 */       definition.setFactoryMethodName("create");
/* 192 */       registry.registerBeanDefinition("org.springframework.boot.context.internalConfigurationPropertiesBinder", (BeanDefinition)definition);
/*     */     } 
/*     */   }
/*     */   
/*     */   static ConfigurationPropertiesBinder get(BeanFactory beanFactory) {
/* 197 */     return (ConfigurationPropertiesBinder)beanFactory.getBean("org.springframework.boot.context.internalConfigurationPropertiesBinder", ConfigurationPropertiesBinder.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Factory
/*     */     implements ApplicationContextAware
/*     */   {
/*     */     private ApplicationContext applicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 212 */       this.applicationContext = applicationContext;
/*     */     }
/*     */     
/*     */     ConfigurationPropertiesBinder create() {
/* 216 */       return new ConfigurationPropertiesBinder(this.applicationContext);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
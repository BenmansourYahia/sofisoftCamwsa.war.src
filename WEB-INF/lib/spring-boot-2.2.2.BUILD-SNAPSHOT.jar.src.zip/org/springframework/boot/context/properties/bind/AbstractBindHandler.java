/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBindHandler
/*    */   implements BindHandler
/*    */ {
/*    */   private final BindHandler parent;
/*    */   
/*    */   public AbstractBindHandler() {
/* 37 */     this(BindHandler.DEFAULT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AbstractBindHandler(BindHandler parent) {
/* 45 */     Assert.notNull(parent, "Parent must not be null");
/* 46 */     this.parent = parent;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> Bindable<T> onStart(ConfigurationPropertyName name, Bindable<T> target, BindContext context) {
/* 51 */     return this.parent.onStart(name, target, context);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/* 56 */     return this.parent.onSuccess(name, target, context, result);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error) throws Exception {
/* 62 */     return this.parent.onFailure(name, target, context, error);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onFinish(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) throws Exception {
/* 68 */     this.parent.onFinish(name, target, context, result);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\AbstractBindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
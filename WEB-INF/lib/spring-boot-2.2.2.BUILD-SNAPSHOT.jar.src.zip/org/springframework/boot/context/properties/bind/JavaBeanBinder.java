/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyState;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JavaBeanBinder
/*     */   implements DataObjectBinder
/*     */ {
/*  45 */   static final JavaBeanBinder INSTANCE = new JavaBeanBinder();
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bind(ConfigurationPropertyName name, Bindable<T> target, Binder.Context context, DataObjectPropertyBinder propertyBinder) {
/*  50 */     boolean hasKnownBindableProperties = (target.getValue() != null && hasKnownBindableProperties(name, context));
/*  51 */     Bean<T> bean = Bean.get(target, hasKnownBindableProperties);
/*  52 */     if (bean == null) {
/*  53 */       return null;
/*     */     }
/*  55 */     BeanSupplier<T> beanSupplier = bean.getSupplier(target);
/*  56 */     boolean bound = bind(propertyBinder, bean, beanSupplier);
/*  57 */     return bound ? beanSupplier.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T create(Bindable<T> target, Binder.Context context) {
/*  63 */     Class<T> type = target.getType().resolve();
/*  64 */     return (type != null) ? (T)BeanUtils.instantiateClass(type) : null;
/*     */   }
/*     */   
/*     */   private boolean hasKnownBindableProperties(ConfigurationPropertyName name, Binder.Context context) {
/*  68 */     for (ConfigurationPropertySource source : context.getSources()) {
/*  69 */       if (source.containsDescendantOf(name) == ConfigurationPropertyState.PRESENT) {
/*  70 */         return true;
/*     */       }
/*     */     } 
/*  73 */     return false;
/*     */   }
/*     */   
/*     */   private <T> boolean bind(DataObjectPropertyBinder propertyBinder, Bean<T> bean, BeanSupplier<T> beanSupplier) {
/*  77 */     boolean bound = false;
/*  78 */     for (BeanProperty beanProperty : bean.getProperties().values()) {
/*  79 */       bound |= bind(beanSupplier, propertyBinder, beanProperty);
/*     */     }
/*  81 */     return bound;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> boolean bind(BeanSupplier<T> beanSupplier, DataObjectPropertyBinder propertyBinder, BeanProperty property) {
/*  86 */     String propertyName = property.getName();
/*  87 */     ResolvableType type = property.getType();
/*  88 */     Supplier<Object> value = property.getValue(beanSupplier);
/*  89 */     Annotation[] annotations = property.getAnnotations();
/*  90 */     Object bound = propertyBinder.bindProperty(propertyName, 
/*  91 */         Bindable.of(type).withSuppliedValue(value).withAnnotations(annotations));
/*  92 */     if (bound == null) {
/*  93 */       return false;
/*     */     }
/*  95 */     if (property.isSettable()) {
/*  96 */       property.setValue(beanSupplier, bound);
/*     */     }
/*  98 */     else if (value == null || !bound.equals(value.get())) {
/*  99 */       throw new IllegalStateException("No setter found for property: " + property.getName());
/*     */     } 
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Bean<T>
/*     */   {
/*     */     private static Bean<?> cached;
/*     */ 
/*     */     
/*     */     private final ResolvableType type;
/*     */ 
/*     */     
/*     */     private final Class<?> resolvedType;
/*     */ 
/*     */     
/* 117 */     private final Map<String, JavaBeanBinder.BeanProperty> properties = new LinkedHashMap<>();
/*     */     
/*     */     Bean(ResolvableType type, Class<?> resolvedType) {
/* 120 */       this.type = type;
/* 121 */       this.resolvedType = resolvedType;
/* 122 */       addProperties(resolvedType);
/*     */     }
/*     */     
/*     */     private void addProperties(Class<?> type) {
/* 126 */       while (type != null && !Object.class.equals(type)) {
/* 127 */         Method[] declaredMethods = type.getDeclaredMethods();
/* 128 */         Field[] declaredFields = type.getDeclaredFields();
/* 129 */         addProperties(declaredMethods, declaredFields);
/* 130 */         type = type.getSuperclass();
/*     */       } 
/*     */     }
/*     */     
/*     */     protected void addProperties(Method[] declaredMethods, Field[] declaredFields) {
/* 135 */       for (int i = 0; i < declaredMethods.length; i++) {
/* 136 */         if (!isCandidate(declaredMethods[i])) {
/* 137 */           declaredMethods[i] = null;
/*     */         }
/*     */       } 
/* 140 */       for (Method method : declaredMethods) {
/* 141 */         addMethodIfPossible(method, "get", 0, JavaBeanBinder.BeanProperty::addGetter);
/* 142 */         addMethodIfPossible(method, "is", 0, JavaBeanBinder.BeanProperty::addGetter);
/*     */       } 
/* 144 */       for (Method method : declaredMethods) {
/* 145 */         addMethodIfPossible(method, "set", 1, JavaBeanBinder.BeanProperty::addSetter);
/*     */       }
/* 147 */       for (Field field : declaredFields) {
/* 148 */         addField(field);
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isCandidate(Method method) {
/* 153 */       int modifiers = method.getModifiers();
/* 154 */       return (!Modifier.isPrivate(modifiers) && !Modifier.isProtected(modifiers) && !Modifier.isAbstract(modifiers) && 
/* 155 */         !Modifier.isStatic(modifiers) && !Object.class.equals(method.getDeclaringClass()) && 
/* 156 */         !Class.class.equals(method.getDeclaringClass()) && method.getName().indexOf('$') == -1);
/*     */     }
/*     */ 
/*     */     
/*     */     private void addMethodIfPossible(Method method, String prefix, int parameterCount, BiConsumer<JavaBeanBinder.BeanProperty, Method> consumer) {
/* 161 */       if (method != null && method.getParameterCount() == parameterCount && method.getName().startsWith(prefix) && method
/* 162 */         .getName().length() > prefix.length()) {
/* 163 */         String propertyName = Introspector.decapitalize(method.getName().substring(prefix.length()));
/* 164 */         consumer.accept(this.properties.computeIfAbsent(propertyName, this::getBeanProperty), method);
/*     */       } 
/*     */     }
/*     */     
/*     */     private JavaBeanBinder.BeanProperty getBeanProperty(String name) {
/* 169 */       return new JavaBeanBinder.BeanProperty(name, this.type);
/*     */     }
/*     */     
/*     */     private void addField(Field field) {
/* 173 */       JavaBeanBinder.BeanProperty property = this.properties.get(field.getName());
/* 174 */       if (property != null) {
/* 175 */         property.addField(field);
/*     */       }
/*     */     }
/*     */     
/*     */     Map<String, JavaBeanBinder.BeanProperty> getProperties() {
/* 180 */       return this.properties;
/*     */     }
/*     */ 
/*     */     
/*     */     JavaBeanBinder.BeanSupplier<T> getSupplier(Bindable<T> target) {
/* 185 */       return new JavaBeanBinder.BeanSupplier<>(() -> {
/*     */             T instance = null;
/*     */             if (target.getValue() != null) {
/*     */               instance = target.getValue().get();
/*     */             }
/*     */             if (instance == null) {
/*     */               instance = (T)BeanUtils.instantiateClass(this.resolvedType);
/*     */             }
/*     */             return (Supplier)instance;
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     static <T> Bean<T> get(Bindable<T> bindable, boolean canCallGetValue) {
/* 199 */       ResolvableType type = bindable.getType();
/* 200 */       Class<?> resolvedType = type.resolve(Object.class);
/* 201 */       Supplier<T> value = bindable.getValue();
/* 202 */       T instance = null;
/* 203 */       if (canCallGetValue && value != null) {
/* 204 */         instance = value.get();
/* 205 */         resolvedType = (instance != null) ? instance.getClass() : resolvedType;
/*     */       } 
/* 207 */       if (instance == null && !isInstantiable(resolvedType)) {
/* 208 */         return null;
/*     */       }
/* 210 */       Bean<?> bean = cached;
/* 211 */       if (bean == null || !bean.isOfType(type, resolvedType)) {
/* 212 */         bean = new Bean(type, resolvedType);
/* 213 */         cached = bean;
/*     */       } 
/* 215 */       return (Bean)bean;
/*     */     }
/*     */     
/*     */     private static boolean isInstantiable(Class<?> type) {
/* 219 */       if (type.isInterface()) {
/* 220 */         return false;
/*     */       }
/*     */       try {
/* 223 */         type.getDeclaredConstructor(new Class[0]);
/* 224 */         return true;
/*     */       }
/* 226 */       catch (Exception ex) {
/* 227 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isOfType(ResolvableType type, Class<?> resolvedType) {
/* 232 */       if (this.type.hasGenerics() || type.hasGenerics()) {
/* 233 */         return this.type.equals(type);
/*     */       }
/* 235 */       return (this.resolvedType != null && this.resolvedType.equals(resolvedType));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class BeanSupplier<T>
/*     */     implements Supplier<T>
/*     */   {
/*     */     private final Supplier<T> factory;
/*     */     private T instance;
/*     */     
/*     */     BeanSupplier(Supplier<T> factory) {
/* 247 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get() {
/* 252 */       if (this.instance == null) {
/* 253 */         this.instance = this.factory.get();
/*     */       }
/* 255 */       return this.instance;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class BeanProperty
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final ResolvableType declaringClassType;
/*     */     
/*     */     private Method getter;
/*     */     
/*     */     private Method setter;
/*     */     
/*     */     private Field field;
/*     */ 
/*     */     
/*     */     BeanProperty(String name, ResolvableType declaringClassType) {
/* 276 */       this.name = DataObjectPropertyName.toDashedForm(name);
/* 277 */       this.declaringClassType = declaringClassType;
/*     */     }
/*     */     
/*     */     void addGetter(Method getter) {
/* 281 */       if (this.getter == null) {
/* 282 */         this.getter = getter;
/*     */       }
/*     */     }
/*     */     
/*     */     void addSetter(Method setter) {
/* 287 */       if (this.setter == null || isBetterSetter(setter)) {
/* 288 */         this.setter = setter;
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isBetterSetter(Method setter) {
/* 293 */       return (this.getter != null && this.getter.getReturnType().equals(setter.getParameterTypes()[0]));
/*     */     }
/*     */     
/*     */     void addField(Field field) {
/* 297 */       if (this.field == null) {
/* 298 */         this.field = field;
/*     */       }
/*     */     }
/*     */     
/*     */     String getName() {
/* 303 */       return this.name;
/*     */     }
/*     */     
/*     */     ResolvableType getType() {
/* 307 */       if (this.setter != null) {
/* 308 */         MethodParameter methodParameter1 = new MethodParameter(this.setter, 0);
/* 309 */         return ResolvableType.forMethodParameter(methodParameter1, this.declaringClassType);
/*     */       } 
/* 311 */       MethodParameter methodParameter = new MethodParameter(this.getter, -1);
/* 312 */       return ResolvableType.forMethodParameter(methodParameter, this.declaringClassType);
/*     */     }
/*     */     
/*     */     Annotation[] getAnnotations() {
/*     */       try {
/* 317 */         return (this.field != null) ? this.field.getDeclaredAnnotations() : null;
/*     */       }
/* 319 */       catch (Exception ex) {
/* 320 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     Supplier<Object> getValue(Supplier<?> instance) {
/* 325 */       if (this.getter == null) {
/* 326 */         return null;
/*     */       }
/* 328 */       return () -> {
/*     */           try {
/*     */             this.getter.setAccessible(true);
/*     */             
/*     */             return this.getter.invoke(instance.get(), new Object[0]);
/* 333 */           } catch (Exception ex) {
/*     */             throw new IllegalStateException("Unable to get value for property " + this.name, ex);
/*     */           } 
/*     */         };
/*     */     }
/*     */     
/*     */     boolean isSettable() {
/* 340 */       return (this.setter != null);
/*     */     }
/*     */     
/*     */     void setValue(Supplier<?> instance, Object value) {
/*     */       try {
/* 345 */         this.setter.setAccessible(true);
/* 346 */         this.setter.invoke(instance.get(), new Object[] { value });
/*     */       }
/* 348 */       catch (Exception ex) {
/* 349 */         throw new IllegalStateException("Unable to set value for property " + this.name, ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\JavaBeanBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanCreationException;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurationPropertiesBindException
/*    */   extends BeanCreationException
/*    */ {
/*    */   private final ConfigurationPropertiesBean bean;
/*    */   
/*    */   ConfigurationPropertiesBindException(ConfigurationPropertiesBean bean, Exception cause) {
/* 35 */     super(bean.getName(), getMessage(bean), cause);
/* 36 */     this.bean = bean;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getBeanType() {
/* 44 */     return this.bean.getType();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurationProperties getAnnotation() {
/* 52 */     return this.bean.getAnnotation();
/*    */   }
/*    */   
/*    */   private static String getMessage(ConfigurationPropertiesBean bean) {
/* 56 */     ConfigurationProperties annotation = bean.getAnnotation();
/* 57 */     StringBuilder message = new StringBuilder();
/* 58 */     message.append("Could not bind properties to '");
/* 59 */     message.append(ClassUtils.getShortName(bean.getType())).append("' : ");
/* 60 */     message.append("prefix=").append(annotation.prefix());
/* 61 */     message.append(", ignoreInvalidFields=").append(annotation.ignoreInvalidFields());
/* 62 */     message.append(", ignoreUnknownFields=").append(annotation.ignoreUnknownFields());
/* 63 */     return message.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBindException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.bind.BindConstructorProvider;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertiesBindConstructorProvider
/*     */   implements BindConstructorProvider
/*     */ {
/*  37 */   static final ConfigurationPropertiesBindConstructorProvider INSTANCE = new ConfigurationPropertiesBindConstructorProvider();
/*     */ 
/*     */   
/*     */   public Constructor<?> getBindConstructor(Bindable<?> bindable, boolean isNestedConstructorBinding) {
/*  41 */     return getBindConstructor(bindable.getType().resolve(), isNestedConstructorBinding);
/*     */   }
/*     */   
/*     */   Constructor<?> getBindConstructor(Class<?> type, boolean isNestedConstructorBinding) {
/*  45 */     if (type == null) {
/*  46 */       return null;
/*     */     }
/*  48 */     Constructor<?> constructor = findConstructorBindingAnnotatedConstructor(type);
/*  49 */     if (constructor == null && (isConstructorBindingAnnotatedType(type) || isNestedConstructorBinding)) {
/*  50 */       constructor = deduceBindConstructor(type);
/*     */     }
/*  52 */     return constructor;
/*     */   }
/*     */   
/*     */   private Constructor<?> findConstructorBindingAnnotatedConstructor(Class<?> type) {
/*  56 */     if (isKotlinType(type)) {
/*  57 */       Constructor<?> constructor = BeanUtils.findPrimaryConstructor(type);
/*  58 */       if (constructor != null) {
/*  59 */         return findAnnotatedConstructor(type, (Constructor<?>[])new Constructor[] { constructor });
/*     */       }
/*     */     } 
/*  62 */     return findAnnotatedConstructor(type, type.getDeclaredConstructors());
/*     */   }
/*     */   
/*     */   private Constructor<?> findAnnotatedConstructor(Class<?> type, Constructor<?>... candidates) {
/*  66 */     Constructor<?> constructor = null;
/*  67 */     for (Constructor<?> candidate : candidates) {
/*  68 */       if (MergedAnnotations.from(candidate).isPresent(ConstructorBinding.class)) {
/*  69 */         Assert.state((candidate.getParameterCount() > 0), type
/*  70 */             .getName() + " declares @ConstructorBinding on a no-args constructor");
/*  71 */         Assert.state((constructor == null), type
/*  72 */             .getName() + " has more than one @ConstructorBinding constructor");
/*  73 */         constructor = candidate;
/*     */       } 
/*     */     } 
/*  76 */     return constructor;
/*     */   }
/*     */   
/*     */   private boolean isConstructorBindingAnnotatedType(Class<?> type) {
/*  80 */     return MergedAnnotations.from(type, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY_AND_ENCLOSING_CLASSES)
/*  81 */       .isPresent(ConstructorBinding.class);
/*     */   }
/*     */   
/*     */   private Constructor<?> deduceBindConstructor(Class<?> type) {
/*  85 */     if (isKotlinType(type)) {
/*  86 */       return deducedKotlinBindConstructor(type);
/*     */     }
/*  88 */     Constructor[] arrayOfConstructor = (Constructor[])type.getDeclaredConstructors();
/*  89 */     if (arrayOfConstructor.length == 1 && arrayOfConstructor[0].getParameterCount() > 0) {
/*  90 */       return arrayOfConstructor[0];
/*     */     }
/*  92 */     return null;
/*     */   }
/*     */   
/*     */   private Constructor<?> deducedKotlinBindConstructor(Class<?> type) {
/*  96 */     Constructor<?> primaryConstructor = BeanUtils.findPrimaryConstructor(type);
/*  97 */     if (primaryConstructor != null && primaryConstructor.getParameterCount() > 0) {
/*  98 */       return primaryConstructor;
/*     */     }
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isKotlinType(Class<?> type) {
/* 104 */     return (KotlinDetector.isKotlinPresent() && KotlinDetector.isKotlinType(type));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBindConstructorProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
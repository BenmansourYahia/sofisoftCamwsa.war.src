/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ interface AggregateElementBinder
/*    */ {
/*    */   default Object bind(ConfigurationPropertyName name, Bindable<?> target) {
/* 39 */     return bind(name, target, null);
/*    */   }
/*    */   
/*    */   Object bind(ConfigurationPropertyName paramConfigurationPropertyName, Bindable<?> paramBindable, ConfigurationPropertySource paramConfigurationPropertySource);
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\AggregateElementBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface PropertyMapper
/*    */ {
/* 41 */   public static final PropertyMapping[] NO_MAPPINGS = new PropertyMapping[0];
/*    */   
/*    */   PropertyMapping[] map(ConfigurationPropertyName paramConfigurationPropertyName);
/*    */   
/*    */   PropertyMapping[] map(String paramString);
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\PropertyMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface ConfigurationPropertySource
/*    */ {
/*    */   ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName paramConfigurationPropertyName);
/*    */   
/*    */   default ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 54 */     return ConfigurationPropertyState.UNKNOWN;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ConfigurationPropertySource filter(Predicate<ConfigurationPropertyName> filter) {
/* 64 */     return new FilteredConfigurationPropertiesSource(this, filter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ConfigurationPropertySource withAliases(ConfigurationPropertyNameAliases aliases) {
/* 73 */     return new AliasedConfigurationPropertySource(this, aliases);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Object getUnderlyingSource() {
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
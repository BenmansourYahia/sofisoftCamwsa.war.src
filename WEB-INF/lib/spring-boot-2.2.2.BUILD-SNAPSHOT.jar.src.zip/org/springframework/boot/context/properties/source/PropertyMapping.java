/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertyMapping
/*    */ {
/*    */   private final String propertySourceName;
/*    */   private final ConfigurationPropertyName configurationPropertyName;
/*    */   
/*    */   PropertyMapping(String propertySourceName, ConfigurationPropertyName configurationPropertyName) {
/* 42 */     this.propertySourceName = propertySourceName;
/* 43 */     this.configurationPropertyName = configurationPropertyName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getPropertySourceName() {
/* 51 */     return this.propertySourceName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ConfigurationPropertyName getConfigurationPropertyName() {
/* 60 */     return this.configurationPropertyName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isApplicable(ConfigurationPropertyName name) {
/* 70 */     return this.configurationPropertyName.equals(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\PropertyMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConfigurationPropertiesValueObjectBeanDefinition
/*    */   extends GenericBeanDefinition
/*    */ {
/*    */   private final BeanFactory beanFactory;
/*    */   private final String beanName;
/*    */   
/*    */   ConfigurationPropertiesValueObjectBeanDefinition(BeanFactory beanFactory, String beanName, Class<?> beanClass) {
/* 39 */     this.beanFactory = beanFactory;
/* 40 */     this.beanName = beanName;
/* 41 */     setBeanClass(beanClass);
/* 42 */     setInstanceSupplier(this::createBean);
/*    */   }
/*    */   
/*    */   private Object createBean() {
/* 46 */     ConfigurationPropertiesBean bean = ConfigurationPropertiesBean.forValueObject(getBeanClass(), this.beanName);
/* 47 */     ConfigurationPropertiesBinder binder = ConfigurationPropertiesBinder.get(this.beanFactory);
/*    */     try {
/* 49 */       return binder.bindOrCreate(bean);
/*    */     }
/* 51 */     catch (Exception ex) {
/* 52 */       throw new ConfigurationPropertiesBindException(bean, ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesValueObjectBeanDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
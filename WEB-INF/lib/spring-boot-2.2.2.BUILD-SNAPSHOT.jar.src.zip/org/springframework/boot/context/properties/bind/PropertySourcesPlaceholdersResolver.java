/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.env.PropertySources;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.PropertyPlaceholderHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertySourcesPlaceholdersResolver
/*    */   implements PlaceholdersResolver
/*    */ {
/*    */   private final Iterable<PropertySource<?>> sources;
/*    */   private final PropertyPlaceholderHelper helper;
/*    */   
/*    */   public PropertySourcesPlaceholdersResolver(Environment environment) {
/* 41 */     this((Iterable<PropertySource<?>>)getSources(environment), null);
/*    */   }
/*    */   
/*    */   public PropertySourcesPlaceholdersResolver(Iterable<PropertySource<?>> sources) {
/* 45 */     this(sources, null);
/*    */   }
/*    */   
/*    */   public PropertySourcesPlaceholdersResolver(Iterable<PropertySource<?>> sources, PropertyPlaceholderHelper helper) {
/* 49 */     this.sources = sources;
/* 50 */     this.helper = (helper != null) ? helper : new PropertyPlaceholderHelper("${", "}", ":", true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object resolvePlaceholders(Object value) {
/* 56 */     if (value instanceof String) {
/* 57 */       return this.helper.replacePlaceholders((String)value, this::resolvePlaceholder);
/*    */     }
/* 59 */     return value;
/*    */   }
/*    */   
/*    */   protected String resolvePlaceholder(String placeholder) {
/* 63 */     if (this.sources != null) {
/* 64 */       for (PropertySource<?> source : this.sources) {
/* 65 */         Object value = source.getProperty(placeholder);
/* 66 */         if (value != null) {
/* 67 */           return String.valueOf(value);
/*    */         }
/*    */       } 
/*    */     }
/* 71 */     return null;
/*    */   }
/*    */   
/*    */   private static PropertySources getSources(Environment environment) {
/* 75 */     Assert.notNull(environment, "Environment must not be null");
/* 76 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment, "Environment must be a ConfigurableEnvironment");
/*    */     
/* 78 */     return (PropertySources)((ConfigurableEnvironment)environment).getPropertySources();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\PropertySourcesPlaceholdersResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
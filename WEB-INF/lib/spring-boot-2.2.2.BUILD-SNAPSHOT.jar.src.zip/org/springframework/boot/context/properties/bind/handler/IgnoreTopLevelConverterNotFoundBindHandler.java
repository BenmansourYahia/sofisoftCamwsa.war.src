/*    */ package org.springframework.boot.context.properties.bind.handler;
/*    */ 
/*    */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.BindHandler;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IgnoreTopLevelConverterNotFoundBindHandler
/*    */   extends AbstractBindHandler
/*    */ {
/*    */   public IgnoreTopLevelConverterNotFoundBindHandler() {}
/*    */   
/*    */   public IgnoreTopLevelConverterNotFoundBindHandler(BindHandler parent) {}
/*    */   
/*    */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error) throws Exception {
/* 52 */     if (context.getDepth() == 0 && error instanceof org.springframework.core.convert.ConverterNotFoundException) {
/* 53 */       return null;
/*    */     }
/* 55 */     throw error;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\handler\IgnoreTopLevelConverterNotFoundBindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
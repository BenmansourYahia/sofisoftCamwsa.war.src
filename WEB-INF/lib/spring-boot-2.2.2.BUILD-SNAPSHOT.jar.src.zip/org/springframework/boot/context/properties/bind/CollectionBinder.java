/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CollectionBinder
/*    */   extends IndexedElementsBinder<Collection<Object>>
/*    */ {
/*    */   CollectionBinder(Binder.Context context) {
/* 37 */     super(context);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object bindAggregate(ConfigurationPropertyName name, Bindable<?> target, AggregateElementBinder elementBinder) {
/* 43 */     Class<?> collectionType = (target.getValue() != null) ? List.class : target.getType().resolve(Object.class);
/* 44 */     ResolvableType aggregateType = ResolvableType.forClassWithGenerics(List.class, target
/* 45 */         .getType().asCollection().getGenerics());
/* 46 */     ResolvableType elementType = target.getType().asCollection().getGeneric(new int[0]);
/* 47 */     IndexedElementsBinder.IndexedCollectionSupplier result = new IndexedElementsBinder.IndexedCollectionSupplier(() -> CollectionFactory.createCollection(collectionType, elementType.resolve(), 0));
/*    */     
/* 49 */     bindIndexed(name, target, elementBinder, aggregateType, elementType, result);
/* 50 */     if (result.wasSupplied()) {
/* 51 */       return result.get();
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<Object> merge(Supplier<Collection<Object>> existing, Collection<Object> additional) {
/* 58 */     Collection<Object> existingCollection = getExistingIfPossible(existing);
/* 59 */     if (existingCollection == null) {
/* 60 */       return additional;
/*    */     }
/*    */     try {
/* 63 */       existingCollection.clear();
/* 64 */       existingCollection.addAll(additional);
/* 65 */       return copyIfPossible(existingCollection);
/*    */     }
/* 67 */     catch (UnsupportedOperationException ex) {
/* 68 */       return createNewCollection(additional);
/*    */     } 
/*    */   }
/*    */   
/*    */   private Collection<Object> getExistingIfPossible(Supplier<Collection<Object>> existing) {
/*    */     try {
/* 74 */       return existing.get();
/*    */     }
/* 76 */     catch (Exception ex) {
/* 77 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private Collection<Object> copyIfPossible(Collection<Object> collection) {
/*    */     try {
/* 83 */       return createNewCollection(collection);
/*    */     }
/* 85 */     catch (Exception ex) {
/* 86 */       return collection;
/*    */     } 
/*    */   }
/*    */   
/*    */   private Collection<Object> createNewCollection(Collection<Object> collection) {
/* 91 */     Collection<Object> result = CollectionFactory.createCollection(collection.getClass(), collection.size());
/* 92 */     result.addAll(collection);
/* 93 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\CollectionBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*    */ import org.springframework.boot.convert.ApplicationConversionService;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConversionServiceDeducer
/*    */ {
/*    */   private final ApplicationContext applicationContext;
/*    */   
/*    */   ConversionServiceDeducer(ApplicationContext applicationContext) {
/* 45 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */   ConversionService getConversionService() {
/*    */     try {
/* 50 */       return (ConversionService)this.applicationContext.getBean("conversionService", ConversionService.class);
/*    */     
/*    */     }
/* 53 */     catch (NoSuchBeanDefinitionException ex) {
/* 54 */       return (new Factory((BeanFactory)this.applicationContext.getAutowireCapableBeanFactory())).create();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private static class Factory
/*    */   {
/*    */     private final List<Converter> converters;
/*    */     
/*    */     private final List<GenericConverter> genericConverters;
/*    */     
/*    */     Factory(BeanFactory beanFactory) {
/* 66 */       this.converters = beans(beanFactory, Converter.class, "org.springframework.boot.context.properties.ConfigurationPropertiesBinding");
/* 67 */       this.genericConverters = beans(beanFactory, GenericConverter.class, "org.springframework.boot.context.properties.ConfigurationPropertiesBinding");
/*    */     }
/*    */     
/*    */     private <T> List<T> beans(BeanFactory beanFactory, Class<T> type, String qualifier) {
/* 71 */       if (beanFactory instanceof ListableBeanFactory) {
/* 72 */         return beans(type, qualifier, (ListableBeanFactory)beanFactory);
/*    */       }
/* 74 */       return Collections.emptyList();
/*    */     }
/*    */     
/*    */     private <T> List<T> beans(Class<T> type, String qualifier, ListableBeanFactory beanFactory) {
/* 78 */       return new ArrayList<>(
/* 79 */           BeanFactoryAnnotationUtils.qualifiedBeansOfType(beanFactory, type, qualifier).values());
/*    */     }
/*    */     
/*    */     ConversionService create() {
/* 83 */       if (this.converters.isEmpty() && this.genericConverters.isEmpty()) {
/* 84 */         return ApplicationConversionService.getSharedInstance();
/*    */       }
/* 86 */       ApplicationConversionService conversionService = new ApplicationConversionService();
/* 87 */       for (Converter<?, ?> converter : this.converters) {
/* 88 */         conversionService.addConverter(converter);
/*    */       }
/* 90 */       for (GenericConverter genericConverter : this.genericConverters) {
/* 91 */         conversionService.addConverter(genericConverter);
/*    */       }
/* 93 */       return (ConversionService)conversionService;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConversionServiceDeducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
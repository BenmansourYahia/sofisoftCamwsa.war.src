/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringConfigurationPropertySource
/*     */   implements ConfigurationPropertySource
/*     */ {
/*  56 */   private static final ConfigurationPropertyName RANDOM = ConfigurationPropertyName.of("random");
/*     */ 
/*     */ 
/*     */   
/*     */   private final PropertySource<?> propertySource;
/*     */ 
/*     */ 
/*     */   
/*     */   private final PropertyMapper mapper;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Function<ConfigurationPropertyName, ConfigurationPropertyState> containsDescendantOf;
/*     */ 
/*     */ 
/*     */   
/*     */   SpringConfigurationPropertySource(PropertySource<?> propertySource, PropertyMapper mapper, Function<ConfigurationPropertyName, ConfigurationPropertyState> containsDescendantOf) {
/*  73 */     Assert.notNull(propertySource, "PropertySource must not be null");
/*  74 */     Assert.notNull(mapper, "Mapper must not be null");
/*  75 */     this.propertySource = propertySource;
/*  76 */     this.mapper = (mapper instanceof DelegatingPropertyMapper) ? mapper : new DelegatingPropertyMapper(mapper);
/*  77 */     this.containsDescendantOf = (containsDescendantOf != null) ? containsDescendantOf : (n -> ConfigurationPropertyState.UNKNOWN);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/*  83 */     PropertyMapping[] mappings = getMapper().map(name);
/*  84 */     return find(mappings, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/*  89 */     return this.containsDescendantOf.apply(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getUnderlyingSource() {
/*  94 */     return this.propertySource;
/*     */   }
/*     */   
/*     */   protected final ConfigurationProperty find(PropertyMapping[] mappings, ConfigurationPropertyName name) {
/*  98 */     for (PropertyMapping candidate : mappings) {
/*  99 */       if (candidate.isApplicable(name)) {
/* 100 */         ConfigurationProperty result = find(candidate);
/* 101 */         if (result != null) {
/* 102 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   private ConfigurationProperty find(PropertyMapping mapping) {
/* 110 */     String propertySourceName = mapping.getPropertySourceName();
/* 111 */     Object value = getPropertySource().getProperty(propertySourceName);
/* 112 */     if (value == null) {
/* 113 */       return null;
/*     */     }
/* 115 */     ConfigurationPropertyName configurationPropertyName = mapping.getConfigurationPropertyName();
/* 116 */     Origin origin = PropertySourceOrigin.get(this.propertySource, propertySourceName);
/* 117 */     return ConfigurationProperty.of(configurationPropertyName, value, origin);
/*     */   }
/*     */   
/*     */   protected PropertySource<?> getPropertySource() {
/* 121 */     return this.propertySource;
/*     */   }
/*     */   
/*     */   protected final PropertyMapper getMapper() {
/* 125 */     return this.mapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return this.propertySource.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SpringConfigurationPropertySource from(PropertySource<?> source) {
/* 141 */     Assert.notNull(source, "Source must not be null");
/* 142 */     PropertyMapper mapper = getPropertyMapper(source);
/* 143 */     if (isFullEnumerable(source)) {
/* 144 */       return new SpringIterableConfigurationPropertySource((EnumerablePropertySource)source, mapper);
/*     */     }
/* 146 */     return new SpringConfigurationPropertySource(source, mapper, getContainsDescendantOfForSource(source));
/*     */   }
/*     */   
/*     */   private static PropertyMapper getPropertyMapper(PropertySource<?> source) {
/* 150 */     if (source instanceof org.springframework.core.env.SystemEnvironmentPropertySource && hasSystemEnvironmentName(source)) {
/* 151 */       return new DelegatingPropertyMapper(SystemEnvironmentPropertyMapper.INSTANCE, DefaultPropertyMapper.INSTANCE);
/*     */     }
/*     */     
/* 154 */     return new DelegatingPropertyMapper(DefaultPropertyMapper.INSTANCE);
/*     */   }
/*     */   
/*     */   private static boolean hasSystemEnvironmentName(PropertySource<?> source) {
/* 158 */     String name = source.getName();
/* 159 */     return ("systemEnvironment".equals(name) || name
/* 160 */       .endsWith("-systemEnvironment"));
/*     */   }
/*     */   
/*     */   private static boolean isFullEnumerable(PropertySource<?> source) {
/* 164 */     PropertySource<?> rootSource = getRootSource(source);
/* 165 */     if (rootSource.getSource() instanceof Map) {
/*     */       
/*     */       try {
/* 168 */         ((Map)rootSource.getSource()).size();
/*     */       }
/* 170 */       catch (UnsupportedOperationException ex) {
/* 171 */         return false;
/*     */       } 
/*     */     }
/* 174 */     return source instanceof EnumerablePropertySource;
/*     */   }
/*     */   
/*     */   private static PropertySource<?> getRootSource(PropertySource<?> source) {
/* 178 */     while (source.getSource() != null && source.getSource() instanceof PropertySource) {
/* 179 */       source = (PropertySource)source.getSource();
/*     */     }
/* 181 */     return source;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Function<ConfigurationPropertyName, ConfigurationPropertyState> getContainsDescendantOfForSource(PropertySource<?> source) {
/* 186 */     if (source.getSource() instanceof java.util.Random) {
/* 187 */       return SpringConfigurationPropertySource::containsDescendantOfForRandom;
/*     */     }
/* 189 */     return null;
/*     */   }
/*     */   
/*     */   private static ConfigurationPropertyState containsDescendantOfForRandom(ConfigurationPropertyName name) {
/* 193 */     if (name.isAncestorOf(RANDOM) || name.equals(RANDOM)) {
/* 194 */       return ConfigurationPropertyState.PRESENT;
/*     */     }
/* 196 */     return ConfigurationPropertyState.ABSENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DelegatingPropertyMapper
/*     */     implements PropertyMapper
/*     */   {
/* 205 */     private static final PropertyMapping[] NONE = new PropertyMapping[0];
/*     */     
/*     */     private final PropertyMapper first;
/*     */     
/*     */     private final PropertyMapper second;
/*     */     
/*     */     DelegatingPropertyMapper(PropertyMapper first) {
/* 212 */       this(first, null);
/*     */     }
/*     */     
/*     */     DelegatingPropertyMapper(PropertyMapper first, PropertyMapper second) {
/* 216 */       this.first = first;
/* 217 */       this.second = second;
/*     */     }
/*     */ 
/*     */     
/*     */     public PropertyMapping[] map(ConfigurationPropertyName configurationPropertyName) {
/* 222 */       PropertyMapping[] first = map(this.first, configurationPropertyName);
/* 223 */       PropertyMapping[] second = map(this.second, configurationPropertyName);
/* 224 */       return merge(first, second);
/*     */     }
/*     */     
/*     */     private PropertyMapping[] map(PropertyMapper mapper, ConfigurationPropertyName configurationPropertyName) {
/*     */       try {
/* 229 */         return (mapper != null) ? mapper.map(configurationPropertyName) : NONE;
/*     */       }
/* 231 */       catch (Exception ex) {
/* 232 */         return NONE;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public PropertyMapping[] map(String propertySourceName) {
/* 238 */       PropertyMapping[] first = map(this.first, propertySourceName);
/* 239 */       PropertyMapping[] second = map(this.second, propertySourceName);
/* 240 */       return merge(first, second);
/*     */     }
/*     */     
/*     */     private PropertyMapping[] map(PropertyMapper mapper, String propertySourceName) {
/*     */       try {
/* 245 */         return (mapper != null) ? mapper.map(propertySourceName) : NONE;
/*     */       }
/* 247 */       catch (Exception ex) {
/* 248 */         return NONE;
/*     */       } 
/*     */     }
/*     */     
/*     */     private PropertyMapping[] merge(PropertyMapping[] first, PropertyMapping[] second) {
/* 253 */       if (ObjectUtils.isEmpty((Object[])second)) {
/* 254 */         return first;
/*     */       }
/* 256 */       if (ObjectUtils.isEmpty((Object[])first)) {
/* 257 */         return second;
/*     */       }
/* 259 */       PropertyMapping[] merged = new PropertyMapping[first.length + second.length];
/* 260 */       System.arraycopy(first, 0, merged, 0, first.length);
/* 261 */       System.arraycopy(second, 0, merged, first.length, second.length);
/* 262 */       return merged;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\SpringConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
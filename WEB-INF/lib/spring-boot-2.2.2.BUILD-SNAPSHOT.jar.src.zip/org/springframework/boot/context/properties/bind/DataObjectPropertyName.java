/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class DataObjectPropertyName
/*    */ {
/*    */   static String toDashedForm(String name) {
/* 37 */     StringBuilder result = new StringBuilder();
/* 38 */     String replaced = name.replace('_', '-');
/* 39 */     for (int i = 0; i < replaced.length(); i++) {
/* 40 */       char ch = replaced.charAt(i);
/* 41 */       if (Character.isUpperCase(ch) && result.length() > 0 && result.charAt(result.length() - 1) != '-') {
/* 42 */         result.append('-');
/*    */       }
/* 44 */       result.append(Character.toLowerCase(ch));
/*    */     } 
/* 46 */     return result.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\DataObjectPropertyName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
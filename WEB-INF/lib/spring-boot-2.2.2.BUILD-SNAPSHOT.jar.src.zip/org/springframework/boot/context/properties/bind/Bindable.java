/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.style.ToStringCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Bindable<T>
/*     */ {
/*  43 */   private static final Annotation[] NO_ANNOTATIONS = new Annotation[0];
/*     */   
/*     */   private final ResolvableType type;
/*     */   
/*     */   private final ResolvableType boxedType;
/*     */   
/*     */   private final Supplier<T> value;
/*     */   
/*     */   private final Annotation[] annotations;
/*     */   
/*     */   private Bindable(ResolvableType type, ResolvableType boxedType, Supplier<T> value, Annotation[] annotations) {
/*  54 */     this.type = type;
/*  55 */     this.boxedType = boxedType;
/*  56 */     this.value = value;
/*  57 */     this.annotations = annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvableType getType() {
/*  65 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvableType getBoxedType() {
/*  73 */     return this.boxedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Supplier<T> getValue() {
/*  81 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/*  89 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getAnnotation(Class<A> type) {
/* 100 */     for (Annotation annotation : this.annotations) {
/* 101 */       if (type.isInstance(annotation)) {
/* 102 */         return (A)annotation;
/*     */       }
/*     */     } 
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 110 */     if (this == obj) {
/* 111 */       return true;
/*     */     }
/* 113 */     if (obj == null || getClass() != obj.getClass()) {
/* 114 */       return false;
/*     */     }
/* 116 */     Bindable<?> other = (Bindable)obj;
/* 117 */     boolean result = true;
/* 118 */     result = (result && nullSafeEquals(this.type.resolve(), other.type.resolve()));
/* 119 */     result = (result && nullSafeEquals(this.annotations, other.annotations));
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 125 */     int prime = 31;
/* 126 */     int result = 1;
/* 127 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.type);
/* 128 */     result = 31 * result + ObjectUtils.nullSafeHashCode((Object[])this.annotations);
/* 129 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     ToStringCreator creator = new ToStringCreator(this);
/* 135 */     creator.append("type", this.type);
/* 136 */     creator.append("value", (this.value != null) ? "provided" : "none");
/* 137 */     creator.append("annotations", this.annotations);
/* 138 */     return creator.toString();
/*     */   }
/*     */   
/*     */   private boolean nullSafeEquals(Object o1, Object o2) {
/* 142 */     return ObjectUtils.nullSafeEquals(o1, o2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withAnnotations(Annotation... annotations) {
/* 151 */     return new Bindable(this.type, this.boxedType, this.value, (annotations != null) ? annotations : NO_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withExistingValue(T existingValue) {
/* 161 */     Assert.isTrue((existingValue == null || this.type
/* 162 */         .isArray() || this.boxedType.resolve().isInstance(existingValue)), () -> "ExistingValue must be an instance of " + this.type);
/*     */     
/* 164 */     Supplier<T> value = (existingValue != null) ? (() -> existingValue) : null;
/* 165 */     return new Bindable(this.type, this.boxedType, value, this.annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withSuppliedValue(Supplier<T> suppliedValue) {
/* 174 */     return new Bindable(this.type, this.boxedType, suppliedValue, this.annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bindable<T> ofInstance(T instance) {
/* 188 */     Assert.notNull(instance, "Instance must not be null");
/* 189 */     Class<T> type = (Class)instance.getClass();
/* 190 */     return of(type).withExistingValue(instance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bindable<T> of(Class<T> type) {
/* 201 */     Assert.notNull(type, "Type must not be null");
/* 202 */     return of(ResolvableType.forClass(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Bindable<List<E>> listOf(Class<E> elementType) {
/* 212 */     return of(ResolvableType.forClassWithGenerics(List.class, new Class[] { elementType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Bindable<Set<E>> setOf(Class<E> elementType) {
/* 222 */     return of(ResolvableType.forClassWithGenerics(Set.class, new Class[] { elementType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> Bindable<Map<K, V>> mapOf(Class<K> keyType, Class<V> valueType) {
/* 234 */     return of(ResolvableType.forClassWithGenerics(Map.class, new Class[] { keyType, valueType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bindable<T> of(ResolvableType type) {
/* 245 */     Assert.notNull(type, "Type must not be null");
/* 246 */     ResolvableType boxedType = box(type);
/* 247 */     return new Bindable<>(type, boxedType, null, NO_ANNOTATIONS);
/*     */   }
/*     */   
/*     */   private static ResolvableType box(ResolvableType type) {
/* 251 */     Class<?> resolved = type.resolve();
/* 252 */     if (resolved != null && resolved.isPrimitive()) {
/* 253 */       Object array = Array.newInstance(resolved, 1);
/* 254 */       Class<?> wrapperType = Array.get(array, 0).getClass();
/* 255 */       return ResolvableType.forClass(wrapperType);
/*     */     } 
/* 257 */     if (resolved != null && resolved.isArray()) {
/* 258 */       return ResolvableType.forArrayComponent(box(type.getComponentType()));
/*     */     }
/* 260 */     return type;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\Bindable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
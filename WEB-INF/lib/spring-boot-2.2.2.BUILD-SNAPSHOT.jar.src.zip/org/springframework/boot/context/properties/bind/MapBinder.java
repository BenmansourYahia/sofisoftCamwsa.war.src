/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyState;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MapBinder
/*     */   extends AggregateBinder<Map<Object, Object>>
/*     */ {
/*  42 */   private static final Bindable<Map<String, String>> STRING_STRING_MAP = Bindable.mapOf(String.class, String.class);
/*     */   
/*     */   MapBinder(Binder.Context context) {
/*  45 */     super(context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAllowRecursiveBinding(ConfigurationPropertySource source) {
/*  50 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object bindAggregate(ConfigurationPropertyName name, Bindable<?> target, AggregateElementBinder elementBinder) {
/*  57 */     Map<Object, Object> map = CollectionFactory.createMap((target.getValue() != null) ? Map.class : target.getType().resolve(Object.class), 0);
/*  58 */     Bindable<?> resolvedTarget = resolveTarget(target);
/*  59 */     boolean hasDescendants = hasDescendants(name);
/*  60 */     for (ConfigurationPropertySource source : getContext().getSources()) {
/*  61 */       if (!ConfigurationPropertyName.EMPTY.equals(name)) {
/*  62 */         ConfigurationProperty property = source.getConfigurationProperty(name);
/*  63 */         if (property != null && !hasDescendants) {
/*  64 */           return getContext().getConverter().convert(property.getValue(), target);
/*     */         }
/*  66 */         source = source.filter(name::isAncestorOf);
/*     */       } 
/*  68 */       (new EntryBinder(name, resolvedTarget, elementBinder)).bindEntries(source, map);
/*     */     } 
/*  70 */     return map.isEmpty() ? null : map;
/*     */   }
/*     */   
/*     */   private boolean hasDescendants(ConfigurationPropertyName name) {
/*  74 */     for (ConfigurationPropertySource source : getContext().getSources()) {
/*  75 */       if (source.containsDescendantOf(name) == ConfigurationPropertyState.PRESENT) {
/*  76 */         return true;
/*     */       }
/*     */     } 
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   private Bindable<?> resolveTarget(Bindable<?> target) {
/*  83 */     Class<?> type = target.getType().resolve(Object.class);
/*  84 */     if (Properties.class.isAssignableFrom(type)) {
/*  85 */       return STRING_STRING_MAP;
/*     */     }
/*  87 */     return target;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<Object, Object> merge(Supplier<Map<Object, Object>> existing, Map<Object, Object> additional) {
/*  92 */     Map<Object, Object> existingMap = getExistingIfPossible(existing);
/*  93 */     if (existingMap == null) {
/*  94 */       return additional;
/*     */     }
/*     */     try {
/*  97 */       existingMap.putAll(additional);
/*  98 */       return copyIfPossible(existingMap);
/*     */     }
/* 100 */     catch (UnsupportedOperationException ex) {
/* 101 */       Map<Object, Object> result = createNewMap(additional.getClass(), existingMap);
/* 102 */       result.putAll(additional);
/* 103 */       return result;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<Object, Object> getExistingIfPossible(Supplier<Map<Object, Object>> existing) {
/*     */     try {
/* 109 */       return existing.get();
/*     */     }
/* 111 */     catch (Exception ex) {
/* 112 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<Object, Object> copyIfPossible(Map<Object, Object> map) {
/*     */     try {
/* 118 */       return createNewMap(map.getClass(), map);
/*     */     }
/* 120 */     catch (Exception ex) {
/* 121 */       return map;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<Object, Object> createNewMap(Class<?> mapClass, Map<Object, Object> map) {
/* 126 */     Map<Object, Object> result = CollectionFactory.createMap(mapClass, map.size());
/* 127 */     result.putAll(map);
/* 128 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private class EntryBinder
/*     */   {
/*     */     private final ConfigurationPropertyName root;
/*     */     
/*     */     private final AggregateElementBinder elementBinder;
/*     */     
/*     */     private final ResolvableType mapType;
/*     */     
/*     */     private final ResolvableType keyType;
/*     */     private final ResolvableType valueType;
/*     */     
/*     */     EntryBinder(ConfigurationPropertyName root, Bindable<?> target, AggregateElementBinder elementBinder) {
/* 144 */       this.root = root;
/* 145 */       this.elementBinder = elementBinder;
/* 146 */       this.mapType = target.getType().asMap();
/* 147 */       this.keyType = this.mapType.getGeneric(new int[] { 0 });
/* 148 */       this.valueType = this.mapType.getGeneric(new int[] { 1 });
/*     */     }
/*     */     
/*     */     void bindEntries(ConfigurationPropertySource source, Map<Object, Object> map) {
/* 152 */       if (source instanceof org.springframework.boot.context.properties.source.IterableConfigurationPropertySource) {
/* 153 */         for (ConfigurationPropertyName name : source) {
/* 154 */           Bindable<?> valueBindable = getValueBindable(name);
/* 155 */           ConfigurationPropertyName entryName = getEntryName(source, name);
/* 156 */           Object key = MapBinder.this.getContext().getConverter().convert(getKeyName(entryName), this.keyType, new java.lang.annotation.Annotation[0]);
/* 157 */           map.computeIfAbsent(key, k -> this.elementBinder.bind(entryName, valueBindable));
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private Bindable<?> getValueBindable(ConfigurationPropertyName name) {
/* 163 */       if (!this.root.isParentOf(name) && isValueTreatedAsNestedMap()) {
/* 164 */         return Bindable.of(this.mapType);
/*     */       }
/* 166 */       return Bindable.of(this.valueType);
/*     */     }
/*     */ 
/*     */     
/*     */     private ConfigurationPropertyName getEntryName(ConfigurationPropertySource source, ConfigurationPropertyName name) {
/* 171 */       Class<?> resolved = this.valueType.resolve(Object.class);
/* 172 */       if (Collection.class.isAssignableFrom(resolved) || this.valueType.isArray()) {
/* 173 */         return chopNameAtNumericIndex(name);
/*     */       }
/* 175 */       if (!this.root.isParentOf(name) && (isValueTreatedAsNestedMap() || !isScalarValue(source, name))) {
/* 176 */         return name.chop(this.root.getNumberOfElements() + 1);
/*     */       }
/* 178 */       return name;
/*     */     }
/*     */     
/*     */     private ConfigurationPropertyName chopNameAtNumericIndex(ConfigurationPropertyName name) {
/* 182 */       int start = this.root.getNumberOfElements() + 1;
/* 183 */       int size = name.getNumberOfElements();
/* 184 */       for (int i = start; i < size; i++) {
/* 185 */         if (name.isNumericIndex(i)) {
/* 186 */           return name.chop(i);
/*     */         }
/*     */       } 
/* 189 */       return name;
/*     */     }
/*     */     
/*     */     private boolean isValueTreatedAsNestedMap() {
/* 193 */       return Object.class.equals(this.valueType.resolve(Object.class));
/*     */     }
/*     */     
/*     */     private boolean isScalarValue(ConfigurationPropertySource source, ConfigurationPropertyName name) {
/* 197 */       Class<?> resolved = this.valueType.resolve(Object.class);
/* 198 */       if (!resolved.getName().startsWith("java.lang") && !resolved.isEnum()) {
/* 199 */         return false;
/*     */       }
/* 201 */       ConfigurationProperty property = source.getConfigurationProperty(name);
/* 202 */       if (property == null) {
/* 203 */         return false;
/*     */       }
/* 205 */       Object value = property.getValue();
/* 206 */       value = MapBinder.this.getContext().getPlaceholdersResolver().resolvePlaceholders(value);
/* 207 */       return MapBinder.this.getContext().getConverter().canConvert(value, this.valueType, new java.lang.annotation.Annotation[0]);
/*     */     }
/*     */     
/*     */     private String getKeyName(ConfigurationPropertyName name) {
/* 211 */       StringBuilder result = new StringBuilder();
/* 212 */       for (int i = this.root.getNumberOfElements(); i < name.getNumberOfElements(); i++) {
/* 213 */         if (result.length() != 0) {
/* 214 */           result.append('.');
/*     */         }
/* 216 */         result.append(name.getElement(i, ConfigurationPropertyName.Form.ORIGINAL));
/*     */       } 
/* 218 */       return result.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\MapBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
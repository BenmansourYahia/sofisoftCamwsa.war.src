/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SystemEnvironmentPropertyMapper
/*     */   implements PropertyMapper
/*     */ {
/*  37 */   public static final PropertyMapper INSTANCE = new SystemEnvironmentPropertyMapper();
/*     */ 
/*     */   
/*     */   public PropertyMapping[] map(ConfigurationPropertyName configurationPropertyName) {
/*  41 */     String name = convertName(configurationPropertyName);
/*  42 */     String legacyName = convertLegacyName(configurationPropertyName);
/*  43 */     if (name.equals(legacyName)) {
/*  44 */       return new PropertyMapping[] { new PropertyMapping(name, configurationPropertyName) };
/*     */     }
/*  46 */     return new PropertyMapping[] { new PropertyMapping(name, configurationPropertyName), new PropertyMapping(legacyName, configurationPropertyName) };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMapping[] map(String propertySourceName) {
/*  52 */     ConfigurationPropertyName name = convertName(propertySourceName);
/*  53 */     if (name == null || name.isEmpty()) {
/*  54 */       return NO_MAPPINGS;
/*     */     }
/*  56 */     return new PropertyMapping[] { new PropertyMapping(propertySourceName, name) };
/*     */   }
/*     */   
/*     */   private ConfigurationPropertyName convertName(String propertySourceName) {
/*     */     try {
/*  61 */       return ConfigurationPropertyName.adapt(propertySourceName, '_', this::processElementValue);
/*     */     }
/*  63 */     catch (Exception ex) {
/*  64 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String convertName(ConfigurationPropertyName name) {
/*  69 */     return convertName(name, name.getNumberOfElements());
/*     */   }
/*     */   
/*     */   private String convertName(ConfigurationPropertyName name, int numberOfElements) {
/*  73 */     StringBuilder result = new StringBuilder();
/*  74 */     for (int i = 0; i < numberOfElements; i++) {
/*  75 */       if (result.length() > 0) {
/*  76 */         result.append("_");
/*     */       }
/*  78 */       result.append(name.getElement(i, ConfigurationPropertyName.Form.UNIFORM).toUpperCase(Locale.ENGLISH));
/*     */     } 
/*  80 */     return result.toString();
/*     */   }
/*     */   
/*     */   private String convertLegacyName(ConfigurationPropertyName name) {
/*  84 */     StringBuilder result = new StringBuilder();
/*  85 */     for (int i = 0; i < name.getNumberOfElements(); i++) {
/*  86 */       if (result.length() > 0) {
/*  87 */         result.append("_");
/*     */       }
/*  89 */       result.append(convertLegacyNameElement(name.getElement(i, ConfigurationPropertyName.Form.ORIGINAL)));
/*     */     } 
/*  91 */     return result.toString();
/*     */   }
/*     */   
/*     */   private Object convertLegacyNameElement(String element) {
/*  95 */     return element.replace('-', '_').toUpperCase(Locale.ENGLISH);
/*     */   }
/*     */   
/*     */   private CharSequence processElementValue(CharSequence value) {
/*  99 */     String result = value.toString().toLowerCase(Locale.ENGLISH);
/* 100 */     return isNumber(result) ? ("[" + result + "]") : result;
/*     */   }
/*     */   
/*     */   private static boolean isNumber(String string) {
/* 104 */     return string.chars().allMatch(Character::isDigit);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\SystemEnvironmentPropertyMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BindResult<T>
/*     */ {
/*  39 */   private static final BindResult<?> UNBOUND = new BindResult(null);
/*     */   
/*     */   private final T value;
/*     */   
/*     */   private BindResult(T value) {
/*  44 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() throws NoSuchElementException {
/*  55 */     if (this.value == null) {
/*  56 */       throw new NoSuchElementException("No value bound");
/*     */     }
/*  58 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBound() {
/*  66 */     return (this.value != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ifBound(Consumer<? super T> consumer) {
/*  75 */     Assert.notNull(consumer, "Consumer must not be null");
/*  76 */     if (this.value != null) {
/*  77 */       consumer.accept(this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <U> BindResult<U> map(Function<? super T, ? extends U> mapper) {
/*  91 */     Assert.notNull(mapper, "Mapper must not be null");
/*  92 */     return of((this.value != null) ? mapper.apply(this.value) : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T orElse(T other) {
/* 102 */     return (this.value != null) ? this.value : other;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T orElseGet(Supplier<? extends T> other) {
/* 113 */     return (this.value != null) ? this.value : other.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public T orElseCreate(Class<? extends T> type) {
/* 125 */     Assert.notNull(type, "Type must not be null");
/* 126 */     return (this.value != null) ? this.value : (T)BeanUtils.instantiateClass(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <X extends Throwable> T orElseThrow(Supplier<? extends X> exceptionSupplier) throws X {
/* 138 */     if (this.value == null) {
/* 139 */       throw (X)exceptionSupplier.get();
/*     */     }
/* 141 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 146 */     if (this == obj) {
/* 147 */       return true;
/*     */     }
/* 149 */     if (obj == null || getClass() != obj.getClass()) {
/* 150 */       return false;
/*     */     }
/* 152 */     return ObjectUtils.nullSafeEquals(this.value, ((BindResult)obj).value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 157 */     return ObjectUtils.nullSafeHashCode(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> BindResult<T> of(T value) {
/* 162 */     if (value == null) {
/* 163 */       return (BindResult)UNBOUND;
/*     */     }
/* 165 */     return new BindResult<>(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\BindResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
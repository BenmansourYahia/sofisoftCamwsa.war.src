/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AliasedConfigurationPropertySource
/*    */   implements ConfigurationPropertySource
/*    */ {
/*    */   private final ConfigurationPropertySource source;
/*    */   private final ConfigurationPropertyNameAliases aliases;
/*    */   
/*    */   AliasedConfigurationPropertySource(ConfigurationPropertySource source, ConfigurationPropertyNameAliases aliases) {
/* 34 */     Assert.notNull(source, "Source must not be null");
/* 35 */     Assert.notNull(aliases, "Aliases must not be null");
/* 36 */     this.source = source;
/* 37 */     this.aliases = aliases;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/* 42 */     Assert.notNull(name, "Name must not be null");
/* 43 */     ConfigurationProperty result = getSource().getConfigurationProperty(name);
/* 44 */     if (result == null) {
/* 45 */       ConfigurationPropertyName aliasedName = getAliases().getNameForAlias(name);
/* 46 */       result = getSource().getConfigurationProperty(aliasedName);
/*    */     } 
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 53 */     Assert.notNull(name, "Name must not be null");
/* 54 */     ConfigurationPropertyState result = this.source.containsDescendantOf(name);
/* 55 */     if (result != ConfigurationPropertyState.ABSENT) {
/* 56 */       return result;
/*    */     }
/* 58 */     for (ConfigurationPropertyName alias : getAliases().getAliases(name)) {
/* 59 */       ConfigurationPropertyState aliasResult = this.source.containsDescendantOf(alias);
/* 60 */       if (aliasResult != ConfigurationPropertyState.ABSENT) {
/* 61 */         return aliasResult;
/*    */       }
/*    */     } 
/* 64 */     for (ConfigurationPropertyName from : getAliases()) {
/* 65 */       for (ConfigurationPropertyName alias : getAliases().getAliases(from)) {
/* 66 */         if (name.isAncestorOf(alias) && 
/* 67 */           this.source.getConfigurationProperty(from) != null) {
/* 68 */           return ConfigurationPropertyState.PRESENT;
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 73 */     return ConfigurationPropertyState.ABSENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getUnderlyingSource() {
/* 78 */     return this.source.getUnderlyingSource();
/*    */   }
/*    */   
/*    */   protected ConfigurationPropertySource getSource() {
/* 82 */     return this.source;
/*    */   }
/*    */   
/*    */   protected ConfigurationPropertyNameAliases getAliases() {
/* 86 */     return this.aliases;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\AliasedConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapConfigurationPropertySource
/*     */   implements IterableConfigurationPropertySource
/*     */ {
/*     */   private final Map<String, Object> source;
/*     */   private final IterableConfigurationPropertySource delegate;
/*     */   
/*     */   public MapConfigurationPropertySource() {
/*  46 */     this(Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapConfigurationPropertySource(Map<?, ?> map) {
/*  55 */     this.source = new LinkedHashMap<>();
/*  56 */     this.delegate = new SpringIterableConfigurationPropertySource((EnumerablePropertySource<?>)new MapPropertySource("source", this.source), DefaultPropertyMapper.INSTANCE);
/*     */     
/*  58 */     putAll(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<?, ?> map) {
/*  66 */     Assert.notNull(map, "Map must not be null");
/*  67 */     assertNotReadOnlySystemAttributesMap(map);
/*  68 */     map.forEach(this::put);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object name, Object value) {
/*  77 */     this.source.put((name != null) ? name.toString() : null, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getUnderlyingSource() {
/*  82 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/*  87 */     return this.delegate.getConfigurationProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ConfigurationPropertyName> iterator() {
/*  92 */     return this.delegate.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<ConfigurationPropertyName> stream() {
/*  97 */     return this.delegate.stream();
/*     */   }
/*     */   
/*     */   private void assertNotReadOnlySystemAttributesMap(Map<?, ?> map) {
/*     */     try {
/* 102 */       map.size();
/*     */     }
/* 104 */     catch (UnsupportedOperationException ex) {
/* 105 */       throw new IllegalArgumentException("Security restricted maps are not supported", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\MapConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
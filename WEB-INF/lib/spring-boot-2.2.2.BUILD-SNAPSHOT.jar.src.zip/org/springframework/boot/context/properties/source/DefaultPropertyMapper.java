/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultPropertyMapper
/*    */   implements PropertyMapper
/*    */ {
/* 33 */   public static final PropertyMapper INSTANCE = new DefaultPropertyMapper();
/*    */ 
/*    */ 
/*    */   
/*    */   private LastMapping<ConfigurationPropertyName> lastMappedConfigurationPropertyName;
/*    */ 
/*    */   
/*    */   private LastMapping<String> lastMappedPropertyName;
/*    */ 
/*    */ 
/*    */   
/*    */   public PropertyMapping[] map(ConfigurationPropertyName configurationPropertyName) {
/* 45 */     LastMapping<ConfigurationPropertyName> last = this.lastMappedConfigurationPropertyName;
/* 46 */     if (last != null && last.isFrom(configurationPropertyName)) {
/* 47 */       return last.getMapping();
/*    */     }
/* 49 */     String convertedName = configurationPropertyName.toString();
/* 50 */     PropertyMapping[] mapping = { new PropertyMapping(convertedName, configurationPropertyName) };
/* 51 */     this.lastMappedConfigurationPropertyName = new LastMapping<>(configurationPropertyName, mapping);
/* 52 */     return mapping;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PropertyMapping[] map(String propertySourceName) {
/* 58 */     LastMapping<String> last = this.lastMappedPropertyName;
/* 59 */     if (last != null && last.isFrom(propertySourceName)) {
/* 60 */       return last.getMapping();
/*    */     }
/* 62 */     PropertyMapping[] mapping = tryMap(propertySourceName);
/* 63 */     this.lastMappedPropertyName = new LastMapping<>(propertySourceName, mapping);
/* 64 */     return mapping;
/*    */   }
/*    */   
/*    */   private PropertyMapping[] tryMap(String propertySourceName) {
/*    */     try {
/* 69 */       ConfigurationPropertyName convertedName = ConfigurationPropertyName.adapt(propertySourceName, '.');
/* 70 */       if (!convertedName.isEmpty()) {
/* 71 */         return new PropertyMapping[] { new PropertyMapping(propertySourceName, convertedName) };
/*    */       }
/*    */     }
/* 74 */     catch (Exception exception) {}
/*    */     
/* 76 */     return NO_MAPPINGS;
/*    */   }
/*    */ 
/*    */   
/*    */   private static class LastMapping<T>
/*    */   {
/*    */     private final T from;
/*    */     private final PropertyMapping[] mapping;
/*    */     
/*    */     LastMapping(T from, PropertyMapping[] mapping) {
/* 86 */       this.from = from;
/* 87 */       this.mapping = mapping;
/*    */     }
/*    */     
/*    */     boolean isFrom(T from) {
/* 91 */       return ObjectUtils.nullSafeEquals(from, this.from);
/*    */     }
/*    */     
/*    */     PropertyMapping[] getMapping() {
/* 95 */       return this.mapping;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\DefaultPropertyMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ArrayBinder
/*    */   extends IndexedElementsBinder<Object>
/*    */ {
/*    */   ArrayBinder(Binder.Context context) {
/* 37 */     super(context);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object bindAggregate(ConfigurationPropertyName name, Bindable<?> target, AggregateElementBinder elementBinder) {
/* 43 */     IndexedElementsBinder.IndexedCollectionSupplier result = new IndexedElementsBinder.IndexedCollectionSupplier(java.util.ArrayList::new);
/* 44 */     ResolvableType aggregateType = target.getType();
/* 45 */     ResolvableType elementType = target.getType().getComponentType();
/* 46 */     bindIndexed(name, target, elementBinder, aggregateType, elementType, result);
/* 47 */     if (result.wasSupplied()) {
/* 48 */       List<Object> list = (List<Object>)result.get();
/* 49 */       Object array = Array.newInstance(elementType.resolve(), list.size());
/* 50 */       for (int i = 0; i < list.size(); i++) {
/* 51 */         Array.set(array, i, list.get(i));
/*    */       }
/* 53 */       return array;
/*    */     } 
/* 55 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object merge(Supplier<Object> existing, Object additional) {
/* 60 */     return additional;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\ArrayBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
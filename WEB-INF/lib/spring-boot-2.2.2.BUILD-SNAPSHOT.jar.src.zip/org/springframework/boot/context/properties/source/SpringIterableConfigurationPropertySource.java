/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringIterableConfigurationPropertySource
/*     */   extends SpringConfigurationPropertySource
/*     */   implements IterableConfigurationPropertySource
/*     */ {
/*     */   private volatile Cache cache;
/*     */   
/*     */   SpringIterableConfigurationPropertySource(EnumerablePropertySource<?> propertySource, PropertyMapper mapper) {
/*  53 */     super((PropertySource<?>)propertySource, mapper, null);
/*  54 */     assertEnumerablePropertySource();
/*     */   }
/*     */   
/*     */   private void assertEnumerablePropertySource() {
/*  58 */     if (getPropertySource() instanceof MapPropertySource) {
/*     */       try {
/*  60 */         ((Map)((MapPropertySource)getPropertySource()).getSource()).size();
/*     */       }
/*  62 */       catch (UnsupportedOperationException ex) {
/*  63 */         throw new IllegalArgumentException("PropertySource must be fully enumerable");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/*  70 */     ConfigurationProperty configurationProperty = super.getConfigurationProperty(name);
/*  71 */     if (configurationProperty == null) {
/*  72 */       configurationProperty = find(getPropertyMappings(getCache()), name);
/*     */     }
/*  74 */     return configurationProperty;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<ConfigurationPropertyName> stream() {
/*  79 */     return getConfigurationPropertyNames().stream();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ConfigurationPropertyName> iterator() {
/*  84 */     return getConfigurationPropertyNames().iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/*  89 */     return ConfigurationPropertyState.search(this, name::isAncestorOf);
/*     */   }
/*     */   
/*     */   private List<ConfigurationPropertyName> getConfigurationPropertyNames() {
/*  93 */     Cache cache = getCache();
/*  94 */     List<ConfigurationPropertyName> names = (cache != null) ? cache.getNames() : null;
/*  95 */     if (names != null) {
/*  96 */       return names;
/*     */     }
/*  98 */     PropertyMapping[] mappings = getPropertyMappings(cache);
/*  99 */     names = new ArrayList<>(mappings.length);
/* 100 */     for (PropertyMapping mapping : mappings) {
/* 101 */       names.add(mapping.getConfigurationPropertyName());
/*     */     }
/* 103 */     names = Collections.unmodifiableList(names);
/* 104 */     if (cache != null) {
/* 105 */       cache.setNames(names);
/*     */     }
/* 107 */     return names;
/*     */   }
/*     */   
/*     */   private PropertyMapping[] getPropertyMappings(Cache cache) {
/* 111 */     PropertyMapping[] result = (cache != null) ? cache.getMappings() : null;
/* 112 */     if (result != null) {
/* 113 */       return result;
/*     */     }
/* 115 */     String[] names = getPropertySource().getPropertyNames();
/* 116 */     List<PropertyMapping> mappings = new ArrayList<>(names.length * 2);
/* 117 */     for (String name : names) {
/* 118 */       Collections.addAll(mappings, getMapper().map(name));
/*     */     }
/* 120 */     result = mappings.<PropertyMapping>toArray(new PropertyMapping[0]);
/* 121 */     if (cache != null) {
/* 122 */       cache.setMappings(result);
/*     */     }
/* 124 */     return result;
/*     */   }
/*     */   
/*     */   private Cache getCache() {
/* 128 */     CacheKey key = CacheKey.get(getPropertySource());
/* 129 */     if (key == null) {
/* 130 */       return null;
/*     */     }
/* 132 */     Cache cache = this.cache;
/*     */     try {
/* 134 */       if (cache != null && cache.hasKeyEqualTo(key)) {
/* 135 */         return cache;
/*     */       }
/* 137 */       cache = new Cache(key.copy());
/* 138 */       this.cache = cache;
/* 139 */       return cache;
/*     */     }
/* 141 */     catch (ConcurrentModificationException ex) {
/*     */       
/* 143 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected EnumerablePropertySource<?> getPropertySource() {
/* 149 */     return (EnumerablePropertySource)super.getPropertySource();
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Cache
/*     */   {
/*     */     private final SpringIterableConfigurationPropertySource.CacheKey key;
/*     */     
/*     */     private List<ConfigurationPropertyName> names;
/*     */     private PropertyMapping[] mappings;
/*     */     
/*     */     Cache(SpringIterableConfigurationPropertySource.CacheKey key) {
/* 161 */       this.key = key;
/*     */     }
/*     */     
/*     */     boolean hasKeyEqualTo(SpringIterableConfigurationPropertySource.CacheKey key) {
/* 165 */       return this.key.equals(key);
/*     */     }
/*     */     
/*     */     List<ConfigurationPropertyName> getNames() {
/* 169 */       return this.names;
/*     */     }
/*     */     
/*     */     void setNames(List<ConfigurationPropertyName> names) {
/* 173 */       this.names = names;
/*     */     }
/*     */     
/*     */     PropertyMapping[] getMappings() {
/* 177 */       return this.mappings;
/*     */     }
/*     */     
/*     */     void setMappings(PropertyMapping[] mappings) {
/* 181 */       this.mappings = mappings;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class CacheKey
/*     */   {
/* 188 */     private static final CacheKey IMMUTABLE_PROPERTY_SOURCE = new CacheKey(new Object[0]);
/*     */     
/*     */     private final Object key;
/*     */     
/*     */     private CacheKey(Object key) {
/* 193 */       this.key = key;
/*     */     }
/*     */     
/*     */     CacheKey copy() {
/* 197 */       if (this == IMMUTABLE_PROPERTY_SOURCE) {
/* 198 */         return IMMUTABLE_PROPERTY_SOURCE;
/*     */       }
/* 200 */       return new CacheKey(copyKey(this.key));
/*     */     }
/*     */     
/*     */     private Object copyKey(Object key) {
/* 204 */       if (key instanceof Set) {
/* 205 */         return new HashSet((Set)key);
/*     */       }
/* 207 */       return ((String[])key).clone();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 212 */       if (this == obj) {
/* 213 */         return true;
/*     */       }
/* 215 */       if (obj == null || getClass() != obj.getClass()) {
/* 216 */         return false;
/*     */       }
/* 218 */       CacheKey otherCacheKey = (CacheKey)obj;
/* 219 */       return ObjectUtils.nullSafeEquals(this.key, otherCacheKey.key);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 224 */       return this.key.hashCode();
/*     */     }
/*     */     
/*     */     static CacheKey get(EnumerablePropertySource<?> source) {
/* 228 */       if (isImmutable(source)) {
/* 229 */         return IMMUTABLE_PROPERTY_SOURCE;
/*     */       }
/* 231 */       if (source instanceof MapPropertySource) {
/* 232 */         MapPropertySource mapPropertySource = (MapPropertySource)source;
/* 233 */         return new CacheKey(((Map)mapPropertySource.getSource()).keySet());
/*     */       } 
/* 235 */       return new CacheKey(source.getPropertyNames());
/*     */     }
/*     */     
/*     */     private static boolean isImmutable(EnumerablePropertySource<?> source) {
/* 239 */       if (source instanceof OriginLookup) {
/* 240 */         return ((OriginLookup)source).isImmutable();
/*     */       }
/* 242 */       if ("systemEnvironment".equals(source.getName())) {
/* 243 */         return (source.getSource() == System.getenv());
/*     */       }
/* 245 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\SpringIterableConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
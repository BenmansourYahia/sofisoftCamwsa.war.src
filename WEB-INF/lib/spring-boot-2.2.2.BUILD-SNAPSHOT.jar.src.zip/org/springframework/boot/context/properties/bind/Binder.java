/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyState;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Binder
/*     */ {
/*  56 */   private static final Set<Class<?>> NON_BEAN_CLASSES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(new Class[] { Object.class, Class.class })));
/*     */ 
/*     */   
/*     */   private final Iterable<ConfigurationPropertySource> sources;
/*     */ 
/*     */   
/*     */   private final PlaceholdersResolver placeholdersResolver;
/*     */ 
/*     */   
/*     */   private final ConversionService conversionService;
/*     */ 
/*     */   
/*     */   private final Consumer<PropertyEditorRegistry> propertyEditorInitializer;
/*     */   
/*     */   private final BindHandler defaultBindHandler;
/*     */   
/*     */   private final List<DataObjectBinder> dataObjectBinders;
/*     */ 
/*     */   
/*     */   public Binder(ConfigurationPropertySource... sources) {
/*  76 */     this(Arrays.asList(sources), null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources) {
/*  85 */     this(sources, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver) {
/*  94 */     this(sources, placeholdersResolver, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService) {
/* 106 */     this(sources, placeholdersResolver, conversionService, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer) {
/* 121 */     this(sources, placeholdersResolver, conversionService, propertyEditorInitializer, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer, BindHandler defaultBindHandler) {
/* 140 */     this(sources, placeholdersResolver, conversionService, propertyEditorInitializer, defaultBindHandler, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer, BindHandler defaultBindHandler, BindConstructorProvider constructorProvider) {
/* 161 */     Assert.notNull(sources, "Sources must not be null");
/* 162 */     this.sources = sources;
/* 163 */     this.placeholdersResolver = (placeholdersResolver != null) ? placeholdersResolver : PlaceholdersResolver.NONE;
/* 164 */     this
/* 165 */       .conversionService = (conversionService != null) ? conversionService : ApplicationConversionService.getSharedInstance();
/* 166 */     this.propertyEditorInitializer = propertyEditorInitializer;
/* 167 */     this.defaultBindHandler = (defaultBindHandler != null) ? defaultBindHandler : BindHandler.DEFAULT;
/* 168 */     if (constructorProvider == null) {
/* 169 */       constructorProvider = BindConstructorProvider.DEFAULT;
/*     */     }
/* 171 */     ValueObjectBinder valueObjectBinder = new ValueObjectBinder(constructorProvider);
/* 172 */     JavaBeanBinder javaBeanBinder = JavaBeanBinder.INSTANCE;
/* 173 */     this.dataObjectBinders = Collections.unmodifiableList(Arrays.asList(new DataObjectBinder[] { valueObjectBinder, javaBeanBinder }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(String name, Class<T> target) {
/* 186 */     return bind(name, Bindable.of(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(String name, Bindable<T> target) {
/* 199 */     return bind(ConfigurationPropertyName.of(name), target, (BindHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(ConfigurationPropertyName name, Bindable<T> target) {
/* 212 */     return bind(name, target, (BindHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(String name, Bindable<T> target, BindHandler handler) {
/* 225 */     return bind(ConfigurationPropertyName.of(name), target, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler) {
/* 238 */     T bound = bind(name, target, handler, false);
/* 239 */     return BindResult.of(bound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(String name, Class<T> target) {
/* 254 */     return bindOrCreate(name, Bindable.of(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(String name, Bindable<T> target) {
/* 269 */     return bindOrCreate(ConfigurationPropertyName.of(name), target, (BindHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(String name, Bindable<T> target, BindHandler handler) {
/* 285 */     return bindOrCreate(ConfigurationPropertyName.of(name), target, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler) {
/* 300 */     return bind(name, target, handler, true);
/*     */   }
/*     */   
/*     */   private <T> T bind(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, boolean create) {
/* 304 */     Assert.notNull(name, "Name must not be null");
/* 305 */     Assert.notNull(target, "Target must not be null");
/* 306 */     handler = (handler != null) ? handler : this.defaultBindHandler;
/* 307 */     Context context = new Context();
/* 308 */     return bind(name, target, handler, context, false, create);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T bind(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, boolean allowRecursiveBinding, boolean create) {
/* 313 */     context.clearConfigurationProperty();
/*     */     try {
/* 315 */       Bindable<T> replacementTarget = handler.onStart(name, target, context);
/* 316 */       if (replacementTarget == null) {
/* 317 */         return handleBindResult(name, target, handler, context, null, create);
/*     */       }
/* 319 */       target = replacementTarget;
/* 320 */       Object bound = bindObject(name, target, handler, context, allowRecursiveBinding);
/* 321 */       return handleBindResult(name, target, handler, context, bound, create);
/*     */     }
/* 323 */     catch (Exception ex) {
/* 324 */       return handleBindError(name, target, handler, context, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T handleBindResult(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, Object result, boolean create) throws Exception {
/* 330 */     if (result != null) {
/* 331 */       result = handler.onSuccess(name, target, context, result);
/* 332 */       result = context.getConverter().convert(result, target);
/*     */     } 
/* 334 */     if (result == null && create) {
/* 335 */       result = create(target, context);
/* 336 */       result = handler.onCreate(name, target, context, result);
/* 337 */       result = context.getConverter().convert(result, target);
/* 338 */       Assert.state((result != null), () -> "Unable to create instance for " + target.getType());
/*     */     } 
/* 340 */     handler.onFinish(name, target, context, result);
/* 341 */     return context.getConverter().convert(result, target);
/*     */   }
/*     */   
/*     */   private Object create(Bindable<?> target, Context context) {
/* 345 */     for (DataObjectBinder dataObjectBinder : this.dataObjectBinders) {
/* 346 */       Object instance = dataObjectBinder.create(target, context);
/* 347 */       if (instance != null) {
/* 348 */         return instance;
/*     */       }
/*     */     } 
/* 351 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T handleBindError(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, Exception error) {
/*     */     try {
/* 357 */       Object result = handler.onFailure(name, target, context, error);
/* 358 */       return context.getConverter().convert(result, target);
/*     */     }
/* 360 */     catch (Exception ex) {
/* 361 */       if (ex instanceof BindException) {
/* 362 */         throw (BindException)ex;
/*     */       }
/* 364 */       throw new BindException(name, target, context.getConfigurationProperty(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Object bindObject(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, boolean allowRecursiveBinding) {
/* 370 */     ConfigurationProperty property = findProperty(name, context);
/* 371 */     if (property == null && containsNoDescendantOf(context.getSources(), name) && context.depth != 0) {
/* 372 */       return null;
/*     */     }
/* 374 */     AggregateBinder<?> aggregateBinder = getAggregateBinder(target, context);
/* 375 */     if (aggregateBinder != null) {
/* 376 */       return bindAggregate(name, target, handler, context, aggregateBinder);
/*     */     }
/* 378 */     if (property != null) {
/*     */       try {
/* 380 */         return bindProperty(target, context, property);
/*     */       }
/* 382 */       catch (ConverterNotFoundException ex) {
/*     */         
/* 384 */         Object instance = bindDataObject(name, target, handler, context, allowRecursiveBinding);
/* 385 */         if (instance != null) {
/* 386 */           return instance;
/*     */         }
/* 388 */         throw ex;
/*     */       } 
/*     */     }
/* 391 */     return bindDataObject(name, target, handler, context, allowRecursiveBinding);
/*     */   }
/*     */   
/*     */   private AggregateBinder<?> getAggregateBinder(Bindable<?> target, Context context) {
/* 395 */     Class<?> resolvedType = target.getType().resolve(Object.class);
/* 396 */     if (Map.class.isAssignableFrom(resolvedType)) {
/* 397 */       return new MapBinder(context);
/*     */     }
/* 399 */     if (Collection.class.isAssignableFrom(resolvedType)) {
/* 400 */       return new CollectionBinder(context);
/*     */     }
/* 402 */     if (target.getType().isArray()) {
/* 403 */       return new ArrayBinder(context);
/*     */     }
/* 405 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Object bindAggregate(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, AggregateBinder<?> aggregateBinder) {
/* 410 */     AggregateElementBinder elementBinder = (itemName, itemTarget, source) -> {
/*     */         boolean allowRecursiveBinding = aggregateBinder.isAllowRecursiveBinding(source);
/*     */         Supplier<?> supplier = ();
/*     */         return (AggregateElementBinder)context.withSource(source, (Supplier)supplier);
/*     */       };
/* 415 */     return context.withIncreasedDepth(() -> aggregateBinder.bind(name, target, elementBinder));
/*     */   }
/*     */   
/*     */   private ConfigurationProperty findProperty(ConfigurationPropertyName name, Context context) {
/* 419 */     if (name.isEmpty()) {
/* 420 */       return null;
/*     */     }
/* 422 */     for (ConfigurationPropertySource source : context.getSources()) {
/* 423 */       ConfigurationProperty property = source.getConfigurationProperty(name);
/* 424 */       if (property != null) {
/* 425 */         return property;
/*     */       }
/*     */     } 
/* 428 */     return null;
/*     */   }
/*     */   
/*     */   private <T> Object bindProperty(Bindable<T> target, Context context, ConfigurationProperty property) {
/* 432 */     context.setConfigurationProperty(property);
/* 433 */     Object result = property.getValue();
/* 434 */     result = this.placeholdersResolver.resolvePlaceholders(result);
/* 435 */     result = context.getConverter().convert(result, target);
/* 436 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object bindDataObject(ConfigurationPropertyName name, Bindable<?> target, BindHandler handler, Context context, boolean allowRecursiveBinding) {
/* 441 */     if (isUnbindableBean(name, target, context)) {
/* 442 */       return null;
/*     */     }
/* 444 */     Class<?> type = target.getType().resolve(Object.class);
/* 445 */     if (!allowRecursiveBinding && context.isBindingDataObject(type)) {
/* 446 */       return null;
/*     */     }
/* 448 */     DataObjectPropertyBinder propertyBinder = (propertyName, propertyTarget) -> bind(name.append(propertyName), propertyTarget, handler, context, false, false);
/*     */     
/* 450 */     return context.withDataObject(type, () -> {
/*     */           for (DataObjectBinder dataObjectBinder : this.dataObjectBinders) {
/*     */             Object instance = dataObjectBinder.bind(name, target, context, propertyBinder);
/*     */             if (instance != null) {
/*     */               return instance;
/*     */             }
/*     */           } 
/*     */           return null;
/*     */         });
/*     */   }
/*     */   
/*     */   private boolean isUnbindableBean(ConfigurationPropertyName name, Bindable<?> target, Context context) {
/* 462 */     for (ConfigurationPropertySource source : context.getSources()) {
/* 463 */       if (source.containsDescendantOf(name) == ConfigurationPropertyState.PRESENT)
/*     */       {
/* 465 */         return false;
/*     */       }
/*     */     } 
/* 468 */     Class<?> resolved = target.getType().resolve(Object.class);
/* 469 */     if (resolved.isPrimitive() || NON_BEAN_CLASSES.contains(resolved)) {
/* 470 */       return true;
/*     */     }
/* 472 */     return resolved.getName().startsWith("java.");
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean containsNoDescendantOf(Iterable<ConfigurationPropertySource> sources, ConfigurationPropertyName name) {
/* 477 */     for (ConfigurationPropertySource source : sources) {
/* 478 */       if (source.containsDescendantOf(name) != ConfigurationPropertyState.ABSENT) {
/* 479 */         return false;
/*     */       }
/*     */     } 
/* 482 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Binder get(Environment environment) {
/* 492 */     return get(environment, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Binder get(Environment environment, BindHandler defaultBindHandler) {
/* 505 */     Iterable<ConfigurationPropertySource> sources = ConfigurationPropertySources.get(environment);
/* 506 */     PropertySourcesPlaceholdersResolver placeholdersResolver = new PropertySourcesPlaceholdersResolver(environment);
/* 507 */     return new Binder(sources, placeholdersResolver, null, null, defaultBindHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final class Context
/*     */     implements BindContext
/*     */   {
/*     */     private final BindConverter converter;
/*     */     
/*     */     private int depth;
/*     */     
/* 519 */     private final List<ConfigurationPropertySource> source = Arrays.asList(new ConfigurationPropertySource[] { (ConfigurationPropertySource)null });
/*     */     
/*     */     private int sourcePushCount;
/*     */     
/* 523 */     private final Deque<Class<?>> dataObjectBindings = new ArrayDeque<>();
/*     */     
/* 525 */     private final Deque<Class<?>> constructorBindings = new ArrayDeque<>();
/*     */     
/*     */     private ConfigurationProperty configurationProperty;
/*     */     
/*     */     Context() {
/* 530 */       this.converter = BindConverter.get(Binder.this.conversionService, Binder.this.propertyEditorInitializer);
/*     */     }
/*     */     
/*     */     private void increaseDepth() {
/* 534 */       this.depth++;
/*     */     }
/*     */     
/*     */     private void decreaseDepth() {
/* 538 */       this.depth--;
/*     */     }
/*     */     
/*     */     private <T> T withSource(ConfigurationPropertySource source, Supplier<T> supplier) {
/* 542 */       if (source == null) {
/* 543 */         return supplier.get();
/*     */       }
/* 545 */       this.source.set(0, source);
/* 546 */       this.sourcePushCount++;
/*     */       try {
/* 548 */         return supplier.get();
/*     */       } finally {
/*     */         
/* 551 */         this.sourcePushCount--;
/*     */       } 
/*     */     }
/*     */     
/*     */     private <T> T withDataObject(Class<?> type, Supplier<T> supplier) {
/* 556 */       this.dataObjectBindings.push(type);
/*     */       try {
/* 558 */         return (T)withIncreasedDepth((Supplier)supplier);
/*     */       } finally {
/*     */         
/* 561 */         this.dataObjectBindings.pop();
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isBindingDataObject(Class<?> type) {
/* 566 */       return this.dataObjectBindings.contains(type);
/*     */     }
/*     */     
/*     */     private <T> T withIncreasedDepth(Supplier<T> supplier) {
/* 570 */       increaseDepth();
/*     */       try {
/* 572 */         return supplier.get();
/*     */       } finally {
/*     */         
/* 575 */         decreaseDepth();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void setConfigurationProperty(ConfigurationProperty configurationProperty) {
/* 580 */       this.configurationProperty = configurationProperty;
/*     */     }
/*     */     
/*     */     void clearConfigurationProperty() {
/* 584 */       this.configurationProperty = null;
/*     */     }
/*     */     
/*     */     void pushConstructorBoundTypes(Class<?> value) {
/* 588 */       this.constructorBindings.push(value);
/*     */     }
/*     */     
/*     */     boolean isNestedConstructorBinding() {
/* 592 */       return !this.constructorBindings.isEmpty();
/*     */     }
/*     */     
/*     */     void popConstructorBoundTypes() {
/* 596 */       this.constructorBindings.pop();
/*     */     }
/*     */     
/*     */     PlaceholdersResolver getPlaceholdersResolver() {
/* 600 */       return Binder.this.placeholdersResolver;
/*     */     }
/*     */     
/*     */     BindConverter getConverter() {
/* 604 */       return this.converter;
/*     */     }
/*     */ 
/*     */     
/*     */     public Binder getBinder() {
/* 609 */       return Binder.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getDepth() {
/* 614 */       return this.depth;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterable<ConfigurationPropertySource> getSources() {
/* 619 */       if (this.sourcePushCount > 0) {
/* 620 */         return this.source;
/*     */       }
/* 622 */       return Binder.this.sources;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurationProperty getConfigurationProperty() {
/* 627 */       return this.configurationProperty;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\Binder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
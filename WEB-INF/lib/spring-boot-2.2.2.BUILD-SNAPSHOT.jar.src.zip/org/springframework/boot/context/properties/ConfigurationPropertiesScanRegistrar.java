/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.boot.context.TypeExcludeFilter;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertiesScanRegistrar
/*     */   implements ImportBeanDefinitionRegistrar
/*     */ {
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   
/*     */   ConfigurationPropertiesScanRegistrar(Environment environment, ResourceLoader resourceLoader) {
/*  53 */     this.environment = environment;
/*  54 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/*  59 */     Set<String> packagesToScan = getPackagesToScan(importingClassMetadata);
/*  60 */     scan(registry, packagesToScan);
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getPackagesToScan(AnnotationMetadata metadata) {
/*  65 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(ConfigurationPropertiesScan.class.getName()));
/*  66 */     String[] basePackages = attributes.getStringArray("basePackages");
/*  67 */     Class<?>[] basePackageClasses = attributes.getClassArray("basePackageClasses");
/*  68 */     Set<String> packagesToScan = new LinkedHashSet<>(Arrays.asList(basePackages));
/*  69 */     for (Class<?> basePackageClass : basePackageClasses) {
/*  70 */       packagesToScan.add(ClassUtils.getPackageName(basePackageClass));
/*     */     }
/*  72 */     if (packagesToScan.isEmpty()) {
/*  73 */       packagesToScan.add(ClassUtils.getPackageName(metadata.getClassName()));
/*     */     }
/*  75 */     packagesToScan.removeIf(candidate -> !StringUtils.hasText(candidate));
/*  76 */     return packagesToScan;
/*     */   }
/*     */   
/*     */   private void scan(BeanDefinitionRegistry registry, Set<String> packages) {
/*  80 */     ConfigurationPropertiesBeanRegistrar registrar = new ConfigurationPropertiesBeanRegistrar(registry);
/*  81 */     ClassPathScanningCandidateComponentProvider scanner = getScanner(registry);
/*  82 */     for (String basePackage : packages) {
/*  83 */       for (BeanDefinition candidate : scanner.findCandidateComponents(basePackage)) {
/*  84 */         register(registrar, candidate.getBeanClassName());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private ClassPathScanningCandidateComponentProvider getScanner(BeanDefinitionRegistry registry) {
/*  90 */     ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
/*  91 */     scanner.setEnvironment(this.environment);
/*  92 */     scanner.setResourceLoader(this.resourceLoader);
/*  93 */     scanner.addIncludeFilter((TypeFilter)new AnnotationTypeFilter(ConfigurationProperties.class));
/*  94 */     TypeExcludeFilter typeExcludeFilter = new TypeExcludeFilter();
/*  95 */     typeExcludeFilter.setBeanFactory((BeanFactory)registry);
/*  96 */     scanner.addExcludeFilter((TypeFilter)typeExcludeFilter);
/*  97 */     return scanner;
/*     */   }
/*     */   
/*     */   private void register(ConfigurationPropertiesBeanRegistrar registrar, String className) throws LinkageError {
/*     */     try {
/* 102 */       register(registrar, ClassUtils.forName(className, null));
/*     */     }
/* 104 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void register(ConfigurationPropertiesBeanRegistrar registrar, Class<?> type) {
/* 110 */     if (!isComponent(type)) {
/* 111 */       registrar.register(type);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isComponent(Class<?> type) {
/* 116 */     return MergedAnnotations.from(type, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).isPresent(Component.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesScanRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
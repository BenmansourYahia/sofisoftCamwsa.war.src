/*     */ package org.springframework.boot.context.properties.bind.validation;
/*     */ 
/*     */ import java.util.Deque;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.BindContext;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.validation.AbstractBindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.Validator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationBindHandler
/*     */   extends AbstractBindHandler
/*     */ {
/*     */   private final Validator[] validators;
/*  48 */   private final Map<ConfigurationPropertyName, ResolvableType> boundTypes = new LinkedHashMap<>();
/*     */   
/*  50 */   private final Map<ConfigurationPropertyName, Object> boundResults = new LinkedHashMap<>();
/*     */   
/*  52 */   private final Set<ConfigurationProperty> boundProperties = new LinkedHashSet<>();
/*     */   
/*  54 */   private final Deque<BindValidationException> exceptions = new LinkedList<>();
/*     */   
/*     */   public ValidationBindHandler(Validator... validators) {
/*  57 */     this.validators = validators;
/*     */   }
/*     */   
/*     */   public ValidationBindHandler(BindHandler parent, Validator... validators) {
/*  61 */     super(parent);
/*  62 */     this.validators = validators;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Bindable<T> onStart(ConfigurationPropertyName name, Bindable<T> target, BindContext context) {
/*  67 */     this.boundTypes.put(name, target.getType());
/*  68 */     return super.onStart(name, target, context);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/*  73 */     this.boundResults.put(name, result);
/*  74 */     if (context.getConfigurationProperty() != null) {
/*  75 */       this.boundProperties.add(context.getConfigurationProperty());
/*     */     }
/*  77 */     return super.onSuccess(name, target, context, result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error) throws Exception {
/*  83 */     Object result = super.onFailure(name, target, context, error);
/*  84 */     if (result != null) {
/*  85 */       clear();
/*  86 */       this.boundResults.put(name, result);
/*     */     } 
/*  88 */     validate(name, target, context, result);
/*  89 */     return result;
/*     */   }
/*     */   
/*     */   private void clear() {
/*  93 */     this.boundTypes.clear();
/*  94 */     this.boundResults.clear();
/*  95 */     this.boundProperties.clear();
/*  96 */     this.exceptions.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onFinish(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) throws Exception {
/* 102 */     validate(name, target, context, result);
/* 103 */     super.onFinish(name, target, context, result);
/*     */   }
/*     */   
/*     */   private void validate(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/* 107 */     Object validationTarget = getValidationTarget(target, context, result);
/* 108 */     Class<?> validationType = target.getBoxedType().resolve();
/* 109 */     if (validationTarget != null) {
/* 110 */       validateAndPush(name, validationTarget, validationType);
/*     */     }
/* 112 */     if (context.getDepth() == 0 && !this.exceptions.isEmpty()) {
/* 113 */       throw (BindValidationException)this.exceptions.pop();
/*     */     }
/*     */   }
/*     */   
/*     */   private Object getValidationTarget(Bindable<?> target, BindContext context, Object result) {
/* 118 */     if (result != null) {
/* 119 */       return result;
/*     */     }
/* 121 */     if (context.getDepth() == 0 && target.getValue() != null) {
/* 122 */       return target.getValue().get();
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */   
/*     */   private void validateAndPush(ConfigurationPropertyName name, Object target, Class<?> type) {
/* 128 */     ValidationResult result = null;
/* 129 */     for (Validator validator : this.validators) {
/* 130 */       if (validator.supports(type)) {
/* 131 */         result = (result != null) ? result : new ValidationResult(name, target);
/* 132 */         validator.validate(target, (Errors)result);
/*     */       } 
/*     */     } 
/* 135 */     if (result != null && result.hasErrors()) {
/* 136 */       this.exceptions.push(new BindValidationException(result.getValidationErrors()));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ValidationResult
/*     */     extends AbstractBindingResult
/*     */   {
/*     */     private final ConfigurationPropertyName name;
/*     */     
/*     */     private Object target;
/*     */ 
/*     */     
/*     */     protected ValidationResult(ConfigurationPropertyName name, Object target) {
/* 150 */       super(null);
/* 151 */       this.name = name;
/* 152 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getObjectName() {
/* 157 */       return this.name.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getTarget() {
/* 162 */       return this.target;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getFieldType(String field) {
/*     */       try {
/* 168 */         ResolvableType type = (ResolvableType)ValidationBindHandler.this.boundTypes.get(getName(field));
/* 169 */         Class<?> resolved = (type != null) ? type.resolve() : null;
/* 170 */         if (resolved != null) {
/* 171 */           return resolved;
/*     */         }
/*     */       }
/* 174 */       catch (Exception exception) {}
/*     */       
/* 176 */       return super.getFieldType(field);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getActualFieldValue(String field) {
/*     */       try {
/* 182 */         return ValidationBindHandler.this.boundResults.get(getName(field));
/*     */       }
/* 184 */       catch (Exception exception) {
/*     */         
/* 186 */         return null;
/*     */       } 
/*     */     }
/*     */     private ConfigurationPropertyName getName(String field) {
/* 190 */       return this.name.append(field);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     ValidationErrors getValidationErrors() {
/* 196 */       Set<ConfigurationProperty> boundProperties = (Set<ConfigurationProperty>)ValidationBindHandler.this.boundProperties.stream().filter(property -> this.name.isAncestorOf(property.getName())).collect(Collectors.toCollection(LinkedHashSet::new));
/* 197 */       return new ValidationErrors(this.name, boundProperties, getAllErrors());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\validation\ValidationBindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationPropertiesBindingPostProcessor
/*     */   implements BeanPostProcessor, PriorityOrdered, ApplicationContextAware, InitializingBean
/*     */ {
/*  50 */   public static final String BEAN_NAME = ConfigurationPropertiesBindingPostProcessor.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final String VALIDATOR_BEAN_NAME = "configurationPropertiesValidator";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanDefinitionRegistry registry;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConfigurationPropertiesBinder binder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/*  78 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  85 */     this.registry = (BeanDefinitionRegistry)this.applicationContext.getAutowireCapableBeanFactory();
/*  86 */     this.binder = ConfigurationPropertiesBinder.get((BeanFactory)this.applicationContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  91 */     return -2147483647;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/*  96 */     bind(ConfigurationPropertiesBean.get(this.applicationContext, bean, beanName));
/*  97 */     return bean;
/*     */   }
/*     */   
/*     */   private void bind(ConfigurationPropertiesBean bean) {
/* 101 */     if (bean == null || hasBoundValueObject(bean.getName())) {
/*     */       return;
/*     */     }
/* 104 */     Assert.state((bean.getBindMethod() == ConfigurationPropertiesBean.BindMethod.JAVA_BEAN), "Cannot bind @ConfigurationProperties for bean '" + bean
/* 105 */         .getName() + "'. Ensure that @ConstructorBinding has not been applied to regular bean");
/*     */     try {
/* 107 */       this.binder.bind(bean);
/*     */     }
/* 109 */     catch (Exception ex) {
/* 110 */       throw new ConfigurationPropertiesBindException(bean, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasBoundValueObject(String beanName) {
/* 115 */     return (this.registry.containsBeanDefinition(beanName) && this.registry
/* 116 */       .getBeanDefinition(beanName) instanceof ConfigurationPropertiesValueObjectBeanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(BeanDefinitionRegistry registry) {
/* 126 */     Assert.notNull(registry, "Registry must not be null");
/* 127 */     if (!registry.containsBeanDefinition(BEAN_NAME)) {
/* 128 */       GenericBeanDefinition definition = new GenericBeanDefinition();
/* 129 */       definition.setBeanClass(ConfigurationPropertiesBindingPostProcessor.class);
/* 130 */       definition.setRole(2);
/* 131 */       registry.registerBeanDefinition(BEAN_NAME, (BeanDefinition)definition);
/*     */     } 
/* 133 */     ConfigurationPropertiesBinder.register(registry);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBindingPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
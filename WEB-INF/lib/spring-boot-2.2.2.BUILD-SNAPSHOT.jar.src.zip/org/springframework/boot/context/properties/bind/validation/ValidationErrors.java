/*     */ package org.springframework.boot.context.properties.bind.validation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.FieldError;
/*     */ import org.springframework.validation.ObjectError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationErrors
/*     */   implements Iterable<ObjectError>
/*     */ {
/*     */   private final ConfigurationPropertyName name;
/*     */   private final Set<ConfigurationProperty> boundProperties;
/*     */   private final List<ObjectError> errors;
/*     */   
/*     */   ValidationErrors(ConfigurationPropertyName name, Set<ConfigurationProperty> boundProperties, List<ObjectError> errors) {
/*  52 */     Assert.notNull(name, "Name must not be null");
/*  53 */     Assert.notNull(boundProperties, "BoundProperties must not be null");
/*  54 */     Assert.notNull(errors, "Errors must not be null");
/*  55 */     this.name = name;
/*  56 */     this.boundProperties = Collections.unmodifiableSet(boundProperties);
/*  57 */     this.errors = convertErrors(name, boundProperties, errors);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ObjectError> convertErrors(ConfigurationPropertyName name, Set<ConfigurationProperty> boundProperties, List<ObjectError> errors) {
/*  62 */     List<ObjectError> converted = new ArrayList<>(errors.size());
/*  63 */     for (ObjectError error : errors) {
/*  64 */       converted.add(convertError(name, boundProperties, error));
/*     */     }
/*  66 */     return Collections.unmodifiableList(converted);
/*     */   }
/*     */ 
/*     */   
/*     */   private ObjectError convertError(ConfigurationPropertyName name, Set<ConfigurationProperty> boundProperties, ObjectError error) {
/*  71 */     if (error instanceof FieldError) {
/*  72 */       return (ObjectError)convertFieldError(name, boundProperties, (FieldError)error);
/*     */     }
/*  74 */     return error;
/*     */   }
/*     */ 
/*     */   
/*     */   private FieldError convertFieldError(ConfigurationPropertyName name, Set<ConfigurationProperty> boundProperties, FieldError error) {
/*  79 */     if (error instanceof org.springframework.boot.origin.OriginProvider) {
/*  80 */       return error;
/*     */     }
/*  82 */     return OriginTrackedFieldError.of(error, findFieldErrorOrigin(name, boundProperties, error));
/*     */   }
/*     */ 
/*     */   
/*     */   private Origin findFieldErrorOrigin(ConfigurationPropertyName name, Set<ConfigurationProperty> boundProperties, FieldError error) {
/*  87 */     for (ConfigurationProperty boundProperty : boundProperties) {
/*  88 */       if (isForError(name, boundProperty.getName(), error)) {
/*  89 */         return Origin.from(boundProperty);
/*     */       }
/*     */     } 
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isForError(ConfigurationPropertyName name, ConfigurationPropertyName boundPropertyName, FieldError error) {
/*  97 */     return (name.isParentOf(boundPropertyName) && boundPropertyName
/*  98 */       .getLastElement(ConfigurationPropertyName.Form.UNIFORM).equalsIgnoreCase(error.getField()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyName getName() {
/* 106 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ConfigurationProperty> getBoundProperties() {
/* 114 */     return this.boundProperties;
/*     */   }
/*     */   
/*     */   public boolean hasErrors() {
/* 118 */     return !this.errors.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ObjectError> getAllErrors() {
/* 126 */     return this.errors;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ObjectError> iterator() {
/* 131 */     return this.errors.iterator();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\validation\ValidationErrors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
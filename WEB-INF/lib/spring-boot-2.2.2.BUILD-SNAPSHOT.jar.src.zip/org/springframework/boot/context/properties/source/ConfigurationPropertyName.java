/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationPropertyName
/*     */   implements Comparable<ConfigurationPropertyName>
/*     */ {
/*     */   private static final String EMPTY_STRING = "";
/*  59 */   public static final ConfigurationPropertyName EMPTY = new ConfigurationPropertyName(Elements.EMPTY);
/*     */   
/*     */   private Elements elements;
/*     */   
/*     */   private final CharSequence[] uniformElements;
/*     */   
/*     */   private String string;
/*     */   
/*     */   private ConfigurationPropertyName(Elements elements) {
/*  68 */     this.elements = elements;
/*  69 */     this.uniformElements = new CharSequence[elements.getSize()];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  77 */     return (this.elements.getSize() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLastElementIndexed() {
/*  85 */     int size = getNumberOfElements();
/*  86 */     return (size > 0 && isIndexed(size - 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isIndexed(int elementIndex) {
/*  95 */     return this.elements.getType(elementIndex).isIndexed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNumericIndex(int elementIndex) {
/* 104 */     return (this.elements.getType(elementIndex) == ElementType.NUMERICALLY_INDEXED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLastElement(Form form) {
/* 113 */     int size = getNumberOfElements();
/* 114 */     return (size != 0) ? getElement(size - 1, form) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getElement(int elementIndex, Form form) {
/* 124 */     CharSequence element = this.elements.get(elementIndex);
/* 125 */     ElementType type = this.elements.getType(elementIndex);
/* 126 */     if (type.isIndexed()) {
/* 127 */       return element.toString();
/*     */     }
/* 129 */     if (form == Form.ORIGINAL) {
/* 130 */       if (type != ElementType.NON_UNIFORM) {
/* 131 */         return element.toString();
/*     */       }
/* 133 */       return convertToOriginalForm(element).toString();
/*     */     } 
/* 135 */     if (form == Form.DASHED) {
/* 136 */       if (type == ElementType.UNIFORM || type == ElementType.DASHED) {
/* 137 */         return element.toString();
/*     */       }
/* 139 */       return convertToDashedElement(element).toString();
/*     */     } 
/* 141 */     CharSequence uniformElement = this.uniformElements[elementIndex];
/* 142 */     if (uniformElement == null) {
/* 143 */       uniformElement = (type != ElementType.UNIFORM) ? convertToUniformElement(element) : element;
/* 144 */       this.uniformElements[elementIndex] = uniformElement.toString();
/*     */     } 
/* 146 */     return uniformElement.toString();
/*     */   }
/*     */   
/*     */   private CharSequence convertToOriginalForm(CharSequence element) {
/* 150 */     return convertElement(element, false, (ch, i) -> 
/* 151 */         (ch == '_' || ElementsParser.isValidChar(Character.toLowerCase(ch), i)));
/*     */   }
/*     */   
/*     */   private CharSequence convertToDashedElement(CharSequence element) {
/* 155 */     return convertElement(element, true, ElementsParser::isValidChar);
/*     */   }
/*     */   
/*     */   private CharSequence convertToUniformElement(CharSequence element) {
/* 159 */     return convertElement(element, true, (ch, i) -> ElementsParser.isAlphaNumeric(ch));
/*     */   }
/*     */   
/*     */   private CharSequence convertElement(CharSequence element, boolean lowercase, ElementCharPredicate filter) {
/* 163 */     StringBuilder result = new StringBuilder(element.length());
/* 164 */     for (int i = 0; i < element.length(); i++) {
/* 165 */       char ch = lowercase ? Character.toLowerCase(element.charAt(i)) : element.charAt(i);
/* 166 */       if (filter.test(ch, i)) {
/* 167 */         result.append(ch);
/*     */       }
/*     */     } 
/* 170 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfElements() {
/* 178 */     return this.elements.getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyName append(String elements) {
/* 188 */     if (elements == null) {
/* 189 */       return this;
/*     */     }
/* 191 */     Elements additionalElements = probablySingleElementOf(elements);
/* 192 */     return new ConfigurationPropertyName(this.elements.append(additionalElements));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyName chop(int size) {
/* 203 */     if (size >= getNumberOfElements()) {
/* 204 */       return this;
/*     */     }
/* 206 */     return new ConfigurationPropertyName(this.elements.chop(size));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParentOf(ConfigurationPropertyName name) {
/* 215 */     Assert.notNull(name, "Name must not be null");
/* 216 */     if (getNumberOfElements() != name.getNumberOfElements() - 1) {
/* 217 */       return false;
/*     */     }
/* 219 */     return isAncestorOf(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAncestorOf(ConfigurationPropertyName name) {
/* 229 */     Assert.notNull(name, "Name must not be null");
/* 230 */     if (getNumberOfElements() >= name.getNumberOfElements()) {
/* 231 */       return false;
/*     */     }
/* 233 */     return elementsEqual(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ConfigurationPropertyName other) {
/* 238 */     return compare(this, other);
/*     */   }
/*     */   
/*     */   private int compare(ConfigurationPropertyName n1, ConfigurationPropertyName n2) {
/* 242 */     int l1 = n1.getNumberOfElements();
/* 243 */     int l2 = n2.getNumberOfElements();
/* 244 */     int i1 = 0;
/* 245 */     int i2 = 0;
/* 246 */     while (i1 < l1 || i2 < l2) {
/*     */       try {
/* 248 */         ElementType type1 = (i1 < l1) ? n1.elements.getType(i1) : null;
/* 249 */         ElementType type2 = (i2 < l2) ? n2.elements.getType(i2) : null;
/* 250 */         String e1 = (i1 < l1) ? n1.getElement(i1++, Form.UNIFORM) : null;
/* 251 */         String e2 = (i2 < l2) ? n2.getElement(i2++, Form.UNIFORM) : null;
/* 252 */         int result = compare(e1, type1, e2, type2);
/* 253 */         if (result != 0) {
/* 254 */           return result;
/*     */         }
/*     */       }
/* 257 */       catch (ArrayIndexOutOfBoundsException ex) {
/* 258 */         throw new RuntimeException(ex);
/*     */       } 
/*     */     } 
/* 261 */     return 0;
/*     */   }
/*     */   
/*     */   private int compare(String e1, ElementType type1, String e2, ElementType type2) {
/* 265 */     if (e1 == null) {
/* 266 */       return -1;
/*     */     }
/* 268 */     if (e2 == null) {
/* 269 */       return 1;
/*     */     }
/* 271 */     int result = Boolean.compare(type2.isIndexed(), type1.isIndexed());
/* 272 */     if (result != 0) {
/* 273 */       return result;
/*     */     }
/* 275 */     if (type1 == ElementType.NUMERICALLY_INDEXED && type2 == ElementType.NUMERICALLY_INDEXED) {
/* 276 */       long v1 = Long.parseLong(e1);
/* 277 */       long v2 = Long.parseLong(e2);
/* 278 */       return Long.compare(v1, v2);
/*     */     } 
/* 280 */     return e1.compareTo(e2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 285 */     if (obj == this) {
/* 286 */       return true;
/*     */     }
/* 288 */     if (obj == null || obj.getClass() != getClass()) {
/* 289 */       return false;
/*     */     }
/* 291 */     ConfigurationPropertyName other = (ConfigurationPropertyName)obj;
/* 292 */     if (getNumberOfElements() != other.getNumberOfElements()) {
/* 293 */       return false;
/*     */     }
/* 295 */     if (this.elements.canShortcutWithSource(ElementType.UNIFORM) && other.elements
/* 296 */       .canShortcutWithSource(ElementType.UNIFORM)) {
/* 297 */       return toString().equals(other.toString());
/*     */     }
/* 299 */     return elementsEqual(other);
/*     */   }
/*     */   
/*     */   private boolean elementsEqual(ConfigurationPropertyName name) {
/* 303 */     for (int i = this.elements.getSize() - 1; i >= 0; i--) {
/* 304 */       if (elementDiffers(this.elements, name.elements, i)) {
/* 305 */         return false;
/*     */       }
/*     */     } 
/* 308 */     return true;
/*     */   }
/*     */   
/*     */   private boolean elementDiffers(Elements e1, Elements e2, int i) {
/* 312 */     ElementType type1 = e1.getType(i);
/* 313 */     ElementType type2 = e2.getType(i);
/* 314 */     if (type1.allowsFastEqualityCheck() && type2.allowsFastEqualityCheck()) {
/* 315 */       return !fastElementEquals(e1, e2, i);
/*     */     }
/* 317 */     if (type1.allowsDashIgnoringEqualityCheck() && type2.allowsDashIgnoringEqualityCheck()) {
/* 318 */       return !dashIgnoringElementEquals(e1, e2, i);
/*     */     }
/*     */     
/* 321 */     return !defaultElementEquals(e1, e2, i);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean defaultElementEquals(Elements e1, Elements e2, int i) {
/* 326 */     int l1 = e1.getLength(i);
/* 327 */     int l2 = e2.getLength(i);
/* 328 */     boolean indexed1 = e1.getType(i).isIndexed();
/* 329 */     boolean indexed2 = e2.getType(i).isIndexed();
/* 330 */     int i1 = 0;
/* 331 */     int i2 = 0;
/* 332 */     while (i1 < l1) {
/* 333 */       if (i2 >= l2) {
/* 334 */         return false;
/*     */       }
/* 336 */       char ch1 = indexed1 ? e1.charAt(i, i1) : Character.toLowerCase(e1.charAt(i, i1));
/* 337 */       char ch2 = indexed2 ? e2.charAt(i, i2) : Character.toLowerCase(e2.charAt(i, i2));
/* 338 */       if (!indexed1 && !ElementsParser.isAlphaNumeric(ch1)) {
/* 339 */         i1++; continue;
/*     */       } 
/* 341 */       if (!indexed2 && !ElementsParser.isAlphaNumeric(ch2)) {
/* 342 */         i2++; continue;
/*     */       } 
/* 344 */       if (ch1 != ch2) {
/* 345 */         return false;
/*     */       }
/*     */       
/* 348 */       i1++;
/* 349 */       i2++;
/*     */     } 
/*     */     
/* 352 */     if (i2 < l2) {
/* 353 */       if (indexed2) {
/* 354 */         return false;
/*     */       }
/*     */       do {
/* 357 */         char ch2 = Character.toLowerCase(e2.charAt(i, i2++));
/* 358 */         if (ElementsParser.isAlphaNumeric(ch2)) {
/* 359 */           return false;
/*     */         }
/*     */       }
/* 362 */       while (i2 < l2);
/*     */     } 
/* 364 */     return true;
/*     */   }
/*     */   
/*     */   private boolean dashIgnoringElementEquals(Elements e1, Elements e2, int i) {
/* 368 */     int l1 = e1.getLength(i);
/* 369 */     int l2 = e2.getLength(i);
/* 370 */     int i1 = 0;
/* 371 */     int i2 = 0;
/* 372 */     while (i1 < l1) {
/* 373 */       if (i2 >= l2) {
/* 374 */         return false;
/*     */       }
/* 376 */       char ch1 = e1.charAt(i, i1);
/* 377 */       char ch2 = e2.charAt(i, i2);
/* 378 */       if (ch1 == '-') {
/* 379 */         i1++; continue;
/*     */       } 
/* 381 */       if (ch2 == '-') {
/* 382 */         i2++; continue;
/*     */       } 
/* 384 */       if (ch1 != ch2) {
/* 385 */         return false;
/*     */       }
/*     */       
/* 388 */       i1++;
/* 389 */       i2++;
/*     */     } 
/*     */     
/* 392 */     if (i2 < l2) {
/* 393 */       if (e2.getType(i).isIndexed()) {
/* 394 */         return false;
/*     */       }
/*     */       do {
/* 397 */         char ch2 = e2.charAt(i, i2++);
/* 398 */         if (ch2 != '-') {
/* 399 */           return false;
/*     */         }
/*     */       }
/* 402 */       while (i2 < l2);
/*     */     } 
/* 404 */     return true;
/*     */   }
/*     */   
/*     */   private boolean fastElementEquals(Elements e1, Elements e2, int i) {
/* 408 */     int length1 = e1.getLength(i);
/* 409 */     int length2 = e2.getLength(i);
/* 410 */     if (length1 == length2) {
/* 411 */       int i1 = 0;
/* 412 */       while (length1-- != 0) {
/* 413 */         char ch1 = e1.charAt(i, i1);
/* 414 */         char ch2 = e2.charAt(i, i1);
/* 415 */         if (ch1 != ch2) {
/* 416 */           return false;
/*     */         }
/* 418 */         i1++;
/*     */       } 
/* 420 */       return true;
/*     */     } 
/* 422 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 427 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 432 */     if (this.string == null) {
/* 433 */       this.string = buildToString();
/*     */     }
/* 435 */     return this.string;
/*     */   }
/*     */   
/*     */   private String buildToString() {
/* 439 */     if (this.elements.canShortcutWithSource(ElementType.UNIFORM, ElementType.DASHED)) {
/* 440 */       return this.elements.getSource().toString();
/*     */     }
/* 442 */     int elements = getNumberOfElements();
/* 443 */     StringBuilder result = new StringBuilder(elements * 8);
/* 444 */     for (int i = 0; i < elements; i++) {
/* 445 */       boolean indexed = isIndexed(i);
/* 446 */       if (result.length() > 0 && !indexed) {
/* 447 */         result.append('.');
/*     */       }
/* 449 */       if (indexed) {
/* 450 */         result.append('[');
/* 451 */         result.append(getElement(i, Form.ORIGINAL));
/* 452 */         result.append(']');
/*     */       } else {
/*     */         
/* 455 */         result.append(getElement(i, Form.DASHED));
/*     */       } 
/*     */     } 
/* 458 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValid(CharSequence name) {
/* 468 */     return (of(name, true) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConfigurationPropertyName of(CharSequence name) {
/* 478 */     return of(name, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigurationPropertyName of(CharSequence name, boolean returnNullIfInvalid) {
/* 490 */     Elements elements = elementsOf(name, returnNullIfInvalid);
/* 491 */     return (elements != null) ? new ConfigurationPropertyName(elements) : null;
/*     */   }
/*     */   
/*     */   private static Elements probablySingleElementOf(CharSequence name) {
/* 495 */     return elementsOf(name, false, 1);
/*     */   }
/*     */   
/*     */   private static Elements elementsOf(CharSequence name, boolean returnNullIfInvalid) {
/* 499 */     return elementsOf(name, returnNullIfInvalid, 6);
/*     */   }
/*     */   
/*     */   private static Elements elementsOf(CharSequence name, boolean returnNullIfInvalid, int parserCapacity) {
/* 503 */     if (name == null) {
/* 504 */       Assert.isTrue(returnNullIfInvalid, "Name must not be null");
/* 505 */       return null;
/*     */     } 
/* 507 */     if (name.length() == 0) {
/* 508 */       return Elements.EMPTY;
/*     */     }
/* 510 */     if (name.charAt(0) == '.' || name.charAt(name.length() - 1) == '.') {
/* 511 */       if (returnNullIfInvalid) {
/* 512 */         return null;
/*     */       }
/* 514 */       throw new InvalidConfigurationPropertyNameException(name, Collections.singletonList(Character.valueOf('.')));
/*     */     } 
/* 516 */     Elements elements = (new ElementsParser(name, '.', parserCapacity)).parse();
/* 517 */     for (int i = 0; i < elements.getSize(); i++) {
/* 518 */       if (elements.getType(i) == ElementType.NON_UNIFORM) {
/* 519 */         if (returnNullIfInvalid) {
/* 520 */           return null;
/*     */         }
/* 522 */         throw new InvalidConfigurationPropertyNameException(name, getInvalidChars(elements, i));
/*     */       } 
/*     */     } 
/* 525 */     return elements;
/*     */   }
/*     */   
/*     */   private static List<Character> getInvalidChars(Elements elements, int index) {
/* 529 */     List<Character> invalidChars = new ArrayList<>();
/* 530 */     for (int charIndex = 0; charIndex < elements.getLength(index); charIndex++) {
/* 531 */       char ch = elements.charAt(index, charIndex);
/* 532 */       if (!ElementsParser.isValidChar(ch, charIndex)) {
/* 533 */         invalidChars.add(Character.valueOf(ch));
/*     */       }
/*     */     } 
/* 536 */     return invalidChars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigurationPropertyName adapt(CharSequence name, char separator) {
/* 547 */     return adapt(name, separator, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigurationPropertyName adapt(CharSequence name, char separator, Function<CharSequence, CharSequence> elementValueProcessor) {
/* 565 */     Assert.notNull(name, "Name must not be null");
/* 566 */     if (name.length() == 0) {
/* 567 */       return EMPTY;
/*     */     }
/* 569 */     Elements elements = (new ElementsParser(name, separator)).parse(elementValueProcessor);
/* 570 */     if (elements.getSize() == 0) {
/* 571 */       return EMPTY;
/*     */     }
/* 573 */     return new ConfigurationPropertyName(elements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Form
/*     */   {
/* 591 */     ORIGINAL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 603 */     DASHED,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 615 */     UNIFORM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Elements
/*     */   {
/* 625 */     private static final int[] NO_POSITION = new int[0];
/*     */     
/* 627 */     private static final ConfigurationPropertyName.ElementType[] NO_TYPE = new ConfigurationPropertyName.ElementType[0];
/*     */     
/* 629 */     public static final Elements EMPTY = new Elements("", 0, NO_POSITION, NO_POSITION, NO_TYPE, null);
/*     */ 
/*     */ 
/*     */     
/*     */     private final CharSequence source;
/*     */ 
/*     */     
/*     */     private final int size;
/*     */ 
/*     */     
/*     */     private final int[] start;
/*     */ 
/*     */     
/*     */     private final int[] end;
/*     */ 
/*     */     
/*     */     private final ConfigurationPropertyName.ElementType[] type;
/*     */ 
/*     */     
/*     */     private final CharSequence[] resolved;
/*     */ 
/*     */ 
/*     */     
/*     */     Elements(CharSequence source, int size, int[] start, int[] end, ConfigurationPropertyName.ElementType[] type, CharSequence[] resolved) {
/* 653 */       this.source = source;
/* 654 */       this.size = size;
/* 655 */       this.start = start;
/* 656 */       this.end = end;
/* 657 */       this.type = type;
/* 658 */       this.resolved = resolved;
/*     */     }
/*     */     
/*     */     Elements append(Elements additional) {
/* 662 */       int size = this.size + additional.size;
/* 663 */       ConfigurationPropertyName.ElementType[] type = new ConfigurationPropertyName.ElementType[size];
/* 664 */       System.arraycopy(this.type, 0, type, 0, this.size);
/* 665 */       System.arraycopy(additional.type, 0, type, this.size, additional.size);
/* 666 */       CharSequence[] resolved = newResolved(size);
/* 667 */       for (int i = 0; i < additional.size; i++) {
/* 668 */         resolved[this.size + i] = additional.get(i);
/*     */       }
/* 670 */       return new Elements(this.source, size, this.start, this.end, type, resolved);
/*     */     }
/*     */     
/*     */     Elements chop(int size) {
/* 674 */       CharSequence[] resolved = newResolved(size);
/* 675 */       return new Elements(this.source, size, this.start, this.end, this.type, resolved);
/*     */     }
/*     */     
/*     */     private CharSequence[] newResolved(int size) {
/* 679 */       CharSequence[] resolved = new CharSequence[size];
/* 680 */       if (this.resolved != null) {
/* 681 */         System.arraycopy(this.resolved, 0, resolved, 0, Math.min(size, this.size));
/*     */       }
/* 683 */       return resolved;
/*     */     }
/*     */     
/*     */     int getSize() {
/* 687 */       return this.size;
/*     */     }
/*     */     
/*     */     CharSequence get(int index) {
/* 691 */       if (this.resolved != null && this.resolved[index] != null) {
/* 692 */         return this.resolved[index];
/*     */       }
/* 694 */       int start = this.start[index];
/* 695 */       int end = this.end[index];
/* 696 */       return this.source.subSequence(start, end);
/*     */     }
/*     */     
/*     */     int getLength(int index) {
/* 700 */       if (this.resolved != null && this.resolved[index] != null) {
/* 701 */         return this.resolved[index].length();
/*     */       }
/* 703 */       int start = this.start[index];
/* 704 */       int end = this.end[index];
/* 705 */       return end - start;
/*     */     }
/*     */     
/*     */     char charAt(int index, int charIndex) {
/* 709 */       if (this.resolved != null && this.resolved[index] != null) {
/* 710 */         return this.resolved[index].charAt(charIndex);
/*     */       }
/* 712 */       int start = this.start[index];
/* 713 */       return this.source.charAt(start + charIndex);
/*     */     }
/*     */     
/*     */     ConfigurationPropertyName.ElementType getType(int index) {
/* 717 */       return this.type[index];
/*     */     }
/*     */     
/*     */     CharSequence getSource() {
/* 721 */       return this.source;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean canShortcutWithSource(ConfigurationPropertyName.ElementType requiredType) {
/* 731 */       return canShortcutWithSource(requiredType, requiredType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean canShortcutWithSource(ConfigurationPropertyName.ElementType requiredType, ConfigurationPropertyName.ElementType alternativeType) {
/* 742 */       if (this.resolved != null) {
/* 743 */         return false;
/*     */       }
/* 745 */       for (int i = 0; i < this.size; i++) {
/* 746 */         ConfigurationPropertyName.ElementType type = this.type[i];
/* 747 */         if (type != requiredType && type != alternativeType) {
/* 748 */           return false;
/*     */         }
/* 750 */         if (i > 0 && this.end[i - 1] + 1 != this.start[i]) {
/* 751 */           return false;
/*     */         }
/*     */       } 
/* 754 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ElementsParser
/*     */   {
/*     */     private static final int DEFAULT_CAPACITY = 6;
/*     */ 
/*     */     
/*     */     private final CharSequence source;
/*     */     
/*     */     private final char separator;
/*     */     
/*     */     private int size;
/*     */     
/*     */     private int[] start;
/*     */     
/*     */     private int[] end;
/*     */     
/*     */     private ConfigurationPropertyName.ElementType[] type;
/*     */     
/*     */     private CharSequence[] resolved;
/*     */ 
/*     */     
/*     */     ElementsParser(CharSequence source, char separator) {
/* 781 */       this(source, separator, 6);
/*     */     }
/*     */     
/*     */     ElementsParser(CharSequence source, char separator, int capacity) {
/* 785 */       this.source = source;
/* 786 */       this.separator = separator;
/* 787 */       this.start = new int[capacity];
/* 788 */       this.end = new int[capacity];
/* 789 */       this.type = new ConfigurationPropertyName.ElementType[capacity];
/*     */     }
/*     */     
/*     */     ConfigurationPropertyName.Elements parse() {
/* 793 */       return parse(null);
/*     */     }
/*     */     
/*     */     ConfigurationPropertyName.Elements parse(Function<CharSequence, CharSequence> valueProcessor) {
/* 797 */       int length = this.source.length();
/* 798 */       int openBracketCount = 0;
/* 799 */       int start = 0;
/* 800 */       ConfigurationPropertyName.ElementType type = ConfigurationPropertyName.ElementType.EMPTY;
/* 801 */       for (int i = 0; i < length; i++) {
/* 802 */         char ch = this.source.charAt(i);
/* 803 */         if (ch == '[') {
/* 804 */           if (openBracketCount == 0) {
/* 805 */             add(start, i, type, valueProcessor);
/* 806 */             start = i + 1;
/* 807 */             type = ConfigurationPropertyName.ElementType.NUMERICALLY_INDEXED;
/*     */           } 
/* 809 */           openBracketCount++;
/*     */         }
/* 811 */         else if (ch == ']') {
/* 812 */           openBracketCount--;
/* 813 */           if (openBracketCount == 0) {
/* 814 */             add(start, i, type, valueProcessor);
/* 815 */             start = i + 1;
/* 816 */             type = ConfigurationPropertyName.ElementType.EMPTY;
/*     */           }
/*     */         
/* 819 */         } else if (!type.isIndexed() && ch == this.separator) {
/* 820 */           add(start, i, type, valueProcessor);
/* 821 */           start = i + 1;
/* 822 */           type = ConfigurationPropertyName.ElementType.EMPTY;
/*     */         } else {
/*     */           
/* 825 */           type = updateType(type, ch, i - start);
/*     */         } 
/*     */       } 
/* 828 */       if (openBracketCount != 0) {
/* 829 */         type = ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*     */       }
/* 831 */       add(start, length, type, valueProcessor);
/* 832 */       return new ConfigurationPropertyName.Elements(this.source, this.size, this.start, this.end, this.type, this.resolved);
/*     */     }
/*     */     
/*     */     private ConfigurationPropertyName.ElementType updateType(ConfigurationPropertyName.ElementType existingType, char ch, int index) {
/* 836 */       if (existingType.isIndexed()) {
/* 837 */         if (existingType == ConfigurationPropertyName.ElementType.NUMERICALLY_INDEXED && !isNumeric(ch)) {
/* 838 */           return ConfigurationPropertyName.ElementType.INDEXED;
/*     */         }
/* 840 */         return existingType;
/*     */       } 
/* 842 */       if (existingType == ConfigurationPropertyName.ElementType.EMPTY && isValidChar(ch, index)) {
/* 843 */         return (index == 0) ? ConfigurationPropertyName.ElementType.UNIFORM : ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*     */       }
/* 845 */       if (existingType == ConfigurationPropertyName.ElementType.UNIFORM && ch == '-') {
/* 846 */         return ConfigurationPropertyName.ElementType.DASHED;
/*     */       }
/* 848 */       if (!isValidChar(ch, index)) {
/* 849 */         if (existingType == ConfigurationPropertyName.ElementType.EMPTY && !isValidChar(Character.toLowerCase(ch), index)) {
/* 850 */           return ConfigurationPropertyName.ElementType.EMPTY;
/*     */         }
/* 852 */         return ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*     */       } 
/* 854 */       return existingType;
/*     */     }
/*     */     
/*     */     private void add(int start, int end, ConfigurationPropertyName.ElementType type, Function<CharSequence, CharSequence> valueProcessor) {
/* 858 */       if (end - start < 1 || type == ConfigurationPropertyName.ElementType.EMPTY) {
/*     */         return;
/*     */       }
/* 861 */       if (this.start.length == this.size) {
/* 862 */         this.start = expand(this.start);
/* 863 */         this.end = expand(this.end);
/* 864 */         this.type = expand(this.type);
/* 865 */         this.resolved = expand(this.resolved);
/*     */       } 
/* 867 */       if (valueProcessor != null) {
/* 868 */         if (this.resolved == null) {
/* 869 */           this.resolved = new CharSequence[this.start.length];
/*     */         }
/* 871 */         CharSequence resolved = valueProcessor.apply(this.source.subSequence(start, end));
/* 872 */         ConfigurationPropertyName.Elements resolvedElements = (new ElementsParser(resolved, '.')).parse();
/* 873 */         Assert.state((resolvedElements.getSize() == 1), "Resolved element must not contain multiple elements");
/* 874 */         this.resolved[this.size] = resolvedElements.get(0);
/* 875 */         type = resolvedElements.getType(0);
/*     */       } 
/* 877 */       this.start[this.size] = start;
/* 878 */       this.end[this.size] = end;
/* 879 */       this.type[this.size] = type;
/* 880 */       this.size++;
/*     */     }
/*     */     
/*     */     private int[] expand(int[] src) {
/* 884 */       int[] dest = new int[src.length + 6];
/* 885 */       System.arraycopy(src, 0, dest, 0, src.length);
/* 886 */       return dest;
/*     */     }
/*     */     
/*     */     private ConfigurationPropertyName.ElementType[] expand(ConfigurationPropertyName.ElementType[] src) {
/* 890 */       ConfigurationPropertyName.ElementType[] dest = new ConfigurationPropertyName.ElementType[src.length + 6];
/* 891 */       System.arraycopy(src, 0, dest, 0, src.length);
/* 892 */       return dest;
/*     */     }
/*     */     
/*     */     private CharSequence[] expand(CharSequence[] src) {
/* 896 */       if (src == null) {
/* 897 */         return null;
/*     */       }
/* 899 */       CharSequence[] dest = new CharSequence[src.length + 6];
/* 900 */       System.arraycopy(src, 0, dest, 0, src.length);
/* 901 */       return dest;
/*     */     }
/*     */     
/*     */     static boolean isValidChar(char ch, int index) {
/* 905 */       return (isAlpha(ch) || isNumeric(ch) || (index != 0 && ch == '-'));
/*     */     }
/*     */     
/*     */     static boolean isAlphaNumeric(char ch) {
/* 909 */       return (isAlpha(ch) || isNumeric(ch));
/*     */     }
/*     */     
/*     */     private static boolean isAlpha(char ch) {
/* 913 */       return (ch >= 'a' && ch <= 'z');
/*     */     }
/*     */     
/*     */     private static boolean isNumeric(char ch) {
/* 917 */       return (ch >= '0' && ch <= '9');
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum ElementType
/*     */   {
/* 930 */     EMPTY(false),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 935 */     UNIFORM(false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 941 */     DASHED(false),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 946 */     NON_UNIFORM(false),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 951 */     INDEXED(true),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 956 */     NUMERICALLY_INDEXED(true);
/*     */     
/*     */     private final boolean indexed;
/*     */     
/*     */     ElementType(boolean indexed) {
/* 961 */       this.indexed = indexed;
/*     */     }
/*     */     
/*     */     public boolean isIndexed() {
/* 965 */       return this.indexed;
/*     */     }
/*     */     
/*     */     public boolean allowsFastEqualityCheck() {
/* 969 */       return (this == UNIFORM || this == NUMERICALLY_INDEXED);
/*     */     }
/*     */     
/*     */     public boolean allowsDashIgnoringEqualityCheck() {
/* 973 */       return (allowsFastEqualityCheck() || this == DASHED);
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface ElementCharPredicate {
/*     */     boolean test(char param1Char, int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
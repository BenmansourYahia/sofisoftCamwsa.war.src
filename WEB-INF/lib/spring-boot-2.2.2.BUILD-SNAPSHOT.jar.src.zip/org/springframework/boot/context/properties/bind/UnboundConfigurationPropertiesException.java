/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnboundConfigurationPropertiesException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final Set<ConfigurationProperty> unboundProperties;
/*    */   
/*    */   public UnboundConfigurationPropertiesException(Set<ConfigurationProperty> unboundProperties) {
/* 39 */     super(buildMessage(unboundProperties));
/* 40 */     this.unboundProperties = Collections.unmodifiableSet(unboundProperties);
/*    */   }
/*    */   
/*    */   public Set<ConfigurationProperty> getUnboundProperties() {
/* 44 */     return this.unboundProperties;
/*    */   }
/*    */   
/*    */   private static String buildMessage(Set<ConfigurationProperty> unboundProperties) {
/* 48 */     StringBuilder builder = new StringBuilder();
/* 49 */     builder.append("The elements [");
/* 50 */     String message = unboundProperties.stream().map(p -> p.getName().toString()).collect(Collectors.joining(","));
/* 51 */     builder.append(message).append("] were left unbound.");
/* 52 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\UnboundConfigurationPropertiesException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
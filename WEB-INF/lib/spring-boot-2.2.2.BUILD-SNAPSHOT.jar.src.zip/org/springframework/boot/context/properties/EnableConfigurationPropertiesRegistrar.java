/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.annotation.MergedAnnotation;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EnableConfigurationPropertiesRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/*    */   public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
/* 38 */     registerInfrastructureBeans(registry);
/* 39 */     ConfigurationPropertiesBeanRegistrar beanRegistrar = new ConfigurationPropertiesBeanRegistrar(registry);
/* 40 */     getTypes(metadata).forEach(beanRegistrar::register);
/*    */   }
/*    */   
/*    */   private Set<Class<?>> getTypes(AnnotationMetadata metadata) {
/* 44 */     return (Set<Class<?>>)metadata.getAnnotations().stream(EnableConfigurationProperties.class)
/* 45 */       .flatMap(annotation -> Arrays.stream((Class<?>[][])annotation.getClassArray("value")))
/* 46 */       .filter(type -> (void.class != type)).collect(Collectors.toSet());
/*    */   }
/*    */ 
/*    */   
/*    */   static void registerInfrastructureBeans(BeanDefinitionRegistry registry) {
/* 51 */     ConfigurationPropertiesBindingPostProcessor.register(registry);
/* 52 */     ConfigurationPropertiesBeanDefinitionValidator.register(registry);
/* 53 */     ConfigurationBeanFactoryMetadata.register(registry);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\EnableConfigurationPropertiesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
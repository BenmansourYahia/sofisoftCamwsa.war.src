/*    */ package org.springframework.boot.context.properties.bind.handler;
/*    */ 
/*    */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.BindHandler;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IgnoreErrorsBindHandler
/*    */   extends AbstractBindHandler
/*    */ {
/*    */   public IgnoreErrorsBindHandler() {}
/*    */   
/*    */   public IgnoreErrorsBindHandler(BindHandler parent) {
/* 38 */     super(parent);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error) throws Exception {
/* 44 */     return (target.getValue() != null) ? target.getValue().get() : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\bind\handler\IgnoreErrorsBindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
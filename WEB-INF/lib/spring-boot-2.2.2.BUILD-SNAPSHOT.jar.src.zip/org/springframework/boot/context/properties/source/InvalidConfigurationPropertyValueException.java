/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidConfigurationPropertyValueException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String name;
/*    */   private final Object value;
/*    */   private final String reason;
/*    */   
/*    */   public InvalidConfigurationPropertyValueException(String name, Object value, String reason) {
/* 46 */     super("Property " + name + " with value '" + value + "' is invalid: " + reason);
/* 47 */     Assert.notNull(name, "Name must not be null");
/* 48 */     this.name = name;
/* 49 */     this.value = value;
/* 50 */     this.reason = reason;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 58 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 66 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getReason() {
/* 74 */     return this.reason;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\context\properties\source\InvalidConfigurationPropertyValueException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
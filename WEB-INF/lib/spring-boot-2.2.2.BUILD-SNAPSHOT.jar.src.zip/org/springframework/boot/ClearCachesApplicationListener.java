/*    */ package org.springframework.boot;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.event.ContextRefreshedEvent;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClearCachesApplicationListener
/*    */   implements ApplicationListener<ContextRefreshedEvent>
/*    */ {
/*    */   public void onApplicationEvent(ContextRefreshedEvent event) {
/* 34 */     ReflectionUtils.clearCache();
/* 35 */     clearClassLoaderCaches(Thread.currentThread().getContextClassLoader());
/*    */   }
/*    */   
/*    */   private void clearClassLoaderCaches(ClassLoader classLoader) {
/* 39 */     if (classLoader == null) {
/*    */       return;
/*    */     }
/*    */     try {
/* 43 */       Method clearCacheMethod = classLoader.getClass().getDeclaredMethod("clearCache", new Class[0]);
/* 44 */       clearCacheMethod.invoke(classLoader, new Object[0]);
/*    */     }
/* 46 */     catch (Exception exception) {}
/*    */ 
/*    */     
/* 49 */     clearClassLoaderCaches(classLoader.getParent());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\ClearCachesApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
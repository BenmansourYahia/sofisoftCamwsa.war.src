/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogFile
/*     */ {
/*     */   @Deprecated
/*     */   public static final String FILE_PROPERTY = "logging.file";
/*     */   @Deprecated
/*     */   public static final String PATH_PROPERTY = "logging.path";
/*     */   public static final String FILE_NAME_PROPERTY = "logging.file.name";
/*     */   public static final String FILE_PATH_PROPERTY = "logging.file.path";
/*     */   private final String file;
/*     */   private final String path;
/*     */   
/*     */   LogFile(String file) {
/*  79 */     this(file, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LogFile(String file, String path) {
/*  88 */     Assert.isTrue((StringUtils.hasLength(file) || StringUtils.hasLength(path)), "File or Path must not be empty");
/*  89 */     this.file = file;
/*  90 */     this.path = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyToSystemProperties() {
/*  97 */     applyTo(System.getProperties());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(Properties properties) {
/* 105 */     put(properties, "LOG_PATH", this.path);
/* 106 */     put(properties, "LOG_FILE", toString());
/*     */   }
/*     */   
/*     */   private void put(Properties properties, String key, String value) {
/* 110 */     if (StringUtils.hasLength(value)) {
/* 111 */       properties.put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     if (StringUtils.hasLength(this.file)) {
/* 118 */       return this.file;
/*     */     }
/* 120 */     return (new File(this.path, "spring.log")).getPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LogFile get(PropertyResolver propertyResolver) {
/* 131 */     String file = getLogFileProperty(propertyResolver, "logging.file.name", "logging.file");
/* 132 */     String path = getLogFileProperty(propertyResolver, "logging.file.path", "logging.path");
/* 133 */     if (StringUtils.hasLength(file) || StringUtils.hasLength(path)) {
/* 134 */       return new LogFile(file, path);
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getLogFileProperty(PropertyResolver propertyResolver, String propertyName, String deprecatedPropertyName) {
/* 141 */     String property = propertyResolver.getProperty(propertyName);
/* 142 */     if (property != null) {
/* 143 */       return property;
/*     */     }
/* 145 */     return propertyResolver.getProperty(deprecatedPropertyName);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\LogFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
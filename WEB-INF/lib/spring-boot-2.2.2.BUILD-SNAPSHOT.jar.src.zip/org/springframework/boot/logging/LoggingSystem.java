/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LoggingSystem
/*     */ {
/*  44 */   public static final String SYSTEM_PROPERTY = LoggingSystem.class.getName();
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String NONE = "none";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ROOT_LOGGER_NAME = "ROOT";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<String, String> SYSTEMS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  62 */     Map<String, String> systems = new LinkedHashMap<>();
/*  63 */     systems.put("ch.qos.logback.core.Appender", "org.springframework.boot.logging.logback.LogbackLoggingSystem");
/*  64 */     systems.put("org.apache.logging.log4j.core.impl.Log4jContextFactory", "org.springframework.boot.logging.log4j2.Log4J2LoggingSystem");
/*     */     
/*  66 */     systems.put("java.util.logging.LogManager", "org.springframework.boot.logging.java.JavaLoggingSystem");
/*  67 */     SYSTEMS = Collections.unmodifiableMap(systems);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUp() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Runnable getShutdownHandler() {
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<LogLevel> getSupportedLogLevels() {
/* 111 */     return EnumSet.allOf(LogLevel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogLevel(String loggerName, LogLevel level) {
/* 122 */     throw new UnsupportedOperationException("Unable to set log level");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<LoggerConfiguration> getLoggerConfigurations() {
/* 132 */     throw new UnsupportedOperationException("Unable to get logger configurations");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggerConfiguration getLoggerConfiguration(String loggerName) {
/* 142 */     throw new UnsupportedOperationException("Unable to get logger configuration");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggingSystem get(ClassLoader classLoader) {
/* 151 */     String loggingSystem = System.getProperty(SYSTEM_PROPERTY);
/* 152 */     if (StringUtils.hasLength(loggingSystem)) {
/* 153 */       if ("none".equals(loggingSystem)) {
/* 154 */         return new NoOpLoggingSystem();
/*     */       }
/* 156 */       return get(classLoader, loggingSystem);
/*     */     } 
/* 158 */     return (LoggingSystem)SYSTEMS.entrySet().stream().filter(entry -> ClassUtils.isPresent((String)entry.getKey(), classLoader))
/* 159 */       .map(entry -> get(classLoader, (String)entry.getValue())).findFirst()
/* 160 */       .orElseThrow(() -> new IllegalStateException("No suitable logging system located"));
/*     */   }
/*     */   
/*     */   private static LoggingSystem get(ClassLoader classLoader, String loggingSystemClass) {
/*     */     try {
/* 165 */       Class<?> systemClass = ClassUtils.forName(loggingSystemClass, classLoader);
/* 166 */       Constructor<?> constructor = systemClass.getDeclaredConstructor(new Class[] { ClassLoader.class });
/* 167 */       constructor.setAccessible(true);
/* 168 */       return (LoggingSystem)constructor.newInstance(new Object[] { classLoader });
/*     */     }
/* 170 */     catch (Exception ex) {
/* 171 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void beforeInitialize();
/*     */ 
/*     */ 
/*     */   
/*     */   static class NoOpLoggingSystem
/*     */     extends LoggingSystem
/*     */   {
/*     */     public void beforeInitialize() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void setLogLevel(String loggerName, LogLevel level) {}
/*     */ 
/*     */     
/*     */     public List<LoggerConfiguration> getLoggerConfigurations() {
/* 192 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */     
/*     */     public LoggerConfiguration getLoggerConfiguration(String loggerName) {
/* 197 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\LoggingSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
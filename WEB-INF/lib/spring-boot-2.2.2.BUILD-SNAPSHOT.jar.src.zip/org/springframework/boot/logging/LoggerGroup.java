/*    */ package org.springframework.boot.logging;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.BiConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoggerGroup
/*    */ {
/*    */   private final String name;
/*    */   private final List<String> members;
/*    */   private LogLevel configuredLevel;
/*    */   
/*    */   LoggerGroup(String name, List<String> members) {
/* 40 */     this.name = name;
/* 41 */     this.members = Collections.unmodifiableList(new ArrayList<>(members));
/*    */   }
/*    */   
/*    */   public String getName() {
/* 45 */     return this.name;
/*    */   }
/*    */   
/*    */   public List<String> getMembers() {
/* 49 */     return this.members;
/*    */   }
/*    */   
/*    */   public boolean hasMembers() {
/* 53 */     return !this.members.isEmpty();
/*    */   }
/*    */   
/*    */   public LogLevel getConfiguredLevel() {
/* 57 */     return this.configuredLevel;
/*    */   }
/*    */   
/*    */   public void configureLogLevel(LogLevel level, BiConsumer<String, LogLevel> configurer) {
/* 61 */     this.configuredLevel = level;
/* 62 */     this.members.forEach(name -> configurer.accept(name, level));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\LoggerGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.logging;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoggerGroups
/*    */   implements Iterable<LoggerGroup>
/*    */ {
/* 33 */   private final Map<String, LoggerGroup> groups = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/*    */   public LoggerGroups() {}
/*    */   
/*    */   public LoggerGroups(Map<String, List<String>> namesAndMembers) {
/* 39 */     putAll(namesAndMembers);
/*    */   }
/*    */   
/*    */   public void putAll(Map<String, List<String>> namesAndMembers) {
/* 43 */     namesAndMembers.forEach(this::put);
/*    */   }
/*    */   
/*    */   private void put(String name, List<String> members) {
/* 47 */     put(new LoggerGroup(name, members));
/*    */   }
/*    */   
/*    */   private void put(LoggerGroup loggerGroup) {
/* 51 */     this.groups.put(loggerGroup.getName(), loggerGroup);
/*    */   }
/*    */   
/*    */   public LoggerGroup get(String name) {
/* 55 */     return this.groups.get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<LoggerGroup> iterator() {
/* 60 */     return this.groups.values().iterator();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\LoggerGroups.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
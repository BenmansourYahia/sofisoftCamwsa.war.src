/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import org.springframework.boot.system.ApplicationPid;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingSystemProperties
/*     */ {
/*     */   public static final String PID_KEY = "PID";
/*     */   public static final String EXCEPTION_CONVERSION_WORD = "LOG_EXCEPTION_CONVERSION_WORD";
/*     */   public static final String LOG_FILE = "LOG_FILE";
/*     */   public static final String LOG_PATH = "LOG_PATH";
/*     */   public static final String CONSOLE_LOG_PATTERN = "CONSOLE_LOG_PATTERN";
/*     */   public static final String FILE_CLEAN_HISTORY_ON_START = "LOG_FILE_CLEAN_HISTORY_ON_START";
/*     */   public static final String FILE_LOG_PATTERN = "FILE_LOG_PATTERN";
/*     */   public static final String FILE_MAX_HISTORY = "LOG_FILE_MAX_HISTORY";
/*     */   public static final String FILE_MAX_SIZE = "LOG_FILE_MAX_SIZE";
/*     */   public static final String FILE_TOTAL_SIZE_CAP = "LOG_FILE_TOTAL_SIZE_CAP";
/*     */   public static final String LOG_LEVEL_PATTERN = "LOG_LEVEL_PATTERN";
/*     */   public static final String LOG_DATEFORMAT_PATTERN = "LOG_DATEFORMAT_PATTERN";
/*     */   public static final String ROLLING_FILE_NAME_PATTERN = "ROLLING_FILE_NAME_PATTERN";
/*     */   private final Environment environment;
/*     */   
/*     */   public LoggingSystemProperties(Environment environment) {
/* 112 */     Assert.notNull(environment, "Environment must not be null");
/* 113 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public void apply() {
/* 117 */     apply(null);
/*     */   }
/*     */   
/*     */   public void apply(LogFile logFile) {
/* 121 */     PropertyResolver resolver = getPropertyResolver();
/* 122 */     setSystemProperty(resolver, "LOG_EXCEPTION_CONVERSION_WORD", "exception-conversion-word");
/* 123 */     setSystemProperty("PID", (new ApplicationPid()).toString());
/* 124 */     setSystemProperty(resolver, "CONSOLE_LOG_PATTERN", "pattern.console");
/* 125 */     setSystemProperty(resolver, "FILE_LOG_PATTERN", "pattern.file");
/* 126 */     setSystemProperty(resolver, "LOG_FILE_CLEAN_HISTORY_ON_START", "file.clean-history-on-start");
/* 127 */     setSystemProperty(resolver, "LOG_FILE_MAX_HISTORY", "file.max-history");
/* 128 */     setSystemProperty(resolver, "LOG_FILE_MAX_SIZE", "file.max-size");
/* 129 */     setSystemProperty(resolver, "LOG_FILE_TOTAL_SIZE_CAP", "file.total-size-cap");
/* 130 */     setSystemProperty(resolver, "LOG_LEVEL_PATTERN", "pattern.level");
/* 131 */     setSystemProperty(resolver, "LOG_DATEFORMAT_PATTERN", "pattern.dateformat");
/* 132 */     setSystemProperty(resolver, "ROLLING_FILE_NAME_PATTERN", "pattern.rolling-file-name");
/* 133 */     if (logFile != null) {
/* 134 */       logFile.applyToSystemProperties();
/*     */     }
/*     */   }
/*     */   
/*     */   private PropertyResolver getPropertyResolver() {
/* 139 */     if (this.environment instanceof ConfigurableEnvironment) {
/*     */       
/* 141 */       PropertySourcesPropertyResolver resolver = new PropertySourcesPropertyResolver((PropertySources)((ConfigurableEnvironment)this.environment).getPropertySources());
/* 142 */       resolver.setIgnoreUnresolvableNestedPlaceholders(true);
/* 143 */       return (PropertyResolver)resolver;
/*     */     } 
/* 145 */     return (PropertyResolver)this.environment;
/*     */   }
/*     */   
/*     */   private void setSystemProperty(PropertyResolver resolver, String systemPropertyName, String propertyName) {
/* 149 */     setSystemProperty(systemPropertyName, resolver.getProperty("logging." + propertyName));
/*     */   }
/*     */   
/*     */   private void setSystemProperty(String name, String value) {
/* 153 */     if (System.getProperty(name) == null && value != null)
/* 154 */       System.setProperty(name, value); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\LoggingSystemProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
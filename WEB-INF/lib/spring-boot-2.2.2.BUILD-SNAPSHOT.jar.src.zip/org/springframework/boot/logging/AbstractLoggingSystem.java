/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.SystemPropertyUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLoggingSystem
/*     */   extends LoggingSystem
/*     */ {
/*  41 */   protected static final Comparator<LoggerConfiguration> CONFIGURATION_COMPARATOR = new LoggerConfigurationComparator("ROOT");
/*     */   
/*     */   private final ClassLoader classLoader;
/*     */ 
/*     */   
/*     */   public AbstractLoggingSystem(ClassLoader classLoader) {
/*  47 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeInitialize() {}
/*     */ 
/*     */   
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile) {
/*  56 */     if (StringUtils.hasLength(configLocation)) {
/*  57 */       initializeWithSpecificConfig(initializationContext, configLocation, logFile);
/*     */       return;
/*     */     } 
/*  60 */     initializeWithConventions(initializationContext, logFile);
/*     */   }
/*     */ 
/*     */   
/*     */   private void initializeWithSpecificConfig(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile) {
/*  65 */     configLocation = SystemPropertyUtils.resolvePlaceholders(configLocation);
/*  66 */     loadConfiguration(initializationContext, configLocation, logFile);
/*     */   }
/*     */   
/*     */   private void initializeWithConventions(LoggingInitializationContext initializationContext, LogFile logFile) {
/*  70 */     String config = getSelfInitializationConfig();
/*  71 */     if (config != null && logFile == null) {
/*     */       
/*  73 */       reinitialize(initializationContext);
/*     */       return;
/*     */     } 
/*  76 */     if (config == null) {
/*  77 */       config = getSpringInitializationConfig();
/*     */     }
/*  79 */     if (config != null) {
/*  80 */       loadConfiguration(initializationContext, config, logFile);
/*     */       return;
/*     */     } 
/*  83 */     loadDefaults(initializationContext, logFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSelfInitializationConfig() {
/*  93 */     return findConfig(getStandardConfigLocations());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSpringInitializationConfig() {
/* 102 */     return findConfig(getSpringConfigLocations());
/*     */   }
/*     */   
/*     */   private String findConfig(String[] locations) {
/* 106 */     for (String location : locations) {
/* 107 */       ClassPathResource resource = new ClassPathResource(location, this.classLoader);
/* 108 */       if (resource.exists()) {
/* 109 */         return "classpath:" + location;
/*     */       }
/*     */     } 
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String[] getStandardConfigLocations();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getSpringConfigLocations() {
/* 129 */     String[] locations = getStandardConfigLocations();
/* 130 */     for (int i = 0; i < locations.length; i++) {
/* 131 */       String extension = StringUtils.getFilenameExtension(locations[i]);
/* 132 */       locations[i] = locations[i].substring(0, locations[i].length() - extension.length() - 1) + "-spring." + extension;
/*     */     } 
/*     */     
/* 135 */     return locations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void loadDefaults(LoggingInitializationContext paramLoggingInitializationContext, LogFile paramLogFile);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void loadConfiguration(LoggingInitializationContext paramLoggingInitializationContext, String paramString, LogFile paramLogFile);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reinitialize(LoggingInitializationContext initializationContext) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ClassLoader getClassLoader() {
/* 165 */     return this.classLoader;
/*     */   }
/*     */   
/*     */   protected final String getPackagedConfigFile(String fileName) {
/* 169 */     String defaultPath = ClassUtils.getPackageName(getClass());
/* 170 */     defaultPath = defaultPath.replace('.', '/');
/* 171 */     defaultPath = defaultPath + "/" + fileName;
/* 172 */     defaultPath = "classpath:" + defaultPath;
/* 173 */     return defaultPath;
/*     */   }
/*     */   
/*     */   protected final void applySystemProperties(Environment environment, LogFile logFile) {
/* 177 */     (new LoggingSystemProperties(environment)).apply(logFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class LogLevels<T>
/*     */   {
/* 192 */     private final Map<LogLevel, T> systemToNative = new EnumMap<>(LogLevel.class);
/* 193 */     private final Map<T, LogLevel> nativeToSystem = new HashMap<>();
/*     */ 
/*     */     
/*     */     public void map(LogLevel system, T nativeLevel) {
/* 197 */       this.systemToNative.putIfAbsent(system, nativeLevel);
/* 198 */       this.nativeToSystem.putIfAbsent(nativeLevel, system);
/*     */     }
/*     */     
/*     */     public LogLevel convertNativeToSystem(T level) {
/* 202 */       return this.nativeToSystem.get(level);
/*     */     }
/*     */     
/*     */     public T convertSystemToNative(LogLevel level) {
/* 206 */       return this.systemToNative.get(level);
/*     */     }
/*     */     
/*     */     public Set<LogLevel> getSupported() {
/* 210 */       return new LinkedHashSet<>(this.nativeToSystem.values());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\AbstractLoggingSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
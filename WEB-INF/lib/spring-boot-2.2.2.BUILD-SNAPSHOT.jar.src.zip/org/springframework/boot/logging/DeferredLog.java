/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredLog
/*     */   implements Log
/*     */ {
/*     */   private volatile Log destination;
/*  36 */   private final List<Line> lines = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/*  40 */     synchronized (this.lines) {
/*  41 */       return (this.destination == null || this.destination.isTraceEnabled());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/*  47 */     synchronized (this.lines) {
/*  48 */       return (this.destination == null || this.destination.isDebugEnabled());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/*  54 */     synchronized (this.lines) {
/*  55 */       return (this.destination == null || this.destination.isInfoEnabled());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/*  61 */     synchronized (this.lines) {
/*  62 */       return (this.destination == null || this.destination.isWarnEnabled());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/*  68 */     synchronized (this.lines) {
/*  69 */       return (this.destination == null || this.destination.isErrorEnabled());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFatalEnabled() {
/*  75 */     synchronized (this.lines) {
/*  76 */       return (this.destination == null || this.destination.isFatalEnabled());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message) {
/*  82 */     log(LogLevel.TRACE, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message, Throwable t) {
/*  87 */     log(LogLevel.TRACE, message, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message) {
/*  92 */     log(LogLevel.DEBUG, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message, Throwable t) {
/*  97 */     log(LogLevel.DEBUG, message, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message) {
/* 102 */     log(LogLevel.INFO, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message, Throwable t) {
/* 107 */     log(LogLevel.INFO, message, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message) {
/* 112 */     log(LogLevel.WARN, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message, Throwable t) {
/* 117 */     log(LogLevel.WARN, message, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message) {
/* 122 */     log(LogLevel.ERROR, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message, Throwable t) {
/* 127 */     log(LogLevel.ERROR, message, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message) {
/* 132 */     log(LogLevel.FATAL, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message, Throwable t) {
/* 137 */     log(LogLevel.FATAL, message, t);
/*     */   }
/*     */   
/*     */   private void log(LogLevel level, Object message, Throwable t) {
/* 141 */     synchronized (this.lines) {
/* 142 */       if (this.destination != null) {
/* 143 */         logTo(this.destination, level, message, t);
/*     */       } else {
/*     */         
/* 146 */         this.lines.add(new Line(level, message, t));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchTo(Class<?> destination) {
/* 157 */     switchTo(LogFactory.getLog(destination));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchTo(Log destination) {
/* 166 */     synchronized (this.lines) {
/* 167 */       replayTo(destination);
/* 168 */       this.destination = destination;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replayTo(Class<?> destination) {
/* 177 */     replayTo(LogFactory.getLog(destination));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replayTo(Log destination) {
/* 185 */     synchronized (this.lines) {
/* 186 */       for (Line line : this.lines) {
/* 187 */         logTo(destination, line.getLevel(), line.getMessage(), line.getThrowable());
/*     */       }
/* 189 */       this.lines.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log replay(Log source, Class<?> destination) {
/* 200 */     return replay(source, LogFactory.getLog(destination));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log replay(Log source, Log destination) {
/* 210 */     if (source instanceof DeferredLog) {
/* 211 */       ((DeferredLog)source).replayTo(destination);
/*     */     }
/* 213 */     return destination;
/*     */   }
/*     */   
/*     */   private static void logTo(Log log, LogLevel level, Object message, Throwable throwable) {
/* 217 */     switch (level) {
/*     */       case TRACE:
/* 219 */         log.trace(message, throwable);
/*     */         return;
/*     */       case DEBUG:
/* 222 */         log.debug(message, throwable);
/*     */         return;
/*     */       case INFO:
/* 225 */         log.info(message, throwable);
/*     */         return;
/*     */       case WARN:
/* 228 */         log.warn(message, throwable);
/*     */         return;
/*     */       case ERROR:
/* 231 */         log.error(message, throwable);
/*     */         return;
/*     */       case FATAL:
/* 234 */         log.fatal(message, throwable);
/*     */         return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Line
/*     */   {
/*     */     private final LogLevel level;
/*     */     
/*     */     private final Object message;
/*     */     private final Throwable throwable;
/*     */     
/*     */     Line(LogLevel level, Object message, Throwable throwable) {
/* 248 */       this.level = level;
/* 249 */       this.message = message;
/* 250 */       this.throwable = throwable;
/*     */     }
/*     */     
/*     */     LogLevel getLevel() {
/* 254 */       return this.level;
/*     */     }
/*     */     
/*     */     Object getMessage() {
/* 258 */       return this.message;
/*     */     }
/*     */     
/*     */     Throwable getThrowable() {
/* 262 */       return this.throwable;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\DeferredLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
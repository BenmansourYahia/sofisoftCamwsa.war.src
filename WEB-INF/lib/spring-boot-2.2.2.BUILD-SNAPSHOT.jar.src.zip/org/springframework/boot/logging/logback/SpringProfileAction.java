/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.core.joran.action.Action;
/*     */ import ch.qos.logback.core.joran.event.InPlayListener;
/*     */ import ch.qos.logback.core.joran.event.SaxEvent;
/*     */ import ch.qos.logback.core.joran.spi.ActionException;
/*     */ import ch.qos.logback.core.joran.spi.InterpretationContext;
/*     */ import ch.qos.logback.core.joran.spi.Interpreter;
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.Profiles;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringProfileAction
/*     */   extends Action
/*     */   implements InPlayListener
/*     */ {
/*     */   private final Environment environment;
/*  47 */   private int depth = 0;
/*     */   
/*     */   private boolean acceptsProfile;
/*     */   
/*     */   private List<SaxEvent> events;
/*     */   
/*     */   SpringProfileAction(Environment environment) {
/*  54 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public void begin(InterpretationContext ic, String name, Attributes attributes) throws ActionException {
/*  59 */     this.depth++;
/*  60 */     if (this.depth != 1) {
/*     */       return;
/*     */     }
/*  63 */     ic.pushObject(this);
/*  64 */     this.acceptsProfile = acceptsProfiles(ic, attributes);
/*  65 */     this.events = new ArrayList<>();
/*  66 */     ic.addInPlayListener(this);
/*     */   }
/*     */   
/*     */   private boolean acceptsProfiles(InterpretationContext ic, Attributes attributes) {
/*  70 */     if (this.environment == null) {
/*  71 */       return false;
/*     */     }
/*     */     
/*  74 */     String[] profileNames = StringUtils.trimArrayElements(StringUtils.commaDelimitedListToStringArray(attributes.getValue("name")));
/*  75 */     if (profileNames.length == 0) {
/*  76 */       return false;
/*     */     }
/*  78 */     for (int i = 0; i < profileNames.length; i++) {
/*  79 */       profileNames[i] = OptionHelper.substVars(profileNames[i], (PropertyContainer)ic, (PropertyContainer)this.context);
/*     */     }
/*  81 */     return this.environment.acceptsProfiles(Profiles.of(profileNames));
/*     */   }
/*     */ 
/*     */   
/*     */   public void end(InterpretationContext ic, String name) throws ActionException {
/*  86 */     this.depth--;
/*  87 */     if (this.depth != 0) {
/*     */       return;
/*     */     }
/*  90 */     ic.removeInPlayListener(this);
/*  91 */     verifyAndPop(ic);
/*  92 */     if (this.acceptsProfile) {
/*  93 */       addEventsToPlayer(ic);
/*     */     }
/*     */   }
/*     */   
/*     */   private void verifyAndPop(InterpretationContext ic) {
/*  98 */     Object o = ic.peekObject();
/*  99 */     Assert.state((o != null), "Unexpected null object on stack");
/* 100 */     Assert.isInstanceOf(SpringProfileAction.class, o, "logback stack error");
/* 101 */     Assert.state((o == this), "ProfileAction different than current one on stack");
/* 102 */     ic.popObject();
/*     */   }
/*     */   
/*     */   private void addEventsToPlayer(InterpretationContext ic) {
/* 106 */     Interpreter interpreter = ic.getJoranInterpreter();
/* 107 */     this.events.remove(0);
/* 108 */     this.events.remove(this.events.size() - 1);
/* 109 */     interpreter.getEventPlayer().addEventsDynamically(this.events, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void inPlay(SaxEvent event) {
/* 114 */     this.events.add(event);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\logback\SpringProfileAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
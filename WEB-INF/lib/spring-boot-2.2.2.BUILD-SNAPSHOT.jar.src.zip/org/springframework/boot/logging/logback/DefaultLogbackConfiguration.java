/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.core.Appender;
/*     */ import ch.qos.logback.core.ConsoleAppender;
/*     */ import ch.qos.logback.core.FileAppender;
/*     */ import ch.qos.logback.core.encoder.Encoder;
/*     */ import ch.qos.logback.core.rolling.RollingFileAppender;
/*     */ import ch.qos.logback.core.rolling.RollingPolicy;
/*     */ import ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.util.FileSize;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultLogbackConfiguration
/*     */ {
/*     */   private static final String CONSOLE_LOG_PATTERN = "%clr(%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}}){faint} %clr(${LOG_LEVEL_PATTERN:-%5p}) %clr(${PID:- }){magenta} %clr(---){faint} %clr([%15.15t]){faint} %clr(%-40.40logger{39}){cyan} %clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}";
/*     */   private static final String FILE_LOG_PATTERN = "%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}} ${LOG_LEVEL_PATTERN:-%5p} ${PID:- } --- [%t] %-40.40logger{39} : %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}";
/*  61 */   private static final DataSize MAX_FILE_SIZE = DataSize.ofMegabytes(10L);
/*     */   
/*  63 */   private static final Integer MAX_FILE_HISTORY = Integer.valueOf(7);
/*     */   
/*     */   private final PropertyResolver patterns;
/*     */   
/*     */   private final LogFile logFile;
/*     */   
/*     */   DefaultLogbackConfiguration(LoggingInitializationContext initializationContext, LogFile logFile) {
/*  70 */     this.patterns = getPatternsResolver(initializationContext.getEnvironment());
/*  71 */     this.logFile = logFile;
/*     */   }
/*     */   
/*     */   private PropertyResolver getPatternsResolver(Environment environment) {
/*  75 */     if (environment == null) {
/*  76 */       return (PropertyResolver)new PropertySourcesPropertyResolver(null);
/*     */     }
/*  78 */     if (environment instanceof ConfigurableEnvironment) {
/*     */       
/*  80 */       PropertySourcesPropertyResolver resolver = new PropertySourcesPropertyResolver((PropertySources)((ConfigurableEnvironment)environment).getPropertySources());
/*  81 */       resolver.setIgnoreUnresolvableNestedPlaceholders(true);
/*  82 */       return (PropertyResolver)resolver;
/*     */     } 
/*  84 */     return (PropertyResolver)environment;
/*     */   }
/*     */   
/*     */   void apply(LogbackConfigurator config) {
/*  88 */     synchronized (config.getConfigurationLock()) {
/*  89 */       base(config);
/*  90 */       Appender<ILoggingEvent> consoleAppender = consoleAppender(config);
/*  91 */       if (this.logFile != null) {
/*  92 */         Appender<ILoggingEvent> fileAppender = fileAppender(config, this.logFile.toString());
/*  93 */         config.root(Level.INFO, (Appender<ILoggingEvent>[])new Appender[] { consoleAppender, fileAppender });
/*     */       } else {
/*     */         
/*  96 */         config.root(Level.INFO, (Appender<ILoggingEvent>[])new Appender[] { consoleAppender });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void base(LogbackConfigurator config) {
/* 102 */     config.conversionRule("clr", (Class)ColorConverter.class);
/* 103 */     config.conversionRule("wex", (Class)WhitespaceThrowableProxyConverter.class);
/* 104 */     config.conversionRule("wEx", (Class)ExtendedWhitespaceThrowableProxyConverter.class);
/* 105 */     config.logger("org.apache.catalina.startup.DigesterFactory", Level.ERROR);
/* 106 */     config.logger("org.apache.catalina.util.LifecycleBase", Level.ERROR);
/* 107 */     config.logger("org.apache.coyote.http11.Http11NioProtocol", Level.WARN);
/* 108 */     config.logger("org.apache.sshd.common.util.SecurityUtils", Level.WARN);
/* 109 */     config.logger("org.apache.tomcat.util.net.NioSelectorPool", Level.WARN);
/* 110 */     config.logger("org.eclipse.jetty.util.component.AbstractLifeCycle", Level.ERROR);
/* 111 */     config.logger("org.hibernate.validator.internal.util.Version", Level.WARN);
/*     */   }
/*     */   
/*     */   private Appender<ILoggingEvent> consoleAppender(LogbackConfigurator config) {
/* 115 */     ConsoleAppender<ILoggingEvent> appender = new ConsoleAppender();
/* 116 */     PatternLayoutEncoder encoder = new PatternLayoutEncoder();
/* 117 */     String logPattern = this.patterns.getProperty("logging.pattern.console", "%clr(%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}}){faint} %clr(${LOG_LEVEL_PATTERN:-%5p}) %clr(${PID:- }){magenta} %clr(---){faint} %clr([%15.15t]){faint} %clr(%-40.40logger{39}){cyan} %clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}");
/* 118 */     encoder.setPattern(OptionHelper.substVars(logPattern, (PropertyContainer)config.getContext()));
/* 119 */     config.start((LifeCycle)encoder);
/* 120 */     appender.setEncoder((Encoder)encoder);
/* 121 */     config.appender("CONSOLE", (Appender<?>)appender);
/* 122 */     return (Appender<ILoggingEvent>)appender;
/*     */   }
/*     */   
/*     */   private Appender<ILoggingEvent> fileAppender(LogbackConfigurator config, String logFile) {
/* 126 */     RollingFileAppender<ILoggingEvent> appender = new RollingFileAppender();
/* 127 */     PatternLayoutEncoder encoder = new PatternLayoutEncoder();
/* 128 */     String logPattern = this.patterns.getProperty("logging.pattern.file", "%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}} ${LOG_LEVEL_PATTERN:-%5p} ${PID:- } --- [%t] %-40.40logger{39} : %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}");
/* 129 */     encoder.setPattern(OptionHelper.substVars(logPattern, (PropertyContainer)config.getContext()));
/* 130 */     appender.setEncoder((Encoder)encoder);
/* 131 */     config.start((LifeCycle)encoder);
/* 132 */     appender.setFile(logFile);
/* 133 */     setRollingPolicy(appender, config, logFile);
/* 134 */     config.appender("FILE", (Appender<?>)appender);
/* 135 */     return (Appender<ILoggingEvent>)appender;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setRollingPolicy(RollingFileAppender<ILoggingEvent> appender, LogbackConfigurator config, String logFile) {
/* 140 */     SizeAndTimeBasedRollingPolicy<ILoggingEvent> rollingPolicy = new SizeAndTimeBasedRollingPolicy();
/* 141 */     rollingPolicy.setCleanHistoryOnStart(((Boolean)this.patterns
/* 142 */         .getProperty("logging.file.clean-history-on-start", Boolean.class, Boolean.valueOf(false))).booleanValue());
/* 143 */     rollingPolicy.setFileNamePattern(this.patterns
/* 144 */         .getProperty("logging.pattern.rolling-file-name", logFile + ".%d{yyyy-MM-dd}.%i.gz"));
/* 145 */     setMaxFileSize(rollingPolicy, getDataSize("logging.file.max-size", MAX_FILE_SIZE));
/* 146 */     rollingPolicy
/* 147 */       .setMaxHistory(((Integer)this.patterns.getProperty("logging.file.max-history", Integer.class, MAX_FILE_HISTORY)).intValue());
/* 148 */     DataSize totalSizeCap = getDataSize("logging.file.total-size-cap", 
/* 149 */         DataSize.ofBytes(0L));
/* 150 */     rollingPolicy.setTotalSizeCap(new FileSize(totalSizeCap.toBytes()));
/* 151 */     appender.setRollingPolicy((RollingPolicy)rollingPolicy);
/* 152 */     rollingPolicy.setParent((FileAppender)appender);
/* 153 */     config.start((LifeCycle)rollingPolicy);
/*     */   }
/*     */   
/*     */   private void setMaxFileSize(SizeAndTimeBasedRollingPolicy<ILoggingEvent> rollingPolicy, DataSize maxFileSize) {
/*     */     try {
/* 158 */       rollingPolicy.setMaxFileSize(new FileSize(maxFileSize.toBytes()));
/*     */     }
/* 160 */     catch (NoSuchMethodError ex) {
/*     */       
/* 162 */       Method method = ReflectionUtils.findMethod(SizeAndTimeBasedRollingPolicy.class, "setMaxFileSize", new Class[] { String.class });
/*     */       
/* 164 */       ReflectionUtils.invokeMethod(method, rollingPolicy, new Object[] { String.valueOf(maxFileSize.toBytes()) });
/*     */     } 
/*     */   }
/*     */   
/*     */   private DataSize getDataSize(String property, DataSize defaultSize) {
/* 169 */     String value = this.patterns.getProperty(property);
/* 170 */     if (value == null) {
/* 171 */       return defaultSize;
/*     */     }
/*     */     try {
/* 174 */       return DataSize.parse(value);
/*     */     }
/* 176 */     catch (IllegalArgumentException ex) {
/* 177 */       FileSize fileSize = FileSize.valueOf(value);
/* 178 */       return DataSize.ofBytes(fileSize.getSize());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\logback\DefaultLogbackConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.joran.JoranConfigurator;
/*     */ import ch.qos.logback.classic.jul.LevelChangePropagator;
/*     */ import ch.qos.logback.classic.spi.LoggerContextListener;
/*     */ import ch.qos.logback.classic.turbo.TurboFilter;
/*     */ import ch.qos.logback.classic.util.ContextInitializer;
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.spi.FilterReply;
/*     */ import ch.qos.logback.core.status.OnConsoleStatusListener;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.util.StatusListenerConfigHelper;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.Logger;
/*     */ import org.slf4j.ILoggerFactory;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.impl.StaticLoggerBinder;
/*     */ import org.springframework.boot.logging.AbstractLoggingSystem;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggerConfiguration;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.boot.logging.LoggingSystem;
/*     */ import org.springframework.boot.logging.Slf4JLoggingSystem;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogbackLoggingSystem
/*     */   extends Slf4JLoggingSystem
/*     */ {
/*     */   private static final String CONFIGURATION_FILE_PROPERTY = "logback.configurationFile";
/*  70 */   private static final AbstractLoggingSystem.LogLevels<Level> LEVELS = new AbstractLoggingSystem.LogLevels();
/*     */   
/*     */   static {
/*  73 */     LEVELS.map(LogLevel.TRACE, Level.TRACE);
/*  74 */     LEVELS.map(LogLevel.TRACE, Level.ALL);
/*  75 */     LEVELS.map(LogLevel.DEBUG, Level.DEBUG);
/*  76 */     LEVELS.map(LogLevel.INFO, Level.INFO);
/*  77 */     LEVELS.map(LogLevel.WARN, Level.WARN);
/*  78 */     LEVELS.map(LogLevel.ERROR, Level.ERROR);
/*  79 */     LEVELS.map(LogLevel.FATAL, Level.ERROR);
/*  80 */     LEVELS.map(LogLevel.OFF, Level.OFF);
/*     */   }
/*     */   
/*  83 */   private static final TurboFilter FILTER = new TurboFilter()
/*     */     {
/*     */       
/*     */       public FilterReply decide(Marker marker, Logger logger, Level level, String format, Object[] params, Throwable t)
/*     */       {
/*  88 */         return FilterReply.DENY;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public LogbackLoggingSystem(ClassLoader classLoader) {
/*  94 */     super(classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getStandardConfigLocations() {
/*  99 */     return new String[] { "logback-test.groovy", "logback-test.xml", "logback.groovy", "logback.xml" };
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeInitialize() {
/* 104 */     LoggerContext loggerContext = getLoggerContext();
/* 105 */     if (isAlreadyInitialized(loggerContext)) {
/*     */       return;
/*     */     }
/* 108 */     super.beforeInitialize();
/* 109 */     loggerContext.getTurboFilterList().add(FILTER);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile) {
/* 114 */     LoggerContext loggerContext = getLoggerContext();
/* 115 */     if (isAlreadyInitialized(loggerContext)) {
/*     */       return;
/*     */     }
/* 118 */     super.initialize(initializationContext, configLocation, logFile);
/* 119 */     loggerContext.getTurboFilterList().remove(FILTER);
/* 120 */     markAsInitialized(loggerContext);
/* 121 */     if (StringUtils.hasText(System.getProperty("logback.configurationFile"))) {
/* 122 */       getLogger(LogbackLoggingSystem.class.getName()).warn("Ignoring 'logback.configurationFile' system property. Please use 'logging.config' instead.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadDefaults(LoggingInitializationContext initializationContext, LogFile logFile) {
/* 129 */     LoggerContext context = getLoggerContext();
/* 130 */     stopAndReset(context);
/* 131 */     boolean debug = Boolean.getBoolean("logback.debug");
/* 132 */     if (debug) {
/* 133 */       StatusListenerConfigHelper.addOnConsoleListenerInstance((Context)context, new OnConsoleStatusListener());
/*     */     }
/* 135 */     LogbackConfigurator configurator = debug ? new DebugLogbackConfigurator(context) : new LogbackConfigurator(context);
/*     */     
/* 137 */     Environment environment = initializationContext.getEnvironment();
/* 138 */     context.putProperty("LOG_LEVEL_PATTERN", environment
/* 139 */         .resolvePlaceholders("${logging.pattern.level:${LOG_LEVEL_PATTERN:%5p}}"));
/* 140 */     context.putProperty("LOG_DATEFORMAT_PATTERN", environment.resolvePlaceholders("${logging.pattern.dateformat:${LOG_DATEFORMAT_PATTERN:yyyy-MM-dd HH:mm:ss.SSS}}"));
/*     */     
/* 142 */     context.putProperty("ROLLING_FILE_NAME_PATTERN", environment
/* 143 */         .resolvePlaceholders("${logging.pattern.rolling-file-name:${LOG_FILE}.%d{yyyy-MM-dd}.%i.gz}"));
/* 144 */     (new DefaultLogbackConfiguration(initializationContext, logFile)).apply(configurator);
/* 145 */     context.setPackagingDataEnabled(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadConfiguration(LoggingInitializationContext initializationContext, String location, LogFile logFile) {
/* 151 */     super.loadConfiguration(initializationContext, location, logFile);
/* 152 */     LoggerContext loggerContext = getLoggerContext();
/* 153 */     stopAndReset(loggerContext);
/*     */     try {
/* 155 */       configureByResourceUrl(initializationContext, loggerContext, ResourceUtils.getURL(location));
/*     */     }
/* 157 */     catch (Exception ex) {
/* 158 */       throw new IllegalStateException("Could not initialize Logback logging from " + location, ex);
/*     */     } 
/* 160 */     List<Status> statuses = loggerContext.getStatusManager().getCopyOfStatusList();
/* 161 */     StringBuilder errors = new StringBuilder();
/* 162 */     for (Status status : statuses) {
/* 163 */       if (status.getLevel() == 2) {
/* 164 */         errors.append((errors.length() > 0) ? String.format("%n", new Object[0]) : "");
/* 165 */         errors.append(status.toString());
/*     */       } 
/*     */     } 
/* 168 */     if (errors.length() > 0) {
/* 169 */       throw new IllegalStateException(String.format("Logback configuration error detected: %n%s", new Object[] { errors }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureByResourceUrl(LoggingInitializationContext initializationContext, LoggerContext loggerContext, URL url) throws JoranException {
/* 175 */     if (url.toString().endsWith("xml")) {
/* 176 */       JoranConfigurator configurator = new SpringBootJoranConfigurator(initializationContext);
/* 177 */       configurator.setContext((Context)loggerContext);
/* 178 */       configurator.doConfigure(url);
/*     */     } else {
/*     */       
/* 181 */       (new ContextInitializer(loggerContext)).configureByResource(url);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void stopAndReset(LoggerContext loggerContext) {
/* 186 */     loggerContext.stop();
/* 187 */     loggerContext.reset();
/* 188 */     if (isBridgeHandlerInstalled()) {
/* 189 */       addLevelChangePropagator(loggerContext);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isBridgeHandlerInstalled() {
/* 194 */     if (!isBridgeHandlerAvailable()) {
/* 195 */       return false;
/*     */     }
/* 197 */     Logger rootLogger = LogManager.getLogManager().getLogger("");
/* 198 */     Handler[] handlers = rootLogger.getHandlers();
/* 199 */     return (handlers.length == 1 && handlers[0] instanceof org.slf4j.bridge.SLF4JBridgeHandler);
/*     */   }
/*     */   
/*     */   private void addLevelChangePropagator(LoggerContext loggerContext) {
/* 203 */     LevelChangePropagator levelChangePropagator = new LevelChangePropagator();
/* 204 */     levelChangePropagator.setResetJUL(true);
/* 205 */     levelChangePropagator.setContext((Context)loggerContext);
/* 206 */     loggerContext.addListener((LoggerContextListener)levelChangePropagator);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/* 211 */     LoggerContext context = getLoggerContext();
/* 212 */     markAsUninitialized(context);
/* 213 */     super.cleanUp();
/* 214 */     context.getStatusManager().clear();
/* 215 */     context.getTurboFilterList().remove(FILTER);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reinitialize(LoggingInitializationContext initializationContext) {
/* 220 */     getLoggerContext().reset();
/* 221 */     getLoggerContext().getStatusManager().clear();
/* 222 */     loadConfiguration(initializationContext, getSelfInitializationConfig(), (LogFile)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<LoggerConfiguration> getLoggerConfigurations() {
/* 227 */     List<LoggerConfiguration> result = new ArrayList<>();
/* 228 */     for (Logger logger : getLoggerContext().getLoggerList()) {
/* 229 */       result.add(getLoggerConfiguration(logger));
/*     */     }
/* 231 */     result.sort(CONFIGURATION_COMPARATOR);
/* 232 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public LoggerConfiguration getLoggerConfiguration(String loggerName) {
/* 237 */     return getLoggerConfiguration(getLogger(loggerName));
/*     */   }
/*     */   
/*     */   private LoggerConfiguration getLoggerConfiguration(Logger logger) {
/* 241 */     if (logger == null) {
/* 242 */       return null;
/*     */     }
/* 244 */     LogLevel level = LEVELS.convertNativeToSystem(logger.getLevel());
/* 245 */     LogLevel effectiveLevel = LEVELS.convertNativeToSystem(logger.getEffectiveLevel());
/* 246 */     String name = logger.getName();
/* 247 */     if (!StringUtils.hasLength(name) || "ROOT".equals(name)) {
/* 248 */       name = "ROOT";
/*     */     }
/* 250 */     return new LoggerConfiguration(name, level, effectiveLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<LogLevel> getSupportedLogLevels() {
/* 255 */     return LEVELS.getSupported();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLogLevel(String loggerName, LogLevel level) {
/* 260 */     Logger logger = getLogger(loggerName);
/* 261 */     if (logger != null) {
/* 262 */       logger.setLevel((Level)LEVELS.convertSystemToNative(level));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Runnable getShutdownHandler() {
/* 268 */     return new ShutdownHandler();
/*     */   }
/*     */   
/*     */   private Logger getLogger(String name) {
/* 272 */     LoggerContext factory = getLoggerContext();
/* 273 */     if (StringUtils.isEmpty(name) || "ROOT".equals(name)) {
/* 274 */       name = "ROOT";
/*     */     }
/* 276 */     return factory.getLogger(name);
/*     */   }
/*     */   
/*     */   private LoggerContext getLoggerContext() {
/* 280 */     ILoggerFactory factory = StaticLoggerBinder.getSingleton().getLoggerFactory();
/* 281 */     Assert.isInstanceOf(LoggerContext.class, factory, 
/* 282 */         String.format("LoggerFactory is not a Logback LoggerContext but Logback is on the classpath. Either remove Logback or the competing implementation (%s loaded from %s). If you are using WebLogic you will need to add 'org.slf4j' to prefer-application-packages in WEB-INF/weblogic.xml", new Object[] {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 288 */             factory.getClass(), getLocation(factory) }));
/* 289 */     return (LoggerContext)factory;
/*     */   }
/*     */   
/*     */   private Object getLocation(ILoggerFactory factory) {
/*     */     try {
/* 294 */       ProtectionDomain protectionDomain = factory.getClass().getProtectionDomain();
/* 295 */       CodeSource codeSource = protectionDomain.getCodeSource();
/* 296 */       if (codeSource != null) {
/* 297 */         return codeSource.getLocation();
/*     */       }
/*     */     }
/* 300 */     catch (SecurityException securityException) {}
/*     */ 
/*     */     
/* 303 */     return "unknown location";
/*     */   }
/*     */   
/*     */   private boolean isAlreadyInitialized(LoggerContext loggerContext) {
/* 307 */     return (loggerContext.getObject(LoggingSystem.class.getName()) != null);
/*     */   }
/*     */   
/*     */   private void markAsInitialized(LoggerContext loggerContext) {
/* 311 */     loggerContext.putObject(LoggingSystem.class.getName(), new Object());
/*     */   }
/*     */   
/*     */   private void markAsUninitialized(LoggerContext loggerContext) {
/* 315 */     loggerContext.removeObject(LoggingSystem.class.getName());
/*     */   }
/*     */   
/*     */   private final class ShutdownHandler implements Runnable {
/*     */     private ShutdownHandler() {}
/*     */     
/*     */     public void run() {
/* 322 */       LogbackLoggingSystem.this.getLoggerContext().stop();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\logback\LogbackLoggingSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
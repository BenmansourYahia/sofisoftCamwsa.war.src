/*    */ package org.springframework.boot.logging.logback;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*    */ import ch.qos.logback.core.pattern.CompositeConverter;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.ansi.AnsiColor;
/*    */ import org.springframework.boot.ansi.AnsiElement;
/*    */ import org.springframework.boot.ansi.AnsiOutput;
/*    */ import org.springframework.boot.ansi.AnsiStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorConverter
/*    */   extends CompositeConverter<ILoggingEvent>
/*    */ {
/*    */   private static final Map<String, AnsiElement> ELEMENTS;
/*    */   private static final Map<Integer, AnsiElement> LEVELS;
/*    */   
/*    */   static {
/* 45 */     Map<String, AnsiElement> ansiElements = new HashMap<>();
/* 46 */     ansiElements.put("faint", AnsiStyle.FAINT);
/* 47 */     ansiElements.put("red", AnsiColor.RED);
/* 48 */     ansiElements.put("green", AnsiColor.GREEN);
/* 49 */     ansiElements.put("yellow", AnsiColor.YELLOW);
/* 50 */     ansiElements.put("blue", AnsiColor.BLUE);
/* 51 */     ansiElements.put("magenta", AnsiColor.MAGENTA);
/* 52 */     ansiElements.put("cyan", AnsiColor.CYAN);
/* 53 */     ELEMENTS = Collections.unmodifiableMap(ansiElements);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 59 */     Map<Integer, AnsiElement> ansiLevels = new HashMap<>();
/* 60 */     ansiLevels.put(Level.ERROR_INTEGER, AnsiColor.RED);
/* 61 */     ansiLevels.put(Level.WARN_INTEGER, AnsiColor.YELLOW);
/* 62 */     LEVELS = Collections.unmodifiableMap(ansiLevels);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String transform(ILoggingEvent event, String in) {
/* 67 */     AnsiElement element = ELEMENTS.get(getFirstOption());
/* 68 */     if (element == null) {
/*    */       
/* 70 */       element = LEVELS.get(event.getLevel().toInteger());
/* 71 */       element = (element != null) ? element : (AnsiElement)AnsiColor.GREEN;
/*    */     } 
/* 73 */     return toAnsiString(in, element);
/*    */   }
/*    */   
/*    */   protected String toAnsiString(String in, AnsiElement element) {
/* 77 */     return AnsiOutput.toString(new Object[] { element, in });
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\logback\ColorConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
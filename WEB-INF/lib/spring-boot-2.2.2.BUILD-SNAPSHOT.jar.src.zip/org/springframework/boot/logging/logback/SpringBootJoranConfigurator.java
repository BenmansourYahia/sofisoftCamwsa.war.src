/*    */ package org.springframework.boot.logging.logback;
/*    */ 
/*    */ import ch.qos.logback.classic.joran.JoranConfigurator;
/*    */ import ch.qos.logback.core.joran.action.Action;
/*    */ import ch.qos.logback.core.joran.action.NOPAction;
/*    */ import ch.qos.logback.core.joran.spi.ElementSelector;
/*    */ import ch.qos.logback.core.joran.spi.RuleStore;
/*    */ import org.springframework.boot.logging.LoggingInitializationContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringBootJoranConfigurator
/*    */   extends JoranConfigurator
/*    */ {
/*    */   private LoggingInitializationContext initializationContext;
/*    */   
/*    */   SpringBootJoranConfigurator(LoggingInitializationContext initializationContext) {
/* 38 */     this.initializationContext = initializationContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addInstanceRules(RuleStore rs) {
/* 43 */     super.addInstanceRules(rs);
/* 44 */     Environment environment = this.initializationContext.getEnvironment();
/* 45 */     rs.addRule(new ElementSelector("configuration/springProperty"), new SpringPropertyAction(environment));
/* 46 */     rs.addRule(new ElementSelector("*/springProfile"), new SpringProfileAction(environment));
/* 47 */     rs.addRule(new ElementSelector("*/springProfile/*"), (Action)new NOPAction());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\logback\SpringBootJoranConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
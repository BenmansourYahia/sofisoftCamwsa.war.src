/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.core.Appender;
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.pattern.Converter;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LogbackConfigurator
/*     */ {
/*     */   private LoggerContext context;
/*     */   
/*     */   LogbackConfigurator(LoggerContext context) {
/*  44 */     Assert.notNull(context, "Context must not be null");
/*  45 */     this.context = context;
/*     */   }
/*     */   
/*     */   LoggerContext getContext() {
/*  49 */     return this.context;
/*     */   }
/*     */   
/*     */   Object getConfigurationLock() {
/*  53 */     return this.context.getConfigurationLock();
/*     */   }
/*     */ 
/*     */   
/*     */   void conversionRule(String conversionWord, Class<? extends Converter> converterClass) {
/*  58 */     Assert.hasLength(conversionWord, "Conversion word must not be empty");
/*  59 */     Assert.notNull(converterClass, "Converter class must not be null");
/*     */     
/*  61 */     Map<String, String> registry = (Map<String, String>)this.context.getObject("PATTERN_RULE_REGISTRY");
/*  62 */     if (registry == null) {
/*  63 */       registry = new HashMap<>();
/*  64 */       this.context.putObject("PATTERN_RULE_REGISTRY", registry);
/*     */     } 
/*  66 */     registry.put(conversionWord, converterClass.getName());
/*     */   }
/*     */   
/*     */   void appender(String name, Appender<?> appender) {
/*  70 */     appender.setName(name);
/*  71 */     start((LifeCycle)appender);
/*     */   }
/*     */   
/*     */   void logger(String name, Level level) {
/*  75 */     logger(name, level, true);
/*     */   }
/*     */   
/*     */   void logger(String name, Level level, boolean additive) {
/*  79 */     logger(name, level, additive, null);
/*     */   }
/*     */   
/*     */   void logger(String name, Level level, boolean additive, Appender<ILoggingEvent> appender) {
/*  83 */     Logger logger = this.context.getLogger(name);
/*  84 */     if (level != null) {
/*  85 */       logger.setLevel(level);
/*     */     }
/*  87 */     logger.setAdditive(additive);
/*  88 */     if (appender != null) {
/*  89 */       logger.addAppender(appender);
/*     */     }
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   final void root(Level level, Appender<ILoggingEvent>... appenders) {
/*  95 */     Logger logger = this.context.getLogger("ROOT");
/*  96 */     if (level != null) {
/*  97 */       logger.setLevel(level);
/*     */     }
/*  99 */     for (Appender<ILoggingEvent> appender : appenders) {
/* 100 */       logger.addAppender(appender);
/*     */     }
/*     */   }
/*     */   
/*     */   void start(LifeCycle lifeCycle) {
/* 105 */     if (lifeCycle instanceof ContextAware) {
/* 106 */       ((ContextAware)lifeCycle).setContext((Context)this.context);
/*     */     }
/* 108 */     lifeCycle.start();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\logback\LogbackConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
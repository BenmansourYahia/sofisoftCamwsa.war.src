/*     */ package org.springframework.boot.logging.java;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.Logger;
/*     */ import org.springframework.boot.logging.AbstractLoggingSystem;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggerConfiguration;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaLoggingSystem
/*     */   extends AbstractLoggingSystem
/*     */ {
/*  53 */   private static final AbstractLoggingSystem.LogLevels<Level> LEVELS = new AbstractLoggingSystem.LogLevels();
/*     */   
/*  55 */   private final Set<Logger> configuredLoggers = Collections.synchronizedSet(new HashSet<>());
/*     */   
/*     */   static {
/*  58 */     LEVELS.map(LogLevel.TRACE, Level.FINEST);
/*  59 */     LEVELS.map(LogLevel.DEBUG, Level.FINE);
/*  60 */     LEVELS.map(LogLevel.INFO, Level.INFO);
/*  61 */     LEVELS.map(LogLevel.WARN, Level.WARNING);
/*  62 */     LEVELS.map(LogLevel.ERROR, Level.SEVERE);
/*  63 */     LEVELS.map(LogLevel.FATAL, Level.SEVERE);
/*  64 */     LEVELS.map(LogLevel.OFF, Level.OFF);
/*     */   }
/*     */   
/*     */   public JavaLoggingSystem(ClassLoader classLoader) {
/*  68 */     super(classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getStandardConfigLocations() {
/*  73 */     return new String[] { "logging.properties" };
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeInitialize() {
/*  78 */     super.beforeInitialize();
/*  79 */     Logger.getLogger("").setLevel(Level.SEVERE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void loadDefaults(LoggingInitializationContext initializationContext, LogFile logFile) {
/*  84 */     if (logFile != null) {
/*  85 */       loadConfiguration(getPackagedConfigFile("logging-file.properties"), logFile);
/*     */     } else {
/*     */       
/*  88 */       loadConfiguration(getPackagedConfigFile("logging.properties"), logFile);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadConfiguration(LoggingInitializationContext initializationContext, String location, LogFile logFile) {
/*  95 */     loadConfiguration(location, logFile);
/*     */   }
/*     */   
/*     */   protected void loadConfiguration(String location, LogFile logFile) {
/*  99 */     Assert.notNull(location, "Location must not be null");
/*     */     
/*     */     try {
/* 102 */       String configuration = FileCopyUtils.copyToString(new InputStreamReader(ResourceUtils.getURL(location).openStream()));
/* 103 */       if (logFile != null) {
/* 104 */         configuration = configuration.replace("${LOG_FILE}", StringUtils.cleanPath(logFile.toString()));
/*     */       }
/* 106 */       LogManager.getLogManager().readConfiguration(new ByteArrayInputStream(configuration.getBytes()));
/*     */     }
/* 108 */     catch (Exception ex) {
/* 109 */       throw new IllegalStateException("Could not initialize Java logging from " + location, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<LogLevel> getSupportedLogLevels() {
/* 115 */     return LEVELS.getSupported();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLogLevel(String loggerName, LogLevel level) {
/* 120 */     if (loggerName == null || "ROOT".equals(loggerName)) {
/* 121 */       loggerName = "";
/*     */     }
/* 123 */     Logger logger = Logger.getLogger(loggerName);
/* 124 */     if (logger != null) {
/* 125 */       this.configuredLoggers.add(logger);
/* 126 */       logger.setLevel((Level)LEVELS.convertSystemToNative(level));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<LoggerConfiguration> getLoggerConfigurations() {
/* 132 */     List<LoggerConfiguration> result = new ArrayList<>();
/* 133 */     Enumeration<String> names = LogManager.getLogManager().getLoggerNames();
/* 134 */     while (names.hasMoreElements()) {
/* 135 */       result.add(getLoggerConfiguration(names.nextElement()));
/*     */     }
/* 137 */     result.sort(CONFIGURATION_COMPARATOR);
/* 138 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public LoggerConfiguration getLoggerConfiguration(String loggerName) {
/* 143 */     Logger logger = Logger.getLogger(loggerName);
/* 144 */     if (logger == null) {
/* 145 */       return null;
/*     */     }
/* 147 */     LogLevel level = LEVELS.convertNativeToSystem(logger.getLevel());
/* 148 */     LogLevel effectiveLevel = LEVELS.convertNativeToSystem(getEffectiveLevel(logger));
/* 149 */     String name = StringUtils.hasLength(logger.getName()) ? logger.getName() : "ROOT";
/* 150 */     return new LoggerConfiguration(name, level, effectiveLevel);
/*     */   }
/*     */   
/*     */   private Level getEffectiveLevel(Logger root) {
/* 154 */     Logger logger = root;
/* 155 */     while (logger.getLevel() == null) {
/* 156 */       logger = logger.getParent();
/*     */     }
/* 158 */     return logger.getLevel();
/*     */   }
/*     */ 
/*     */   
/*     */   public Runnable getShutdownHandler() {
/* 163 */     return new ShutdownHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/* 168 */     this.configuredLoggers.clear();
/*     */   }
/*     */   
/*     */   private static final class ShutdownHandler implements Runnable {
/*     */     private ShutdownHandler() {}
/*     */     
/*     */     public void run() {
/* 175 */       LogManager.getLogManager().reset();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\java\JavaLoggingSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.logging.java;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.util.Date;
/*    */ import java.util.logging.Formatter;
/*    */ import java.util.logging.LogRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleFormatter
/*    */   extends Formatter
/*    */ {
/*    */   private static final String DEFAULT_FORMAT = "[%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS.%1$tL] - %8$s %4$s [%7$s] --- %3$s: %5$s%6$s%n";
/* 37 */   private final String format = getOrUseDefault("LOG_FORMAT", "[%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS.%1$tL] - %8$s %4$s [%7$s] --- %3$s: %5$s%6$s%n");
/*    */   
/* 39 */   private final String pid = getOrUseDefault("PID", "????");
/*    */   
/* 41 */   private final Date date = new Date();
/*    */ 
/*    */   
/*    */   public synchronized String format(LogRecord record) {
/* 45 */     this.date.setTime(record.getMillis());
/* 46 */     String source = record.getLoggerName();
/* 47 */     String message = formatMessage(record);
/* 48 */     String throwable = getThrowable(record);
/* 49 */     String thread = getThreadName();
/* 50 */     return String.format(this.format, new Object[] { this.date, source, record.getLoggerName(), record
/* 51 */           .getLevel().getLocalizedName(), message, throwable, thread, this.pid });
/*    */   }
/*    */   
/*    */   private String getThrowable(LogRecord record) {
/* 55 */     if (record.getThrown() == null) {
/* 56 */       return "";
/*    */     }
/* 58 */     StringWriter stringWriter = new StringWriter();
/* 59 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/* 60 */     printWriter.println();
/* 61 */     record.getThrown().printStackTrace(printWriter);
/* 62 */     printWriter.close();
/* 63 */     return stringWriter.toString();
/*    */   }
/*    */   
/*    */   private String getThreadName() {
/* 67 */     String name = Thread.currentThread().getName();
/* 68 */     return (name != null) ? name : "";
/*    */   }
/*    */   
/*    */   private static String getOrUseDefault(String key, String defaultValue) {
/* 72 */     String value = null;
/*    */     try {
/* 74 */       value = System.getenv(key);
/*    */     }
/* 76 */     catch (Exception exception) {}
/*    */ 
/*    */     
/* 79 */     if (value == null) {
/* 80 */       value = defaultValue;
/*    */     }
/* 82 */     return System.getProperty(key, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\java\SimpleFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
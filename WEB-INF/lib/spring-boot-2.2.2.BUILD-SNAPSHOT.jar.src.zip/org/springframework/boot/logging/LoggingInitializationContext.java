/*    */ package org.springframework.boot.logging;
/*    */ 
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingInitializationContext
/*    */ {
/*    */   private final ConfigurableEnvironment environment;
/*    */   
/*    */   public LoggingInitializationContext(ConfigurableEnvironment environment) {
/* 37 */     this.environment = environment;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Environment getEnvironment() {
/* 45 */     return (Environment)this.environment;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\LoggingInitializationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
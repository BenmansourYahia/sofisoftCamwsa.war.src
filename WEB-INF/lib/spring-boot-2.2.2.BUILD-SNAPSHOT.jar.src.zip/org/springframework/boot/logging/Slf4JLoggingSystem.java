/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.Logger;
/*     */ import org.slf4j.bridge.SLF4JBridgeHandler;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Slf4JLoggingSystem
/*     */   extends AbstractLoggingSystem
/*     */ {
/*     */   private static final String BRIDGE_HANDLER = "org.slf4j.bridge.SLF4JBridgeHandler";
/*     */   
/*     */   public Slf4JLoggingSystem(ClassLoader classLoader) {
/*  40 */     super(classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeInitialize() {
/*  45 */     super.beforeInitialize();
/*  46 */     configureJdkLoggingBridgeHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/*  51 */     if (isBridgeHandlerAvailable()) {
/*  52 */       removeJdkLoggingBridgeHandler();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadConfiguration(LoggingInitializationContext initializationContext, String location, LogFile logFile) {
/*  59 */     Assert.notNull(location, "Location must not be null");
/*  60 */     if (initializationContext != null) {
/*  61 */       applySystemProperties(initializationContext.getEnvironment(), logFile);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureJdkLoggingBridgeHandler() {
/*     */     try {
/*  67 */       if (isBridgeJulIntoSlf4j()) {
/*  68 */         removeJdkLoggingBridgeHandler();
/*  69 */         SLF4JBridgeHandler.install();
/*     */       }
/*     */     
/*  72 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isBridgeJulIntoSlf4j() {
/*  83 */     return (isBridgeHandlerAvailable() && isJulUsingASingleConsoleHandlerAtMost());
/*     */   }
/*     */   
/*     */   protected final boolean isBridgeHandlerAvailable() {
/*  87 */     return ClassUtils.isPresent("org.slf4j.bridge.SLF4JBridgeHandler", getClassLoader());
/*     */   }
/*     */   
/*     */   private boolean isJulUsingASingleConsoleHandlerAtMost() {
/*  91 */     Logger rootLogger = LogManager.getLogManager().getLogger("");
/*  92 */     Handler[] handlers = rootLogger.getHandlers();
/*  93 */     return (handlers.length == 0 || (handlers.length == 1 && handlers[0] instanceof java.util.logging.ConsoleHandler));
/*     */   }
/*     */   
/*     */   private void removeJdkLoggingBridgeHandler() {
/*     */     try {
/*  98 */       removeDefaultRootHandler();
/*  99 */       SLF4JBridgeHandler.uninstall();
/*     */     }
/* 101 */     catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeDefaultRootHandler() {
/*     */     try {
/* 108 */       Logger rootLogger = LogManager.getLogManager().getLogger("");
/* 109 */       Handler[] handlers = rootLogger.getHandlers();
/* 110 */       if (handlers.length == 1 && handlers[0] instanceof java.util.logging.ConsoleHandler) {
/* 111 */         rootLogger.removeHandler(handlers[0]);
/*     */       }
/*     */     }
/* 114 */     catch (Throwable throwable) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\Slf4JLoggingSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
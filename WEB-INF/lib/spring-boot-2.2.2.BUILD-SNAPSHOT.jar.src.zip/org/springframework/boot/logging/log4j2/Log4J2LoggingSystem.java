/*     */ package org.springframework.boot.logging.log4j2;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.core.Filter;
/*     */ import org.apache.logging.log4j.core.LogEvent;
/*     */ import org.apache.logging.log4j.core.Logger;
/*     */ import org.apache.logging.log4j.core.LoggerContext;
/*     */ import org.apache.logging.log4j.core.config.Configuration;
/*     */ import org.apache.logging.log4j.core.config.ConfigurationFactory;
/*     */ import org.apache.logging.log4j.core.config.ConfigurationSource;
/*     */ import org.apache.logging.log4j.core.config.LoggerConfig;
/*     */ import org.apache.logging.log4j.core.filter.AbstractFilter;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.springframework.boot.logging.AbstractLoggingSystem;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggerConfiguration;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.boot.logging.LoggingSystem;
/*     */ import org.springframework.boot.logging.Slf4JLoggingSystem;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log4J2LoggingSystem
/*     */   extends Slf4JLoggingSystem
/*     */ {
/*     */   private static final String FILE_PROTOCOL = "file";
/*  65 */   private static final AbstractLoggingSystem.LogLevels<Level> LEVELS = new AbstractLoggingSystem.LogLevels();
/*     */   
/*     */   static {
/*  68 */     LEVELS.map(LogLevel.TRACE, Level.TRACE);
/*  69 */     LEVELS.map(LogLevel.DEBUG, Level.DEBUG);
/*  70 */     LEVELS.map(LogLevel.INFO, Level.INFO);
/*  71 */     LEVELS.map(LogLevel.WARN, Level.WARN);
/*  72 */     LEVELS.map(LogLevel.ERROR, Level.ERROR);
/*  73 */     LEVELS.map(LogLevel.FATAL, Level.FATAL);
/*  74 */     LEVELS.map(LogLevel.OFF, Level.OFF);
/*     */   }
/*     */   
/*  77 */   private static final Filter FILTER = (Filter)new AbstractFilter()
/*     */     {
/*     */       public Filter.Result filter(LogEvent event)
/*     */       {
/*  81 */         return Filter.Result.DENY;
/*     */       }
/*     */ 
/*     */       
/*     */       public Filter.Result filter(Logger logger, Level level, Marker marker, Message msg, Throwable t) {
/*  86 */         return Filter.Result.DENY;
/*     */       }
/*     */ 
/*     */       
/*     */       public Filter.Result filter(Logger logger, Level level, Marker marker, Object msg, Throwable t) {
/*  91 */         return Filter.Result.DENY;
/*     */       }
/*     */ 
/*     */       
/*     */       public Filter.Result filter(Logger logger, Level level, Marker marker, String msg, Object... params) {
/*  96 */         return Filter.Result.DENY;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public Log4J2LoggingSystem(ClassLoader classLoader) {
/* 102 */     super(classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getStandardConfigLocations() {
/* 107 */     return getCurrentlySupportedConfigLocations();
/*     */   }
/*     */   
/*     */   private String[] getCurrentlySupportedConfigLocations() {
/* 111 */     List<String> supportedConfigLocations = new ArrayList<>();
/* 112 */     supportedConfigLocations.add("log4j2.properties");
/* 113 */     if (isClassAvailable("com.fasterxml.jackson.dataformat.yaml.YAMLParser")) {
/* 114 */       Collections.addAll(supportedConfigLocations, new String[] { "log4j2.yaml", "log4j2.yml" });
/*     */     }
/* 116 */     if (isClassAvailable("com.fasterxml.jackson.databind.ObjectMapper")) {
/* 117 */       Collections.addAll(supportedConfigLocations, new String[] { "log4j2.json", "log4j2.jsn" });
/*     */     }
/* 119 */     supportedConfigLocations.add("log4j2.xml");
/* 120 */     return StringUtils.toStringArray(supportedConfigLocations);
/*     */   }
/*     */   
/*     */   protected boolean isClassAvailable(String className) {
/* 124 */     return ClassUtils.isPresent(className, getClassLoader());
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeInitialize() {
/* 129 */     LoggerContext loggerContext = getLoggerContext();
/* 130 */     if (isAlreadyInitialized(loggerContext)) {
/*     */       return;
/*     */     }
/* 133 */     super.beforeInitialize();
/* 134 */     loggerContext.getConfiguration().addFilter(FILTER);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile) {
/* 139 */     LoggerContext loggerContext = getLoggerContext();
/* 140 */     if (isAlreadyInitialized(loggerContext)) {
/*     */       return;
/*     */     }
/* 143 */     loggerContext.getConfiguration().removeFilter(FILTER);
/* 144 */     super.initialize(initializationContext, configLocation, logFile);
/* 145 */     markAsInitialized(loggerContext);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void loadDefaults(LoggingInitializationContext initializationContext, LogFile logFile) {
/* 150 */     if (logFile != null) {
/* 151 */       loadConfiguration(getPackagedConfigFile("log4j2-file.xml"), logFile);
/*     */     } else {
/*     */       
/* 154 */       loadConfiguration(getPackagedConfigFile("log4j2.xml"), logFile);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadConfiguration(LoggingInitializationContext initializationContext, String location, LogFile logFile) {
/* 161 */     super.loadConfiguration(initializationContext, location, logFile);
/* 162 */     loadConfiguration(location, logFile);
/*     */   }
/*     */   
/*     */   protected void loadConfiguration(String location, LogFile logFile) {
/* 166 */     Assert.notNull(location, "Location must not be null");
/*     */     try {
/* 168 */       LoggerContext ctx = getLoggerContext();
/* 169 */       URL url = ResourceUtils.getURL(location);
/* 170 */       ConfigurationSource source = getConfigurationSource(url);
/* 171 */       ctx.start(ConfigurationFactory.getInstance().getConfiguration(ctx, source));
/*     */     }
/* 173 */     catch (Exception ex) {
/* 174 */       throw new IllegalStateException("Could not initialize Log4J2 logging from " + location, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ConfigurationSource getConfigurationSource(URL url) throws IOException {
/* 179 */     InputStream stream = url.openStream();
/* 180 */     if ("file".equals(url.getProtocol())) {
/* 181 */       return new ConfigurationSource(stream, ResourceUtils.getFile(url));
/*     */     }
/* 183 */     return new ConfigurationSource(stream, url);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reinitialize(LoggingInitializationContext initializationContext) {
/* 188 */     getLoggerContext().reconfigure();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<LogLevel> getSupportedLogLevels() {
/* 193 */     return LEVELS.getSupported();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLogLevel(String loggerName, LogLevel logLevel) {
/* 198 */     Level level = (Level)LEVELS.convertSystemToNative(logLevel);
/* 199 */     LoggerConfig loggerConfig = getLoggerConfig(loggerName);
/* 200 */     if (loggerConfig == null) {
/* 201 */       loggerConfig = new LoggerConfig(loggerName, level, true);
/* 202 */       getLoggerContext().getConfiguration().addLogger(loggerName, loggerConfig);
/*     */     } else {
/*     */       
/* 205 */       loggerConfig.setLevel(level);
/*     */     } 
/* 207 */     getLoggerContext().updateLoggers();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<LoggerConfiguration> getLoggerConfigurations() {
/* 212 */     List<LoggerConfiguration> result = new ArrayList<>();
/* 213 */     Configuration configuration = getLoggerContext().getConfiguration();
/* 214 */     for (LoggerConfig loggerConfig : configuration.getLoggers().values()) {
/* 215 */       result.add(convertLoggerConfiguration(loggerConfig));
/*     */     }
/* 217 */     result.sort(CONFIGURATION_COMPARATOR);
/* 218 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public LoggerConfiguration getLoggerConfiguration(String loggerName) {
/* 223 */     return convertLoggerConfiguration(getLoggerConfig(loggerName));
/*     */   }
/*     */   
/*     */   private LoggerConfiguration convertLoggerConfiguration(LoggerConfig loggerConfig) {
/* 227 */     if (loggerConfig == null) {
/* 228 */       return null;
/*     */     }
/* 230 */     LogLevel level = LEVELS.convertNativeToSystem(loggerConfig.getLevel());
/* 231 */     String name = loggerConfig.getName();
/* 232 */     if (!StringUtils.hasLength(name) || "".equals(name)) {
/* 233 */       name = "ROOT";
/*     */     }
/* 235 */     return new LoggerConfiguration(name, level, level);
/*     */   }
/*     */ 
/*     */   
/*     */   public Runnable getShutdownHandler() {
/* 240 */     return new ShutdownHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/* 245 */     super.cleanUp();
/* 246 */     LoggerContext loggerContext = getLoggerContext();
/* 247 */     markAsUninitialized(loggerContext);
/* 248 */     loggerContext.getConfiguration().removeFilter(FILTER);
/*     */   }
/*     */   
/*     */   private LoggerConfig getLoggerConfig(String name) {
/* 252 */     if (!StringUtils.hasLength(name) || "ROOT".equals(name)) {
/* 253 */       name = "";
/*     */     }
/* 255 */     return (LoggerConfig)getLoggerContext().getConfiguration().getLoggers().get(name);
/*     */   }
/*     */   
/*     */   private LoggerContext getLoggerContext() {
/* 259 */     return (LoggerContext)LogManager.getContext(false);
/*     */   }
/*     */   
/*     */   private boolean isAlreadyInitialized(LoggerContext loggerContext) {
/* 263 */     return LoggingSystem.class.getName().equals(loggerContext.getExternalContext());
/*     */   }
/*     */   
/*     */   private void markAsInitialized(LoggerContext loggerContext) {
/* 267 */     loggerContext.setExternalContext(LoggingSystem.class.getName());
/*     */   }
/*     */   
/*     */   private void markAsUninitialized(LoggerContext loggerContext) {
/* 271 */     loggerContext.setExternalContext(null);
/*     */   }
/*     */   
/*     */   private final class ShutdownHandler implements Runnable {
/*     */     private ShutdownHandler() {}
/*     */     
/*     */     public void run() {
/* 278 */       Log4J2LoggingSystem.this.getLoggerContext().stop();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\log4j2\Log4J2LoggingSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.logging.log4j2;
/*    */ 
/*    */ import org.apache.logging.log4j.core.LogEvent;
/*    */ import org.apache.logging.log4j.core.config.Configuration;
/*    */ import org.apache.logging.log4j.core.config.plugins.Plugin;
/*    */ import org.apache.logging.log4j.core.pattern.ConverterKeys;
/*    */ import org.apache.logging.log4j.core.pattern.ThrowablePatternConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(name = "WhitespaceThrowablePatternConverter", category = "Converter")
/*    */ @ConverterKeys({"wEx", "wThrowable", "wException"})
/*    */ public final class WhitespaceThrowablePatternConverter
/*    */   extends ThrowablePatternConverter
/*    */ {
/*    */   private WhitespaceThrowablePatternConverter(Configuration configuration, String[] options) {
/* 38 */     super("WhitespaceThrowable", "throwable", options, configuration);
/*    */   }
/*    */ 
/*    */   
/*    */   public void format(LogEvent event, StringBuilder buffer) {
/* 43 */     if (event.getThrown() != null) {
/* 44 */       buffer.append(this.options.getSeparator());
/* 45 */       super.format(event, buffer);
/* 46 */       buffer.append(this.options.getSeparator());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static WhitespaceThrowablePatternConverter newInstance(Configuration configuration, String[] options) {
/* 58 */     return new WhitespaceThrowablePatternConverter(configuration, options);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\logging\log4j2\WhitespaceThrowablePatternConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.ansi.AnsiPropertySource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceBanner
/*     */   implements Banner
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(ResourceBanner.class);
/*     */   
/*     */   private Resource resource;
/*     */   
/*     */   public ResourceBanner(Resource resource) {
/*  57 */     Assert.notNull(resource, "Resource must not be null");
/*  58 */     Assert.isTrue(resource.exists(), "Resource must exist");
/*  59 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) {
/*     */     try {
/*  65 */       String banner = StreamUtils.copyToString(this.resource.getInputStream(), (Charset)environment
/*  66 */           .getProperty("spring.banner.charset", Charset.class, StandardCharsets.UTF_8));
/*     */       
/*  68 */       for (PropertyResolver resolver : getPropertyResolvers(environment, sourceClass)) {
/*  69 */         banner = resolver.resolvePlaceholders(banner);
/*     */       }
/*  71 */       out.println(banner);
/*     */     }
/*  73 */     catch (Exception ex) {
/*  74 */       logger.warn(LogMessage.format("Banner not printable: %s (%s: '%s')", this.resource, ex.getClass(), ex
/*  75 */             .getMessage()), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected List<PropertyResolver> getPropertyResolvers(Environment environment, Class<?> sourceClass) {
/*  80 */     List<PropertyResolver> resolvers = new ArrayList<>();
/*  81 */     resolvers.add(environment);
/*  82 */     resolvers.add(getVersionResolver(sourceClass));
/*  83 */     resolvers.add(getAnsiResolver());
/*  84 */     resolvers.add(getTitleResolver(sourceClass));
/*  85 */     return resolvers;
/*     */   }
/*     */   
/*     */   private PropertyResolver getVersionResolver(Class<?> sourceClass) {
/*  89 */     MutablePropertySources propertySources = new MutablePropertySources();
/*  90 */     propertySources.addLast((PropertySource)new MapPropertySource("version", getVersionsMap(sourceClass)));
/*  91 */     return (PropertyResolver)new PropertySourcesPropertyResolver((PropertySources)propertySources);
/*     */   }
/*     */   
/*     */   private Map<String, Object> getVersionsMap(Class<?> sourceClass) {
/*  95 */     String appVersion = getApplicationVersion(sourceClass);
/*  96 */     String bootVersion = getBootVersion();
/*  97 */     Map<String, Object> versions = new HashMap<>();
/*  98 */     versions.put("application.version", getVersionString(appVersion, false));
/*  99 */     versions.put("spring-boot.version", getVersionString(bootVersion, false));
/* 100 */     versions.put("application.formatted-version", getVersionString(appVersion, true));
/* 101 */     versions.put("spring-boot.formatted-version", getVersionString(bootVersion, true));
/* 102 */     return versions;
/*     */   }
/*     */   
/*     */   protected String getApplicationVersion(Class<?> sourceClass) {
/* 106 */     Package sourcePackage = (sourceClass != null) ? sourceClass.getPackage() : null;
/* 107 */     return (sourcePackage != null) ? sourcePackage.getImplementationVersion() : null;
/*     */   }
/*     */   
/*     */   protected String getBootVersion() {
/* 111 */     return SpringBootVersion.getVersion();
/*     */   }
/*     */   
/*     */   private String getVersionString(String version, boolean format) {
/* 115 */     if (version == null) {
/* 116 */       return "";
/*     */     }
/* 118 */     return format ? (" (v" + version + ")") : version;
/*     */   }
/*     */   
/*     */   private PropertyResolver getAnsiResolver() {
/* 122 */     MutablePropertySources sources = new MutablePropertySources();
/* 123 */     sources.addFirst((PropertySource)new AnsiPropertySource("ansi", true));
/* 124 */     return (PropertyResolver)new PropertySourcesPropertyResolver((PropertySources)sources);
/*     */   }
/*     */   
/*     */   private PropertyResolver getTitleResolver(Class<?> sourceClass) {
/* 128 */     MutablePropertySources sources = new MutablePropertySources();
/* 129 */     String applicationTitle = getApplicationTitle(sourceClass);
/* 130 */     Map<String, Object> titleMap = Collections.singletonMap("application.title", (applicationTitle != null) ? applicationTitle : "");
/*     */     
/* 132 */     sources.addFirst((PropertySource)new MapPropertySource("title", titleMap));
/* 133 */     return (PropertyResolver)new PropertySourcesPropertyResolver((PropertySources)sources);
/*     */   }
/*     */   
/*     */   protected String getApplicationTitle(Class<?> sourceClass) {
/* 137 */     Package sourcePackage = (sourceClass != null) ? sourceClass.getPackage() : null;
/* 138 */     return (sourcePackage != null) ? sourcePackage.getImplementationTitle() : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\ResourceBanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
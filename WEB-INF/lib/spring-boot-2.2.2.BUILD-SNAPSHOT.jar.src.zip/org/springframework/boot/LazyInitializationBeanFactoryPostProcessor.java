/*    */ package org.springframework.boot;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LazyInitializationBeanFactoryPostProcessor
/*    */   implements BeanFactoryPostProcessor, Ordered
/*    */ {
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/* 47 */     Collection<LazyInitializationExcludeFilter> filters = beanFactory.getBeansOfType(LazyInitializationExcludeFilter.class, false, false).values();
/* 48 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 49 */       BeanDefinition beanDefinition = beanFactory.getBeanDefinition(beanName);
/* 50 */       if (beanDefinition instanceof AbstractBeanDefinition) {
/* 51 */         postProcess(beanFactory, filters, beanName, (AbstractBeanDefinition)beanDefinition);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void postProcess(ConfigurableListableBeanFactory beanFactory, Collection<LazyInitializationExcludeFilter> filters, String beanName, AbstractBeanDefinition beanDefinition) {
/* 59 */     Boolean lazyInit = beanDefinition.getLazyInit();
/* 60 */     if (lazyInit != null) {
/*    */       return;
/*    */     }
/* 63 */     Class<?> beanType = getBeanType(beanFactory, beanName);
/* 64 */     if (!isExcluded(filters, beanName, beanDefinition, beanType)) {
/* 65 */       beanDefinition.setLazyInit(true);
/*    */     }
/*    */   }
/*    */   
/*    */   private Class<?> getBeanType(ConfigurableListableBeanFactory beanFactory, String beanName) {
/*    */     try {
/* 71 */       return beanFactory.getType(beanName, false);
/*    */     }
/* 73 */     catch (NoSuchBeanDefinitionException ex) {
/* 74 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean isExcluded(Collection<LazyInitializationExcludeFilter> filters, String beanName, AbstractBeanDefinition beanDefinition, Class<?> beanType) {
/* 80 */     if (beanType != null) {
/* 81 */       for (LazyInitializationExcludeFilter filter : filters) {
/* 82 */         if (filter.isExcluded(beanName, (BeanDefinition)beanDefinition, beanType)) {
/* 83 */           return true;
/*    */         }
/*    */       } 
/*    */     }
/* 87 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 92 */     return Integer.MIN_VALUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\LazyInitializationBeanFactoryPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.builder;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.boot.Banner;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.WebApplicationType;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringApplicationBuilder
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private ConfigurableApplicationContext context;
/*     */   private SpringApplicationBuilder parent;
/*  78 */   private final AtomicBoolean running = new AtomicBoolean(false);
/*     */   
/*  80 */   private final Set<Class<?>> sources = new LinkedHashSet<>();
/*     */   
/*  82 */   private final Map<String, Object> defaultProperties = new LinkedHashMap<>();
/*     */   
/*     */   private ConfigurableEnvironment environment;
/*     */   
/*  86 */   private Set<String> additionalProfiles = new LinkedHashSet<>();
/*     */   
/*     */   private boolean registerShutdownHookApplied;
/*     */   
/*     */   private boolean configuredAsChild = false;
/*     */   
/*     */   public SpringApplicationBuilder(Class<?>... sources) {
/*  93 */     this.application = createSpringApplication(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpringApplication createSpringApplication(Class<?>... sources) {
/* 105 */     return new SpringApplication(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurableApplicationContext context() {
/* 113 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplication application() {
/* 121 */     return this.application;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurableApplicationContext run(String... args) {
/* 132 */     if (this.running.get())
/*     */     {
/* 134 */       return this.context;
/*     */     }
/* 136 */     configureAsChildIfNecessary(args);
/* 137 */     if (this.running.compareAndSet(false, true)) {
/* 138 */       synchronized (this.running) {
/*     */         
/* 140 */         this.context = build().run(args);
/*     */       } 
/*     */     }
/* 143 */     return this.context;
/*     */   }
/*     */   
/*     */   private void configureAsChildIfNecessary(String... args) {
/* 147 */     if (this.parent != null && !this.configuredAsChild) {
/* 148 */       this.configuredAsChild = true;
/* 149 */       if (!this.registerShutdownHookApplied) {
/* 150 */         this.application.setRegisterShutdownHook(false);
/*     */       }
/* 152 */       initializers((ApplicationContextInitializer<?>[])new ApplicationContextInitializer[] { new ParentContextApplicationContextInitializer((ApplicationContext)this.parent.run(args)) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplication build() {
/* 161 */     return build(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplication build(String... args) {
/* 171 */     configureAsChildIfNecessary(args);
/* 172 */     this.application.addPrimarySources(this.sources);
/* 173 */     return this.application;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder child(Class<?>... sources) {
/* 183 */     SpringApplicationBuilder child = new SpringApplicationBuilder(new Class[0]);
/* 184 */     child.sources(sources);
/*     */ 
/*     */     
/* 187 */     child.properties(this.defaultProperties).environment(this.environment)
/* 188 */       .additionalProfiles(this.additionalProfiles);
/* 189 */     child.parent = this;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     web(WebApplicationType.NONE);
/*     */ 
/*     */     
/* 197 */     bannerMode(Banner.Mode.OFF);
/*     */ 
/*     */     
/* 200 */     this.application.addPrimarySources(this.sources);
/*     */     
/* 202 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder parent(Class<?>... sources) {
/* 212 */     if (this.parent == null) {
/* 213 */       this
/* 214 */         .parent = (new SpringApplicationBuilder(sources)).web(WebApplicationType.NONE).properties(this.defaultProperties).environment(this.environment);
/*     */     } else {
/*     */       
/* 217 */       this.parent.sources(sources);
/*     */     } 
/* 219 */     return this.parent;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder runAndExtractParent(String... args) {
/* 223 */     if (this.context == null) {
/* 224 */       run(args);
/*     */     }
/* 226 */     if (this.parent != null) {
/* 227 */       return this.parent;
/*     */     }
/* 229 */     throw new IllegalStateException("No parent defined yet (please use the other overloaded parent methods to set one)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder parent(ConfigurableApplicationContext parent) {
/* 239 */     this.parent = new SpringApplicationBuilder(new Class[0]);
/* 240 */     this.parent.context = parent;
/* 241 */     this.parent.running.set(true);
/* 242 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder sibling(Class<?>... sources) {
/* 255 */     return runAndExtractParent(new String[0]).child(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder sibling(Class<?>[] sources, String... args) {
/* 268 */     return runAndExtractParent(args).child(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder contextClass(Class<? extends ConfigurableApplicationContext> cls) {
/* 277 */     this.application.setApplicationContextClass(cls);
/* 278 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder sources(Class<?>... sources) {
/* 287 */     this.sources.addAll(new LinkedHashSet<>(Arrays.asList(sources)));
/* 288 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder web(WebApplicationType webApplicationType) {
/* 299 */     this.application.setWebApplicationType(webApplicationType);
/* 300 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder logStartupInfo(boolean logStartupInfo) {
/* 309 */     this.application.setLogStartupInfo(logStartupInfo);
/* 310 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder banner(Banner banner) {
/* 320 */     this.application.setBanner(banner);
/* 321 */     return this;
/*     */   }
/*     */   
/*     */   public SpringApplicationBuilder bannerMode(Banner.Mode bannerMode) {
/* 325 */     this.application.setBannerMode(bannerMode);
/* 326 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder headless(boolean headless) {
/* 336 */     this.application.setHeadless(headless);
/* 337 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder registerShutdownHook(boolean registerShutdownHook) {
/* 347 */     this.registerShutdownHookApplied = true;
/* 348 */     this.application.setRegisterShutdownHook(registerShutdownHook);
/* 349 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder main(Class<?> mainApplicationClass) {
/* 358 */     this.application.setMainApplicationClass(mainApplicationClass);
/* 359 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder addCommandLineProperties(boolean addCommandLineProperties) {
/* 368 */     this.application.setAddCommandLineProperties(addCommandLineProperties);
/* 369 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder setAddConversionService(boolean addConversionService) {
/* 380 */     this.application.setAddConversionService(addConversionService);
/* 381 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder properties(String... defaultProperties) {
/* 391 */     return properties(getMapFromKeyValuePairs(defaultProperties));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder lazyInitialization(boolean lazyInitialization) {
/* 401 */     this.application.setLazyInitialization(lazyInitialization);
/* 402 */     return this;
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromKeyValuePairs(String[] properties) {
/* 406 */     Map<String, Object> map = new HashMap<>();
/* 407 */     for (String property : properties) {
/* 408 */       int index = lowestIndexOf(property, new String[] { ":", "=" });
/* 409 */       String key = (index > 0) ? property.substring(0, index) : property;
/* 410 */       String value = (index > 0) ? property.substring(index + 1) : "";
/* 411 */       map.put(key, value);
/*     */     } 
/* 413 */     return map;
/*     */   }
/*     */   
/*     */   private int lowestIndexOf(String property, String... candidates) {
/* 417 */     int index = -1;
/* 418 */     for (String candidate : candidates) {
/* 419 */       int candidateIndex = property.indexOf(candidate);
/* 420 */       if (candidateIndex > 0) {
/* 421 */         index = (index != -1) ? Math.min(index, candidateIndex) : candidateIndex;
/*     */       }
/*     */     } 
/* 424 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder properties(Properties defaultProperties) {
/* 434 */     return properties(getMapFromProperties(defaultProperties));
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromProperties(Properties properties) {
/* 438 */     Map<String, Object> map = new HashMap<>();
/* 439 */     for (Object key : Collections.list(properties.propertyNames())) {
/* 440 */       map.put((String)key, properties.get(key));
/*     */     }
/* 442 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder properties(Map<String, Object> defaults) {
/* 453 */     this.defaultProperties.putAll(defaults);
/* 454 */     this.application.setDefaultProperties(this.defaultProperties);
/* 455 */     if (this.parent != null) {
/* 456 */       this.parent.properties(this.defaultProperties);
/* 457 */       this.parent.environment(this.environment);
/*     */     } 
/* 459 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder profiles(String... profiles) {
/* 468 */     this.additionalProfiles.addAll(Arrays.asList(profiles));
/* 469 */     this.application.setAdditionalProfiles(StringUtils.toStringArray(this.additionalProfiles));
/* 470 */     return this;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder additionalProfiles(Collection<String> additionalProfiles) {
/* 474 */     this.additionalProfiles = new LinkedHashSet<>(additionalProfiles);
/* 475 */     this.application.setAdditionalProfiles(StringUtils.toStringArray(this.additionalProfiles));
/* 476 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder beanNameGenerator(BeanNameGenerator beanNameGenerator) {
/* 486 */     this.application.setBeanNameGenerator(beanNameGenerator);
/* 487 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder environment(ConfigurableEnvironment environment) {
/* 496 */     this.application.setEnvironment(environment);
/* 497 */     this.environment = environment;
/* 498 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder resourceLoader(ResourceLoader resourceLoader) {
/* 508 */     this.application.setResourceLoader(resourceLoader);
/* 509 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder initializers(ApplicationContextInitializer<?>... initializers) {
/* 519 */     this.application.addInitializers((ApplicationContextInitializer[])initializers);
/* 520 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder listeners(ApplicationListener<?>... listeners) {
/* 532 */     this.application.addListeners((ApplicationListener[])listeners);
/* 533 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\builder\SpringApplicationBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
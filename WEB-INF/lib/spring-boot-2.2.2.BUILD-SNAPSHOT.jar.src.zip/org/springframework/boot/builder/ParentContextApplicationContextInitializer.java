/*    */ package org.springframework.boot.builder;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.context.event.ContextRefreshedEvent;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParentContextApplicationContextInitializer
/*    */   implements ApplicationContextInitializer<ConfigurableApplicationContext>, Ordered
/*    */ {
/* 38 */   private int order = Integer.MIN_VALUE;
/*    */   
/*    */   private final ApplicationContext parent;
/*    */   
/*    */   public ParentContextApplicationContextInitializer(ApplicationContext parent) {
/* 43 */     this.parent = parent;
/*    */   }
/*    */   
/*    */   public void setOrder(int order) {
/* 47 */     this.order = order;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 52 */     return this.order;
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize(ConfigurableApplicationContext applicationContext) {
/* 57 */     if (applicationContext != this.parent) {
/* 58 */       applicationContext.setParent(this.parent);
/* 59 */       applicationContext.addApplicationListener(EventPublisher.INSTANCE);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static class EventPublisher
/*    */     implements ApplicationListener<ContextRefreshedEvent>, Ordered {
/* 65 */     private static final EventPublisher INSTANCE = new EventPublisher();
/*    */ 
/*    */     
/*    */     public int getOrder() {
/* 69 */       return Integer.MIN_VALUE;
/*    */     }
/*    */ 
/*    */     
/*    */     public void onApplicationEvent(ContextRefreshedEvent event) {
/* 74 */       ApplicationContext context = event.getApplicationContext();
/* 75 */       if (context instanceof ConfigurableApplicationContext && context == event.getSource()) {
/* 76 */         context.publishEvent(new ParentContextApplicationContextInitializer.ParentContextAvailableEvent((ConfigurableApplicationContext)context));
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class ParentContextAvailableEvent
/*    */     extends ApplicationEvent
/*    */   {
/*    */     public ParentContextAvailableEvent(ConfigurableApplicationContext applicationContext) {
/* 89 */       super(applicationContext);
/*    */     }
/*    */     
/*    */     public ConfigurableApplicationContext getApplicationContext() {
/* 93 */       return (ConfigurableApplicationContext)getSource();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\builder\ParentContextApplicationContextInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
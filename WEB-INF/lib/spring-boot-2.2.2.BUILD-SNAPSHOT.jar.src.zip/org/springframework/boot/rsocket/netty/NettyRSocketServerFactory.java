/*     */ package org.springframework.boot.rsocket.netty;
/*     */ 
/*     */ import io.rsocket.RSocketFactory;
/*     */ import io.rsocket.SocketAcceptor;
/*     */ import io.rsocket.transport.ServerTransport;
/*     */ import io.rsocket.transport.netty.server.CloseableChannel;
/*     */ import io.rsocket.transport.netty.server.TcpServerTransport;
/*     */ import io.rsocket.transport.netty.server.WebsocketServerTransport;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.rsocket.server.ConfigurableRSocketServerFactory;
/*     */ import org.springframework.boot.rsocket.server.RSocketServer;
/*     */ import org.springframework.boot.rsocket.server.RSocketServerFactory;
/*     */ import org.springframework.boot.rsocket.server.ServerRSocketFactoryProcessor;
/*     */ import org.springframework.http.client.reactive.ReactorResourceFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.http.server.HttpServer;
/*     */ import reactor.netty.tcp.TcpServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NettyRSocketServerFactory
/*     */   implements RSocketServerFactory, ConfigurableRSocketServerFactory
/*     */ {
/*  54 */   private int port = 9898;
/*     */   
/*     */   private InetAddress address;
/*     */   
/*  58 */   private RSocketServer.Transport transport = RSocketServer.Transport.TCP;
/*     */   
/*     */   private ReactorResourceFactory resourceFactory;
/*     */   
/*     */   private Duration lifecycleTimeout;
/*     */   
/*  64 */   private List<ServerRSocketFactoryProcessor> socketFactoryProcessors = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public void setPort(int port) {
/*  68 */     this.port = port;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAddress(InetAddress address) {
/*  73 */     this.address = address;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransport(RSocketServer.Transport transport) {
/*  78 */     this.transport = transport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceFactory(ReactorResourceFactory resourceFactory) {
/*  86 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSocketFactoryProcessors(Collection<? extends ServerRSocketFactoryProcessor> socketFactoryProcessors) {
/*  97 */     Assert.notNull(socketFactoryProcessors, "SocketFactoryProcessors must not be null");
/*  98 */     this.socketFactoryProcessors = new ArrayList<>(socketFactoryProcessors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSocketFactoryProcessors(ServerRSocketFactoryProcessor... socketFactoryProcessors) {
/* 107 */     Assert.notNull(socketFactoryProcessors, "SocketFactoryProcessors must not be null");
/* 108 */     this.socketFactoryProcessors.addAll(Arrays.asList(socketFactoryProcessors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLifecycleTimeout(Duration lifecycleTimeout) {
/* 117 */     this.lifecycleTimeout = lifecycleTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyRSocketServer create(SocketAcceptor socketAcceptor) {
/* 122 */     ServerTransport<CloseableChannel> transport = createTransport();
/* 123 */     RSocketFactory.ServerRSocketFactory factory = RSocketFactory.receive();
/* 124 */     for (ServerRSocketFactoryProcessor processor : this.socketFactoryProcessors) {
/* 125 */       factory = processor.process(factory);
/*     */     }
/* 127 */     Mono<CloseableChannel> starter = factory.acceptor(socketAcceptor).transport(transport).start();
/* 128 */     return new NettyRSocketServer(starter, this.lifecycleTimeout);
/*     */   }
/*     */   
/*     */   private ServerTransport<CloseableChannel> createTransport() {
/* 132 */     if (this.transport == RSocketServer.Transport.WEBSOCKET) {
/* 133 */       return createWebSocketTransport();
/*     */     }
/* 135 */     return createTcpTransport();
/*     */   }
/*     */   
/*     */   private ServerTransport<CloseableChannel> createWebSocketTransport() {
/* 139 */     if (this.resourceFactory != null) {
/* 140 */       HttpServer httpServer = HttpServer.create().tcpConfiguration(tcpServer -> tcpServer.runOn(this.resourceFactory.getLoopResources()).addressSupplier(this::getListenAddress));
/*     */       
/* 142 */       return (ServerTransport<CloseableChannel>)WebsocketServerTransport.create(httpServer);
/*     */     } 
/* 144 */     return (ServerTransport<CloseableChannel>)WebsocketServerTransport.create(getListenAddress());
/*     */   }
/*     */   
/*     */   private ServerTransport<CloseableChannel> createTcpTransport() {
/* 148 */     if (this.resourceFactory != null) {
/*     */       
/* 150 */       TcpServer tcpServer = TcpServer.create().runOn(this.resourceFactory.getLoopResources()).addressSupplier(this::getListenAddress);
/* 151 */       return (ServerTransport<CloseableChannel>)TcpServerTransport.create(tcpServer);
/*     */     } 
/* 153 */     return (ServerTransport<CloseableChannel>)TcpServerTransport.create(getListenAddress());
/*     */   }
/*     */   
/*     */   private InetSocketAddress getListenAddress() {
/* 157 */     if (this.address != null) {
/* 158 */       return new InetSocketAddress(this.address.getHostAddress(), this.port);
/*     */     }
/* 160 */     return new InetSocketAddress(this.port);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\rsocket\netty\NettyRSocketServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
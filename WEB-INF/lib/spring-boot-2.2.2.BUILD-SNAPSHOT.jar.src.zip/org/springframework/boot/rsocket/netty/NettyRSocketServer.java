/*    */ package org.springframework.boot.rsocket.netty;
/*    */ 
/*    */ import io.rsocket.transport.netty.server.CloseableChannel;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.time.Duration;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.rsocket.server.RSocketServer;
/*    */ import org.springframework.boot.rsocket.server.RSocketServerException;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NettyRSocketServer
/*    */   implements RSocketServer
/*    */ {
/* 40 */   private static final Log logger = LogFactory.getLog(NettyRSocketServer.class);
/*    */   
/*    */   private final Mono<CloseableChannel> starter;
/*    */   
/*    */   private final Duration lifecycleTimeout;
/*    */   
/*    */   private CloseableChannel channel;
/*    */   
/*    */   public NettyRSocketServer(Mono<CloseableChannel> starter, Duration lifecycleTimeout) {
/* 49 */     Assert.notNull(starter, "starter must not be null");
/* 50 */     this.starter = starter;
/* 51 */     this.lifecycleTimeout = lifecycleTimeout;
/*    */   }
/*    */ 
/*    */   
/*    */   public InetSocketAddress address() {
/* 56 */     if (this.channel != null) {
/* 57 */       return this.channel.address();
/*    */     }
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void start() throws RSocketServerException {
/* 64 */     this.channel = block(this.starter, this.lifecycleTimeout);
/* 65 */     logger.info("Netty RSocket started on port(s): " + address().getPort());
/* 66 */     startDaemonAwaitThread(this.channel);
/*    */   }
/*    */   
/*    */   private void startDaemonAwaitThread(CloseableChannel channel) {
/* 70 */     Thread awaitThread = new Thread(() -> (Void)channel.onClose().block(), "rsocket");
/* 71 */     awaitThread.setContextClassLoader(getClass().getClassLoader());
/* 72 */     awaitThread.setDaemon(false);
/* 73 */     awaitThread.start();
/*    */   }
/*    */ 
/*    */   
/*    */   public void stop() throws RSocketServerException {
/* 78 */     if (this.channel != null) {
/* 79 */       this.channel.dispose();
/* 80 */       this.channel = null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private <T> T block(Mono<T> mono, Duration timeout) {
/* 85 */     return (timeout != null) ? (T)mono.block(timeout) : (T)mono.block();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\rsocket\netty\NettyRSocketServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
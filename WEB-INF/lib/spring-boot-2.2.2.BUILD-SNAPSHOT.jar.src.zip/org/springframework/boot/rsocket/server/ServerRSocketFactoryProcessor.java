package org.springframework.boot.rsocket.server;

import io.rsocket.RSocketFactory;

@FunctionalInterface
public interface ServerRSocketFactoryProcessor {
  RSocketFactory.ServerRSocketFactory process(RSocketFactory.ServerRSocketFactory paramServerRSocketFactory);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\rsocket\server\ServerRSocketFactoryProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
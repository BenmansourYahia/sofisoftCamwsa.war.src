/*    */ package org.springframework.boot.rsocket.server;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RSocketServer
/*    */ {
/*    */   void start() throws RSocketServerException;
/*    */   
/*    */   void stop() throws RSocketServerException;
/*    */   
/*    */   InetSocketAddress address();
/*    */   
/*    */   public enum Transport
/*    */   {
/* 58 */     TCP,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 63 */     WEBSOCKET;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\rsocket\server\RSocketServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
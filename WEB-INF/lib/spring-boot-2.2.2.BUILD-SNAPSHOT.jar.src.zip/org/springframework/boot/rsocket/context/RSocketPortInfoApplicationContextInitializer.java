/*    */ package org.springframework.boot.rsocket.context;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.MapPropertySource;
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RSocketPortInfoApplicationContextInitializer
/*    */   implements ApplicationContextInitializer<ConfigurableApplicationContext>
/*    */ {
/*    */   public void initialize(ConfigurableApplicationContext applicationContext) {
/* 51 */     applicationContext.addApplicationListener(new Listener(applicationContext));
/*    */   }
/*    */   
/*    */   private static class Listener
/*    */     implements ApplicationListener<RSocketServerInitializedEvent>
/*    */   {
/*    */     private static final String PROPERTY_NAME = "local.rsocket.server.port";
/*    */     private final ConfigurableApplicationContext applicationContext;
/*    */     
/*    */     Listener(ConfigurableApplicationContext applicationContext) {
/* 61 */       this.applicationContext = applicationContext;
/*    */     }
/*    */ 
/*    */     
/*    */     public void onApplicationEvent(RSocketServerInitializedEvent event) {
/* 66 */       setPortProperty((ApplicationContext)this.applicationContext, event.getServer().address().getPort());
/*    */     }
/*    */     
/*    */     private void setPortProperty(ApplicationContext context, int port) {
/* 70 */       if (context instanceof ConfigurableApplicationContext) {
/* 71 */         setPortProperty(((ConfigurableApplicationContext)context).getEnvironment(), port);
/*    */       }
/* 73 */       if (context.getParent() != null)
/* 74 */         setPortProperty(context.getParent(), port); 
/*    */     }
/*    */     
/*    */     private void setPortProperty(ConfigurableEnvironment environment, int port) {
/*    */       MapPropertySource mapPropertySource;
/* 79 */       MutablePropertySources sources = environment.getPropertySources();
/* 80 */       PropertySource<?> source = sources.get("server.ports");
/* 81 */       if (source == null) {
/* 82 */         mapPropertySource = new MapPropertySource("server.ports", new HashMap<>());
/* 83 */         sources.addFirst((PropertySource)mapPropertySource);
/*    */       } 
/* 85 */       setPortProperty(port, (PropertySource<?>)mapPropertySource);
/*    */     }
/*    */ 
/*    */     
/*    */     private void setPortProperty(int port, PropertySource<?> source) {
/* 90 */       ((Map<String, Integer>)source.getSource()).put("local.rsocket.server.port", Integer.valueOf(port));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\rsocket\context\RSocketPortInfoApplicationContextInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.rsocket.context;
/*    */ 
/*    */ import io.rsocket.SocketAcceptor;
/*    */ import org.springframework.boot.rsocket.server.RSocketServer;
/*    */ import org.springframework.boot.rsocket.server.RSocketServerFactory;
/*    */ import org.springframework.context.ApplicationEventPublisher;
/*    */ import org.springframework.context.ApplicationEventPublisherAware;
/*    */ import org.springframework.context.SmartLifecycle;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RSocketServerBootstrap
/*    */   implements ApplicationEventPublisherAware, SmartLifecycle
/*    */ {
/*    */   private final RSocketServer server;
/*    */   private ApplicationEventPublisher eventPublisher;
/*    */   
/*    */   public RSocketServerBootstrap(RSocketServerFactory serverFactory, SocketAcceptor socketAcceptor) {
/* 41 */     Assert.notNull(serverFactory, "ServerFactory must not be null");
/* 42 */     this.server = serverFactory.create(socketAcceptor);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 47 */     this.eventPublisher = applicationEventPublisher;
/*    */   }
/*    */ 
/*    */   
/*    */   public void start() {
/* 52 */     this.server.start();
/* 53 */     this.eventPublisher.publishEvent(new RSocketServerInitializedEvent(this.server));
/*    */   }
/*    */ 
/*    */   
/*    */   public void stop() {
/* 58 */     this.server.stop();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRunning() {
/* 63 */     RSocketServer server = this.server;
/* 64 */     if (server != null) {
/* 65 */       return (server.address() != null);
/*    */     }
/* 67 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\rsocket\context\RSocketServerBootstrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.task;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.core.task.TaskDecorator;
/*     */ import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskExecutorBuilder
/*     */ {
/*     */   private final Integer queueCapacity;
/*     */   private final Integer corePoolSize;
/*     */   private final Integer maxPoolSize;
/*     */   private final Boolean allowCoreThreadTimeOut;
/*     */   private final Duration keepAlive;
/*     */   private final Boolean awaitTermination;
/*     */   private final Duration awaitTerminationPeriod;
/*     */   private final String threadNamePrefix;
/*     */   private final TaskDecorator taskDecorator;
/*     */   private final Set<TaskExecutorCustomizer> customizers;
/*     */   
/*     */   public TaskExecutorBuilder() {
/*  69 */     this.queueCapacity = null;
/*  70 */     this.corePoolSize = null;
/*  71 */     this.maxPoolSize = null;
/*  72 */     this.allowCoreThreadTimeOut = null;
/*  73 */     this.keepAlive = null;
/*  74 */     this.awaitTermination = null;
/*  75 */     this.awaitTerminationPeriod = null;
/*  76 */     this.threadNamePrefix = null;
/*  77 */     this.taskDecorator = null;
/*  78 */     this.customizers = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TaskExecutorBuilder(Integer queueCapacity, Integer corePoolSize, Integer maxPoolSize, Boolean allowCoreThreadTimeOut, Duration keepAlive, Boolean awaitTermination, Duration awaitTerminationPeriod, String threadNamePrefix, TaskDecorator taskDecorator, Set<TaskExecutorCustomizer> customizers) {
/*  85 */     this.queueCapacity = queueCapacity;
/*  86 */     this.corePoolSize = corePoolSize;
/*  87 */     this.maxPoolSize = maxPoolSize;
/*  88 */     this.allowCoreThreadTimeOut = allowCoreThreadTimeOut;
/*  89 */     this.keepAlive = keepAlive;
/*  90 */     this.awaitTermination = awaitTermination;
/*  91 */     this.awaitTerminationPeriod = awaitTerminationPeriod;
/*  92 */     this.threadNamePrefix = threadNamePrefix;
/*  93 */     this.taskDecorator = taskDecorator;
/*  94 */     this.customizers = customizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder queueCapacity(int queueCapacity) {
/* 104 */     return new TaskExecutorBuilder(Integer.valueOf(queueCapacity), this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder corePoolSize(int corePoolSize) {
/* 119 */     return new TaskExecutorBuilder(this.queueCapacity, Integer.valueOf(corePoolSize), this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder maxPoolSize(int maxPoolSize) {
/* 134 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, Integer.valueOf(maxPoolSize), this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder allowCoreThreadTimeOut(boolean allowCoreThreadTimeOut) {
/* 146 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, Boolean.valueOf(allowCoreThreadTimeOut), this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder keepAlive(Duration keepAlive) {
/* 157 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder awaitTermination(boolean awaitTermination) {
/* 171 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, 
/* 172 */         Boolean.valueOf(awaitTermination), this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder awaitTerminationPeriod(Duration awaitTerminationPeriod) {
/* 186 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder threadNamePrefix(String threadNamePrefix) {
/* 197 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, threadNamePrefix, this.taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder taskDecorator(TaskDecorator taskDecorator) {
/* 208 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, taskDecorator, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder customizers(TaskExecutorCustomizer... customizers) {
/* 223 */     Assert.notNull(customizers, "Customizers must not be null");
/* 224 */     return customizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder customizers(Iterable<TaskExecutorCustomizer> customizers) {
/* 237 */     Assert.notNull(customizers, "Customizers must not be null");
/* 238 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, 
/*     */         
/* 240 */         append(null, customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder additionalCustomizers(TaskExecutorCustomizer... customizers) {
/* 252 */     Assert.notNull(customizers, "Customizers must not be null");
/* 253 */     return additionalCustomizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskExecutorBuilder additionalCustomizers(Iterable<TaskExecutorCustomizer> customizers) {
/* 265 */     Assert.notNull(customizers, "Customizers must not be null");
/* 266 */     return new TaskExecutorBuilder(this.queueCapacity, this.corePoolSize, this.maxPoolSize, this.allowCoreThreadTimeOut, this.keepAlive, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.taskDecorator, 
/*     */         
/* 268 */         append(this.customizers, customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreadPoolTaskExecutor build() {
/* 279 */     return build(ThreadPoolTaskExecutor.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ThreadPoolTaskExecutor> T build(Class<T> taskExecutorClass) {
/* 292 */     return configure((T)BeanUtils.instantiateClass(taskExecutorClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ThreadPoolTaskExecutor> T configure(T taskExecutor) {
/* 304 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 305 */     map.from(this.queueCapacity).to(taskExecutor::setQueueCapacity);
/* 306 */     map.from(this.corePoolSize).to(taskExecutor::setCorePoolSize);
/* 307 */     map.from(this.maxPoolSize).to(taskExecutor::setMaxPoolSize);
/* 308 */     map.from(this.keepAlive).asInt(Duration::getSeconds).to(taskExecutor::setKeepAliveSeconds);
/* 309 */     map.from(this.allowCoreThreadTimeOut).to(taskExecutor::setAllowCoreThreadTimeOut);
/* 310 */     map.from(this.awaitTermination).to(taskExecutor::setWaitForTasksToCompleteOnShutdown);
/* 311 */     map.from(this.awaitTerminationPeriod).asInt(Duration::getSeconds).to(taskExecutor::setAwaitTerminationSeconds);
/* 312 */     map.from(this.threadNamePrefix).whenHasText().to(taskExecutor::setThreadNamePrefix);
/* 313 */     map.from(this.taskDecorator).to(taskExecutor::setTaskDecorator);
/* 314 */     if (!CollectionUtils.isEmpty(this.customizers)) {
/* 315 */       this.customizers.forEach(customizer -> customizer.customize(taskExecutor));
/*     */     }
/* 317 */     return taskExecutor;
/*     */   }
/*     */   
/*     */   private <T> Set<T> append(Set<T> set, Iterable<? extends T> additions) {
/* 321 */     Set<T> result = new LinkedHashSet<>((set != null) ? set : Collections.<T>emptySet());
/* 322 */     additions.forEach(result::add);
/* 323 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\task\TaskExecutorBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
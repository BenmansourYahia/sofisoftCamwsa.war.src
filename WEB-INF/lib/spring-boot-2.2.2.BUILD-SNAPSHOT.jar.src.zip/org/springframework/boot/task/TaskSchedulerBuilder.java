/*     */ package org.springframework.boot.task;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskSchedulerBuilder
/*     */ {
/*     */   private final Integer poolSize;
/*     */   private final Boolean awaitTermination;
/*     */   private final Duration awaitTerminationPeriod;
/*     */   private final String threadNamePrefix;
/*     */   private final Set<TaskSchedulerCustomizer> customizers;
/*     */   
/*     */   public TaskSchedulerBuilder() {
/*  55 */     this.poolSize = null;
/*  56 */     this.awaitTermination = null;
/*  57 */     this.awaitTerminationPeriod = null;
/*  58 */     this.threadNamePrefix = null;
/*  59 */     this.customizers = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder(Integer poolSize, Boolean awaitTermination, Duration awaitTerminationPeriod, String threadNamePrefix, Set<TaskSchedulerCustomizer> taskSchedulerCustomizers) {
/*  64 */     this.poolSize = poolSize;
/*  65 */     this.awaitTermination = awaitTermination;
/*  66 */     this.awaitTerminationPeriod = awaitTerminationPeriod;
/*  67 */     this.threadNamePrefix = threadNamePrefix;
/*  68 */     this.customizers = taskSchedulerCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder poolSize(int poolSize) {
/*  77 */     return new TaskSchedulerBuilder(Integer.valueOf(poolSize), this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder awaitTermination(boolean awaitTermination) {
/*  90 */     return new TaskSchedulerBuilder(this.poolSize, Boolean.valueOf(awaitTermination), this.awaitTerminationPeriod, this.threadNamePrefix, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder awaitTerminationPeriod(Duration awaitTerminationPeriod) {
/* 104 */     return new TaskSchedulerBuilder(this.poolSize, this.awaitTermination, awaitTerminationPeriod, this.threadNamePrefix, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder threadNamePrefix(String threadNamePrefix) {
/* 114 */     return new TaskSchedulerBuilder(this.poolSize, this.awaitTermination, this.awaitTerminationPeriod, threadNamePrefix, this.customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder customizers(TaskSchedulerCustomizer... customizers) {
/* 128 */     Assert.notNull(customizers, "Customizers must not be null");
/* 129 */     return customizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder customizers(Iterable<TaskSchedulerCustomizer> customizers) {
/* 142 */     Assert.notNull(customizers, "Customizers must not be null");
/* 143 */     return new TaskSchedulerBuilder(this.poolSize, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, 
/* 144 */         append(null, customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder additionalCustomizers(TaskSchedulerCustomizer... customizers) {
/* 156 */     Assert.notNull(customizers, "Customizers must not be null");
/* 157 */     return additionalCustomizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskSchedulerBuilder additionalCustomizers(Iterable<TaskSchedulerCustomizer> customizers) {
/* 169 */     Assert.notNull(customizers, "Customizers must not be null");
/* 170 */     return new TaskSchedulerBuilder(this.poolSize, this.awaitTermination, this.awaitTerminationPeriod, this.threadNamePrefix, 
/* 171 */         append(this.customizers, customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreadPoolTaskScheduler build() {
/* 181 */     return configure(new ThreadPoolTaskScheduler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ThreadPoolTaskScheduler> T configure(T taskScheduler) {
/* 192 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 193 */     map.from(this.poolSize).to(taskScheduler::setPoolSize);
/* 194 */     map.from(this.awaitTermination).to(taskScheduler::setWaitForTasksToCompleteOnShutdown);
/* 195 */     map.from(this.awaitTerminationPeriod).asInt(Duration::getSeconds).to(taskScheduler::setAwaitTerminationSeconds);
/* 196 */     map.from(this.threadNamePrefix).to(taskScheduler::setThreadNamePrefix);
/* 197 */     if (!CollectionUtils.isEmpty(this.customizers)) {
/* 198 */       this.customizers.forEach(customizer -> customizer.customize(taskScheduler));
/*     */     }
/* 200 */     return taskScheduler;
/*     */   }
/*     */   
/*     */   private <T> Set<T> append(Set<T> set, Iterable<? extends T> additions) {
/* 204 */     Set<T> result = new LinkedHashSet<>((set != null) ? set : Collections.<T>emptySet());
/* 205 */     additions.forEach(result::add);
/* 206 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\task\TaskSchedulerBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LambdaSafe
/*     */ {
/*  51 */   private static final Method CLASS_GET_MODULE = ReflectionUtils.findMethod(Class.class, "getModule");
/*  52 */   private static final Method MODULE_GET_NAME = (CLASS_GET_MODULE != null) ? 
/*  53 */     ReflectionUtils.findMethod(CLASS_GET_MODULE.getReturnType(), "getName") : null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <C, A> Callback<C, A> callback(Class<C> callbackType, C callbackInstance, A argument, Object... additionalArguments) {
/*  73 */     Assert.notNull(callbackType, "CallbackType must not be null");
/*  74 */     Assert.notNull(callbackInstance, "CallbackInstance must not be null");
/*  75 */     return new Callback<>(callbackType, callbackInstance, argument, additionalArguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <C, A> Callbacks<C, A> callbacks(Class<C> callbackType, Collection<? extends C> callbackInstances, A argument, Object... additionalArguments) {
/*  92 */     Assert.notNull(callbackType, "CallbackType must not be null");
/*  93 */     Assert.notNull(callbackInstances, "CallbackInstances must not be null");
/*  94 */     return new Callbacks<>(callbackType, callbackInstances, argument, additionalArguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static abstract class LambdaSafeCallback<C, A, SELF extends LambdaSafeCallback<C, A, SELF>>
/*     */   {
/*     */     private final Class<C> callbackType;
/*     */ 
/*     */     
/*     */     private final A argument;
/*     */ 
/*     */     
/*     */     private final Object[] additionalArguments;
/*     */ 
/*     */     
/*     */     private Log logger;
/*     */ 
/*     */     
/* 114 */     private LambdaSafe.Filter<C, A> filter = new LambdaSafe.GenericTypeFilter<>();
/*     */     
/*     */     LambdaSafeCallback(Class<C> callbackType, A argument, Object[] additionalArguments) {
/* 117 */       this.callbackType = callbackType;
/* 118 */       this.argument = argument;
/* 119 */       this.additionalArguments = additionalArguments;
/* 120 */       this.logger = LogFactory.getLog(callbackType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SELF withLogger(Class<?> loggerSource) {
/* 129 */       return withLogger(LogFactory.getLog(loggerSource));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SELF withLogger(Log logger) {
/* 138 */       Assert.notNull(logger, "Logger must not be null");
/* 139 */       this.logger = logger;
/* 140 */       return self();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SELF withFilter(LambdaSafe.Filter<C, A> filter) {
/* 151 */       Assert.notNull(filter, "Filter must not be null");
/* 152 */       this.filter = filter;
/* 153 */       return self();
/*     */     }
/*     */     
/*     */     protected final <R> LambdaSafe.InvocationResult<R> invoke(C callbackInstance, Supplier<R> supplier) {
/* 157 */       if (this.filter.match(this.callbackType, callbackInstance, this.argument, this.additionalArguments)) {
/*     */         try {
/* 159 */           return LambdaSafe.InvocationResult.of(supplier.get());
/*     */         }
/* 161 */         catch (ClassCastException ex) {
/* 162 */           if (!isLambdaGenericProblem(ex)) {
/* 163 */             throw ex;
/*     */           }
/* 165 */           logNonMatchingType(callbackInstance, ex);
/*     */         } 
/*     */       }
/* 168 */       return LambdaSafe.InvocationResult.noResult();
/*     */     }
/*     */     
/*     */     private boolean isLambdaGenericProblem(ClassCastException ex) {
/* 172 */       return (ex.getMessage() == null || startsWithArgumentClassName(ex.getMessage()));
/*     */     }
/*     */     
/*     */     private boolean startsWithArgumentClassName(String message) {
/* 176 */       Predicate<Object> startsWith = argument -> startsWithArgumentClassName(message, argument);
/* 177 */       return (startsWith.test(this.argument) || Stream.<Object>of(this.additionalArguments).anyMatch(startsWith));
/*     */     }
/*     */     
/*     */     private boolean startsWithArgumentClassName(String message, Object argument) {
/* 181 */       if (argument == null) {
/* 182 */         return false;
/*     */       }
/* 184 */       Class<?> argumentType = argument.getClass();
/*     */ 
/*     */       
/* 187 */       if (message.startsWith(argumentType.getName())) {
/* 188 */         return true;
/*     */       }
/*     */       
/* 191 */       if (message.startsWith(argumentType.toString())) {
/* 192 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 196 */       int moduleSeparatorIndex = message.indexOf('/');
/* 197 */       if (moduleSeparatorIndex != -1 && message.startsWith(argumentType.getName(), moduleSeparatorIndex + 1)) {
/* 198 */         return true;
/*     */       }
/* 200 */       if (LambdaSafe.CLASS_GET_MODULE != null) {
/* 201 */         Object module = ReflectionUtils.invokeMethod(LambdaSafe.CLASS_GET_MODULE, argumentType);
/* 202 */         Object moduleName = ReflectionUtils.invokeMethod(LambdaSafe.MODULE_GET_NAME, module);
/* 203 */         return message.startsWith(moduleName + "/" + argumentType.getName());
/*     */       } 
/* 205 */       return false;
/*     */     }
/*     */     
/*     */     private void logNonMatchingType(C callback, ClassCastException ex) {
/* 209 */       if (this.logger.isDebugEnabled()) {
/* 210 */         Class<?> expectedType = ResolvableType.forClass(this.callbackType).resolveGeneric(new int[0]);
/* 211 */         String expectedTypeName = (expectedType != null) ? (ClassUtils.getShortName(expectedType) + " type") : "type";
/*     */ 
/*     */         
/* 214 */         String message = "Non-matching " + expectedTypeName + " for callback " + ClassUtils.getShortName(this.callbackType) + ": " + callback;
/* 215 */         this.logger.debug(message, ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private SELF self() {
/* 221 */       return (SELF)this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Callback<C, A>
/*     */     extends LambdaSafeCallback<C, A, Callback<C, A>>
/*     */   {
/*     */     private final C callbackInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Callback(Class<C> callbackType, C callbackInstance, A argument, Object[] additionalArguments) {
/* 237 */       super(callbackType, argument, additionalArguments);
/* 238 */       this.callbackInstance = callbackInstance;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void invoke(Consumer<C> invoker) {
/* 246 */       invoke(this.callbackInstance, () -> {
/*     */             invoker.accept(this.callbackInstance);
/*     */             return null;
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> LambdaSafe.InvocationResult<R> invokeAnd(Function<C, R> invoker) {
/* 260 */       return invoke(this.callbackInstance, () -> invoker.apply(this.callbackInstance));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Callbacks<C, A>
/*     */     extends LambdaSafeCallback<C, A, Callbacks<C, A>>
/*     */   {
/*     */     private final Collection<? extends C> callbackInstances;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Callbacks(Class<C> callbackType, Collection<? extends C> callbackInstances, A argument, Object[] additionalArguments) {
/* 277 */       super(callbackType, argument, additionalArguments);
/* 278 */       this.callbackInstances = callbackInstances;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void invoke(Consumer<C> invoker) {
/* 286 */       this.callbackInstances.forEach(callbackInstance -> invoke((C)callbackInstance, ()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> Stream<R> invokeAnd(Function<C, R> invoker) {
/* 300 */       Function<C, LambdaSafe.InvocationResult<R>> mapper = callbackInstance -> invoke((C)callbackInstance, ());
/*     */       
/* 302 */       return this.callbackInstances.stream().<LambdaSafe.InvocationResult<R>>map(mapper).filter(LambdaSafe.InvocationResult::hasResult)
/* 303 */         .map(LambdaSafe.InvocationResult::get);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   static interface Filter<C, A>
/*     */   {
/*     */     boolean match(Class<C> param1Class, C param1C, A param1A, Object[] param1ArrayOfObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static <C, A> Filter<C, A> allowAll() {
/* 334 */       return (callbackType, callbackInstance, argument, additionalArguments) -> true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class GenericTypeFilter<C, A>
/*     */     implements Filter<C, A>
/*     */   {
/*     */     private GenericTypeFilter() {}
/*     */ 
/*     */     
/*     */     public boolean match(Class<C> callbackType, C callbackInstance, A argument, Object[] additionalArguments) {
/* 347 */       ResolvableType type = ResolvableType.forClass(callbackType, callbackInstance.getClass());
/* 348 */       if ((type.getGenerics()).length == 1 && type.resolveGeneric(new int[0]) != null) {
/* 349 */         return type.resolveGeneric(new int[0]).isInstance(argument);
/*     */       }
/*     */       
/* 352 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class InvocationResult<R>
/*     */   {
/* 366 */     private static final InvocationResult<?> NONE = new InvocationResult(null);
/*     */     
/*     */     private final R value;
/*     */     
/*     */     private InvocationResult(R value) {
/* 371 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasResult() {
/* 379 */       return (this != NONE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public R get() {
/* 388 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public R get(R fallback) {
/* 398 */       return (this != NONE) ? this.value : fallback;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <R> InvocationResult<R> of(R value) {
/* 408 */       return new InvocationResult<>(value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <R> InvocationResult<R> noResult() {
/* 418 */       return (InvocationResult)NONE;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boo\\util\LambdaSafe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;

public interface SpringApplicationRunListener {
  default void starting() {}
  
  default void environmentPrepared(ConfigurableEnvironment environment) {}
  
  default void contextPrepared(ConfigurableApplicationContext context) {}
  
  default void contextLoaded(ConfigurableApplicationContext context) {}
  
  default void started(ConfigurableApplicationContext context) {}
  
  default void running(ConfigurableApplicationContext context) {}
  
  default void failed(ConfigurableApplicationContext context, Throwable exception) {}
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\SpringApplicationRunListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
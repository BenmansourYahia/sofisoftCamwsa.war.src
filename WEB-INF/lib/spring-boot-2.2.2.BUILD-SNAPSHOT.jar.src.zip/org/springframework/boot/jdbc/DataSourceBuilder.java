/*     */ package org.springframework.boot.jdbc;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyNameAliases;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.MapConfigurationPropertySource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DataSourceBuilder<T extends DataSource>
/*     */ {
/*  49 */   private static final String[] DATA_SOURCE_TYPE_NAMES = new String[] { "com.zaxxer.hikari.HikariDataSource", "org.apache.tomcat.jdbc.pool.DataSource", "org.apache.commons.dbcp2.BasicDataSource" };
/*     */ 
/*     */   
/*     */   private Class<? extends DataSource> type;
/*     */   
/*     */   private ClassLoader classLoader;
/*     */   
/*  56 */   private Map<String, String> properties = new HashMap<>();
/*     */   
/*     */   public static DataSourceBuilder<?> create() {
/*  59 */     return new DataSourceBuilder(null);
/*     */   }
/*     */   
/*     */   public static DataSourceBuilder<?> create(ClassLoader classLoader) {
/*  63 */     return new DataSourceBuilder(classLoader);
/*     */   }
/*     */   
/*     */   private DataSourceBuilder(ClassLoader classLoader) {
/*  67 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public T build() {
/*  72 */     Class<? extends DataSource> type = getType();
/*  73 */     DataSource result = (DataSource)BeanUtils.instantiateClass(type);
/*  74 */     maybeGetDriverClassName();
/*  75 */     bind(result);
/*  76 */     return (T)result;
/*     */   }
/*     */   
/*     */   private void maybeGetDriverClassName() {
/*  80 */     if (!this.properties.containsKey("driverClassName") && this.properties.containsKey("url")) {
/*  81 */       String url = this.properties.get("url");
/*  82 */       String driverClass = DatabaseDriver.fromJdbcUrl(url).getDriverClassName();
/*  83 */       this.properties.put("driverClassName", driverClass);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void bind(DataSource result) {
/*  88 */     MapConfigurationPropertySource mapConfigurationPropertySource = new MapConfigurationPropertySource(this.properties);
/*  89 */     ConfigurationPropertyNameAliases aliases = new ConfigurationPropertyNameAliases();
/*  90 */     aliases.addAliases("url", new String[] { "jdbc-url" });
/*  91 */     aliases.addAliases("username", new String[] { "user" });
/*  92 */     Binder binder = new Binder(new ConfigurationPropertySource[] { mapConfigurationPropertySource.withAliases(aliases) });
/*  93 */     binder.bind(ConfigurationPropertyName.EMPTY, Bindable.ofInstance(result));
/*     */   }
/*     */ 
/*     */   
/*     */   public <D extends DataSource> DataSourceBuilder<D> type(Class<D> type) {
/*  98 */     this.type = type;
/*  99 */     return this;
/*     */   }
/*     */   
/*     */   public DataSourceBuilder<T> url(String url) {
/* 103 */     this.properties.put("url", url);
/* 104 */     return this;
/*     */   }
/*     */   
/*     */   public DataSourceBuilder<T> driverClassName(String driverClassName) {
/* 108 */     this.properties.put("driverClassName", driverClassName);
/* 109 */     return this;
/*     */   }
/*     */   
/*     */   public DataSourceBuilder<T> username(String username) {
/* 113 */     this.properties.put("username", username);
/* 114 */     return this;
/*     */   }
/*     */   
/*     */   public DataSourceBuilder<T> password(String password) {
/* 118 */     this.properties.put("password", password);
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Class<? extends DataSource> findType(ClassLoader classLoader) {
/* 124 */     for (String name : DATA_SOURCE_TYPE_NAMES) {
/*     */       try {
/* 126 */         return ClassUtils.forName(name, classLoader);
/*     */       }
/* 128 */       catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 132 */     return null;
/*     */   }
/*     */   
/*     */   private Class<? extends DataSource> getType() {
/* 136 */     Class<? extends DataSource> type = (this.type != null) ? this.type : findType(this.classLoader);
/* 137 */     if (type != null) {
/* 138 */       return type;
/*     */     }
/* 140 */     throw new IllegalStateException("No supported DataSource type found");
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\DataSourceBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.jdbc;
/*    */ 
/*    */ import java.sql.Wrapper;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.aop.framework.AopProxyUtils;
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.jdbc.datasource.DelegatingDataSource;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DataSourceUnwrapper
/*    */ {
/* 38 */   private static final boolean DELEGATING_DATA_SOURCE_PRESENT = ClassUtils.isPresent("org.springframework.jdbc.datasource.DelegatingDataSource", DataSourceUnwrapper.class
/* 39 */       .getClassLoader());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> T unwrap(DataSource dataSource, Class<T> target) {
/* 53 */     if (target.isInstance(dataSource)) {
/* 54 */       return target.cast(dataSource);
/*    */     }
/* 56 */     T unwrapped = safeUnwrap(dataSource, target);
/* 57 */     if (unwrapped != null) {
/* 58 */       return unwrapped;
/*    */     }
/* 60 */     if (DELEGATING_DATA_SOURCE_PRESENT) {
/* 61 */       DataSource targetDataSource = DelegatingDataSourceUnwrapper.getTargetDataSource(dataSource);
/* 62 */       if (targetDataSource != null) {
/* 63 */         return unwrap(targetDataSource, target);
/*    */       }
/*    */     } 
/* 66 */     if (AopUtils.isAopProxy(dataSource)) {
/* 67 */       Object proxyTarget = AopProxyUtils.getSingletonTarget(dataSource);
/* 68 */       if (proxyTarget instanceof DataSource) {
/* 69 */         return unwrap((DataSource)proxyTarget, target);
/*    */       }
/*    */     } 
/* 72 */     return null;
/*    */   }
/*    */   
/*    */   private static <S> S safeUnwrap(Wrapper wrapper, Class<S> target) {
/*    */     try {
/* 77 */       if (wrapper.isWrapperFor(target)) {
/* 78 */         return wrapper.unwrap(target);
/*    */       }
/*    */     }
/* 81 */     catch (Exception exception) {}
/*    */ 
/*    */     
/* 84 */     return null;
/*    */   }
/*    */   
/*    */   private static class DelegatingDataSourceUnwrapper
/*    */   {
/*    */     private static DataSource getTargetDataSource(DataSource dataSource) {
/* 90 */       if (dataSource instanceof DelegatingDataSource) {
/* 91 */         return ((DelegatingDataSource)dataSource).getTargetDataSource();
/*    */       }
/* 93 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\DataSourceUnwrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
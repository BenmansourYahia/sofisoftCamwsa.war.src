/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import com.zaxxer.hikari.HikariDataSource;
/*    */ import com.zaxxer.hikari.pool.HikariPool;
/*    */ import org.springframework.beans.DirectFieldAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HikariDataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<HikariDataSource>
/*    */ {
/*    */   public HikariDataSourcePoolMetadata(HikariDataSource dataSource) {
/* 35 */     super(dataSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getActive() {
/*    */     try {
/* 41 */       return Integer.valueOf(getHikariPool().getActiveConnections());
/*    */     }
/* 43 */     catch (Exception ex) {
/* 44 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getIdle() {
/*    */     try {
/* 51 */       return Integer.valueOf(getHikariPool().getIdleConnections());
/*    */     }
/* 53 */     catch (Exception ex) {
/* 54 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private HikariPool getHikariPool() {
/* 59 */     return (HikariPool)(new DirectFieldAccessor(getDataSource())).getPropertyValue("pool");
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMax() {
/* 64 */     return Integer.valueOf(getDataSource().getMaximumPoolSize());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMin() {
/* 69 */     return Integer.valueOf(getDataSource().getMinimumIdle());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValidationQuery() {
/* 74 */     return getDataSource().getConnectionTestQuery();
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean getDefaultAutoCommit() {
/* 79 */     return Boolean.valueOf(getDataSource().isAutoCommit());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\metadata\HikariDataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
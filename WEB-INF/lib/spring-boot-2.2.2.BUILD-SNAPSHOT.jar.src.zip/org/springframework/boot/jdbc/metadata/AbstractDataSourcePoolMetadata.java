/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDataSourcePoolMetadata<T extends DataSource>
/*    */   implements DataSourcePoolMetadata
/*    */ {
/*    */   private final T dataSource;
/*    */   
/*    */   protected AbstractDataSourcePoolMetadata(T dataSource) {
/* 37 */     this.dataSource = dataSource;
/*    */   }
/*    */ 
/*    */   
/*    */   public Float getUsage() {
/* 42 */     Integer maxSize = getMax();
/* 43 */     Integer currentSize = getActive();
/* 44 */     if (maxSize == null || currentSize == null) {
/* 45 */       return null;
/*    */     }
/* 47 */     if (maxSize.intValue() < 0) {
/* 48 */       return Float.valueOf(-1.0F);
/*    */     }
/* 50 */     if (currentSize.intValue() == 0) {
/* 51 */       return Float.valueOf(0.0F);
/*    */     }
/* 53 */     return Float.valueOf(currentSize.intValue() / maxSize.intValue());
/*    */   }
/*    */   
/*    */   protected final T getDataSource() {
/* 57 */     return this.dataSource;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\metadata\AbstractDataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
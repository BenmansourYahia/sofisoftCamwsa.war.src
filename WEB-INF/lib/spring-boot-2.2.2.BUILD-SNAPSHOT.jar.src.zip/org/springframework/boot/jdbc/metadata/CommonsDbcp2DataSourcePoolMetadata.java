/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import org.apache.commons.dbcp2.BasicDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonsDbcp2DataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<BasicDataSource>
/*    */ {
/*    */   public CommonsDbcp2DataSourcePoolMetadata(BasicDataSource dataSource) {
/* 32 */     super(dataSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getActive() {
/* 37 */     return Integer.valueOf(getDataSource().getNumActive());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getIdle() {
/* 42 */     return Integer.valueOf(getDataSource().getNumIdle());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMax() {
/* 47 */     return Integer.valueOf(getDataSource().getMaxTotal());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMin() {
/* 52 */     return Integer.valueOf(getDataSource().getMinIdle());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValidationQuery() {
/* 57 */     return getDataSource().getValidationQuery();
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean getDefaultAutoCommit() {
/* 62 */     return getDataSource().getDefaultAutoCommit();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\metadata\CommonsDbcp2DataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
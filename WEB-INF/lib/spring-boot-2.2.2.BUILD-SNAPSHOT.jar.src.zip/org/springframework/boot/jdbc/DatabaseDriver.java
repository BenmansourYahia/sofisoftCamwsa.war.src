/*     */ package org.springframework.boot.jdbc;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DatabaseDriver
/*     */ {
/*  41 */   UNKNOWN(null, null),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   DERBY("Apache Derby", "org.apache.derby.jdbc.EmbeddedDriver", "org.apache.derby.jdbc.EmbeddedXADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   H2("H2", "org.h2.Driver", "org.h2.jdbcx.JdbcDataSource", "SELECT 1"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   HSQLDB("HSQL Database Engine", "org.hsqldb.jdbc.JDBCDriver", "org.hsqldb.jdbc.pool.JDBCXADataSource", "SELECT COUNT(*) FROM INFORMATION_SCHEMA.SYSTEM_USERS"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   SQLITE("SQLite", "org.sqlite.JDBC"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   MYSQL("MySQL", "com.mysql.cj.jdbc.Driver", "com.mysql.cj.jdbc.MysqlXADataSource", "/* ping */ SELECT 1"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   MARIADB("MySQL", "org.mariadb.jdbc.Driver", "org.mariadb.jdbc.MariaDbDataSource", "SELECT 1")
/*     */   {
/*     */     public String getId()
/*     */     {
/*  77 */       return "mysql";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   GAE(null, "com.google.appengine.api.rdbms.AppEngineDriver"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   ORACLE("Oracle", "oracle.jdbc.OracleDriver", "oracle.jdbc.xa.client.OracleXADataSource", "SELECT 'Hello' from DUAL"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   POSTGRESQL("PostgreSQL", "org.postgresql.Driver", "org.postgresql.xa.PGXADataSource", "SELECT 1"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   REDSHIFT("Amazon Redshift", "com.amazon.redshift.jdbc.Driver", null, "SELECT 1"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   HANA("HDB", "com.sap.db.jdbc.Driver", "com.sap.db.jdbcext.XADataSourceSAP", "SELECT 1 FROM SYS.DUMMY")
/*     */   {
/*     */     protected Collection<String> getUrlPrefixes() {
/* 110 */       return Collections.singleton("sap");
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   JTDS(null, "net.sourceforge.jtds.jdbc.Driver"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   SQLSERVER("Microsoft SQL Server", "com.microsoft.sqlserver.jdbc.SQLServerDriver", "com.microsoft.sqlserver.jdbc.SQLServerXADataSource", "SELECT 1")
/*     */   {
/*     */     
/*     */     protected boolean matchProductName(String productName)
/*     */     {
/* 128 */       return (super.matchProductName(productName) || "SQL SERVER".equalsIgnoreCase(productName));
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   FIREBIRD("Firebird", "org.firebirdsql.jdbc.FBDriver", "org.firebirdsql.ds.FBXADataSource", "SELECT 1 FROM RDB$DATABASE")
/*     */   {
/*     */     
/*     */     protected Collection<String> getUrlPrefixes()
/*     */     {
/* 141 */       return Arrays.asList(new String[] { "firebirdsql", "firebird" });
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchProductName(String productName) {
/* 146 */       return (super.matchProductName(productName) || productName
/* 147 */         .toLowerCase(Locale.ENGLISH).startsWith("firebird"));
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   DB2("DB2", "com.ibm.db2.jcc.DB2Driver", "com.ibm.db2.jcc.DB2XADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1")
/*     */   {
/*     */     protected boolean matchProductName(String productName)
/*     */     {
/* 158 */       return (super.matchProductName(productName) || productName.toLowerCase(Locale.ENGLISH).startsWith("db2/"));
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   DB2_AS400("DB2 UDB for AS/400", "com.ibm.as400.access.AS400JDBCDriver", "com.ibm.as400.access.AS400JDBCXADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1")
/*     */   {
/*     */     
/*     */     public String getId()
/*     */     {
/* 170 */       return "db2";
/*     */     }
/*     */ 
/*     */     
/*     */     protected Collection<String> getUrlPrefixes() {
/* 175 */       return Collections.singleton("as400");
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchProductName(String productName) {
/* 180 */       return (super.matchProductName(productName) || productName.toLowerCase(Locale.ENGLISH).contains("as/400"));
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   TERADATA("Teradata", "com.teradata.jdbc.TeraDriver"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   INFORMIX("Informix Dynamic Server", "com.informix.jdbc.IfxDriver", null, "select count(*) from systables")
/*     */   {
/*     */     protected Collection<String> getUrlPrefixes()
/*     */     {
/* 196 */       return Arrays.asList(new String[] { "informix-sqli", "informix-direct" });
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String productName;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String driverClassName;
/*     */ 
/*     */   
/*     */   private final String xaDataSourceClassName;
/*     */ 
/*     */   
/*     */   private final String validationQuery;
/*     */ 
/*     */ 
/*     */   
/*     */   DatabaseDriver(String productName, String driverClassName, String xaDataSourceClassName, String validationQuery) {
/* 218 */     this.productName = productName;
/* 219 */     this.driverClassName = driverClassName;
/* 220 */     this.xaDataSourceClassName = xaDataSourceClassName;
/* 221 */     this.validationQuery = validationQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 229 */     return name().toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */   
/*     */   protected boolean matchProductName(String productName) {
/* 233 */     return (this.productName != null && this.productName.equalsIgnoreCase(productName));
/*     */   }
/*     */   
/*     */   protected Collection<String> getUrlPrefixes() {
/* 237 */     return Collections.singleton(name().toLowerCase(Locale.ENGLISH));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDriverClassName() {
/* 245 */     return this.driverClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getXaDataSourceClassName() {
/* 253 */     return this.xaDataSourceClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValidationQuery() {
/* 261 */     return this.validationQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DatabaseDriver fromJdbcUrl(String url) {
/* 270 */     if (StringUtils.hasLength(url)) {
/* 271 */       Assert.isTrue(url.startsWith("jdbc"), "URL must start with 'jdbc'");
/* 272 */       String urlWithoutPrefix = url.substring("jdbc".length()).toLowerCase(Locale.ENGLISH);
/* 273 */       for (DatabaseDriver driver : values()) {
/* 274 */         for (String urlPrefix : driver.getUrlPrefixes()) {
/* 275 */           String prefix = ":" + urlPrefix + ":";
/* 276 */           if (driver != UNKNOWN && urlWithoutPrefix.startsWith(prefix)) {
/* 277 */             return driver;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 282 */     return UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DatabaseDriver fromProductName(String productName) {
/* 291 */     if (StringUtils.hasLength(productName)) {
/* 292 */       for (DatabaseDriver candidate : values()) {
/* 293 */         if (candidate.matchProductName(productName)) {
/* 294 */           return candidate;
/*     */         }
/*     */       } 
/*     */     }
/* 298 */     return UNKNOWN;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\DatabaseDriver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
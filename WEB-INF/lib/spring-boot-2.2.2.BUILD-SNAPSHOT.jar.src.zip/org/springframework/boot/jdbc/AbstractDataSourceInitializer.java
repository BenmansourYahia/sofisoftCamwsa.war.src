/*    */ package org.springframework.boot.jdbc;
/*    */ 
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*    */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDataSourceInitializer
/*    */ {
/*    */   private static final String PLATFORM_PLACEHOLDER = "@@platform@@";
/*    */   private final DataSource dataSource;
/*    */   private final ResourceLoader resourceLoader;
/*    */   
/*    */   protected AbstractDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader) {
/* 45 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 46 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 47 */     this.dataSource = dataSource;
/* 48 */     this.resourceLoader = resourceLoader;
/*    */   }
/*    */   
/*    */   @PostConstruct
/*    */   protected void initialize() {
/* 53 */     if (!isEnabled()) {
/*    */       return;
/*    */     }
/* 56 */     ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 57 */     String schemaLocation = getSchemaLocation();
/* 58 */     if (schemaLocation.contains("@@platform@@")) {
/* 59 */       String platform = getDatabaseName();
/* 60 */       schemaLocation = schemaLocation.replace("@@platform@@", platform);
/*    */     } 
/* 62 */     populator.addScript(this.resourceLoader.getResource(schemaLocation));
/* 63 */     populator.setContinueOnError(true);
/* 64 */     customize(populator);
/* 65 */     DatabasePopulatorUtils.execute((DatabasePopulator)populator, this.dataSource);
/*    */   }
/*    */   
/*    */   private boolean isEnabled() {
/* 69 */     if (getMode() == DataSourceInitializationMode.NEVER) {
/* 70 */       return false;
/*    */     }
/* 72 */     return (getMode() != DataSourceInitializationMode.EMBEDDED || 
/* 73 */       EmbeddedDatabaseConnection.isEmbedded(this.dataSource));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void customize(ResourceDatabasePopulator populator) {}
/*    */ 
/*    */   
/*    */   protected abstract DataSourceInitializationMode getMode();
/*    */ 
/*    */   
/*    */   protected abstract String getSchemaLocation();
/*    */ 
/*    */   
/*    */   protected String getDatabaseName() {
/*    */     try {
/* 89 */       String productName = JdbcUtils.commonDatabaseName(
/* 90 */           JdbcUtils.extractDatabaseMetaData(this.dataSource, "getDatabaseProductName").toString());
/* 91 */       DatabaseDriver databaseDriver = DatabaseDriver.fromProductName(productName);
/* 92 */       if (databaseDriver == DatabaseDriver.UNKNOWN) {
/* 93 */         throw new IllegalStateException("Unable to detect database type");
/*    */       }
/* 95 */       return databaseDriver.getId();
/*    */     }
/* 97 */     catch (MetaDataAccessException ex) {
/* 98 */       throw new IllegalStateException("Unable to detect database type", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\AbstractDataSourceInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
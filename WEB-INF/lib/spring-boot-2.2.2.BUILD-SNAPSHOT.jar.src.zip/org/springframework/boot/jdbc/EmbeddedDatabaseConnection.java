/*     */ package org.springframework.boot.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Locale;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.ConnectionCallback;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum EmbeddedDatabaseConnection
/*     */ {
/*  46 */   NONE(null, null, null),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   H2(EmbeddedDatabaseType.H2, "org.h2.Driver", "jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   DERBY(EmbeddedDatabaseType.DERBY, "org.apache.derby.jdbc.EmbeddedDriver", "jdbc:derby:memory:%s;create=true"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   HSQL(EmbeddedDatabaseType.HSQL, "org.hsqldb.jdbcDriver", "jdbc:hsqldb:mem:%s");
/*     */   
/*     */   private final EmbeddedDatabaseType type;
/*     */   
/*     */   private final String driverClass;
/*     */   
/*     */   private final String url;
/*     */   
/*     */   EmbeddedDatabaseConnection(EmbeddedDatabaseType type, String driverClass, String url) {
/*  70 */     this.type = type;
/*  71 */     this.driverClass = driverClass;
/*  72 */     this.url = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDriverClassName() {
/*  80 */     return this.driverClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseType getType() {
/*  88 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl(String databaseName) {
/*  97 */     Assert.hasText(databaseName, "DatabaseName must not be empty");
/*  98 */     return (this.url != null) ? String.format(this.url, new Object[] { databaseName }) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmbedded(String driverClass) {
/* 108 */     return (driverClass != null && (driverClass.equals(HSQL.driverClass) || driverClass.equals(H2.driverClass) || driverClass
/* 109 */       .equals(DERBY.driverClass)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmbedded(DataSource dataSource) {
/*     */     try {
/* 120 */       return ((Boolean)(new JdbcTemplate(dataSource)).execute(new IsEmbedded())).booleanValue();
/*     */     }
/* 122 */     catch (DataAccessException ex) {
/*     */       
/* 124 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EmbeddedDatabaseConnection get(ClassLoader classLoader) {
/* 135 */     for (EmbeddedDatabaseConnection candidate : values()) {
/* 136 */       if (candidate != NONE && ClassUtils.isPresent(candidate.getDriverClassName(), classLoader)) {
/* 137 */         return candidate;
/*     */       }
/*     */     } 
/* 140 */     return NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class IsEmbedded
/*     */     implements ConnectionCallback<Boolean>
/*     */   {
/*     */     private IsEmbedded() {}
/*     */     
/*     */     public Boolean doInConnection(Connection connection) throws SQLException, DataAccessException {
/* 150 */       String productName = connection.getMetaData().getDatabaseProductName();
/* 151 */       if (productName == null) {
/* 152 */         return Boolean.valueOf(false);
/*     */       }
/* 154 */       productName = productName.toUpperCase(Locale.ENGLISH);
/* 155 */       EmbeddedDatabaseConnection[] candidates = EmbeddedDatabaseConnection.values();
/* 156 */       for (EmbeddedDatabaseConnection candidate : candidates) {
/* 157 */         if (candidate != EmbeddedDatabaseConnection.NONE && productName.contains(candidate.name())) {
/* 158 */           return Boolean.valueOf(true);
/*     */         }
/*     */       } 
/* 161 */       return Boolean.valueOf(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jdbc\EmbeddedDatabaseConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot;
/*    */ 
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum WebApplicationType
/*    */ {
/* 34 */   NONE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   SERVLET,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   REACTIVE;
/*    */   static {
/* 48 */     SERVLET_INDICATOR_CLASSES = new String[] { "javax.servlet.Servlet", "org.springframework.web.context.ConfigurableWebApplicationContext" };
/*    */   }
/*    */ 
/*    */   
/*    */   private static final String[] SERVLET_INDICATOR_CLASSES;
/*    */   
/*    */   private static final String WEBMVC_INDICATOR_CLASS = "org.springframework.web.servlet.DispatcherServlet";
/*    */   
/*    */   private static final String WEBFLUX_INDICATOR_CLASS = "org.springframework.web.reactive.DispatcherHandler";
/*    */   private static final String JERSEY_INDICATOR_CLASS = "org.glassfish.jersey.servlet.ServletContainer";
/*    */   private static final String SERVLET_APPLICATION_CONTEXT_CLASS = "org.springframework.web.context.WebApplicationContext";
/*    */   private static final String REACTIVE_APPLICATION_CONTEXT_CLASS = "org.springframework.boot.web.reactive.context.ReactiveWebApplicationContext";
/*    */   
/*    */   static WebApplicationType deduceFromClasspath() {
/* 62 */     if (ClassUtils.isPresent("org.springframework.web.reactive.DispatcherHandler", null) && !ClassUtils.isPresent("org.springframework.web.servlet.DispatcherServlet", null) && 
/* 63 */       !ClassUtils.isPresent("org.glassfish.jersey.servlet.ServletContainer", null)) {
/* 64 */       return REACTIVE;
/*    */     }
/* 66 */     for (String className : SERVLET_INDICATOR_CLASSES) {
/* 67 */       if (!ClassUtils.isPresent(className, null)) {
/* 68 */         return NONE;
/*    */       }
/*    */     } 
/* 71 */     return SERVLET;
/*    */   }
/*    */   
/*    */   static WebApplicationType deduceFromApplicationContext(Class<?> applicationContextClass) {
/* 75 */     if (isAssignable("org.springframework.web.context.WebApplicationContext", applicationContextClass)) {
/* 76 */       return SERVLET;
/*    */     }
/* 78 */     if (isAssignable("org.springframework.boot.web.reactive.context.ReactiveWebApplicationContext", applicationContextClass)) {
/* 79 */       return REACTIVE;
/*    */     }
/* 81 */     return NONE;
/*    */   }
/*    */   
/*    */   private static boolean isAssignable(String target, Class<?> type) {
/*    */     try {
/* 86 */       return ClassUtils.resolveClassName(target, null).isAssignableFrom(type);
/*    */     }
/* 88 */     catch (Throwable ex) {
/* 89 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\WebApplicationType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EnvironmentConverter
/*     */ {
/*     */   private static final String CONFIGURABLE_WEB_ENVIRONMENT_CLASS = "org.springframework.web.context.ConfigurableWebEnvironment";
/*     */   private static final Set<String> SERVLET_ENVIRONMENT_SOURCE_NAMES;
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   static {
/*  45 */     Set<String> names = new HashSet<>();
/*  46 */     names.add("servletContextInitParams");
/*  47 */     names.add("servletConfigInitParams");
/*  48 */     names.add("jndiProperties");
/*  49 */     SERVLET_ENVIRONMENT_SOURCE_NAMES = Collections.unmodifiableSet(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EnvironmentConverter(ClassLoader classLoader) {
/*  60 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StandardEnvironment convertEnvironmentIfNecessary(ConfigurableEnvironment environment, Class<? extends StandardEnvironment> type) {
/*  73 */     if (type.equals(environment.getClass())) {
/*  74 */       return (StandardEnvironment)environment;
/*     */     }
/*  76 */     return convertEnvironment(environment, type);
/*     */   }
/*     */ 
/*     */   
/*     */   private StandardEnvironment convertEnvironment(ConfigurableEnvironment environment, Class<? extends StandardEnvironment> type) {
/*  81 */     StandardEnvironment result = createEnvironment(type);
/*  82 */     result.setActiveProfiles(environment.getActiveProfiles());
/*  83 */     result.setConversionService(environment.getConversionService());
/*  84 */     copyPropertySources(environment, result);
/*  85 */     return result;
/*     */   }
/*     */   
/*     */   private StandardEnvironment createEnvironment(Class<? extends StandardEnvironment> type) {
/*     */     try {
/*  90 */       return type.newInstance();
/*     */     }
/*  92 */     catch (Exception ex) {
/*  93 */       return new StandardEnvironment();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyPropertySources(ConfigurableEnvironment source, StandardEnvironment target) {
/*  98 */     removePropertySources(target.getPropertySources(), isServletEnvironment(target.getClass(), this.classLoader));
/*  99 */     for (PropertySource<?> propertySource : (Iterable<PropertySource<?>>)source.getPropertySources()) {
/* 100 */       if (!SERVLET_ENVIRONMENT_SOURCE_NAMES.contains(propertySource.getName())) {
/* 101 */         target.getPropertySources().addLast(propertySource);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isServletEnvironment(Class<?> conversionType, ClassLoader classLoader) {
/*     */     try {
/* 108 */       Class<?> webEnvironmentClass = ClassUtils.forName("org.springframework.web.context.ConfigurableWebEnvironment", classLoader);
/* 109 */       return webEnvironmentClass.isAssignableFrom(conversionType);
/*     */     }
/* 111 */     catch (Throwable ex) {
/* 112 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removePropertySources(MutablePropertySources propertySources, boolean isServletEnvironment) {
/* 117 */     Set<String> names = new HashSet<>();
/* 118 */     for (PropertySource<?> propertySource : (Iterable<PropertySource<?>>)propertySources) {
/* 119 */       names.add(propertySource.getName());
/*     */     }
/* 121 */     for (String name : names) {
/* 122 */       if (!isServletEnvironment || !SERVLET_ENVIRONMENT_SOURCE_NAMES.contains(name))
/* 123 */         propertySources.remove(name); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\EnvironmentConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
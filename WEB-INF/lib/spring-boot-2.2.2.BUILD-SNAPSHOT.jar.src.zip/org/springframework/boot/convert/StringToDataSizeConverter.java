/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.util.unit.DataSize;
/*    */ import org.springframework.util.unit.DataUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringToDataSizeConverter
/*    */   implements GenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 40 */     return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, DataSize.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 45 */     if (ObjectUtils.isEmpty(source)) {
/* 46 */       return null;
/*    */     }
/* 48 */     return convert(source.toString(), getDataUnit(targetType));
/*    */   }
/*    */   
/*    */   private DataUnit getDataUnit(TypeDescriptor targetType) {
/* 52 */     DataSizeUnit annotation = (DataSizeUnit)targetType.getAnnotation(DataSizeUnit.class);
/* 53 */     return (annotation != null) ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private DataSize convert(String source, DataUnit unit) {
/* 57 */     return DataSize.parse(source, unit);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\StringToDataSizeConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
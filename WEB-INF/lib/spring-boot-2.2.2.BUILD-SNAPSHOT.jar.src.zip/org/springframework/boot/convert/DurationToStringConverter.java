/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DurationToStringConverter
/*    */   implements GenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 39 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Duration.class, String.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 44 */     if (source == null) {
/* 45 */       return null;
/*    */     }
/* 47 */     return convert((Duration)source, getDurationStyle(sourceType), getDurationUnit(sourceType));
/*    */   }
/*    */   
/*    */   private ChronoUnit getDurationUnit(TypeDescriptor sourceType) {
/* 51 */     DurationUnit annotation = (DurationUnit)sourceType.getAnnotation(DurationUnit.class);
/* 52 */     return (annotation != null) ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private DurationStyle getDurationStyle(TypeDescriptor sourceType) {
/* 56 */     DurationFormat annotation = (DurationFormat)sourceType.getAnnotation(DurationFormat.class);
/* 57 */     return (annotation != null) ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private String convert(Duration source, DurationStyle style, ChronoUnit unit) {
/* 61 */     style = (style != null) ? style : DurationStyle.ISO8601;
/* 62 */     return style.print(source, unit);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\DurationToStringConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
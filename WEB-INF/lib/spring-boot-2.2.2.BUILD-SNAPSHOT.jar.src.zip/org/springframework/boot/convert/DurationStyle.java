/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DurationStyle
/*     */ {
/*  39 */   SIMPLE("^([\\+\\-]?\\d+)([a-zA-Z]{0,2})$")
/*     */   {
/*     */     public Duration parse(String value, ChronoUnit unit)
/*     */     {
/*     */       try {
/*  44 */         Matcher matcher = matcher(value);
/*  45 */         Assert.state(matcher.matches(), "Does not match simple duration pattern");
/*  46 */         String suffix = matcher.group(2);
/*  47 */         return (StringUtils.hasLength(suffix) ? Unit.fromSuffix(suffix) : Unit.fromChronoUnit(unit))
/*  48 */           .parse(matcher.group(1));
/*     */       }
/*  50 */       catch (Exception ex) {
/*  51 */         throw new IllegalArgumentException("'" + value + "' is not a valid simple duration", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String print(Duration value, ChronoUnit unit) {
/*  57 */       return Unit.fromChronoUnit(unit).print(value);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   ISO8601("^[\\+\\-]?P.*$")
/*     */   {
/*     */     public Duration parse(String value, ChronoUnit unit)
/*     */     {
/*     */       try {
/*  70 */         return Duration.parse(value);
/*     */       }
/*  72 */       catch (Exception ex) {
/*  73 */         throw new IllegalArgumentException("'" + value + "' is not a valid ISO-8601 duration", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String print(Duration value, ChronoUnit unit) {
/*  79 */       return value.toString();
/*     */     }
/*     */   };
/*     */ 
/*     */   
/*     */   private final Pattern pattern;
/*     */   
/*     */   DurationStyle(String pattern) {
/*  87 */     this.pattern = Pattern.compile(pattern);
/*     */   }
/*     */   
/*     */   protected final boolean matches(String value) {
/*  91 */     return this.pattern.matcher(value).matches();
/*     */   }
/*     */   
/*     */   protected final Matcher matcher(String value) {
/*  95 */     return this.pattern.matcher(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration parse(String value) {
/* 104 */     return parse(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String print(Duration value) {
/* 122 */     return print(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration detectAndParse(String value) {
/* 140 */     return detectAndParse(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration detectAndParse(String value, ChronoUnit unit) {
/* 152 */     return detect(value).parse(value, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DurationStyle detect(String value) {
/* 162 */     Assert.notNull(value, "Value must not be null");
/* 163 */     for (DurationStyle candidate : values()) {
/* 164 */       if (candidate.matches(value)) {
/* 165 */         return candidate;
/*     */       }
/*     */     } 
/* 168 */     throw new IllegalArgumentException("'" + value + "' is not a valid duration");
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract Duration parse(String paramString, ChronoUnit paramChronoUnit);
/*     */ 
/*     */   
/*     */   public abstract String print(Duration paramDuration, ChronoUnit paramChronoUnit);
/*     */   
/*     */   enum Unit
/*     */   {
/* 179 */     NANOS((String)ChronoUnit.NANOS, "ns", (ChronoUnit)Duration::toNanos),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     MILLIS((String)ChronoUnit.MILLIS, "ms", (ChronoUnit)Duration::toMillis),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     SECONDS((String)ChronoUnit.SECONDS, "s", (ChronoUnit)Duration::getSeconds),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     MINUTES((String)ChronoUnit.MINUTES, "m", (ChronoUnit)Duration::toMinutes),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     HOURS((String)ChronoUnit.HOURS, "h", (ChronoUnit)Duration::toHours),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     DAYS((String)ChronoUnit.DAYS, "d", (ChronoUnit)Duration::toDays), MICROS((String)ChronoUnit.DAYS, "d", (ChronoUnit)Duration::toDays);
/*     */     
/*     */     static {
/*     */       MICROS = new Unit("MICROS", 1, ChronoUnit.MICROS, "us", duration -> Long.valueOf(duration.toMillis() * 1000L));
/*     */     }
/*     */     
/*     */     private final ChronoUnit chronoUnit;
/*     */     
/*     */     Unit(ChronoUnit chronoUnit, String suffix, Function<Duration, Long> toUnit) {
/* 218 */       this.chronoUnit = chronoUnit;
/* 219 */       this.suffix = suffix;
/* 220 */       this.longValue = toUnit;
/*     */     }
/*     */     private final String suffix; private Function<Duration, Long> longValue;
/*     */     public Duration parse(String value) {
/* 224 */       return Duration.of(Long.parseLong(value), this.chronoUnit);
/*     */     }
/*     */     
/*     */     public String print(Duration value) {
/* 228 */       return longValue(value) + this.suffix;
/*     */     }
/*     */     
/*     */     public long longValue(Duration value) {
/* 232 */       return ((Long)this.longValue.apply(value)).longValue();
/*     */     }
/*     */     
/*     */     public static Unit fromChronoUnit(ChronoUnit chronoUnit) {
/* 236 */       if (chronoUnit == null) {
/* 237 */         return MILLIS;
/*     */       }
/* 239 */       for (Unit candidate : values()) {
/* 240 */         if (candidate.chronoUnit == chronoUnit) {
/* 241 */           return candidate;
/*     */         }
/*     */       } 
/* 244 */       throw new IllegalArgumentException("Unknown unit " + chronoUnit);
/*     */     }
/*     */     
/*     */     public static Unit fromSuffix(String suffix) {
/* 248 */       for (Unit candidate : values()) {
/* 249 */         if (candidate.suffix.equalsIgnoreCase(suffix)) {
/* 250 */           return candidate;
/*     */         }
/*     */       } 
/* 253 */       throw new IllegalArgumentException("Unknown unit '" + suffix + "'");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\DurationStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
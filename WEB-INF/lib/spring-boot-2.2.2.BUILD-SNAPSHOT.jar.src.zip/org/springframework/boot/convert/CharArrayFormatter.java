/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CharArrayFormatter
/*    */   implements Formatter<char[]>
/*    */ {
/*    */   public String print(char[] object, Locale locale) {
/* 33 */     return new String(object);
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] parse(String text, Locale locale) throws ParseException {
/* 38 */     return text.toCharArray();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\CharArrayFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
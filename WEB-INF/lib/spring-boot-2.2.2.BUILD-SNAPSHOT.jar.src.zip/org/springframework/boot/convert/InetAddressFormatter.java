/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class InetAddressFormatter
/*    */   implements Formatter<InetAddress>
/*    */ {
/*    */   public String print(InetAddress object, Locale locale) {
/* 35 */     return object.getHostAddress();
/*    */   }
/*    */ 
/*    */   
/*    */   public InetAddress parse(String text, Locale locale) throws ParseException {
/*    */     try {
/* 41 */       return InetAddress.getByName(text);
/*    */     }
/* 43 */     catch (UnknownHostException ex) {
/* 44 */       throw new IllegalStateException("Unknown host " + text, ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\InetAddressFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
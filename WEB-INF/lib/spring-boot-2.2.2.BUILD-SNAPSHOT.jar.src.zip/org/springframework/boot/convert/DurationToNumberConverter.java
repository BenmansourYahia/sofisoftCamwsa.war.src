/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DurationToNumberConverter
/*    */   implements GenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 40 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Duration.class, Number.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 45 */     if (source == null) {
/* 46 */       return null;
/*    */     }
/* 48 */     return convert((Duration)source, getDurationUnit(sourceType), targetType.getObjectType());
/*    */   }
/*    */   
/*    */   private ChronoUnit getDurationUnit(TypeDescriptor sourceType) {
/* 52 */     DurationUnit annotation = (DurationUnit)sourceType.getAnnotation(DurationUnit.class);
/* 53 */     return (annotation != null) ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private Object convert(Duration source, ChronoUnit unit, Class<?> type) {
/*    */     try {
/* 58 */       return type.getConstructor(new Class[] { String.class
/* 59 */           }).newInstance(new Object[] { String.valueOf(DurationStyle.Unit.fromChronoUnit(unit).longValue(source)) });
/*    */     }
/* 61 */     catch (Exception ex) {
/* 62 */       ReflectionUtils.rethrowRuntimeException(ex);
/* 63 */       throw new IllegalStateException(ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\DurationToNumberConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
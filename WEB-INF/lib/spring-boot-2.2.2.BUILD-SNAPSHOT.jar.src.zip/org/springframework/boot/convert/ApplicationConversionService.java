/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.format.support.FormattingConversionService;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationConversionService
/*     */   extends FormattingConversionService
/*     */ {
/*     */   private static volatile ApplicationConversionService sharedInstance;
/*     */   
/*     */   public ApplicationConversionService() {
/*  54 */     this(null);
/*     */   }
/*     */   
/*     */   public ApplicationConversionService(StringValueResolver embeddedValueResolver) {
/*  58 */     if (embeddedValueResolver != null) {
/*  59 */       setEmbeddedValueResolver(embeddedValueResolver);
/*     */     }
/*  61 */     configure((FormatterRegistry)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConversionService getSharedInstance() {
/*  75 */     ApplicationConversionService sharedInstance = ApplicationConversionService.sharedInstance;
/*  76 */     if (sharedInstance == null) {
/*  77 */       synchronized (ApplicationConversionService.class) {
/*  78 */         sharedInstance = ApplicationConversionService.sharedInstance;
/*  79 */         if (sharedInstance == null) {
/*  80 */           sharedInstance = new ApplicationConversionService();
/*  81 */           ApplicationConversionService.sharedInstance = sharedInstance;
/*     */         } 
/*     */       } 
/*     */     }
/*  85 */     return (ConversionService)sharedInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void configure(FormatterRegistry registry) {
/*  97 */     DefaultConversionService.addDefaultConverters((ConverterRegistry)registry);
/*  98 */     DefaultFormattingConversionService.addDefaultFormatters(registry);
/*  99 */     addApplicationFormatters(registry);
/* 100 */     addApplicationConverters((ConverterRegistry)registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addApplicationConverters(ConverterRegistry registry) {
/* 111 */     addDelimitedStringConverters(registry);
/* 112 */     registry.addConverter(new StringToDurationConverter());
/* 113 */     registry.addConverter(new DurationToStringConverter());
/* 114 */     registry.addConverter(new NumberToDurationConverter());
/* 115 */     registry.addConverter(new DurationToNumberConverter());
/* 116 */     registry.addConverter(new StringToDataSizeConverter());
/* 117 */     registry.addConverter(new NumberToDataSizeConverter());
/* 118 */     registry.addConverter(new StringToFileConverter());
/* 119 */     registry.addConverterFactory(new LenientStringToEnumConverterFactory());
/* 120 */     registry.addConverterFactory(new LenientBooleanToEnumConverterFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addDelimitedStringConverters(ConverterRegistry registry) {
/* 131 */     ConversionService service = (ConversionService)registry;
/* 132 */     registry.addConverter((GenericConverter)new ArrayToDelimitedStringConverter(service));
/* 133 */     registry.addConverter((GenericConverter)new CollectionToDelimitedStringConverter(service));
/* 134 */     registry.addConverter((GenericConverter)new DelimitedStringToArrayConverter(service));
/* 135 */     registry.addConverter((GenericConverter)new DelimitedStringToCollectionConverter(service));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addApplicationFormatters(FormatterRegistry registry) {
/* 143 */     registry.addFormatter(new CharArrayFormatter());
/* 144 */     registry.addFormatter(new InetAddressFormatter());
/* 145 */     registry.addFormatter(new IsoOffsetFormatter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addBeans(FormatterRegistry registry, ListableBeanFactory beanFactory) {
/* 156 */     Set<Object> beans = new LinkedHashSet();
/* 157 */     beans.addAll(beanFactory.getBeansOfType(GenericConverter.class).values());
/* 158 */     beans.addAll(beanFactory.getBeansOfType(Converter.class).values());
/* 159 */     beans.addAll(beanFactory.getBeansOfType(Printer.class).values());
/* 160 */     beans.addAll(beanFactory.getBeansOfType(Parser.class).values());
/* 161 */     for (Object bean : beans) {
/* 162 */       if (bean instanceof GenericConverter) {
/* 163 */         registry.addConverter((GenericConverter)bean); continue;
/*     */       } 
/* 165 */       if (bean instanceof Converter) {
/* 166 */         registry.addConverter((Converter)bean); continue;
/*     */       } 
/* 168 */       if (bean instanceof Formatter) {
/* 169 */         registry.addFormatter((Formatter)bean); continue;
/*     */       } 
/* 171 */       if (bean instanceof Printer) {
/* 172 */         registry.addPrinter((Printer)bean); continue;
/*     */       } 
/* 174 */       if (bean instanceof Parser)
/* 175 */         registry.addParser((Parser)bean); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\ApplicationConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
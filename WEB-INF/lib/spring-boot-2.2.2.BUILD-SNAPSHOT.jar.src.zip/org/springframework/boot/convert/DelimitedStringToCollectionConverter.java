/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DelimitedStringToCollectionConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */   
/*    */   DelimitedStringToCollectionConverter(ConversionService conversionService) {
/* 42 */     Assert.notNull(conversionService, "ConversionService must not be null");
/* 43 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 48 */     return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, Collection.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 53 */     return (targetType.getElementTypeDescriptor() == null || this.conversionService
/* 54 */       .canConvert(sourceType, targetType.getElementTypeDescriptor()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 59 */     if (source == null) {
/* 60 */       return null;
/*    */     }
/* 62 */     return convert((String)source, sourceType, targetType);
/*    */   }
/*    */   
/*    */   private Object convert(String source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 66 */     Delimiter delimiter = (Delimiter)targetType.getAnnotation(Delimiter.class);
/* 67 */     String[] elements = getElements(source, (delimiter != null) ? delimiter.value() : ",");
/* 68 */     TypeDescriptor elementDescriptor = targetType.getElementTypeDescriptor();
/* 69 */     Collection<Object> target = createCollection(targetType, elementDescriptor, elements.length);
/* 70 */     Stream<Object> stream = Arrays.<String>stream(elements).map(String::trim);
/* 71 */     if (elementDescriptor != null) {
/* 72 */       stream = stream.map(element -> this.conversionService.convert(element, sourceType, elementDescriptor));
/*    */     }
/* 74 */     stream.forEach(target::add);
/* 75 */     return target;
/*    */   }
/*    */ 
/*    */   
/*    */   private Collection<Object> createCollection(TypeDescriptor targetType, TypeDescriptor elementDescriptor, int length) {
/* 80 */     return CollectionFactory.createCollection(targetType.getType(), (elementDescriptor != null) ? elementDescriptor
/* 81 */         .getType() : null, length);
/*    */   }
/*    */   
/*    */   private String[] getElements(String source, String delimiter) {
/* 85 */     return StringUtils.delimitedListToStringArray(source, "".equals(delimiter) ? null : delimiter);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\DelimitedStringToCollectionConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CollectionToDelimitedStringConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */   
/*    */   CollectionToDelimitedStringConverter(ConversionService conversionService) {
/* 38 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 43 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Collection.class, String.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 48 */     TypeDescriptor sourceElementType = sourceType.getElementTypeDescriptor();
/* 49 */     if (targetType == null || sourceElementType == null) {
/* 50 */       return true;
/*    */     }
/* 52 */     return (this.conversionService.canConvert(sourceElementType, targetType) || sourceElementType
/* 53 */       .getType().isAssignableFrom(targetType.getType()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 58 */     if (source == null) {
/* 59 */       return null;
/*    */     }
/* 61 */     Collection<?> sourceCollection = (Collection)source;
/* 62 */     return convert(sourceCollection, sourceType, targetType);
/*    */   }
/*    */   
/*    */   private Object convert(Collection<?> source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 66 */     if (source.isEmpty()) {
/* 67 */       return "";
/*    */     }
/* 69 */     return source.stream().map(element -> convertElement(element, sourceType, targetType))
/* 70 */       .collect(Collectors.joining(getDelimiter(sourceType)));
/*    */   }
/*    */   
/*    */   private CharSequence getDelimiter(TypeDescriptor sourceType) {
/* 74 */     Delimiter annotation = (Delimiter)sourceType.getAnnotation(Delimiter.class);
/* 75 */     return (annotation != null) ? annotation.value() : ",";
/*    */   }
/*    */   
/*    */   private String convertElement(Object element, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 79 */     return String.valueOf(this.conversionService
/* 80 */         .convert(element, sourceType.elementTypeDescriptor(element), targetType));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\convert\CollectionToDelimitedStringConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
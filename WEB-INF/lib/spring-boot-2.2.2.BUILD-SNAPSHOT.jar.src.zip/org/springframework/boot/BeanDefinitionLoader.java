/*     */ package org.springframework.boot;
/*     */ 
/*     */ import groovy.lang.Closure;
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.groovy.GroovyBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.type.filter.AbstractTypeHierarchyTraversingFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanDefinitionLoader
/*     */ {
/*     */   private final Object[] sources;
/*     */   private final AnnotatedBeanDefinitionReader annotatedReader;
/*     */   private final XmlBeanDefinitionReader xmlReader;
/*     */   private BeanDefinitionReader groovyReader;
/*     */   private final ClassPathBeanDefinitionScanner scanner;
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */   BeanDefinitionLoader(BeanDefinitionRegistry registry, Object... sources) {
/*  79 */     Assert.notNull(registry, "Registry must not be null");
/*  80 */     Assert.notEmpty(sources, "Sources must not be empty");
/*  81 */     this.sources = sources;
/*  82 */     this.annotatedReader = new AnnotatedBeanDefinitionReader(registry);
/*  83 */     this.xmlReader = new XmlBeanDefinitionReader(registry);
/*  84 */     if (isGroovyPresent()) {
/*  85 */       this.groovyReader = (BeanDefinitionReader)new GroovyBeanDefinitionReader(registry);
/*     */     }
/*  87 */     this.scanner = new ClassPathBeanDefinitionScanner(registry);
/*  88 */     this.scanner.addExcludeFilter((TypeFilter)new ClassExcludeFilter(sources));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setBeanNameGenerator(BeanNameGenerator beanNameGenerator) {
/*  96 */     this.annotatedReader.setBeanNameGenerator(beanNameGenerator);
/*  97 */     this.xmlReader.setBeanNameGenerator(beanNameGenerator);
/*  98 */     this.scanner.setBeanNameGenerator(beanNameGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setResourceLoader(ResourceLoader resourceLoader) {
/* 106 */     this.resourceLoader = resourceLoader;
/* 107 */     this.xmlReader.setResourceLoader(resourceLoader);
/* 108 */     this.scanner.setResourceLoader(resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEnvironment(ConfigurableEnvironment environment) {
/* 116 */     this.annotatedReader.setEnvironment((Environment)environment);
/* 117 */     this.xmlReader.setEnvironment((Environment)environment);
/* 118 */     this.scanner.setEnvironment((Environment)environment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int load() {
/* 126 */     int count = 0;
/* 127 */     for (Object source : this.sources) {
/* 128 */       count += load(source);
/*     */     }
/* 130 */     return count;
/*     */   }
/*     */   
/*     */   private int load(Object source) {
/* 134 */     Assert.notNull(source, "Source must not be null");
/* 135 */     if (source instanceof Class) {
/* 136 */       return load((Class)source);
/*     */     }
/* 138 */     if (source instanceof Resource) {
/* 139 */       return load((Resource)source);
/*     */     }
/* 141 */     if (source instanceof Package) {
/* 142 */       return load((Package)source);
/*     */     }
/* 144 */     if (source instanceof CharSequence) {
/* 145 */       return load((CharSequence)source);
/*     */     }
/* 147 */     throw new IllegalArgumentException("Invalid source type " + source.getClass());
/*     */   }
/*     */   
/*     */   private int load(Class<?> source) {
/* 151 */     if (isGroovyPresent() && GroovyBeanDefinitionSource.class.isAssignableFrom(source)) {
/*     */       
/* 153 */       GroovyBeanDefinitionSource loader = (GroovyBeanDefinitionSource)BeanUtils.instantiateClass(source, GroovyBeanDefinitionSource.class);
/* 154 */       load(loader);
/*     */     } 
/* 156 */     if (isComponent(source)) {
/* 157 */       this.annotatedReader.register(new Class[] { source });
/* 158 */       return 1;
/*     */     } 
/* 160 */     return 0;
/*     */   }
/*     */   
/*     */   private int load(GroovyBeanDefinitionSource source) {
/* 164 */     int before = this.xmlReader.getRegistry().getBeanDefinitionCount();
/* 165 */     ((GroovyBeanDefinitionReader)this.groovyReader).beans(source.getBeans());
/* 166 */     int after = this.xmlReader.getRegistry().getBeanDefinitionCount();
/* 167 */     return after - before;
/*     */   }
/*     */   
/*     */   private int load(Resource source) {
/* 171 */     if (source.getFilename().endsWith(".groovy")) {
/* 172 */       if (this.groovyReader == null) {
/* 173 */         throw new BeanDefinitionStoreException("Cannot load Groovy beans without Groovy on classpath");
/*     */       }
/* 175 */       return this.groovyReader.loadBeanDefinitions(source);
/*     */     } 
/* 177 */     return this.xmlReader.loadBeanDefinitions(source);
/*     */   }
/*     */   
/*     */   private int load(Package source) {
/* 181 */     return this.scanner.scan(new String[] { source.getName() });
/*     */   }
/*     */   
/*     */   private int load(CharSequence source) {
/* 185 */     String resolvedSource = this.xmlReader.getEnvironment().resolvePlaceholders(source.toString());
/*     */     
/*     */     try {
/* 188 */       return load(ClassUtils.forName(resolvedSource, null));
/*     */     }
/* 190 */     catch (IllegalArgumentException|ClassNotFoundException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */       
/* 194 */       Resource[] resources = findResources(resolvedSource);
/* 195 */       int loadCount = 0;
/* 196 */       boolean atLeastOneResourceExists = false;
/* 197 */       for (Resource resource : resources) {
/* 198 */         if (isLoadCandidate(resource)) {
/* 199 */           atLeastOneResourceExists = true;
/* 200 */           loadCount += load(resource);
/*     */         } 
/*     */       } 
/* 203 */       if (atLeastOneResourceExists) {
/* 204 */         return loadCount;
/*     */       }
/*     */       
/* 207 */       Package packageResource = findPackage(resolvedSource);
/* 208 */       if (packageResource != null) {
/* 209 */         return load(packageResource);
/*     */       }
/* 211 */       throw new IllegalArgumentException("Invalid source '" + resolvedSource + "'");
/*     */     } 
/*     */   }
/*     */   private boolean isGroovyPresent() {
/* 215 */     return ClassUtils.isPresent("groovy.lang.MetaClass", null);
/*     */   }
/*     */   
/*     */   private Resource[] findResources(String source) {
/* 219 */     ResourceLoader loader = (this.resourceLoader != null) ? this.resourceLoader : (ResourceLoader)new PathMatchingResourcePatternResolver();
/*     */     
/*     */     try {
/* 222 */       if (loader instanceof ResourcePatternResolver) {
/* 223 */         return ((ResourcePatternResolver)loader).getResources(source);
/*     */       }
/* 225 */       return new Resource[] { loader.getResource(source) };
/*     */     }
/* 227 */     catch (IOException ex) {
/* 228 */       throw new IllegalStateException("Error reading source '" + source + "'");
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isLoadCandidate(Resource resource) {
/* 233 */     if (resource == null || !resource.exists()) {
/* 234 */       return false;
/*     */     }
/* 236 */     if (resource instanceof ClassPathResource) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 241 */       String path = ((ClassPathResource)resource).getPath();
/* 242 */       if (path.indexOf('.') == -1) {
/*     */         try {
/* 244 */           return (Package.getPackage(path) == null);
/*     */         }
/* 246 */         catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 251 */     return true;
/*     */   }
/*     */   
/*     */   private Package findPackage(CharSequence source) {
/* 255 */     Package pkg = Package.getPackage(source.toString());
/* 256 */     if (pkg != null) {
/* 257 */       return pkg;
/*     */     }
/*     */     
/*     */     try {
/* 261 */       PathMatchingResourcePatternResolver pathMatchingResourcePatternResolver = new PathMatchingResourcePatternResolver(getClass().getClassLoader());
/*     */       
/* 263 */       Resource[] resources = pathMatchingResourcePatternResolver.getResources(ClassUtils.convertClassNameToResourcePath(source.toString()) + "/*.class");
/* 264 */       Resource[] arrayOfResource1 = resources; int i = arrayOfResource1.length; byte b = 0; if (b < i) { Resource resource = arrayOfResource1[b];
/* 265 */         String className = StringUtils.stripFilenameExtension(resource.getFilename());
/* 266 */         load(Class.forName(source.toString() + "." + className)); }
/*     */ 
/*     */     
/*     */     }
/* 270 */     catch (Exception exception) {}
/*     */ 
/*     */     
/* 273 */     return Package.getPackage(source.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isComponent(Class<?> type) {
/* 279 */     if (MergedAnnotations.from(type, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).isPresent(Component.class)) {
/* 280 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 284 */     return (!type.getName().matches(".*\\$_.*closure.*") && !type.isAnonymousClass() && type
/* 285 */       .getConstructors() != null && (type.getConstructors()).length != 0);
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface GroovyBeanDefinitionSource {
/*     */     Closure<?> getBeans();
/*     */   }
/*     */   
/*     */   private static class ClassExcludeFilter extends AbstractTypeHierarchyTraversingFilter {
/* 294 */     private final Set<String> classNames = new HashSet<>();
/*     */     
/*     */     ClassExcludeFilter(Object... sources) {
/* 297 */       super(false, false);
/* 298 */       for (Object source : sources) {
/* 299 */         if (source instanceof Class) {
/* 300 */           this.classNames.add(((Class)source).getName());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchClassName(String className) {
/* 307 */       return this.classNames.contains(className);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\BeanDefinitionLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
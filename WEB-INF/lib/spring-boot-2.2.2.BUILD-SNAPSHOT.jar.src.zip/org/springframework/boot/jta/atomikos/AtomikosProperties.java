/*     */ package org.springframework.boot.jta.atomikos;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Properties;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.jta.atomikos.properties")
/*     */ public class AtomikosProperties
/*     */ {
/*     */   private String service;
/*  46 */   private Duration maxTimeout = Duration.ofMillis(300000L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private Duration defaultJtaTimeout = Duration.ofMillis(10000L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private int maxActives = 50;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enableLogging = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String transactionManagerUniqueName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean serialJtaTransactions = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean allowSubTransactions = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean forceShutdownOnVmExit;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private long defaultMaxWaitTimeOnShutdown = Long.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private String logBaseName = "tmlog";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String logBaseDir;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   private long checkpointInterval = 500L;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean threadedTwoPhaseCommit;
/*     */ 
/*     */ 
/*     */   
/* 114 */   private final Recovery recovery = new Recovery();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setService(String service) {
/* 124 */     this.service = service;
/*     */   }
/*     */   
/*     */   public String getService() {
/* 128 */     return this.service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxTimeout(Duration maxTimeout) {
/* 138 */     this.maxTimeout = maxTimeout;
/*     */   }
/*     */   
/*     */   public Duration getMaxTimeout() {
/* 142 */     return this.maxTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultJtaTimeout(Duration defaultJtaTimeout) {
/* 151 */     this.defaultJtaTimeout = defaultJtaTimeout;
/*     */   }
/*     */   
/*     */   public Duration getDefaultJtaTimeout() {
/* 155 */     return this.defaultJtaTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxActives(int maxActives) {
/* 167 */     this.maxActives = maxActives;
/*     */   }
/*     */   
/*     */   public int getMaxActives() {
/* 171 */     return this.maxActives;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableLogging(boolean enableLogging) {
/* 182 */     this.enableLogging = enableLogging;
/*     */   }
/*     */   
/*     */   public boolean isEnableLogging() {
/* 186 */     return this.enableLogging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionManagerUniqueName(String uniqueName) {
/* 201 */     this.transactionManagerUniqueName = uniqueName;
/*     */   }
/*     */   
/*     */   public String getTransactionManagerUniqueName() {
/* 205 */     return this.transactionManagerUniqueName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSerialJtaTransactions(boolean serialJtaTransactions) {
/* 217 */     this.serialJtaTransactions = serialJtaTransactions;
/*     */   }
/*     */   
/*     */   public boolean isSerialJtaTransactions() {
/* 221 */     return this.serialJtaTransactions;
/*     */   }
/*     */   
/*     */   public void setAllowSubTransactions(boolean allowSubTransactions) {
/* 225 */     this.allowSubTransactions = allowSubTransactions;
/*     */   }
/*     */   
/*     */   public boolean isAllowSubTransactions() {
/* 229 */     return this.allowSubTransactions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForceShutdownOnVmExit(boolean forceShutdownOnVmExit) {
/* 238 */     this.forceShutdownOnVmExit = forceShutdownOnVmExit;
/*     */   }
/*     */   
/*     */   public boolean isForceShutdownOnVmExit() {
/* 242 */     return this.forceShutdownOnVmExit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultMaxWaitTimeOnShutdown(long defaultMaxWaitTimeOnShutdown) {
/* 251 */     this.defaultMaxWaitTimeOnShutdown = defaultMaxWaitTimeOnShutdown;
/*     */   }
/*     */   
/*     */   public long getDefaultMaxWaitTimeOnShutdown() {
/* 255 */     return this.defaultMaxWaitTimeOnShutdown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogBaseName(String logBaseName) {
/* 266 */     this.logBaseName = logBaseName;
/*     */   }
/*     */   
/*     */   public String getLogBaseName() {
/* 270 */     return this.logBaseName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogBaseDir(String logBaseDir) {
/* 281 */     this.logBaseDir = logBaseDir;
/*     */   }
/*     */   
/*     */   public String getLogBaseDir() {
/* 285 */     return this.logBaseDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckpointInterval(long checkpointInterval) {
/* 294 */     this.checkpointInterval = checkpointInterval;
/*     */   }
/*     */   
/*     */   public long getCheckpointInterval() {
/* 298 */     return this.checkpointInterval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThreadedTwoPhaseCommit(boolean threadedTwoPhaseCommit) {
/* 311 */     this.threadedTwoPhaseCommit = threadedTwoPhaseCommit;
/*     */   }
/*     */   
/*     */   public boolean isThreadedTwoPhaseCommit() {
/* 315 */     return this.threadedTwoPhaseCommit;
/*     */   }
/*     */   
/*     */   public Recovery getRecovery() {
/* 319 */     return this.recovery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties asProperties() {
/* 328 */     Properties properties = new Properties();
/* 329 */     set(properties, "service", getService());
/* 330 */     set(properties, "max_timeout", getMaxTimeout());
/* 331 */     set(properties, "default_jta_timeout", getDefaultJtaTimeout());
/* 332 */     set(properties, "max_actives", Integer.valueOf(getMaxActives()));
/* 333 */     set(properties, "enable_logging", Boolean.valueOf(isEnableLogging()));
/* 334 */     set(properties, "tm_unique_name", getTransactionManagerUniqueName());
/* 335 */     set(properties, "serial_jta_transactions", Boolean.valueOf(isSerialJtaTransactions()));
/* 336 */     set(properties, "allow_subtransactions", Boolean.valueOf(isAllowSubTransactions()));
/* 337 */     set(properties, "force_shutdown_on_vm_exit", Boolean.valueOf(isForceShutdownOnVmExit()));
/* 338 */     set(properties, "default_max_wait_time_on_shutdown", Long.valueOf(getDefaultMaxWaitTimeOnShutdown()));
/* 339 */     set(properties, "log_base_name", getLogBaseName());
/* 340 */     set(properties, "log_base_dir", getLogBaseDir());
/* 341 */     set(properties, "checkpoint_interval", Long.valueOf(getCheckpointInterval()));
/* 342 */     set(properties, "threaded_2pc", Boolean.valueOf(isThreadedTwoPhaseCommit()));
/* 343 */     Recovery recovery = getRecovery();
/* 344 */     set(properties, "forget_orphaned_log_entries_delay", recovery.getForgetOrphanedLogEntriesDelay());
/* 345 */     set(properties, "recovery_delay", recovery.getDelay());
/* 346 */     set(properties, "oltp_max_retries", Integer.valueOf(recovery.getMaxRetries()));
/* 347 */     set(properties, "oltp_retry_interval", recovery.getRetryInterval());
/* 348 */     return properties;
/*     */   }
/*     */   
/*     */   private void set(Properties properties, String key, Object value) {
/* 352 */     String id = "com.atomikos.icatch." + key;
/* 353 */     if (value != null && !properties.containsKey(id)) {
/* 354 */       properties.setProperty(id, asString(value));
/*     */     }
/*     */   }
/*     */   
/*     */   private String asString(Object value) {
/* 359 */     if (value instanceof Duration) {
/* 360 */       return String.valueOf(((Duration)value).toMillis());
/*     */     }
/* 362 */     return value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Recovery
/*     */   {
/* 373 */     private Duration forgetOrphanedLogEntriesDelay = Duration.ofMillis(86400000L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 378 */     private Duration delay = Duration.ofMillis(10000L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 384 */     private int maxRetries = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 389 */     private Duration retryInterval = Duration.ofMillis(10000L);
/*     */     
/*     */     public Duration getForgetOrphanedLogEntriesDelay() {
/* 392 */       return this.forgetOrphanedLogEntriesDelay;
/*     */     }
/*     */     
/*     */     public void setForgetOrphanedLogEntriesDelay(Duration forgetOrphanedLogEntriesDelay) {
/* 396 */       this.forgetOrphanedLogEntriesDelay = forgetOrphanedLogEntriesDelay;
/*     */     }
/*     */     
/*     */     public Duration getDelay() {
/* 400 */       return this.delay;
/*     */     }
/*     */     
/*     */     public void setDelay(Duration delay) {
/* 404 */       this.delay = delay;
/*     */     }
/*     */     
/*     */     public int getMaxRetries() {
/* 408 */       return this.maxRetries;
/*     */     }
/*     */     
/*     */     public void setMaxRetries(int maxRetries) {
/* 412 */       this.maxRetries = maxRetries;
/*     */     }
/*     */     
/*     */     public Duration getRetryInterval() {
/* 416 */       return this.retryInterval;
/*     */     }
/*     */     
/*     */     public void setRetryInterval(Duration retryInterval) {
/* 420 */       this.retryInterval = retryInterval;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\atomikos\AtomikosProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.jta.atomikos;
/*     */ 
/*     */ import com.atomikos.icatch.jta.UserTransactionManager;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AtomikosDependsOnBeanFactoryPostProcessor
/*     */   implements BeanFactoryPostProcessor, Ordered
/*     */ {
/*  45 */   private static final String[] NO_BEANS = new String[0];
/*     */   
/*  47 */   private int order = Integer.MAX_VALUE;
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/*  51 */     String[] transactionManagers = beanFactory.getBeanNamesForType(UserTransactionManager.class, true, false);
/*  52 */     for (String transactionManager : transactionManagers) {
/*  53 */       addTransactionManagerDependencies(beanFactory, transactionManager);
/*     */     }
/*  55 */     addMessageDrivenContainerDependencies(beanFactory, transactionManagers);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addTransactionManagerDependencies(ConfigurableListableBeanFactory beanFactory, String transactionManager) {
/*  60 */     BeanDefinition bean = beanFactory.getBeanDefinition(transactionManager);
/*  61 */     Set<String> dependsOn = new LinkedHashSet<>(asList(bean.getDependsOn()));
/*  62 */     int initialSize = dependsOn.size();
/*  63 */     addDependencies(beanFactory, "javax.jms.ConnectionFactory", dependsOn);
/*  64 */     addDependencies(beanFactory, "javax.sql.DataSource", dependsOn);
/*  65 */     if (dependsOn.size() != initialSize) {
/*  66 */       bean.setDependsOn(StringUtils.toStringArray(dependsOn));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addMessageDrivenContainerDependencies(ConfigurableListableBeanFactory beanFactory, String[] transactionManagers) {
/*  72 */     String[] messageDrivenContainers = getBeanNamesForType(beanFactory, "com.atomikos.jms.extra.MessageDrivenContainer");
/*     */     
/*  74 */     for (String messageDrivenContainer : messageDrivenContainers) {
/*  75 */       BeanDefinition bean = beanFactory.getBeanDefinition(messageDrivenContainer);
/*  76 */       Set<String> dependsOn = new LinkedHashSet<>(asList(bean.getDependsOn()));
/*  77 */       dependsOn.addAll(asList(transactionManagers));
/*  78 */       bean.setDependsOn(StringUtils.toStringArray(dependsOn));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addDependencies(ConfigurableListableBeanFactory beanFactory, String type, Set<String> dependsOn) {
/*  83 */     dependsOn.addAll(asList(getBeanNamesForType(beanFactory, type)));
/*     */   }
/*     */   
/*     */   private String[] getBeanNamesForType(ConfigurableListableBeanFactory beanFactory, String type) {
/*     */     try {
/*  88 */       return beanFactory.getBeanNamesForType(Class.forName(type), true, false);
/*     */     }
/*  90 */     catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {
/*     */ 
/*     */       
/*  93 */       return NO_BEANS;
/*     */     } 
/*     */   }
/*     */   private List<String> asList(String[] array) {
/*  97 */     return (array != null) ? Arrays.<String>asList(array) : Collections.<String>emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 102 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 106 */     this.order = order;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\atomikos\AtomikosDependsOnBeanFactoryPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
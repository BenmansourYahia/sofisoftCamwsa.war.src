/*    */ package org.springframework.boot.jta.atomikos;
/*    */ 
/*    */ import com.atomikos.jms.AtomikosConnectionFactoryBean;
/*    */ import org.springframework.beans.factory.BeanNameAware;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.jta.atomikos.connectionfactory")
/*    */ public class AtomikosConnectionFactoryBean
/*    */   extends AtomikosConnectionFactoryBean
/*    */   implements BeanNameAware, InitializingBean, DisposableBean
/*    */ {
/*    */   private String beanName;
/*    */   
/*    */   public void setBeanName(String name) {
/* 41 */     this.beanName = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 46 */     if (!StringUtils.hasLength(getUniqueResourceName())) {
/* 47 */       setUniqueResourceName(this.beanName);
/*    */     }
/* 49 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() throws Exception {
/* 54 */     close();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\atomikos\AtomikosConnectionFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
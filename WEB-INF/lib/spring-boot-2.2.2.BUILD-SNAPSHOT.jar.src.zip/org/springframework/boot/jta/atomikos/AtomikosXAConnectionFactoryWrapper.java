/*    */ package org.springframework.boot.jta.atomikos;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.XAConnectionFactory;
/*    */ import org.springframework.boot.jms.XAConnectionFactoryWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AtomikosXAConnectionFactoryWrapper
/*    */   implements XAConnectionFactoryWrapper
/*    */ {
/*    */   public ConnectionFactory wrapConnectionFactory(XAConnectionFactory connectionFactory) {
/* 35 */     AtomikosConnectionFactoryBean bean = new AtomikosConnectionFactoryBean();
/* 36 */     bean.setXaConnectionFactory(connectionFactory);
/* 37 */     return (ConnectionFactory)bean;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\atomikos\AtomikosXAConnectionFactoryWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
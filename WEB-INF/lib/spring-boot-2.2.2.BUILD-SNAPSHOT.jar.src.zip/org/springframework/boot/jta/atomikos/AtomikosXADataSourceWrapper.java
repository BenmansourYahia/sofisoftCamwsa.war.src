/*    */ package org.springframework.boot.jta.atomikos;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import javax.sql.XADataSource;
/*    */ import org.springframework.boot.jdbc.XADataSourceWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AtomikosXADataSourceWrapper
/*    */   implements XADataSourceWrapper
/*    */ {
/*    */   public AtomikosDataSourceBean wrapDataSource(XADataSource dataSource) throws Exception {
/* 34 */     AtomikosDataSourceBean bean = new AtomikosDataSourceBean();
/* 35 */     bean.setXaDataSource(dataSource);
/* 36 */     return bean;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\atomikos\AtomikosXADataSourceWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.jta.bitronix;
/*    */ 
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BitronixDependentBeanFactoryPostProcessor
/*    */   implements BeanFactoryPostProcessor, Ordered
/*    */ {
/* 38 */   private static final String[] NO_BEANS = new String[0];
/*    */   
/* 40 */   private int order = Integer.MAX_VALUE;
/*    */ 
/*    */   
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/* 44 */     String[] transactionManagers = beanFactory.getBeanNamesForType(TransactionManager.class, true, false);
/* 45 */     for (String transactionManager : transactionManagers) {
/* 46 */       addTransactionManagerDependencies(beanFactory, transactionManager);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private void addTransactionManagerDependencies(ConfigurableListableBeanFactory beanFactory, String transactionManager) {
/* 52 */     for (String dependentBeanName : getBeanNamesForType(beanFactory, "javax.jms.ConnectionFactory")) {
/* 53 */       beanFactory.registerDependentBean(transactionManager, dependentBeanName);
/*    */     }
/* 55 */     for (String dependentBeanName : getBeanNamesForType(beanFactory, "javax.sql.DataSource")) {
/* 56 */       beanFactory.registerDependentBean(transactionManager, dependentBeanName);
/*    */     }
/*    */   }
/*    */   
/*    */   private String[] getBeanNamesForType(ConfigurableListableBeanFactory beanFactory, String type) {
/*    */     try {
/* 62 */       return beanFactory.getBeanNamesForType(Class.forName(type), true, false);
/*    */     }
/* 64 */     catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {
/*    */ 
/*    */       
/* 67 */       return NO_BEANS;
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getOrder() {
/* 72 */     return this.order;
/*    */   }
/*    */   
/*    */   public void setOrder(int order) {
/* 76 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\bitronix\BitronixDependentBeanFactoryPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
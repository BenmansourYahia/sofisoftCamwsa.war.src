/*     */ package org.springframework.boot.jta.bitronix;
/*     */ 
/*     */ import bitronix.tm.resource.common.ResourceBean;
/*     */ import bitronix.tm.resource.common.XAStatefulHolder;
/*     */ import bitronix.tm.resource.jdbc.PoolingDataSource;
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.jta.bitronix.datasource")
/*     */ public class PoolingDataSourceBean
/*     */   extends PoolingDataSource
/*     */   implements BeanNameAware, InitializingBean
/*     */ {
/*  50 */   private static final ThreadLocal<PoolingDataSourceBean> source = new ThreadLocal<>();
/*     */   
/*     */   private XADataSource dataSource;
/*     */   
/*     */   private String beanName;
/*     */   
/*     */   public PoolingDataSourceBean() {
/*  57 */     setMaxPoolSize(10);
/*  58 */     setAllowLocalTransactions(true);
/*  59 */     setEnableJdbc4ConnectionTest(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void init() {
/*  64 */     source.set(this);
/*     */     try {
/*  66 */       super.init();
/*     */     } finally {
/*     */       
/*  69 */       source.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanName(String name) {
/*  75 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  80 */     if (!StringUtils.hasLength(getUniqueName())) {
/*  81 */       setUniqueName(this.beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(XADataSource dataSource) {
/*  91 */     this.dataSource = dataSource;
/*  92 */     setClassName(DirectXADataSource.class.getName());
/*  93 */     setDriverProperties(new Properties());
/*     */   }
/*     */   
/*     */   protected final XADataSource getDataSource() {
/*  97 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public XAStatefulHolder createPooledConnection(Object xaFactory, ResourceBean bean) throws Exception {
/* 102 */     if (xaFactory instanceof DirectXADataSource) {
/* 103 */       xaFactory = ((DirectXADataSource)xaFactory).getDataSource();
/*     */     }
/* 105 */     return super.createPooledConnection(xaFactory, bean);
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/*     */     try {
/* 111 */       return getParentLogger();
/*     */     }
/* 113 */     catch (Exception ex) {
/*     */       
/* 115 */       return Logger.getLogger("global");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DirectXADataSource
/*     */     implements XADataSource
/*     */   {
/* 130 */     private final XADataSource dataSource = (PoolingDataSourceBean.source.get()).dataSource;
/*     */ 
/*     */ 
/*     */     
/*     */     public PrintWriter getLogWriter() throws SQLException {
/* 135 */       return this.dataSource.getLogWriter();
/*     */     }
/*     */ 
/*     */     
/*     */     public XAConnection getXAConnection() throws SQLException {
/* 140 */       return this.dataSource.getXAConnection();
/*     */     }
/*     */ 
/*     */     
/*     */     public XAConnection getXAConnection(String user, String password) throws SQLException {
/* 145 */       return this.dataSource.getXAConnection(user, password);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLogWriter(PrintWriter out) throws SQLException {
/* 150 */       this.dataSource.setLogWriter(out);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLoginTimeout(int seconds) throws SQLException {
/* 155 */       this.dataSource.setLoginTimeout(seconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getLoginTimeout() throws SQLException {
/* 160 */       return this.dataSource.getLoginTimeout();
/*     */     }
/*     */ 
/*     */     
/*     */     public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/* 165 */       return this.dataSource.getParentLogger();
/*     */     }
/*     */     
/*     */     public XADataSource getDataSource() {
/* 169 */       return this.dataSource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\bitronix\PoolingDataSourceBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
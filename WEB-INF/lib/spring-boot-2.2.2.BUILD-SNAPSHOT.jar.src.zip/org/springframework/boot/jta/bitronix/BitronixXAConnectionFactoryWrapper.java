/*    */ package org.springframework.boot.jta.bitronix;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.XAConnectionFactory;
/*    */ import org.springframework.boot.jms.XAConnectionFactoryWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BitronixXAConnectionFactoryWrapper
/*    */   implements XAConnectionFactoryWrapper
/*    */ {
/*    */   public ConnectionFactory wrapConnectionFactory(XAConnectionFactory connectionFactory) {
/* 35 */     PoolingConnectionFactoryBean pool = new PoolingConnectionFactoryBean();
/* 36 */     pool.setConnectionFactory(connectionFactory);
/* 37 */     return (ConnectionFactory)pool;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\bitronix\BitronixXAConnectionFactoryWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.jta.bitronix;
/*     */ 
/*     */ import bitronix.tm.resource.common.ResourceBean;
/*     */ import bitronix.tm.resource.common.XAStatefulHolder;
/*     */ import bitronix.tm.resource.jms.PoolingConnectionFactory;
/*     */ import java.util.Properties;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.XAConnection;
/*     */ import javax.jms.XAConnectionFactory;
/*     */ import javax.jms.XAJMSContext;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.jta.bitronix.connectionfactory")
/*     */ public class PoolingConnectionFactoryBean
/*     */   extends PoolingConnectionFactory
/*     */   implements BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*  50 */   private static final ThreadLocal<PoolingConnectionFactoryBean> source = new ThreadLocal<>();
/*     */   
/*     */   private String beanName;
/*     */   
/*     */   private XAConnectionFactory connectionFactory;
/*     */   
/*     */   public PoolingConnectionFactoryBean() {
/*  57 */     setMaxPoolSize(10);
/*  58 */     setTestConnections(true);
/*  59 */     setAutomaticEnlistingEnabled(true);
/*  60 */     setAllowLocalTransactions(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void init() {
/*  65 */     source.set(this);
/*     */     try {
/*  67 */       super.init();
/*     */     } finally {
/*     */       
/*  70 */       source.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanName(String name) {
/*  76 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  81 */     if (!StringUtils.hasLength(getUniqueName())) {
/*  82 */       setUniqueName(this.beanName);
/*     */     }
/*  84 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/*  89 */     close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionFactory(XAConnectionFactory connectionFactory) {
/*  98 */     this.connectionFactory = connectionFactory;
/*  99 */     setClassName(DirectXAConnectionFactory.class.getName());
/* 100 */     setDriverProperties(new Properties());
/*     */   }
/*     */   
/*     */   protected final XAConnectionFactory getConnectionFactory() {
/* 104 */     return this.connectionFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public XAStatefulHolder createPooledConnection(Object xaFactory, ResourceBean bean) throws Exception {
/* 109 */     if (xaFactory instanceof DirectXAConnectionFactory) {
/* 110 */       xaFactory = ((DirectXAConnectionFactory)xaFactory).getConnectionFactory();
/*     */     }
/* 112 */     return super.createPooledConnection(xaFactory, bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DirectXAConnectionFactory
/*     */     implements XAConnectionFactory
/*     */   {
/* 126 */     private final XAConnectionFactory connectionFactory = (PoolingConnectionFactoryBean.source.get()).connectionFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     public XAConnection createXAConnection() throws JMSException {
/* 131 */       return this.connectionFactory.createXAConnection();
/*     */     }
/*     */ 
/*     */     
/*     */     public XAConnection createXAConnection(String userName, String password) throws JMSException {
/* 136 */       return this.connectionFactory.createXAConnection(userName, password);
/*     */     }
/*     */     
/*     */     public XAConnectionFactory getConnectionFactory() {
/* 140 */       return this.connectionFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public XAJMSContext createXAContext() {
/* 145 */       return this.connectionFactory.createXAContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public XAJMSContext createXAContext(String username, String password) {
/* 150 */       return this.connectionFactory.createXAContext(username, password);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jta\bitronix\PoolingConnectionFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
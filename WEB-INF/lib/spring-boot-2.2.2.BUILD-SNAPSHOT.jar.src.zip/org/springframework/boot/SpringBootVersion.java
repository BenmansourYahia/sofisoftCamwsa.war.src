/*    */ package org.springframework.boot;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.net.JarURLConnection;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.security.CodeSource;
/*    */ import java.util.jar.Attributes;
/*    */ import java.util.jar.JarFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringBootVersion
/*    */ {
/*    */   public static String getVersion() {
/* 57 */     return determineSpringBootVersion();
/*    */   }
/*    */   
/*    */   private static String determineSpringBootVersion() {
/* 61 */     String implementationVersion = SpringBootVersion.class.getPackage().getImplementationVersion();
/* 62 */     if (implementationVersion != null) {
/* 63 */       return implementationVersion;
/*    */     }
/* 65 */     CodeSource codeSource = SpringBootVersion.class.getProtectionDomain().getCodeSource();
/* 66 */     if (codeSource == null) {
/* 67 */       return null;
/*    */     }
/* 69 */     URL codeSourceLocation = codeSource.getLocation();
/*    */     try {
/* 71 */       URLConnection connection = codeSourceLocation.openConnection();
/* 72 */       if (connection instanceof JarURLConnection) {
/* 73 */         return getImplementationVersion(((JarURLConnection)connection).getJarFile());
/*    */       }
/* 75 */       try (JarFile jarFile = new JarFile(new File(codeSourceLocation.toURI()))) {
/* 76 */         return getImplementationVersion(jarFile);
/*    */       }
/*    */     
/* 79 */     } catch (Exception ex) {
/* 80 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private static String getImplementationVersion(JarFile jarFile) throws IOException {
/* 85 */     return jarFile.getManifest().getMainAttributes().getValue(Attributes.Name.IMPLEMENTATION_VERSION);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\SpringBootVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
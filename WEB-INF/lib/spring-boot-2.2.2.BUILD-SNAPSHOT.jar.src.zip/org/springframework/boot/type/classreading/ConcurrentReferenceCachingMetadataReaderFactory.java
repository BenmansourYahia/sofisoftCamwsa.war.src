/*    */ package org.springframework.boot.type.classreading;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.classreading.MetadataReader;
/*    */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*    */ import org.springframework.util.ConcurrentReferenceHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConcurrentReferenceCachingMetadataReaderFactory
/*    */   extends SimpleMetadataReaderFactory
/*    */ {
/* 41 */   private final Map<Resource, MetadataReader> cache = (Map<Resource, MetadataReader>)new ConcurrentReferenceHashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConcurrentReferenceCachingMetadataReaderFactory() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConcurrentReferenceCachingMetadataReaderFactory(ResourceLoader resourceLoader) {
/* 57 */     super(resourceLoader);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConcurrentReferenceCachingMetadataReaderFactory(ClassLoader classLoader) {
/* 66 */     super(classLoader);
/*    */   }
/*    */ 
/*    */   
/*    */   public MetadataReader getMetadataReader(Resource resource) throws IOException {
/* 71 */     MetadataReader metadataReader = this.cache.get(resource);
/* 72 */     if (metadataReader == null) {
/* 73 */       metadataReader = createMetadataReader(resource);
/* 74 */       this.cache.put(resource, metadataReader);
/*    */     } 
/* 76 */     return metadataReader;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MetadataReader createMetadataReader(Resource resource) throws IOException {
/* 86 */     return super.getMetadataReader(resource);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void clearCache() {
/* 93 */     this.cache.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\type\classreading\ConcurrentReferenceCachingMetadataReaderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
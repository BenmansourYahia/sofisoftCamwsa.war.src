/*     */ package org.springframework.boot.ansi;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.IntFunction;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnsiPropertySource
/*     */   extends PropertySource<AnsiElement>
/*     */ {
/*     */   private static final Iterable<Mapping> MAPPINGS;
/*     */   private final boolean encode;
/*     */   
/*     */   static {
/*  51 */     List<Mapping> mappings = new ArrayList<>();
/*  52 */     mappings.add(new EnumMapping<>("AnsiStyle.", AnsiStyle.class));
/*  53 */     mappings.add(new EnumMapping<>("AnsiColor.", AnsiColor.class));
/*  54 */     mappings.add(new Ansi8BitColorMapping("AnsiColor.", Ansi8BitColor::foreground));
/*  55 */     mappings.add(new EnumMapping<>("AnsiBackground.", AnsiBackground.class));
/*  56 */     mappings.add(new Ansi8BitColorMapping("AnsiBackground.", Ansi8BitColor::background));
/*  57 */     mappings.add(new EnumMapping<>("Ansi.", AnsiStyle.class));
/*  58 */     mappings.add(new EnumMapping<>("Ansi.", AnsiColor.class));
/*  59 */     mappings.add(new EnumMapping<>("Ansi.BG_", AnsiBackground.class));
/*  60 */     MAPPINGS = Collections.unmodifiableList(mappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnsiPropertySource(String name, boolean encode) {
/*  71 */     super(name);
/*  72 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) {
/*  77 */     if (StringUtils.hasLength(name)) {
/*  78 */       for (Mapping mapping : MAPPINGS) {
/*  79 */         String prefix = mapping.getPrefix();
/*  80 */         if (name.startsWith(prefix)) {
/*  81 */           String postfix = name.substring(prefix.length());
/*  82 */           AnsiElement element = mapping.getElement(postfix);
/*  83 */           if (element != null) {
/*  84 */             return this.encode ? AnsiOutput.encode(element) : element;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static abstract class Mapping
/*     */   {
/*     */     private final String prefix;
/*     */ 
/*     */     
/*     */     Mapping(String prefix) {
/* 100 */       this.prefix = prefix;
/*     */     }
/*     */     
/*     */     String getPrefix() {
/* 104 */       return this.prefix;
/*     */     }
/*     */ 
/*     */     
/*     */     abstract AnsiElement getElement(String param1String);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class EnumMapping<E extends Enum<E> & AnsiElement>
/*     */     extends Mapping
/*     */   {
/*     */     private final Set<E> enums;
/*     */ 
/*     */     
/*     */     EnumMapping(String prefix, Class<E> enumType) {
/* 119 */       super(prefix);
/* 120 */       this.enums = EnumSet.allOf(enumType);
/*     */     }
/*     */ 
/*     */     
/*     */     AnsiElement getElement(String postfix) {
/* 125 */       for (Enum<?> candidate : this.enums) {
/* 126 */         if (candidate.name().equals(postfix)) {
/* 127 */           return (AnsiElement)candidate;
/*     */         }
/*     */       } 
/* 130 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Ansi8BitColorMapping
/*     */     extends Mapping
/*     */   {
/*     */     private final IntFunction<Ansi8BitColor> factory;
/*     */ 
/*     */     
/*     */     Ansi8BitColorMapping(String prefix, IntFunction<Ansi8BitColor> factory) {
/* 143 */       super(prefix);
/* 144 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */     
/*     */     AnsiElement getElement(String postfix) {
/* 149 */       if (containsOnlyDigits(postfix)) {
/*     */         try {
/* 151 */           return this.factory.apply(Integer.parseInt(postfix));
/*     */         }
/* 153 */         catch (IllegalArgumentException illegalArgumentException) {}
/*     */       }
/*     */       
/* 156 */       return null;
/*     */     }
/*     */     
/*     */     private boolean containsOnlyDigits(String postfix) {
/* 160 */       for (int i = 0; i < postfix.length(); i++) {
/* 161 */         if (!Character.isDigit(postfix.charAt(i))) {
/* 162 */           return false;
/*     */         }
/*     */       } 
/* 165 */       return (postfix.length() > 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\ansi\AnsiPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
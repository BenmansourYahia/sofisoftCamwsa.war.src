/*     */ package org.springframework.boot.ansi;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnsiOutput
/*     */ {
/*     */   private static final String ENCODE_JOIN = ";";
/*  34 */   private static Enabled enabled = Enabled.DETECT;
/*     */   
/*     */   private static Boolean consoleAvailable;
/*     */   
/*     */   private static Boolean ansiCapable;
/*     */   
/*  40 */   private static final String OPERATING_SYSTEM_NAME = System.getProperty("os.name").toLowerCase(Locale.ENGLISH);
/*     */   
/*     */   private static final String ENCODE_START = "\033[";
/*     */   
/*     */   private static final String ENCODE_END = "m";
/*     */   
/*  46 */   private static final String RESET = "0;" + AnsiColor.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setEnabled(Enabled enabled) {
/*  53 */     Assert.notNull(enabled, "Enabled must not be null");
/*  54 */     AnsiOutput.enabled = enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Enabled getEnabled() {
/*  62 */     return enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setConsoleAvailable(Boolean consoleAvailable) {
/*  71 */     AnsiOutput.consoleAvailable = consoleAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(AnsiElement element) {
/*  80 */     if (isEnabled()) {
/*  81 */       return "\033[" + element + "m";
/*     */     }
/*  83 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Object... elements) {
/*  93 */     StringBuilder sb = new StringBuilder();
/*  94 */     if (isEnabled()) {
/*  95 */       buildEnabled(sb, elements);
/*     */     } else {
/*     */       
/*  98 */       buildDisabled(sb, elements);
/*     */     } 
/* 100 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static void buildEnabled(StringBuilder sb, Object[] elements) {
/* 104 */     boolean writingAnsi = false;
/* 105 */     boolean containsEncoding = false;
/* 106 */     for (Object element : elements) {
/* 107 */       if (element instanceof AnsiElement) {
/* 108 */         containsEncoding = true;
/* 109 */         if (!writingAnsi) {
/* 110 */           sb.append("\033[");
/* 111 */           writingAnsi = true;
/*     */         } else {
/*     */           
/* 114 */           sb.append(";");
/*     */         }
/*     */       
/*     */       }
/* 118 */       else if (writingAnsi) {
/* 119 */         sb.append("m");
/* 120 */         writingAnsi = false;
/*     */       } 
/*     */       
/* 123 */       sb.append(element);
/*     */     } 
/* 125 */     if (containsEncoding) {
/* 126 */       sb.append(writingAnsi ? ";" : "\033[");
/* 127 */       sb.append(RESET);
/* 128 */       sb.append("m");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void buildDisabled(StringBuilder sb, Object[] elements) {
/* 133 */     for (Object element : elements) {
/* 134 */       if (!(element instanceof AnsiElement) && element != null) {
/* 135 */         sb.append(element);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isEnabled() {
/* 141 */     if (enabled == Enabled.DETECT) {
/* 142 */       if (ansiCapable == null) {
/* 143 */         ansiCapable = Boolean.valueOf(detectIfAnsiCapable());
/*     */       }
/* 145 */       return ansiCapable.booleanValue();
/*     */     } 
/* 147 */     return (enabled == Enabled.ALWAYS);
/*     */   }
/*     */   
/*     */   private static boolean detectIfAnsiCapable() {
/*     */     try {
/* 152 */       if (Boolean.FALSE.equals(consoleAvailable)) {
/* 153 */         return false;
/*     */       }
/* 155 */       if (consoleAvailable == null && System.console() == null) {
/* 156 */         return false;
/*     */       }
/* 158 */       return !OPERATING_SYSTEM_NAME.contains("win");
/*     */     }
/* 160 */     catch (Throwable ex) {
/* 161 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Enabled
/*     */   {
/* 175 */     DETECT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     ALWAYS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     NEVER;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\ansi\AnsiOutput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
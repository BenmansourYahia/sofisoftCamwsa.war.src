/*    */ package org.springframework.boot.ansi;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Ansi8BitColor
/*    */   implements AnsiElement
/*    */ {
/*    */   private final String prefix;
/*    */   private final int code;
/*    */   
/*    */   private Ansi8BitColor(String prefix, int code) {
/* 43 */     Assert.isTrue((code >= 0 && code <= 255), "Code must be between 0 and 255");
/* 44 */     this.prefix = prefix;
/* 45 */     this.code = code;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 50 */     if (this == obj) {
/* 51 */       return true;
/*    */     }
/* 53 */     if (obj == null || getClass() != obj.getClass()) {
/* 54 */       return false;
/*    */     }
/* 56 */     Ansi8BitColor other = (Ansi8BitColor)obj;
/* 57 */     return (this.prefix.equals(other.prefix) && this.code == other.code);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 62 */     return this.prefix.hashCode() * 31 + this.code;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return this.prefix + this.code;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Ansi8BitColor foreground(int code) {
/* 76 */     return new Ansi8BitColor("38;5;", code);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Ansi8BitColor background(int code) {
/* 85 */     return new Ansi8BitColor("48;5;", code);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\ansi\Ansi8BitColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringApplicationRunListeners
/*     */ {
/*     */   private final Log log;
/*     */   private final List<SpringApplicationRunListener> listeners;
/*     */   
/*     */   SpringApplicationRunListeners(Log log, Collection<? extends SpringApplicationRunListener> listeners) {
/*  41 */     this.log = log;
/*  42 */     this.listeners = new ArrayList<>(listeners);
/*     */   }
/*     */   
/*     */   void starting() {
/*  46 */     for (SpringApplicationRunListener listener : this.listeners) {
/*  47 */       listener.starting();
/*     */     }
/*     */   }
/*     */   
/*     */   void environmentPrepared(ConfigurableEnvironment environment) {
/*  52 */     for (SpringApplicationRunListener listener : this.listeners) {
/*  53 */       listener.environmentPrepared(environment);
/*     */     }
/*     */   }
/*     */   
/*     */   void contextPrepared(ConfigurableApplicationContext context) {
/*  58 */     for (SpringApplicationRunListener listener : this.listeners) {
/*  59 */       listener.contextPrepared(context);
/*     */     }
/*     */   }
/*     */   
/*     */   void contextLoaded(ConfigurableApplicationContext context) {
/*  64 */     for (SpringApplicationRunListener listener : this.listeners) {
/*  65 */       listener.contextLoaded(context);
/*     */     }
/*     */   }
/*     */   
/*     */   void started(ConfigurableApplicationContext context) {
/*  70 */     for (SpringApplicationRunListener listener : this.listeners) {
/*  71 */       listener.started(context);
/*     */     }
/*     */   }
/*     */   
/*     */   void running(ConfigurableApplicationContext context) {
/*  76 */     for (SpringApplicationRunListener listener : this.listeners) {
/*  77 */       listener.running(context);
/*     */     }
/*     */   }
/*     */   
/*     */   void failed(ConfigurableApplicationContext context, Throwable exception) {
/*  82 */     for (SpringApplicationRunListener listener : this.listeners) {
/*  83 */       callFailedListener(listener, context, exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void callFailedListener(SpringApplicationRunListener listener, ConfigurableApplicationContext context, Throwable exception) {
/*     */     try {
/*  90 */       listener.failed(context, exception);
/*     */     }
/*  92 */     catch (Throwable ex) {
/*  93 */       if (exception == null) {
/*  94 */         ReflectionUtils.rethrowRuntimeException(ex);
/*     */       }
/*  96 */       if (this.log.isDebugEnabled()) {
/*  97 */         this.log.error("Error handling failed", ex);
/*     */       } else {
/*     */         
/* 100 */         String message = ex.getMessage();
/* 101 */         message = (message != null) ? message : "no error message";
/* 102 */         this.log.warn("Error handling failed (" + message + ")");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\SpringApplicationRunListeners.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
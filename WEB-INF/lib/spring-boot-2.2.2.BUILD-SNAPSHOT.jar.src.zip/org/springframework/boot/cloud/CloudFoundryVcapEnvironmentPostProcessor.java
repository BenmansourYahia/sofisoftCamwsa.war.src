/*     */ package org.springframework.boot.cloud;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.env.EnvironmentPostProcessor;
/*     */ import org.springframework.boot.json.JsonParser;
/*     */ import org.springframework.boot.json.JsonParserFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloudFoundryVcapEnvironmentPostProcessor
/*     */   implements EnvironmentPostProcessor, Ordered
/*     */ {
/*  94 */   private static final Log logger = LogFactory.getLog(CloudFoundryVcapEnvironmentPostProcessor.class);
/*     */ 
/*     */   
/*     */   private static final String VCAP_APPLICATION = "VCAP_APPLICATION";
/*     */   
/*     */   private static final String VCAP_SERVICES = "VCAP_SERVICES";
/*     */   
/* 101 */   private int order = -2147483639;
/*     */   
/*     */   public void setOrder(int order) {
/* 104 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 109 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/* 114 */     if (CloudPlatform.CLOUD_FOUNDRY.isActive((Environment)environment)) {
/* 115 */       Properties properties = new Properties();
/* 116 */       JsonParser jsonParser = JsonParserFactory.getJsonParser();
/* 117 */       addWithPrefix(properties, getPropertiesFromApplication((Environment)environment, jsonParser), "vcap.application.");
/* 118 */       addWithPrefix(properties, getPropertiesFromServices((Environment)environment, jsonParser), "vcap.services.");
/* 119 */       MutablePropertySources propertySources = environment.getPropertySources();
/* 120 */       if (propertySources.contains("commandLineArgs")) {
/* 121 */         propertySources.addAfter("commandLineArgs", (PropertySource)new PropertiesPropertySource("vcap", properties));
/*     */       }
/*     */       else {
/*     */         
/* 125 */         propertySources.addFirst((PropertySource)new PropertiesPropertySource("vcap", properties));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addWithPrefix(Properties properties, Properties other, String prefix) {
/* 131 */     for (String key : other.stringPropertyNames()) {
/* 132 */       String prefixed = prefix + key;
/* 133 */       properties.setProperty(prefixed, other.getProperty(key));
/*     */     } 
/*     */   }
/*     */   
/*     */   private Properties getPropertiesFromApplication(Environment environment, JsonParser parser) {
/* 138 */     Properties properties = new Properties();
/*     */     try {
/* 140 */       String property = environment.getProperty("VCAP_APPLICATION", "{}");
/* 141 */       Map<String, Object> map = parser.parseMap(property);
/* 142 */       extractPropertiesFromApplication(properties, map);
/*     */     }
/* 144 */     catch (Exception ex) {
/* 145 */       logger.error("Could not parse VCAP_APPLICATION", ex);
/*     */     } 
/* 147 */     return properties;
/*     */   }
/*     */   
/*     */   private Properties getPropertiesFromServices(Environment environment, JsonParser parser) {
/* 151 */     Properties properties = new Properties();
/*     */     try {
/* 153 */       String property = environment.getProperty("VCAP_SERVICES", "{}");
/* 154 */       Map<String, Object> map = parser.parseMap(property);
/* 155 */       extractPropertiesFromServices(properties, map);
/*     */     }
/* 157 */     catch (Exception ex) {
/* 158 */       logger.error("Could not parse VCAP_SERVICES", ex);
/*     */     } 
/* 160 */     return properties;
/*     */   }
/*     */   
/*     */   private void extractPropertiesFromApplication(Properties properties, Map<String, Object> map) {
/* 164 */     if (map != null) {
/* 165 */       flatten(properties, map, "");
/*     */     }
/*     */   }
/*     */   
/*     */   private void extractPropertiesFromServices(Properties properties, Map<String, Object> map) {
/* 170 */     if (map != null) {
/* 171 */       for (Object services : map.values()) {
/*     */         
/* 173 */         List<Object> list = (List<Object>)services;
/* 174 */         for (Object object : list) {
/*     */           
/* 176 */           Map<String, Object> service = (Map<String, Object>)object;
/* 177 */           String key = (String)service.get("name");
/* 178 */           if (key == null) {
/* 179 */             key = (String)service.get("label");
/*     */           }
/* 181 */           flatten(properties, service, key);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void flatten(Properties properties, Map<String, Object> input, String path) {
/* 189 */     input.forEach((key, value) -> {
/*     */           String name = getPropertyName(path, key);
/*     */           if (value instanceof Map) {
/*     */             flatten(properties, (Map<String, Object>)value, name);
/*     */           } else if (value instanceof Collection) {
/*     */             Collection<Object> collection = (Collection<Object>)value;
/*     */             properties.put(name, StringUtils.collectionToCommaDelimitedString(collection));
/*     */             int count = 0;
/*     */             for (Object item : collection) {
/*     */               String itemKey = "[" + count++ + "]";
/*     */               flatten(properties, Collections.singletonMap(itemKey, item), name);
/*     */             } 
/*     */           } else if (value instanceof String) {
/*     */             properties.put(name, value);
/*     */           } else if (value instanceof Number) {
/*     */             properties.put(name, value.toString());
/*     */           } else if (value instanceof Boolean) {
/*     */             properties.put(name, value.toString());
/*     */           } else {
/*     */             properties.put(name, (value != null) ? value : "");
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPropertyName(String path, String key) {
/* 221 */     if (!StringUtils.hasText(path)) {
/* 222 */       return key;
/*     */     }
/* 224 */     if (key.startsWith("[")) {
/* 225 */       return path + key;
/*     */     }
/* 227 */     return path + "." + key;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\cloud\CloudFoundryVcapEnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
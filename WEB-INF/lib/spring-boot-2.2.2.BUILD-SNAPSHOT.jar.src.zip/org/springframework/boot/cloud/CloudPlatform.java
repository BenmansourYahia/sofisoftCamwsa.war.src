/*     */ package org.springframework.boot.cloud;
/*     */ 
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CloudPlatform
/*     */ {
/*  38 */   CLOUD_FOUNDRY
/*     */   {
/*     */     public boolean isActive(Environment environment)
/*     */     {
/*  42 */       return (environment.containsProperty("VCAP_APPLICATION") || environment.containsProperty("VCAP_SERVICES"));
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   HEROKU
/*     */   {
/*     */     public boolean isActive(Environment environment)
/*     */     {
/*  54 */       return environment.containsProperty("DYNO");
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   SAP
/*     */   {
/*     */     public boolean isActive(Environment environment)
/*     */     {
/*  66 */       return environment.containsProperty("HC_LANDSCAPE");
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   KUBERNETES
/*     */   {
/*     */     private static final String SERVICE_HOST_SUFFIX = "_SERVICE_HOST";
/*     */     
/*     */     private static final String SERVICE_PORT_SUFFIX = "_SERVICE_PORT";
/*     */ 
/*     */     
/*     */     public boolean isActive(Environment environment) {
/*  82 */       if (environment instanceof ConfigurableEnvironment) {
/*  83 */         return isActive((ConfigurableEnvironment)environment);
/*     */       }
/*  85 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isActive(ConfigurableEnvironment environment) {
/*  90 */       PropertySource<?> environmentPropertySource = environment.getPropertySources().get("systemEnvironment");
/*  91 */       if (environmentPropertySource instanceof EnumerablePropertySource) {
/*  92 */         return isActive((EnumerablePropertySource)environmentPropertySource);
/*     */       }
/*  94 */       return false;
/*     */     }
/*     */     
/*     */     private boolean isActive(EnumerablePropertySource<?> environmentPropertySource) {
/*  98 */       for (String propertyName : environmentPropertySource.getPropertyNames()) {
/*  99 */         if (propertyName.endsWith("_SERVICE_HOST")) {
/* 100 */           String serviceName = propertyName.substring(0, propertyName
/* 101 */               .length() - "_SERVICE_HOST".length());
/* 102 */           if (environmentPropertySource.getProperty(serviceName + "_SERVICE_PORT") != null) {
/* 103 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 107 */       return false;
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUsingForwardHeaders() {
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CloudPlatform getActive(Environment environment) {
/* 134 */     if (environment != null) {
/* 135 */       for (CloudPlatform cloudPlatform : values()) {
/* 136 */         if (cloudPlatform.isActive(environment)) {
/* 137 */           return cloudPlatform;
/*     */         }
/*     */       } 
/*     */     }
/* 141 */     return null;
/*     */   }
/*     */   
/*     */   public abstract boolean isActive(Environment paramEnvironment);
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\cloud\CloudPlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
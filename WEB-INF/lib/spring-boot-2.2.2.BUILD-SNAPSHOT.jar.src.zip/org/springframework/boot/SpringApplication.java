/*      */ package org.springframework.boot;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.security.AccessControlException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*      */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*      */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*      */ import org.springframework.boot.context.properties.bind.Bindable;
/*      */ import org.springframework.boot.context.properties.bind.Binder;
/*      */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*      */ import org.springframework.boot.convert.ApplicationConversionService;
/*      */ import org.springframework.boot.web.reactive.context.StandardReactiveWebEnvironment;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextInitializer;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.ConfigurableApplicationContext;
/*      */ import org.springframework.context.support.AbstractApplicationContext;
/*      */ import org.springframework.context.support.GenericApplicationContext;
/*      */ import org.springframework.core.GenericTypeResolver;
/*      */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*      */ import org.springframework.core.env.CompositePropertySource;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.env.MapPropertySource;
/*      */ import org.springframework.core.env.MutablePropertySources;
/*      */ import org.springframework.core.env.PropertySource;
/*      */ import org.springframework.core.env.SimpleCommandLinePropertySource;
/*      */ import org.springframework.core.env.StandardEnvironment;
/*      */ import org.springframework.core.io.DefaultResourceLoader;
/*      */ import org.springframework.core.io.ResourceLoader;
/*      */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StopWatch;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.web.context.support.StandardServletEnvironment;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SpringApplication
/*      */ {
/*      */   public static final String DEFAULT_CONTEXT_CLASS = "org.springframework.context.annotation.AnnotationConfigApplicationContext";
/*      */   public static final String DEFAULT_SERVLET_WEB_CONTEXT_CLASS = "org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext";
/*      */   public static final String DEFAULT_REACTIVE_WEB_CONTEXT_CLASS = "org.springframework.boot.web.reactive.context.AnnotationConfigReactiveWebServerApplicationContext";
/*      */   public static final String BANNER_LOCATION_PROPERTY_VALUE = "banner.txt";
/*      */   public static final String BANNER_LOCATION_PROPERTY = "spring.banner.location";
/*      */   private static final String SYSTEM_PROPERTY_JAVA_AWT_HEADLESS = "java.awt.headless";
/*  196 */   private static final Log logger = LogFactory.getLog(SpringApplication.class);
/*      */   
/*      */   private Set<Class<?>> primarySources;
/*      */   
/*  200 */   private Set<String> sources = new LinkedHashSet<>();
/*      */   
/*      */   private Class<?> mainApplicationClass;
/*      */   
/*  204 */   private Banner.Mode bannerMode = Banner.Mode.CONSOLE;
/*      */   
/*      */   private boolean logStartupInfo = true;
/*      */   
/*      */   private boolean addCommandLineProperties = true;
/*      */   
/*      */   private boolean addConversionService = true;
/*      */   
/*      */   private Banner banner;
/*      */   
/*      */   private ResourceLoader resourceLoader;
/*      */   
/*      */   private BeanNameGenerator beanNameGenerator;
/*      */   
/*      */   private ConfigurableEnvironment environment;
/*      */   
/*      */   private Class<? extends ConfigurableApplicationContext> applicationContextClass;
/*      */   
/*      */   private WebApplicationType webApplicationType;
/*      */   
/*      */   private boolean headless = true;
/*      */   
/*      */   private boolean registerShutdownHook = true;
/*      */   
/*      */   private List<ApplicationContextInitializer<?>> initializers;
/*      */   
/*      */   private List<ApplicationListener<?>> listeners;
/*      */   
/*      */   private Map<String, Object> defaultProperties;
/*      */   
/*  234 */   private Set<String> additionalProfiles = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowBeanDefinitionOverriding;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isCustomEnvironment = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean lazyInitialization = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SpringApplication(Class<?>... primarySources) {
/*  253 */     this(null, primarySources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SpringApplication(ResourceLoader resourceLoader, Class<?>... primarySources) {
/*  268 */     this.resourceLoader = resourceLoader;
/*  269 */     Assert.notNull(primarySources, "PrimarySources must not be null");
/*  270 */     this.primarySources = new LinkedHashSet<>(Arrays.asList(primarySources));
/*  271 */     this.webApplicationType = WebApplicationType.deduceFromClasspath();
/*  272 */     setInitializers(getSpringFactoriesInstances((Class)ApplicationContextInitializer.class));
/*  273 */     setListeners(getSpringFactoriesInstances((Class)ApplicationListener.class));
/*  274 */     this.mainApplicationClass = deduceMainApplicationClass();
/*      */   }
/*      */   
/*      */   private Class<?> deduceMainApplicationClass() {
/*      */     try {
/*  279 */       StackTraceElement[] stackTrace = (new RuntimeException()).getStackTrace();
/*  280 */       for (StackTraceElement stackTraceElement : stackTrace) {
/*  281 */         if ("main".equals(stackTraceElement.getMethodName())) {
/*  282 */           return Class.forName(stackTraceElement.getClassName());
/*      */         }
/*      */       }
/*      */     
/*  286 */     } catch (ClassNotFoundException classNotFoundException) {}
/*      */ 
/*      */     
/*  289 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurableApplicationContext run(String... args) {
/*  299 */     StopWatch stopWatch = new StopWatch();
/*  300 */     stopWatch.start();
/*  301 */     ConfigurableApplicationContext context = null;
/*  302 */     Collection<SpringBootExceptionReporter> exceptionReporters = new ArrayList<>();
/*  303 */     configureHeadlessProperty();
/*  304 */     SpringApplicationRunListeners listeners = getRunListeners(args);
/*  305 */     listeners.starting();
/*      */     try {
/*  307 */       ApplicationArguments applicationArguments = new DefaultApplicationArguments(args);
/*  308 */       ConfigurableEnvironment environment = prepareEnvironment(listeners, applicationArguments);
/*  309 */       configureIgnoreBeanInfo(environment);
/*  310 */       Banner printedBanner = printBanner(environment);
/*  311 */       context = createApplicationContext();
/*  312 */       exceptionReporters = getSpringFactoriesInstances(SpringBootExceptionReporter.class, new Class[] { ConfigurableApplicationContext.class }, new Object[] { context });
/*      */       
/*  314 */       prepareContext(context, environment, listeners, applicationArguments, printedBanner);
/*  315 */       refreshContext(context);
/*  316 */       afterRefresh(context, applicationArguments);
/*  317 */       stopWatch.stop();
/*  318 */       if (this.logStartupInfo) {
/*  319 */         (new StartupInfoLogger(this.mainApplicationClass)).logStarted(getApplicationLog(), stopWatch);
/*      */       }
/*  321 */       listeners.started(context);
/*  322 */       callRunners((ApplicationContext)context, applicationArguments);
/*      */     }
/*  324 */     catch (Throwable ex) {
/*  325 */       handleRunFailure(context, ex, exceptionReporters, listeners);
/*  326 */       throw new IllegalStateException(ex);
/*      */     } 
/*      */     
/*      */     try {
/*  330 */       listeners.running(context);
/*      */     }
/*  332 */     catch (Throwable ex) {
/*  333 */       handleRunFailure(context, ex, exceptionReporters, null);
/*  334 */       throw new IllegalStateException(ex);
/*      */     } 
/*  336 */     return context;
/*      */   }
/*      */ 
/*      */   
/*      */   private ConfigurableEnvironment prepareEnvironment(SpringApplicationRunListeners listeners, ApplicationArguments applicationArguments) {
/*      */     StandardEnvironment standardEnvironment;
/*  342 */     ConfigurableEnvironment environment = getOrCreateEnvironment();
/*  343 */     configureEnvironment(environment, applicationArguments.getSourceArgs());
/*  344 */     ConfigurationPropertySources.attach((Environment)environment);
/*  345 */     listeners.environmentPrepared(environment);
/*  346 */     bindToSpringApplication(environment);
/*  347 */     if (!this.isCustomEnvironment) {
/*  348 */       standardEnvironment = (new EnvironmentConverter(getClassLoader())).convertEnvironmentIfNecessary(environment, 
/*  349 */           deduceEnvironmentClass());
/*      */     }
/*  351 */     ConfigurationPropertySources.attach((Environment)standardEnvironment);
/*  352 */     return (ConfigurableEnvironment)standardEnvironment;
/*      */   }
/*      */   
/*      */   private Class<? extends StandardEnvironment> deduceEnvironmentClass() {
/*  356 */     switch (this.webApplicationType) {
/*      */       case SERVLET:
/*  358 */         return (Class)StandardServletEnvironment.class;
/*      */       case REACTIVE:
/*  360 */         return (Class)StandardReactiveWebEnvironment.class;
/*      */     } 
/*  362 */     return StandardEnvironment.class;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareContext(ConfigurableApplicationContext context, ConfigurableEnvironment environment, SpringApplicationRunListeners listeners, ApplicationArguments applicationArguments, Banner printedBanner) {
/*  368 */     context.setEnvironment(environment);
/*  369 */     postProcessApplicationContext(context);
/*  370 */     applyInitializers(context);
/*  371 */     listeners.contextPrepared(context);
/*  372 */     if (this.logStartupInfo) {
/*  373 */       logStartupInfo((context.getParent() == null));
/*  374 */       logStartupProfileInfo(context);
/*      */     } 
/*      */     
/*  377 */     ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/*  378 */     beanFactory.registerSingleton("springApplicationArguments", applicationArguments);
/*  379 */     if (printedBanner != null) {
/*  380 */       beanFactory.registerSingleton("springBootBanner", printedBanner);
/*      */     }
/*  382 */     if (beanFactory instanceof DefaultListableBeanFactory) {
/*  383 */       ((DefaultListableBeanFactory)beanFactory)
/*  384 */         .setAllowBeanDefinitionOverriding(this.allowBeanDefinitionOverriding);
/*      */     }
/*  386 */     if (this.lazyInitialization) {
/*  387 */       context.addBeanFactoryPostProcessor(new LazyInitializationBeanFactoryPostProcessor());
/*      */     }
/*      */     
/*  390 */     Set<Object> sources = getAllSources();
/*  391 */     Assert.notEmpty(sources, "Sources must not be empty");
/*  392 */     load((ApplicationContext)context, sources.toArray(new Object[0]));
/*  393 */     listeners.contextLoaded(context);
/*      */   }
/*      */   
/*      */   private void refreshContext(ConfigurableApplicationContext context) {
/*  397 */     refresh((ApplicationContext)context);
/*  398 */     if (this.registerShutdownHook) {
/*      */       try {
/*  400 */         context.registerShutdownHook();
/*      */       }
/*  402 */       catch (AccessControlException accessControlException) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void configureHeadlessProperty() {
/*  409 */     System.setProperty("java.awt.headless", 
/*  410 */         System.getProperty("java.awt.headless", Boolean.toString(this.headless)));
/*      */   }
/*      */   
/*      */   private SpringApplicationRunListeners getRunListeners(String[] args) {
/*  414 */     Class<?>[] types = new Class[] { SpringApplication.class, String[].class };
/*  415 */     return new SpringApplicationRunListeners(logger, 
/*  416 */         getSpringFactoriesInstances(SpringApplicationRunListener.class, types, new Object[] { this, args }));
/*      */   }
/*      */   
/*      */   private <T> Collection<T> getSpringFactoriesInstances(Class<T> type) {
/*  420 */     return getSpringFactoriesInstances(type, new Class[0], new Object[0]);
/*      */   }
/*      */   
/*      */   private <T> Collection<T> getSpringFactoriesInstances(Class<T> type, Class<?>[] parameterTypes, Object... args) {
/*  424 */     ClassLoader classLoader = getClassLoader();
/*      */     
/*  426 */     Set<String> names = new LinkedHashSet<>(SpringFactoriesLoader.loadFactoryNames(type, classLoader));
/*  427 */     List<T> instances = createSpringFactoriesInstances(type, parameterTypes, classLoader, args, names);
/*  428 */     AnnotationAwareOrderComparator.sort(instances);
/*  429 */     return instances;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> List<T> createSpringFactoriesInstances(Class<T> type, Class<?>[] parameterTypes, ClassLoader classLoader, Object[] args, Set<String> names) {
/*  435 */     List<T> instances = new ArrayList<>(names.size());
/*  436 */     for (String name : names) {
/*      */       try {
/*  438 */         Class<?> instanceClass = ClassUtils.forName(name, classLoader);
/*  439 */         Assert.isAssignable(type, instanceClass);
/*  440 */         Constructor<?> constructor = instanceClass.getDeclaredConstructor(parameterTypes);
/*  441 */         T instance = (T)BeanUtils.instantiateClass(constructor, args);
/*  442 */         instances.add(instance);
/*      */       }
/*  444 */       catch (Throwable ex) {
/*  445 */         throw new IllegalArgumentException("Cannot instantiate " + type + " : " + name, ex);
/*      */       } 
/*      */     } 
/*  448 */     return instances;
/*      */   }
/*      */   
/*      */   private ConfigurableEnvironment getOrCreateEnvironment() {
/*  452 */     if (this.environment != null) {
/*  453 */       return this.environment;
/*      */     }
/*  455 */     switch (this.webApplicationType) {
/*      */       case SERVLET:
/*  457 */         return (ConfigurableEnvironment)new StandardServletEnvironment();
/*      */       case REACTIVE:
/*  459 */         return (ConfigurableEnvironment)new StandardReactiveWebEnvironment();
/*      */     } 
/*  461 */     return (ConfigurableEnvironment)new StandardEnvironment();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureEnvironment(ConfigurableEnvironment environment, String[] args) {
/*  477 */     if (this.addConversionService) {
/*  478 */       ConversionService conversionService = ApplicationConversionService.getSharedInstance();
/*  479 */       environment.setConversionService((ConfigurableConversionService)conversionService);
/*      */     } 
/*  481 */     configurePropertySources(environment, args);
/*  482 */     configureProfiles(environment, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configurePropertySources(ConfigurableEnvironment environment, String[] args) {
/*  493 */     MutablePropertySources sources = environment.getPropertySources();
/*  494 */     if (this.defaultProperties != null && !this.defaultProperties.isEmpty()) {
/*  495 */       sources.addLast((PropertySource)new MapPropertySource("defaultProperties", this.defaultProperties));
/*      */     }
/*  497 */     if (this.addCommandLineProperties && args.length > 0) {
/*  498 */       String name = "commandLineArgs";
/*  499 */       if (sources.contains(name)) {
/*  500 */         PropertySource<?> source = sources.get(name);
/*  501 */         CompositePropertySource composite = new CompositePropertySource(name);
/*  502 */         composite.addPropertySource((PropertySource)new SimpleCommandLinePropertySource("springApplicationCommandLineArgs", args));
/*      */         
/*  504 */         composite.addPropertySource(source);
/*  505 */         sources.replace(name, (PropertySource)composite);
/*      */       } else {
/*      */         
/*  508 */         sources.addFirst((PropertySource)new SimpleCommandLinePropertySource(args));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureProfiles(ConfigurableEnvironment environment, String[] args) {
/*  523 */     Set<String> profiles = new LinkedHashSet<>(this.additionalProfiles);
/*  524 */     profiles.addAll(Arrays.asList(environment.getActiveProfiles()));
/*  525 */     environment.setActiveProfiles(StringUtils.toStringArray(profiles));
/*      */   }
/*      */   
/*      */   private void configureIgnoreBeanInfo(ConfigurableEnvironment environment) {
/*  529 */     if (System.getProperty("spring.beaninfo.ignore") == null) {
/*  530 */       Boolean ignore = (Boolean)environment.getProperty("spring.beaninfo.ignore", Boolean.class, Boolean.TRUE);
/*  531 */       System.setProperty("spring.beaninfo.ignore", ignore.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void bindToSpringApplication(ConfigurableEnvironment environment) {
/*      */     try {
/*  541 */       Binder.get((Environment)environment).bind("spring.main", Bindable.ofInstance(this));
/*      */     }
/*  543 */     catch (Exception ex) {
/*  544 */       throw new IllegalStateException("Cannot bind to SpringApplication", ex);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Banner printBanner(ConfigurableEnvironment environment) {
/*  549 */     if (this.bannerMode == Banner.Mode.OFF) {
/*  550 */       return null;
/*      */     }
/*      */     
/*  553 */     ResourceLoader resourceLoader = (this.resourceLoader != null) ? this.resourceLoader : (ResourceLoader)new DefaultResourceLoader(getClassLoader());
/*  554 */     SpringApplicationBannerPrinter bannerPrinter = new SpringApplicationBannerPrinter(resourceLoader, this.banner);
/*  555 */     if (this.bannerMode == Banner.Mode.LOG) {
/*  556 */       return bannerPrinter.print((Environment)environment, this.mainApplicationClass, logger);
/*      */     }
/*  558 */     return bannerPrinter.print((Environment)environment, this.mainApplicationClass, System.out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ConfigurableApplicationContext createApplicationContext() {
/*  569 */     Class<?> contextClass = this.applicationContextClass;
/*  570 */     if (contextClass == null)
/*      */       
/*  572 */       try { switch (this.webApplicationType)
/*      */         { case SERVLET:
/*  574 */             contextClass = Class.forName("org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  588 */             return (ConfigurableApplicationContext)BeanUtils.instantiateClass(contextClass);case REACTIVE: contextClass = Class.forName("org.springframework.boot.web.reactive.context.AnnotationConfigReactiveWebServerApplicationContext"); return (ConfigurableApplicationContext)BeanUtils.instantiateClass(contextClass); }  contextClass = Class.forName("org.springframework.context.annotation.AnnotationConfigApplicationContext"); } catch (ClassNotFoundException ex) { throw new IllegalStateException("Unable create a default ApplicationContext, please specify an ApplicationContextClass", ex); }   return (ConfigurableApplicationContext)BeanUtils.instantiateClass(contextClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void postProcessApplicationContext(ConfigurableApplicationContext context) {
/*  597 */     if (this.beanNameGenerator != null) {
/*  598 */       context.getBeanFactory().registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", this.beanNameGenerator);
/*      */     }
/*      */     
/*  601 */     if (this.resourceLoader != null) {
/*  602 */       if (context instanceof GenericApplicationContext) {
/*  603 */         ((GenericApplicationContext)context).setResourceLoader(this.resourceLoader);
/*      */       }
/*  605 */       if (context instanceof DefaultResourceLoader) {
/*  606 */         ((DefaultResourceLoader)context).setClassLoader(this.resourceLoader.getClassLoader());
/*      */       }
/*      */     } 
/*  609 */     if (this.addConversionService) {
/*  610 */       context.getBeanFactory().setConversionService(ApplicationConversionService.getSharedInstance());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyInitializers(ConfigurableApplicationContext context) {
/*  622 */     for (ApplicationContextInitializer<?> initializer : getInitializers()) {
/*  623 */       Class<?> requiredType = GenericTypeResolver.resolveTypeArgument(initializer.getClass(), ApplicationContextInitializer.class);
/*      */       
/*  625 */       Assert.isInstanceOf(requiredType, context, "Unable to call initializer.");
/*  626 */       initializer.initialize(context);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logStartupInfo(boolean isRoot) {
/*  636 */     if (isRoot) {
/*  637 */       (new StartupInfoLogger(this.mainApplicationClass)).logStarting(getApplicationLog());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logStartupProfileInfo(ConfigurableApplicationContext context) {
/*  646 */     Log log = getApplicationLog();
/*  647 */     if (log.isInfoEnabled()) {
/*  648 */       String[] activeProfiles = context.getEnvironment().getActiveProfiles();
/*  649 */       if (ObjectUtils.isEmpty((Object[])activeProfiles)) {
/*  650 */         String[] defaultProfiles = context.getEnvironment().getDefaultProfiles();
/*  651 */         log.info("No active profile set, falling back to default profiles: " + 
/*  652 */             StringUtils.arrayToCommaDelimitedString((Object[])defaultProfiles));
/*      */       } else {
/*      */         
/*  655 */         log.info("The following profiles are active: " + 
/*  656 */             StringUtils.arrayToCommaDelimitedString((Object[])activeProfiles));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Log getApplicationLog() {
/*  666 */     if (this.mainApplicationClass == null) {
/*  667 */       return logger;
/*      */     }
/*  669 */     return LogFactory.getLog(this.mainApplicationClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void load(ApplicationContext context, Object[] sources) {
/*  678 */     if (logger.isDebugEnabled()) {
/*  679 */       logger.debug("Loading source " + StringUtils.arrayToCommaDelimitedString(sources));
/*      */     }
/*  681 */     BeanDefinitionLoader loader = createBeanDefinitionLoader(getBeanDefinitionRegistry(context), sources);
/*  682 */     if (this.beanNameGenerator != null) {
/*  683 */       loader.setBeanNameGenerator(this.beanNameGenerator);
/*      */     }
/*  685 */     if (this.resourceLoader != null) {
/*  686 */       loader.setResourceLoader(this.resourceLoader);
/*      */     }
/*  688 */     if (this.environment != null) {
/*  689 */       loader.setEnvironment(this.environment);
/*      */     }
/*  691 */     loader.load();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceLoader getResourceLoader() {
/*  700 */     return this.resourceLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassLoader getClassLoader() {
/*  710 */     if (this.resourceLoader != null) {
/*  711 */       return this.resourceLoader.getClassLoader();
/*      */     }
/*  713 */     return ClassUtils.getDefaultClassLoader();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BeanDefinitionRegistry getBeanDefinitionRegistry(ApplicationContext context) {
/*  722 */     if (context instanceof BeanDefinitionRegistry) {
/*  723 */       return (BeanDefinitionRegistry)context;
/*      */     }
/*  725 */     if (context instanceof AbstractApplicationContext) {
/*  726 */       return (BeanDefinitionRegistry)((AbstractApplicationContext)context).getBeanFactory();
/*      */     }
/*  728 */     throw new IllegalStateException("Could not locate BeanDefinitionRegistry");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDefinitionLoader createBeanDefinitionLoader(BeanDefinitionRegistry registry, Object[] sources) {
/*  738 */     return new BeanDefinitionLoader(registry, sources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void refresh(ApplicationContext applicationContext) {
/*  746 */     Assert.isInstanceOf(AbstractApplicationContext.class, applicationContext);
/*  747 */     ((AbstractApplicationContext)applicationContext).refresh();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void afterRefresh(ConfigurableApplicationContext context, ApplicationArguments args) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void callRunners(ApplicationContext context, ApplicationArguments args) {
/*  759 */     List<Object> runners = new ArrayList();
/*  760 */     runners.addAll(context.getBeansOfType(ApplicationRunner.class).values());
/*  761 */     runners.addAll(context.getBeansOfType(CommandLineRunner.class).values());
/*  762 */     AnnotationAwareOrderComparator.sort(runners);
/*  763 */     for (Object runner : new LinkedHashSet(runners)) {
/*  764 */       if (runner instanceof ApplicationRunner) {
/*  765 */         callRunner((ApplicationRunner)runner, args);
/*      */       }
/*  767 */       if (runner instanceof CommandLineRunner) {
/*  768 */         callRunner((CommandLineRunner)runner, args);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void callRunner(ApplicationRunner runner, ApplicationArguments args) {
/*      */     try {
/*  775 */       runner.run(args);
/*      */     }
/*  777 */     catch (Exception ex) {
/*  778 */       throw new IllegalStateException("Failed to execute ApplicationRunner", ex);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void callRunner(CommandLineRunner runner, ApplicationArguments args) {
/*      */     try {
/*  784 */       runner.run(args.getSourceArgs());
/*      */     }
/*  786 */     catch (Exception ex) {
/*  787 */       throw new IllegalStateException("Failed to execute CommandLineRunner", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleRunFailure(ConfigurableApplicationContext context, Throwable exception, Collection<SpringBootExceptionReporter> exceptionReporters, SpringApplicationRunListeners listeners) {
/*      */     try {
/*      */       try {
/*  795 */         handleExitCode(context, exception);
/*  796 */         if (listeners != null) {
/*  797 */           listeners.failed(context, exception);
/*      */         }
/*      */       } finally {
/*      */         
/*  801 */         reportFailure(exceptionReporters, exception);
/*  802 */         if (context != null) {
/*  803 */           context.close();
/*      */         }
/*      */       }
/*      */     
/*  807 */     } catch (Exception ex) {
/*  808 */       logger.warn("Unable to close ApplicationContext", ex);
/*      */     } 
/*  810 */     ReflectionUtils.rethrowRuntimeException(exception);
/*      */   }
/*      */   
/*      */   private void reportFailure(Collection<SpringBootExceptionReporter> exceptionReporters, Throwable failure) {
/*      */     try {
/*  815 */       for (SpringBootExceptionReporter reporter : exceptionReporters) {
/*  816 */         if (reporter.reportException(failure)) {
/*  817 */           registerLoggedException(failure);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*  822 */     } catch (Throwable throwable) {}
/*      */ 
/*      */     
/*  825 */     if (logger.isErrorEnabled()) {
/*  826 */       logger.error("Application run failed", failure);
/*  827 */       registerLoggedException(failure);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerLoggedException(Throwable exception) {
/*  837 */     SpringBootExceptionHandler handler = getSpringBootExceptionHandler();
/*  838 */     if (handler != null) {
/*  839 */       handler.registerLoggedException(exception);
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleExitCode(ConfigurableApplicationContext context, Throwable exception) {
/*  844 */     int exitCode = getExitCodeFromException(context, exception);
/*  845 */     if (exitCode != 0) {
/*  846 */       if (context != null) {
/*  847 */         context.publishEvent(new ExitCodeEvent(context, exitCode));
/*      */       }
/*  849 */       SpringBootExceptionHandler handler = getSpringBootExceptionHandler();
/*  850 */       if (handler != null) {
/*  851 */         handler.registerExitCode(exitCode);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getExitCodeFromException(ConfigurableApplicationContext context, Throwable exception) {
/*  857 */     int exitCode = getExitCodeFromMappedException(context, exception);
/*  858 */     if (exitCode == 0) {
/*  859 */       exitCode = getExitCodeFromExitCodeGeneratorException(exception);
/*      */     }
/*  861 */     return exitCode;
/*      */   }
/*      */   
/*      */   private int getExitCodeFromMappedException(ConfigurableApplicationContext context, Throwable exception) {
/*  865 */     if (context == null || !context.isActive()) {
/*  866 */       return 0;
/*      */     }
/*  868 */     ExitCodeGenerators generators = new ExitCodeGenerators();
/*  869 */     Collection<ExitCodeExceptionMapper> beans = context.getBeansOfType(ExitCodeExceptionMapper.class).values();
/*  870 */     generators.addAll(exception, beans);
/*  871 */     return generators.getExitCode();
/*      */   }
/*      */   
/*      */   private int getExitCodeFromExitCodeGeneratorException(Throwable exception) {
/*  875 */     if (exception == null) {
/*  876 */       return 0;
/*      */     }
/*  878 */     if (exception instanceof ExitCodeGenerator) {
/*  879 */       return ((ExitCodeGenerator)exception).getExitCode();
/*      */     }
/*  881 */     return getExitCodeFromExitCodeGeneratorException(exception.getCause());
/*      */   }
/*      */   
/*      */   SpringBootExceptionHandler getSpringBootExceptionHandler() {
/*  885 */     if (isMainThread(Thread.currentThread())) {
/*  886 */       return SpringBootExceptionHandler.forCurrentThread();
/*      */     }
/*  888 */     return null;
/*      */   }
/*      */   
/*      */   private boolean isMainThread(Thread currentThread) {
/*  892 */     return (("main".equals(currentThread.getName()) || "restartedMain".equals(currentThread.getName())) && "main"
/*  893 */       .equals(currentThread.getThreadGroup().getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> getMainApplicationClass() {
/*  901 */     return this.mainApplicationClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMainApplicationClass(Class<?> mainApplicationClass) {
/*  911 */     this.mainApplicationClass = mainApplicationClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebApplicationType getWebApplicationType() {
/*  920 */     return this.webApplicationType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWebApplicationType(WebApplicationType webApplicationType) {
/*  930 */     Assert.notNull(webApplicationType, "WebApplicationType must not be null");
/*  931 */     this.webApplicationType = webApplicationType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding) {
/*  942 */     this.allowBeanDefinitionOverriding = allowBeanDefinitionOverriding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLazyInitialization(boolean lazyInitialization) {
/*  952 */     this.lazyInitialization = lazyInitialization;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeadless(boolean headless) {
/*  961 */     this.headless = headless;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRegisterShutdownHook(boolean registerShutdownHook) {
/*  971 */     this.registerShutdownHook = registerShutdownHook;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBanner(Banner banner) {
/*  980 */     this.banner = banner;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBannerMode(Banner.Mode bannerMode) {
/*  989 */     this.bannerMode = bannerMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogStartupInfo(boolean logStartupInfo) {
/*  998 */     this.logStartupInfo = logStartupInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAddCommandLineProperties(boolean addCommandLineProperties) {
/* 1007 */     this.addCommandLineProperties = addCommandLineProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAddConversionService(boolean addConversionService) {
/* 1017 */     this.addConversionService = addConversionService;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultProperties(Map<String, Object> defaultProperties) {
/* 1026 */     this.defaultProperties = defaultProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultProperties(Properties defaultProperties) {
/* 1034 */     this.defaultProperties = new HashMap<>();
/* 1035 */     for (Object key : Collections.list(defaultProperties.propertyNames())) {
/* 1036 */       this.defaultProperties.put((String)key, defaultProperties.get(key));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAdditionalProfiles(String... profiles) {
/* 1046 */     this.additionalProfiles = new LinkedHashSet<>(Arrays.asList(profiles));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator) {
/* 1054 */     this.beanNameGenerator = beanNameGenerator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnvironment(ConfigurableEnvironment environment) {
/* 1063 */     this.isCustomEnvironment = true;
/* 1064 */     this.environment = environment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPrimarySources(Collection<Class<?>> additionalPrimarySources) {
/* 1081 */     this.primarySources.addAll(additionalPrimarySources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getSources() {
/* 1095 */     return this.sources;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSources(Set<String> sources) {
/* 1109 */     Assert.notNull(sources, "Sources must not be null");
/* 1110 */     this.sources = new LinkedHashSet<>(sources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Object> getAllSources() {
/* 1121 */     Set<Object> allSources = new LinkedHashSet();
/* 1122 */     if (!CollectionUtils.isEmpty(this.primarySources)) {
/* 1123 */       allSources.addAll(this.primarySources);
/*      */     }
/* 1125 */     if (!CollectionUtils.isEmpty(this.sources)) {
/* 1126 */       allSources.addAll(this.sources);
/*      */     }
/* 1128 */     return Collections.unmodifiableSet(allSources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 1136 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 1137 */     this.resourceLoader = resourceLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setApplicationContextClass(Class<? extends ConfigurableApplicationContext> applicationContextClass) {
/* 1148 */     this.applicationContextClass = applicationContextClass;
/* 1149 */     this.webApplicationType = WebApplicationType.deduceFromApplicationContext(applicationContextClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInitializers(Collection<? extends ApplicationContextInitializer<?>> initializers) {
/* 1158 */     this.initializers = new ArrayList<>(initializers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInitializers(ApplicationContextInitializer<?>... initializers) {
/* 1167 */     this.initializers.addAll(Arrays.asList(initializers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<ApplicationContextInitializer<?>> getInitializers() {
/* 1176 */     return asUnmodifiableOrderedSet(this.initializers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListeners(Collection<? extends ApplicationListener<?>> listeners) {
/* 1185 */     this.listeners = new ArrayList<>(listeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addListeners(ApplicationListener<?>... listeners) {
/* 1194 */     this.listeners.addAll(Arrays.asList(listeners));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<ApplicationListener<?>> getListeners() {
/* 1204 */     return asUnmodifiableOrderedSet(this.listeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ConfigurableApplicationContext run(Class<?> primarySource, String... args) {
/* 1215 */     return run(new Class[] { primarySource }, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ConfigurableApplicationContext run(Class<?>[] primarySources, String[] args) {
/* 1226 */     return (new SpringApplication(primarySources)).run(args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) throws Exception {
/* 1242 */     run(new Class[0], args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int exit(ApplicationContext context, ExitCodeGenerator... exitCodeGenerators) {
/* 1257 */     Assert.notNull(context, "Context must not be null");
/* 1258 */     int exitCode = 0;
/*      */     try {
/*      */       try {
/* 1261 */         ExitCodeGenerators generators = new ExitCodeGenerators();
/* 1262 */         Collection<ExitCodeGenerator> beans = context.getBeansOfType(ExitCodeGenerator.class).values();
/* 1263 */         generators.addAll(exitCodeGenerators);
/* 1264 */         generators.addAll(beans);
/* 1265 */         exitCode = generators.getExitCode();
/* 1266 */         if (exitCode != 0) {
/* 1267 */           context.publishEvent(new ExitCodeEvent(context, exitCode));
/*      */         }
/*      */       } finally {
/*      */         
/* 1271 */         close(context);
/*      */       }
/*      */     
/* 1274 */     } catch (Exception ex) {
/* 1275 */       ex.printStackTrace();
/* 1276 */       exitCode = (exitCode != 0) ? exitCode : 1;
/*      */     } 
/* 1278 */     return exitCode;
/*      */   }
/*      */   
/*      */   private static void close(ApplicationContext context) {
/* 1282 */     if (context instanceof ConfigurableApplicationContext) {
/* 1283 */       ConfigurableApplicationContext closable = (ConfigurableApplicationContext)context;
/* 1284 */       closable.close();
/*      */     } 
/*      */   }
/*      */   
/*      */   private static <E> Set<E> asUnmodifiableOrderedSet(Collection<E> elements) {
/* 1289 */     List<E> list = new ArrayList<>(elements);
/* 1290 */     list.sort((Comparator<? super E>)AnnotationAwareOrderComparator.INSTANCE);
/* 1291 */     return new LinkedHashSet<>(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\SpringApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
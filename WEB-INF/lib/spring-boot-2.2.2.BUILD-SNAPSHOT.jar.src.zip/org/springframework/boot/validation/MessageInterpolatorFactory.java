/*    */ package org.springframework.boot.validation;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import javax.validation.MessageInterpolator;
/*    */ import javax.validation.Validation;
/*    */ import javax.validation.ValidationException;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageInterpolatorFactory
/*    */   implements ObjectFactory<MessageInterpolator>
/*    */ {
/*    */   private static final Set<String> FALLBACKS;
/*    */   
/*    */   static {
/* 45 */     Set<String> fallbacks = new LinkedHashSet<>();
/* 46 */     fallbacks.add("org.hibernate.validator.messageinterpolation.ParameterMessageInterpolator");
/* 47 */     FALLBACKS = Collections.unmodifiableSet(fallbacks);
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageInterpolator getObject() throws BeansException {
/*    */     try {
/* 53 */       return Validation.byDefaultProvider().configure().getDefaultMessageInterpolator();
/*    */     }
/* 55 */     catch (ValidationException ex) {
/* 56 */       MessageInterpolator fallback = getFallback();
/* 57 */       if (fallback != null) {
/* 58 */         return fallback;
/*    */       }
/* 60 */       throw ex;
/*    */     } 
/*    */   }
/*    */   
/*    */   private MessageInterpolator getFallback() {
/* 65 */     for (String fallback : FALLBACKS) {
/*    */       try {
/* 67 */         return getFallback(fallback);
/*    */       }
/* 69 */       catch (Exception exception) {}
/*    */     } 
/*    */ 
/*    */     
/* 73 */     return null;
/*    */   }
/*    */   
/*    */   private MessageInterpolator getFallback(String fallback) {
/* 77 */     Class<?> interpolatorClass = ClassUtils.resolveClassName(fallback, null);
/* 78 */     Object interpolator = BeanUtils.instantiateClass(interpolatorClass);
/* 79 */     return (MessageInterpolator)interpolator;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\validation\MessageInterpolatorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
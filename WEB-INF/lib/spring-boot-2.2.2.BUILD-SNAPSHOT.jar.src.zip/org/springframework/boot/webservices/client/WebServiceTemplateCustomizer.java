package org.springframework.boot.webservices.client;

import org.springframework.ws.client.core.WebServiceTemplate;

@FunctionalInterface
public interface WebServiceTemplateCustomizer {
  void customize(WebServiceTemplate paramWebServiceTemplate);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\webservices\client\WebServiceTemplateCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
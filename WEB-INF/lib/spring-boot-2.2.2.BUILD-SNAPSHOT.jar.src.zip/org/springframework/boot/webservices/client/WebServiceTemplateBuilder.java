/*     */ package org.springframework.boot.webservices.client;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.oxm.Marshaller;
/*     */ import org.springframework.oxm.Unmarshaller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.ws.WebServiceMessageFactory;
/*     */ import org.springframework.ws.client.core.FaultMessageResolver;
/*     */ import org.springframework.ws.client.core.WebServiceTemplate;
/*     */ import org.springframework.ws.client.support.destination.DestinationProvider;
/*     */ import org.springframework.ws.client.support.interceptor.ClientInterceptor;
/*     */ import org.springframework.ws.transport.WebServiceMessageSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceTemplateBuilder
/*     */ {
/*     */   private final boolean detectHttpMessageSender;
/*     */   private final Set<ClientInterceptor> interceptors;
/*     */   private final Set<WebServiceTemplateCustomizer> internalCustomizers;
/*     */   private final Set<WebServiceTemplateCustomizer> customizers;
/*     */   private final WebServiceMessageSenders messageSenders;
/*     */   private final Marshaller marshaller;
/*     */   private final Unmarshaller unmarshaller;
/*     */   private final DestinationProvider destinationProvider;
/*     */   private final Class<? extends TransformerFactory> transformerFactoryClass;
/*     */   private final WebServiceMessageFactory messageFactory;
/*     */   
/*     */   public WebServiceTemplateBuilder(WebServiceTemplateCustomizer... customizers) {
/*  80 */     this.detectHttpMessageSender = true;
/*  81 */     this.interceptors = null;
/*  82 */     this.internalCustomizers = null;
/*  83 */     this.customizers = Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(customizers)));
/*  84 */     this.messageSenders = new WebServiceMessageSenders();
/*  85 */     this.marshaller = null;
/*  86 */     this.unmarshaller = null;
/*  87 */     this.destinationProvider = null;
/*  88 */     this.transformerFactoryClass = null;
/*  89 */     this.messageFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WebServiceTemplateBuilder(boolean detectHttpMessageSender, Set<ClientInterceptor> interceptors, Set<WebServiceTemplateCustomizer> internalCustomizers, Set<WebServiceTemplateCustomizer> customizers, WebServiceMessageSenders messageSenders, Marshaller marshaller, Unmarshaller unmarshaller, DestinationProvider destinationProvider, Class<? extends TransformerFactory> transformerFactoryClass, WebServiceMessageFactory messageFactory) {
/*  97 */     this.detectHttpMessageSender = detectHttpMessageSender;
/*  98 */     this.interceptors = interceptors;
/*  99 */     this.internalCustomizers = internalCustomizers;
/* 100 */     this.customizers = customizers;
/* 101 */     this.messageSenders = messageSenders;
/* 102 */     this.marshaller = marshaller;
/* 103 */     this.unmarshaller = unmarshaller;
/* 104 */     this.destinationProvider = destinationProvider;
/* 105 */     this.transformerFactoryClass = transformerFactoryClass;
/* 106 */     this.messageFactory = messageFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder detectHttpMessageSender(boolean detectHttpMessageSender) {
/* 118 */     return new WebServiceTemplateBuilder(detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder messageSenders(WebServiceMessageSender... messageSenders) {
/* 135 */     Assert.notNull(messageSenders, "MessageSenders must not be null");
/* 136 */     return messageSenders(Arrays.asList(messageSenders));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder messageSenders(Collection<? extends WebServiceMessageSender> messageSenders) {
/* 151 */     Assert.notNull(messageSenders, "MessageSenders must not be null");
/* 152 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders
/* 153 */         .set(messageSenders), this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder additionalMessageSenders(WebServiceMessageSender... messageSenders) {
/* 165 */     Assert.notNull(messageSenders, "MessageSenders must not be null");
/* 166 */     return additionalMessageSenders(Arrays.asList(messageSenders));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder additionalMessageSenders(Collection<? extends WebServiceMessageSender> messageSenders) {
/* 178 */     Assert.notNull(messageSenders, "MessageSenders must not be null");
/* 179 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders
/* 180 */         .add(messageSenders), this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder interceptors(ClientInterceptor... interceptors) {
/* 193 */     Assert.notNull(interceptors, "Interceptors must not be null");
/* 194 */     return interceptors(Arrays.asList(interceptors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder interceptors(Collection<? extends ClientInterceptor> interceptors) {
/* 206 */     Assert.notNull(interceptors, "Interceptors must not be null");
/* 207 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, 
/* 208 */         append(Collections.emptySet(), interceptors), this.internalCustomizers, this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder additionalInterceptors(ClientInterceptor... interceptors) {
/* 221 */     Assert.notNull(interceptors, "Interceptors must not be null");
/* 222 */     return additionalInterceptors(Arrays.asList(interceptors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder additionalInterceptors(Collection<? extends ClientInterceptor> interceptors) {
/* 233 */     Assert.notNull(interceptors, "Interceptors must not be null");
/* 234 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, append(this.interceptors, interceptors), this.internalCustomizers, this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder customizers(WebServiceTemplateCustomizer... customizers) {
/* 249 */     Assert.notNull(customizers, "Customizers must not be null");
/* 250 */     return customizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder customizers(Collection<? extends WebServiceTemplateCustomizer> customizers) {
/* 263 */     Assert.notNull(customizers, "Customizers must not be null");
/* 264 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, 
/* 265 */         append(Collections.emptySet(), customizers), this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder additionalCustomizers(WebServiceTemplateCustomizer... customizers) {
/* 279 */     Assert.notNull(customizers, "Customizers must not be null");
/* 280 */     return additionalCustomizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder additionalCustomizers(Collection<? extends WebServiceTemplateCustomizer> customizers) {
/* 293 */     Assert.notNull(customizers, "Customizers must not be null");
/* 294 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, 
/* 295 */         append(this.customizers, customizers), this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setCheckConnectionForFault(boolean checkConnectionForFault) {
/* 307 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, 
/* 308 */         append(this.internalCustomizers, new CheckConnectionFaultCustomizer(checkConnectionForFault)), this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setCheckConnectionForError(boolean checkConnectionForError) {
/* 321 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, 
/* 322 */         append(this.internalCustomizers, new CheckConnectionForErrorCustomizer(checkConnectionForError)), this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setWebServiceMessageFactory(WebServiceMessageFactory messageFactory) {
/* 334 */     Assert.notNull(messageFactory, "MessageFactory must not be null");
/* 335 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setUnmarshaller(Unmarshaller unmarshaller) {
/* 347 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders, this.marshaller, unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setMarshaller(Marshaller marshaller) {
/* 359 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders, marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setFaultMessageResolver(FaultMessageResolver faultMessageResolver) {
/* 371 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, 
/* 372 */         append(this.internalCustomizers, new FaultMessageResolverCustomizer(faultMessageResolver)), this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setTransformerFactoryClass(Class<? extends TransformerFactory> transformerFactoryClass) {
/* 385 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, this.destinationProvider, transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setDefaultUri(String defaultUri) {
/* 400 */     Assert.hasText(defaultUri, "DefaultUri must not be empty");
/* 401 */     return setDestinationProvider(() -> URI.create(defaultUri));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplateBuilder setDestinationProvider(DestinationProvider destinationProvider) {
/* 413 */     Assert.notNull(destinationProvider, "DestinationProvider must not be null");
/* 414 */     return new WebServiceTemplateBuilder(this.detectHttpMessageSender, this.interceptors, this.internalCustomizers, this.customizers, this.messageSenders, this.marshaller, this.unmarshaller, destinationProvider, this.transformerFactoryClass, this.messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTemplate build() {
/* 427 */     return build(WebServiceTemplate.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends WebServiceTemplate> T build(Class<T> webServiceTemplateClass) {
/* 440 */     Assert.notNull(webServiceTemplateClass, "WebServiceTemplateClass must not be null");
/* 441 */     return configure((T)BeanUtils.instantiateClass(webServiceTemplateClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends WebServiceTemplate> T configure(T webServiceTemplate) {
/* 453 */     Assert.notNull(webServiceTemplate, "WebServiceTemplate must not be null");
/* 454 */     configureMessageSenders(webServiceTemplate);
/* 455 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 456 */     applyCustomizers((WebServiceTemplate)webServiceTemplate, this.internalCustomizers);
/* 457 */     map.from(this.marshaller).to(webServiceTemplate::setMarshaller);
/* 458 */     map.from(this.unmarshaller).to(webServiceTemplate::setUnmarshaller);
/* 459 */     map.from(this.destinationProvider).to(webServiceTemplate::setDestinationProvider);
/* 460 */     map.from(this.transformerFactoryClass).to(webServiceTemplate::setTransformerFactoryClass);
/* 461 */     map.from(this.messageFactory).to(webServiceTemplate::setMessageFactory);
/* 462 */     if (!CollectionUtils.isEmpty(this.interceptors)) {
/* 463 */       Set<ClientInterceptor> merged = new LinkedHashSet<>(this.interceptors);
/* 464 */       if (webServiceTemplate.getInterceptors() != null) {
/* 465 */         merged.addAll(Arrays.asList(webServiceTemplate.getInterceptors()));
/*     */       }
/* 467 */       webServiceTemplate.setInterceptors(merged.<ClientInterceptor>toArray(new ClientInterceptor[0]));
/*     */     } 
/* 469 */     applyCustomizers((WebServiceTemplate)webServiceTemplate, this.customizers);
/* 470 */     return webServiceTemplate;
/*     */   }
/*     */ 
/*     */   
/*     */   private void applyCustomizers(WebServiceTemplate webServiceTemplate, Set<WebServiceTemplateCustomizer> customizers) {
/* 475 */     if (!CollectionUtils.isEmpty(customizers)) {
/* 476 */       for (WebServiceTemplateCustomizer customizer : customizers) {
/* 477 */         customizer.customize(webServiceTemplate);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private <T extends WebServiceTemplate> void configureMessageSenders(T webServiceTemplate) {
/* 483 */     if (this.messageSenders.isOnlyAdditional() && this.detectHttpMessageSender) {
/* 484 */       Set<WebServiceMessageSender> merged = append(this.messageSenders.getMessageSenders(), (new HttpWebServiceMessageSenderBuilder())
/* 485 */           .build());
/* 486 */       webServiceTemplate.setMessageSenders(merged.<WebServiceMessageSender>toArray(new WebServiceMessageSender[0]));
/*     */     }
/* 488 */     else if (!CollectionUtils.isEmpty(this.messageSenders.getMessageSenders())) {
/* 489 */       webServiceTemplate
/* 490 */         .setMessageSenders(this.messageSenders.getMessageSenders().<WebServiceMessageSender>toArray(new WebServiceMessageSender[0]));
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T> Set<T> append(Set<T> set, T addition) {
/* 495 */     return append(set, Collections.singleton(addition));
/*     */   }
/*     */   
/*     */   private static <T> Set<T> append(Set<T> set, Collection<? extends T> additions) {
/* 499 */     Set<T> result = new LinkedHashSet<>((set != null) ? set : Collections.<T>emptySet());
/* 500 */     result.addAll((additions != null) ? additions : Collections.<T>emptyList());
/* 501 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class WebServiceMessageSenders
/*     */   {
/*     */     private final boolean onlyAdditional;
/*     */ 
/*     */     
/*     */     private Set<WebServiceMessageSender> messageSenders;
/*     */ 
/*     */     
/*     */     private WebServiceMessageSenders() {
/* 515 */       this(true, Collections.emptySet());
/*     */     }
/*     */     
/*     */     private WebServiceMessageSenders(boolean onlyAdditional, Set<WebServiceMessageSender> messageSenders) {
/* 519 */       this.onlyAdditional = onlyAdditional;
/* 520 */       this.messageSenders = messageSenders;
/*     */     }
/*     */     
/*     */     boolean isOnlyAdditional() {
/* 524 */       return this.onlyAdditional;
/*     */     }
/*     */     
/*     */     Set<WebServiceMessageSender> getMessageSenders() {
/* 528 */       return this.messageSenders;
/*     */     }
/*     */     
/*     */     WebServiceMessageSenders set(Collection<? extends WebServiceMessageSender> messageSenders) {
/* 532 */       return new WebServiceMessageSenders(false, new LinkedHashSet<>(messageSenders));
/*     */     }
/*     */     
/*     */     WebServiceMessageSenders add(Collection<? extends WebServiceMessageSender> messageSenders) {
/* 536 */       return new WebServiceMessageSenders(this.onlyAdditional, (Set)WebServiceTemplateBuilder.append((Set)this.messageSenders, (Collection)messageSenders));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class CheckConnectionFaultCustomizer
/*     */     implements WebServiceTemplateCustomizer
/*     */   {
/*     */     private final boolean checkConnectionFault;
/*     */ 
/*     */ 
/*     */     
/*     */     private CheckConnectionFaultCustomizer(boolean checkConnectionFault) {
/* 551 */       this.checkConnectionFault = checkConnectionFault;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(WebServiceTemplate webServiceTemplate) {
/* 556 */       webServiceTemplate.setCheckConnectionForFault(this.checkConnectionFault);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class CheckConnectionForErrorCustomizer
/*     */     implements WebServiceTemplateCustomizer
/*     */   {
/*     */     private final boolean checkConnectionForError;
/*     */ 
/*     */ 
/*     */     
/*     */     private CheckConnectionForErrorCustomizer(boolean checkConnectionForError) {
/* 571 */       this.checkConnectionForError = checkConnectionForError;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(WebServiceTemplate webServiceTemplate) {
/* 576 */       webServiceTemplate.setCheckConnectionForError(this.checkConnectionForError);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FaultMessageResolverCustomizer
/*     */     implements WebServiceTemplateCustomizer
/*     */   {
/*     */     private final FaultMessageResolver faultMessageResolver;
/*     */ 
/*     */ 
/*     */     
/*     */     private FaultMessageResolverCustomizer(FaultMessageResolver faultMessageResolver) {
/* 591 */       this.faultMessageResolver = faultMessageResolver;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(WebServiceTemplate webServiceTemplate) {
/* 596 */       webServiceTemplate.setFaultMessageResolver(this.faultMessageResolver);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\webservices\client\WebServiceTemplateBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
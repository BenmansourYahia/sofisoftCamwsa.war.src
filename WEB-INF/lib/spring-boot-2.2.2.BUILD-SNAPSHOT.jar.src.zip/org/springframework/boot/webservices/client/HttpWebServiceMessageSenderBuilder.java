/*     */ package org.springframework.boot.webservices.client;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.web.client.ClientHttpRequestFactorySupplier;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.ws.transport.WebServiceMessageSender;
/*     */ import org.springframework.ws.transport.http.ClientHttpRequestMessageSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpWebServiceMessageSenderBuilder
/*     */ {
/*     */   private Duration connectTimeout;
/*     */   private Duration readTimeout;
/*     */   private Supplier<ClientHttpRequestFactory> requestFactorySupplier;
/*     */   
/*     */   public HttpWebServiceMessageSenderBuilder setConnectTimeout(Duration connectTimeout) {
/*  51 */     this.connectTimeout = connectTimeout;
/*  52 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpWebServiceMessageSenderBuilder setReadTimeout(Duration readTimeout) {
/*  61 */     this.readTimeout = readTimeout;
/*  62 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpWebServiceMessageSenderBuilder requestFactory(Supplier<ClientHttpRequestFactory> requestFactorySupplier) {
/*  73 */     Assert.notNull(requestFactorySupplier, "RequestFactory Supplier must not be null");
/*  74 */     this.requestFactorySupplier = requestFactorySupplier;
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public WebServiceMessageSender build() {
/*  80 */     ClientHttpRequestFactory requestFactory = (this.requestFactorySupplier != null) ? this.requestFactorySupplier.get() : (new ClientHttpRequestFactorySupplier()).get();
/*  81 */     if (this.connectTimeout != null) {
/*  82 */       (new TimeoutRequestFactoryCustomizer(this.connectTimeout, "setConnectTimeout")).customize(requestFactory);
/*     */     }
/*  84 */     if (this.readTimeout != null) {
/*  85 */       (new TimeoutRequestFactoryCustomizer(this.readTimeout, "setReadTimeout")).customize(requestFactory);
/*     */     }
/*  87 */     return (WebServiceMessageSender)new ClientHttpRequestMessageSender(requestFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TimeoutRequestFactoryCustomizer
/*     */   {
/*     */     private final Duration timeout;
/*     */     
/*     */     private final String methodName;
/*     */ 
/*     */     
/*     */     TimeoutRequestFactoryCustomizer(Duration timeout, String methodName) {
/* 100 */       this.timeout = timeout;
/* 101 */       this.methodName = methodName;
/*     */     }
/*     */     
/*     */     void customize(ClientHttpRequestFactory factory) {
/* 105 */       ReflectionUtils.invokeMethod(findMethod(factory), factory, new Object[] { Integer.valueOf(Math.toIntExact(this.timeout.toMillis())) });
/*     */     }
/*     */     
/*     */     private Method findMethod(ClientHttpRequestFactory factory) {
/* 109 */       Method method = ReflectionUtils.findMethod(factory.getClass(), this.methodName, new Class[] { int.class });
/* 110 */       if (method != null) {
/* 111 */         return method;
/*     */       }
/* 113 */       throw new IllegalStateException("Request factory " + factory
/* 114 */           .getClass() + " does not have a " + this.methodName + "(int) method");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\webservices\client\HttpWebServiceMessageSenderBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.system;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JavaVersion
/*     */ {
/*  38 */   EIGHT("1.8", Optional.class, "empty"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   NINE("9", Optional.class, "stream"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   TEN("10", Optional.class, "orElseThrow"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   ELEVEN("11", String.class, "strip"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   TWELVE("12", String.class, "describeConstable"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   THIRTEEN("13", String.class, "stripIndent");
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final boolean available;
/*     */   
/*     */   JavaVersion(String name, Class<?> clazz, String methodName) {
/*  70 */     this.name = name;
/*  71 */     this.available = ClassUtils.hasMethod(clazz, methodName, new Class[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  76 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaVersion getJavaVersion() {
/*  84 */     List<JavaVersion> candidates = Arrays.asList(values());
/*  85 */     Collections.reverse(candidates);
/*  86 */     for (JavaVersion candidate : candidates) {
/*  87 */       if (candidate.available) {
/*  88 */         return candidate;
/*     */       }
/*     */     } 
/*  91 */     return EIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEqualOrNewerThan(JavaVersion version) {
/* 100 */     return (compareTo(version) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOlderThan(JavaVersion version) {
/* 109 */     return (compareTo(version) < 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\system\JavaVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
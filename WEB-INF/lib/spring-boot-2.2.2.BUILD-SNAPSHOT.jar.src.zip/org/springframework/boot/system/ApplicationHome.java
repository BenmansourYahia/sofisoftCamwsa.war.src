/*     */ package org.springframework.boot.system;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationHome
/*     */ {
/*     */   private final File source;
/*     */   private final File dir;
/*     */   
/*     */   public ApplicationHome() {
/*  52 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationHome(Class<?> sourceClass) {
/*  60 */     this.source = findSource((sourceClass != null) ? sourceClass : getStartClass());
/*  61 */     this.dir = findHomeDir(this.source);
/*     */   }
/*     */   
/*     */   private Class<?> getStartClass() {
/*     */     try {
/*  66 */       ClassLoader classLoader = getClass().getClassLoader();
/*  67 */       return getStartClass(classLoader.getResources("META-INF/MANIFEST.MF"));
/*     */     }
/*  69 */     catch (Exception ex) {
/*  70 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class<?> getStartClass(Enumeration<URL> manifestResources) {
/*  75 */     while (manifestResources.hasMoreElements()) {
/*  76 */       try (InputStream inputStream = ((URL)manifestResources.nextElement()).openStream()) {
/*  77 */         Manifest manifest = new Manifest(inputStream);
/*  78 */         String startClass = manifest.getMainAttributes().getValue("Start-Class");
/*  79 */         if (startClass != null) {
/*  80 */           return ClassUtils.forName(startClass, getClass().getClassLoader());
/*     */         }
/*     */       }
/*  83 */       catch (Exception exception) {}
/*     */     } 
/*     */     
/*  86 */     return null;
/*     */   }
/*     */   
/*     */   private File findSource(Class<?> sourceClass) {
/*     */     try {
/*  91 */       ProtectionDomain domain = (sourceClass != null) ? sourceClass.getProtectionDomain() : null;
/*  92 */       CodeSource codeSource = (domain != null) ? domain.getCodeSource() : null;
/*  93 */       URL location = (codeSource != null) ? codeSource.getLocation() : null;
/*  94 */       File source = (location != null) ? findSource(location) : null;
/*  95 */       if (source != null && source.exists() && !isUnitTest()) {
/*  96 */         return source.getAbsoluteFile();
/*     */       }
/*  98 */       return null;
/*     */     }
/* 100 */     catch (Exception ex) {
/* 101 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isUnitTest() {
/*     */     try {
/* 107 */       StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
/* 108 */       for (int i = stackTrace.length - 1; i >= 0; i--) {
/* 109 */         if (stackTrace[i].getClassName().startsWith("org.junit.")) {
/* 110 */           return true;
/*     */         }
/*     */       }
/*     */     
/* 114 */     } catch (Exception exception) {}
/*     */     
/* 116 */     return false;
/*     */   }
/*     */   
/*     */   private File findSource(URL location) throws IOException {
/* 120 */     URLConnection connection = location.openConnection();
/* 121 */     if (connection instanceof JarURLConnection) {
/* 122 */       return getRootJarFile(((JarURLConnection)connection).getJarFile());
/*     */     }
/* 124 */     return new File(location.getPath());
/*     */   }
/*     */   
/*     */   private File getRootJarFile(JarFile jarFile) {
/* 128 */     String name = jarFile.getName();
/* 129 */     int separator = name.indexOf("!/");
/* 130 */     if (separator > 0) {
/* 131 */       name = name.substring(0, separator);
/*     */     }
/* 133 */     return new File(name);
/*     */   }
/*     */   
/*     */   private File findHomeDir(File source) {
/* 137 */     File homeDir = source;
/* 138 */     homeDir = (homeDir != null) ? homeDir : findDefaultHomeDir();
/* 139 */     if (homeDir.isFile()) {
/* 140 */       homeDir = homeDir.getParentFile();
/*     */     }
/* 142 */     homeDir = homeDir.exists() ? homeDir : new File(".");
/* 143 */     return homeDir.getAbsoluteFile();
/*     */   }
/*     */   
/*     */   private File findDefaultHomeDir() {
/* 147 */     String userDir = System.getProperty("user.dir");
/* 148 */     return new File(StringUtils.hasLength(userDir) ? userDir : ".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getSource() {
/* 158 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getDir() {
/* 166 */     return this.dir;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return getDir().toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\system\ApplicationHome.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.system;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.attribute.PosixFilePermission;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationPid
/*     */ {
/*  39 */   private static final PosixFilePermission[] WRITE_PERMISSIONS = new PosixFilePermission[] { PosixFilePermission.OWNER_WRITE, PosixFilePermission.GROUP_WRITE, PosixFilePermission.OTHERS_WRITE };
/*     */   
/*     */   private final String pid;
/*     */ 
/*     */   
/*     */   public ApplicationPid() {
/*  45 */     this.pid = getPid();
/*     */   }
/*     */   
/*     */   protected ApplicationPid(String pid) {
/*  49 */     this.pid = pid;
/*     */   }
/*     */   
/*     */   private String getPid() {
/*     */     try {
/*  54 */       String jvmName = ManagementFactory.getRuntimeMXBean().getName();
/*  55 */       return jvmName.split("@")[0];
/*     */     }
/*  57 */     catch (Throwable ex) {
/*  58 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  64 */     if (obj == this) {
/*  65 */       return true;
/*     */     }
/*  67 */     if (obj instanceof ApplicationPid) {
/*  68 */       return ObjectUtils.nullSafeEquals(this.pid, ((ApplicationPid)obj).pid);
/*     */     }
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  75 */     return ObjectUtils.nullSafeHashCode(this.pid);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  80 */     return (this.pid != null) ? this.pid : "???";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File file) throws IOException {
/*  90 */     Assert.state((this.pid != null), "No PID available");
/*  91 */     createParentFolder(file);
/*  92 */     if (file.exists()) {
/*  93 */       assertCanOverwrite(file);
/*     */     }
/*  95 */     try (FileWriter writer = new FileWriter(file)) {
/*  96 */       writer.append(this.pid);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void createParentFolder(File file) {
/* 101 */     File parent = file.getParentFile();
/* 102 */     if (parent != null) {
/* 103 */       parent.mkdirs();
/*     */     }
/*     */   }
/*     */   
/*     */   private void assertCanOverwrite(File file) throws IOException {
/* 108 */     if (!file.canWrite() || !canWritePosixFile(file)) {
/* 109 */       throw new FileNotFoundException(file.toString() + " (permission denied)");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean canWritePosixFile(File file) throws IOException {
/*     */     try {
/* 115 */       Set<PosixFilePermission> permissions = Files.getPosixFilePermissions(file.toPath(), new java.nio.file.LinkOption[0]);
/* 116 */       for (PosixFilePermission permission : WRITE_PERMISSIONS) {
/* 117 */         if (permissions.contains(permission)) {
/* 118 */           return true;
/*     */         }
/*     */       } 
/* 121 */       return false;
/*     */     }
/* 123 */     catch (UnsupportedOperationException ex) {
/*     */       
/* 125 */       return true;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\system\ApplicationPid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.net.InetAddress;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.system.ApplicationHome;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StopWatch;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StartupInfoLogger
/*     */ {
/*  43 */   private static final Log logger = LogFactory.getLog(StartupInfoLogger.class);
/*     */   
/*     */   private static final long HOST_NAME_RESOLVE_THRESHOLD = 200L;
/*     */   
/*     */   private final Class<?> sourceClass;
/*     */   
/*     */   StartupInfoLogger(Class<?> sourceClass) {
/*  50 */     this.sourceClass = sourceClass;
/*     */   }
/*     */   
/*     */   void logStarting(Log applicationLog) {
/*  54 */     Assert.notNull(applicationLog, "Log must not be null");
/*  55 */     applicationLog.info(LogMessage.of(this::getStartingMessage));
/*  56 */     applicationLog.debug(LogMessage.of(this::getRunningMessage));
/*     */   }
/*     */   
/*     */   void logStarted(Log applicationLog, StopWatch stopWatch) {
/*  60 */     if (applicationLog.isInfoEnabled()) {
/*  61 */       applicationLog.info(getStartedMessage(stopWatch));
/*     */     }
/*     */   }
/*     */   
/*     */   private CharSequence getStartingMessage() {
/*  66 */     StringBuilder message = new StringBuilder();
/*  67 */     message.append("Starting ");
/*  68 */     appendApplicationName(message);
/*  69 */     appendVersion(message, this.sourceClass);
/*  70 */     appendOn(message);
/*  71 */     appendPid(message);
/*  72 */     appendContext(message);
/*  73 */     return message;
/*     */   }
/*     */   
/*     */   private CharSequence getRunningMessage() {
/*  77 */     StringBuilder message = new StringBuilder();
/*  78 */     message.append("Running with Spring Boot");
/*  79 */     appendVersion(message, getClass());
/*  80 */     message.append(", Spring");
/*  81 */     appendVersion(message, ApplicationContext.class);
/*  82 */     return message;
/*     */   }
/*     */   
/*     */   private CharSequence getStartedMessage(StopWatch stopWatch) {
/*  86 */     StringBuilder message = new StringBuilder();
/*  87 */     message.append("Started ");
/*  88 */     appendApplicationName(message);
/*  89 */     message.append(" in ");
/*  90 */     message.append(stopWatch.getTotalTimeMillis() / 1000.0D);
/*  91 */     message.append(" seconds");
/*     */     try {
/*  93 */       double uptime = ManagementFactory.getRuntimeMXBean().getUptime() / 1000.0D;
/*  94 */       message.append(" (JVM running for ").append(uptime).append(")");
/*     */     }
/*  96 */     catch (Throwable throwable) {}
/*     */ 
/*     */     
/*  99 */     return message;
/*     */   }
/*     */   
/*     */   private void appendApplicationName(StringBuilder message) {
/* 103 */     String name = (this.sourceClass != null) ? ClassUtils.getShortName(this.sourceClass) : "application";
/* 104 */     message.append(name);
/*     */   }
/*     */   
/*     */   private void appendVersion(StringBuilder message, Class<?> source) {
/* 108 */     append(message, "v", () -> source.getPackage().getImplementationVersion());
/*     */   }
/*     */   
/*     */   private void appendOn(StringBuilder message) {
/* 112 */     long startTime = System.currentTimeMillis();
/* 113 */     append(message, "on ", () -> InetAddress.getLocalHost().getHostName());
/* 114 */     long resolveTime = System.currentTimeMillis() - startTime;
/* 115 */     if (resolveTime > 200L) {
/* 116 */       logger.warn(LogMessage.of(() -> {
/*     */               StringBuilder warning = new StringBuilder();
/*     */               warning.append("InetAddress.getLocalHost().getHostName() took ");
/*     */               warning.append(resolveTime);
/*     */               warning.append(" milliseconds to respond.");
/*     */               warning.append(" Please verify your network configuration");
/*     */               if (System.getProperty("os.name").toLowerCase().contains("mac")) {
/*     */                 warning.append(" (macOS machines may need to add entries to /etc/hosts)");
/*     */               }
/*     */               warning.append(".");
/*     */               return warning;
/*     */             }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendPid(StringBuilder message) {
/* 132 */     append(message, "with PID ", org.springframework.boot.system.ApplicationPid::new);
/*     */   }
/*     */   
/*     */   private void appendContext(StringBuilder message) {
/* 136 */     StringBuilder context = new StringBuilder();
/* 137 */     ApplicationHome home = new ApplicationHome(this.sourceClass);
/* 138 */     if (home.getSource() != null) {
/* 139 */       context.append(home.getSource().getAbsolutePath());
/*     */     }
/* 141 */     append(context, "started by ", () -> System.getProperty("user.name"));
/* 142 */     append(context, "in ", () -> System.getProperty("user.dir"));
/* 143 */     if (context.length() > 0) {
/* 144 */       message.append(" (");
/* 145 */       message.append(context);
/* 146 */       message.append(")");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void append(StringBuilder message, String prefix, Callable<Object> call) {
/* 151 */     append(message, prefix, call, "");
/*     */   }
/*     */   
/*     */   private void append(StringBuilder message, String prefix, Callable<Object> call, String defaultValue) {
/* 155 */     Object result = callIfPossible(call);
/* 156 */     String value = (result != null) ? result.toString() : null;
/* 157 */     if (!StringUtils.hasLength(value)) {
/* 158 */       value = defaultValue;
/*     */     }
/* 160 */     if (StringUtils.hasLength(value)) {
/* 161 */       message.append((message.length() > 0) ? " " : "");
/* 162 */       message.append(prefix);
/* 163 */       message.append(value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object callIfPossible(Callable<Object> call) {
/*     */     try {
/* 169 */       return call.call();
/*     */     }
/* 171 */     catch (Exception ex) {
/* 172 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\StartupInfoLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
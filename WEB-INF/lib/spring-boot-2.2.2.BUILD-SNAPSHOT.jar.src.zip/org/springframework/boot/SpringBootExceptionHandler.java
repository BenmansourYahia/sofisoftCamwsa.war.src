/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringBootExceptionHandler
/*     */   implements Thread.UncaughtExceptionHandler
/*     */ {
/*     */   private static final Set<String> LOG_CONFIGURATION_MESSAGES;
/*     */   
/*     */   static {
/*  38 */     Set<String> messages = new HashSet<>();
/*  39 */     messages.add("Logback configuration error detected");
/*  40 */     LOG_CONFIGURATION_MESSAGES = Collections.unmodifiableSet(messages);
/*     */   }
/*     */   
/*  43 */   private static LoggedExceptionHandlerThreadLocal handler = new LoggedExceptionHandlerThreadLocal();
/*     */   
/*     */   private final Thread.UncaughtExceptionHandler parent;
/*     */   
/*  47 */   private final List<Throwable> loggedExceptions = new ArrayList<>();
/*     */   
/*  49 */   private int exitCode = 0;
/*     */   
/*     */   SpringBootExceptionHandler(Thread.UncaughtExceptionHandler parent) {
/*  52 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   void registerLoggedException(Throwable exception) {
/*  56 */     this.loggedExceptions.add(exception);
/*     */   }
/*     */   
/*     */   void registerExitCode(int exitCode) {
/*  60 */     this.exitCode = exitCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void uncaughtException(Thread thread, Throwable ex) {
/*     */     try {
/*  66 */       if (isPassedToParent(ex) && this.parent != null) {
/*  67 */         this.parent.uncaughtException(thread, ex);
/*     */       }
/*     */     } finally {
/*     */       
/*  71 */       this.loggedExceptions.clear();
/*  72 */       if (this.exitCode != 0) {
/*  73 */         System.exit(this.exitCode);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPassedToParent(Throwable ex) {
/*  79 */     return (isLogConfigurationMessage(ex) || !isRegistered(ex));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLogConfigurationMessage(Throwable ex) {
/*  89 */     if (ex instanceof java.lang.reflect.InvocationTargetException) {
/*  90 */       return isLogConfigurationMessage(ex.getCause());
/*     */     }
/*  92 */     String message = ex.getMessage();
/*  93 */     if (message != null) {
/*  94 */       for (String candidate : LOG_CONFIGURATION_MESSAGES) {
/*  95 */         if (message.contains(candidate)) {
/*  96 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isRegistered(Throwable ex) {
/* 104 */     if (this.loggedExceptions.contains(ex)) {
/* 105 */       return true;
/*     */     }
/* 107 */     if (ex instanceof java.lang.reflect.InvocationTargetException) {
/* 108 */       return isRegistered(ex.getCause());
/*     */     }
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   static SpringBootExceptionHandler forCurrentThread() {
/* 114 */     return handler.get();
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LoggedExceptionHandlerThreadLocal
/*     */     extends ThreadLocal<SpringBootExceptionHandler>
/*     */   {
/*     */     private LoggedExceptionHandlerThreadLocal() {}
/*     */ 
/*     */     
/*     */     protected SpringBootExceptionHandler initialValue() {
/* 125 */       SpringBootExceptionHandler handler = new SpringBootExceptionHandler(Thread.currentThread().getUncaughtExceptionHandler());
/* 126 */       Thread.currentThread().setUncaughtExceptionHandler(handler);
/* 127 */       return handler;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\SpringBootExceptionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
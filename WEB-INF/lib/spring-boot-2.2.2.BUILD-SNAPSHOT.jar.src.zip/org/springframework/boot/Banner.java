/*    */ package org.springframework.boot;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface Banner
/*    */ {
/*    */   void printBanner(Environment paramEnvironment, Class<?> paramClass, PrintStream paramPrintStream);
/*    */   
/*    */   public enum Mode
/*    */   {
/* 50 */     OFF,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 55 */     CONSOLE,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 60 */     LOG;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\Banner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.context;
/*    */ 
/*    */ import org.springframework.boot.web.server.WebServer;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebServerApplicationContext
/*    */   extends ApplicationContext
/*    */ {
/*    */   WebServer getWebServer();
/*    */   
/*    */   String getServerNamespace();
/*    */   
/*    */   static boolean hasServerNamespace(ApplicationContext context, String serverNamespace) {
/* 57 */     return (context instanceof WebServerApplicationContext && 
/* 58 */       ObjectUtils.nullSafeEquals(((WebServerApplicationContext)context).getServerNamespace(), serverNamespace));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\context\WebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
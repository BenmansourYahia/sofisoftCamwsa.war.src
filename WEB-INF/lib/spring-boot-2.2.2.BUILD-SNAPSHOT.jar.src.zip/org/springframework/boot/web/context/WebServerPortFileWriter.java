/*     */ package org.springframework.boot.web.context;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.system.SystemProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServerPortFileWriter
/*     */   implements ApplicationListener<WebServerInitializedEvent>
/*     */ {
/*     */   private static final String DEFAULT_FILE_NAME = "application.port";
/*  48 */   private static final String[] PROPERTY_VARIABLES = new String[] { "PORTFILE", "portfile" };
/*     */   
/*  50 */   private static final Log logger = LogFactory.getLog(WebServerPortFileWriter.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final File file;
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServerPortFileWriter() {
/*  59 */     this(new File("application.port"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServerPortFileWriter(String filename) {
/*  67 */     this(new File(filename));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServerPortFileWriter(File file) {
/*  75 */     Assert.notNull(file, "File must not be null");
/*  76 */     String override = SystemProperties.get(PROPERTY_VARIABLES);
/*  77 */     if (override != null) {
/*  78 */       this.file = new File(override);
/*     */     } else {
/*     */       
/*  81 */       this.file = file;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(WebServerInitializedEvent event) {
/*  87 */     File portFile = getPortFile(event.getApplicationContext());
/*     */     try {
/*  89 */       String port = String.valueOf(event.getWebServer().getPort());
/*  90 */       createParentFolder(portFile);
/*  91 */       FileCopyUtils.copy(port.getBytes(), portFile);
/*  92 */       portFile.deleteOnExit();
/*     */     }
/*  94 */     catch (Exception ex) {
/*  95 */       logger.warn(LogMessage.format("Cannot create port file %s", this.file));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getPortFile(ApplicationContext applicationContext) {
/* 107 */     String namespace = getServerNamespace(applicationContext);
/* 108 */     if (StringUtils.isEmpty(namespace)) {
/* 109 */       return this.file;
/*     */     }
/* 111 */     String name = this.file.getName();
/* 112 */     String extension = StringUtils.getFilenameExtension(this.file.getName());
/* 113 */     name = name.substring(0, name.length() - extension.length() - 1);
/* 114 */     if (isUpperCase(name)) {
/* 115 */       name = name + "-" + namespace.toUpperCase(Locale.ENGLISH);
/*     */     } else {
/*     */       
/* 118 */       name = name + "-" + namespace.toLowerCase(Locale.ENGLISH);
/*     */     } 
/* 120 */     if (StringUtils.hasLength(extension)) {
/* 121 */       name = name + "." + extension;
/*     */     }
/* 123 */     return new File(this.file.getParentFile(), name);
/*     */   }
/*     */   
/*     */   private String getServerNamespace(ApplicationContext applicationContext) {
/* 127 */     if (applicationContext instanceof WebServerApplicationContext) {
/* 128 */       return ((WebServerApplicationContext)applicationContext).getServerNamespace();
/*     */     }
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isUpperCase(String name) {
/* 134 */     for (int i = 0; i < name.length(); i++) {
/* 135 */       if (Character.isLetter(name.charAt(i)) && !Character.isUpperCase(name.charAt(i))) {
/* 136 */         return false;
/*     */       }
/*     */     } 
/* 139 */     return true;
/*     */   }
/*     */   
/*     */   private void createParentFolder(File file) {
/* 143 */     File parent = file.getParentFile();
/* 144 */     if (parent != null)
/* 145 */       parent.mkdirs(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\context\WebServerPortFileWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot.web.server;

import java.net.InetAddress;
import java.util.Set;

public interface ConfigurableWebServerFactory extends WebServerFactory, ErrorPageRegistry {
  void setPort(int paramInt);
  
  void setAddress(InetAddress paramInetAddress);
  
  void setErrorPages(Set<? extends ErrorPage> paramSet);
  
  void setSsl(Ssl paramSsl);
  
  void setSslStoreProvider(SslStoreProvider paramSslStoreProvider);
  
  void setHttp2(Http2 paramHttp2);
  
  void setCompression(Compression paramCompression);
  
  void setServerHeader(String paramString);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\server\ConfigurableWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
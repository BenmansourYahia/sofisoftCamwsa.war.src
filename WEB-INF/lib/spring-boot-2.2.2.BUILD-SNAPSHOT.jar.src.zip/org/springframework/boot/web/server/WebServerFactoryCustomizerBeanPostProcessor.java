/*    */ package org.springframework.boot.web.server;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ import org.springframework.boot.util.LambdaSafe;
/*    */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServerFactoryCustomizerBeanPostProcessor
/*    */   implements BeanPostProcessor, BeanFactoryAware
/*    */ {
/*    */   private ListableBeanFactory beanFactory;
/*    */   private List<WebServerFactoryCustomizer<?>> customizers;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) {
/* 50 */     Assert.isInstanceOf(ListableBeanFactory.class, beanFactory, "WebServerCustomizerBeanPostProcessor can only be used with a ListableBeanFactory");
/*    */     
/* 52 */     this.beanFactory = (ListableBeanFactory)beanFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/* 57 */     if (bean instanceof WebServerFactory) {
/* 58 */       postProcessBeforeInitialization((WebServerFactory)bean);
/*    */     }
/* 60 */     return bean;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
/* 65 */     return bean;
/*    */   }
/*    */ 
/*    */   
/*    */   private void postProcessBeforeInitialization(WebServerFactory webServerFactory) {
/* 70 */     ((LambdaSafe.Callbacks)LambdaSafe.callbacks(WebServerFactoryCustomizer.class, getCustomizers(), webServerFactory, new Object[0])
/* 71 */       .withLogger(WebServerFactoryCustomizerBeanPostProcessor.class))
/* 72 */       .invoke(customizer -> customizer.customize(webServerFactory));
/*    */   }
/*    */   
/*    */   private Collection<WebServerFactoryCustomizer<?>> getCustomizers() {
/* 76 */     if (this.customizers == null) {
/*    */       
/* 78 */       this.customizers = new ArrayList<>(getWebServerFactoryCustomizerBeans());
/* 79 */       this.customizers.sort((Comparator<? super WebServerFactoryCustomizer<?>>)AnnotationAwareOrderComparator.INSTANCE);
/* 80 */       this.customizers = Collections.unmodifiableList(this.customizers);
/*    */     } 
/* 82 */     return this.customizers;
/*    */   }
/*    */ 
/*    */   
/*    */   private Collection<WebServerFactoryCustomizer<?>> getWebServerFactoryCustomizerBeans() {
/* 87 */     return this.beanFactory.getBeansOfType(WebServerFactoryCustomizer.class, false, false).values();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\server\WebServerFactoryCustomizerBeanPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
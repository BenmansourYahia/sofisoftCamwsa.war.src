/*     */ package org.springframework.boot.web.server;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractConfigurableWebServerFactory
/*     */   implements ConfigurableWebServerFactory
/*     */ {
/*  42 */   private int port = 8080;
/*     */   
/*     */   private InetAddress address;
/*     */   
/*  46 */   private Set<ErrorPage> errorPages = new LinkedHashSet<>();
/*     */ 
/*     */   
/*     */   private Ssl ssl;
/*     */ 
/*     */   
/*     */   private SslStoreProvider sslStoreProvider;
/*     */ 
/*     */   
/*     */   private Http2 http2;
/*     */ 
/*     */   
/*     */   private Compression compression;
/*     */ 
/*     */   
/*     */   private String serverHeader;
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractConfigurableWebServerFactory() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractConfigurableWebServerFactory(int port) {
/*  70 */     this.port = port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/*  78 */     return this.port;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPort(int port) {
/*  83 */     this.port = port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InetAddress getAddress() {
/*  91 */     return this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAddress(InetAddress address) {
/*  96 */     this.address = address;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ErrorPage> getErrorPages() {
/* 105 */     return this.errorPages;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setErrorPages(Set<? extends ErrorPage> errorPages) {
/* 110 */     Assert.notNull(errorPages, "ErrorPages must not be null");
/* 111 */     this.errorPages = new LinkedHashSet<>(errorPages);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addErrorPages(ErrorPage... errorPages) {
/* 116 */     Assert.notNull(errorPages, "ErrorPages must not be null");
/* 117 */     this.errorPages.addAll(Arrays.asList(errorPages));
/*     */   }
/*     */   
/*     */   public Ssl getSsl() {
/* 121 */     return this.ssl;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSsl(Ssl ssl) {
/* 126 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */   public SslStoreProvider getSslStoreProvider() {
/* 130 */     return this.sslStoreProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSslStoreProvider(SslStoreProvider sslStoreProvider) {
/* 135 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */   
/*     */   public Http2 getHttp2() {
/* 139 */     return this.http2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHttp2(Http2 http2) {
/* 144 */     this.http2 = http2;
/*     */   }
/*     */   
/*     */   public Compression getCompression() {
/* 148 */     return this.compression;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCompression(Compression compression) {
/* 153 */     this.compression = compression;
/*     */   }
/*     */   
/*     */   public String getServerHeader() {
/* 157 */     return this.serverHeader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerHeader(String serverHeader) {
/* 162 */     this.serverHeader = serverHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final File createTempDir(String prefix) {
/*     */     try {
/* 172 */       File tempDir = File.createTempFile(prefix + ".", "." + getPort());
/* 173 */       tempDir.delete();
/* 174 */       tempDir.mkdir();
/* 175 */       tempDir.deleteOnExit();
/* 176 */       return tempDir;
/*     */     }
/* 178 */     catch (IOException ex) {
/* 179 */       throw new WebServerException("Unable to create tempDir. java.io.tmpdir is set to " + 
/* 180 */           System.getProperty("java.io.tmpdir"), ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\server\AbstractConfigurableWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
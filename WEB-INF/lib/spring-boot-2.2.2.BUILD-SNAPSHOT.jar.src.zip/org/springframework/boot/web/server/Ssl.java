/*     */ package org.springframework.boot.web.server;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ssl
/*     */ {
/*     */   private boolean enabled = true;
/*     */   private ClientAuth clientAuth;
/*     */   private String[] ciphers;
/*     */   private String[] enabledProtocols;
/*     */   private String keyAlias;
/*     */   private String keyPassword;
/*     */   private String keyStore;
/*     */   private String keyStorePassword;
/*     */   private String keyStoreType;
/*     */   private String keyStoreProvider;
/*     */   private String trustStore;
/*     */   private String trustStorePassword;
/*     */   private String trustStoreType;
/*     */   private String trustStoreProvider;
/*  57 */   private String protocol = "TLS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/*  64 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  68 */     this.enabled = enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientAuth getClientAuth() {
/*  77 */     return this.clientAuth;
/*     */   }
/*     */   
/*     */   public void setClientAuth(ClientAuth clientAuth) {
/*  81 */     this.clientAuth = clientAuth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getCiphers() {
/*  89 */     return this.ciphers;
/*     */   }
/*     */   
/*     */   public void setCiphers(String[] ciphers) {
/*  93 */     this.ciphers = ciphers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getEnabledProtocols() {
/* 101 */     return this.enabledProtocols;
/*     */   }
/*     */   
/*     */   public void setEnabledProtocols(String[] enabledProtocols) {
/* 105 */     this.enabledProtocols = enabledProtocols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyAlias() {
/* 113 */     return this.keyAlias;
/*     */   }
/*     */   
/*     */   public void setKeyAlias(String keyAlias) {
/* 117 */     this.keyAlias = keyAlias;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyPassword() {
/* 125 */     return this.keyPassword;
/*     */   }
/*     */   
/*     */   public void setKeyPassword(String keyPassword) {
/* 129 */     this.keyPassword = keyPassword;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyStore() {
/* 138 */     return this.keyStore;
/*     */   }
/*     */   
/*     */   public void setKeyStore(String keyStore) {
/* 142 */     this.keyStore = keyStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyStorePassword() {
/* 150 */     return this.keyStorePassword;
/*     */   }
/*     */   
/*     */   public void setKeyStorePassword(String keyStorePassword) {
/* 154 */     this.keyStorePassword = keyStorePassword;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyStoreType() {
/* 162 */     return this.keyStoreType;
/*     */   }
/*     */   
/*     */   public void setKeyStoreType(String keyStoreType) {
/* 166 */     this.keyStoreType = keyStoreType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyStoreProvider() {
/* 174 */     return this.keyStoreProvider;
/*     */   }
/*     */   
/*     */   public void setKeyStoreProvider(String keyStoreProvider) {
/* 178 */     this.keyStoreProvider = keyStoreProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTrustStore() {
/* 186 */     return this.trustStore;
/*     */   }
/*     */   
/*     */   public void setTrustStore(String trustStore) {
/* 190 */     this.trustStore = trustStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTrustStorePassword() {
/* 198 */     return this.trustStorePassword;
/*     */   }
/*     */   
/*     */   public void setTrustStorePassword(String trustStorePassword) {
/* 202 */     this.trustStorePassword = trustStorePassword;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTrustStoreType() {
/* 210 */     return this.trustStoreType;
/*     */   }
/*     */   
/*     */   public void setTrustStoreType(String trustStoreType) {
/* 214 */     this.trustStoreType = trustStoreType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTrustStoreProvider() {
/* 222 */     return this.trustStoreProvider;
/*     */   }
/*     */   
/*     */   public void setTrustStoreProvider(String trustStoreProvider) {
/* 226 */     this.trustStoreProvider = trustStoreProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProtocol() {
/* 234 */     return this.protocol;
/*     */   }
/*     */   
/*     */   public void setProtocol(String protocol) {
/* 238 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ClientAuth
/*     */   {
/* 249 */     NONE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     WANT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 259 */     NEED;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\server\Ssl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
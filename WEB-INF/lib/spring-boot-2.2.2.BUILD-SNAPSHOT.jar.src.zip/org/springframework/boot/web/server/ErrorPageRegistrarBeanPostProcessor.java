/*    */ package org.springframework.boot.web.server;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorPageRegistrarBeanPostProcessor
/*    */   implements BeanPostProcessor, BeanFactoryAware
/*    */ {
/*    */   private ListableBeanFactory beanFactory;
/*    */   private List<ErrorPageRegistrar> registrars;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) {
/* 48 */     Assert.isInstanceOf(ListableBeanFactory.class, beanFactory, "ErrorPageRegistrarBeanPostProcessor can only be used with a ListableBeanFactory");
/*    */     
/* 50 */     this.beanFactory = (ListableBeanFactory)beanFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/* 55 */     if (bean instanceof ErrorPageRegistry) {
/* 56 */       postProcessBeforeInitialization((ErrorPageRegistry)bean);
/*    */     }
/* 58 */     return bean;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
/* 63 */     return bean;
/*    */   }
/*    */   
/*    */   private void postProcessBeforeInitialization(ErrorPageRegistry registry) {
/* 67 */     for (ErrorPageRegistrar registrar : getRegistrars()) {
/* 68 */       registrar.registerErrorPages(registry);
/*    */     }
/*    */   }
/*    */   
/*    */   private Collection<ErrorPageRegistrar> getRegistrars() {
/* 73 */     if (this.registrars == null) {
/*    */       
/* 75 */       this
/* 76 */         .registrars = new ArrayList<>(this.beanFactory.getBeansOfType(ErrorPageRegistrar.class, false, false).values());
/* 77 */       this.registrars.sort((Comparator<? super ErrorPageRegistrar>)AnnotationAwareOrderComparator.INSTANCE);
/* 78 */       this.registrars = Collections.unmodifiableList(this.registrars);
/*    */     } 
/* 80 */     return this.registrars;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\server\ErrorPageRegistrarBeanPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.server;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PortInUseException
/*    */   extends WebServerException
/*    */ {
/*    */   private final int port;
/*    */   
/*    */   public PortInUseException(int port) {
/* 35 */     super("Port " + port + " is already in use", null);
/* 36 */     this.port = port;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPort() {
/* 44 */     return this.port;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\server\PortInUseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
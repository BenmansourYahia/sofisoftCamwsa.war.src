/*    */ package org.springframework.boot.web.client;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.springframework.boot.util.LambdaSafe;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.client.ClientHttpRequest;
/*    */ import org.springframework.http.client.ClientHttpRequestInitializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RestTemplateBuilderClientHttpRequestInitializer
/*    */   implements ClientHttpRequestInitializer
/*    */ {
/*    */   private final BasicAuthentication basicAuthentication;
/*    */   private final Map<String, List<String>> defaultHeaders;
/*    */   private final Set<RestTemplateRequestCustomizer<?>> requestCustomizers;
/*    */   
/*    */   RestTemplateBuilderClientHttpRequestInitializer(BasicAuthentication basicAuthentication, Map<String, List<String>> defaultHeaders, Set<RestTemplateRequestCustomizer<?>> requestCustomizers) {
/* 46 */     this.basicAuthentication = basicAuthentication;
/* 47 */     this.defaultHeaders = defaultHeaders;
/* 48 */     this.requestCustomizers = requestCustomizers;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(ClientHttpRequest request) {
/* 54 */     HttpHeaders headers = request.getHeaders();
/* 55 */     if (this.basicAuthentication != null) {
/* 56 */       this.basicAuthentication.applyTo(headers);
/*    */     }
/* 58 */     this.defaultHeaders.forEach(headers::putIfAbsent);
/* 59 */     LambdaSafe.callbacks(RestTemplateRequestCustomizer.class, this.requestCustomizers, request, new Object[0])
/* 60 */       .invoke(customizer -> customizer.customize(request));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\client\RestTemplateBuilderClientHttpRequestInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
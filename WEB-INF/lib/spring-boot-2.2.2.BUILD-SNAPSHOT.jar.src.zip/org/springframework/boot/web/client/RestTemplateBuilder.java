/*     */ package org.springframework.boot.web.client;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.charset.Charset;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.http.client.AbstractClientHttpRequestFactoryWrapper;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpRequestInterceptor;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.client.ResponseErrorHandler;
/*     */ import org.springframework.web.client.RestTemplate;
/*     */ import org.springframework.web.util.UriTemplateHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestTemplateBuilder
/*     */ {
/*     */   private final RequestFactoryCustomizer requestFactoryCustomizer;
/*     */   private final boolean detectRequestFactory;
/*     */   private final String rootUri;
/*     */   private final Set<HttpMessageConverter<?>> messageConverters;
/*     */   private final Set<ClientHttpRequestInterceptor> interceptors;
/*     */   private final Supplier<ClientHttpRequestFactory> requestFactory;
/*     */   private final UriTemplateHandler uriTemplateHandler;
/*     */   private final ResponseErrorHandler errorHandler;
/*     */   private final BasicAuthentication basicAuthentication;
/*     */   private final Map<String, List<String>> defaultHeaders;
/*     */   private final Set<RestTemplateCustomizer> customizers;
/*     */   private final Set<RestTemplateRequestCustomizer<?>> requestCustomizers;
/*     */   
/*     */   public RestTemplateBuilder(RestTemplateCustomizer... customizers) {
/* 106 */     Assert.notNull(customizers, "Customizers must not be null");
/* 107 */     this.requestFactoryCustomizer = new RequestFactoryCustomizer();
/* 108 */     this.detectRequestFactory = true;
/* 109 */     this.rootUri = null;
/* 110 */     this.messageConverters = null;
/* 111 */     this.interceptors = Collections.emptySet();
/* 112 */     this.requestFactory = null;
/* 113 */     this.uriTemplateHandler = null;
/* 114 */     this.errorHandler = null;
/* 115 */     this.basicAuthentication = null;
/* 116 */     this.defaultHeaders = Collections.emptyMap();
/* 117 */     this.customizers = copiedSetOf(customizers);
/* 118 */     this.requestCustomizers = Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RestTemplateBuilder(RequestFactoryCustomizer requestFactoryCustomizer, boolean detectRequestFactory, String rootUri, Set<HttpMessageConverter<?>> messageConverters, Set<ClientHttpRequestInterceptor> interceptors, Supplier<ClientHttpRequestFactory> requestFactorySupplier, UriTemplateHandler uriTemplateHandler, ResponseErrorHandler errorHandler, BasicAuthentication basicAuthentication, Map<String, List<String>> defaultHeaders, Set<RestTemplateCustomizer> customizers, Set<RestTemplateRequestCustomizer<?>> requestCustomizers) {
/* 127 */     this.requestFactoryCustomizer = requestFactoryCustomizer;
/* 128 */     this.detectRequestFactory = detectRequestFactory;
/* 129 */     this.rootUri = rootUri;
/* 130 */     this.messageConverters = messageConverters;
/* 131 */     this.interceptors = interceptors;
/* 132 */     this.requestFactory = requestFactorySupplier;
/* 133 */     this.uriTemplateHandler = uriTemplateHandler;
/* 134 */     this.errorHandler = errorHandler;
/* 135 */     this.basicAuthentication = basicAuthentication;
/* 136 */     this.defaultHeaders = defaultHeaders;
/* 137 */     this.customizers = customizers;
/* 138 */     this.requestCustomizers = requestCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder detectRequestFactory(boolean detectRequestFactory) {
/* 149 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder rootUri(String rootUri) {
/* 165 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder messageConverters(HttpMessageConverter<?>... messageConverters) {
/* 181 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/* 182 */     return messageConverters(Arrays.asList(messageConverters));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder messageConverters(Collection<? extends HttpMessageConverter<?>> messageConverters) {
/* 195 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/* 196 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, 
/* 197 */         copiedSetOf(messageConverters), this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalMessageConverters(HttpMessageConverter<?>... messageConverters) {
/* 211 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/* 212 */     return additionalMessageConverters(Arrays.asList(messageConverters));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalMessageConverters(Collection<? extends HttpMessageConverter<?>> messageConverters) {
/* 225 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/* 226 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, 
/* 227 */         append(this.messageConverters, messageConverters), this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder defaultMessageConverters() {
/* 240 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, 
/* 241 */         copiedSetOf((new RestTemplate()).getMessageConverters()), this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder interceptors(ClientHttpRequestInterceptor... interceptors) {
/* 256 */     Assert.notNull(interceptors, "interceptors must not be null");
/* 257 */     return interceptors(Arrays.asList(interceptors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder interceptors(Collection<ClientHttpRequestInterceptor> interceptors) {
/* 270 */     Assert.notNull(interceptors, "interceptors must not be null");
/* 271 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, 
/* 272 */         copiedSetOf(interceptors), this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalInterceptors(ClientHttpRequestInterceptor... interceptors) {
/* 286 */     Assert.notNull(interceptors, "interceptors must not be null");
/* 287 */     return additionalInterceptors(Arrays.asList(interceptors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalInterceptors(Collection<? extends ClientHttpRequestInterceptor> interceptors) {
/* 299 */     Assert.notNull(interceptors, "interceptors must not be null");
/* 300 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, 
/* 301 */         append(this.interceptors, interceptors), this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder requestFactory(Class<? extends ClientHttpRequestFactory> requestFactory) {
/* 313 */     Assert.notNull(requestFactory, "RequestFactory must not be null");
/* 314 */     return requestFactory(() -> createRequestFactory(requestFactory));
/*     */   }
/*     */   
/*     */   private ClientHttpRequestFactory createRequestFactory(Class<? extends ClientHttpRequestFactory> requestFactory) {
/*     */     try {
/* 319 */       Constructor<?> constructor = requestFactory.getDeclaredConstructor(new Class[0]);
/* 320 */       constructor.setAccessible(true);
/* 321 */       return (ClientHttpRequestFactory)constructor.newInstance(new Object[0]);
/*     */     }
/* 323 */     catch (Exception ex) {
/* 324 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder requestFactory(Supplier<ClientHttpRequestFactory> requestFactory) {
/* 336 */     Assert.notNull(requestFactory, "RequestFactory Supplier must not be null");
/* 337 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder uriTemplateHandler(UriTemplateHandler uriTemplateHandler) {
/* 349 */     Assert.notNull(uriTemplateHandler, "UriTemplateHandler must not be null");
/* 350 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder errorHandler(ResponseErrorHandler errorHandler) {
/* 362 */     Assert.notNull(errorHandler, "ErrorHandler must not be null");
/* 363 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder basicAuthentication(String username, String password) {
/* 378 */     return basicAuthentication(username, password, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder basicAuthentication(String username, String password, Charset charset) {
/* 391 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, new BasicAuthentication(username, password, charset), this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder defaultHeader(String name, String... values) {
/* 406 */     Assert.notNull(name, "Name must not be null");
/* 407 */     Assert.notNull(values, "Values must not be null");
/* 408 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, 
/*     */         
/* 410 */         append(this.defaultHeaders, name, values), this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder setConnectTimeout(Duration connectTimeout) {
/* 421 */     return new RestTemplateBuilder(this.requestFactoryCustomizer.connectTimeout(connectTimeout), this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder setReadTimeout(Duration readTimeout) {
/* 434 */     return new RestTemplateBuilder(this.requestFactoryCustomizer.readTimeout(readTimeout), this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder setBufferRequestBody(boolean bufferRequestBody) {
/* 450 */     return new RestTemplateBuilder(this.requestFactoryCustomizer.bufferRequestBody(bufferRequestBody), this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder customizers(RestTemplateCustomizer... customizers) {
/* 466 */     Assert.notNull(customizers, "Customizers must not be null");
/* 467 */     return customizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder customizers(Collection<? extends RestTemplateCustomizer> customizers) {
/* 480 */     Assert.notNull(customizers, "Customizers must not be null");
/* 481 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, 
/*     */         
/* 483 */         copiedSetOf(customizers), this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalCustomizers(RestTemplateCustomizer... customizers) {
/* 496 */     Assert.notNull(customizers, "Customizers must not be null");
/* 497 */     return additionalCustomizers(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalCustomizers(Collection<? extends RestTemplateCustomizer> customizers) {
/* 509 */     Assert.notNull(customizers, "RestTemplateCustomizers must not be null");
/* 510 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, 
/*     */         
/* 512 */         append(this.customizers, customizers), this.requestCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder requestCustomizers(RestTemplateRequestCustomizer<?>... requestCustomizers) {
/* 527 */     Assert.notNull(requestCustomizers, "RequestCustomizers must not be null");
/* 528 */     return requestCustomizers(Arrays.asList(requestCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder requestCustomizers(Collection<? extends RestTemplateRequestCustomizer<?>> requestCustomizers) {
/* 543 */     Assert.notNull(requestCustomizers, "RequestCustomizers must not be null");
/* 544 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, 
/*     */ 
/*     */         
/* 547 */         copiedSetOf(requestCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalRequestCustomizers(RestTemplateRequestCustomizer<?>... requestCustomizers) {
/* 560 */     Assert.notNull(requestCustomizers, "RequestCustomizers must not be null");
/* 561 */     return additionalRequestCustomizers(Arrays.asList(requestCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplateBuilder additionalRequestCustomizers(Collection<? extends RestTemplateRequestCustomizer<?>> requestCustomizers) {
/* 575 */     Assert.notNull(requestCustomizers, "RequestCustomizers must not be null");
/* 576 */     return new RestTemplateBuilder(this.requestFactoryCustomizer, this.detectRequestFactory, this.rootUri, this.messageConverters, this.interceptors, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthentication, this.defaultHeaders, this.customizers, 
/*     */ 
/*     */         
/* 579 */         append(this.requestCustomizers, requestCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestTemplate build() {
/* 589 */     return build(RestTemplate.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends RestTemplate> T build(Class<T> restTemplateClass) {
/* 602 */     return configure((T)BeanUtils.instantiateClass(restTemplateClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends RestTemplate> T configure(T restTemplate) {
/* 614 */     ClientHttpRequestFactory requestFactory = buildRequestFactory();
/* 615 */     if (requestFactory != null) {
/* 616 */       restTemplate.setRequestFactory(requestFactory);
/*     */     }
/* 618 */     addClientHttpRequestInitializer((RestTemplate)restTemplate);
/* 619 */     if (!CollectionUtils.isEmpty(this.messageConverters)) {
/* 620 */       restTemplate.setMessageConverters(new ArrayList<>(this.messageConverters));
/*     */     }
/* 622 */     if (this.uriTemplateHandler != null) {
/* 623 */       restTemplate.setUriTemplateHandler(this.uriTemplateHandler);
/*     */     }
/* 625 */     if (this.errorHandler != null) {
/* 626 */       restTemplate.setErrorHandler(this.errorHandler);
/*     */     }
/* 628 */     if (this.rootUri != null) {
/* 629 */       RootUriTemplateHandler.addTo((RestTemplate)restTemplate, this.rootUri);
/*     */     }
/* 631 */     restTemplate.getInterceptors().addAll(this.interceptors);
/* 632 */     if (!CollectionUtils.isEmpty(this.customizers)) {
/* 633 */       for (RestTemplateCustomizer customizer : this.customizers) {
/* 634 */         customizer.customize((RestTemplate)restTemplate);
/*     */       }
/*     */     }
/* 637 */     return restTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactory buildRequestFactory() {
/* 647 */     ClientHttpRequestFactory requestFactory = null;
/* 648 */     if (this.requestFactory != null) {
/* 649 */       requestFactory = this.requestFactory.get();
/*     */     }
/* 651 */     else if (this.detectRequestFactory) {
/* 652 */       requestFactory = (new ClientHttpRequestFactorySupplier()).get();
/*     */     } 
/* 654 */     if (requestFactory != null && 
/* 655 */       this.requestFactoryCustomizer != null) {
/* 656 */       this.requestFactoryCustomizer.accept(requestFactory);
/*     */     }
/*     */     
/* 659 */     return requestFactory;
/*     */   }
/*     */   
/*     */   private void addClientHttpRequestInitializer(RestTemplate restTemplate) {
/* 663 */     if (this.basicAuthentication == null && this.defaultHeaders.isEmpty() && this.requestCustomizers.isEmpty()) {
/*     */       return;
/*     */     }
/* 666 */     restTemplate.getClientHttpRequestInitializers().add(new RestTemplateBuilderClientHttpRequestInitializer(this.basicAuthentication, this.defaultHeaders, this.requestCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> Set<T> copiedSetOf(T... items) {
/* 672 */     return copiedSetOf(Arrays.asList(items));
/*     */   }
/*     */   
/*     */   private <T> Set<T> copiedSetOf(Collection<? extends T> collection) {
/* 676 */     return Collections.unmodifiableSet(new LinkedHashSet<>(collection));
/*     */   }
/*     */   
/*     */   private static <T> List<T> copiedListOf(T[] items) {
/* 680 */     return Collections.unmodifiableList(Arrays.asList(Arrays.copyOf(items, items.length)));
/*     */   }
/*     */   
/*     */   private static <T> Set<T> append(Collection<? extends T> collection, Collection<? extends T> additions) {
/* 684 */     Set<T> result = new LinkedHashSet<>((collection != null) ? collection : Collections.<T>emptySet());
/* 685 */     if (additions != null) {
/* 686 */       result.addAll(additions);
/*     */     }
/* 688 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */   
/*     */   private static <K, V> Map<K, List<V>> append(Map<K, List<V>> map, K key, V[] values) {
/* 692 */     Map<K, List<V>> result = new LinkedHashMap<>((map != null) ? map : Collections.<K, List<V>>emptyMap());
/* 693 */     if (values != null) {
/* 694 */       result.put(key, copiedListOf(values));
/*     */     }
/* 696 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class RequestFactoryCustomizer
/*     */     implements Consumer<ClientHttpRequestFactory>
/*     */   {
/*     */     private final Duration connectTimeout;
/*     */     
/*     */     private final Duration readTimeout;
/*     */     
/*     */     private final Boolean bufferRequestBody;
/*     */ 
/*     */     
/*     */     RequestFactoryCustomizer() {
/* 711 */       this(null, null, null);
/*     */     }
/*     */     
/*     */     private RequestFactoryCustomizer(Duration connectTimeout, Duration readTimeout, Boolean bufferRequestBody) {
/* 715 */       this.connectTimeout = connectTimeout;
/* 716 */       this.readTimeout = readTimeout;
/* 717 */       this.bufferRequestBody = bufferRequestBody;
/*     */     }
/*     */     
/*     */     RequestFactoryCustomizer connectTimeout(Duration connectTimeout) {
/* 721 */       return new RequestFactoryCustomizer(connectTimeout, this.readTimeout, this.bufferRequestBody);
/*     */     }
/*     */     
/*     */     RequestFactoryCustomizer readTimeout(Duration readTimeout) {
/* 725 */       return new RequestFactoryCustomizer(this.connectTimeout, readTimeout, this.bufferRequestBody);
/*     */     }
/*     */     
/*     */     RequestFactoryCustomizer bufferRequestBody(boolean bufferRequestBody) {
/* 729 */       return new RequestFactoryCustomizer(this.connectTimeout, this.readTimeout, Boolean.valueOf(bufferRequestBody));
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(ClientHttpRequestFactory requestFactory) {
/* 734 */       ClientHttpRequestFactory unwrappedRequestFactory = unwrapRequestFactoryIfNecessary(requestFactory);
/* 735 */       if (this.connectTimeout != null) {
/* 736 */         setConnectTimeout(unwrappedRequestFactory);
/*     */       }
/* 738 */       if (this.readTimeout != null) {
/* 739 */         setReadTimeout(unwrappedRequestFactory);
/*     */       }
/* 741 */       if (this.bufferRequestBody != null) {
/* 742 */         setBufferRequestBody(unwrappedRequestFactory);
/*     */       }
/*     */     }
/*     */     
/*     */     private ClientHttpRequestFactory unwrapRequestFactoryIfNecessary(ClientHttpRequestFactory requestFactory) {
/* 747 */       if (!(requestFactory instanceof AbstractClientHttpRequestFactoryWrapper)) {
/* 748 */         return requestFactory;
/*     */       }
/* 750 */       Field field = ReflectionUtils.findField(AbstractClientHttpRequestFactoryWrapper.class, "requestFactory");
/* 751 */       ReflectionUtils.makeAccessible(field);
/* 752 */       ClientHttpRequestFactory unwrappedRequestFactory = requestFactory;
/* 753 */       while (unwrappedRequestFactory instanceof AbstractClientHttpRequestFactoryWrapper) {
/* 754 */         unwrappedRequestFactory = (ClientHttpRequestFactory)ReflectionUtils.getField(field, unwrappedRequestFactory);
/*     */       }
/*     */       
/* 757 */       return unwrappedRequestFactory;
/*     */     }
/*     */     
/*     */     private void setConnectTimeout(ClientHttpRequestFactory factory) {
/* 761 */       Method method = findMethod(factory, "setConnectTimeout", new Class[] { int.class });
/* 762 */       int timeout = Math.toIntExact(this.connectTimeout.toMillis());
/* 763 */       invoke(factory, method, new Object[] { Integer.valueOf(timeout) });
/*     */     }
/*     */     
/*     */     private void setReadTimeout(ClientHttpRequestFactory factory) {
/* 767 */       Method method = findMethod(factory, "setReadTimeout", new Class[] { int.class });
/* 768 */       int timeout = Math.toIntExact(this.readTimeout.toMillis());
/* 769 */       invoke(factory, method, new Object[] { Integer.valueOf(timeout) });
/*     */     }
/*     */     
/*     */     private void setBufferRequestBody(ClientHttpRequestFactory factory) {
/* 773 */       Method method = findMethod(factory, "setBufferRequestBody", new Class[] { boolean.class });
/* 774 */       invoke(factory, method, new Object[] { this.bufferRequestBody });
/*     */     }
/*     */     
/*     */     private Method findMethod(ClientHttpRequestFactory requestFactory, String methodName, Class<?>... parameters) {
/* 778 */       Method method = ReflectionUtils.findMethod(requestFactory.getClass(), methodName, parameters);
/* 779 */       if (method != null) {
/* 780 */         return method;
/*     */       }
/* 782 */       throw new IllegalStateException("Request factory " + requestFactory.getClass() + " does not have a suitable " + methodName + " method");
/*     */     }
/*     */ 
/*     */     
/*     */     private void invoke(ClientHttpRequestFactory requestFactory, Method method, Object... parameters) {
/* 787 */       ReflectionUtils.invokeMethod(method, requestFactory, parameters);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\client\RestTemplateBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.reactive.context;
/*    */ 
/*    */ import org.springframework.boot.web.context.WebServerApplicationContext;
/*    */ import org.springframework.boot.web.context.WebServerInitializedEvent;
/*    */ import org.springframework.boot.web.server.WebServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactiveWebServerInitializedEvent
/*    */   extends WebServerInitializedEvent
/*    */ {
/*    */   private final ReactiveWebServerApplicationContext applicationContext;
/*    */   
/*    */   public ReactiveWebServerInitializedEvent(WebServer webServer, ReactiveWebServerApplicationContext applicationContext) {
/* 37 */     super(webServer);
/* 38 */     this.applicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public ReactiveWebServerApplicationContext getApplicationContext() {
/* 43 */     return this.applicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\context\ReactiveWebServerInitializedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
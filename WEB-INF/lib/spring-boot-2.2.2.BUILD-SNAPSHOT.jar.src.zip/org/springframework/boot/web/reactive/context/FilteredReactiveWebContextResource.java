/*    */ package org.springframework.boot.web.reactive.context;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.core.io.AbstractResource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FilteredReactiveWebContextResource
/*    */   extends AbstractResource
/*    */ {
/*    */   private final String path;
/*    */   
/*    */   FilteredReactiveWebContextResource(String path) {
/* 42 */     this.path = path;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean exists() {
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Resource createRelative(String relativePath) throws IOException {
/* 52 */     String pathToUse = StringUtils.applyRelativePath(this.path, relativePath);
/* 53 */     return (Resource)new FilteredReactiveWebContextResource(pathToUse);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 58 */     return "ReactiveWebContext resource [" + this.path + "]";
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() throws IOException {
/* 63 */     throw new FileNotFoundException(getDescription() + " cannot be opened because it does not exist");
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\context\FilteredReactiveWebContextResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
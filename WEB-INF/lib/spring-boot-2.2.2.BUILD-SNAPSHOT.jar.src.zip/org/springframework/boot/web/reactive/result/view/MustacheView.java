/*     */ package org.springframework.boot.web.reactive.result.view;
/*     */ 
/*     */ import com.samskivert.mustache.Mustache;
/*     */ import com.samskivert.mustache.Template;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.reactive.result.view.AbstractUrlBasedView;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MustacheView
/*     */   extends AbstractUrlBasedView
/*     */ {
/*     */   private Mustache.Compiler compiler;
/*     */   private String charset;
/*     */   
/*     */   public void setCompiler(Mustache.Compiler compiler) {
/*  61 */     this.compiler = compiler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(String charset) {
/*  69 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkResourceExists(Locale locale) throws Exception {
/*  74 */     return (resolveResource() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Mono<Void> renderInternal(Map<String, Object> model, MediaType contentType, ServerWebExchange exchange) {
/*  79 */     Resource resource = resolveResource();
/*  80 */     if (resource == null) {
/*  81 */       return 
/*  82 */         Mono.error(new IllegalStateException("Could not find Mustache template with URL [" + getUrl() + "]"));
/*     */     }
/*  84 */     DataBuffer dataBuffer = exchange.getResponse().bufferFactory().allocateBuffer();
/*  85 */     try (Reader reader = getReader(resource)) {
/*  86 */       Template template = this.compiler.compile(reader);
/*  87 */       Charset charset = getCharset(contentType).orElse(getDefaultCharset());
/*  88 */       try (Writer writer = new OutputStreamWriter(dataBuffer.asOutputStream(), charset)) {
/*  89 */         template.execute(model, writer);
/*  90 */         writer.flush();
/*     */       }
/*     */     
/*  93 */     } catch (Exception ex) {
/*  94 */       DataBufferUtils.release(dataBuffer);
/*  95 */       return Mono.error(ex);
/*     */     } 
/*  97 */     return exchange.getResponse().writeWith((Publisher)Flux.just(dataBuffer));
/*     */   }
/*     */   
/*     */   private Resource resolveResource() {
/* 101 */     Resource resource = getApplicationContext().getResource(getUrl());
/* 102 */     if (resource == null || !resource.exists()) {
/* 103 */       return null;
/*     */     }
/* 105 */     return resource;
/*     */   }
/*     */   
/*     */   private Reader getReader(Resource resource) throws IOException {
/* 109 */     if (this.charset != null) {
/* 110 */       return new InputStreamReader(resource.getInputStream(), this.charset);
/*     */     }
/* 112 */     return new InputStreamReader(resource.getInputStream());
/*     */   }
/*     */   
/*     */   private Optional<Charset> getCharset(MediaType mediaType) {
/* 116 */     return Optional.ofNullable((mediaType != null) ? mediaType.getCharset() : null);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\result\view\MustacheView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
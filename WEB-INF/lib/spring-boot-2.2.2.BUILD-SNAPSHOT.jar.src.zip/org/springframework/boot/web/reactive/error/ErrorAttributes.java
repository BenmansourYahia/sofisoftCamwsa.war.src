package org.springframework.boot.web.reactive.error;

import java.util.Map;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.server.ServerWebExchange;

public interface ErrorAttributes {
  Map<String, Object> getErrorAttributes(ServerRequest paramServerRequest, boolean paramBoolean);
  
  Throwable getError(ServerRequest paramServerRequest);
  
  void storeErrorInformation(Throwable paramThrowable, ServerWebExchange paramServerWebExchange);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\error\ErrorAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
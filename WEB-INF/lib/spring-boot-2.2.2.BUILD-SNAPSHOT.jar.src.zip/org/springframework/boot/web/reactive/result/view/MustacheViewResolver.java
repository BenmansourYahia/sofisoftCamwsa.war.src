/*    */ package org.springframework.boot.web.reactive.result.view;
/*    */ 
/*    */ import com.samskivert.mustache.Mustache;
/*    */ import org.springframework.web.reactive.result.view.AbstractUrlBasedView;
/*    */ import org.springframework.web.reactive.result.view.UrlBasedViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MustacheViewResolver
/*    */   extends UrlBasedViewResolver
/*    */ {
/*    */   private final Mustache.Compiler compiler;
/*    */   private String charset;
/*    */   
/*    */   public MustacheViewResolver() {
/* 43 */     this.compiler = Mustache.compiler();
/* 44 */     setViewClass(requiredViewClass());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MustacheViewResolver(Mustache.Compiler compiler) {
/* 53 */     this.compiler = compiler;
/* 54 */     setViewClass(requiredViewClass());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCharset(String charset) {
/* 62 */     this.charset = charset;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> requiredViewClass() {
/* 67 */     return MustacheView.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected AbstractUrlBasedView createView(String viewName) {
/* 72 */     MustacheView view = (MustacheView)super.createView(viewName);
/* 73 */     view.setCompiler(this.compiler);
/* 74 */     view.setCharset(this.charset);
/* 75 */     return view;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\result\view\MustacheViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
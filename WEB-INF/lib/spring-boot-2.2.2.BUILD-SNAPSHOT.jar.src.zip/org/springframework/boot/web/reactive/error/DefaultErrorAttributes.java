/*     */ package org.springframework.boot.web.reactive.error;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.annotation.ResponseStatus;
/*     */ import org.springframework.web.reactive.function.server.ServerRequest;
/*     */ import org.springframework.web.server.ResponseStatusException;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultErrorAttributes
/*     */   implements ErrorAttributes
/*     */ {
/*  60 */   private static final String ERROR_ATTRIBUTE = DefaultErrorAttributes.class.getName() + ".ERROR";
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean includeException;
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultErrorAttributes() {
/*  69 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultErrorAttributes(boolean includeException) {
/*  77 */     this.includeException = includeException;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getErrorAttributes(ServerRequest request, boolean includeStackTrace) {
/*  82 */     Map<String, Object> errorAttributes = new LinkedHashMap<>();
/*  83 */     errorAttributes.put("timestamp", new Date());
/*  84 */     errorAttributes.put("path", request.path());
/*  85 */     Throwable error = getError(request);
/*     */     
/*  87 */     MergedAnnotation<ResponseStatus> responseStatusAnnotation = MergedAnnotations.from(error.getClass(), MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(ResponseStatus.class);
/*  88 */     HttpStatus errorStatus = determineHttpStatus(error, responseStatusAnnotation);
/*  89 */     errorAttributes.put("status", Integer.valueOf(errorStatus.value()));
/*  90 */     errorAttributes.put("error", errorStatus.getReasonPhrase());
/*  91 */     errorAttributes.put("message", determineMessage(error, responseStatusAnnotation));
/*  92 */     errorAttributes.put("requestId", request.exchange().getRequest().getId());
/*  93 */     handleException(errorAttributes, determineException(error), includeStackTrace);
/*  94 */     return errorAttributes;
/*     */   }
/*     */   
/*     */   private HttpStatus determineHttpStatus(Throwable error, MergedAnnotation<ResponseStatus> responseStatusAnnotation) {
/*  98 */     if (error instanceof ResponseStatusException) {
/*  99 */       return ((ResponseStatusException)error).getStatus();
/*     */     }
/* 101 */     return responseStatusAnnotation.getValue("code", HttpStatus.class).orElse(HttpStatus.INTERNAL_SERVER_ERROR);
/*     */   }
/*     */   
/*     */   private String determineMessage(Throwable error, MergedAnnotation<ResponseStatus> responseStatusAnnotation) {
/* 105 */     if (error instanceof org.springframework.web.bind.support.WebExchangeBindException) {
/* 106 */       return error.getMessage();
/*     */     }
/* 108 */     if (error instanceof ResponseStatusException) {
/* 109 */       return ((ResponseStatusException)error).getReason();
/*     */     }
/* 111 */     return responseStatusAnnotation.getValue("reason", String.class).orElseGet(error::getMessage);
/*     */   }
/*     */   
/*     */   private Throwable determineException(Throwable error) {
/* 115 */     if (error instanceof ResponseStatusException) {
/* 116 */       return (error.getCause() != null) ? error.getCause() : error;
/*     */     }
/* 118 */     return error;
/*     */   }
/*     */   
/*     */   private void addStackTrace(Map<String, Object> errorAttributes, Throwable error) {
/* 122 */     StringWriter stackTrace = new StringWriter();
/* 123 */     error.printStackTrace(new PrintWriter(stackTrace));
/* 124 */     stackTrace.flush();
/* 125 */     errorAttributes.put("trace", stackTrace.toString());
/*     */   }
/*     */   
/*     */   private void handleException(Map<String, Object> errorAttributes, Throwable error, boolean includeStackTrace) {
/* 129 */     if (this.includeException) {
/* 130 */       errorAttributes.put("exception", error.getClass().getName());
/*     */     }
/* 132 */     if (includeStackTrace) {
/* 133 */       addStackTrace(errorAttributes, error);
/*     */     }
/* 135 */     if (error instanceof BindingResult) {
/* 136 */       BindingResult result = (BindingResult)error;
/* 137 */       if (result.hasErrors()) {
/* 138 */         errorAttributes.put("errors", result.getAllErrors());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getError(ServerRequest request) {
/* 145 */     return (Throwable)request.attribute(ERROR_ATTRIBUTE)
/* 146 */       .orElseThrow(() -> new IllegalStateException("Missing exception attribute in ServerWebExchange"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void storeErrorInformation(Throwable error, ServerWebExchange exchange) {
/* 151 */     exchange.getAttributes().putIfAbsent(ERROR_ATTRIBUTE, error);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\error\DefaultErrorAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.reactive.context;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.AnnotationConfigRegistry;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationConfigReactiveWebServerApplicationContext
/*     */   extends ReactiveWebServerApplicationContext
/*     */   implements AnnotationConfigRegistry
/*     */ {
/*     */   private final AnnotatedBeanDefinitionReader reader;
/*     */   private final ClassPathBeanDefinitionScanner scanner;
/*  66 */   private final Set<Class<?>> annotatedClasses = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] basePackages;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigReactiveWebServerApplicationContext() {
/*  76 */     this.reader = new AnnotatedBeanDefinitionReader((BeanDefinitionRegistry)this);
/*  77 */     this.scanner = new ClassPathBeanDefinitionScanner((BeanDefinitionRegistry)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigReactiveWebServerApplicationContext(DefaultListableBeanFactory beanFactory) {
/*  87 */     super(beanFactory);
/*  88 */     this.reader = new AnnotatedBeanDefinitionReader((BeanDefinitionRegistry)this);
/*  89 */     this.scanner = new ClassPathBeanDefinitionScanner((BeanDefinitionRegistry)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigReactiveWebServerApplicationContext(Class<?>... annotatedClasses) {
/* 100 */     this();
/* 101 */     register(annotatedClasses);
/* 102 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigReactiveWebServerApplicationContext(String... basePackages) {
/* 112 */     this();
/* 113 */     scan(basePackages);
/* 114 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(ConfigurableEnvironment environment) {
/* 125 */     super.setEnvironment(environment);
/* 126 */     this.reader.setEnvironment((Environment)environment);
/* 127 */     this.scanner.setEnvironment((Environment)environment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator) {
/* 145 */     this.reader.setBeanNameGenerator(beanNameGenerator);
/* 146 */     this.scanner.setBeanNameGenerator(beanNameGenerator);
/* 147 */     getBeanFactory().registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver) {
/* 161 */     this.reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 162 */     this.scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void register(Class<?>... annotatedClasses) {
/* 179 */     Assert.notEmpty((Object[])annotatedClasses, "At least one annotated class must be specified");
/* 180 */     this.annotatedClasses.addAll(Arrays.asList(annotatedClasses));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void scan(String... basePackages) {
/* 192 */     Assert.notEmpty((Object[])basePackages, "At least one base package must be specified");
/* 193 */     this.basePackages = basePackages;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void prepareRefresh() {
/* 198 */     this.scanner.clearCache();
/* 199 */     super.prepareRefresh();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/* 204 */     super.postProcessBeanFactory(beanFactory);
/* 205 */     if (!ObjectUtils.isEmpty((Object[])this.basePackages)) {
/* 206 */       this.scanner.scan(this.basePackages);
/*     */     }
/* 208 */     if (!this.annotatedClasses.isEmpty())
/* 209 */       this.reader.register(ClassUtils.toClassArray(this.annotatedClasses)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\context\AnnotationConfigReactiveWebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.reactive.filter;
/*    */ 
/*    */ import org.springframework.web.filter.reactive.HiddenHttpMethodFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderedHiddenHttpMethodFilter
/*    */   extends HiddenHttpMethodFilter
/*    */   implements OrderedWebFilter
/*    */ {
/*    */   public static final int DEFAULT_ORDER = -10000;
/* 35 */   private int order = -10000;
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 39 */     return this.order;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOrder(int order) {
/* 47 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\filter\OrderedHiddenHttpMethodFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.reactive.context;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.boot.web.context.ConfigurableWebServerApplicationContext;
/*     */ import org.springframework.boot.web.reactive.server.ReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.http.server.reactive.HttpHandler;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactiveWebServerApplicationContext
/*     */   extends GenericReactiveWebApplicationContext
/*     */   implements ConfigurableWebServerApplicationContext
/*     */ {
/*     */   private volatile ServerManager serverManager;
/*     */   private String serverNamespace;
/*     */   
/*     */   public ReactiveWebServerApplicationContext() {}
/*     */   
/*     */   public ReactiveWebServerApplicationContext(DefaultListableBeanFactory beanFactory) {
/*  60 */     super(beanFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void refresh() throws BeansException, IllegalStateException {
/*     */     try {
/*  66 */       super.refresh();
/*     */     }
/*  68 */     catch (RuntimeException ex) {
/*  69 */       stopAndReleaseReactiveWebServer();
/*  70 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onRefresh() {
/*  76 */     super.onRefresh();
/*     */     try {
/*  78 */       createWebServer();
/*     */     }
/*  80 */     catch (Throwable ex) {
/*  81 */       throw new ApplicationContextException("Unable to start reactive web server", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void createWebServer() {
/*  86 */     ServerManager serverManager = this.serverManager;
/*  87 */     if (serverManager == null) {
/*  88 */       String webServerFactoryBeanName = getWebServerFactoryBeanName();
/*  89 */       ReactiveWebServerFactory webServerFactory = getWebServerFactory(webServerFactoryBeanName);
/*  90 */       boolean lazyInit = getBeanFactory().getBeanDefinition(webServerFactoryBeanName).isLazyInit();
/*  91 */       this.serverManager = ServerManager.get(webServerFactory, lazyInit);
/*     */     } 
/*  93 */     initPropertySources();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getWebServerFactoryBeanName() {
/*  98 */     String[] beanNames = getBeanFactory().getBeanNamesForType(ReactiveWebServerFactory.class);
/*  99 */     if (beanNames.length == 0) {
/* 100 */       throw new ApplicationContextException("Unable to start ReactiveWebApplicationContext due to missing ReactiveWebServerFactory bean.");
/*     */     }
/*     */     
/* 103 */     if (beanNames.length > 1) {
/* 104 */       throw new ApplicationContextException("Unable to start ReactiveWebApplicationContext due to multiple ReactiveWebServerFactory beans : " + 
/* 105 */           StringUtils.arrayToCommaDelimitedString(beanNames));
/*     */     }
/* 107 */     return beanNames[0];
/*     */   }
/*     */   
/*     */   protected ReactiveWebServerFactory getWebServerFactory(String factoryBeanName) {
/* 111 */     return (ReactiveWebServerFactory)getBeanFactory().getBean(factoryBeanName, ReactiveWebServerFactory.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ReactiveWebServerFactory getWebServerFactory() {
/* 124 */     return getWebServerFactory(getWebServerFactoryBeanName());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finishRefresh() {
/* 129 */     super.finishRefresh();
/* 130 */     WebServer webServer = startReactiveWebServer();
/* 131 */     if (webServer != null) {
/* 132 */       publishEvent((ApplicationEvent)new ReactiveWebServerInitializedEvent(webServer, this));
/*     */     }
/*     */   }
/*     */   
/*     */   private WebServer startReactiveWebServer() {
/* 137 */     ServerManager serverManager = this.serverManager;
/* 138 */     ServerManager.start(serverManager, this::getHttpHandler);
/* 139 */     return ServerManager.getWebServer(serverManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpHandler getHttpHandler() {
/* 149 */     String[] beanNames = getBeanFactory().getBeanNamesForType(HttpHandler.class);
/* 150 */     if (beanNames.length == 0) {
/* 151 */       throw new ApplicationContextException("Unable to start ReactiveWebApplicationContext due to missing HttpHandler bean.");
/*     */     }
/*     */     
/* 154 */     if (beanNames.length > 1) {
/* 155 */       throw new ApplicationContextException("Unable to start ReactiveWebApplicationContext due to multiple HttpHandler beans : " + 
/*     */           
/* 157 */           StringUtils.arrayToCommaDelimitedString(beanNames));
/*     */     }
/* 159 */     return (HttpHandler)getBeanFactory().getBean(beanNames[0], HttpHandler.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onClose() {
/* 164 */     super.onClose();
/* 165 */     stopAndReleaseReactiveWebServer();
/*     */   }
/*     */   
/*     */   private void stopAndReleaseReactiveWebServer() {
/* 169 */     ServerManager serverManager = this.serverManager;
/*     */     try {
/* 171 */       ServerManager.stop(serverManager);
/*     */     } finally {
/*     */       
/* 174 */       this.serverManager = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServer getWebServer() {
/* 185 */     return ServerManager.getWebServer(this.serverManager);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServerNamespace() {
/* 190 */     return this.serverNamespace;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerNamespace(String serverNamespace) {
/* 195 */     this.serverNamespace = serverNamespace;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class LazyHttpHandler
/*     */     implements HttpHandler
/*     */   {
/*     */     private final Mono<HttpHandler> delegate;
/*     */ 
/*     */     
/*     */     private LazyHttpHandler(Mono<HttpHandler> delegate) {
/* 206 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> handle(ServerHttpRequest request, ServerHttpResponse response) {
/* 211 */       return this.delegate.flatMap(handler -> handler.handle(request, response));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ServerManager
/*     */     implements HttpHandler
/*     */   {
/*     */     private final WebServer server;
/*     */ 
/*     */     
/*     */     private final boolean lazyInit;
/*     */     
/*     */     private volatile HttpHandler handler;
/*     */ 
/*     */     
/*     */     private ServerManager(ReactiveWebServerFactory factory, boolean lazyInit) {
/* 229 */       this.handler = this::handleUninitialized;
/* 230 */       this.server = factory.getWebServer(this);
/* 231 */       this.lazyInit = lazyInit;
/*     */     }
/*     */     
/*     */     private Mono<Void> handleUninitialized(ServerHttpRequest request, ServerHttpResponse response) {
/* 235 */       throw new IllegalStateException("The HttpHandler has not yet been initialized");
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> handle(ServerHttpRequest request, ServerHttpResponse response) {
/* 240 */       return this.handler.handle(request, response);
/*     */     }
/*     */     
/*     */     HttpHandler getHandler() {
/* 244 */       return this.handler;
/*     */     }
/*     */     
/*     */     static ServerManager get(ReactiveWebServerFactory factory, boolean lazyInit) {
/* 248 */       return new ServerManager(factory, lazyInit);
/*     */     }
/*     */     
/*     */     static WebServer getWebServer(ServerManager manager) {
/* 252 */       return (manager != null) ? manager.server : null;
/*     */     }
/*     */     
/*     */     static void start(ServerManager manager, Supplier<HttpHandler> handlerSupplier) {
/* 256 */       if (manager != null && manager.server != null) {
/* 257 */         manager
/* 258 */           .handler = manager.lazyInit ? new ReactiveWebServerApplicationContext.LazyHttpHandler(Mono.fromSupplier(handlerSupplier)) : handlerSupplier.get();
/* 259 */         manager.server.start();
/*     */       } 
/*     */     }
/*     */     
/*     */     static void stop(ServerManager manager) {
/* 264 */       if (manager != null && manager.server != null)
/*     */         try {
/* 266 */           manager.server.stop();
/*     */         }
/* 268 */         catch (Exception ex) {
/* 269 */           throw new IllegalStateException(ex);
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\context\ReactiveWebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.reactive.context;
/*    */ 
/*    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*    */ import org.springframework.context.support.GenericApplicationContext;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericReactiveWebApplicationContext
/*    */   extends GenericApplicationContext
/*    */   implements ConfigurableReactiveWebApplicationContext
/*    */ {
/*    */   public GenericReactiveWebApplicationContext() {}
/*    */   
/*    */   public GenericReactiveWebApplicationContext(DefaultListableBeanFactory beanFactory) {
/* 50 */     super(beanFactory);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ConfigurableEnvironment createEnvironment() {
/* 55 */     return new StandardReactiveWebEnvironment();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Resource getResourceByPath(String path) {
/* 61 */     return (Resource)new FilteredReactiveWebContextResource(path);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\context\GenericReactiveWebApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
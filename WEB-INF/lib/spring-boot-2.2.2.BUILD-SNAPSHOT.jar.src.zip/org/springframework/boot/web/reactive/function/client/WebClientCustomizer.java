package org.springframework.boot.web.reactive.function.client;

import org.springframework.web.reactive.function.client.WebClient;

@FunctionalInterface
public interface WebClientCustomizer {
  void customize(WebClient.Builder paramBuilder);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\reactive\function\client\WebClientCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
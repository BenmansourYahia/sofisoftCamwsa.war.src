/*    */ package org.springframework.boot.web.servlet.view;
/*    */ 
/*    */ import com.samskivert.mustache.Mustache;
/*    */ import com.samskivert.mustache.Template;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.web.servlet.view.AbstractTemplateView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MustacheView
/*    */   extends AbstractTemplateView
/*    */ {
/*    */   private Mustache.Compiler compiler;
/*    */   private String charset;
/*    */   
/*    */   public void setCompiler(Mustache.Compiler compiler) {
/* 58 */     this.compiler = compiler;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCharset(String charset) {
/* 66 */     this.charset = charset;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean checkResource(Locale locale) throws Exception {
/* 71 */     Resource resource = getApplicationContext().getResource(getUrl());
/* 72 */     return (resource != null && resource.exists());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderMergedTemplateModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 78 */     Template template = createTemplate(getApplicationContext().getResource(getUrl()));
/* 79 */     if (template != null) {
/* 80 */       template.execute(model, response.getWriter());
/*    */     }
/*    */   }
/*    */   
/*    */   private Template createTemplate(Resource resource) throws IOException {
/* 85 */     try (Reader reader = getReader(resource)) {
/* 86 */       return this.compiler.compile(reader);
/*    */     } 
/*    */   }
/*    */   
/*    */   private Reader getReader(Resource resource) throws IOException {
/* 91 */     if (this.charset != null) {
/* 92 */       return new InputStreamReader(resource.getInputStream(), this.charset);
/*    */     }
/* 94 */     return new InputStreamReader(resource.getInputStream());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\view\MustacheView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletContextAttributeListener;
/*     */ import javax.servlet.ServletContextListener;
/*     */ import javax.servlet.ServletRequestAttributeListener;
/*     */ import javax.servlet.ServletRequestListener;
/*     */ import javax.servlet.http.HttpSessionAttributeListener;
/*     */ import javax.servlet.http.HttpSessionListener;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletListenerRegistrationBean<T extends EventListener>
/*     */   extends RegistrationBean
/*     */ {
/*     */   private static final Set<Class<?>> SUPPORTED_TYPES;
/*     */   private T listener;
/*     */   
/*     */   static {
/*  61 */     Set<Class<?>> types = new HashSet<>();
/*  62 */     types.add(ServletContextAttributeListener.class);
/*  63 */     types.add(ServletRequestListener.class);
/*  64 */     types.add(ServletRequestAttributeListener.class);
/*  65 */     types.add(HttpSessionAttributeListener.class);
/*  66 */     types.add(HttpSessionListener.class);
/*  67 */     types.add(ServletContextListener.class);
/*  68 */     SUPPORTED_TYPES = Collections.unmodifiableSet(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletListenerRegistrationBean() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletListenerRegistrationBean(T listener) {
/*  84 */     Assert.notNull(listener, "Listener must not be null");
/*  85 */     Assert.isTrue(isSupportedType((EventListener)listener), "Listener is not of a supported type");
/*  86 */     this.listener = listener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListener(T listener) {
/*  94 */     Assert.notNull(listener, "Listener must not be null");
/*  95 */     Assert.isTrue(isSupportedType((EventListener)listener), "Listener is not of a supported type");
/*  96 */     this.listener = listener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getListener() {
/* 104 */     return this.listener;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDescription() {
/* 109 */     Assert.notNull(this.listener, "Listener must not be null");
/* 110 */     return "listener " + this.listener;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void register(String description, ServletContext servletContext) {
/*     */     try {
/* 116 */       servletContext.addListener((EventListener)this.listener);
/*     */     }
/* 118 */     catch (RuntimeException ex) {
/* 119 */       throw new IllegalStateException("Failed to add listener '" + this.listener + "' to servlet context", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSupportedType(EventListener listener) {
/* 129 */     for (Class<?> type : SUPPORTED_TYPES) {
/* 130 */       if (ClassUtils.isAssignableValue(type, listener)) {
/* 131 */         return true;
/*     */       }
/*     */     } 
/* 134 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> getSupportedTypes() {
/* 142 */     return SUPPORTED_TYPES;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\ServletListenerRegistrationBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
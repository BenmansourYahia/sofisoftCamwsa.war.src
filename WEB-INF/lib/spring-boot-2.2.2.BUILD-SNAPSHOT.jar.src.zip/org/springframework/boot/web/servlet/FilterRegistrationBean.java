/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import javax.servlet.Filter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterRegistrationBean<T extends Filter>
/*    */   extends AbstractFilterRegistrationBean<T>
/*    */ {
/*    */   private T filter;
/*    */   
/*    */   public FilterRegistrationBean() {
/* 50 */     super((ServletRegistrationBean<?>[])new ServletRegistrationBean[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterRegistrationBean(T filter, ServletRegistrationBean<?>... servletRegistrationBeans) {
/* 60 */     super(servletRegistrationBeans);
/* 61 */     Assert.notNull(filter, "Filter must not be null");
/* 62 */     this.filter = filter;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getFilter() {
/* 67 */     return this.filter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFilter(T filter) {
/* 75 */     Assert.notNull(filter, "Filter must not be null");
/* 76 */     this.filter = filter;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\FilterRegistrationBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
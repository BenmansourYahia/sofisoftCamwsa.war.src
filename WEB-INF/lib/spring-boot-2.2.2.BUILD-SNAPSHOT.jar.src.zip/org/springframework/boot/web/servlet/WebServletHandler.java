/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.MultipartConfigElement;
/*    */ import javax.servlet.annotation.MultipartConfig;
/*    */ import javax.servlet.annotation.WebServlet;
/*    */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebServletHandler
/*    */   extends ServletComponentHandler
/*    */ {
/*    */   WebServletHandler() {
/* 39 */     super((Class)WebServlet.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void doHandle(Map<String, Object> attributes, AnnotatedBeanDefinition beanDefinition, BeanDefinitionRegistry registry) {
/* 45 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(ServletRegistrationBean.class);
/* 46 */     builder.addPropertyValue("asyncSupported", attributes.get("asyncSupported"));
/* 47 */     builder.addPropertyValue("initParameters", extractInitParameters(attributes));
/* 48 */     builder.addPropertyValue("loadOnStartup", attributes.get("loadOnStartup"));
/* 49 */     String name = determineName(attributes, (BeanDefinition)beanDefinition);
/* 50 */     builder.addPropertyValue("name", name);
/* 51 */     builder.addPropertyValue("servlet", beanDefinition);
/* 52 */     builder.addPropertyValue("urlMappings", extractUrlPatterns(attributes));
/* 53 */     builder.addPropertyValue("multipartConfig", determineMultipartConfig(beanDefinition));
/* 54 */     registry.registerBeanDefinition(name, (BeanDefinition)builder.getBeanDefinition());
/*    */   }
/*    */   
/*    */   private String determineName(Map<String, Object> attributes, BeanDefinition beanDefinition) {
/* 58 */     return StringUtils.hasText((String)attributes.get("name")) ? (String)attributes.get("name") : beanDefinition
/* 59 */       .getBeanClassName();
/*    */   }
/*    */ 
/*    */   
/*    */   private MultipartConfigElement determineMultipartConfig(AnnotatedBeanDefinition beanDefinition) {
/* 64 */     Map<String, Object> attributes = beanDefinition.getMetadata().getAnnotationAttributes(MultipartConfig.class.getName());
/* 65 */     if (attributes == null) {
/* 66 */       return null;
/*    */     }
/* 68 */     return new MultipartConfigElement((String)attributes.get("location"), ((Long)attributes.get("maxFileSize")).longValue(), ((Long)attributes
/* 69 */         .get("maxRequestSize")).longValue(), ((Integer)attributes.get("fileSizeThreshold")).intValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\WebServletHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
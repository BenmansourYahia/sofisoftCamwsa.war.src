/*     */ package org.springframework.boot.web.servlet.context;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.Scope;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.boot.web.context.ConfigurableWebServerApplicationContext;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializerBeans;
/*     */ import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*     */ import org.springframework.web.context.ContextLoader;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.GenericWebApplicationContext;
/*     */ import org.springframework.web.context.support.ServletContextResource;
/*     */ import org.springframework.web.context.support.ServletContextScope;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletWebServerApplicationContext
/*     */   extends GenericWebApplicationContext
/*     */   implements ConfigurableWebServerApplicationContext
/*     */ {
/*  96 */   private static final Log logger = LogFactory.getLog(ServletWebServerApplicationContext.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DISPATCHER_SERVLET_NAME = "dispatcherServlet";
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile WebServer webServer;
/*     */ 
/*     */ 
/*     */   
/*     */   private ServletConfig servletConfig;
/*     */ 
/*     */ 
/*     */   
/*     */   private String serverNamespace;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletWebServerApplicationContext() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletWebServerApplicationContext(DefaultListableBeanFactory beanFactory) {
/* 124 */     super(beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/* 133 */     beanFactory.addBeanPostProcessor((BeanPostProcessor)new WebApplicationContextServletContextAwareProcessor((ConfigurableWebApplicationContext)this));
/* 134 */     beanFactory.ignoreDependencyInterface(ServletContextAware.class);
/* 135 */     registerWebApplicationScopes();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void refresh() throws BeansException, IllegalStateException {
/*     */     try {
/* 141 */       super.refresh();
/*     */     }
/* 143 */     catch (RuntimeException ex) {
/* 144 */       stopAndReleaseWebServer();
/* 145 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onRefresh() {
/* 151 */     super.onRefresh();
/*     */     try {
/* 153 */       createWebServer();
/*     */     }
/* 155 */     catch (Throwable ex) {
/* 156 */       throw new ApplicationContextException("Unable to start web server", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finishRefresh() {
/* 162 */     super.finishRefresh();
/* 163 */     WebServer webServer = startWebServer();
/* 164 */     if (webServer != null) {
/* 165 */       publishEvent((ApplicationEvent)new ServletWebServerInitializedEvent(webServer, this));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onClose() {
/* 171 */     super.onClose();
/* 172 */     stopAndReleaseWebServer();
/*     */   }
/*     */   
/*     */   private void createWebServer() {
/* 176 */     WebServer webServer = this.webServer;
/* 177 */     ServletContext servletContext = getServletContext();
/* 178 */     if (webServer == null && servletContext == null) {
/* 179 */       ServletWebServerFactory factory = getWebServerFactory();
/* 180 */       this.webServer = factory.getWebServer(new ServletContextInitializer[] { getSelfInitializer() });
/*     */     }
/* 182 */     else if (servletContext != null) {
/*     */       try {
/* 184 */         getSelfInitializer().onStartup(servletContext);
/*     */       }
/* 186 */       catch (ServletException ex) {
/* 187 */         throw new ApplicationContextException("Cannot initialize servlet context", ex);
/*     */       } 
/*     */     } 
/* 190 */     initPropertySources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletWebServerFactory getWebServerFactory() {
/* 201 */     String[] beanNames = getBeanFactory().getBeanNamesForType(ServletWebServerFactory.class);
/* 202 */     if (beanNames.length == 0) {
/* 203 */       throw new ApplicationContextException("Unable to start ServletWebServerApplicationContext due to missing ServletWebServerFactory bean.");
/*     */     }
/*     */     
/* 206 */     if (beanNames.length > 1) {
/* 207 */       throw new ApplicationContextException("Unable to start ServletWebServerApplicationContext due to multiple ServletWebServerFactory beans : " + 
/* 208 */           StringUtils.arrayToCommaDelimitedString(beanNames));
/*     */     }
/* 210 */     return (ServletWebServerFactory)getBeanFactory().getBean(beanNames[0], ServletWebServerFactory.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ServletContextInitializer getSelfInitializer() {
/* 220 */     return this::selfInitialize;
/*     */   }
/*     */   
/*     */   private void selfInitialize(ServletContext servletContext) throws ServletException {
/* 224 */     prepareWebApplicationContext(servletContext);
/* 225 */     registerApplicationScope(servletContext);
/* 226 */     WebApplicationContextUtils.registerEnvironmentBeans(getBeanFactory(), servletContext);
/* 227 */     for (ServletContextInitializer beans : getServletContextInitializerBeans()) {
/* 228 */       beans.onStartup(servletContext);
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerApplicationScope(ServletContext servletContext) {
/* 233 */     ServletContextScope appScope = new ServletContextScope(servletContext);
/* 234 */     getBeanFactory().registerScope("application", (Scope)appScope);
/*     */     
/* 236 */     servletContext.setAttribute(ServletContextScope.class.getName(), appScope);
/*     */   }
/*     */   
/*     */   private void registerWebApplicationScopes() {
/* 240 */     ExistingWebApplicationScopes existingScopes = new ExistingWebApplicationScopes(getBeanFactory());
/* 241 */     WebApplicationContextUtils.registerWebApplicationScopes(getBeanFactory());
/* 242 */     existingScopes.restore();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<ServletContextInitializer> getServletContextInitializerBeans() {
/* 253 */     return (Collection<ServletContextInitializer>)new ServletContextInitializerBeans((ListableBeanFactory)getBeanFactory(), new Class[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepareWebApplicationContext(ServletContext servletContext) {
/* 264 */     Object rootContext = servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 265 */     if (rootContext != null) {
/* 266 */       if (rootContext == this) {
/* 267 */         throw new IllegalStateException("Cannot initialize context because there is already a root application context present - check whether you have multiple ServletContextInitializers!");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 273 */     Log logger = LogFactory.getLog(ContextLoader.class);
/* 274 */     servletContext.log("Initializing Spring embedded WebApplicationContext");
/*     */     try {
/* 276 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, this);
/* 277 */       if (logger.isDebugEnabled()) {
/* 278 */         logger.debug("Published root WebApplicationContext as ServletContext attribute with name [" + WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE + "]");
/*     */       }
/*     */       
/* 281 */       setServletContext(servletContext);
/* 282 */       if (logger.isInfoEnabled()) {
/* 283 */         long elapsedTime = System.currentTimeMillis() - getStartupDate();
/* 284 */         logger.info("Root WebApplicationContext: initialization completed in " + elapsedTime + " ms");
/*     */       }
/*     */     
/* 287 */     } catch (RuntimeException|Error ex) {
/* 288 */       logger.error("Context initialization failed", ex);
/* 289 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, ex);
/* 290 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   private WebServer startWebServer() {
/* 295 */     WebServer webServer = this.webServer;
/* 296 */     if (webServer != null) {
/* 297 */       webServer.start();
/*     */     }
/* 299 */     return webServer;
/*     */   }
/*     */   
/*     */   private void stopAndReleaseWebServer() {
/* 303 */     WebServer webServer = this.webServer;
/* 304 */     if (webServer != null) {
/*     */       try {
/* 306 */         webServer.stop();
/* 307 */         this.webServer = null;
/*     */       }
/* 309 */       catch (Exception ex) {
/* 310 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Resource getResourceByPath(String path) {
/* 317 */     if (getServletContext() == null) {
/* 318 */       return (Resource)new DefaultResourceLoader.ClassPathContextResource(path, getClassLoader());
/*     */     }
/* 320 */     return (Resource)new ServletContextResource(getServletContext(), path);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServerNamespace() {
/* 325 */     return this.serverNamespace;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerNamespace(String serverNamespace) {
/* 330 */     this.serverNamespace = serverNamespace;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServletConfig(ServletConfig servletConfig) {
/* 335 */     this.servletConfig = servletConfig;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServletConfig getServletConfig() {
/* 340 */     return this.servletConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServer getWebServer() {
/* 350 */     return this.webServer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ExistingWebApplicationScopes
/*     */   {
/*     */     private static final Set<String> SCOPES;
/*     */     
/*     */     private final ConfigurableListableBeanFactory beanFactory;
/*     */ 
/*     */     
/*     */     static {
/* 363 */       Set<String> scopes = new LinkedHashSet<>();
/* 364 */       scopes.add("request");
/* 365 */       scopes.add("session");
/* 366 */       SCOPES = Collections.unmodifiableSet(scopes);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 371 */     private final Map<String, Scope> scopes = new HashMap<>();
/*     */     
/*     */     public ExistingWebApplicationScopes(ConfigurableListableBeanFactory beanFactory) {
/* 374 */       this.beanFactory = beanFactory;
/* 375 */       for (String scopeName : SCOPES) {
/* 376 */         Scope scope = beanFactory.getRegisteredScope(scopeName);
/* 377 */         if (scope != null) {
/* 378 */           this.scopes.put(scopeName, scope);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void restore() {
/* 384 */       this.scopes.forEach((key, value) -> {
/*     */             if (ServletWebServerApplicationContext.logger.isInfoEnabled())
/*     */               ServletWebServerApplicationContext.logger.info("Restoring user defined scope " + key); 
/*     */             this.beanFactory.registerScope(key, value);
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\context\ServletWebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
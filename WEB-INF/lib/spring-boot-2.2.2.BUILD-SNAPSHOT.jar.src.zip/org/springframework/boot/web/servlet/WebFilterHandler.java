/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.EnumSet;
/*    */ import java.util.Map;
/*    */ import javax.servlet.DispatcherType;
/*    */ import javax.servlet.annotation.WebFilter;
/*    */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebFilterHandler
/*    */   extends ServletComponentHandler
/*    */ {
/*    */   WebFilterHandler() {
/* 40 */     super((Class)WebFilter.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void doHandle(Map<String, Object> attributes, AnnotatedBeanDefinition beanDefinition, BeanDefinitionRegistry registry) {
/* 46 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(FilterRegistrationBean.class);
/* 47 */     builder.addPropertyValue("asyncSupported", attributes.get("asyncSupported"));
/* 48 */     builder.addPropertyValue("dispatcherTypes", extractDispatcherTypes(attributes));
/* 49 */     builder.addPropertyValue("filter", beanDefinition);
/* 50 */     builder.addPropertyValue("initParameters", extractInitParameters(attributes));
/* 51 */     String name = determineName(attributes, (BeanDefinition)beanDefinition);
/* 52 */     builder.addPropertyValue("name", name);
/* 53 */     builder.addPropertyValue("servletNames", attributes.get("servletNames"));
/* 54 */     builder.addPropertyValue("urlPatterns", extractUrlPatterns(attributes));
/* 55 */     registry.registerBeanDefinition(name, (BeanDefinition)builder.getBeanDefinition());
/*    */   }
/*    */   
/*    */   private EnumSet<DispatcherType> extractDispatcherTypes(Map<String, Object> attributes) {
/* 59 */     DispatcherType[] dispatcherTypes = (DispatcherType[])attributes.get("dispatcherTypes");
/* 60 */     if (dispatcherTypes.length == 0) {
/* 61 */       return EnumSet.noneOf(DispatcherType.class);
/*    */     }
/* 63 */     if (dispatcherTypes.length == 1) {
/* 64 */       return EnumSet.of(dispatcherTypes[0]);
/*    */     }
/* 66 */     return (EnumSet)EnumSet.of(dispatcherTypes[0], Arrays.copyOfRange((Object[])dispatcherTypes, 1, dispatcherTypes.length));
/*    */   }
/*    */   
/*    */   private String determineName(Map<String, Object> attributes, BeanDefinition beanDefinition) {
/* 70 */     return StringUtils.hasText((String)attributes.get("filterName")) ? (String)attributes.get("filterName") : beanDefinition
/* 71 */       .getBeanClassName();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\WebFilterHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.servlet.server;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StaticResourceJars
/*     */ {
/*     */   List<URL> getUrls() {
/*  43 */     ClassLoader classLoader = getClass().getClassLoader();
/*  44 */     if (classLoader instanceof URLClassLoader) {
/*  45 */       return getUrlsFrom(((URLClassLoader)classLoader).getURLs());
/*     */     }
/*     */     
/*  48 */     return getUrlsFrom((URL[])Stream.<String>of(ManagementFactory.getRuntimeMXBean().getClassPath().split(File.pathSeparator))
/*  49 */         .map(this::toUrl).toArray(x$0 -> new URL[x$0]));
/*     */   }
/*     */ 
/*     */   
/*     */   List<URL> getUrlsFrom(URL... urls) {
/*  54 */     List<URL> resourceJarUrls = new ArrayList<>();
/*  55 */     for (URL url : urls) {
/*  56 */       addUrl(resourceJarUrls, url);
/*     */     }
/*  58 */     return resourceJarUrls;
/*     */   }
/*     */   
/*     */   private URL toUrl(String classPathEntry) {
/*     */     try {
/*  63 */       return (new File(classPathEntry)).toURI().toURL();
/*     */     }
/*  65 */     catch (MalformedURLException ex) {
/*  66 */       throw new IllegalArgumentException("URL could not be created from '" + classPathEntry + "'", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private File toFile(URL url) {
/*     */     try {
/*  72 */       return new File(url.toURI());
/*     */     }
/*  74 */     catch (URISyntaxException ex) {
/*  75 */       throw new IllegalStateException("Failed to create File from URL '" + url + "'");
/*     */     }
/*  77 */     catch (IllegalArgumentException ex) {
/*  78 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addUrl(List<URL> urls, URL url) {
/*     */     try {
/*  84 */       if (!"file".equals(url.getProtocol())) {
/*  85 */         addUrlConnection(urls, url, url.openConnection());
/*     */       } else {
/*     */         
/*  88 */         File file = toFile(url);
/*  89 */         if (file != null) {
/*  90 */           addUrlFile(urls, url, file);
/*     */         } else {
/*     */           
/*  93 */           addUrlConnection(urls, url, url.openConnection());
/*     */         }
/*     */       
/*     */       } 
/*  97 */     } catch (IOException ex) {
/*  98 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addUrlFile(List<URL> urls, URL url, File file) {
/* 103 */     if ((file.isDirectory() && (new File(file, "META-INF/resources")).isDirectory()) || isResourcesJar(file)) {
/* 104 */       urls.add(url);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addUrlConnection(List<URL> urls, URL url, URLConnection connection) {
/* 109 */     if (connection instanceof JarURLConnection && isResourcesJar((JarURLConnection)connection)) {
/* 110 */       urls.add(url);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isResourcesJar(JarURLConnection connection) {
/*     */     try {
/* 116 */       return isResourcesJar(connection.getJarFile());
/*     */     }
/* 118 */     catch (IOException ex) {
/* 119 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isResourcesJar(File file) {
/*     */     try {
/* 125 */       return isResourcesJar(new JarFile(file));
/*     */     }
/* 127 */     catch (IOException ex) {
/* 128 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isResourcesJar(JarFile jar) throws IOException {
/*     */     try {
/* 134 */       return (jar.getName().endsWith(".jar") && jar.getJarEntry("META-INF/resources") != null);
/*     */     } finally {
/*     */       
/* 137 */       jar.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\server\StaticResourceJars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
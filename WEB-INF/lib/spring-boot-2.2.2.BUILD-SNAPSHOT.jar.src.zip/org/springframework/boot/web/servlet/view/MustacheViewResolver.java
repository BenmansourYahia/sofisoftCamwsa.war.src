/*    */ package org.springframework.boot.web.servlet.view;
/*    */ 
/*    */ import com.samskivert.mustache.Mustache;
/*    */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MustacheViewResolver
/*    */   extends AbstractTemplateViewResolver
/*    */ {
/*    */   private final Mustache.Compiler compiler;
/*    */   private String charset;
/*    */   
/*    */   public MustacheViewResolver() {
/* 43 */     this.compiler = Mustache.compiler();
/* 44 */     setViewClass(requiredViewClass());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MustacheViewResolver(Mustache.Compiler compiler) {
/* 53 */     this.compiler = compiler;
/* 54 */     setViewClass(requiredViewClass());
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> requiredViewClass() {
/* 59 */     return MustacheView.class;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCharset(String charset) {
/* 67 */     this.charset = charset;
/*    */   }
/*    */ 
/*    */   
/*    */   protected AbstractUrlBasedView buildView(String viewName) throws Exception {
/* 72 */     MustacheView view = (MustacheView)super.buildView(viewName);
/* 73 */     view.setCompiler(this.compiler);
/* 74 */     view.setCharset(this.charset);
/* 75 */     return (AbstractUrlBasedView)view;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\view\MustacheViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
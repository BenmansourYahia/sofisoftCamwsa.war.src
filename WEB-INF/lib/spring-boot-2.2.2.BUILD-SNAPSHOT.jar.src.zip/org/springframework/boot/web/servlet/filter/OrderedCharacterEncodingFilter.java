/*    */ package org.springframework.boot.web.servlet.filter;
/*    */ 
/*    */ import org.springframework.web.filter.CharacterEncodingFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderedCharacterEncodingFilter
/*    */   extends CharacterEncodingFilter
/*    */   implements OrderedFilter
/*    */ {
/* 30 */   private int order = Integer.MIN_VALUE;
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 34 */     return this.order;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOrder(int order) {
/* 42 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\filter\OrderedCharacterEncodingFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
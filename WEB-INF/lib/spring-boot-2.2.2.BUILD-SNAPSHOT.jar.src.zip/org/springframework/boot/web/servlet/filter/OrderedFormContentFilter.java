/*    */ package org.springframework.boot.web.servlet.filter;
/*    */ 
/*    */ import org.springframework.web.filter.FormContentFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderedFormContentFilter
/*    */   extends FormContentFilter
/*    */   implements OrderedFilter
/*    */ {
/*    */   public static final int DEFAULT_ORDER = -9900;
/* 36 */   private int order = -9900;
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 40 */     return this.order;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOrder(int order) {
/* 48 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\filter\OrderedFormContentFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
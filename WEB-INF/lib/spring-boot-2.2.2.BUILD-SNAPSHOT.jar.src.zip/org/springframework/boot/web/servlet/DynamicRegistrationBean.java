/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.Registration;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DynamicRegistrationBean<D extends Registration.Dynamic>
/*     */   extends RegistrationBean
/*     */ {
/*  42 */   private static final Log logger = LogFactory.getLog(RegistrationBean.class);
/*     */   
/*     */   private String name;
/*     */   
/*     */   private boolean asyncSupported = true;
/*     */   
/*  48 */   private Map<String, String> initParameters = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/*  55 */     Assert.hasLength(name, "Name must not be empty");
/*  56 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported) {
/*  65 */     this.asyncSupported = asyncSupported;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAsyncSupported() {
/*  73 */     return this.asyncSupported;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitParameters(Map<String, String> initParameters) {
/*  84 */     Assert.notNull(initParameters, "InitParameters must not be null");
/*  85 */     this.initParameters = new LinkedHashMap<>(initParameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getInitParameters() {
/*  93 */     return this.initParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInitParameter(String name, String value) {
/* 102 */     Assert.notNull(name, "Name must not be null");
/* 103 */     this.initParameters.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void register(String description, ServletContext servletContext) {
/* 108 */     D registration = addRegistration(description, servletContext);
/* 109 */     if (registration == null) {
/* 110 */       logger.info(StringUtils.capitalize(description) + " was not registered (possibly already registered?)");
/*     */       return;
/*     */     } 
/* 113 */     configure(registration);
/*     */   }
/*     */   
/*     */   protected abstract D addRegistration(String paramString, ServletContext paramServletContext);
/*     */   
/*     */   protected void configure(D registration) {
/* 119 */     registration.setAsyncSupported(this.asyncSupported);
/* 120 */     if (!this.initParameters.isEmpty()) {
/* 121 */       registration.setInitParameters(this.initParameters);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getOrDeduceName(Object value) {
/* 132 */     return (this.name != null) ? this.name : Conventions.getVariableName(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\DynamicRegistrationBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
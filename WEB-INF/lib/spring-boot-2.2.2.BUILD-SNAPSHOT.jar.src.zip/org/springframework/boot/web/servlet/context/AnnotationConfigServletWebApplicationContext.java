/*     */ package org.springframework.boot.web.servlet.context;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionCustomizer;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.AnnotationConfigRegistry;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.context.support.GenericWebApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationConfigServletWebApplicationContext
/*     */   extends GenericWebApplicationContext
/*     */   implements AnnotationConfigRegistry
/*     */ {
/*     */   private final AnnotatedBeanDefinitionReader reader;
/*     */   private final ClassPathBeanDefinitionScanner scanner;
/*  66 */   private final Set<Class<?>> annotatedClasses = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] basePackages;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebApplicationContext() {
/*  76 */     this.reader = new AnnotatedBeanDefinitionReader((BeanDefinitionRegistry)this);
/*  77 */     this.scanner = new ClassPathBeanDefinitionScanner((BeanDefinitionRegistry)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebApplicationContext(DefaultListableBeanFactory beanFactory) {
/*  87 */     super(beanFactory);
/*  88 */     this.reader = new AnnotatedBeanDefinitionReader((BeanDefinitionRegistry)this);
/*  89 */     this.scanner = new ClassPathBeanDefinitionScanner((BeanDefinitionRegistry)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebApplicationContext(Class<?>... annotatedClasses) {
/* 100 */     this();
/* 101 */     register(annotatedClasses);
/* 102 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebApplicationContext(String... basePackages) {
/* 111 */     this();
/* 112 */     scan(basePackages);
/* 113 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(ConfigurableEnvironment environment) {
/* 124 */     super.setEnvironment(environment);
/* 125 */     this.reader.setEnvironment((Environment)environment);
/* 126 */     this.scanner.setEnvironment((Environment)environment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator) {
/* 144 */     this.reader.setBeanNameGenerator(beanNameGenerator);
/* 145 */     this.scanner.setBeanNameGenerator(beanNameGenerator);
/* 146 */     getBeanFactory().registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver) {
/* 160 */     this.reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 161 */     this.scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void register(Class<?>... annotatedClasses) {
/* 178 */     Assert.notEmpty((Object[])annotatedClasses, "At least one annotated class must be specified");
/* 179 */     this.annotatedClasses.addAll(Arrays.asList(annotatedClasses));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void scan(String... basePackages) {
/* 191 */     Assert.notEmpty((Object[])basePackages, "At least one base package must be specified");
/* 192 */     this.basePackages = basePackages;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void prepareRefresh() {
/* 197 */     this.scanner.clearCache();
/* 198 */     super.prepareRefresh();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/* 203 */     super.postProcessBeanFactory(beanFactory);
/* 204 */     if (!ObjectUtils.isEmpty((Object[])this.basePackages)) {
/* 205 */       this.scanner.scan(this.basePackages);
/*     */     }
/* 207 */     if (!this.annotatedClasses.isEmpty()) {
/* 208 */       this.reader.register(ClassUtils.toClassArray(this.annotatedClasses));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void registerBean(String beanName, Class<T> beanClass, Supplier<T> supplier, BeanDefinitionCustomizer... customizers) {
/* 215 */     this.reader.registerBean(beanClass, beanName, supplier, customizers);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\context\AnnotationConfigServletWebApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
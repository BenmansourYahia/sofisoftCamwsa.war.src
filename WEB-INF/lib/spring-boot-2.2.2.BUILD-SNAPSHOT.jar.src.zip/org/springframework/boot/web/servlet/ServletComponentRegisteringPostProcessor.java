/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServletComponentRegisteringPostProcessor
/*     */   implements BeanFactoryPostProcessor, ApplicationContextAware
/*     */ {
/*     */   private static final List<ServletComponentHandler> HANDLERS;
/*     */   private final Set<String> packagesToScan;
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   static {
/*  48 */     List<ServletComponentHandler> servletComponentHandlers = new ArrayList<>();
/*  49 */     servletComponentHandlers.add(new WebServletHandler());
/*  50 */     servletComponentHandlers.add(new WebFilterHandler());
/*  51 */     servletComponentHandlers.add(new WebListenerHandler());
/*  52 */     HANDLERS = Collections.unmodifiableList(servletComponentHandlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServletComponentRegisteringPostProcessor(Set<String> packagesToScan) {
/*  60 */     this.packagesToScan = packagesToScan;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/*  65 */     if (isRunningInEmbeddedWebServer()) {
/*  66 */       ClassPathScanningCandidateComponentProvider componentProvider = createComponentProvider();
/*  67 */       for (String packageToScan : this.packagesToScan) {
/*  68 */         scanPackage(componentProvider, packageToScan);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanPackage(ClassPathScanningCandidateComponentProvider componentProvider, String packageToScan) {
/*  74 */     for (BeanDefinition candidate : componentProvider.findCandidateComponents(packageToScan)) {
/*  75 */       if (candidate instanceof AnnotatedBeanDefinition) {
/*  76 */         for (ServletComponentHandler handler : HANDLERS) {
/*  77 */           handler.handle((AnnotatedBeanDefinition)candidate, (BeanDefinitionRegistry)this.applicationContext);
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isRunningInEmbeddedWebServer() {
/*  85 */     return (this.applicationContext instanceof WebApplicationContext && ((WebApplicationContext)this.applicationContext)
/*  86 */       .getServletContext() == null);
/*     */   }
/*     */   
/*     */   private ClassPathScanningCandidateComponentProvider createComponentProvider() {
/*  90 */     ClassPathScanningCandidateComponentProvider componentProvider = new ClassPathScanningCandidateComponentProvider(false);
/*     */     
/*  92 */     componentProvider.setEnvironment(this.applicationContext.getEnvironment());
/*  93 */     componentProvider.setResourceLoader((ResourceLoader)this.applicationContext);
/*  94 */     for (ServletComponentHandler handler : HANDLERS) {
/*  95 */       componentProvider.addIncludeFilter(handler.getTypeFilter());
/*     */     }
/*  97 */     return componentProvider;
/*     */   }
/*     */   
/*     */   Set<String> getPackagesToScan() {
/* 101 */     return Collections.unmodifiableSet(this.packagesToScan);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 106 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\ServletComponentRegisteringPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
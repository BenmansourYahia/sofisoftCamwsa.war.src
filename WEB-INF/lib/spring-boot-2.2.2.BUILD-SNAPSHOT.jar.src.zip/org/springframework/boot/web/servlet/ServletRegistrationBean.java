/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import javax.servlet.Registration;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRegistration;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletRegistrationBean<T extends Servlet>
/*     */   extends DynamicRegistrationBean<ServletRegistration.Dynamic>
/*     */ {
/*  53 */   private static final String[] DEFAULT_MAPPINGS = new String[] { "/*" };
/*     */   
/*     */   private T servlet;
/*     */   
/*  57 */   private Set<String> urlMappings = new LinkedHashSet<>();
/*     */   
/*     */   private boolean alwaysMapUrl = true;
/*     */   
/*  61 */   private int loadOnStartup = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MultipartConfigElement multipartConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRegistrationBean(T servlet, String... urlMappings) {
/*  78 */     this(servlet, true, urlMappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRegistrationBean(T servlet, boolean alwaysMapUrl, String... urlMappings) {
/*  89 */     Assert.notNull(servlet, "Servlet must not be null");
/*  90 */     Assert.notNull(urlMappings, "UrlMappings must not be null");
/*  91 */     this.servlet = servlet;
/*  92 */     this.alwaysMapUrl = alwaysMapUrl;
/*  93 */     this.urlMappings.addAll(Arrays.asList(urlMappings));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServlet(T servlet) {
/* 101 */     Assert.notNull(servlet, "Servlet must not be null");
/* 102 */     this.servlet = servlet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getServlet() {
/* 110 */     return this.servlet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlMappings(Collection<String> urlMappings) {
/* 120 */     Assert.notNull(urlMappings, "UrlMappings must not be null");
/* 121 */     this.urlMappings = new LinkedHashSet<>(urlMappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getUrlMappings() {
/* 130 */     return this.urlMappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUrlMappings(String... urlMappings) {
/* 139 */     Assert.notNull(urlMappings, "UrlMappings must not be null");
/* 140 */     this.urlMappings.addAll(Arrays.asList(urlMappings));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoadOnStartup(int loadOnStartup) {
/* 149 */     this.loadOnStartup = loadOnStartup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMultipartConfig(MultipartConfigElement multipartConfig) {
/* 157 */     this.multipartConfig = multipartConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartConfigElement getMultipartConfig() {
/* 166 */     return this.multipartConfig;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDescription() {
/* 171 */     Assert.notNull(this.servlet, "Servlet must not be null");
/* 172 */     return "servlet " + getServletName();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ServletRegistration.Dynamic addRegistration(String description, ServletContext servletContext) {
/* 177 */     String name = getServletName();
/* 178 */     return servletContext.addServlet(name, (Servlet)this.servlet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configure(ServletRegistration.Dynamic registration) {
/* 188 */     super.configure(registration);
/* 189 */     String[] urlMapping = StringUtils.toStringArray(this.urlMappings);
/* 190 */     if (urlMapping.length == 0 && this.alwaysMapUrl) {
/* 191 */       urlMapping = DEFAULT_MAPPINGS;
/*     */     }
/* 193 */     if (!ObjectUtils.isEmpty((Object[])urlMapping)) {
/* 194 */       registration.addMapping(urlMapping);
/*     */     }
/* 196 */     registration.setLoadOnStartup(this.loadOnStartup);
/* 197 */     if (this.multipartConfig != null) {
/* 198 */       registration.setMultipartConfig(this.multipartConfig);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServletName() {
/* 207 */     return getOrDeduceName(this.servlet);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 212 */     return getServletName() + " urls=" + getUrlMappings();
/*     */   }
/*     */   
/*     */   public ServletRegistrationBean() {}
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\ServletRegistrationBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
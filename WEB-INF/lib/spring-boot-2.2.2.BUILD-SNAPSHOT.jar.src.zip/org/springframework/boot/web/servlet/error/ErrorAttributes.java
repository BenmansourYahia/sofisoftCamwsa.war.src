package org.springframework.boot.web.servlet.error;

import java.util.Map;
import org.springframework.web.context.request.WebRequest;

public interface ErrorAttributes {
  Map<String, Object> getErrorAttributes(WebRequest paramWebRequest, boolean paramBoolean);
  
  Throwable getError(WebRequest paramWebRequest);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\error\ErrorAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.servlet.context;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*    */ import org.springframework.web.context.support.ServletContextAwareProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebApplicationContextServletContextAwareProcessor
/*    */   extends ServletContextAwareProcessor
/*    */ {
/*    */   private final ConfigurableWebApplicationContext webApplicationContext;
/*    */   
/*    */   public WebApplicationContextServletContextAwareProcessor(ConfigurableWebApplicationContext webApplicationContext) {
/* 40 */     Assert.notNull(webApplicationContext, "WebApplicationContext must not be null");
/* 41 */     this.webApplicationContext = webApplicationContext;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ServletContext getServletContext() {
/* 46 */     ServletContext servletContext = this.webApplicationContext.getServletContext();
/* 47 */     return (servletContext != null) ? servletContext : super.getServletContext();
/*    */   }
/*    */ 
/*    */   
/*    */   protected ServletConfig getServletConfig() {
/* 52 */     ServletConfig servletConfig = this.webApplicationContext.getServletConfig();
/* 53 */     return (servletConfig != null) ? servletConfig : super.getServletConfig();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\context\WebApplicationContextServletContextAwareProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
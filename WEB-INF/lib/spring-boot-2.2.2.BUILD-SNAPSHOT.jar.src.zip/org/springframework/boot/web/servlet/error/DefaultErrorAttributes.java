/*     */ package org.springframework.boot.web.servlet.error;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483648)
/*     */ public class DefaultErrorAttributes
/*     */   implements ErrorAttributes, HandlerExceptionResolver, Ordered
/*     */ {
/*  65 */   private static final String ERROR_ATTRIBUTE = DefaultErrorAttributes.class.getName() + ".ERROR";
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean includeException;
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultErrorAttributes() {
/*  74 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultErrorAttributes(boolean includeException) {
/*  82 */     this.includeException = includeException;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  87 */     return Integer.MIN_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
/*  93 */     storeErrorAttributes(request, ex);
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   private void storeErrorAttributes(HttpServletRequest request, Exception ex) {
/*  98 */     request.setAttribute(ERROR_ATTRIBUTE, ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getErrorAttributes(WebRequest webRequest, boolean includeStackTrace) {
/* 103 */     Map<String, Object> errorAttributes = new LinkedHashMap<>();
/* 104 */     errorAttributes.put("timestamp", new Date());
/* 105 */     addStatus(errorAttributes, (RequestAttributes)webRequest);
/* 106 */     addErrorDetails(errorAttributes, webRequest, includeStackTrace);
/* 107 */     addPath(errorAttributes, (RequestAttributes)webRequest);
/* 108 */     return errorAttributes;
/*     */   }
/*     */   
/*     */   private void addStatus(Map<String, Object> errorAttributes, RequestAttributes requestAttributes) {
/* 112 */     Integer status = getAttribute(requestAttributes, "javax.servlet.error.status_code");
/* 113 */     if (status == null) {
/* 114 */       errorAttributes.put("status", Integer.valueOf(999));
/* 115 */       errorAttributes.put("error", "None");
/*     */       return;
/*     */     } 
/* 118 */     errorAttributes.put("status", status);
/*     */     try {
/* 120 */       errorAttributes.put("error", HttpStatus.valueOf(status.intValue()).getReasonPhrase());
/*     */     }
/* 122 */     catch (Exception ex) {
/*     */       
/* 124 */       errorAttributes.put("error", "Http Status " + status);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addErrorDetails(Map<String, Object> errorAttributes, WebRequest webRequest, boolean includeStackTrace) {
/* 130 */     Throwable error = getError(webRequest);
/* 131 */     if (error != null) {
/* 132 */       while (error instanceof javax.servlet.ServletException && error.getCause() != null) {
/* 133 */         error = error.getCause();
/*     */       }
/* 135 */       if (this.includeException) {
/* 136 */         errorAttributes.put("exception", error.getClass().getName());
/*     */       }
/* 138 */       addErrorMessage(errorAttributes, error);
/* 139 */       if (includeStackTrace) {
/* 140 */         addStackTrace(errorAttributes, error);
/*     */       }
/*     */     } 
/* 143 */     Object message = getAttribute((RequestAttributes)webRequest, "javax.servlet.error.message");
/* 144 */     if ((!StringUtils.isEmpty(message) || errorAttributes.get("message") == null) && !(error instanceof BindingResult))
/*     */     {
/* 146 */       errorAttributes.put("message", StringUtils.isEmpty(message) ? "No message available" : message);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addErrorMessage(Map<String, Object> errorAttributes, Throwable error) {
/* 151 */     BindingResult result = extractBindingResult(error);
/* 152 */     if (result == null) {
/* 153 */       errorAttributes.put("message", error.getMessage());
/*     */       return;
/*     */     } 
/* 156 */     if (result.hasErrors()) {
/* 157 */       errorAttributes.put("errors", result.getAllErrors());
/* 158 */       errorAttributes.put("message", "Validation failed for object='" + result.getObjectName() + "'. Error count: " + result
/* 159 */           .getErrorCount());
/*     */     } else {
/*     */       
/* 162 */       errorAttributes.put("message", "No errors");
/*     */     } 
/*     */   }
/*     */   
/*     */   private BindingResult extractBindingResult(Throwable error) {
/* 167 */     if (error instanceof BindingResult) {
/* 168 */       return (BindingResult)error;
/*     */     }
/* 170 */     if (error instanceof MethodArgumentNotValidException) {
/* 171 */       return ((MethodArgumentNotValidException)error).getBindingResult();
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */   
/*     */   private void addStackTrace(Map<String, Object> errorAttributes, Throwable error) {
/* 177 */     StringWriter stackTrace = new StringWriter();
/* 178 */     error.printStackTrace(new PrintWriter(stackTrace));
/* 179 */     stackTrace.flush();
/* 180 */     errorAttributes.put("trace", stackTrace.toString());
/*     */   }
/*     */   
/*     */   private void addPath(Map<String, Object> errorAttributes, RequestAttributes requestAttributes) {
/* 184 */     String path = getAttribute(requestAttributes, "javax.servlet.error.request_uri");
/* 185 */     if (path != null) {
/* 186 */       errorAttributes.put("path", path);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getError(WebRequest webRequest) {
/* 192 */     Throwable exception = getAttribute((RequestAttributes)webRequest, ERROR_ATTRIBUTE);
/* 193 */     if (exception == null) {
/* 194 */       exception = getAttribute((RequestAttributes)webRequest, "javax.servlet.error.exception");
/*     */     }
/* 196 */     return exception;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T getAttribute(RequestAttributes requestAttributes, String name) {
/* 201 */     return (T)requestAttributes.getAttribute(name, 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\error\DefaultErrorAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
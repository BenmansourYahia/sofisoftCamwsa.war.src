/*     */ package org.springframework.boot.web.servlet.server;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.CodeSource;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DocumentRoot
/*     */ {
/*  37 */   private static final String[] COMMON_DOC_ROOTS = new String[] { "src/main/webapp", "public", "static" };
/*     */   
/*     */   private final Log logger;
/*     */   
/*     */   private File directory;
/*     */   
/*     */   DocumentRoot(Log logger) {
/*  44 */     this.logger = logger;
/*     */   }
/*     */   
/*     */   File getDirectory() {
/*  48 */     return this.directory;
/*     */   }
/*     */   
/*     */   void setDirectory(File directory) {
/*  52 */     this.directory = directory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final File getValidDirectory() {
/*  61 */     File file = this.directory;
/*  62 */     file = (file != null) ? file : getWarFileDocumentRoot();
/*  63 */     file = (file != null) ? file : getExplodedWarFileDocumentRoot();
/*  64 */     file = (file != null) ? file : getCommonDocumentRoot();
/*  65 */     if (file == null && this.logger.isDebugEnabled()) {
/*  66 */       logNoDocumentRoots();
/*     */     }
/*  68 */     else if (this.logger.isDebugEnabled()) {
/*  69 */       this.logger.debug("Document root: " + file);
/*     */     } 
/*  71 */     return file;
/*     */   }
/*     */   
/*     */   private File getWarFileDocumentRoot() {
/*  75 */     return getArchiveFileDocumentRoot(".war");
/*     */   }
/*     */   
/*     */   private File getArchiveFileDocumentRoot(String extension) {
/*  79 */     File file = getCodeSourceArchive();
/*  80 */     if (this.logger.isDebugEnabled()) {
/*  81 */       this.logger.debug("Code archive: " + file);
/*     */     }
/*  83 */     if (file != null && file.exists() && !file.isDirectory() && file
/*  84 */       .getName().toLowerCase(Locale.ENGLISH).endsWith(extension)) {
/*  85 */       return file.getAbsoluteFile();
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */   
/*     */   private File getExplodedWarFileDocumentRoot() {
/*  91 */     return getExplodedWarFileDocumentRoot(getCodeSourceArchive());
/*     */   }
/*     */   
/*     */   private File getCodeSourceArchive() {
/*  95 */     return getCodeSourceArchive(getClass().getProtectionDomain().getCodeSource());
/*     */   }
/*     */   File getCodeSourceArchive(CodeSource codeSource) {
/*     */     try {
/*     */       String path;
/* 100 */       URL location = (codeSource != null) ? codeSource.getLocation() : null;
/* 101 */       if (location == null) {
/* 102 */         return null;
/*     */       }
/*     */       
/* 105 */       URLConnection connection = location.openConnection();
/* 106 */       if (connection instanceof JarURLConnection) {
/* 107 */         path = ((JarURLConnection)connection).getJarFile().getName();
/*     */       } else {
/*     */         
/* 110 */         path = location.toURI().getPath();
/*     */       } 
/* 112 */       int index = path.indexOf("!/");
/* 113 */       if (index != -1) {
/* 114 */         path = path.substring(0, index);
/*     */       }
/* 116 */       return new File(path);
/*     */     }
/* 118 */     catch (Exception ex) {
/* 119 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   final File getExplodedWarFileDocumentRoot(File codeSourceFile) {
/* 124 */     if (this.logger.isDebugEnabled()) {
/* 125 */       this.logger.debug("Code archive: " + codeSourceFile);
/*     */     }
/* 127 */     if (codeSourceFile != null && codeSourceFile.exists()) {
/* 128 */       String path = codeSourceFile.getAbsolutePath();
/* 129 */       int webInfPathIndex = path.indexOf(File.separatorChar + "WEB-INF" + File.separatorChar);
/* 130 */       if (webInfPathIndex >= 0) {
/* 131 */         path = path.substring(0, webInfPathIndex);
/* 132 */         return new File(path);
/*     */       } 
/*     */     } 
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   private File getCommonDocumentRoot() {
/* 139 */     for (String commonDocRoot : COMMON_DOC_ROOTS) {
/* 140 */       File root = new File(commonDocRoot);
/* 141 */       if (root.exists() && root.isDirectory()) {
/* 142 */         return root.getAbsoluteFile();
/*     */       }
/*     */     } 
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   private void logNoDocumentRoots() {
/* 149 */     this.logger.debug("None of the document roots " + Arrays.<String>asList(COMMON_DOC_ROOTS) + " point to a directory and will be ignored.");
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\server\DocumentRoot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*    */ import org.springframework.core.type.filter.TypeFilter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ServletComponentHandler
/*    */ {
/*    */   private final Class<? extends Annotation> annotationType;
/*    */   private final TypeFilter typeFilter;
/*    */   
/*    */   protected ServletComponentHandler(Class<? extends Annotation> annotationType) {
/* 43 */     this.typeFilter = (TypeFilter)new AnnotationTypeFilter(annotationType);
/* 44 */     this.annotationType = annotationType;
/*    */   }
/*    */   
/*    */   TypeFilter getTypeFilter() {
/* 48 */     return this.typeFilter;
/*    */   }
/*    */   
/*    */   protected String[] extractUrlPatterns(Map<String, Object> attributes) {
/* 52 */     String[] value = (String[])attributes.get("value");
/* 53 */     String[] urlPatterns = (String[])attributes.get("urlPatterns");
/* 54 */     if (urlPatterns.length > 0) {
/* 55 */       Assert.state((value.length == 0), "The urlPatterns and value attributes are mutually exclusive.");
/* 56 */       return urlPatterns;
/*    */     } 
/* 58 */     return value;
/*    */   }
/*    */   
/*    */   protected final Map<String, String> extractInitParameters(Map<String, Object> attributes) {
/* 62 */     Map<String, String> initParameters = new HashMap<>();
/* 63 */     for (AnnotationAttributes initParam : (AnnotationAttributes[])attributes.get("initParams")) {
/* 64 */       String name = (String)initParam.get("name");
/* 65 */       String value = (String)initParam.get("value");
/* 66 */       initParameters.put(name, value);
/*    */     } 
/* 68 */     return initParameters;
/*    */   }
/*    */ 
/*    */   
/*    */   void handle(AnnotatedBeanDefinition beanDefinition, BeanDefinitionRegistry registry) {
/* 73 */     Map<String, Object> attributes = beanDefinition.getMetadata().getAnnotationAttributes(this.annotationType.getName());
/* 74 */     if (attributes != null)
/* 75 */       doHandle(attributes, beanDefinition, registry); 
/*    */   }
/*    */   
/*    */   protected abstract void doHandle(Map<String, Object> paramMap, AnnotatedBeanDefinition paramAnnotatedBeanDefinition, BeanDefinitionRegistry paramBeanDefinitionRegistry);
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\ServletComponentHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.servlet.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EventListener;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.builder.ParentContextApplicationContextInitializer;
/*     */ import org.springframework.boot.builder.SpringApplicationBuilder;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.WebApplicationInitializer;
/*     */ import org.springframework.web.context.ConfigurableWebEnvironment;
/*     */ import org.springframework.web.context.ContextLoaderListener;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpringBootServletInitializer
/*     */   implements WebApplicationInitializer
/*     */ {
/*     */   protected Log logger;
/*     */   private boolean registerErrorPageFilter = true;
/*     */   
/*     */   protected final void setRegisterErrorPageFilter(boolean registerErrorPageFilter) {
/*  84 */     this.registerErrorPageFilter = registerErrorPageFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onStartup(ServletContext servletContext) throws ServletException {
/*  91 */     this.logger = LogFactory.getLog(getClass());
/*  92 */     WebApplicationContext rootAppContext = createRootApplicationContext(servletContext);
/*  93 */     if (rootAppContext != null) {
/*  94 */       servletContext.addListener((EventListener)new ContextLoaderListener(rootAppContext)
/*     */           {
/*     */ 
/*     */ 
/*     */             
/*     */             public void contextInitialized(ServletContextEvent event) {}
/*     */           });
/*     */     } else {
/* 102 */       this.logger.debug("No ContextLoaderListener registered, as createRootApplicationContext() did not return an application context");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected WebApplicationContext createRootApplicationContext(ServletContext servletContext) {
/* 108 */     SpringApplicationBuilder builder = createSpringApplicationBuilder();
/* 109 */     builder.main(getClass());
/* 110 */     ApplicationContext parent = getExistingRootWebApplicationContext(servletContext);
/* 111 */     if (parent != null) {
/* 112 */       this.logger.info("Root context already created (using as parent).");
/* 113 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, null);
/* 114 */       builder.initializers(new ApplicationContextInitializer[] { (ApplicationContextInitializer)new ParentContextApplicationContextInitializer(parent) });
/*     */     } 
/* 116 */     builder.initializers(new ApplicationContextInitializer[] { new ServletContextApplicationContextInitializer(servletContext) });
/* 117 */     builder.contextClass(AnnotationConfigServletWebServerApplicationContext.class);
/* 118 */     builder = configure(builder);
/* 119 */     builder.listeners(new ApplicationListener[] { new WebEnvironmentPropertySourceInitializer(servletContext) });
/* 120 */     SpringApplication application = builder.build();
/* 121 */     if (application.getAllSources().isEmpty() && 
/* 122 */       MergedAnnotations.from(getClass(), MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).isPresent(Configuration.class)) {
/* 123 */       application.addPrimarySources(Collections.singleton(getClass()));
/*     */     }
/* 125 */     Assert.state(!application.getAllSources().isEmpty(), "No SpringApplication sources have been defined. Either override the configure method or add an @Configuration annotation");
/*     */ 
/*     */ 
/*     */     
/* 129 */     if (this.registerErrorPageFilter) {
/* 130 */       application.addPrimarySources(Collections.singleton(ErrorPageFilterConfiguration.class));
/*     */     }
/* 132 */     return run(application);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpringApplicationBuilder createSpringApplicationBuilder() {
/* 143 */     return new SpringApplicationBuilder(new Class[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebApplicationContext run(SpringApplication application) {
/* 152 */     return (WebApplicationContext)application.run(new String[0]);
/*     */   }
/*     */   
/*     */   private ApplicationContext getExistingRootWebApplicationContext(ServletContext servletContext) {
/* 156 */     Object context = servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 157 */     if (context instanceof ApplicationContext) {
/* 158 */       return (ApplicationContext)context;
/*     */     }
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
/* 173 */     return builder;
/*     */   }
/*     */   
/*     */   private static final class WebEnvironmentPropertySourceInitializer
/*     */     implements ApplicationListener<ApplicationEnvironmentPreparedEvent>, Ordered
/*     */   {
/*     */     private final ServletContext servletContext;
/*     */     
/*     */     private WebEnvironmentPropertySourceInitializer(ServletContext servletContext) {
/* 182 */       this.servletContext = servletContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
/* 187 */       ConfigurableEnvironment environment = event.getEnvironment();
/* 188 */       if (environment instanceof ConfigurableWebEnvironment) {
/* 189 */         ((ConfigurableWebEnvironment)environment).initPropertySources(this.servletContext, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 195 */       return Integer.MIN_VALUE;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\support\SpringBootServletInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
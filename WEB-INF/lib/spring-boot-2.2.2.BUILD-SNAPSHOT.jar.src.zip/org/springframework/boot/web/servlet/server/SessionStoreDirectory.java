/*    */ package org.springframework.boot.web.servlet.server;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.springframework.boot.system.ApplicationHome;
/*    */ import org.springframework.boot.system.ApplicationTemp;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SessionStoreDirectory
/*    */ {
/*    */   private File directory;
/*    */   
/*    */   File getDirectory() {
/* 36 */     return this.directory;
/*    */   }
/*    */   
/*    */   void setDirectory(File directory) {
/* 40 */     this.directory = directory;
/*    */   }
/*    */   
/*    */   File getValidDirectory(boolean mkdirs) {
/* 44 */     File dir = getDirectory();
/* 45 */     if (dir == null) {
/* 46 */       return (new ApplicationTemp()).getDir("servlet-sessions");
/*    */     }
/* 48 */     if (!dir.isAbsolute()) {
/* 49 */       dir = new File((new ApplicationHome()).getDir(), dir.getPath());
/*    */     }
/* 51 */     if (!dir.exists() && mkdirs) {
/* 52 */       dir.mkdirs();
/*    */     }
/* 54 */     assertDirectory(mkdirs, dir);
/* 55 */     return dir;
/*    */   }
/*    */   
/*    */   private void assertDirectory(boolean mkdirs, File dir) {
/* 59 */     Assert.state((!mkdirs || dir.exists()), () -> "Session dir " + dir + " does not exist");
/* 60 */     Assert.state(!dir.isFile(), () -> "Session dir " + dir + " points to a file");
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\server\SessionStoreDirectory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
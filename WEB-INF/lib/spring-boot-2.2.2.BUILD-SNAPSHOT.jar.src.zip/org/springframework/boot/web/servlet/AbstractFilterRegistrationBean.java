/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterRegistration;
/*     */ import javax.servlet.Registration;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFilterRegistrationBean<T extends Filter>
/*     */   extends DynamicRegistrationBean<FilterRegistration.Dynamic>
/*     */ {
/*  46 */   private static final String[] DEFAULT_URL_MAPPINGS = new String[] { "/*" };
/*     */   
/*  48 */   private Set<ServletRegistrationBean<?>> servletRegistrationBeans = new LinkedHashSet<>();
/*     */   
/*  50 */   private Set<String> servletNames = new LinkedHashSet<>();
/*     */   
/*  52 */   private Set<String> urlPatterns = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private EnumSet<DispatcherType> dispatcherTypes;
/*     */ 
/*     */   
/*     */   private boolean matchAfter = false;
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractFilterRegistrationBean(ServletRegistrationBean<?>... servletRegistrationBeans) {
/*  64 */     Assert.notNull(servletRegistrationBeans, "ServletRegistrationBeans must not be null");
/*  65 */     Collections.addAll(this.servletRegistrationBeans, servletRegistrationBeans);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletRegistrationBeans(Collection<? extends ServletRegistrationBean<?>> servletRegistrationBeans) {
/*  73 */     Assert.notNull(servletRegistrationBeans, "ServletRegistrationBeans must not be null");
/*  74 */     this.servletRegistrationBeans = new LinkedHashSet<>(servletRegistrationBeans);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ServletRegistrationBean<?>> getServletRegistrationBeans() {
/*  85 */     return this.servletRegistrationBeans;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addServletRegistrationBeans(ServletRegistrationBean<?>... servletRegistrationBeans) {
/*  94 */     Assert.notNull(servletRegistrationBeans, "ServletRegistrationBeans must not be null");
/*  95 */     Collections.addAll(this.servletRegistrationBeans, servletRegistrationBeans);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletNames(Collection<String> servletNames) {
/* 106 */     Assert.notNull(servletNames, "ServletNames must not be null");
/* 107 */     this.servletNames = new LinkedHashSet<>(servletNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getServletNames() {
/* 116 */     return this.servletNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addServletNames(String... servletNames) {
/* 124 */     Assert.notNull(servletNames, "ServletNames must not be null");
/* 125 */     this.servletNames.addAll(Arrays.asList(servletNames));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPatterns(Collection<String> urlPatterns) {
/* 136 */     Assert.notNull(urlPatterns, "UrlPatterns must not be null");
/* 137 */     this.urlPatterns = new LinkedHashSet<>(urlPatterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getUrlPatterns() {
/* 146 */     return this.urlPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUrlPatterns(String... urlPatterns) {
/* 155 */     Assert.notNull(urlPatterns, "UrlPatterns must not be null");
/* 156 */     Collections.addAll(this.urlPatterns, urlPatterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDispatcherTypes(DispatcherType first, DispatcherType... rest) {
/* 166 */     this.dispatcherTypes = EnumSet.of(first, rest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDispatcherTypes(EnumSet<DispatcherType> dispatcherTypes) {
/* 176 */     this.dispatcherTypes = dispatcherTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchAfter(boolean matchAfter) {
/* 186 */     this.matchAfter = matchAfter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMatchAfter() {
/* 195 */     return this.matchAfter;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDescription() {
/* 200 */     Filter filter = (Filter)getFilter();
/* 201 */     Assert.notNull(filter, "Filter must not be null");
/* 202 */     return "filter " + getOrDeduceName(filter);
/*     */   }
/*     */ 
/*     */   
/*     */   protected FilterRegistration.Dynamic addRegistration(String description, ServletContext servletContext) {
/* 207 */     Filter filter = (Filter)getFilter();
/* 208 */     return servletContext.addFilter(getOrDeduceName(filter), filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configure(FilterRegistration.Dynamic registration) {
/* 218 */     super.configure(registration);
/* 219 */     EnumSet<DispatcherType> dispatcherTypes = this.dispatcherTypes;
/* 220 */     if (dispatcherTypes == null) {
/* 221 */       dispatcherTypes = EnumSet.of(DispatcherType.REQUEST);
/*     */     }
/* 223 */     Set<String> servletNames = new LinkedHashSet<>();
/* 224 */     for (ServletRegistrationBean<?> servletRegistrationBean : this.servletRegistrationBeans) {
/* 225 */       servletNames.add(servletRegistrationBean.getServletName());
/*     */     }
/* 227 */     servletNames.addAll(this.servletNames);
/* 228 */     if (servletNames.isEmpty() && this.urlPatterns.isEmpty()) {
/* 229 */       registration.addMappingForUrlPatterns(dispatcherTypes, this.matchAfter, DEFAULT_URL_MAPPINGS);
/*     */     } else {
/*     */       
/* 232 */       if (!servletNames.isEmpty()) {
/* 233 */         registration.addMappingForServletNames(dispatcherTypes, this.matchAfter, 
/* 234 */             StringUtils.toStringArray(servletNames));
/*     */       }
/* 236 */       if (!this.urlPatterns.isEmpty()) {
/* 237 */         registration.addMappingForUrlPatterns(dispatcherTypes, this.matchAfter, 
/* 238 */             StringUtils.toStringArray(this.urlPatterns));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 251 */     StringBuilder builder = new StringBuilder(getOrDeduceName(this));
/* 252 */     if (this.servletNames.isEmpty() && this.urlPatterns.isEmpty()) {
/* 253 */       builder.append(" urls=").append(Arrays.toString((Object[])DEFAULT_URL_MAPPINGS));
/*     */     } else {
/*     */       
/* 256 */       if (!this.servletNames.isEmpty()) {
/* 257 */         builder.append(" servlets=").append(this.servletNames);
/*     */       }
/* 259 */       if (!this.urlPatterns.isEmpty()) {
/* 260 */         builder.append(" urls=").append(this.urlPatterns);
/*     */       }
/*     */     } 
/* 263 */     builder.append(" order=").append(getOrder());
/* 264 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public abstract T getFilter();
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\AbstractFilterRegistrationBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
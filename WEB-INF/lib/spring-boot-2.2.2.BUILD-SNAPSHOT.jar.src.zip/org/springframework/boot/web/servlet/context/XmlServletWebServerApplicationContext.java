/*     */ package org.springframework.boot.web.servlet.context;
/*     */ 
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlServletWebServerApplicationContext
/*     */   extends ServletWebServerApplicationContext
/*     */ {
/*  43 */   private final XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader((BeanDefinitionRegistry)this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlServletWebServerApplicationContext() {
/*  50 */     this.reader.setEnvironment((Environment)getEnvironment());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlServletWebServerApplicationContext(Resource... resources) {
/*  59 */     load(resources);
/*  60 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlServletWebServerApplicationContext(String... resourceLocations) {
/*  70 */     load(resourceLocations);
/*  71 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlServletWebServerApplicationContext(Class<?> relativeClass, String... resourceNames) {
/*  83 */     load(relativeClass, resourceNames);
/*  84 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidating(boolean validating) {
/*  92 */     this.reader.setValidating(validating);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(ConfigurableEnvironment environment) {
/* 103 */     super.setEnvironment(environment);
/* 104 */     this.reader.setEnvironment((Environment)getEnvironment());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void load(Resource... resources) {
/* 112 */     this.reader.loadBeanDefinitions(resources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void load(String... resourceLocations) {
/* 120 */     this.reader.loadBeanDefinitions(resourceLocations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void load(Class<?> relativeClass, String... resourceNames) {
/* 130 */     Resource[] resources = new Resource[resourceNames.length];
/* 131 */     for (int i = 0; i < resourceNames.length; i++) {
/* 132 */       resources[i] = (Resource)new ClassPathResource(resourceNames[i], relativeClass);
/*     */     }
/* 134 */     this.reader.loadBeanDefinitions(resources);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\context\XmlServletWebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
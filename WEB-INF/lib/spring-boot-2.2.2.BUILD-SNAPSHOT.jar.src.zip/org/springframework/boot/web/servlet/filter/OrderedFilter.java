package org.springframework.boot.web.servlet.filter;

import javax.servlet.Filter;
import org.springframework.core.Ordered;

public interface OrderedFilter extends Filter, Ordered {
  public static final int REQUEST_WRAPPER_FILTER_MAX_ORDER = 0;
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\filter\OrderedFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
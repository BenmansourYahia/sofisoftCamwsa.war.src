/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import javax.servlet.MultipartConfigElement;
/*    */ import org.springframework.util.unit.DataSize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipartConfigFactory
/*    */ {
/*    */   private String location;
/*    */   private DataSize maxFileSize;
/*    */   private DataSize maxRequestSize;
/*    */   private DataSize fileSizeThreshold;
/*    */   
/*    */   public void setLocation(String location) {
/* 44 */     this.location = location;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMaxFileSize(DataSize maxFileSize) {
/* 52 */     this.maxFileSize = maxFileSize;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMaxRequestSize(DataSize maxRequestSize) {
/* 60 */     this.maxRequestSize = maxRequestSize;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFileSizeThreshold(DataSize fileSizeThreshold) {
/* 68 */     this.fileSizeThreshold = fileSizeThreshold;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MultipartConfigElement createMultipartConfig() {
/* 76 */     long maxFileSizeBytes = convertToBytes(this.maxFileSize, -1);
/* 77 */     long maxRequestSizeBytes = convertToBytes(this.maxRequestSize, -1);
/* 78 */     long fileSizeThresholdBytes = convertToBytes(this.fileSizeThreshold, 0);
/* 79 */     return new MultipartConfigElement(this.location, maxFileSizeBytes, maxRequestSizeBytes, (int)fileSizeThresholdBytes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private long convertToBytes(DataSize size, int defaultValue) {
/* 91 */     if (size != null && !size.isNegative()) {
/* 92 */       return size.toBytes();
/*    */     }
/* 94 */     return defaultValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\MultipartConfigFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
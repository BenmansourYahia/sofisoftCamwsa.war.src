/*    */ package org.springframework.boot.web.servlet.server;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jsp
/*    */ {
/* 35 */   private String className = "org.apache.jasper.servlet.JspServlet";
/*    */   
/* 37 */   private Map<String, String> initParameters = new HashMap<>();
/*    */ 
/*    */   
/*    */   private boolean registered = true;
/*    */ 
/*    */ 
/*    */   
/*    */   public Jsp() {
/* 45 */     this.initParameters.put("development", "false");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 55 */     return this.className;
/*    */   }
/*    */   
/*    */   public void setClassName(String className) {
/* 59 */     this.className = className;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, String> getInitParameters() {
/* 67 */     return this.initParameters;
/*    */   }
/*    */   
/*    */   public void setInitParameters(Map<String, String> initParameters) {
/* 71 */     this.initParameters = initParameters;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getRegistered() {
/* 79 */     return this.registered;
/*    */   }
/*    */   
/*    */   public void setRegistered(boolean registered) {
/* 83 */     this.registered = registered;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\server\Jsp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.servlet.context;
/*    */ 
/*    */ import org.springframework.boot.web.context.WebServerApplicationContext;
/*    */ import org.springframework.boot.web.context.WebServerInitializedEvent;
/*    */ import org.springframework.boot.web.server.WebServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletWebServerInitializedEvent
/*    */   extends WebServerInitializedEvent
/*    */ {
/*    */   private final ServletWebServerApplicationContext applicationContext;
/*    */   
/*    */   public ServletWebServerInitializedEvent(WebServer webServer, ServletWebServerApplicationContext applicationContext) {
/* 41 */     super(webServer);
/* 42 */     this.applicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ServletWebServerApplicationContext getApplicationContext() {
/* 53 */     return this.applicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\context\ServletWebServerInitializedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
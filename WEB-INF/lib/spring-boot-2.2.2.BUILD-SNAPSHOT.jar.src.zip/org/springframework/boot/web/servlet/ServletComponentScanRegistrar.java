/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ServletComponentScanRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/*    */   private static final String BEAN_NAME = "servletComponentRegisteringPostProcessor";
/*    */   
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 45 */     Set<String> packagesToScan = getPackagesToScan(importingClassMetadata);
/* 46 */     if (registry.containsBeanDefinition("servletComponentRegisteringPostProcessor")) {
/* 47 */       updatePostProcessor(registry, packagesToScan);
/*    */     } else {
/*    */       
/* 50 */       addPostProcessor(registry, packagesToScan);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void updatePostProcessor(BeanDefinitionRegistry registry, Set<String> packagesToScan) {
/* 55 */     BeanDefinition definition = registry.getBeanDefinition("servletComponentRegisteringPostProcessor");
/* 56 */     ConstructorArgumentValues.ValueHolder constructorArguments = definition.getConstructorArgumentValues().getGenericArgumentValue(Set.class);
/*    */     
/* 58 */     Set<String> mergedPackages = (Set<String>)constructorArguments.getValue();
/* 59 */     mergedPackages.addAll(packagesToScan);
/* 60 */     constructorArguments.setValue(mergedPackages);
/*    */   }
/*    */   
/*    */   private void addPostProcessor(BeanDefinitionRegistry registry, Set<String> packagesToScan) {
/* 64 */     GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 65 */     beanDefinition.setBeanClass(ServletComponentRegisteringPostProcessor.class);
/* 66 */     beanDefinition.getConstructorArgumentValues().addGenericArgumentValue(packagesToScan);
/* 67 */     beanDefinition.setRole(2);
/* 68 */     registry.registerBeanDefinition("servletComponentRegisteringPostProcessor", (BeanDefinition)beanDefinition);
/*    */   }
/*    */ 
/*    */   
/*    */   private Set<String> getPackagesToScan(AnnotationMetadata metadata) {
/* 73 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(ServletComponentScan.class.getName()));
/* 74 */     String[] basePackages = attributes.getStringArray("basePackages");
/* 75 */     Class<?>[] basePackageClasses = attributes.getClassArray("basePackageClasses");
/* 76 */     Set<String> packagesToScan = new LinkedHashSet<>(Arrays.asList(basePackages));
/* 77 */     for (Class<?> basePackageClass : basePackageClasses) {
/* 78 */       packagesToScan.add(ClassUtils.getPackageName(basePackageClass));
/*    */     }
/* 80 */     if (packagesToScan.isEmpty()) {
/* 81 */       packagesToScan.add(ClassUtils.getPackageName(metadata.getClassName()));
/*    */     }
/* 83 */     return packagesToScan;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\ServletComponentScanRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
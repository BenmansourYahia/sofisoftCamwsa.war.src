/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.scope.ScopedProxyUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletContextInitializerBeans
/*     */   extends AbstractCollection<ServletContextInitializer>
/*     */ {
/*     */   private static final String DISPATCHER_SERVLET_NAME = "dispatcherServlet";
/*  66 */   private static final Log logger = LogFactory.getLog(ServletContextInitializerBeans.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private final Set<Object> seen = new HashSet();
/*     */   
/*     */   private final MultiValueMap<Class<?>, ServletContextInitializer> initializers;
/*     */   
/*     */   private final List<Class<? extends ServletContextInitializer>> initializerTypes;
/*     */   
/*     */   private List<ServletContextInitializer> sortedList;
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ServletContextInitializerBeans(ListableBeanFactory beanFactory, Class<? extends ServletContextInitializer>... initializerTypes) {
/*  82 */     this.initializers = (MultiValueMap<Class<?>, ServletContextInitializer>)new LinkedMultiValueMap();
/*  83 */     this
/*  84 */       .initializerTypes = (initializerTypes.length != 0) ? Arrays.<Class<? extends ServletContextInitializer>>asList(initializerTypes) : Collections.<Class<? extends ServletContextInitializer>>singletonList(ServletContextInitializer.class);
/*  85 */     addServletContextInitializerBeans(beanFactory);
/*  86 */     addAdaptableBeans(beanFactory);
/*     */ 
/*     */     
/*  89 */     List<ServletContextInitializer> sortedInitializers = (List<ServletContextInitializer>)this.initializers.values().stream().flatMap(value -> value.stream().sorted((Comparator)AnnotationAwareOrderComparator.INSTANCE)).collect(Collectors.toList());
/*  90 */     this.sortedList = Collections.unmodifiableList(sortedInitializers);
/*  91 */     logMappings(this.initializers);
/*     */   }
/*     */   
/*     */   private void addServletContextInitializerBeans(ListableBeanFactory beanFactory) {
/*  95 */     for (Class<? extends ServletContextInitializer> initializerType : this.initializerTypes) {
/*  96 */       for (Map.Entry<String, ? extends ServletContextInitializer> initializerBean : getOrderedBeansOfType(beanFactory, initializerType))
/*     */       {
/*  98 */         addServletContextInitializerBean(initializerBean.getKey(), initializerBean.getValue(), beanFactory);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addServletContextInitializerBean(String beanName, ServletContextInitializer initializer, ListableBeanFactory beanFactory) {
/* 105 */     if (initializer instanceof ServletRegistrationBean) {
/* 106 */       Servlet source = ((ServletRegistrationBean<Servlet>)initializer).getServlet();
/* 107 */       addServletContextInitializerBean(Servlet.class, beanName, initializer, beanFactory, source);
/*     */     }
/* 109 */     else if (initializer instanceof FilterRegistrationBean) {
/* 110 */       Filter source = ((FilterRegistrationBean<Filter>)initializer).getFilter();
/* 111 */       addServletContextInitializerBean(Filter.class, beanName, initializer, beanFactory, source);
/*     */     }
/* 113 */     else if (initializer instanceof DelegatingFilterProxyRegistrationBean) {
/* 114 */       String source = ((DelegatingFilterProxyRegistrationBean)initializer).getTargetBeanName();
/* 115 */       addServletContextInitializerBean(Filter.class, beanName, initializer, beanFactory, source);
/*     */     }
/* 117 */     else if (initializer instanceof ServletListenerRegistrationBean) {
/* 118 */       EventListener source = ((ServletListenerRegistrationBean<EventListener>)initializer).getListener();
/* 119 */       addServletContextInitializerBean(EventListener.class, beanName, initializer, beanFactory, source);
/*     */     } else {
/*     */       
/* 122 */       addServletContextInitializerBean(ServletContextInitializer.class, beanName, initializer, beanFactory, initializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addServletContextInitializerBean(Class<?> type, String beanName, ServletContextInitializer initializer, ListableBeanFactory beanFactory, Object source) {
/* 129 */     this.initializers.add(type, initializer);
/* 130 */     if (source != null)
/*     */     {
/* 132 */       this.seen.add(source);
/*     */     }
/* 134 */     if (logger.isTraceEnabled()) {
/* 135 */       String resourceDescription = getResourceDescription(beanName, beanFactory);
/* 136 */       int order = getOrder(initializer);
/* 137 */       logger.trace("Added existing " + type.getSimpleName() + " initializer bean '" + beanName + "'; order=" + order + ", resource=" + resourceDescription);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getResourceDescription(String beanName, ListableBeanFactory beanFactory) {
/* 143 */     if (beanFactory instanceof BeanDefinitionRegistry) {
/* 144 */       BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/* 145 */       return registry.getBeanDefinition(beanName).getResourceDescription();
/*     */     } 
/* 147 */     return "unknown";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addAdaptableBeans(ListableBeanFactory beanFactory) {
/* 152 */     MultipartConfigElement multipartConfig = getMultipartConfig(beanFactory);
/* 153 */     addAsRegistrationBean(beanFactory, Servlet.class, new ServletRegistrationBeanAdapter(multipartConfig));
/* 154 */     addAsRegistrationBean(beanFactory, Filter.class, new FilterRegistrationBeanAdapter());
/* 155 */     for (Class<?> listenerType : ServletListenerRegistrationBean.getSupportedTypes()) {
/* 156 */       addAsRegistrationBean(beanFactory, EventListener.class, listenerType, new ServletListenerRegistrationBeanAdapter());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private MultipartConfigElement getMultipartConfig(ListableBeanFactory beanFactory) {
/* 162 */     List<Map.Entry<String, MultipartConfigElement>> beans = getOrderedBeansOfType(beanFactory, MultipartConfigElement.class);
/*     */     
/* 164 */     return beans.isEmpty() ? null : (MultipartConfigElement)((Map.Entry)beans.get(0)).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T> void addAsRegistrationBean(ListableBeanFactory beanFactory, Class<T> type, RegistrationBeanAdapter<T> adapter) {
/* 169 */     addAsRegistrationBean(beanFactory, type, type, adapter);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T, B extends T> void addAsRegistrationBean(ListableBeanFactory beanFactory, Class<T> type, Class<B> beanType, RegistrationBeanAdapter<T> adapter) {
/* 174 */     List<Map.Entry<String, B>> entries = getOrderedBeansOfType(beanFactory, beanType, this.seen);
/* 175 */     for (Map.Entry<String, B> entry : entries) {
/* 176 */       String beanName = entry.getKey();
/* 177 */       B bean = entry.getValue();
/* 178 */       if (this.seen.add(bean)) {
/*     */         
/* 180 */         RegistrationBean registration = adapter.createRegistrationBean(beanName, (T)bean, entries.size());
/* 181 */         int order = getOrder(bean);
/* 182 */         registration.setOrder(order);
/* 183 */         this.initializers.add(type, registration);
/* 184 */         if (logger.isTraceEnabled()) {
/* 185 */           logger.trace("Created " + type.getSimpleName() + " initializer for bean '" + beanName + "'; order=" + order + ", resource=" + 
/* 186 */               getResourceDescription(beanName, beanFactory));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getOrder(Object value) {
/* 193 */     return (new AnnotationAwareOrderComparator()
/*     */       {
/*     */         public int getOrder(Object obj) {
/* 196 */           return super.getOrder(obj);
/*     */         }
/* 198 */       }).getOrder(value);
/*     */   }
/*     */   
/*     */   private <T> List<Map.Entry<String, T>> getOrderedBeansOfType(ListableBeanFactory beanFactory, Class<T> type) {
/* 202 */     return getOrderedBeansOfType(beanFactory, type, Collections.emptySet());
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> List<Map.Entry<String, T>> getOrderedBeansOfType(ListableBeanFactory beanFactory, Class<T> type, Set<?> excludes) {
/* 207 */     String[] names = beanFactory.getBeanNamesForType(type, true, false);
/* 208 */     Map<String, T> map = new LinkedHashMap<>();
/* 209 */     for (String name : names) {
/* 210 */       if (!excludes.contains(name) && !ScopedProxyUtils.isScopedTarget(name)) {
/* 211 */         T bean = (T)beanFactory.getBean(name, type);
/* 212 */         if (!excludes.contains(bean)) {
/* 213 */           map.put(name, bean);
/*     */         }
/*     */       } 
/*     */     } 
/* 217 */     List<Map.Entry<String, T>> beans = new ArrayList<>(map.entrySet());
/* 218 */     beans.sort((o1, o2) -> AnnotationAwareOrderComparator.INSTANCE.compare(o1.getValue(), o2.getValue()));
/* 219 */     return beans;
/*     */   }
/*     */   
/*     */   private void logMappings(MultiValueMap<Class<?>, ServletContextInitializer> initializers) {
/* 223 */     if (logger.isDebugEnabled()) {
/* 224 */       logMappings("filters", initializers, Filter.class, (Class)FilterRegistrationBean.class);
/* 225 */       logMappings("servlets", initializers, Servlet.class, (Class)ServletRegistrationBean.class);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void logMappings(String name, MultiValueMap<Class<?>, ServletContextInitializer> initializers, Class<?> type, Class<? extends RegistrationBean> registrationType) {
/* 231 */     List<ServletContextInitializer> registrations = new ArrayList<>();
/* 232 */     registrations.addAll((Collection<? extends ServletContextInitializer>)initializers.getOrDefault(registrationType, Collections.emptyList()));
/* 233 */     registrations.addAll((Collection<? extends ServletContextInitializer>)initializers.getOrDefault(type, Collections.emptyList()));
/* 234 */     String info = registrations.stream().map(Object::toString).collect(Collectors.joining(", "));
/* 235 */     logger.debug("Mapping " + name + ": " + info);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ServletContextInitializer> iterator() {
/* 240 */     return this.sortedList.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 245 */     return this.sortedList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface RegistrationBeanAdapter<T>
/*     */   {
/*     */     RegistrationBean createRegistrationBean(String param1String, T param1T, int param1Int);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ServletRegistrationBeanAdapter
/*     */     implements RegistrationBeanAdapter<Servlet>
/*     */   {
/*     */     private final MultipartConfigElement multipartConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ServletRegistrationBeanAdapter(MultipartConfigElement multipartConfig) {
/* 269 */       this.multipartConfig = multipartConfig;
/*     */     }
/*     */ 
/*     */     
/*     */     public RegistrationBean createRegistrationBean(String name, Servlet source, int totalNumberOfSourceBeans) {
/* 274 */       String url = (totalNumberOfSourceBeans != 1) ? ("/" + name + "/") : "/";
/* 275 */       if (name.equals("dispatcherServlet")) {
/* 276 */         url = "/";
/*     */       }
/* 278 */       ServletRegistrationBean<Servlet> bean = new ServletRegistrationBean<>(source, new String[] { url });
/* 279 */       bean.setName(name);
/* 280 */       bean.setMultipartConfig(this.multipartConfig);
/* 281 */       return bean;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class FilterRegistrationBeanAdapter
/*     */     implements RegistrationBeanAdapter<Filter>
/*     */   {
/*     */     private FilterRegistrationBeanAdapter() {}
/*     */ 
/*     */     
/*     */     public RegistrationBean createRegistrationBean(String name, Filter source, int totalNumberOfSourceBeans) {
/* 293 */       FilterRegistrationBean<Filter> bean = new FilterRegistrationBean<>(source, (ServletRegistrationBean<?>[])new ServletRegistrationBean[0]);
/* 294 */       bean.setName(name);
/* 295 */       return bean;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ServletListenerRegistrationBeanAdapter
/*     */     implements RegistrationBeanAdapter<EventListener>
/*     */   {
/*     */     private ServletListenerRegistrationBeanAdapter() {}
/*     */ 
/*     */     
/*     */     public RegistrationBean createRegistrationBean(String name, EventListener source, int totalNumberOfSourceBeans) {
/* 308 */       return new ServletListenerRegistrationBean<>(source);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\ServletContextInitializerBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.servlet.filter;
/*    */ 
/*    */ import org.springframework.web.filter.RequestContextFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderedRequestContextFilter
/*    */   extends RequestContextFilter
/*    */   implements OrderedFilter
/*    */ {
/* 31 */   private int order = -105;
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 35 */     return this.order;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOrder(int order) {
/* 43 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\filter\OrderedRequestContextFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
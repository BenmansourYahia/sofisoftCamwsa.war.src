/*     */ package org.springframework.boot.web.servlet.server;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.SessionCookieConfig;
/*     */ import javax.servlet.SessionTrackingMode;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.web.server.AbstractConfigurableWebServerFactory;
/*     */ import org.springframework.boot.web.server.MimeMappings;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractServletWebServerFactory
/*     */   extends AbstractConfigurableWebServerFactory
/*     */   implements ConfigurableServletWebServerFactory
/*     */ {
/*  60 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  62 */   private String contextPath = "";
/*     */   
/*     */   private String displayName;
/*     */   
/*  66 */   private Session session = new Session();
/*     */   
/*     */   private boolean registerDefaultServlet = true;
/*     */   
/*  70 */   private MimeMappings mimeMappings = new MimeMappings(MimeMappings.DEFAULT);
/*     */   
/*  72 */   private List<ServletContextInitializer> initializers = new ArrayList<>();
/*     */   
/*  74 */   private Jsp jsp = new Jsp();
/*     */   
/*  76 */   private Map<Locale, Charset> localeCharsetMappings = new HashMap<>();
/*     */   
/*  78 */   private Map<String, String> initParameters = Collections.emptyMap();
/*     */   
/*  80 */   private final DocumentRoot documentRoot = new DocumentRoot(this.logger);
/*     */   
/*  82 */   private final StaticResourceJars staticResourceJars = new StaticResourceJars();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractServletWebServerFactory(int port) {
/*  96 */     super(port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractServletWebServerFactory(String contextPath, int port) {
/* 106 */     super(port);
/* 107 */     checkContextPath(contextPath);
/* 108 */     this.contextPath = contextPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextPath() {
/* 117 */     return this.contextPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContextPath(String contextPath) {
/* 122 */     checkContextPath(contextPath);
/* 123 */     this.contextPath = contextPath;
/*     */   }
/*     */   
/*     */   private void checkContextPath(String contextPath) {
/* 127 */     Assert.notNull(contextPath, "ContextPath must not be null");
/* 128 */     if (!contextPath.isEmpty()) {
/* 129 */       if ("/".equals(contextPath)) {
/* 130 */         throw new IllegalArgumentException("Root ContextPath must be specified using an empty string");
/*     */       }
/* 132 */       if (!contextPath.startsWith("/") || contextPath.endsWith("/")) {
/* 133 */         throw new IllegalArgumentException("ContextPath must start with '/' and not end with '/'");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getDisplayName() {
/* 139 */     return this.displayName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDisplayName(String displayName) {
/* 144 */     this.displayName = displayName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRegisterDefaultServlet() {
/* 152 */     return this.registerDefaultServlet;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRegisterDefaultServlet(boolean registerDefaultServlet) {
/* 157 */     this.registerDefaultServlet = registerDefaultServlet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeMappings getMimeMappings() {
/* 165 */     return this.mimeMappings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMimeMappings(MimeMappings mimeMappings) {
/* 170 */     this.mimeMappings = new MimeMappings(mimeMappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getDocumentRoot() {
/* 179 */     return this.documentRoot.getDirectory();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDocumentRoot(File documentRoot) {
/* 184 */     this.documentRoot.setDirectory(documentRoot);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInitializers(List<? extends ServletContextInitializer> initializers) {
/* 189 */     Assert.notNull(initializers, "Initializers must not be null");
/* 190 */     this.initializers = new ArrayList<>(initializers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInitializers(ServletContextInitializer... initializers) {
/* 195 */     Assert.notNull(initializers, "Initializers must not be null");
/* 196 */     this.initializers.addAll(Arrays.asList(initializers));
/*     */   }
/*     */   
/*     */   public Jsp getJsp() {
/* 200 */     return this.jsp;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJsp(Jsp jsp) {
/* 205 */     this.jsp = jsp;
/*     */   }
/*     */   
/*     */   public Session getSession() {
/* 209 */     return this.session;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSession(Session session) {
/* 214 */     this.session = session;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Locale, Charset> getLocaleCharsetMappings() {
/* 222 */     return this.localeCharsetMappings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocaleCharsetMappings(Map<Locale, Charset> localeCharsetMappings) {
/* 227 */     Assert.notNull(localeCharsetMappings, "localeCharsetMappings must not be null");
/* 228 */     this.localeCharsetMappings = localeCharsetMappings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInitParameters(Map<String, String> initParameters) {
/* 233 */     this.initParameters = initParameters;
/*     */   }
/*     */   
/*     */   public Map<String, String> getInitParameters() {
/* 237 */     return this.initParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ServletContextInitializer[] mergeInitializers(ServletContextInitializer... initializers) {
/* 248 */     List<ServletContextInitializer> mergedInitializers = new ArrayList<>();
/* 249 */     mergedInitializers.add(servletContext -> this.initParameters.forEach(servletContext::setInitParameter));
/* 250 */     mergedInitializers.add(new SessionConfiguringInitializer(this.session));
/* 251 */     mergedInitializers.addAll(Arrays.asList(initializers));
/* 252 */     mergedInitializers.addAll(this.initializers);
/* 253 */     return mergedInitializers.<ServletContextInitializer>toArray(new ServletContextInitializer[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldRegisterJspServlet() {
/* 261 */     return (this.jsp != null && this.jsp.getRegistered() && 
/* 262 */       ClassUtils.isPresent(this.jsp.getClassName(), getClass().getClassLoader()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final File getValidDocumentRoot() {
/* 271 */     return this.documentRoot.getValidDirectory();
/*     */   }
/*     */   
/*     */   protected final List<URL> getUrlsOfJarsWithMetaInfResources() {
/* 275 */     return this.staticResourceJars.getUrls();
/*     */   }
/*     */   
/*     */   protected final File getValidSessionStoreDir() {
/* 279 */     return getValidSessionStoreDir(true);
/*     */   }
/*     */   
/*     */   protected final File getValidSessionStoreDir(boolean mkdirs) {
/* 283 */     return this.session.getSessionStoreDirectory().getValidDirectory(mkdirs);
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractServletWebServerFactory() {}
/*     */   
/*     */   private static class SessionConfiguringInitializer
/*     */     implements ServletContextInitializer
/*     */   {
/*     */     private final Session session;
/*     */     
/*     */     SessionConfiguringInitializer(Session session) {
/* 295 */       this.session = session;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStartup(ServletContext servletContext) throws ServletException {
/* 300 */       if (this.session.getTrackingModes() != null) {
/* 301 */         servletContext.setSessionTrackingModes(unwrap(this.session.getTrackingModes()));
/*     */       }
/* 303 */       configureSessionCookie(servletContext.getSessionCookieConfig());
/*     */     }
/*     */     
/*     */     private void configureSessionCookie(SessionCookieConfig config) {
/* 307 */       Session.Cookie cookie = this.session.getCookie();
/* 308 */       if (cookie.getName() != null) {
/* 309 */         config.setName(cookie.getName());
/*     */       }
/* 311 */       if (cookie.getDomain() != null) {
/* 312 */         config.setDomain(cookie.getDomain());
/*     */       }
/* 314 */       if (cookie.getPath() != null) {
/* 315 */         config.setPath(cookie.getPath());
/*     */       }
/* 317 */       if (cookie.getComment() != null) {
/* 318 */         config.setComment(cookie.getComment());
/*     */       }
/* 320 */       if (cookie.getHttpOnly() != null) {
/* 321 */         config.setHttpOnly(cookie.getHttpOnly().booleanValue());
/*     */       }
/* 323 */       if (cookie.getSecure() != null) {
/* 324 */         config.setSecure(cookie.getSecure().booleanValue());
/*     */       }
/* 326 */       if (cookie.getMaxAge() != null) {
/* 327 */         config.setMaxAge((int)cookie.getMaxAge().getSeconds());
/*     */       }
/*     */     }
/*     */     
/*     */     private Set<SessionTrackingMode> unwrap(Set<Session.SessionTrackingMode> modes) {
/* 332 */       if (modes == null) {
/* 333 */         return null;
/*     */       }
/* 335 */       Set<SessionTrackingMode> result = new LinkedHashSet<>();
/* 336 */       for (Session.SessionTrackingMode mode : modes) {
/* 337 */         result.add(SessionTrackingMode.valueOf(mode.name()));
/*     */       }
/* 339 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\server\AbstractServletWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.servlet.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.web.server.ErrorPage;
/*     */ import org.springframework.boot.web.server.ErrorPageRegistry;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483647)
/*     */ public class ErrorPageFilter
/*     */   implements Filter, ErrorPageRegistry
/*     */ {
/*  68 */   private static final Log logger = LogFactory.getLog(ErrorPageFilter.class);
/*     */ 
/*     */   
/*     */   private static final String ERROR_EXCEPTION = "javax.servlet.error.exception";
/*     */   
/*     */   private static final String ERROR_EXCEPTION_TYPE = "javax.servlet.error.exception_type";
/*     */   
/*     */   private static final String ERROR_MESSAGE = "javax.servlet.error.message";
/*     */   
/*     */   public static final String ERROR_REQUEST_URI = "javax.servlet.error.request_uri";
/*     */   
/*     */   private static final String ERROR_STATUS_CODE = "javax.servlet.error.status_code";
/*     */   
/*     */   private static final Set<Class<?>> CLIENT_ABORT_EXCEPTIONS;
/*     */   
/*     */   private String global;
/*     */ 
/*     */   
/*     */   static {
/*  87 */     Set<Class<?>> clientAbortExceptions = new HashSet<>();
/*  88 */     addClassIfPresent(clientAbortExceptions, "org.apache.catalina.connector.ClientAbortException");
/*  89 */     CLIENT_ABORT_EXCEPTIONS = Collections.unmodifiableSet(clientAbortExceptions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  94 */   private final Map<Integer, String> statuses = new HashMap<>();
/*     */   
/*  96 */   private final Map<Class<?>, String> exceptions = new HashMap<>();
/*     */   
/*  98 */   private final OncePerRequestFilter delegate = new OncePerRequestFilter()
/*     */     {
/*     */       
/*     */       protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException
/*     */       {
/* 103 */         ErrorPageFilter.this.doFilter(request, response, chain);
/*     */       }
/*     */ 
/*     */       
/*     */       protected boolean shouldNotFilterAsyncDispatch() {
/* 108 */         return false;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/* 115 */     this.delegate.init(filterConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 121 */     this.delegate.doFilter(request, response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 126 */     ErrorWrapperResponse wrapped = new ErrorWrapperResponse(response);
/*     */     try {
/* 128 */       chain.doFilter((ServletRequest)request, (ServletResponse)wrapped);
/* 129 */       if (wrapped.hasErrorToSend()) {
/* 130 */         handleErrorStatus(request, response, wrapped.getStatus(), wrapped.getMessage());
/* 131 */         response.flushBuffer();
/*     */       }
/* 133 */       else if (!request.isAsyncStarted() && !response.isCommitted()) {
/* 134 */         response.flushBuffer();
/*     */       }
/*     */     
/* 137 */     } catch (Throwable ex) {
/* 138 */       Throwable exceptionToHandle = ex;
/* 139 */       if (ex instanceof NestedServletException) {
/* 140 */         exceptionToHandle = ((NestedServletException)ex).getRootCause();
/*     */       }
/* 142 */       handleException(request, response, wrapped, exceptionToHandle);
/* 143 */       response.flushBuffer();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleErrorStatus(HttpServletRequest request, HttpServletResponse response, int status, String message) throws ServletException, IOException {
/* 149 */     if (response.isCommitted()) {
/* 150 */       handleCommittedResponse(request, null);
/*     */       return;
/*     */     } 
/* 153 */     String errorPath = getErrorPath(this.statuses, Integer.valueOf(status));
/* 154 */     if (errorPath == null) {
/* 155 */       response.sendError(status, message);
/*     */       return;
/*     */     } 
/* 158 */     response.setStatus(status);
/* 159 */     setErrorAttributes(request, status, message);
/* 160 */     request.getRequestDispatcher(errorPath).forward((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleException(HttpServletRequest request, HttpServletResponse response, ErrorWrapperResponse wrapped, Throwable ex) throws IOException, ServletException {
/* 165 */     Class<?> type = ex.getClass();
/* 166 */     String errorPath = getErrorPath(type);
/* 167 */     if (errorPath == null) {
/* 168 */       rethrow(ex);
/*     */       return;
/*     */     } 
/* 171 */     if (response.isCommitted()) {
/* 172 */       handleCommittedResponse(request, ex);
/*     */       return;
/*     */     } 
/* 175 */     forwardToErrorPage(errorPath, request, (HttpServletResponse)wrapped, ex);
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardToErrorPage(String path, HttpServletRequest request, HttpServletResponse response, Throwable ex) throws ServletException, IOException {
/* 180 */     if (logger.isErrorEnabled()) {
/*     */       
/* 182 */       String message = "Forwarding to error page from request " + getDescription(request) + " due to exception [" + ex.getMessage() + "]";
/* 183 */       logger.error(message, ex);
/*     */     } 
/* 185 */     setErrorAttributes(request, 500, ex.getMessage());
/* 186 */     request.setAttribute("javax.servlet.error.exception", ex);
/* 187 */     request.setAttribute("javax.servlet.error.exception_type", ex.getClass());
/* 188 */     response.reset();
/* 189 */     response.setStatus(500);
/* 190 */     request.getRequestDispatcher(path).forward((ServletRequest)request, (ServletResponse)response);
/* 191 */     request.removeAttribute("javax.servlet.error.exception");
/* 192 */     request.removeAttribute("javax.servlet.error.exception_type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDescription(HttpServletRequest request) {
/* 203 */     String pathInfo = (request.getPathInfo() != null) ? request.getPathInfo() : "";
/* 204 */     return "[" + request.getServletPath() + pathInfo + "]";
/*     */   }
/*     */   
/*     */   private void handleCommittedResponse(HttpServletRequest request, Throwable ex) {
/* 208 */     if (isClientAbortException(ex)) {
/*     */       return;
/*     */     }
/* 211 */     String message = "Cannot forward to error page for request " + getDescription(request) + " as the response has already been committed. As a result, the response may have the wrong status code. If your application is running on WebSphere Application Server you may be able to resolve this problem by setting com.ibm.ws.webcontainer.invokeFlushAfterService to false";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     if (ex == null) {
/* 218 */       logger.error(message);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 223 */       logger.error(message, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isClientAbortException(Throwable ex) {
/* 228 */     if (ex == null) {
/* 229 */       return false;
/*     */     }
/* 231 */     for (Class<?> candidate : CLIENT_ABORT_EXCEPTIONS) {
/* 232 */       if (candidate.isInstance(ex)) {
/* 233 */         return true;
/*     */       }
/*     */     } 
/* 236 */     return isClientAbortException(ex.getCause());
/*     */   }
/*     */   
/*     */   private String getErrorPath(Map<Integer, String> map, Integer status) {
/* 240 */     if (map.containsKey(status)) {
/* 241 */       return map.get(status);
/*     */     }
/* 243 */     return this.global;
/*     */   }
/*     */   
/*     */   private String getErrorPath(Class<?> type) {
/* 247 */     while (type != Object.class) {
/* 248 */       String path = this.exceptions.get(type);
/* 249 */       if (path != null) {
/* 250 */         return path;
/*     */       }
/* 252 */       type = type.getSuperclass();
/*     */     } 
/* 254 */     return this.global;
/*     */   }
/*     */   
/*     */   private void setErrorAttributes(HttpServletRequest request, int status, String message) {
/* 258 */     request.setAttribute("javax.servlet.error.status_code", Integer.valueOf(status));
/* 259 */     request.setAttribute("javax.servlet.error.message", message);
/* 260 */     request.setAttribute("javax.servlet.error.request_uri", request.getRequestURI());
/*     */   }
/*     */   
/*     */   private void rethrow(Throwable ex) throws IOException, ServletException {
/* 264 */     if (ex instanceof RuntimeException) {
/* 265 */       throw (RuntimeException)ex;
/*     */     }
/* 267 */     if (ex instanceof Error) {
/* 268 */       throw (Error)ex;
/*     */     }
/* 270 */     if (ex instanceof IOException) {
/* 271 */       throw (IOException)ex;
/*     */     }
/* 273 */     if (ex instanceof ServletException) {
/* 274 */       throw (ServletException)ex;
/*     */     }
/* 276 */     throw new IllegalStateException(ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addErrorPages(ErrorPage... errorPages) {
/* 281 */     for (ErrorPage errorPage : errorPages) {
/* 282 */       if (errorPage.isGlobal()) {
/* 283 */         this.global = errorPage.getPath();
/*     */       }
/* 285 */       else if (errorPage.getStatus() != null) {
/* 286 */         this.statuses.put(Integer.valueOf(errorPage.getStatus().value()), errorPage.getPath());
/*     */       } else {
/*     */         
/* 289 */         this.exceptions.put(errorPage.getException(), errorPage.getPath());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */   
/*     */   private static void addClassIfPresent(Collection<Class<?>> collection, String className) {
/*     */     try {
/* 300 */       collection.add(ClassUtils.forName(className, null));
/*     */     }
/* 302 */     catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ErrorWrapperResponse
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private int status;
/*     */     
/*     */     private String message;
/*     */     private boolean hasErrorToSend = false;
/*     */     
/*     */     ErrorWrapperResponse(HttpServletResponse response) {
/* 315 */       super(response);
/*     */     }
/*     */ 
/*     */     
/*     */     public void sendError(int status) throws IOException {
/* 320 */       sendError(status, (String)null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void sendError(int status, String message) throws IOException {
/* 325 */       this.status = status;
/* 326 */       this.message = message;
/* 327 */       this.hasErrorToSend = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getStatus() {
/* 334 */       if (this.hasErrorToSend) {
/* 335 */         return this.status;
/*     */       }
/*     */       
/* 338 */       return super.getStatus();
/*     */     }
/*     */ 
/*     */     
/*     */     public void flushBuffer() throws IOException {
/* 343 */       sendErrorIfNecessary();
/* 344 */       super.flushBuffer();
/*     */     }
/*     */     
/*     */     private void sendErrorIfNecessary() throws IOException {
/* 348 */       if (this.hasErrorToSend && !isCommitted()) {
/* 349 */         ((HttpServletResponse)getResponse()).sendError(this.status, this.message);
/*     */       }
/*     */     }
/*     */     
/*     */     String getMessage() {
/* 354 */       return this.message;
/*     */     }
/*     */     
/*     */     boolean hasErrorToSend() {
/* 358 */       return this.hasErrorToSend;
/*     */     }
/*     */ 
/*     */     
/*     */     public PrintWriter getWriter() throws IOException {
/* 363 */       sendErrorIfNecessary();
/* 364 */       return super.getWriter();
/*     */     }
/*     */ 
/*     */     
/*     */     public ServletOutputStream getOutputStream() throws IOException {
/* 369 */       sendErrorIfNecessary();
/* 370 */       return super.getOutputStream();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\support\ErrorPageFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot.web.servlet.server;

import java.io.File;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.MimeMappings;
import org.springframework.boot.web.servlet.ServletContextInitializer;

public interface ConfigurableServletWebServerFactory extends ConfigurableWebServerFactory, ServletWebServerFactory {
  void setContextPath(String paramString);
  
  void setDisplayName(String paramString);
  
  void setSession(Session paramSession);
  
  void setRegisterDefaultServlet(boolean paramBoolean);
  
  void setMimeMappings(MimeMappings paramMimeMappings);
  
  void setDocumentRoot(File paramFile);
  
  void setInitializers(List<? extends ServletContextInitializer> paramList);
  
  void addInitializers(ServletContextInitializer... paramVarArgs);
  
  void setJsp(Jsp paramJsp);
  
  void setLocaleCharsetMappings(Map<Locale, Charset> paramMap);
  
  void setInitParameters(Map<String, String> paramMap);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\server\ConfigurableServletWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
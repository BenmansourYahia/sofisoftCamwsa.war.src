/*     */ package org.springframework.boot.web.servlet.context;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.AnnotationConfigRegistry;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationConfigServletWebServerApplicationContext
/*     */   extends ServletWebServerApplicationContext
/*     */   implements AnnotationConfigRegistry
/*     */ {
/*     */   private final AnnotatedBeanDefinitionReader reader;
/*     */   private final ClassPathBeanDefinitionScanner scanner;
/*  63 */   private final Set<Class<?>> annotatedClasses = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] basePackages;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebServerApplicationContext() {
/*  73 */     this.reader = new AnnotatedBeanDefinitionReader((BeanDefinitionRegistry)this);
/*  74 */     this.scanner = new ClassPathBeanDefinitionScanner((BeanDefinitionRegistry)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebServerApplicationContext(DefaultListableBeanFactory beanFactory) {
/*  84 */     super(beanFactory);
/*  85 */     this.reader = new AnnotatedBeanDefinitionReader((BeanDefinitionRegistry)this);
/*  86 */     this.scanner = new ClassPathBeanDefinitionScanner((BeanDefinitionRegistry)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebServerApplicationContext(Class<?>... annotatedClasses) {
/*  97 */     this();
/*  98 */     register(annotatedClasses);
/*  99 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationConfigServletWebServerApplicationContext(String... basePackages) {
/* 109 */     this();
/* 110 */     scan(basePackages);
/* 111 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(ConfigurableEnvironment environment) {
/* 122 */     super.setEnvironment(environment);
/* 123 */     this.reader.setEnvironment((Environment)environment);
/* 124 */     this.scanner.setEnvironment((Environment)environment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator) {
/* 142 */     this.reader.setBeanNameGenerator(beanNameGenerator);
/* 143 */     this.scanner.setBeanNameGenerator(beanNameGenerator);
/* 144 */     getBeanFactory().registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver) {
/* 158 */     this.reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 159 */     this.scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void register(Class<?>... annotatedClasses) {
/* 176 */     Assert.notEmpty((Object[])annotatedClasses, "At least one annotated class must be specified");
/* 177 */     this.annotatedClasses.addAll(Arrays.asList(annotatedClasses));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void scan(String... basePackages) {
/* 189 */     Assert.notEmpty((Object[])basePackages, "At least one base package must be specified");
/* 190 */     this.basePackages = basePackages;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void prepareRefresh() {
/* 195 */     this.scanner.clearCache();
/* 196 */     super.prepareRefresh();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/* 201 */     super.postProcessBeanFactory(beanFactory);
/* 202 */     if (this.basePackages != null && this.basePackages.length > 0) {
/* 203 */       this.scanner.scan(this.basePackages);
/*     */     }
/* 205 */     if (!this.annotatedClasses.isEmpty())
/* 206 */       this.reader.register(ClassUtils.toClassArray(this.annotatedClasses)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\servlet\context\AnnotationConfigServletWebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Handlers;
/*     */ import io.undertow.Undertow;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.handlers.ProxyPeerAddressHandler;
/*     */ import io.undertow.server.handlers.SetHeaderHandler;
/*     */ import io.undertow.servlet.api.DeploymentManager;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.BindException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.web.server.Compression;
/*     */ import org.springframework.boot.web.server.PortInUseException;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xnio.channels.BoundChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowServletWebServer
/*     */   implements WebServer
/*     */ {
/*  59 */   private static final Log logger = LogFactory.getLog(UndertowServletWebServer.class);
/*     */   
/*  61 */   private final Object monitor = new Object();
/*     */ 
/*     */   
/*     */   private final Undertow.Builder builder;
/*     */ 
/*     */   
/*     */   private final DeploymentManager manager;
/*     */ 
/*     */   
/*     */   private final String contextPath;
/*     */ 
/*     */   
/*     */   private final boolean useForwardHeaders;
/*     */ 
/*     */   
/*     */   private final boolean autoStart;
/*     */ 
/*     */   
/*     */   private final Compression compression;
/*     */ 
/*     */   
/*     */   private final String serverHeader;
/*     */ 
/*     */   
/*     */   private Undertow undertow;
/*     */   
/*     */   private volatile boolean started = false;
/*     */ 
/*     */   
/*     */   public UndertowServletWebServer(Undertow.Builder builder, DeploymentManager manager, String contextPath, boolean autoStart, Compression compression) {
/*  91 */     this(builder, manager, contextPath, false, autoStart, compression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UndertowServletWebServer(Undertow.Builder builder, DeploymentManager manager, String contextPath, boolean useForwardHeaders, boolean autoStart, Compression compression) {
/* 105 */     this(builder, manager, contextPath, useForwardHeaders, autoStart, compression, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UndertowServletWebServer(Undertow.Builder builder, DeploymentManager manager, String contextPath, boolean useForwardHeaders, boolean autoStart, Compression compression, String serverHeader) {
/* 120 */     this.builder = builder;
/* 121 */     this.manager = manager;
/* 122 */     this.contextPath = contextPath;
/* 123 */     this.useForwardHeaders = useForwardHeaders;
/* 124 */     this.autoStart = autoStart;
/* 125 */     this.compression = compression;
/* 126 */     this.serverHeader = serverHeader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() throws WebServerException {
/* 131 */     synchronized (this.monitor) {
/* 132 */       if (this.started) {
/*     */         return;
/*     */       }
/*     */       try {
/* 136 */         if (!this.autoStart) {
/*     */           return;
/*     */         }
/* 139 */         if (this.undertow == null) {
/* 140 */           this.undertow = createUndertowServer();
/*     */         }
/* 142 */         this.undertow.start();
/* 143 */         this.started = true;
/* 144 */         logger.info("Undertow started on port(s) " + getPortsDescription() + " with context path '" + this.contextPath + "'");
/*     */       
/*     */       }
/* 147 */       catch (Exception ex) {
/*     */         try {
/* 149 */           if (findBindException(ex) != null) {
/* 150 */             List<Port> failedPorts = getConfiguredPorts();
/* 151 */             List<Port> actualPorts = getActualPorts();
/* 152 */             failedPorts.removeAll(actualPorts);
/* 153 */             if (failedPorts.size() == 1) {
/* 154 */               throw new PortInUseException(((Port)failedPorts.iterator().next()).getNumber());
/*     */             }
/*     */           } 
/* 157 */           throw new WebServerException("Unable to start embedded Undertow", ex);
/*     */         } finally {
/*     */           
/* 160 */           stopSilently();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public DeploymentManager getDeploymentManager() {
/* 167 */     synchronized (this.monitor) {
/* 168 */       return this.manager;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void stopSilently() {
/*     */     try {
/* 174 */       if (this.undertow != null) {
/* 175 */         this.undertow.stop();
/*     */       }
/*     */     }
/* 178 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BindException findBindException(Exception ex) {
/* 184 */     Throwable candidate = ex;
/* 185 */     while (candidate != null) {
/* 186 */       if (candidate instanceof BindException) {
/* 187 */         return (BindException)candidate;
/*     */       }
/* 189 */       candidate = candidate.getCause();
/*     */     } 
/* 191 */     return null;
/*     */   } private Undertow createUndertowServer() throws ServletException {
/*     */     ProxyPeerAddressHandler proxyPeerAddressHandler;
/*     */     SetHeaderHandler setHeaderHandler;
/* 195 */     HttpHandler httpHandler = this.manager.start();
/* 196 */     httpHandler = getContextHandler(httpHandler);
/* 197 */     if (this.useForwardHeaders) {
/* 198 */       proxyPeerAddressHandler = Handlers.proxyPeerAddress(httpHandler);
/*     */     }
/* 200 */     if (StringUtils.hasText(this.serverHeader)) {
/* 201 */       setHeaderHandler = Handlers.header((HttpHandler)proxyPeerAddressHandler, "Server", this.serverHeader);
/*     */     }
/* 203 */     this.builder.setHandler((HttpHandler)setHeaderHandler);
/* 204 */     return this.builder.build();
/*     */   }
/*     */   
/*     */   private HttpHandler getContextHandler(HttpHandler httpHandler) {
/* 208 */     HttpHandler contextHandler = UndertowCompressionConfigurer.configureCompression(this.compression, httpHandler);
/* 209 */     if (StringUtils.isEmpty(this.contextPath)) {
/* 210 */       return contextHandler;
/*     */     }
/* 212 */     return (HttpHandler)Handlers.path().addPrefixPath(this.contextPath, contextHandler);
/*     */   }
/*     */   
/*     */   private String getPortsDescription() {
/* 216 */     List<Port> ports = getActualPorts();
/* 217 */     if (!ports.isEmpty()) {
/* 218 */       return StringUtils.collectionToDelimitedString(ports, " ");
/*     */     }
/* 220 */     return "unknown";
/*     */   }
/*     */   
/*     */   private List<Port> getActualPorts() {
/* 224 */     List<Port> ports = new ArrayList<>();
/*     */     try {
/* 226 */       if (!this.autoStart) {
/* 227 */         ports.add(new Port(-1, "unknown"));
/*     */       } else {
/*     */         
/* 230 */         for (BoundChannel channel : extractChannels()) {
/* 231 */           ports.add(getPortFromChannel(channel));
/*     */         }
/*     */       }
/*     */     
/* 235 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 238 */     return ports;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<BoundChannel> extractChannels() {
/* 243 */     Field channelsField = ReflectionUtils.findField(Undertow.class, "channels");
/* 244 */     ReflectionUtils.makeAccessible(channelsField);
/* 245 */     return (List<BoundChannel>)ReflectionUtils.getField(channelsField, this.undertow);
/*     */   }
/*     */   
/*     */   private Port getPortFromChannel(BoundChannel channel) {
/* 249 */     SocketAddress socketAddress = channel.getLocalAddress();
/* 250 */     if (socketAddress instanceof InetSocketAddress) {
/* 251 */       String protocol = (ReflectionUtils.findField(channel.getClass(), "ssl") != null) ? "https" : "http";
/* 252 */       return new Port(((InetSocketAddress)socketAddress).getPort(), protocol);
/*     */     } 
/* 254 */     return null;
/*     */   }
/*     */   
/*     */   private List<Port> getConfiguredPorts() {
/* 258 */     List<Port> ports = new ArrayList<>();
/* 259 */     for (Object listener : extractListeners()) {
/*     */       try {
/* 261 */         Port port = getPortFromListener(listener);
/* 262 */         if (port.getNumber() != 0) {
/* 263 */           ports.add(port);
/*     */         }
/*     */       }
/* 266 */       catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 270 */     return ports;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Object> extractListeners() {
/* 275 */     Field listenersField = ReflectionUtils.findField(Undertow.class, "listeners");
/* 276 */     ReflectionUtils.makeAccessible(listenersField);
/* 277 */     return (List<Object>)ReflectionUtils.getField(listenersField, this.undertow);
/*     */   }
/*     */   
/*     */   private Port getPortFromListener(Object listener) {
/* 281 */     Field typeField = ReflectionUtils.findField(listener.getClass(), "type");
/* 282 */     ReflectionUtils.makeAccessible(typeField);
/* 283 */     String protocol = ReflectionUtils.getField(typeField, listener).toString();
/* 284 */     Field portField = ReflectionUtils.findField(listener.getClass(), "port");
/* 285 */     ReflectionUtils.makeAccessible(portField);
/* 286 */     int port = ((Integer)ReflectionUtils.getField(portField, listener)).intValue();
/* 287 */     return new Port(port, protocol);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() throws WebServerException {
/* 292 */     synchronized (this.monitor) {
/* 293 */       if (!this.started) {
/*     */         return;
/*     */       }
/* 296 */       this.started = false;
/*     */       try {
/* 298 */         this.manager.stop();
/* 299 */         this.manager.undeploy();
/* 300 */         this.undertow.stop();
/*     */       }
/* 302 */       catch (Exception ex) {
/* 303 */         throw new WebServerException("Unable to stop undertow", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 310 */     List<Port> ports = getActualPorts();
/* 311 */     if (ports.isEmpty()) {
/* 312 */       return 0;
/*     */     }
/* 314 */     return ((Port)ports.get(0)).getNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Port
/*     */   {
/*     */     private final int number;
/*     */     
/*     */     private final String protocol;
/*     */ 
/*     */     
/*     */     private Port(int number, String protocol) {
/* 327 */       this.number = number;
/* 328 */       this.protocol = protocol;
/*     */     }
/*     */     
/*     */     int getNumber() {
/* 332 */       return this.number;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 337 */       if (this == obj) {
/* 338 */         return true;
/*     */       }
/* 340 */       if (obj == null) {
/* 341 */         return false;
/*     */       }
/* 343 */       if (getClass() != obj.getClass()) {
/* 344 */         return false;
/*     */       }
/* 346 */       Port other = (Port)obj;
/* 347 */       return (this.number == other.number);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 352 */       return this.number;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 357 */       return this.number + " (" + this.protocol + ")";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\UndertowServletWebServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
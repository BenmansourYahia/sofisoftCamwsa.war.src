/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.core.AprLifecycleListener;
/*     */ import org.apache.catalina.loader.WebappLoader;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.apache.coyote.AbstractProtocol;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.coyote.UpgradeProtocol;
/*     */ import org.apache.coyote.http2.Http2Protocol;
/*     */ import org.apache.tomcat.JarScanFilter;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.scan.StandardJarScanFilter;
/*     */ import org.springframework.boot.util.LambdaSafe;
/*     */ import org.springframework.boot.web.reactive.server.AbstractReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.http.server.reactive.HttpHandler;
/*     */ import org.springframework.http.server.reactive.TomcatHttpHandlerAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatReactiveWebServerFactory
/*     */   extends AbstractReactiveWebServerFactory
/*     */   implements ConfigurableTomcatWebServerFactory
/*     */ {
/*  64 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_PROTOCOL = "org.apache.coyote.http11.Http11NioProtocol";
/*     */ 
/*     */   
/*     */   private File baseDirectory;
/*     */ 
/*     */   
/*  73 */   private final List<Valve> engineValves = new ArrayList<>();
/*     */   
/*  75 */   private List<LifecycleListener> contextLifecycleListeners = getDefaultLifecycleListeners();
/*     */   
/*  77 */   private Set<TomcatContextCustomizer> tomcatContextCustomizers = new LinkedHashSet<>();
/*     */   
/*  79 */   private Set<TomcatConnectorCustomizer> tomcatConnectorCustomizers = new LinkedHashSet<>();
/*     */   
/*  81 */   private Set<TomcatProtocolHandlerCustomizer<?>> tomcatProtocolHandlerCustomizers = new LinkedHashSet<>();
/*     */   
/*  83 */   private final List<Connector> additionalTomcatConnectors = new ArrayList<>();
/*     */   
/*  85 */   private String protocol = "org.apache.coyote.http11.Http11NioProtocol";
/*     */   
/*  87 */   private Charset uriEncoding = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int backgroundProcessorDelay;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableMBeanRegistry = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TomcatReactiveWebServerFactory(int port) {
/* 105 */     super(port);
/*     */   }
/*     */   
/*     */   private static List<LifecycleListener> getDefaultLifecycleListeners() {
/* 109 */     AprLifecycleListener aprLifecycleListener = new AprLifecycleListener();
/* 110 */     return AprLifecycleListener.isAprAvailable() ? new ArrayList<>((Collection)Arrays.asList((Object[])new AprLifecycleListener[] { aprLifecycleListener })) : new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServer getWebServer(HttpHandler httpHandler) {
/* 116 */     if (this.disableMBeanRegistry) {
/* 117 */       Registry.disableRegistry();
/*     */     }
/* 119 */     Tomcat tomcat = new Tomcat();
/* 120 */     File baseDir = (this.baseDirectory != null) ? this.baseDirectory : createTempDir("tomcat");
/* 121 */     tomcat.setBaseDir(baseDir.getAbsolutePath());
/* 122 */     Connector connector = new Connector(this.protocol);
/* 123 */     connector.setThrowOnFailure(true);
/* 124 */     tomcat.getService().addConnector(connector);
/* 125 */     customizeConnector(connector);
/* 126 */     tomcat.setConnector(connector);
/* 127 */     tomcat.getHost().setAutoDeploy(false);
/* 128 */     configureEngine(tomcat.getEngine());
/* 129 */     for (Connector additionalConnector : this.additionalTomcatConnectors) {
/* 130 */       tomcat.getService().addConnector(additionalConnector);
/*     */     }
/* 132 */     TomcatHttpHandlerAdapter servlet = new TomcatHttpHandlerAdapter(httpHandler);
/* 133 */     prepareContext(tomcat.getHost(), servlet);
/* 134 */     return new TomcatWebServer(tomcat, (getPort() >= 0));
/*     */   }
/*     */   
/*     */   private void configureEngine(Engine engine) {
/* 138 */     engine.setBackgroundProcessorDelay(this.backgroundProcessorDelay);
/* 139 */     for (Valve valve : this.engineValves) {
/* 140 */       engine.getPipeline().addValve(valve);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void prepareContext(Host host, TomcatHttpHandlerAdapter servlet) {
/* 145 */     File docBase = createTempDir("tomcat-docbase");
/* 146 */     TomcatEmbeddedContext context = new TomcatEmbeddedContext();
/* 147 */     context.setPath("");
/* 148 */     context.setDocBase(docBase.getAbsolutePath());
/* 149 */     context.addLifecycleListener((LifecycleListener)new Tomcat.FixContextListener());
/* 150 */     context.setParentClassLoader(ClassUtils.getDefaultClassLoader());
/* 151 */     skipAllTldScanning(context);
/* 152 */     WebappLoader loader = new WebappLoader(context.getParentClassLoader());
/* 153 */     loader.setLoaderClass(TomcatEmbeddedWebappClassLoader.class.getName());
/* 154 */     loader.setDelegate(true);
/* 155 */     context.setLoader((Loader)loader);
/* 156 */     Tomcat.addServlet((Context)context, "httpHandlerServlet", (Servlet)servlet).setAsyncSupported(true);
/* 157 */     context.addServletMappingDecoded("/", "httpHandlerServlet");
/* 158 */     host.addChild((Container)context);
/* 159 */     configureContext((Context)context);
/*     */   }
/*     */   
/*     */   private void skipAllTldScanning(TomcatEmbeddedContext context) {
/* 163 */     StandardJarScanFilter filter = new StandardJarScanFilter();
/* 164 */     filter.setTldSkip("*.jar");
/* 165 */     context.getJarScanner().setJarScanFilter((JarScanFilter)filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureContext(Context context) {
/* 173 */     this.contextLifecycleListeners.forEach(context::addLifecycleListener);
/* 174 */     (new DisableReferenceClearingContextCustomizer()).customize(context);
/* 175 */     this.tomcatContextCustomizers.forEach(customizer -> customizer.customize(context));
/*     */   }
/*     */   
/*     */   protected void customizeConnector(Connector connector) {
/* 179 */     int port = Math.max(getPort(), 0);
/* 180 */     connector.setPort(port);
/* 181 */     if (StringUtils.hasText(getServerHeader())) {
/* 182 */       connector.setAttribute("server", getServerHeader());
/*     */     }
/* 184 */     if (connector.getProtocolHandler() instanceof AbstractProtocol) {
/* 185 */       customizeProtocol((AbstractProtocol)connector.getProtocolHandler());
/*     */     }
/* 187 */     invokeProtocolHandlerCustomizers(connector.getProtocolHandler());
/* 188 */     if (getUriEncoding() != null) {
/* 189 */       connector.setURIEncoding(getUriEncoding().name());
/*     */     }
/*     */     
/* 192 */     connector.setProperty("bindOnInit", "false");
/* 193 */     if (getSsl() != null && getSsl().isEnabled()) {
/* 194 */       customizeSsl(connector);
/*     */     }
/* 196 */     TomcatConnectorCustomizer compression = new CompressionConnectorCustomizer(getCompression());
/* 197 */     compression.customize(connector);
/* 198 */     for (TomcatConnectorCustomizer customizer : this.tomcatConnectorCustomizers) {
/* 199 */       customizer.customize(connector);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void invokeProtocolHandlerCustomizers(ProtocolHandler protocolHandler) {
/* 205 */     LambdaSafe.callbacks(TomcatProtocolHandlerCustomizer.class, this.tomcatProtocolHandlerCustomizers, protocolHandler, new Object[0])
/* 206 */       .invoke(customizer -> customizer.customize(protocolHandler));
/*     */   }
/*     */   
/*     */   private void customizeProtocol(AbstractProtocol<?> protocol) {
/* 210 */     if (getAddress() != null) {
/* 211 */       protocol.setAddress(getAddress());
/*     */     }
/*     */   }
/*     */   
/*     */   private void customizeSsl(Connector connector) {
/* 216 */     (new SslConnectorCustomizer(getSsl(), getSslStoreProvider())).customize(connector);
/* 217 */     if (getHttp2() != null && getHttp2().isEnabled()) {
/* 218 */       connector.addUpgradeProtocol((UpgradeProtocol)new Http2Protocol());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBaseDirectory(File baseDirectory) {
/* 224 */     this.baseDirectory = baseDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBackgroundProcessorDelay(int delay) {
/* 229 */     this.backgroundProcessorDelay = delay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTomcatContextCustomizers(Collection<? extends TomcatContextCustomizer> tomcatContextCustomizers) {
/* 238 */     Assert.notNull(tomcatContextCustomizers, "TomcatContextCustomizers must not be null");
/* 239 */     this.tomcatContextCustomizers = new LinkedHashSet<>(tomcatContextCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TomcatContextCustomizer> getTomcatContextCustomizers() {
/* 248 */     return this.tomcatContextCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContextCustomizers(TomcatContextCustomizer... tomcatContextCustomizers) {
/* 258 */     Assert.notNull(tomcatContextCustomizers, "TomcatContextCustomizers must not be null");
/* 259 */     this.tomcatContextCustomizers.addAll(Arrays.asList(tomcatContextCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTomcatConnectorCustomizers(Collection<? extends TomcatConnectorCustomizer> tomcatConnectorCustomizers) {
/* 269 */     Assert.notNull(tomcatConnectorCustomizers, "TomcatConnectorCustomizers must not be null");
/* 270 */     this.tomcatConnectorCustomizers = new LinkedHashSet<>(tomcatConnectorCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConnectorCustomizers(TomcatConnectorCustomizer... tomcatConnectorCustomizers) {
/* 280 */     Assert.notNull(tomcatConnectorCustomizers, "TomcatConnectorCustomizers must not be null");
/* 281 */     this.tomcatConnectorCustomizers.addAll(Arrays.asList(tomcatConnectorCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TomcatConnectorCustomizer> getTomcatConnectorCustomizers() {
/* 290 */     return this.tomcatConnectorCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTomcatProtocolHandlerCustomizers(Collection<? extends TomcatProtocolHandlerCustomizer<?>> tomcatProtocolHandlerCustomizers) {
/* 301 */     Assert.notNull(tomcatProtocolHandlerCustomizers, "TomcatProtocolHandlerCustomizers must not be null");
/* 302 */     this.tomcatProtocolHandlerCustomizers = new LinkedHashSet<>(tomcatProtocolHandlerCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addProtocolHandlerCustomizers(TomcatProtocolHandlerCustomizer<?>... tomcatProtocolHandlerCustomizers) {
/* 313 */     Assert.notNull(tomcatProtocolHandlerCustomizers, "TomcatProtocolHandlerCustomizers must not be null");
/* 314 */     this.tomcatProtocolHandlerCustomizers.addAll(Arrays.asList(tomcatProtocolHandlerCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TomcatProtocolHandlerCustomizer<?>> getTomcatProtocolHandlerCustomizers() {
/* 324 */     return this.tomcatProtocolHandlerCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAdditionalTomcatConnectors(Connector... connectors) {
/* 333 */     Assert.notNull(connectors, "Connectors must not be null");
/* 334 */     this.additionalTomcatConnectors.addAll(Arrays.asList(connectors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Connector> getAdditionalTomcatConnectors() {
/* 344 */     return this.additionalTomcatConnectors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addEngineValves(Valve... engineValves) {
/* 349 */     Assert.notNull(engineValves, "Valves must not be null");
/* 350 */     this.engineValves.addAll(Arrays.asList(engineValves));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Valve> getEngineValves() {
/* 359 */     return this.engineValves;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUriEncoding(Charset uriEncoding) {
/* 369 */     this.uriEncoding = uriEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getUriEncoding() {
/* 377 */     return this.uriEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextLifecycleListeners(Collection<? extends LifecycleListener> contextLifecycleListeners) {
/* 386 */     Assert.notNull(contextLifecycleListeners, "ContextLifecycleListeners must not be null");
/* 387 */     this.contextLifecycleListeners = new ArrayList<>(contextLifecycleListeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<LifecycleListener> getContextLifecycleListeners() {
/* 396 */     return this.contextLifecycleListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContextLifecycleListeners(LifecycleListener... contextLifecycleListeners) {
/* 404 */     Assert.notNull(contextLifecycleListeners, "ContextLifecycleListeners must not be null");
/* 405 */     this.contextLifecycleListeners.addAll(Arrays.asList(contextLifecycleListeners));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
/* 416 */     return new TomcatWebServer(tomcat, (getPort() >= 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProtocol(String protocol) {
/* 425 */     Assert.hasLength(protocol, "Protocol must not be empty");
/* 426 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisableMBeanRegistry(boolean disableMBeanRegistry) {
/* 436 */     this.disableMBeanRegistry = disableMBeanRegistry;
/*     */   }
/*     */   
/*     */   public TomcatReactiveWebServerFactory() {}
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\TomcatReactiveWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
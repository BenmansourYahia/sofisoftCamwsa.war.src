/*     */ package org.springframework.boot.web.embedded.netty;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.web.reactive.server.AbstractReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.http.client.reactive.ReactorResourceFactory;
/*     */ import org.springframework.http.server.reactive.HttpHandler;
/*     */ import org.springframework.http.server.reactive.ReactorHttpHandlerAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.netty.http.HttpProtocol;
/*     */ import reactor.netty.http.server.HttpServer;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.tcp.TcpServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NettyReactiveWebServerFactory
/*     */   extends AbstractReactiveWebServerFactory
/*     */ {
/*  48 */   private Set<NettyServerCustomizer> serverCustomizers = new LinkedHashSet<>();
/*     */   
/*  50 */   private List<NettyRouteProvider> routeProviders = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private Duration lifecycleTimeout;
/*     */ 
/*     */   
/*     */   private boolean useForwardHeaders;
/*     */   
/*     */   private ReactorResourceFactory resourceFactory;
/*     */ 
/*     */   
/*     */   public NettyReactiveWebServerFactory(int port) {
/*  62 */     super(port);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebServer getWebServer(HttpHandler httpHandler) {
/*  67 */     HttpServer httpServer = createHttpServer();
/*  68 */     ReactorHttpHandlerAdapter handlerAdapter = new ReactorHttpHandlerAdapter(httpHandler);
/*  69 */     NettyWebServer webServer = new NettyWebServer(httpServer, handlerAdapter, this.lifecycleTimeout);
/*  70 */     webServer.setRouteProviders(this.routeProviders);
/*  71 */     return webServer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<NettyServerCustomizer> getServerCustomizers() {
/*  80 */     return this.serverCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerCustomizers(Collection<? extends NettyServerCustomizer> serverCustomizers) {
/*  89 */     Assert.notNull(serverCustomizers, "ServerCustomizers must not be null");
/*  90 */     this.serverCustomizers = new LinkedHashSet<>(serverCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addServerCustomizers(NettyServerCustomizer... serverCustomizers) {
/*  98 */     Assert.notNull(serverCustomizers, "ServerCustomizer must not be null");
/*  99 */     this.serverCustomizers.addAll(Arrays.asList(serverCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRouteProviders(NettyRouteProvider... routeProviders) {
/* 108 */     Assert.notNull(routeProviders, "NettyRouteProvider must not be null");
/* 109 */     this.routeProviders.addAll(Arrays.asList(routeProviders));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLifecycleTimeout(Duration lifecycleTimeout) {
/* 118 */     this.lifecycleTimeout = lifecycleTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders) {
/* 127 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceFactory(ReactorResourceFactory resourceFactory) {
/* 136 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */   
/*     */   private HttpServer createHttpServer() {
/* 140 */     HttpServer server = HttpServer.create();
/* 141 */     if (this.resourceFactory != null) {
/* 142 */       LoopResources resources = this.resourceFactory.getLoopResources();
/* 143 */       Assert.notNull(resources, "No LoopResources: is ReactorResourceFactory not initialized yet?");
/* 144 */       server = server.tcpConfiguration(tcpServer -> tcpServer.runOn(resources).addressSupplier(this::getListenAddress));
/*     */     }
/*     */     else {
/*     */       
/* 148 */       server = server.tcpConfiguration(tcpServer -> tcpServer.addressSupplier(this::getListenAddress));
/*     */     } 
/* 150 */     if (getSsl() != null && getSsl().isEnabled()) {
/*     */       
/* 152 */       SslServerCustomizer sslServerCustomizer = new SslServerCustomizer(getSsl(), getHttp2(), getSslStoreProvider());
/* 153 */       server = sslServerCustomizer.apply(server);
/*     */     } 
/* 155 */     if (getCompression() != null && getCompression().getEnabled()) {
/* 156 */       CompressionCustomizer compressionCustomizer = new CompressionCustomizer(getCompression());
/* 157 */       server = compressionCustomizer.apply(server);
/*     */     } 
/* 159 */     server = server.protocol(listProtocols()).forwarded(this.useForwardHeaders);
/* 160 */     return applyCustomizers(server);
/*     */   }
/*     */   
/*     */   private HttpProtocol[] listProtocols() {
/* 164 */     if (getHttp2() != null && getHttp2().isEnabled() && getSsl() != null && getSsl().isEnabled()) {
/* 165 */       return new HttpProtocol[] { HttpProtocol.H2, HttpProtocol.HTTP11 };
/*     */     }
/* 167 */     return new HttpProtocol[] { HttpProtocol.HTTP11 };
/*     */   }
/*     */   
/*     */   private InetSocketAddress getListenAddress() {
/* 171 */     if (getAddress() != null) {
/* 172 */       return new InetSocketAddress(getAddress().getHostAddress(), getPort());
/*     */     }
/* 174 */     return new InetSocketAddress(getPort());
/*     */   }
/*     */   
/*     */   private HttpServer applyCustomizers(HttpServer server) {
/* 178 */     for (NettyServerCustomizer customizer : this.serverCustomizers) {
/* 179 */       server = customizer.apply(server);
/*     */     }
/* 181 */     return server;
/*     */   }
/*     */   
/*     */   public NettyReactiveWebServerFactory() {}
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\netty\NettyReactiveWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
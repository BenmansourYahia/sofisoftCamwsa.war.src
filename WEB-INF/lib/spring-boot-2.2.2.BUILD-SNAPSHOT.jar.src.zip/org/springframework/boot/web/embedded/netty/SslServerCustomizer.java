/*     */ package org.springframework.boot.web.embedded.netty;
/*     */ 
/*     */ import io.netty.handler.ssl.ClientAuth;
/*     */ import io.netty.handler.ssl.SslContextBuilder;
/*     */ import java.net.URL;
/*     */ import java.security.KeyStore;
/*     */ import java.util.Arrays;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import org.springframework.boot.web.server.Http2;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.boot.web.server.SslStoreProvider;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import reactor.netty.http.server.HttpServer;
/*     */ import reactor.netty.tcp.SslProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SslServerCustomizer
/*     */   implements NettyServerCustomizer
/*     */ {
/*     */   private final Ssl ssl;
/*     */   private final Http2 http2;
/*     */   private final SslStoreProvider sslStoreProvider;
/*     */   
/*     */   public SslServerCustomizer(Ssl ssl, Http2 http2, SslStoreProvider sslStoreProvider) {
/*  54 */     this.ssl = ssl;
/*  55 */     this.http2 = http2;
/*  56 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServer apply(HttpServer server) {
/*     */     try {
/*  62 */       return server.secure(contextSpec -> {
/*     */             SslProvider.DefaultConfigurationSpec spec = contextSpec.sslContext(getContextBuilder());
/*     */             
/*     */             if (this.http2 != null && this.http2.isEnabled()) {
/*     */               spec.defaultConfiguration(SslProvider.DefaultConfigurationType.H2);
/*     */             }
/*     */           });
/*  69 */     } catch (Exception ex) {
/*  70 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected SslContextBuilder getContextBuilder() {
/*  76 */     SslContextBuilder builder = SslContextBuilder.forServer(getKeyManagerFactory(this.ssl, this.sslStoreProvider)).trustManager(getTrustManagerFactory(this.ssl, this.sslStoreProvider));
/*  77 */     if (this.ssl.getEnabledProtocols() != null) {
/*  78 */       builder.protocols(this.ssl.getEnabledProtocols());
/*     */     }
/*  80 */     if (this.ssl.getCiphers() != null) {
/*  81 */       builder.ciphers(Arrays.asList(this.ssl.getCiphers()));
/*     */     }
/*  83 */     if (this.ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/*  84 */       builder.clientAuth(ClientAuth.REQUIRE);
/*     */     }
/*  86 */     else if (this.ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/*  87 */       builder.clientAuth(ClientAuth.OPTIONAL);
/*     */     } 
/*  89 */     return builder;
/*     */   }
/*     */   
/*     */   protected KeyManagerFactory getKeyManagerFactory(Ssl ssl, SslStoreProvider sslStoreProvider) {
/*     */     try {
/*  94 */       KeyStore keyStore = getKeyStore(ssl, sslStoreProvider);
/*     */       
/*  96 */       KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/*  97 */       char[] keyPassword = (ssl.getKeyPassword() != null) ? ssl.getKeyPassword().toCharArray() : null;
/*  98 */       if (keyPassword == null && ssl.getKeyStorePassword() != null) {
/*  99 */         keyPassword = ssl.getKeyStorePassword().toCharArray();
/*     */       }
/* 101 */       keyManagerFactory.init(keyStore, keyPassword);
/* 102 */       return keyManagerFactory;
/*     */     }
/* 104 */     catch (Exception ex) {
/* 105 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private KeyStore getKeyStore(Ssl ssl, SslStoreProvider sslStoreProvider) throws Exception {
/* 110 */     if (sslStoreProvider != null) {
/* 111 */       return sslStoreProvider.getKeyStore();
/*     */     }
/* 113 */     return loadKeyStore(ssl.getKeyStoreType(), ssl.getKeyStoreProvider(), ssl.getKeyStore(), ssl
/* 114 */         .getKeyStorePassword());
/*     */   }
/*     */   
/*     */   protected TrustManagerFactory getTrustManagerFactory(Ssl ssl, SslStoreProvider sslStoreProvider) {
/*     */     try {
/* 119 */       KeyStore store = getTrustStore(ssl, sslStoreProvider);
/*     */       
/* 121 */       TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/* 122 */       trustManagerFactory.init(store);
/* 123 */       return trustManagerFactory;
/*     */     }
/* 125 */     catch (Exception ex) {
/* 126 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private KeyStore getTrustStore(Ssl ssl, SslStoreProvider sslStoreProvider) throws Exception {
/* 131 */     if (sslStoreProvider != null) {
/* 132 */       return sslStoreProvider.getTrustStore();
/*     */     }
/* 134 */     return loadTrustStore(ssl.getTrustStoreType(), ssl.getTrustStoreProvider(), ssl.getTrustStore(), ssl
/* 135 */         .getTrustStorePassword());
/*     */   }
/*     */ 
/*     */   
/*     */   private KeyStore loadKeyStore(String type, String provider, String resource, String password) throws Exception {
/* 140 */     return loadStore(type, provider, resource, password);
/*     */   }
/*     */   
/*     */   private KeyStore loadTrustStore(String type, String provider, String resource, String password) throws Exception {
/* 144 */     if (resource == null) {
/* 145 */       return null;
/*     */     }
/* 147 */     return loadStore(type, provider, resource, password);
/*     */   }
/*     */   
/*     */   private KeyStore loadStore(String type, String provider, String resource, String password) throws Exception {
/* 151 */     type = (type != null) ? type : "JKS";
/* 152 */     KeyStore store = (provider != null) ? KeyStore.getInstance(type, provider) : KeyStore.getInstance(type);
/*     */     try {
/* 154 */       URL url = ResourceUtils.getURL(resource);
/* 155 */       store.load(url.openStream(), (password != null) ? password.toCharArray() : null);
/* 156 */       return store;
/*     */     }
/* 158 */     catch (Exception ex) {
/* 159 */       throw new WebServerException("Could not load key store '" + resource + "'", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\netty\SslServerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.embedded.jetty;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URL;
/*     */ import org.eclipse.jetty.alpn.server.ALPNServerConnectionFactory;
/*     */ import org.eclipse.jetty.http.HttpVersion;
/*     */ import org.eclipse.jetty.http2.HTTP2Cipher;
/*     */ import org.eclipse.jetty.http2.server.HTTP2ServerConnectionFactory;
/*     */ import org.eclipse.jetty.server.ConnectionFactory;
/*     */ import org.eclipse.jetty.server.Connector;
/*     */ import org.eclipse.jetty.server.HttpConfiguration;
/*     */ import org.eclipse.jetty.server.HttpConnectionFactory;
/*     */ import org.eclipse.jetty.server.SecureRequestCustomizer;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.server.ServerConnector;
/*     */ import org.eclipse.jetty.server.SslConnectionFactory;
/*     */ import org.eclipse.jetty.util.resource.Resource;
/*     */ import org.eclipse.jetty.util.ssl.SslContextFactory;
/*     */ import org.springframework.boot.web.server.Http2;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.boot.web.server.SslStoreProvider;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SslServerCustomizer
/*     */   implements JettyServerCustomizer
/*     */ {
/*     */   private final InetSocketAddress address;
/*     */   private final Ssl ssl;
/*     */   private final SslStoreProvider sslStoreProvider;
/*     */   private final Http2 http2;
/*     */   
/*     */   SslServerCustomizer(InetSocketAddress address, Ssl ssl, SslStoreProvider sslStoreProvider, Http2 http2) {
/*  63 */     this.address = address;
/*  64 */     this.ssl = ssl;
/*  65 */     this.sslStoreProvider = sslStoreProvider;
/*  66 */     this.http2 = http2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void customize(Server server) {
/*  71 */     SslContextFactory.Server sslContextFactory = new SslContextFactory.Server();
/*  72 */     sslContextFactory.setEndpointIdentificationAlgorithm(null);
/*  73 */     configureSsl(sslContextFactory, this.ssl, this.sslStoreProvider);
/*  74 */     ServerConnector connector = createConnector(server, sslContextFactory, this.address);
/*  75 */     server.setConnectors(new Connector[] { (Connector)connector });
/*     */   }
/*     */ 
/*     */   
/*     */   private ServerConnector createConnector(Server server, SslContextFactory.Server sslContextFactory, InetSocketAddress address) {
/*  80 */     HttpConfiguration config = new HttpConfiguration();
/*  81 */     config.setSendServerVersion(false);
/*  82 */     config.setSecureScheme("https");
/*  83 */     config.setSecurePort(address.getPort());
/*  84 */     config.addCustomizer((HttpConfiguration.Customizer)new SecureRequestCustomizer());
/*  85 */     ServerConnector connector = createServerConnector(server, sslContextFactory, config);
/*  86 */     connector.setPort(address.getPort());
/*  87 */     connector.setHost(address.getHostString());
/*  88 */     return connector;
/*     */   }
/*     */ 
/*     */   
/*     */   private ServerConnector createServerConnector(Server server, SslContextFactory.Server sslContextFactory, HttpConfiguration config) {
/*  93 */     if (this.http2 == null || !this.http2.isEnabled()) {
/*  94 */       return createHttp11ServerConnector(server, config, sslContextFactory);
/*     */     }
/*  96 */     Assert.state(isAlpnPresent(), () -> "The 'org.eclipse.jetty:jetty-alpn-server' dependency is required for HTTP/2 support.");
/*     */     
/*  98 */     Assert.state(isConscryptPresent(), () -> "The 'org.eclipse.jetty.http2:http2-server' and Conscrypt dependencies are required for HTTP/2 support.");
/*     */     
/* 100 */     return createHttp2ServerConnector(server, config, sslContextFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   private ServerConnector createHttp11ServerConnector(Server server, HttpConfiguration config, SslContextFactory.Server sslContextFactory) {
/* 105 */     HttpConnectionFactory connectionFactory = new HttpConnectionFactory(config);
/*     */     
/* 107 */     SslConnectionFactory sslConnectionFactory = new SslConnectionFactory((SslContextFactory)sslContextFactory, HttpVersion.HTTP_1_1.asString());
/* 108 */     return new ServerConnector(server, new ConnectionFactory[] { (ConnectionFactory)sslConnectionFactory, (ConnectionFactory)connectionFactory });
/*     */   }
/*     */   
/*     */   private boolean isAlpnPresent() {
/* 112 */     return ClassUtils.isPresent("org.eclipse.jetty.http2.server.HTTP2ServerConnectionFactory", null);
/*     */   }
/*     */   
/*     */   private boolean isConscryptPresent() {
/* 116 */     return ClassUtils.isPresent("org.conscrypt.Conscrypt", null);
/*     */   }
/*     */ 
/*     */   
/*     */   private ServerConnector createHttp2ServerConnector(Server server, HttpConfiguration config, SslContextFactory.Server sslContextFactory) {
/* 121 */     HTTP2ServerConnectionFactory h2 = new HTTP2ServerConnectionFactory(config);
/* 122 */     ALPNServerConnectionFactory alpn = new ALPNServerConnectionFactory(new String[0]);
/* 123 */     sslContextFactory.setCipherComparator(HTTP2Cipher.COMPARATOR);
/* 124 */     sslContextFactory.setProvider("Conscrypt");
/* 125 */     SslConnectionFactory ssl = new SslConnectionFactory((SslContextFactory)sslContextFactory, alpn.getProtocol());
/* 126 */     return new ServerConnector(server, new ConnectionFactory[] { (ConnectionFactory)ssl, (ConnectionFactory)alpn, (ConnectionFactory)h2, (ConnectionFactory)new HttpConnectionFactory(config) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureSsl(SslContextFactory.Server factory, Ssl ssl, SslStoreProvider sslStoreProvider) {
/* 136 */     factory.setProtocol(ssl.getProtocol());
/* 137 */     configureSslClientAuth(factory, ssl);
/* 138 */     configureSslPasswords(factory, ssl);
/* 139 */     factory.setCertAlias(ssl.getKeyAlias());
/* 140 */     if (!ObjectUtils.isEmpty((Object[])ssl.getCiphers())) {
/* 141 */       factory.setIncludeCipherSuites(ssl.getCiphers());
/* 142 */       factory.setExcludeCipherSuites(new String[0]);
/*     */     } 
/* 144 */     if (ssl.getEnabledProtocols() != null) {
/* 145 */       factory.setIncludeProtocols(ssl.getEnabledProtocols());
/*     */     }
/* 147 */     if (sslStoreProvider != null) {
/*     */       try {
/* 149 */         factory.setKeyStore(sslStoreProvider.getKeyStore());
/* 150 */         factory.setTrustStore(sslStoreProvider.getTrustStore());
/*     */       }
/* 152 */       catch (Exception ex) {
/* 153 */         throw new IllegalStateException("Unable to set SSL store", ex);
/*     */       } 
/*     */     } else {
/*     */       
/* 157 */       configureSslKeyStore(factory, ssl);
/* 158 */       configureSslTrustStore(factory, ssl);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configureSslClientAuth(SslContextFactory.Server factory, Ssl ssl) {
/* 163 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/* 164 */       factory.setNeedClientAuth(true);
/* 165 */       factory.setWantClientAuth(true);
/*     */     }
/* 167 */     else if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/* 168 */       factory.setWantClientAuth(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configureSslPasswords(SslContextFactory.Server factory, Ssl ssl) {
/* 173 */     if (ssl.getKeyStorePassword() != null) {
/* 174 */       factory.setKeyStorePassword(ssl.getKeyStorePassword());
/*     */     }
/* 176 */     if (ssl.getKeyPassword() != null) {
/* 177 */       factory.setKeyManagerPassword(ssl.getKeyPassword());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslKeyStore(SslContextFactory.Server factory, Ssl ssl) {
/*     */     try {
/* 183 */       URL url = ResourceUtils.getURL(ssl.getKeyStore());
/* 184 */       factory.setKeyStoreResource(Resource.newResource(url));
/*     */     }
/* 186 */     catch (Exception ex) {
/* 187 */       throw new WebServerException("Could not load key store '" + ssl.getKeyStore() + "'", ex);
/*     */     } 
/* 189 */     if (ssl.getKeyStoreType() != null) {
/* 190 */       factory.setKeyStoreType(ssl.getKeyStoreType());
/*     */     }
/* 192 */     if (ssl.getKeyStoreProvider() != null) {
/* 193 */       factory.setKeyStoreProvider(ssl.getKeyStoreProvider());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslTrustStore(SslContextFactory.Server factory, Ssl ssl) {
/* 198 */     if (ssl.getTrustStorePassword() != null) {
/* 199 */       factory.setTrustStorePassword(ssl.getTrustStorePassword());
/*     */     }
/* 201 */     if (ssl.getTrustStore() != null) {
/*     */       try {
/* 203 */         URL url = ResourceUtils.getURL(ssl.getTrustStore());
/* 204 */         factory.setTrustStoreResource(Resource.newResource(url));
/*     */       }
/* 206 */       catch (IOException ex) {
/* 207 */         throw new WebServerException("Could not find trust store '" + ssl.getTrustStore() + "'", ex);
/*     */       } 
/*     */     }
/* 210 */     if (ssl.getTrustStoreType() != null) {
/* 211 */       factory.setTrustStoreType(ssl.getTrustStoreType());
/*     */     }
/* 213 */     if (ssl.getTrustStoreProvider() != null)
/* 214 */       factory.setTrustStoreProvider(ssl.getTrustStoreProvider()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\SslServerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
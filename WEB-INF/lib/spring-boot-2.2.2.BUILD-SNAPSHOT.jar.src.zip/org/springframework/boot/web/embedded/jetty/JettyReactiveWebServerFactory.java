/*     */ package org.springframework.boot.web.embedded.jetty;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.eclipse.jetty.server.AbstractConnector;
/*     */ import org.eclipse.jetty.server.ConnectionFactory;
/*     */ import org.eclipse.jetty.server.Connector;
/*     */ import org.eclipse.jetty.server.Handler;
/*     */ import org.eclipse.jetty.server.HandlerContainer;
/*     */ import org.eclipse.jetty.server.HttpConfiguration;
/*     */ import org.eclipse.jetty.server.HttpConnectionFactory;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.server.ServerConnector;
/*     */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*     */ import org.eclipse.jetty.servlet.ServletContextHandler;
/*     */ import org.eclipse.jetty.servlet.ServletHolder;
/*     */ import org.eclipse.jetty.util.thread.ThreadPool;
/*     */ import org.springframework.boot.web.reactive.server.AbstractReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.http.client.reactive.JettyResourceFactory;
/*     */ import org.springframework.http.server.reactive.HttpHandler;
/*     */ import org.springframework.http.server.reactive.JettyHttpHandlerAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyReactiveWebServerFactory
/*     */   extends AbstractReactiveWebServerFactory
/*     */   implements ConfigurableJettyWebServerFactory
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(JettyReactiveWebServerFactory.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private int acceptors = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private int selectors = -1;
/*     */   
/*     */   private boolean useForwardHeaders;
/*     */   
/*  71 */   private Set<JettyServerCustomizer> jettyServerCustomizers = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private JettyResourceFactory resourceFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadPool threadPool;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyReactiveWebServerFactory() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyReactiveWebServerFactory(int port) {
/*  89 */     super(port);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders) {
/*  94 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAcceptors(int acceptors) {
/*  99 */     this.acceptors = acceptors;
/*     */   }
/*     */ 
/*     */   
/*     */   public WebServer getWebServer(HttpHandler httpHandler) {
/* 104 */     JettyHttpHandlerAdapter servlet = new JettyHttpHandlerAdapter(httpHandler);
/* 105 */     Server server = createJettyServer(servlet);
/* 106 */     return new JettyWebServer(server, (getPort() >= 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addServerCustomizers(JettyServerCustomizer... customizers) {
/* 111 */     Assert.notNull(customizers, "Customizers must not be null");
/* 112 */     this.jettyServerCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerCustomizers(Collection<? extends JettyServerCustomizer> customizers) {
/* 121 */     Assert.notNull(customizers, "Customizers must not be null");
/* 122 */     this.jettyServerCustomizers = new LinkedHashSet<>(customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<JettyServerCustomizer> getServerCustomizers() {
/* 131 */     return this.jettyServerCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreadPool getThreadPool() {
/* 139 */     return this.threadPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThreadPool(ThreadPool threadPool) {
/* 148 */     this.threadPool = threadPool;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSelectors(int selectors) {
/* 153 */     this.selectors = selectors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceFactory(JettyResourceFactory resourceFactory) {
/* 162 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */   
/*     */   protected JettyResourceFactory getResourceFactory() {
/* 166 */     return this.resourceFactory;
/*     */   }
/*     */   
/*     */   protected Server createJettyServer(JettyHttpHandlerAdapter servlet) {
/* 170 */     int port = Math.max(getPort(), 0);
/* 171 */     InetSocketAddress address = new InetSocketAddress(getAddress(), port);
/* 172 */     Server server = new Server(getThreadPool());
/* 173 */     server.addConnector((Connector)createConnector(address, server));
/* 174 */     ServletHolder servletHolder = new ServletHolder((Servlet)servlet);
/* 175 */     servletHolder.setAsyncSupported(true);
/* 176 */     ServletContextHandler contextHandler = new ServletContextHandler((HandlerContainer)server, "/", false, false);
/* 177 */     contextHandler.addServlet(servletHolder, "/");
/* 178 */     server.setHandler(addHandlerWrappers((Handler)contextHandler));
/* 179 */     logger.info("Server initialized with port: " + port);
/* 180 */     if (getSsl() != null && getSsl().isEnabled()) {
/* 181 */       customizeSsl(server, address);
/*     */     }
/* 183 */     for (JettyServerCustomizer customizer : getServerCustomizers()) {
/* 184 */       customizer.customize(server);
/*     */     }
/* 186 */     if (this.useForwardHeaders) {
/* 187 */       (new ForwardHeadersCustomizer()).customize(server);
/*     */     }
/* 189 */     return server;
/*     */   }
/*     */   
/*     */   private AbstractConnector createConnector(InetSocketAddress address, Server server) {
/*     */     ServerConnector connector;
/* 194 */     JettyResourceFactory resourceFactory = getResourceFactory();
/* 195 */     if (resourceFactory != null) {
/*     */       
/* 197 */       connector = new ServerConnector(server, resourceFactory.getExecutor(), resourceFactory.getScheduler(), resourceFactory.getByteBufferPool(), this.acceptors, this.selectors, new ConnectionFactory[] { (ConnectionFactory)new HttpConnectionFactory() });
/*     */     } else {
/*     */       
/* 200 */       connector = new ServerConnector(server, this.acceptors, this.selectors);
/*     */     } 
/* 202 */     connector.setHost(address.getHostString());
/* 203 */     connector.setPort(address.getPort());
/* 204 */     for (ConnectionFactory connectionFactory : connector.getConnectionFactories()) {
/* 205 */       if (connectionFactory instanceof HttpConfiguration.ConnectionFactory) {
/* 206 */         ((HttpConfiguration.ConnectionFactory)connectionFactory).getHttpConfiguration()
/* 207 */           .setSendServerVersion(false);
/*     */       }
/*     */     } 
/* 210 */     return (AbstractConnector)connector;
/*     */   }
/*     */   
/*     */   private Handler addHandlerWrappers(Handler handler) {
/* 214 */     if (getCompression() != null && getCompression().getEnabled()) {
/* 215 */       handler = applyWrapper(handler, JettyHandlerWrappers.createGzipHandlerWrapper(getCompression()));
/*     */     }
/* 217 */     if (StringUtils.hasText(getServerHeader())) {
/* 218 */       handler = applyWrapper(handler, JettyHandlerWrappers.createServerHeaderHandlerWrapper(getServerHeader()));
/*     */     }
/* 220 */     return handler;
/*     */   }
/*     */   
/*     */   private Handler applyWrapper(Handler handler, HandlerWrapper wrapper) {
/* 224 */     wrapper.setHandler(handler);
/* 225 */     return (Handler)wrapper;
/*     */   }
/*     */   
/*     */   private void customizeSsl(Server server, InetSocketAddress address) {
/* 229 */     (new SslServerCustomizer(address, getSsl(), getSslStoreProvider(), getHttp2())).customize(server);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\JettyReactiveWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
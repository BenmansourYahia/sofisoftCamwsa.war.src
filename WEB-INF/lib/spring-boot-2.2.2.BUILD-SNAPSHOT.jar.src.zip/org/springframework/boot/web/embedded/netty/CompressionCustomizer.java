/*    */ package org.springframework.boot.web.embedded.netty;
/*    */ 
/*    */ import io.netty.handler.codec.http.HttpHeaderNames;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.function.BiPredicate;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.boot.web.server.Compression;
/*    */ import org.springframework.util.InvalidMimeTypeException;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ import reactor.netty.http.server.HttpServer;
/*    */ import reactor.netty.http.server.HttpServerRequest;
/*    */ import reactor.netty.http.server.HttpServerResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CompressionCustomizer
/*    */   implements NettyServerCustomizer
/*    */ {
/*    */   private static final CompressionPredicate ALWAYS_COMPRESS = (request, response) -> true;
/*    */   private final Compression compression;
/*    */   
/*    */   CompressionCustomizer(Compression compression) {
/* 51 */     this.compression = compression;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpServer apply(HttpServer server) {
/* 56 */     if (!this.compression.getMinResponseSize().isNegative()) {
/* 57 */       server = server.compress((int)this.compression.getMinResponseSize().toBytes());
/*    */     }
/* 59 */     CompressionPredicate mimeTypes = getMimeTypesPredicate(this.compression.getMimeTypes());
/* 60 */     CompressionPredicate excludedUserAgents = getExcludedUserAgentsPredicate(this.compression
/* 61 */         .getExcludedUserAgents());
/* 62 */     server = server.compress(mimeTypes.and(excludedUserAgents));
/* 63 */     return server;
/*    */   }
/*    */   
/*    */   private CompressionPredicate getMimeTypesPredicate(String[] mimeTypeValues) {
/* 67 */     if (ObjectUtils.isEmpty((Object[])mimeTypeValues)) {
/* 68 */       return ALWAYS_COMPRESS;
/*    */     }
/*    */     
/* 71 */     List<MimeType> mimeTypes = (List<MimeType>)Arrays.<String>stream(mimeTypeValues).map(MimeTypeUtils::parseMimeType).collect(Collectors.toList());
/* 72 */     return (request, response) -> {
/*    */         String contentType = response.responseHeaders().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/*    */         
/*    */         if (StringUtils.isEmpty(contentType)) {
/*    */           return false;
/*    */         }
/*    */         try {
/*    */           MimeType contentMimeType = MimeTypeUtils.parseMimeType(contentType);
/*    */           return mimeTypes.stream().anyMatch(());
/* 81 */         } catch (InvalidMimeTypeException ex) {
/*    */           return false;
/*    */         } 
/*    */       };
/*    */   }
/*    */   
/*    */   private CompressionPredicate getExcludedUserAgentsPredicate(String[] excludedUserAgents) {
/* 88 */     if (ObjectUtils.isEmpty((Object[])excludedUserAgents)) {
/* 89 */       return ALWAYS_COMPRESS;
/*    */     }
/* 91 */     return (request, response) -> {
/*    */         HttpHeaders headers = request.requestHeaders();
/*    */         return Arrays.<String>stream(excludedUserAgents).noneMatch(());
/*    */       };
/*    */   }
/*    */   
/*    */   private static interface CompressionPredicate extends BiPredicate<HttpServerRequest, HttpServerResponse> {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\netty\CompressionCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
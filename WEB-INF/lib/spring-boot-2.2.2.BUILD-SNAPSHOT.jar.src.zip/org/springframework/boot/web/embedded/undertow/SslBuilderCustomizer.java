/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509ExtendedKeyManager;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.boot.web.server.SslStoreProvider;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.xnio.Options;
/*     */ import org.xnio.Sequence;
/*     */ import org.xnio.SslClientAuthMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SslBuilderCustomizer
/*     */   implements UndertowBuilderCustomizer
/*     */ {
/*     */   private final int port;
/*     */   private final InetAddress address;
/*     */   private final Ssl ssl;
/*     */   private final SslStoreProvider sslStoreProvider;
/*     */   
/*     */   SslBuilderCustomizer(int port, InetAddress address, Ssl ssl, SslStoreProvider sslStoreProvider) {
/*  64 */     this.port = port;
/*  65 */     this.address = address;
/*  66 */     this.ssl = ssl;
/*  67 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public void customize(Undertow.Builder builder) {
/*     */     try {
/*  73 */       SSLContext sslContext = SSLContext.getInstance(this.ssl.getProtocol());
/*  74 */       sslContext.init(getKeyManagers(this.ssl, this.sslStoreProvider), 
/*  75 */           getTrustManagers(this.ssl, this.sslStoreProvider), null);
/*  76 */       builder.addHttpsListener(this.port, getListenAddress(), sslContext);
/*  77 */       builder.setSocketOption(Options.SSL_CLIENT_AUTH_MODE, getSslClientAuthMode(this.ssl));
/*  78 */       if (this.ssl.getEnabledProtocols() != null) {
/*  79 */         builder.setSocketOption(Options.SSL_ENABLED_PROTOCOLS, Sequence.of((Object[])this.ssl.getEnabledProtocols()));
/*     */       }
/*  81 */       if (this.ssl.getCiphers() != null) {
/*  82 */         builder.setSocketOption(Options.SSL_ENABLED_CIPHER_SUITES, Sequence.of((Object[])this.ssl.getCiphers()));
/*     */       }
/*     */     }
/*  85 */     catch (NoSuchAlgorithmException|java.security.KeyManagementException ex) {
/*  86 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getListenAddress() {
/*  91 */     if (this.address == null) {
/*  92 */       return "0.0.0.0";
/*     */     }
/*  94 */     return this.address.getHostAddress();
/*     */   }
/*     */   
/*     */   private SslClientAuthMode getSslClientAuthMode(Ssl ssl) {
/*  98 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/*  99 */       return SslClientAuthMode.REQUIRED;
/*     */     }
/* 101 */     if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/* 102 */       return SslClientAuthMode.REQUESTED;
/*     */     }
/* 104 */     return SslClientAuthMode.NOT_REQUESTED;
/*     */   }
/*     */   
/*     */   private KeyManager[] getKeyManagers(Ssl ssl, SslStoreProvider sslStoreProvider) {
/*     */     try {
/* 109 */       KeyStore keyStore = getKeyStore(ssl, sslStoreProvider);
/*     */       
/* 111 */       KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/* 112 */       char[] keyPassword = (ssl.getKeyPassword() != null) ? ssl.getKeyPassword().toCharArray() : null;
/* 113 */       if (keyPassword == null && ssl.getKeyStorePassword() != null) {
/* 114 */         keyPassword = ssl.getKeyStorePassword().toCharArray();
/*     */       }
/* 116 */       keyManagerFactory.init(keyStore, keyPassword);
/* 117 */       if (ssl.getKeyAlias() != null) {
/* 118 */         return getConfigurableAliasKeyManagers(ssl, keyManagerFactory.getKeyManagers());
/*     */       }
/* 120 */       return keyManagerFactory.getKeyManagers();
/*     */     }
/* 122 */     catch (Exception ex) {
/* 123 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private KeyManager[] getConfigurableAliasKeyManagers(Ssl ssl, KeyManager[] keyManagers) {
/* 128 */     for (int i = 0; i < keyManagers.length; i++) {
/* 129 */       if (keyManagers[i] instanceof X509ExtendedKeyManager) {
/* 130 */         keyManagers[i] = new ConfigurableAliasKeyManager((X509ExtendedKeyManager)keyManagers[i], ssl
/* 131 */             .getKeyAlias());
/*     */       }
/*     */     } 
/* 134 */     return keyManagers;
/*     */   }
/*     */   
/*     */   private KeyStore getKeyStore(Ssl ssl, SslStoreProvider sslStoreProvider) throws Exception {
/* 138 */     if (sslStoreProvider != null) {
/* 139 */       return sslStoreProvider.getKeyStore();
/*     */     }
/* 141 */     return loadKeyStore(ssl.getKeyStoreType(), ssl.getKeyStoreProvider(), ssl.getKeyStore(), ssl
/* 142 */         .getKeyStorePassword());
/*     */   }
/*     */   
/*     */   private TrustManager[] getTrustManagers(Ssl ssl, SslStoreProvider sslStoreProvider) {
/*     */     try {
/* 147 */       KeyStore store = getTrustStore(ssl, sslStoreProvider);
/*     */       
/* 149 */       TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/* 150 */       trustManagerFactory.init(store);
/* 151 */       return trustManagerFactory.getTrustManagers();
/*     */     }
/* 153 */     catch (Exception ex) {
/* 154 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private KeyStore getTrustStore(Ssl ssl, SslStoreProvider sslStoreProvider) throws Exception {
/* 159 */     if (sslStoreProvider != null) {
/* 160 */       return sslStoreProvider.getTrustStore();
/*     */     }
/* 162 */     return loadTrustStore(ssl.getTrustStoreType(), ssl.getTrustStoreProvider(), ssl.getTrustStore(), ssl
/* 163 */         .getTrustStorePassword());
/*     */   }
/*     */   
/*     */   private KeyStore loadKeyStore(String type, String provider, String resource, String password) throws Exception {
/* 167 */     return loadStore(type, provider, resource, password);
/*     */   }
/*     */   
/*     */   private KeyStore loadTrustStore(String type, String provider, String resource, String password) throws Exception {
/* 171 */     if (resource == null) {
/* 172 */       return null;
/*     */     }
/* 174 */     return loadStore(type, provider, resource, password);
/*     */   }
/*     */   
/*     */   private KeyStore loadStore(String type, String provider, String resource, String password) throws Exception {
/* 178 */     type = (type != null) ? type : "JKS";
/* 179 */     KeyStore store = (provider != null) ? KeyStore.getInstance(type, provider) : KeyStore.getInstance(type);
/*     */     try {
/* 181 */       URL url = ResourceUtils.getURL(resource);
/* 182 */       store.load(url.openStream(), (password != null) ? password.toCharArray() : null);
/* 183 */       return store;
/*     */     }
/* 185 */     catch (Exception ex) {
/* 186 */       throw new WebServerException("Could not load key store '" + resource + "'", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ConfigurableAliasKeyManager
/*     */     extends X509ExtendedKeyManager
/*     */   {
/*     */     private final X509ExtendedKeyManager keyManager;
/*     */     
/*     */     private final String alias;
/*     */ 
/*     */     
/*     */     ConfigurableAliasKeyManager(X509ExtendedKeyManager keyManager, String alias) {
/* 200 */       this.keyManager = keyManager;
/* 201 */       this.alias = alias;
/*     */     }
/*     */ 
/*     */     
/*     */     public String chooseEngineClientAlias(String[] strings, Principal[] principals, SSLEngine sslEngine) {
/* 206 */       return this.keyManager.chooseEngineClientAlias(strings, principals, sslEngine);
/*     */     }
/*     */ 
/*     */     
/*     */     public String chooseEngineServerAlias(String s, Principal[] principals, SSLEngine sslEngine) {
/* 211 */       if (this.alias == null) {
/* 212 */         return this.keyManager.chooseEngineServerAlias(s, principals, sslEngine);
/*     */       }
/* 214 */       return this.alias;
/*     */     }
/*     */ 
/*     */     
/*     */     public String chooseClientAlias(String[] keyType, Principal[] issuers, Socket socket) {
/* 219 */       return this.keyManager.chooseClientAlias(keyType, issuers, socket);
/*     */     }
/*     */ 
/*     */     
/*     */     public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
/* 224 */       return this.keyManager.chooseServerAlias(keyType, issuers, socket);
/*     */     }
/*     */ 
/*     */     
/*     */     public X509Certificate[] getCertificateChain(String alias) {
/* 229 */       return this.keyManager.getCertificateChain(alias);
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getClientAliases(String keyType, Principal[] issuers) {
/* 234 */       return this.keyManager.getClientAliases(keyType, issuers);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrivateKey getPrivateKey(String alias) {
/* 239 */       return this.keyManager.getPrivateKey(alias);
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getServerAliases(String keyType, Principal[] issuers) {
/* 244 */       return this.keyManager.getServerAliases(keyType, issuers);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\SslBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
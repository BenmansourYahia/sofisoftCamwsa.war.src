/*     */ package org.springframework.boot.web.embedded.jetty;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.BindException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.eclipse.jetty.server.Connector;
/*     */ import org.eclipse.jetty.server.Handler;
/*     */ import org.eclipse.jetty.server.NetworkConnector;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.server.handler.ContextHandler;
/*     */ import org.eclipse.jetty.server.handler.HandlerCollection;
/*     */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*     */ import org.eclipse.jetty.util.component.AbstractLifeCycle;
/*     */ import org.springframework.boot.web.server.PortInUseException;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyWebServer
/*     */   implements WebServer
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(JettyWebServer.class);
/*     */   
/*  59 */   private final Object monitor = new Object();
/*     */ 
/*     */   
/*     */   private final Server server;
/*     */ 
/*     */   
/*     */   private final boolean autoStart;
/*     */ 
/*     */   
/*     */   private Connector[] connectors;
/*     */   
/*     */   private volatile boolean started;
/*     */ 
/*     */   
/*     */   public JettyWebServer(Server server) {
/*  74 */     this(server, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyWebServer(Server server, boolean autoStart) {
/*  83 */     this.autoStart = autoStart;
/*  84 */     Assert.notNull(server, "Jetty Server must not be null");
/*  85 */     this.server = server;
/*  86 */     initialize();
/*     */   }
/*     */   
/*     */   private void initialize() {
/*  90 */     synchronized (this.monitor) {
/*     */ 
/*     */       
/*     */       try {
/*  94 */         this.connectors = this.server.getConnectors();
/*  95 */         this.server.addBean(new AbstractLifeCycle()
/*     */             {
/*     */               protected void doStart() throws Exception
/*     */               {
/*  99 */                 for (Connector connector : JettyWebServer.this.connectors) {
/* 100 */                   Assert.state(connector.isStopped(), () -> "Connector " + connector + " has been started prematurely");
/*     */                 }
/*     */                 
/* 103 */                 JettyWebServer.this.server.setConnectors(null);
/*     */               }
/*     */             });
/*     */ 
/*     */         
/* 108 */         this.server.start();
/* 109 */         this.server.setStopAtShutdown(false);
/*     */       }
/* 111 */       catch (Throwable ex) {
/*     */         
/* 113 */         stopSilently();
/* 114 */         throw new WebServerException("Unable to start embedded Jetty web server", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void stopSilently() {
/*     */     try {
/* 121 */       this.server.stop();
/*     */     }
/* 123 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws WebServerException {
/* 130 */     synchronized (this.monitor) {
/* 131 */       if (this.started) {
/*     */         return;
/*     */       }
/* 134 */       this.server.setConnectors(this.connectors);
/* 135 */       if (!this.autoStart) {
/*     */         return;
/*     */       }
/*     */       try {
/* 139 */         this.server.start();
/* 140 */         for (Handler handler : this.server.getHandlers()) {
/* 141 */           handleDeferredInitialize(new Handler[] { handler });
/*     */         } 
/* 143 */         Connector[] connectors = this.server.getConnectors();
/* 144 */         for (Connector connector : connectors) {
/*     */           try {
/* 146 */             connector.start();
/*     */           }
/* 148 */           catch (IOException ex) {
/* 149 */             if (connector instanceof NetworkConnector && findBindException(ex) != null) {
/* 150 */               throw new PortInUseException(((NetworkConnector)connector).getPort());
/*     */             }
/* 152 */             throw ex;
/*     */           } 
/*     */         } 
/* 155 */         this.started = true;
/* 156 */         logger.info("Jetty started on port(s) " + getActualPortsDescription() + " with context path '" + 
/* 157 */             getContextPath() + "'");
/*     */       }
/* 159 */       catch (WebServerException ex) {
/* 160 */         stopSilently();
/* 161 */         throw ex;
/*     */       }
/* 163 */       catch (Exception ex) {
/* 164 */         stopSilently();
/* 165 */         throw new WebServerException("Unable to start embedded Jetty server", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private BindException findBindException(Throwable ex) {
/* 171 */     if (ex == null) {
/* 172 */       return null;
/*     */     }
/* 174 */     if (ex instanceof BindException) {
/* 175 */       return (BindException)ex;
/*     */     }
/* 177 */     return findBindException(ex.getCause());
/*     */   }
/*     */   
/*     */   private String getActualPortsDescription() {
/* 181 */     StringBuilder ports = new StringBuilder();
/* 182 */     for (Connector connector : this.server.getConnectors()) {
/* 183 */       if (ports.length() != 0) {
/* 184 */         ports.append(", ");
/*     */       }
/* 186 */       ports.append(getLocalPort(connector)).append(getProtocols(connector));
/*     */     } 
/* 188 */     return ports.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private Integer getLocalPort(Connector connector) {
/*     */     try {
/* 194 */       return 
/* 195 */         (Integer)ReflectionUtils.invokeMethod(ReflectionUtils.findMethod(connector.getClass(), "getLocalPort"), connector);
/*     */     }
/* 197 */     catch (Exception ex) {
/* 198 */       logger.info("could not determine port ( " + ex.getMessage() + ")");
/* 199 */       return Integer.valueOf(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getProtocols(Connector connector) {
/* 204 */     List<String> protocols = connector.getProtocols();
/* 205 */     return " (" + StringUtils.collectionToDelimitedString(protocols, ", ") + ")";
/*     */   }
/*     */   
/*     */   private String getContextPath() {
/* 209 */     return Arrays.<Handler>stream(this.server.getHandlers()).filter(ContextHandler.class::isInstance)
/* 210 */       .map(ContextHandler.class::cast).map(ContextHandler::getContextPath).collect(Collectors.joining(" "));
/*     */   }
/*     */   
/*     */   private void handleDeferredInitialize(Handler... handlers) throws Exception {
/* 214 */     for (Handler handler : handlers) {
/* 215 */       if (handler instanceof JettyEmbeddedWebAppContext) {
/* 216 */         ((JettyEmbeddedWebAppContext)handler).deferredInitialize();
/*     */       }
/* 218 */       else if (handler instanceof HandlerWrapper) {
/* 219 */         handleDeferredInitialize(new Handler[] { ((HandlerWrapper)handler).getHandler() });
/*     */       }
/* 221 */       else if (handler instanceof HandlerCollection) {
/* 222 */         handleDeferredInitialize(((HandlerCollection)handler).getHandlers());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 229 */     synchronized (this.monitor) {
/* 230 */       this.started = false;
/*     */       try {
/* 232 */         this.server.stop();
/*     */       }
/* 234 */       catch (InterruptedException ex) {
/* 235 */         Thread.currentThread().interrupt();
/*     */       }
/* 237 */       catch (Exception ex) {
/* 238 */         throw new WebServerException("Unable to stop embedded Jetty server", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 245 */     Connector[] connectors = this.server.getConnectors();
/* 246 */     Connector[] arrayOfConnector1 = connectors; int i = arrayOfConnector1.length; byte b = 0; if (b < i) { Connector connector = arrayOfConnector1[b];
/*     */       
/* 248 */       return getLocalPort(connector).intValue(); }
/*     */     
/* 250 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Server getServer() {
/* 258 */     return this.server;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\JettyWebServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.embedded.tomcat;
/*    */ 
/*    */ import org.apache.catalina.LifecycleException;
/*    */ import org.apache.catalina.LifecycleState;
/*    */ import org.apache.catalina.util.StandardSessionIdGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LazySessionIdGenerator
/*    */   extends StandardSessionIdGenerator
/*    */ {
/*    */   protected void startInternal() throws LifecycleException {
/* 33 */     setState(LifecycleState.STARTING);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\LazySessionIdGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
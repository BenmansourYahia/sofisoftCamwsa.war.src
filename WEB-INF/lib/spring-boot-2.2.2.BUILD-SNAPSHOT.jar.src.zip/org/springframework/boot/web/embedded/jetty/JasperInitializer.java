/*     */ package org.springframework.boot.web.embedded.jetty;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.webresources.TomcatURLStreamHandlerFactory;
/*     */ import org.eclipse.jetty.util.component.AbstractLifeCycle;
/*     */ import org.eclipse.jetty.webapp.WebAppContext;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JasperInitializer
/*     */   extends AbstractLifeCycle
/*     */ {
/*  42 */   private static final String[] INITIALIZER_CLASSES = new String[] { "org.eclipse.jetty.apache.jsp.JettyJasperInitializer", "org.apache.jasper.servlet.JasperInitializer" };
/*     */   
/*     */   private final WebAppContext context;
/*     */   
/*     */   private final ServletContainerInitializer initializer;
/*     */ 
/*     */   
/*     */   JasperInitializer(WebAppContext context) {
/*  50 */     this.context = context;
/*  51 */     this.initializer = newInitializer();
/*     */   }
/*     */   
/*     */   private ServletContainerInitializer newInitializer() {
/*  55 */     for (String className : INITIALIZER_CLASSES) {
/*     */       try {
/*  57 */         Class<?> initializerClass = ClassUtils.forName(className, null);
/*  58 */         return (ServletContainerInitializer)initializerClass.newInstance();
/*     */       }
/*  60 */       catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doStart() throws Exception {
/*  69 */     if (this.initializer == null) {
/*     */       return;
/*     */     }
/*  72 */     if (ClassUtils.isPresent("org.apache.catalina.webresources.TomcatURLStreamHandlerFactory", 
/*  73 */         getClass().getClassLoader())) {
/*  74 */       TomcatURLStreamHandlerFactory.register();
/*     */     } else {
/*     */       
/*     */       try {
/*  78 */         URL.setURLStreamHandlerFactory(new WarUrlStreamHandlerFactory());
/*     */       }
/*  80 */       catch (Error error) {}
/*     */     } 
/*     */ 
/*     */     
/*  84 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/*  86 */       Thread.currentThread().setContextClassLoader(this.context.getClassLoader());
/*     */       try {
/*  88 */         setExtendedListenerTypes(true);
/*  89 */         this.initializer.onStartup(null, (ServletContext)this.context.getServletContext());
/*     */       } finally {
/*     */         
/*  92 */         setExtendedListenerTypes(false);
/*     */       } 
/*     */     } finally {
/*     */       
/*  96 */       Thread.currentThread().setContextClassLoader(classLoader);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setExtendedListenerTypes(boolean extended) {
/*     */     try {
/* 102 */       this.context.getServletContext().setExtendedListenerTypes(extended);
/*     */     }
/* 104 */     catch (NoSuchMethodError noSuchMethodError) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class WarUrlStreamHandlerFactory
/*     */     implements URLStreamHandlerFactory
/*     */   {
/*     */     private WarUrlStreamHandlerFactory() {}
/*     */ 
/*     */     
/*     */     public URLStreamHandler createURLStreamHandler(String protocol) {
/* 116 */       if ("war".equals(protocol)) {
/* 117 */         return new JasperInitializer.WarUrlStreamHandler();
/*     */       }
/* 119 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class WarUrlStreamHandler
/*     */     extends URLStreamHandler
/*     */   {
/*     */     private WarUrlStreamHandler() {}
/*     */ 
/*     */ 
/*     */     
/*     */     protected void parseURL(URL u, String spec, int start, int limit) {
/* 133 */       String path = "jar:" + spec.substring("war:".length());
/* 134 */       int separator = path.indexOf("*/");
/* 135 */       if (separator >= 0) {
/* 136 */         path = path.substring(0, separator) + "!/" + path.substring(separator + 2);
/*     */       }
/* 138 */       setURL(u, u.getProtocol(), "", -1, null, null, path, null, null);
/*     */     }
/*     */ 
/*     */     
/*     */     protected URLConnection openConnection(URL u) throws IOException {
/* 143 */       return new JasperInitializer.WarURLConnection(u);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class WarURLConnection
/*     */     extends URLConnection
/*     */   {
/*     */     private final URLConnection connection;
/*     */ 
/*     */     
/*     */     protected WarURLConnection(URL url) throws IOException {
/* 156 */       super(url);
/* 157 */       this.connection = (new URL(url.getFile())).openConnection();
/*     */     }
/*     */ 
/*     */     
/*     */     public void connect() throws IOException {
/* 162 */       if (!this.connected) {
/* 163 */         this.connection.connect();
/* 164 */         this.connected = true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 170 */       connect();
/* 171 */       return this.connection.getInputStream();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\JasperInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.embedded.jetty;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jetty.http.MimeTypes;
/*     */ import org.eclipse.jetty.server.AbstractConnector;
/*     */ import org.eclipse.jetty.server.ConnectionFactory;
/*     */ import org.eclipse.jetty.server.Connector;
/*     */ import org.eclipse.jetty.server.Handler;
/*     */ import org.eclipse.jetty.server.HttpConfiguration;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.server.ServerConnector;
/*     */ import org.eclipse.jetty.server.handler.ErrorHandler;
/*     */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*     */ import org.eclipse.jetty.server.session.DefaultSessionCache;
/*     */ import org.eclipse.jetty.server.session.FileSessionDataStore;
/*     */ import org.eclipse.jetty.server.session.SessionCache;
/*     */ import org.eclipse.jetty.server.session.SessionDataStore;
/*     */ import org.eclipse.jetty.server.session.SessionHandler;
/*     */ import org.eclipse.jetty.servlet.ErrorPageErrorHandler;
/*     */ import org.eclipse.jetty.servlet.ServletHolder;
/*     */ import org.eclipse.jetty.servlet.ServletMapping;
/*     */ import org.eclipse.jetty.util.resource.JarResource;
/*     */ import org.eclipse.jetty.util.resource.Resource;
/*     */ import org.eclipse.jetty.util.resource.ResourceCollection;
/*     */ import org.eclipse.jetty.util.thread.ThreadPool;
/*     */ import org.eclipse.jetty.webapp.AbstractConfiguration;
/*     */ import org.eclipse.jetty.webapp.Configuration;
/*     */ import org.eclipse.jetty.webapp.WebAppContext;
/*     */ import org.springframework.boot.web.server.ErrorPage;
/*     */ import org.springframework.boot.web.server.MimeMappings;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.boot.web.servlet.server.AbstractServletWebServerFactory;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyServletWebServerFactory
/*     */   extends AbstractServletWebServerFactory
/*     */   implements ConfigurableJettyWebServerFactory, ResourceLoaderAware
/*     */ {
/*  92 */   private List<Configuration> configurations = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useForwardHeaders;
/*     */ 
/*     */   
/*  99 */   private int acceptors = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private int selectors = -1;
/*     */   
/* 106 */   private Set<JettyServerCustomizer> jettyServerCustomizers = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadPool threadPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyServletWebServerFactory(int port) {
/* 124 */     super(port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyServletWebServerFactory(String contextPath, int port) {
/* 134 */     super(contextPath, port);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebServer getWebServer(ServletContextInitializer... initializers) {
/* 139 */     JettyEmbeddedWebAppContext context = new JettyEmbeddedWebAppContext();
/* 140 */     int port = Math.max(getPort(), 0);
/* 141 */     InetSocketAddress address = new InetSocketAddress(getAddress(), port);
/* 142 */     Server server = createServer(address);
/* 143 */     configureWebAppContext(context, initializers);
/* 144 */     server.setHandler(addHandlerWrappers((Handler)context));
/* 145 */     this.logger.info("Server initialized with port: " + port);
/* 146 */     if (getSsl() != null && getSsl().isEnabled()) {
/* 147 */       customizeSsl(server, address);
/*     */     }
/* 149 */     for (JettyServerCustomizer customizer : getServerCustomizers()) {
/* 150 */       customizer.customize(server);
/*     */     }
/* 152 */     if (this.useForwardHeaders) {
/* 153 */       (new ForwardHeadersCustomizer()).customize(server);
/*     */     }
/* 155 */     return getJettyWebServer(server);
/*     */   }
/*     */   
/*     */   private Server createServer(InetSocketAddress address) {
/* 159 */     Server server = new Server(getThreadPool());
/* 160 */     server.setConnectors(new Connector[] { (Connector)createConnector(address, server) });
/* 161 */     return server;
/*     */   }
/*     */   
/*     */   private AbstractConnector createConnector(InetSocketAddress address, Server server) {
/* 165 */     ServerConnector connector = new ServerConnector(server, this.acceptors, this.selectors);
/* 166 */     connector.setHost(address.getHostString());
/* 167 */     connector.setPort(address.getPort());
/* 168 */     for (ConnectionFactory connectionFactory : connector.getConnectionFactories()) {
/* 169 */       if (connectionFactory instanceof HttpConfiguration.ConnectionFactory) {
/* 170 */         ((HttpConfiguration.ConnectionFactory)connectionFactory).getHttpConfiguration()
/* 171 */           .setSendServerVersion(false);
/*     */       }
/*     */     } 
/* 174 */     return (AbstractConnector)connector;
/*     */   }
/*     */   
/*     */   private Handler addHandlerWrappers(Handler handler) {
/* 178 */     if (getCompression() != null && getCompression().getEnabled()) {
/* 179 */       handler = applyWrapper(handler, JettyHandlerWrappers.createGzipHandlerWrapper(getCompression()));
/*     */     }
/* 181 */     if (StringUtils.hasText(getServerHeader())) {
/* 182 */       handler = applyWrapper(handler, JettyHandlerWrappers.createServerHeaderHandlerWrapper(getServerHeader()));
/*     */     }
/* 184 */     return handler;
/*     */   }
/*     */   
/*     */   private Handler applyWrapper(Handler handler, HandlerWrapper wrapper) {
/* 188 */     wrapper.setHandler(handler);
/* 189 */     return (Handler)wrapper;
/*     */   }
/*     */   
/*     */   private void customizeSsl(Server server, InetSocketAddress address) {
/* 193 */     (new SslServerCustomizer(address, getSsl(), getSslStoreProvider(), getHttp2())).customize(server);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void configureWebAppContext(WebAppContext context, ServletContextInitializer... initializers) {
/* 202 */     Assert.notNull(context, "Context must not be null");
/* 203 */     context.getAliasChecks().clear();
/* 204 */     context.setTempDirectory(getTempDirectory());
/* 205 */     if (this.resourceLoader != null) {
/* 206 */       context.setClassLoader(this.resourceLoader.getClassLoader());
/*     */     }
/* 208 */     String contextPath = getContextPath();
/* 209 */     context.setContextPath(StringUtils.hasLength(contextPath) ? contextPath : "/");
/* 210 */     context.setDisplayName(getDisplayName());
/* 211 */     configureDocumentRoot(context);
/* 212 */     if (isRegisterDefaultServlet()) {
/* 213 */       addDefaultServlet(context);
/*     */     }
/* 215 */     if (shouldRegisterJspServlet()) {
/* 216 */       addJspServlet(context);
/* 217 */       context.addBean(new JasperInitializer(context), true);
/*     */     } 
/* 219 */     addLocaleMappings(context);
/* 220 */     ServletContextInitializer[] initializersToUse = mergeInitializers(initializers);
/* 221 */     Configuration[] configurations = getWebAppContextConfigurations(context, initializersToUse);
/* 222 */     context.setConfigurations(configurations);
/* 223 */     context.setThrowUnavailableOnStartupException(true);
/* 224 */     configureSession(context);
/* 225 */     postProcessWebAppContext(context);
/*     */   }
/*     */   
/*     */   private void configureSession(WebAppContext context) {
/* 229 */     SessionHandler handler = context.getSessionHandler();
/* 230 */     Duration sessionTimeout = getSession().getTimeout();
/* 231 */     handler.setMaxInactiveInterval(isNegative(sessionTimeout) ? -1 : (int)sessionTimeout.getSeconds());
/* 232 */     if (getSession().isPersistent()) {
/* 233 */       DefaultSessionCache cache = new DefaultSessionCache(handler);
/* 234 */       FileSessionDataStore store = new FileSessionDataStore();
/* 235 */       store.setStoreDir(getValidSessionStoreDir());
/* 236 */       cache.setSessionDataStore((SessionDataStore)store);
/* 237 */       handler.setSessionCache((SessionCache)cache);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isNegative(Duration sessionTimeout) {
/* 242 */     return (sessionTimeout == null || sessionTimeout.isNegative());
/*     */   }
/*     */   
/*     */   private void addLocaleMappings(WebAppContext context) {
/* 246 */     getLocaleCharsetMappings()
/* 247 */       .forEach((locale, charset) -> context.addLocaleEncoding(locale.toString(), charset.toString()));
/*     */   }
/*     */   
/*     */   private File getTempDirectory() {
/* 251 */     String temp = System.getProperty("java.io.tmpdir");
/* 252 */     return (temp != null) ? new File(temp) : null;
/*     */   }
/*     */   
/*     */   private void configureDocumentRoot(WebAppContext handler) {
/* 256 */     File root = getValidDocumentRoot();
/* 257 */     File docBase = (root != null) ? root : createTempDir("jetty-docbase");
/*     */     try {
/* 259 */       List<Resource> resources = new ArrayList<>();
/*     */       
/* 261 */       Resource rootResource = docBase.isDirectory() ? Resource.newResource(docBase.getCanonicalFile()) : JarResource.newJarResource(Resource.newResource(docBase));
/* 262 */       resources.add((root != null) ? new LoaderHidingResource(rootResource) : rootResource);
/* 263 */       for (URL resourceJarUrl : getUrlsOfJarsWithMetaInfResources()) {
/* 264 */         Resource resource = createResource(resourceJarUrl);
/* 265 */         if (resource.exists() && resource.isDirectory()) {
/* 266 */           resources.add(resource);
/*     */         }
/*     */       } 
/* 269 */       handler.setBaseResource((Resource)new ResourceCollection(resources.<Resource>toArray(new Resource[0])));
/*     */     }
/* 271 */     catch (Exception ex) {
/* 272 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Resource createResource(URL url) throws Exception {
/* 277 */     if ("file".equals(url.getProtocol())) {
/* 278 */       File file = new File(url.toURI());
/* 279 */       if (file.isFile()) {
/* 280 */         return Resource.newResource("jar:" + url + "!/META-INF/resources");
/*     */       }
/*     */     } 
/* 283 */     return Resource.newResource(url + "META-INF/resources");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void addDefaultServlet(WebAppContext context) {
/* 291 */     Assert.notNull(context, "Context must not be null");
/* 292 */     ServletHolder holder = new ServletHolder();
/* 293 */     holder.setName("default");
/* 294 */     holder.setClassName("org.eclipse.jetty.servlet.DefaultServlet");
/* 295 */     holder.setInitParameter("dirAllowed", "false");
/* 296 */     holder.setInitOrder(1);
/* 297 */     context.getServletHandler().addServletWithMapping(holder, "/");
/* 298 */     context.getServletHandler().getServletMapping("/").setDefault(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void addJspServlet(WebAppContext context) {
/* 306 */     Assert.notNull(context, "Context must not be null");
/* 307 */     ServletHolder holder = new ServletHolder();
/* 308 */     holder.setName("jsp");
/* 309 */     holder.setClassName(getJsp().getClassName());
/* 310 */     holder.setInitParameter("fork", "false");
/* 311 */     holder.setInitParameters(getJsp().getInitParameters());
/* 312 */     holder.setInitOrder(3);
/* 313 */     context.getServletHandler().addServlet(holder);
/* 314 */     ServletMapping mapping = new ServletMapping();
/* 315 */     mapping.setServletName("jsp");
/* 316 */     mapping.setPathSpecs(new String[] { "*.jsp", "*.jspx" });
/* 317 */     context.getServletHandler().addServletMapping(mapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configuration[] getWebAppContextConfigurations(WebAppContext webAppContext, ServletContextInitializer... initializers) {
/* 328 */     List<Configuration> configurations = new ArrayList<>();
/* 329 */     configurations.add(getServletContextInitializerConfiguration(webAppContext, initializers));
/* 330 */     configurations.addAll(getConfigurations());
/* 331 */     configurations.add(getErrorPageConfiguration());
/* 332 */     configurations.add(getMimeTypeConfiguration());
/* 333 */     return configurations.<Configuration>toArray(new Configuration[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Configuration getErrorPageConfiguration() {
/* 341 */     return (Configuration)new AbstractConfiguration()
/*     */       {
/*     */         public void configure(WebAppContext context) throws Exception
/*     */         {
/* 345 */           JettyEmbeddedErrorHandler errorHandler = new JettyEmbeddedErrorHandler();
/* 346 */           context.setErrorHandler((ErrorHandler)errorHandler);
/* 347 */           JettyServletWebServerFactory.this.addJettyErrorPages((ErrorHandler)errorHandler, JettyServletWebServerFactory.this.getErrorPages());
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Configuration getMimeTypeConfiguration() {
/* 358 */     return (Configuration)new AbstractConfiguration()
/*     */       {
/*     */         public void configure(WebAppContext context) throws Exception
/*     */         {
/* 362 */           MimeTypes mimeTypes = context.getMimeTypes();
/* 363 */           for (MimeMappings.Mapping mapping : JettyServletWebServerFactory.this.getMimeMappings()) {
/* 364 */             mimeTypes.addMimeMapping(mapping.getExtension(), mapping.getMimeType());
/*     */           }
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configuration getServletContextInitializerConfiguration(WebAppContext webAppContext, ServletContextInitializer... initializers) {
/* 381 */     return (Configuration)new ServletContextInitializerConfiguration(initializers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessWebAppContext(WebAppContext webAppContext) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JettyWebServer getJettyWebServer(Server server) {
/* 401 */     return new JettyWebServer(server, (getPort() >= 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 406 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders) {
/* 411 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAcceptors(int acceptors) {
/* 416 */     this.acceptors = acceptors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSelectors(int selectors) {
/* 421 */     this.selectors = selectors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerCustomizers(Collection<? extends JettyServerCustomizer> customizers) {
/* 430 */     Assert.notNull(customizers, "Customizers must not be null");
/* 431 */     this.jettyServerCustomizers = new LinkedHashSet<>(customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<JettyServerCustomizer> getServerCustomizers() {
/* 440 */     return this.jettyServerCustomizers;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addServerCustomizers(JettyServerCustomizer... customizers) {
/* 445 */     Assert.notNull(customizers, "Customizers must not be null");
/* 446 */     this.jettyServerCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigurations(Collection<? extends Configuration> configurations) {
/* 456 */     Assert.notNull(configurations, "Configurations must not be null");
/* 457 */     this.configurations = new ArrayList<>(configurations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Configuration> getConfigurations() {
/* 466 */     return this.configurations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConfigurations(Configuration... configurations) {
/* 475 */     Assert.notNull(configurations, "Configurations must not be null");
/* 476 */     this.configurations.addAll(Arrays.asList(configurations));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreadPool getThreadPool() {
/* 484 */     return this.threadPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThreadPool(ThreadPool threadPool) {
/* 493 */     this.threadPool = threadPool;
/*     */   }
/*     */   
/*     */   private void addJettyErrorPages(ErrorHandler errorHandler, Collection<ErrorPage> errorPages) {
/* 497 */     if (errorHandler instanceof ErrorPageErrorHandler) {
/* 498 */       ErrorPageErrorHandler handler = (ErrorPageErrorHandler)errorHandler;
/* 499 */       for (ErrorPage errorPage : errorPages) {
/* 500 */         if (errorPage.isGlobal()) {
/* 501 */           handler.addErrorPage("org.eclipse.jetty.server.error_page.global", errorPage.getPath());
/*     */           continue;
/*     */         } 
/* 504 */         if (errorPage.getExceptionName() != null) {
/* 505 */           handler.addErrorPage(errorPage.getExceptionName(), errorPage.getPath());
/*     */           continue;
/*     */         } 
/* 508 */         handler.addErrorPage(errorPage.getStatusCode(), errorPage.getPath());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public JettyServletWebServerFactory() {}
/*     */   
/*     */   private static final class LoaderHidingResource
/*     */     extends Resource {
/*     */     private final Resource delegate;
/*     */     
/*     */     private LoaderHidingResource(Resource delegate) {
/* 520 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public Resource addPath(String path) throws IOException, MalformedURLException {
/* 525 */       if (path.startsWith("/org/springframework/boot")) {
/* 526 */         return null;
/*     */       }
/* 528 */       return this.delegate.addPath(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isContainedIn(Resource resource) throws MalformedURLException {
/* 533 */       return this.delegate.isContainedIn(resource);
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 538 */       this.delegate.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean exists() {
/* 543 */       return this.delegate.exists();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDirectory() {
/* 548 */       return this.delegate.isDirectory();
/*     */     }
/*     */ 
/*     */     
/*     */     public long lastModified() {
/* 553 */       return this.delegate.lastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public long length() {
/* 558 */       return this.delegate.length();
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public URL getURL() {
/* 564 */       return this.delegate.getURL();
/*     */     }
/*     */ 
/*     */     
/*     */     public File getFile() throws IOException {
/* 569 */       return this.delegate.getFile();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 574 */       return this.delegate.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 579 */       return this.delegate.getInputStream();
/*     */     }
/*     */ 
/*     */     
/*     */     public ReadableByteChannel getReadableByteChannel() throws IOException {
/* 584 */       return this.delegate.getReadableByteChannel();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean delete() throws SecurityException {
/* 589 */       return this.delegate.delete();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean renameTo(Resource dest) throws SecurityException {
/* 594 */       return this.delegate.renameTo(dest);
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] list() {
/* 599 */       return this.delegate.list();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\JettyServletWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.embedded.jetty;
/*    */ 
/*    */ import org.eclipse.jetty.servlet.ServletHandler;
/*    */ import org.eclipse.jetty.webapp.WebAppContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JettyEmbeddedWebAppContext
/*    */   extends WebAppContext
/*    */ {
/*    */   protected ServletHandler newServletHandler() {
/* 32 */     return new JettyEmbeddedServletHandler();
/*    */   }
/*    */   
/*    */   void deferredInitialize() throws Exception {
/* 36 */     ((JettyEmbeddedServletHandler)getServletHandler()).deferredInitialize();
/*    */   }
/*    */   
/*    */   private static class JettyEmbeddedServletHandler
/*    */     extends ServletHandler {
/*    */     private JettyEmbeddedServletHandler() {}
/*    */     
/*    */     public void initialize() throws Exception {}
/*    */     
/*    */     void deferredInitialize() throws Exception {
/* 46 */       super.initialize();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\JettyEmbeddedWebAppContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
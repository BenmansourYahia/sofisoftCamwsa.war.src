/*    */ package org.springframework.boot.web.embedded.undertow;
/*    */ 
/*    */ import io.undertow.UndertowMessages;
/*    */ import io.undertow.server.handlers.resource.Resource;
/*    */ import io.undertow.server.handlers.resource.ResourceChangeListener;
/*    */ import io.undertow.server.handlers.resource.ResourceManager;
/*    */ import io.undertow.server.handlers.resource.URLResource;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JarResourceManager
/*    */   implements ResourceManager
/*    */ {
/*    */   private final String jarPath;
/*    */   
/*    */   JarResourceManager(File jarFile) {
/* 42 */     this(jarFile.getAbsolutePath());
/*    */   }
/*    */   
/*    */   JarResourceManager(String jarPath) {
/* 46 */     this.jarPath = jarPath;
/*    */   }
/*    */ 
/*    */   
/*    */   public Resource getResource(String path) throws IOException {
/* 51 */     URL url = new URL("jar:file:" + this.jarPath + "!" + (path.startsWith("/") ? path : ("/" + path)));
/* 52 */     URLResource resource = new URLResource(url, path);
/* 53 */     if (StringUtils.hasText(path) && !"/".equals(path) && resource.getContentLength().longValue() < 0L) {
/* 54 */       return null;
/*    */     }
/* 56 */     return (Resource)resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isResourceChangeListenerSupported() {
/* 61 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerResourceChangeListener(ResourceChangeListener listener) {
/* 66 */     throw UndertowMessages.MESSAGES.resourceChangeListenerNotSupported();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeResourceChangeListener(ResourceChangeListener listener) {
/* 72 */     throw UndertowMessages.MESSAGES.resourceChangeListenerNotSupported();
/*    */   }
/*    */   
/*    */   public void close() throws IOException {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\JarResourceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
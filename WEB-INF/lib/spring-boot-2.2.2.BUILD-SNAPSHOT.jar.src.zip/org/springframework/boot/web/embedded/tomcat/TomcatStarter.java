/*    */ package org.springframework.boot.web.embedded.tomcat;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.servlet.ServletContainerInitializer;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TomcatStarter
/*    */   implements ServletContainerInitializer
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog(TomcatStarter.class);
/*    */   
/*    */   private final ServletContextInitializer[] initializers;
/*    */   
/*    */   private volatile Exception startUpException;
/*    */   
/*    */   TomcatStarter(ServletContextInitializer[] initializers) {
/* 46 */     this.initializers = initializers;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onStartup(Set<Class<?>> classes, ServletContext servletContext) throws ServletException {
/*    */     try {
/* 52 */       for (ServletContextInitializer initializer : this.initializers) {
/* 53 */         initializer.onStartup(servletContext);
/*    */       }
/*    */     }
/* 56 */     catch (Exception ex) {
/* 57 */       this.startUpException = ex;
/*    */ 
/*    */       
/* 60 */       if (logger.isErrorEnabled()) {
/* 61 */         logger.error("Error starting Tomcat context. Exception: " + ex.getClass().getName() + ". Message: " + ex
/* 62 */             .getMessage());
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   Exception getStartUpException() {
/* 68 */     return this.startUpException;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\TomcatStarter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
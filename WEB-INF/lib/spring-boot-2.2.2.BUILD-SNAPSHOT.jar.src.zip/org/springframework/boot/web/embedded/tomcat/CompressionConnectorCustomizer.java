/*    */ package org.springframework.boot.web.embedded.tomcat;
/*    */ 
/*    */ import org.apache.catalina.connector.Connector;
/*    */ import org.apache.coyote.ProtocolHandler;
/*    */ import org.apache.coyote.UpgradeProtocol;
/*    */ import org.apache.coyote.http11.AbstractHttp11Protocol;
/*    */ import org.apache.coyote.http2.Http2Protocol;
/*    */ import org.springframework.boot.web.server.Compression;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CompressionConnectorCustomizer
/*    */   implements TomcatConnectorCustomizer
/*    */ {
/*    */   private final Compression compression;
/*    */   
/*    */   CompressionConnectorCustomizer(Compression compression) {
/* 39 */     this.compression = compression;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(Connector connector) {
/* 44 */     if (this.compression != null && this.compression.getEnabled()) {
/* 45 */       ProtocolHandler handler = connector.getProtocolHandler();
/* 46 */       if (handler instanceof AbstractHttp11Protocol) {
/* 47 */         customize((AbstractHttp11Protocol)handler);
/*    */       }
/* 49 */       for (UpgradeProtocol upgradeProtocol : connector.findUpgradeProtocols()) {
/* 50 */         if (upgradeProtocol instanceof Http2Protocol) {
/* 51 */           customize((Http2Protocol)upgradeProtocol);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void customize(Http2Protocol protocol) {
/* 58 */     Compression compression = this.compression;
/* 59 */     protocol.setCompression("on");
/* 60 */     protocol.setCompressionMinSize(getMinResponseSize(compression));
/* 61 */     protocol.setCompressibleMimeType(getMimeTypes(compression));
/* 62 */     if (this.compression.getExcludedUserAgents() != null) {
/* 63 */       protocol.setNoCompressionUserAgents(getExcludedUserAgents());
/*    */     }
/*    */   }
/*    */   
/*    */   private void customize(AbstractHttp11Protocol<?> protocol) {
/* 68 */     Compression compression = this.compression;
/* 69 */     protocol.setCompression("on");
/* 70 */     protocol.setCompressionMinSize(getMinResponseSize(compression));
/* 71 */     protocol.setCompressibleMimeType(getMimeTypes(compression));
/* 72 */     if (this.compression.getExcludedUserAgents() != null) {
/* 73 */       protocol.setNoCompressionUserAgents(getExcludedUserAgents());
/*    */     }
/*    */   }
/*    */   
/*    */   private int getMinResponseSize(Compression compression) {
/* 78 */     return (int)compression.getMinResponseSize().toBytes();
/*    */   }
/*    */   
/*    */   private String getMimeTypes(Compression compression) {
/* 82 */     return StringUtils.arrayToCommaDelimitedString((Object[])compression.getMimeTypes());
/*    */   }
/*    */   
/*    */   private String getExcludedUserAgents() {
/* 86 */     return StringUtils.arrayToCommaDelimitedString((Object[])this.compression.getExcludedUserAgents());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\CompressionConnectorCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
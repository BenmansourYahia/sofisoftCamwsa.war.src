/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.servlet.UndertowServletLogger;
/*     */ import io.undertow.servlet.api.SessionPersistenceManager;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.ConfigurableObjectInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FileSessionPersistence
/*     */   implements SessionPersistenceManager
/*     */ {
/*     */   private final File dir;
/*     */   
/*     */   FileSessionPersistence(File dir) {
/*  47 */     this.dir = dir;
/*     */   }
/*     */ 
/*     */   
/*     */   public void persistSessions(String deploymentName, Map<String, SessionPersistenceManager.PersistentSession> sessionData) {
/*     */     try {
/*  53 */       save(sessionData, getSessionFile(deploymentName));
/*     */     }
/*  55 */     catch (Exception ex) {
/*  56 */       UndertowServletLogger.ROOT_LOGGER.failedToPersistSessions(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void save(Map<String, SessionPersistenceManager.PersistentSession> sessionData, File file) throws IOException {
/*  61 */     try (ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(file))) {
/*  62 */       save(sessionData, stream);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void save(Map<String, SessionPersistenceManager.PersistentSession> sessionData, ObjectOutputStream stream) throws IOException {
/*  67 */     Map<String, Serializable> session = new LinkedHashMap<>();
/*  68 */     sessionData.forEach((key, value) -> (Serializable)session.put(key, new SerializablePersistentSession(value)));
/*  69 */     stream.writeObject(session);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, SessionPersistenceManager.PersistentSession> loadSessionAttributes(String deploymentName, ClassLoader classLoader) {
/*     */     try {
/*  75 */       File file = getSessionFile(deploymentName);
/*  76 */       if (file.exists()) {
/*  77 */         return load(file, classLoader);
/*     */       }
/*     */     }
/*  80 */     catch (Exception ex) {
/*  81 */       UndertowServletLogger.ROOT_LOGGER.failedtoLoadPersistentSessions(ex);
/*     */     } 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, SessionPersistenceManager.PersistentSession> load(File file, ClassLoader classLoader) throws IOException, ClassNotFoundException {
/*  88 */     try (ConfigurableObjectInputStream null = new ConfigurableObjectInputStream(new FileInputStream(file), classLoader)) {
/*  89 */       return load((ObjectInputStream)configurableObjectInputStream);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<String, SessionPersistenceManager.PersistentSession> load(ObjectInputStream stream) throws ClassNotFoundException, IOException {
/*  94 */     Map<String, SerializablePersistentSession> session = readSession(stream);
/*  95 */     long time = System.currentTimeMillis();
/*  96 */     Map<String, SessionPersistenceManager.PersistentSession> result = new LinkedHashMap<>();
/*  97 */     session.forEach((key, value) -> {
/*     */           SessionPersistenceManager.PersistentSession entrySession = value.getPersistentSession();
/*     */           if (entrySession.getExpiration().getTime() > time) {
/*     */             result.put(key, entrySession);
/*     */           }
/*     */         });
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, SerializablePersistentSession> readSession(ObjectInputStream stream) throws ClassNotFoundException, IOException {
/* 109 */     return (Map<String, SerializablePersistentSession>)stream.readObject();
/*     */   }
/*     */   
/*     */   private File getSessionFile(String deploymentName) {
/* 113 */     if (!this.dir.exists()) {
/* 114 */       this.dir.mkdirs();
/*     */     }
/* 116 */     return new File(this.dir, deploymentName + ".session");
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear(String deploymentName) {
/* 121 */     getSessionFile(deploymentName).delete();
/*     */   }
/*     */ 
/*     */   
/*     */   static class SerializablePersistentSession
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 0L;
/*     */     
/*     */     private final Date expiration;
/*     */     
/*     */     private final Map<String, Object> sessionData;
/*     */ 
/*     */     
/*     */     SerializablePersistentSession(SessionPersistenceManager.PersistentSession session) {
/* 136 */       this.expiration = session.getExpiration();
/* 137 */       this.sessionData = new LinkedHashMap<>(session.getSessionData());
/*     */     }
/*     */     
/*     */     SessionPersistenceManager.PersistentSession getPersistentSession() {
/* 141 */       return new SessionPersistenceManager.PersistentSession(this.expiration, this.sessionData);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\FileSessionPersistence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.webresources.TomcatURLStreamHandlerFactory;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*     */ import org.apache.coyote.http11.Http11NioProtocol;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.boot.web.server.SslStoreProvider;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SslConnectorCustomizer
/*     */   implements TomcatConnectorCustomizer
/*     */ {
/*     */   private final Ssl ssl;
/*     */   private final SslStoreProvider sslStoreProvider;
/*     */   
/*     */   SslConnectorCustomizer(Ssl ssl, SslStoreProvider sslStoreProvider) {
/*  47 */     Assert.notNull(ssl, "Ssl configuration should not be null");
/*  48 */     this.ssl = ssl;
/*  49 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public void customize(Connector connector) {
/*  54 */     ProtocolHandler handler = connector.getProtocolHandler();
/*  55 */     Assert.state(handler instanceof AbstractHttp11JsseProtocol, "To use SSL, the connector's protocol handler must be an AbstractHttp11JsseProtocol subclass");
/*     */     
/*  57 */     configureSsl((AbstractHttp11JsseProtocol)handler, this.ssl, this.sslStoreProvider);
/*  58 */     connector.setScheme("https");
/*  59 */     connector.setSecure(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureSsl(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl, SslStoreProvider sslStoreProvider) {
/*  69 */     protocol.setSSLEnabled(true);
/*  70 */     protocol.setSslProtocol(ssl.getProtocol());
/*  71 */     configureSslClientAuth(protocol, ssl);
/*  72 */     protocol.setKeystorePass(ssl.getKeyStorePassword());
/*  73 */     protocol.setKeyPass(ssl.getKeyPassword());
/*  74 */     protocol.setKeyAlias(ssl.getKeyAlias());
/*  75 */     String ciphers = StringUtils.arrayToCommaDelimitedString((Object[])ssl.getCiphers());
/*  76 */     if (StringUtils.hasText(ciphers)) {
/*  77 */       protocol.setCiphers(ciphers);
/*     */     }
/*  79 */     if (ssl.getEnabledProtocols() != null) {
/*  80 */       for (SSLHostConfig sslHostConfig : protocol.findSslHostConfigs()) {
/*  81 */         sslHostConfig.setProtocols(StringUtils.arrayToCommaDelimitedString((Object[])ssl.getEnabledProtocols()));
/*     */       }
/*     */     }
/*  84 */     if (sslStoreProvider != null) {
/*  85 */       configureSslStoreProvider(protocol, sslStoreProvider);
/*     */     } else {
/*     */       
/*  88 */       configureSslKeyStore(protocol, ssl);
/*  89 */       configureSslTrustStore(protocol, ssl);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configureSslClientAuth(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl) {
/*  94 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/*  95 */       protocol.setClientAuth(Boolean.TRUE.toString());
/*     */     }
/*  97 */     else if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/*  98 */       protocol.setClientAuth("want");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureSslStoreProvider(AbstractHttp11JsseProtocol<?> protocol, SslStoreProvider sslStoreProvider) {
/* 104 */     Assert.isInstanceOf(Http11NioProtocol.class, protocol, "SslStoreProvider can only be used with Http11NioProtocol");
/*     */     
/* 106 */     TomcatURLStreamHandlerFactory instance = TomcatURLStreamHandlerFactory.getInstance();
/* 107 */     instance.addUserFactory(new SslStoreProviderUrlStreamHandlerFactory(sslStoreProvider));
/*     */     try {
/* 109 */       if (sslStoreProvider.getKeyStore() != null) {
/* 110 */         protocol.setKeystorePass("");
/* 111 */         protocol.setKeystoreFile("springbootssl:keyStore");
/*     */       } 
/* 113 */       if (sslStoreProvider.getTrustStore() != null) {
/* 114 */         protocol.setTruststorePass("");
/* 115 */         protocol.setTruststoreFile("springbootssl:trustStore");
/*     */       }
/*     */     
/* 118 */     } catch (Exception ex) {
/* 119 */       throw new WebServerException("Could not load store: " + ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configureSslKeyStore(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl) {
/*     */     try {
/* 125 */       protocol.setKeystoreFile(ResourceUtils.getURL(ssl.getKeyStore()).toString());
/*     */     }
/* 127 */     catch (Exception ex) {
/* 128 */       throw new WebServerException("Could not load key store '" + ssl.getKeyStore() + "'", ex);
/*     */     } 
/* 130 */     if (ssl.getKeyStoreType() != null) {
/* 131 */       protocol.setKeystoreType(ssl.getKeyStoreType());
/*     */     }
/* 133 */     if (ssl.getKeyStoreProvider() != null) {
/* 134 */       protocol.setKeystoreProvider(ssl.getKeyStoreProvider());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslTrustStore(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl) {
/* 139 */     if (ssl.getTrustStore() != null) {
/*     */       try {
/* 141 */         protocol.setTruststoreFile(ResourceUtils.getURL(ssl.getTrustStore()).toString());
/*     */       }
/* 143 */       catch (FileNotFoundException ex) {
/* 144 */         throw new WebServerException("Could not load trust store: " + ex.getMessage(), ex);
/*     */       } 
/*     */     }
/* 147 */     protocol.setTruststorePass(ssl.getTrustStorePassword());
/* 148 */     if (ssl.getTrustStoreType() != null) {
/* 149 */       protocol.setTruststoreType(ssl.getTrustStoreType());
/*     */     }
/* 151 */     if (ssl.getTrustStoreProvider() != null)
/* 152 */       protocol.setTruststoreProvider(ssl.getTrustStoreProvider()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\SslConnectorCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.WebResourceSet;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.core.AprLifecycleListener;
/*     */ import org.apache.catalina.loader.WebappLoader;
/*     */ import org.apache.catalina.session.StandardManager;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ import org.apache.catalina.webresources.AbstractResourceSet;
/*     */ import org.apache.catalina.webresources.EmptyResource;
/*     */ import org.apache.catalina.webresources.StandardRoot;
/*     */ import org.apache.coyote.AbstractProtocol;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.coyote.UpgradeProtocol;
/*     */ import org.apache.coyote.http2.Http2Protocol;
/*     */ import org.apache.tomcat.JarScanFilter;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.scan.StandardJarScanFilter;
/*     */ import org.springframework.boot.util.LambdaSafe;
/*     */ import org.springframework.boot.web.server.ErrorPage;
/*     */ import org.springframework.boot.web.server.MimeMappings;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.boot.web.servlet.server.AbstractServletWebServerFactory;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatServletWebServerFactory
/*     */   extends AbstractServletWebServerFactory
/*     */   implements ConfigurableTomcatWebServerFactory, ResourceLoaderAware
/*     */ {
/* 104 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */   
/* 106 */   private static final Set<Class<?>> NO_CLASSES = Collections.emptySet();
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_PROTOCOL = "org.apache.coyote.http11.Http11NioProtocol";
/*     */ 
/*     */   
/*     */   private File baseDirectory;
/*     */ 
/*     */   
/* 115 */   private List<Valve> engineValves = new ArrayList<>();
/*     */   
/* 117 */   private List<Valve> contextValves = new ArrayList<>();
/*     */   
/* 119 */   private List<LifecycleListener> contextLifecycleListeners = getDefaultLifecycleListeners();
/*     */   
/* 121 */   private Set<TomcatContextCustomizer> tomcatContextCustomizers = new LinkedHashSet<>();
/*     */   
/* 123 */   private Set<TomcatConnectorCustomizer> tomcatConnectorCustomizers = new LinkedHashSet<>();
/*     */   
/* 125 */   private Set<TomcatProtocolHandlerCustomizer<?>> tomcatProtocolHandlerCustomizers = new LinkedHashSet<>();
/*     */   
/* 127 */   private final List<Connector> additionalTomcatConnectors = new ArrayList<>();
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */   
/* 131 */   private String protocol = "org.apache.coyote.http11.Http11NioProtocol";
/*     */   
/* 133 */   private Set<String> tldSkipPatterns = new LinkedHashSet<>(TldSkipPatterns.DEFAULT);
/*     */   
/* 135 */   private Charset uriEncoding = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int backgroundProcessorDelay;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableMBeanRegistry = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TomcatServletWebServerFactory(int port) {
/* 153 */     super(port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TomcatServletWebServerFactory(String contextPath, int port) {
/* 163 */     super(contextPath, port);
/*     */   }
/*     */   
/*     */   private static List<LifecycleListener> getDefaultLifecycleListeners() {
/* 167 */     AprLifecycleListener aprLifecycleListener = new AprLifecycleListener();
/* 168 */     return AprLifecycleListener.isAprAvailable() ? new ArrayList<>((Collection)Arrays.asList((Object[])new AprLifecycleListener[] { aprLifecycleListener })) : new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServer getWebServer(ServletContextInitializer... initializers) {
/* 174 */     if (this.disableMBeanRegistry) {
/* 175 */       Registry.disableRegistry();
/*     */     }
/* 177 */     Tomcat tomcat = new Tomcat();
/* 178 */     File baseDir = (this.baseDirectory != null) ? this.baseDirectory : createTempDir("tomcat");
/* 179 */     tomcat.setBaseDir(baseDir.getAbsolutePath());
/* 180 */     Connector connector = new Connector(this.protocol);
/* 181 */     connector.setThrowOnFailure(true);
/* 182 */     tomcat.getService().addConnector(connector);
/* 183 */     customizeConnector(connector);
/* 184 */     tomcat.setConnector(connector);
/* 185 */     tomcat.getHost().setAutoDeploy(false);
/* 186 */     configureEngine(tomcat.getEngine());
/* 187 */     for (Connector additionalConnector : this.additionalTomcatConnectors) {
/* 188 */       tomcat.getService().addConnector(additionalConnector);
/*     */     }
/* 190 */     prepareContext(tomcat.getHost(), initializers);
/* 191 */     return getTomcatWebServer(tomcat);
/*     */   }
/*     */   
/*     */   private void configureEngine(Engine engine) {
/* 195 */     engine.setBackgroundProcessorDelay(this.backgroundProcessorDelay);
/* 196 */     for (Valve valve : this.engineValves) {
/* 197 */       engine.getPipeline().addValve(valve);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void prepareContext(Host host, ServletContextInitializer[] initializers) {
/* 202 */     File documentRoot = getValidDocumentRoot();
/* 203 */     TomcatEmbeddedContext context = new TomcatEmbeddedContext();
/* 204 */     if (documentRoot != null) {
/* 205 */       context.setResources((WebResourceRoot)new LoaderHidingResourceRoot(context));
/*     */     }
/* 207 */     context.setName(getContextPath());
/* 208 */     context.setDisplayName(getDisplayName());
/* 209 */     context.setPath(getContextPath());
/* 210 */     File docBase = (documentRoot != null) ? documentRoot : createTempDir("tomcat-docbase");
/* 211 */     context.setDocBase(docBase.getAbsolutePath());
/* 212 */     context.addLifecycleListener((LifecycleListener)new Tomcat.FixContextListener());
/* 213 */     context.setParentClassLoader((this.resourceLoader != null) ? this.resourceLoader.getClassLoader() : 
/* 214 */         ClassUtils.getDefaultClassLoader());
/* 215 */     resetDefaultLocaleMapping(context);
/* 216 */     addLocaleMappings(context);
/* 217 */     context.setUseRelativeRedirects(false);
/*     */     try {
/* 219 */       context.setCreateUploadTargets(true);
/*     */     }
/* 221 */     catch (NoSuchMethodError noSuchMethodError) {}
/*     */ 
/*     */     
/* 224 */     configureTldSkipPatterns(context);
/* 225 */     WebappLoader loader = new WebappLoader(context.getParentClassLoader());
/* 226 */     loader.setLoaderClass(TomcatEmbeddedWebappClassLoader.class.getName());
/* 227 */     loader.setDelegate(true);
/* 228 */     context.setLoader((Loader)loader);
/* 229 */     if (isRegisterDefaultServlet()) {
/* 230 */       addDefaultServlet((Context)context);
/*     */     }
/* 232 */     if (shouldRegisterJspServlet()) {
/* 233 */       addJspServlet((Context)context);
/* 234 */       addJasperInitializer(context);
/*     */     } 
/* 236 */     context.addLifecycleListener(new StaticResourceConfigurer((Context)context));
/* 237 */     ServletContextInitializer[] initializersToUse = mergeInitializers(initializers);
/* 238 */     host.addChild((Container)context);
/* 239 */     configureContext((Context)context, initializersToUse);
/* 240 */     postProcessContext((Context)context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetDefaultLocaleMapping(TomcatEmbeddedContext context) {
/* 249 */     context.addLocaleEncodingMappingParameter(Locale.ENGLISH.toString(), DEFAULT_CHARSET.displayName());
/* 250 */     context.addLocaleEncodingMappingParameter(Locale.FRENCH.toString(), DEFAULT_CHARSET.displayName());
/*     */   }
/*     */   
/*     */   private void addLocaleMappings(TomcatEmbeddedContext context) {
/* 254 */     getLocaleCharsetMappings().forEach((locale, charset) -> context.addLocaleEncodingMappingParameter(locale.toString(), charset.toString()));
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureTldSkipPatterns(TomcatEmbeddedContext context) {
/* 259 */     StandardJarScanFilter filter = new StandardJarScanFilter();
/* 260 */     filter.setTldSkip(StringUtils.collectionToCommaDelimitedString(this.tldSkipPatterns));
/* 261 */     context.getJarScanner().setJarScanFilter((JarScanFilter)filter);
/*     */   }
/*     */   
/*     */   private void addDefaultServlet(Context context) {
/* 265 */     Wrapper defaultServlet = context.createWrapper();
/* 266 */     defaultServlet.setName("default");
/* 267 */     defaultServlet.setServletClass("org.apache.catalina.servlets.DefaultServlet");
/* 268 */     defaultServlet.addInitParameter("debug", "0");
/* 269 */     defaultServlet.addInitParameter("listings", "false");
/* 270 */     defaultServlet.setLoadOnStartup(1);
/*     */     
/* 272 */     defaultServlet.setOverridable(true);
/* 273 */     context.addChild((Container)defaultServlet);
/* 274 */     context.addServletMappingDecoded("/", "default");
/*     */   }
/*     */   
/*     */   private void addJspServlet(Context context) {
/* 278 */     Wrapper jspServlet = context.createWrapper();
/* 279 */     jspServlet.setName("jsp");
/* 280 */     jspServlet.setServletClass(getJsp().getClassName());
/* 281 */     jspServlet.addInitParameter("fork", "false");
/* 282 */     getJsp().getInitParameters().forEach(jspServlet::addInitParameter);
/* 283 */     jspServlet.setLoadOnStartup(3);
/* 284 */     context.addChild((Container)jspServlet);
/* 285 */     context.addServletMappingDecoded("*.jsp", "jsp");
/* 286 */     context.addServletMappingDecoded("*.jspx", "jsp");
/*     */   }
/*     */ 
/*     */   
/*     */   private void addJasperInitializer(TomcatEmbeddedContext context) {
/*     */     try {
/* 292 */       ServletContainerInitializer initializer = ClassUtils.forName("org.apache.jasper.servlet.JasperInitializer", null).newInstance();
/* 293 */       context.addServletContainerInitializer(initializer, null);
/*     */     }
/* 295 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customizeConnector(Connector connector) {
/* 302 */     int port = Math.max(getPort(), 0);
/* 303 */     connector.setPort(port);
/* 304 */     if (StringUtils.hasText(getServerHeader())) {
/* 305 */       connector.setAttribute("server", getServerHeader());
/*     */     }
/* 307 */     if (connector.getProtocolHandler() instanceof AbstractProtocol) {
/* 308 */       customizeProtocol((AbstractProtocol)connector.getProtocolHandler());
/*     */     }
/* 310 */     invokeProtocolHandlerCustomizers(connector.getProtocolHandler());
/* 311 */     if (getUriEncoding() != null) {
/* 312 */       connector.setURIEncoding(getUriEncoding().name());
/*     */     }
/*     */     
/* 315 */     connector.setProperty("bindOnInit", "false");
/* 316 */     if (getSsl() != null && getSsl().isEnabled()) {
/* 317 */       customizeSsl(connector);
/*     */     }
/* 319 */     TomcatConnectorCustomizer compression = new CompressionConnectorCustomizer(getCompression());
/* 320 */     compression.customize(connector);
/* 321 */     for (TomcatConnectorCustomizer customizer : this.tomcatConnectorCustomizers) {
/* 322 */       customizer.customize(connector);
/*     */     }
/*     */   }
/*     */   
/*     */   private void customizeProtocol(AbstractProtocol<?> protocol) {
/* 327 */     if (getAddress() != null) {
/* 328 */       protocol.setAddress(getAddress());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void invokeProtocolHandlerCustomizers(ProtocolHandler protocolHandler) {
/* 334 */     LambdaSafe.callbacks(TomcatProtocolHandlerCustomizer.class, this.tomcatProtocolHandlerCustomizers, protocolHandler, new Object[0])
/* 335 */       .invoke(customizer -> customizer.customize(protocolHandler));
/*     */   }
/*     */   
/*     */   private void customizeSsl(Connector connector) {
/* 339 */     (new SslConnectorCustomizer(getSsl(), getSslStoreProvider())).customize(connector);
/* 340 */     if (getHttp2() != null && getHttp2().isEnabled()) {
/* 341 */       connector.addUpgradeProtocol((UpgradeProtocol)new Http2Protocol());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureContext(Context context, ServletContextInitializer[] initializers) {
/* 351 */     TomcatStarter starter = new TomcatStarter(initializers);
/* 352 */     if (context instanceof TomcatEmbeddedContext) {
/* 353 */       TomcatEmbeddedContext embeddedContext = (TomcatEmbeddedContext)context;
/* 354 */       embeddedContext.setStarter(starter);
/* 355 */       embeddedContext.setFailCtxIfServletStartFails(Boolean.valueOf(true));
/*     */     } 
/* 357 */     context.addServletContainerInitializer(starter, NO_CLASSES);
/* 358 */     for (LifecycleListener lifecycleListener : this.contextLifecycleListeners) {
/* 359 */       context.addLifecycleListener(lifecycleListener);
/*     */     }
/* 361 */     for (Valve valve : this.contextValves) {
/* 362 */       context.getPipeline().addValve(valve);
/*     */     }
/* 364 */     for (ErrorPage errorPage : getErrorPages()) {
/* 365 */       ErrorPage tomcatErrorPage = new ErrorPage();
/* 366 */       tomcatErrorPage.setLocation(errorPage.getPath());
/* 367 */       tomcatErrorPage.setErrorCode(errorPage.getStatusCode());
/* 368 */       tomcatErrorPage.setExceptionType(errorPage.getExceptionName());
/* 369 */       context.addErrorPage(tomcatErrorPage);
/*     */     } 
/* 371 */     for (MimeMappings.Mapping mapping : getMimeMappings()) {
/* 372 */       context.addMimeMapping(mapping.getExtension(), mapping.getMimeType());
/*     */     }
/* 374 */     configureSession(context);
/* 375 */     (new DisableReferenceClearingContextCustomizer()).customize(context);
/* 376 */     for (TomcatContextCustomizer customizer : this.tomcatContextCustomizers) {
/* 377 */       customizer.customize(context);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSession(Context context) {
/* 382 */     long sessionTimeout = getSessionTimeoutInMinutes();
/* 383 */     context.setSessionTimeout((int)sessionTimeout);
/* 384 */     Boolean httpOnly = getSession().getCookie().getHttpOnly();
/* 385 */     if (httpOnly != null) {
/* 386 */       context.setUseHttpOnly(httpOnly.booleanValue());
/*     */     }
/* 388 */     if (getSession().isPersistent()) {
/* 389 */       StandardManager standardManager; Manager manager = context.getManager();
/* 390 */       if (manager == null) {
/* 391 */         standardManager = new StandardManager();
/* 392 */         context.setManager((Manager)standardManager);
/*     */       } 
/* 394 */       configurePersistSession((Manager)standardManager);
/*     */     } else {
/*     */       
/* 397 */       context.addLifecycleListener(new DisablePersistSessionListener());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configurePersistSession(Manager manager) {
/* 402 */     Assert.state(manager instanceof StandardManager, () -> "Unable to persist HTTP session state using manager type " + manager.getClass().getName());
/*     */     
/* 404 */     File dir = getValidSessionStoreDir();
/* 405 */     File file = new File(dir, "SESSIONS.ser");
/* 406 */     ((StandardManager)manager).setPathname(file.getAbsolutePath());
/*     */   }
/*     */   
/*     */   private long getSessionTimeoutInMinutes() {
/* 410 */     Duration sessionTimeout = getSession().getTimeout();
/* 411 */     if (isZeroOrLess(sessionTimeout)) {
/* 412 */       return 0L;
/*     */     }
/* 414 */     return Math.max(sessionTimeout.toMinutes(), 1L);
/*     */   }
/*     */   
/*     */   private boolean isZeroOrLess(Duration sessionTimeout) {
/* 418 */     return (sessionTimeout == null || sessionTimeout.isNegative() || sessionTimeout.isZero());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessContext(Context context) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
/* 438 */     return new TomcatWebServer(tomcat, (getPort() >= 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 443 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBaseDirectory(File baseDirectory) {
/* 448 */     this.baseDirectory = baseDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getTldSkipPatterns() {
/* 456 */     return this.tldSkipPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTldSkipPatterns(Collection<String> patterns) {
/* 465 */     Assert.notNull(patterns, "Patterns must not be null");
/* 466 */     this.tldSkipPatterns = new LinkedHashSet<>(patterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTldSkipPatterns(String... patterns) {
/* 475 */     Assert.notNull(patterns, "Patterns must not be null");
/* 476 */     this.tldSkipPatterns.addAll(Arrays.asList(patterns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProtocol(String protocol) {
/* 485 */     Assert.hasLength(protocol, "Protocol must not be empty");
/* 486 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEngineValves(Collection<? extends Valve> engineValves) {
/* 495 */     Assert.notNull(engineValves, "Valves must not be null");
/* 496 */     this.engineValves = new ArrayList<>(engineValves);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Valve> getEngineValves() {
/* 505 */     return this.engineValves;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addEngineValves(Valve... engineValves) {
/* 510 */     Assert.notNull(engineValves, "Valves must not be null");
/* 511 */     this.engineValves.addAll(Arrays.asList(engineValves));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextValves(Collection<? extends Valve> contextValves) {
/* 520 */     Assert.notNull(contextValves, "Valves must not be null");
/* 521 */     this.contextValves = new ArrayList<>(contextValves);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Valve> getContextValves() {
/* 531 */     return this.contextValves;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContextValves(Valve... contextValves) {
/* 539 */     Assert.notNull(contextValves, "Valves must not be null");
/* 540 */     this.contextValves.addAll(Arrays.asList(contextValves));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextLifecycleListeners(Collection<? extends LifecycleListener> contextLifecycleListeners) {
/* 549 */     Assert.notNull(contextLifecycleListeners, "ContextLifecycleListeners must not be null");
/* 550 */     this.contextLifecycleListeners = new ArrayList<>(contextLifecycleListeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<LifecycleListener> getContextLifecycleListeners() {
/* 559 */     return this.contextLifecycleListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContextLifecycleListeners(LifecycleListener... contextLifecycleListeners) {
/* 567 */     Assert.notNull(contextLifecycleListeners, "ContextLifecycleListeners must not be null");
/* 568 */     this.contextLifecycleListeners.addAll(Arrays.asList(contextLifecycleListeners));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTomcatContextCustomizers(Collection<? extends TomcatContextCustomizer> tomcatContextCustomizers) {
/* 577 */     Assert.notNull(tomcatContextCustomizers, "TomcatContextCustomizers must not be null");
/* 578 */     this.tomcatContextCustomizers = new LinkedHashSet<>(tomcatContextCustomizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TomcatContextCustomizer> getTomcatContextCustomizers() {
/* 587 */     return this.tomcatContextCustomizers;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addContextCustomizers(TomcatContextCustomizer... tomcatContextCustomizers) {
/* 592 */     Assert.notNull(tomcatContextCustomizers, "TomcatContextCustomizers must not be null");
/* 593 */     this.tomcatContextCustomizers.addAll(Arrays.asList(tomcatContextCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTomcatConnectorCustomizers(Collection<? extends TomcatConnectorCustomizer> tomcatConnectorCustomizers) {
/* 603 */     Assert.notNull(tomcatConnectorCustomizers, "TomcatConnectorCustomizers must not be null");
/* 604 */     this.tomcatConnectorCustomizers = new LinkedHashSet<>(tomcatConnectorCustomizers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addConnectorCustomizers(TomcatConnectorCustomizer... tomcatConnectorCustomizers) {
/* 609 */     Assert.notNull(tomcatConnectorCustomizers, "TomcatConnectorCustomizers must not be null");
/* 610 */     this.tomcatConnectorCustomizers.addAll(Arrays.asList(tomcatConnectorCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TomcatConnectorCustomizer> getTomcatConnectorCustomizers() {
/* 619 */     return this.tomcatConnectorCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTomcatProtocolHandlerCustomizers(Collection<? extends TomcatProtocolHandlerCustomizer<?>> tomcatProtocolHandlerCustomizer) {
/* 630 */     Assert.notNull(tomcatProtocolHandlerCustomizer, "TomcatProtocolHandlerCustomizers must not be null");
/* 631 */     this.tomcatProtocolHandlerCustomizers = new LinkedHashSet<>(tomcatProtocolHandlerCustomizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addProtocolHandlerCustomizers(TomcatProtocolHandlerCustomizer<?>... tomcatProtocolHandlerCustomizers) {
/* 642 */     Assert.notNull(tomcatProtocolHandlerCustomizers, "TomcatProtocolHandlerCustomizers must not be null");
/* 643 */     this.tomcatProtocolHandlerCustomizers.addAll(Arrays.asList(tomcatProtocolHandlerCustomizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TomcatProtocolHandlerCustomizer<?>> getTomcatProtocolHandlerCustomizers() {
/* 653 */     return this.tomcatProtocolHandlerCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAdditionalTomcatConnectors(Connector... connectors) {
/* 661 */     Assert.notNull(connectors, "Connectors must not be null");
/* 662 */     this.additionalTomcatConnectors.addAll(Arrays.asList(connectors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Connector> getAdditionalTomcatConnectors() {
/* 671 */     return this.additionalTomcatConnectors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUriEncoding(Charset uriEncoding) {
/* 676 */     this.uriEncoding = uriEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getUriEncoding() {
/* 684 */     return this.uriEncoding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBackgroundProcessorDelay(int delay) {
/* 689 */     this.backgroundProcessorDelay = delay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisableMBeanRegistry(boolean disableMBeanRegistry) {
/* 699 */     this.disableMBeanRegistry = disableMBeanRegistry;
/*     */   }
/*     */ 
/*     */   
/*     */   public TomcatServletWebServerFactory() {}
/*     */   
/*     */   private static class DisablePersistSessionListener
/*     */     implements LifecycleListener
/*     */   {
/*     */     private DisablePersistSessionListener() {}
/*     */     
/*     */     public void lifecycleEvent(LifecycleEvent event) {
/* 711 */       if (event.getType().equals("start")) {
/* 712 */         Context context = (Context)event.getLifecycle();
/* 713 */         Manager manager = context.getManager();
/* 714 */         if (manager instanceof StandardManager) {
/* 715 */           ((StandardManager)manager).setPathname(null);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final class StaticResourceConfigurer
/*     */     implements LifecycleListener
/*     */   {
/*     */     private final Context context;
/*     */     
/*     */     private StaticResourceConfigurer(Context context) {
/* 727 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public void lifecycleEvent(LifecycleEvent event) {
/* 732 */       if (event.getType().equals("configure_start")) {
/* 733 */         addResourceJars(TomcatServletWebServerFactory.this.getUrlsOfJarsWithMetaInfResources());
/*     */       }
/*     */     }
/*     */     
/*     */     private void addResourceJars(List<URL> resourceJarUrls) {
/* 738 */       for (URL url : resourceJarUrls) {
/* 739 */         String path = url.getPath();
/* 740 */         if (path.endsWith(".jar") || path.endsWith(".jar!/")) {
/* 741 */           String jar = url.toString();
/* 742 */           if (!jar.startsWith("jar:"))
/*     */           {
/* 744 */             jar = "jar:" + jar + "!/";
/*     */           }
/* 746 */           addResourceSet(jar);
/*     */           continue;
/*     */         } 
/* 749 */         addResourceSet(url.toString());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void addResourceSet(String resource) {
/*     */       try {
/* 756 */         if (isInsideNestedJar(resource))
/*     */         {
/*     */ 
/*     */           
/* 760 */           resource = resource.substring(0, resource.length() - 2);
/*     */         }
/* 762 */         URL url = new URL(resource);
/* 763 */         String path = "/META-INF/resources";
/* 764 */         this.context.getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", url, path);
/*     */       }
/* 766 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isInsideNestedJar(String dir) {
/* 772 */       return (dir.indexOf("!/") < dir.lastIndexOf("!/"));
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class LoaderHidingResourceRoot
/*     */     extends StandardRoot
/*     */   {
/*     */     private LoaderHidingResourceRoot(TomcatEmbeddedContext context) {
/* 780 */       super((Context)context);
/*     */     }
/*     */ 
/*     */     
/*     */     protected WebResourceSet createMainResourceSet() {
/* 785 */       return (WebResourceSet)new TomcatServletWebServerFactory.LoaderHidingWebResourceSet(super.createMainResourceSet());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class LoaderHidingWebResourceSet
/*     */     extends AbstractResourceSet
/*     */   {
/*     */     private final WebResourceSet delegate;
/*     */     private final Method initInternal;
/*     */     
/*     */     private LoaderHidingWebResourceSet(WebResourceSet delegate) {
/* 797 */       this.delegate = delegate;
/*     */       try {
/* 799 */         this.initInternal = LifecycleBase.class.getDeclaredMethod("initInternal", new Class[0]);
/* 800 */         this.initInternal.setAccessible(true);
/*     */       }
/* 802 */       catch (Exception ex) {
/* 803 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public WebResource getResource(String path) {
/* 809 */       if (path.startsWith("/org/springframework/boot")) {
/* 810 */         return (WebResource)new EmptyResource(getRoot(), path);
/*     */       }
/* 812 */       return this.delegate.getResource(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] list(String path) {
/* 817 */       return this.delegate.list(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<String> listWebAppPaths(String path) {
/* 822 */       return (Set<String>)this.delegate.listWebAppPaths(path).stream()
/* 823 */         .filter(webAppPath -> !webAppPath.startsWith("/org/springframework/boot"))
/* 824 */         .collect(Collectors.toSet());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean mkdir(String path) {
/* 829 */       return this.delegate.mkdir(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean write(String path, InputStream is, boolean overwrite) {
/* 834 */       return this.delegate.write(path, is, overwrite);
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getBaseUrl() {
/* 839 */       return this.delegate.getBaseUrl();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setReadOnly(boolean readOnly) {
/* 844 */       this.delegate.setReadOnly(readOnly);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isReadOnly() {
/* 849 */       return this.delegate.isReadOnly();
/*     */     }
/*     */ 
/*     */     
/*     */     public void gc() {
/* 854 */       this.delegate.gc();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initInternal() throws LifecycleException {
/* 859 */       if (this.delegate instanceof LifecycleBase)
/*     */         try {
/* 861 */           ReflectionUtils.invokeMethod(this.initInternal, this.delegate);
/*     */         }
/* 863 */         catch (Exception ex) {
/* 864 */           throw new LifecycleException(ex);
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\TomcatServletWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
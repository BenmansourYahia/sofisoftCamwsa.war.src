/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.net.BindException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.core.StandardContext;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.naming.ContextBindings;
/*     */ import org.springframework.boot.web.server.PortInUseException;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatWebServer
/*     */   implements WebServer
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(TomcatWebServer.class);
/*     */   
/*  59 */   private static final AtomicInteger containerCounter = new AtomicInteger(-1);
/*     */   
/*  61 */   private final Object monitor = new Object();
/*     */   
/*  63 */   private final Map<Service, Connector[]> serviceConnectors = (Map)new HashMap<>();
/*     */ 
/*     */   
/*     */   private final Tomcat tomcat;
/*     */ 
/*     */   
/*     */   private final boolean autoStart;
/*     */ 
/*     */   
/*     */   private volatile boolean started;
/*     */ 
/*     */   
/*     */   public TomcatWebServer(Tomcat tomcat) {
/*  76 */     this(tomcat, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TomcatWebServer(Tomcat tomcat, boolean autoStart) {
/*  85 */     Assert.notNull(tomcat, "Tomcat Server must not be null");
/*  86 */     this.tomcat = tomcat;
/*  87 */     this.autoStart = autoStart;
/*  88 */     initialize();
/*     */   }
/*     */   
/*     */   private void initialize() throws WebServerException {
/*  92 */     logger.info("Tomcat initialized with port(s): " + getPortsDescription(false));
/*  93 */     synchronized (this.monitor) {
/*     */       try {
/*  95 */         addInstanceIdToEngineName();
/*     */         
/*  97 */         Context context = findContext();
/*  98 */         context.addLifecycleListener(event -> {
/*     */               if (context.equals(event.getSource()) && "start".equals(event.getType())) {
/*     */                 removeServiceConnectors();
/*     */               }
/*     */             });
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 107 */         this.tomcat.start();
/*     */ 
/*     */         
/* 110 */         rethrowDeferredStartupExceptions();
/*     */         
/*     */         try {
/* 113 */           ContextBindings.bindClassLoader(context, context.getNamingToken(), getClass().getClassLoader());
/*     */         }
/* 115 */         catch (NamingException namingException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 121 */         startDaemonAwaitThread();
/*     */       }
/* 123 */       catch (Exception ex) {
/* 124 */         stopSilently();
/* 125 */         destroySilently();
/* 126 */         throw new WebServerException("Unable to start embedded Tomcat", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Context findContext() {
/* 132 */     for (Container child : this.tomcat.getHost().findChildren()) {
/* 133 */       if (child instanceof Context) {
/* 134 */         return (Context)child;
/*     */       }
/*     */     } 
/* 137 */     throw new IllegalStateException("The host does not contain a Context");
/*     */   }
/*     */   
/*     */   private void addInstanceIdToEngineName() {
/* 141 */     int instanceId = containerCounter.incrementAndGet();
/* 142 */     if (instanceId > 0) {
/* 143 */       Engine engine = this.tomcat.getEngine();
/* 144 */       engine.setName(engine.getName() + "-" + instanceId);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeServiceConnectors() {
/* 149 */     for (Service service : this.tomcat.getServer().findServices()) {
/* 150 */       Connector[] connectors = (Connector[])service.findConnectors().clone();
/* 151 */       this.serviceConnectors.put(service, connectors);
/* 152 */       for (Connector connector : connectors) {
/* 153 */         service.removeConnector(connector);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void rethrowDeferredStartupExceptions() throws Exception {
/* 159 */     Container[] children = this.tomcat.getHost().findChildren();
/* 160 */     for (Container container : children) {
/* 161 */       if (container instanceof TomcatEmbeddedContext) {
/* 162 */         TomcatStarter tomcatStarter = ((TomcatEmbeddedContext)container).getStarter();
/* 163 */         if (tomcatStarter != null) {
/* 164 */           Exception exception = tomcatStarter.getStartUpException();
/* 165 */           if (exception != null) {
/* 166 */             throw exception;
/*     */           }
/*     */         } 
/*     */       } 
/* 170 */       if (!LifecycleState.STARTED.equals(container.getState())) {
/* 171 */         throw new IllegalStateException(container + " failed to start");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void startDaemonAwaitThread() {
/* 177 */     Thread awaitThread = new Thread("container-" + containerCounter.get())
/*     */       {
/*     */         public void run()
/*     */         {
/* 181 */           TomcatWebServer.this.tomcat.getServer().await();
/*     */         }
/*     */       };
/*     */     
/* 185 */     awaitThread.setContextClassLoader(getClass().getClassLoader());
/* 186 */     awaitThread.setDaemon(false);
/* 187 */     awaitThread.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() throws WebServerException {
/* 192 */     synchronized (this.monitor) {
/* 193 */       if (this.started) {
/*     */         return;
/*     */       }
/*     */       try {
/* 197 */         addPreviouslyRemovedConnectors();
/* 198 */         Connector connector = this.tomcat.getConnector();
/* 199 */         if (connector != null && this.autoStart) {
/* 200 */           performDeferredLoadOnStartup();
/*     */         }
/* 202 */         checkThatConnectorsHaveStarted();
/* 203 */         this.started = true;
/* 204 */         logger.info("Tomcat started on port(s): " + getPortsDescription(true) + " with context path '" + 
/* 205 */             getContextPath() + "'");
/*     */       }
/* 207 */       catch (ConnectorStartFailedException ex) {
/* 208 */         stopSilently();
/* 209 */         throw ex;
/*     */       }
/* 211 */       catch (Exception ex) {
/* 212 */         if (findBindException(ex) != null) {
/* 213 */           throw new PortInUseException(this.tomcat.getConnector().getPort());
/*     */         }
/* 215 */         throw new WebServerException("Unable to start embedded Tomcat server", ex);
/*     */       } finally {
/*     */         
/* 218 */         Context context = findContext();
/* 219 */         ContextBindings.unbindClassLoader(context, context.getNamingToken(), getClass().getClassLoader());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkThatConnectorsHaveStarted() {
/* 225 */     checkConnectorHasStarted(this.tomcat.getConnector());
/* 226 */     for (Connector connector : this.tomcat.getService().findConnectors()) {
/* 227 */       checkConnectorHasStarted(connector);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkConnectorHasStarted(Connector connector) {
/* 232 */     if (LifecycleState.FAILED.equals(connector.getState())) {
/* 233 */       throw new ConnectorStartFailedException(connector.getPort());
/*     */     }
/*     */   }
/*     */   
/*     */   private BindException findBindException(Throwable ex) {
/* 238 */     if (ex == null) {
/* 239 */       return null;
/*     */     }
/* 241 */     if (ex instanceof BindException) {
/* 242 */       return (BindException)ex;
/*     */     }
/* 244 */     return findBindException(ex.getCause());
/*     */   }
/*     */   
/*     */   private void stopSilently() {
/*     */     try {
/* 249 */       stopTomcat();
/*     */     }
/* 251 */     catch (LifecycleException lifecycleException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void destroySilently() {
/*     */     try {
/* 258 */       this.tomcat.destroy();
/*     */     }
/* 260 */     catch (LifecycleException lifecycleException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void stopTomcat() throws LifecycleException {
/* 266 */     if (Thread.currentThread().getContextClassLoader() instanceof TomcatEmbeddedWebappClassLoader) {
/* 267 */       Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*     */     }
/* 269 */     this.tomcat.stop();
/*     */   }
/*     */   
/*     */   private void addPreviouslyRemovedConnectors() {
/* 273 */     Service[] services = this.tomcat.getServer().findServices();
/* 274 */     for (Service service : services) {
/* 275 */       Connector[] connectors = this.serviceConnectors.get(service);
/* 276 */       if (connectors != null) {
/* 277 */         for (Connector connector : connectors) {
/* 278 */           service.addConnector(connector);
/* 279 */           if (!this.autoStart) {
/* 280 */             stopProtocolHandler(connector);
/*     */           }
/*     */         } 
/* 283 */         this.serviceConnectors.remove(service);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void stopProtocolHandler(Connector connector) {
/*     */     try {
/* 290 */       connector.getProtocolHandler().stop();
/*     */     }
/* 292 */     catch (Exception ex) {
/* 293 */       logger.error("Cannot pause connector: ", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void performDeferredLoadOnStartup() {
/*     */     try {
/* 299 */       for (Container child : this.tomcat.getHost().findChildren()) {
/* 300 */         if (child instanceof TomcatEmbeddedContext) {
/* 301 */           ((TomcatEmbeddedContext)child).deferredLoadOnStartup();
/*     */         }
/*     */       }
/*     */     
/* 305 */     } catch (Exception ex) {
/* 306 */       if (ex instanceof WebServerException) {
/* 307 */         throw (WebServerException)ex;
/*     */       }
/* 309 */       throw new WebServerException("Unable to start embedded Tomcat connectors", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   Map<Service, Connector[]> getServiceConnectors() {
/* 314 */     return this.serviceConnectors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() throws WebServerException {
/* 319 */     synchronized (this.monitor) {
/* 320 */       boolean wasStarted = this.started;
/*     */       try {
/* 322 */         this.started = false;
/*     */         try {
/* 324 */           stopTomcat();
/* 325 */           this.tomcat.destroy();
/*     */         }
/* 327 */         catch (LifecycleException lifecycleException) {}
/*     */ 
/*     */       
/*     */       }
/* 331 */       catch (Exception ex) {
/* 332 */         throw new WebServerException("Unable to stop embedded Tomcat", ex);
/*     */       } finally {
/*     */         
/* 335 */         if (wasStarted) {
/* 336 */           containerCounter.decrementAndGet();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getPortsDescription(boolean localPort) {
/* 343 */     StringBuilder ports = new StringBuilder();
/* 344 */     for (Connector connector : this.tomcat.getService().findConnectors()) {
/* 345 */       if (ports.length() != 0) {
/* 346 */         ports.append(' ');
/*     */       }
/* 348 */       int port = localPort ? connector.getLocalPort() : connector.getPort();
/* 349 */       ports.append(port).append(" (").append(connector.getScheme()).append(')');
/*     */     } 
/* 351 */     return ports.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 356 */     Connector connector = this.tomcat.getConnector();
/* 357 */     if (connector != null) {
/* 358 */       return connector.getLocalPort();
/*     */     }
/* 360 */     return 0;
/*     */   }
/*     */   
/*     */   private String getContextPath() {
/* 364 */     return Arrays.<Container>stream(this.tomcat.getHost().findChildren()).filter(TomcatEmbeddedContext.class::isInstance)
/* 365 */       .map(TomcatEmbeddedContext.class::cast).map(StandardContext::getPath)
/* 366 */       .collect(Collectors.joining(" "));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tomcat getTomcat() {
/* 374 */     return this.tomcat;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\TomcatWebServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
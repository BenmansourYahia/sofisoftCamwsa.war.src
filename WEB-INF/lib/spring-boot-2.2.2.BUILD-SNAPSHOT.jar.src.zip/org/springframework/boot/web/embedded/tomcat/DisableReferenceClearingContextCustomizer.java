/*    */ package org.springframework.boot.web.embedded.tomcat;
/*    */ 
/*    */ import org.apache.catalina.Context;
/*    */ import org.apache.catalina.core.StandardContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DisableReferenceClearingContextCustomizer
/*    */   implements TomcatContextCustomizer
/*    */ {
/*    */   public void customize(Context context) {
/* 32 */     if (!(context instanceof StandardContext)) {
/*    */       return;
/*    */     }
/* 35 */     StandardContext standardContext = (StandardContext)context;
/*    */     try {
/* 37 */       standardContext.setClearReferencesObjectStreamClassCaches(false);
/* 38 */       standardContext.setClearReferencesRmiTargets(false);
/* 39 */       standardContext.setClearReferencesThreadLocals(false);
/*    */     }
/* 41 */     catch (NoSuchMethodError noSuchMethodError) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\DisableReferenceClearingContextCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
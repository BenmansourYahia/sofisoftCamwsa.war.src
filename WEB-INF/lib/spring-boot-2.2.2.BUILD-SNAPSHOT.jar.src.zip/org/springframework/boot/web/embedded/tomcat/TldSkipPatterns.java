/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TldSkipPatterns
/*     */ {
/*     */   private static final Set<String> TOMCAT;
/*     */   private static final Set<String> ADDITIONAL;
/*     */   static final Set<String> DEFAULT;
/*     */   
/*     */   static {
/*  34 */     Set<String> patterns = new LinkedHashSet<>();
/*  35 */     patterns.add("ant-*.jar");
/*  36 */     patterns.add("aspectj*.jar");
/*  37 */     patterns.add("commons-beanutils*.jar");
/*  38 */     patterns.add("commons-codec*.jar");
/*  39 */     patterns.add("commons-collections*.jar");
/*  40 */     patterns.add("commons-dbcp*.jar");
/*  41 */     patterns.add("commons-digester*.jar");
/*  42 */     patterns.add("commons-fileupload*.jar");
/*  43 */     patterns.add("commons-httpclient*.jar");
/*  44 */     patterns.add("commons-io*.jar");
/*  45 */     patterns.add("commons-lang*.jar");
/*  46 */     patterns.add("commons-logging*.jar");
/*  47 */     patterns.add("commons-math*.jar");
/*  48 */     patterns.add("commons-pool*.jar");
/*  49 */     patterns.add("geronimo-spec-jaxrpc*.jar");
/*  50 */     patterns.add("h2*.jar");
/*  51 */     patterns.add("hamcrest*.jar");
/*  52 */     patterns.add("hibernate*.jar");
/*  53 */     patterns.add("jaxb-runtime-*.jar");
/*  54 */     patterns.add("jmx*.jar");
/*  55 */     patterns.add("jmx-tools-*.jar");
/*  56 */     patterns.add("jta*.jar");
/*  57 */     patterns.add("junit-*.jar");
/*  58 */     patterns.add("httpclient*.jar");
/*  59 */     patterns.add("log4j-*.jar");
/*  60 */     patterns.add("mail*.jar");
/*  61 */     patterns.add("org.hamcrest*.jar");
/*  62 */     patterns.add("slf4j*.jar");
/*  63 */     patterns.add("tomcat-embed-core-*.jar");
/*  64 */     patterns.add("tomcat-embed-logging-*.jar");
/*  65 */     patterns.add("tomcat-jdbc-*.jar");
/*  66 */     patterns.add("tomcat-juli-*.jar");
/*  67 */     patterns.add("tools.jar");
/*  68 */     patterns.add("wsdl4j*.jar");
/*  69 */     patterns.add("xercesImpl-*.jar");
/*  70 */     patterns.add("xmlParserAPIs-*.jar");
/*  71 */     patterns.add("xml-apis-*.jar");
/*  72 */     TOMCAT = Collections.unmodifiableSet(patterns);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     patterns = new LinkedHashSet<>();
/*  80 */     patterns.add("antlr-*.jar");
/*  81 */     patterns.add("aopalliance-*.jar");
/*  82 */     patterns.add("aspectjrt-*.jar");
/*  83 */     patterns.add("aspectjweaver-*.jar");
/*  84 */     patterns.add("classmate-*.jar");
/*  85 */     patterns.add("dom4j-*.jar");
/*  86 */     patterns.add("ecj-*.jar");
/*  87 */     patterns.add("ehcache-core-*.jar");
/*  88 */     patterns.add("hibernate-core-*.jar");
/*  89 */     patterns.add("hibernate-commons-annotations-*.jar");
/*  90 */     patterns.add("hibernate-entitymanager-*.jar");
/*  91 */     patterns.add("hibernate-jpa-2.1-api-*.jar");
/*  92 */     patterns.add("hibernate-validator-*.jar");
/*  93 */     patterns.add("hsqldb-*.jar");
/*  94 */     patterns.add("jackson-annotations-*.jar");
/*  95 */     patterns.add("jackson-core-*.jar");
/*  96 */     patterns.add("jackson-databind-*.jar");
/*  97 */     patterns.add("jandex-*.jar");
/*  98 */     patterns.add("javassist-*.jar");
/*  99 */     patterns.add("jboss-logging-*.jar");
/* 100 */     patterns.add("jboss-transaction-api_*.jar");
/* 101 */     patterns.add("jcl-over-slf4j-*.jar");
/* 102 */     patterns.add("jdom-*.jar");
/* 103 */     patterns.add("jul-to-slf4j-*.jar");
/* 104 */     patterns.add("log4j-over-slf4j-*.jar");
/* 105 */     patterns.add("logback-classic-*.jar");
/* 106 */     patterns.add("logback-core-*.jar");
/* 107 */     patterns.add("rome-*.jar");
/* 108 */     patterns.add("slf4j-api-*.jar");
/* 109 */     patterns.add("spring-aop-*.jar");
/* 110 */     patterns.add("spring-aspects-*.jar");
/* 111 */     patterns.add("spring-beans-*.jar");
/* 112 */     patterns.add("spring-boot-*.jar");
/* 113 */     patterns.add("spring-core-*.jar");
/* 114 */     patterns.add("spring-context-*.jar");
/* 115 */     patterns.add("spring-data-*.jar");
/* 116 */     patterns.add("spring-expression-*.jar");
/* 117 */     patterns.add("spring-jdbc-*.jar,");
/* 118 */     patterns.add("spring-orm-*.jar");
/* 119 */     patterns.add("spring-oxm-*.jar");
/* 120 */     patterns.add("spring-tx-*.jar");
/* 121 */     patterns.add("snakeyaml-*.jar");
/* 122 */     patterns.add("tomcat-embed-el-*.jar");
/* 123 */     patterns.add("validation-api-*.jar");
/* 124 */     patterns.add("xml-apis-*.jar");
/* 125 */     ADDITIONAL = Collections.unmodifiableSet(patterns);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     patterns = new LinkedHashSet<>();
/* 132 */     patterns.addAll(TOMCAT);
/* 133 */     patterns.addAll(ADDITIONAL);
/* 134 */     DEFAULT = Collections.unmodifiableSet(patterns);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\TldSkipPatterns.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot.web.embedded.tomcat;

import java.io.File;
import java.nio.charset.Charset;
import org.apache.catalina.Valve;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;

public interface ConfigurableTomcatWebServerFactory extends ConfigurableWebServerFactory {
  void setBaseDirectory(File paramFile);
  
  void setBackgroundProcessorDelay(int paramInt);
  
  void addEngineValves(Valve... paramVarArgs);
  
  void addConnectorCustomizers(TomcatConnectorCustomizer... paramVarArgs);
  
  void addContextCustomizers(TomcatContextCustomizer... paramVarArgs);
  
  void addProtocolHandlerCustomizers(TomcatProtocolHandlerCustomizer<?>... paramVarArgs);
  
  void setUriEncoding(Charset paramCharset);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\ConfigurableTomcatWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
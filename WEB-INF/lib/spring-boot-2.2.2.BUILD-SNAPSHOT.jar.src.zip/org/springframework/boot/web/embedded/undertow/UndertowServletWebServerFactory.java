/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import io.undertow.UndertowOptions;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.handlers.accesslog.AccessLogHandler;
/*     */ import io.undertow.server.handlers.accesslog.AccessLogReceiver;
/*     */ import io.undertow.server.handlers.accesslog.DefaultAccessLogReceiver;
/*     */ import io.undertow.server.handlers.resource.FileResourceManager;
/*     */ import io.undertow.server.handlers.resource.Resource;
/*     */ import io.undertow.server.handlers.resource.ResourceChangeListener;
/*     */ import io.undertow.server.handlers.resource.ResourceManager;
/*     */ import io.undertow.server.handlers.resource.URLResource;
/*     */ import io.undertow.server.session.SessionManager;
/*     */ import io.undertow.servlet.Servlets;
/*     */ import io.undertow.servlet.api.DeploymentInfo;
/*     */ import io.undertow.servlet.api.DeploymentManager;
/*     */ import io.undertow.servlet.api.ErrorPage;
/*     */ import io.undertow.servlet.api.InstanceFactory;
/*     */ import io.undertow.servlet.api.ListenerInfo;
/*     */ import io.undertow.servlet.api.MimeMapping;
/*     */ import io.undertow.servlet.api.ServletContainerInitializerInfo;
/*     */ import io.undertow.servlet.api.ServletStackTraces;
/*     */ import io.undertow.servlet.core.DeploymentImpl;
/*     */ import io.undertow.servlet.handlers.DefaultServlet;
/*     */ import io.undertow.servlet.util.ImmediateInstanceFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import javax.servlet.ServletContextListener;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.boot.web.server.ErrorPage;
/*     */ import org.springframework.boot.web.server.MimeMappings;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.boot.web.servlet.server.AbstractServletWebServerFactory;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.xnio.OptionMap;
/*     */ import org.xnio.Options;
/*     */ import org.xnio.Xnio;
/*     */ import org.xnio.XnioWorker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowServletWebServerFactory
/*     */   extends AbstractServletWebServerFactory
/*     */   implements ConfigurableUndertowWebServerFactory, ResourceLoaderAware
/*     */ {
/*  99 */   private static final Pattern ENCODED_SLASH = Pattern.compile("%2F", 16);
/*     */   
/* 101 */   private static final Set<Class<?>> NO_CLASSES = Collections.emptySet();
/*     */   
/* 103 */   private Set<UndertowBuilderCustomizer> builderCustomizers = new LinkedHashSet<>();
/*     */   
/* 105 */   private Set<UndertowDeploymentInfoCustomizer> deploymentInfoCustomizers = new LinkedHashSet<>();
/*     */ 
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */ 
/*     */   
/*     */   private Integer bufferSize;
/*     */   
/*     */   private Integer ioThreads;
/*     */   
/*     */   private Integer workerThreads;
/*     */   
/*     */   private Boolean directBuffers;
/*     */   
/*     */   private File accessLogDirectory;
/*     */   
/*     */   private String accessLogPattern;
/*     */   
/*     */   private String accessLogPrefix;
/*     */   
/*     */   private String accessLogSuffix;
/*     */   
/*     */   private boolean accessLogEnabled = false;
/*     */   
/*     */   private boolean accessLogRotate = true;
/*     */   
/*     */   private boolean useForwardHeaders;
/*     */   
/*     */   private boolean eagerInitFilters = true;
/*     */ 
/*     */   
/*     */   public UndertowServletWebServerFactory() {
/* 137 */     getJsp().setRegistered(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UndertowServletWebServerFactory(int port) {
/* 146 */     super(port);
/* 147 */     getJsp().setRegistered(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UndertowServletWebServerFactory(String contextPath, int port) {
/* 157 */     super(contextPath, port);
/* 158 */     getJsp().setRegistered(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuilderCustomizers(Collection<? extends UndertowBuilderCustomizer> customizers) {
/* 167 */     Assert.notNull(customizers, "Customizers must not be null");
/* 168 */     this.builderCustomizers = new LinkedHashSet<>(customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<UndertowBuilderCustomizer> getBuilderCustomizers() {
/* 177 */     return this.builderCustomizers;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addBuilderCustomizers(UndertowBuilderCustomizer... customizers) {
/* 182 */     Assert.notNull(customizers, "Customizers must not be null");
/* 183 */     this.builderCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeploymentInfoCustomizers(Collection<? extends UndertowDeploymentInfoCustomizer> customizers) {
/* 193 */     Assert.notNull(customizers, "Customizers must not be null");
/* 194 */     this.deploymentInfoCustomizers = new LinkedHashSet<>(customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<UndertowDeploymentInfoCustomizer> getDeploymentInfoCustomizers() {
/* 203 */     return this.deploymentInfoCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDeploymentInfoCustomizers(UndertowDeploymentInfoCustomizer... customizers) {
/* 212 */     Assert.notNull(customizers, "UndertowDeploymentInfoCustomizers must not be null");
/* 213 */     this.deploymentInfoCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */ 
/*     */   
/*     */   public WebServer getWebServer(ServletContextInitializer... initializers) {
/* 218 */     DeploymentManager manager = createDeploymentManager(initializers);
/* 219 */     int port = getPort();
/* 220 */     Undertow.Builder builder = createBuilder(port);
/* 221 */     return getUndertowWebServer(builder, manager, port);
/*     */   }
/*     */   
/*     */   private Undertow.Builder createBuilder(int port) {
/* 225 */     Undertow.Builder builder = Undertow.builder();
/* 226 */     if (this.bufferSize != null) {
/* 227 */       builder.setBufferSize(this.bufferSize.intValue());
/*     */     }
/* 229 */     if (this.ioThreads != null) {
/* 230 */       builder.setIoThreads(this.ioThreads.intValue());
/*     */     }
/* 232 */     if (this.workerThreads != null) {
/* 233 */       builder.setWorkerThreads(this.workerThreads.intValue());
/*     */     }
/* 235 */     if (this.directBuffers != null) {
/* 236 */       builder.setDirectBuffers(this.directBuffers.booleanValue());
/*     */     }
/* 238 */     if (getSsl() != null && getSsl().isEnabled()) {
/* 239 */       customizeSsl(builder);
/*     */     } else {
/*     */       
/* 242 */       builder.addHttpListener(port, getListenAddress());
/*     */     } 
/* 244 */     for (UndertowBuilderCustomizer customizer : this.builderCustomizers) {
/* 245 */       customizer.customize(builder);
/*     */     }
/* 247 */     return builder;
/*     */   }
/*     */   
/*     */   private void customizeSsl(Undertow.Builder builder) {
/* 251 */     (new SslBuilderCustomizer(getPort(), getAddress(), getSsl(), getSslStoreProvider())).customize(builder);
/* 252 */     if (getHttp2() != null) {
/* 253 */       builder.setServerOption(UndertowOptions.ENABLE_HTTP2, Boolean.valueOf(getHttp2().isEnabled()));
/*     */     }
/*     */   }
/*     */   
/*     */   private String getListenAddress() {
/* 258 */     if (getAddress() == null) {
/* 259 */       return "0.0.0.0";
/*     */     }
/* 261 */     return getAddress().getHostAddress();
/*     */   }
/*     */   
/*     */   private DeploymentManager createDeploymentManager(ServletContextInitializer... initializers) {
/* 265 */     DeploymentInfo deployment = Servlets.deployment();
/* 266 */     registerServletContainerInitializerToDriveServletContextInitializers(deployment, initializers);
/* 267 */     deployment.setClassLoader(getServletClassLoader());
/* 268 */     deployment.setContextPath(getContextPath());
/* 269 */     deployment.setDisplayName(getDisplayName());
/* 270 */     deployment.setDeploymentName("spring-boot");
/* 271 */     if (isRegisterDefaultServlet()) {
/* 272 */       deployment.addServlet(Servlets.servlet("default", DefaultServlet.class));
/*     */     }
/* 274 */     configureErrorPages(deployment);
/* 275 */     deployment.setServletStackTraces(ServletStackTraces.NONE);
/* 276 */     deployment.setResourceManager(getDocumentRootResourceManager());
/* 277 */     deployment.setTempDir(createTempDir("undertow"));
/* 278 */     deployment.setEagerFilterInit(this.eagerInitFilters);
/* 279 */     configureMimeMappings(deployment);
/* 280 */     for (UndertowDeploymentInfoCustomizer customizer : this.deploymentInfoCustomizers) {
/* 281 */       customizer.customize(deployment);
/*     */     }
/* 283 */     if (isAccessLogEnabled()) {
/* 284 */       configureAccessLog(deployment);
/*     */     }
/* 286 */     if (getSession().isPersistent()) {
/* 287 */       File dir = getValidSessionStoreDir();
/* 288 */       deployment.setSessionPersistenceManager(new FileSessionPersistence(dir));
/*     */     } 
/* 290 */     addLocaleMappings(deployment);
/* 291 */     DeploymentManager manager = Servlets.newContainer().addDeployment(deployment);
/* 292 */     manager.deploy();
/* 293 */     if (manager.getDeployment() instanceof DeploymentImpl) {
/* 294 */       removeSuperfluousMimeMappings((DeploymentImpl)manager.getDeployment(), deployment);
/*     */     }
/* 296 */     SessionManager sessionManager = manager.getDeployment().getSessionManager();
/* 297 */     Duration timeoutDuration = getSession().getTimeout();
/* 298 */     int sessionTimeout = isZeroOrLess(timeoutDuration) ? -1 : (int)timeoutDuration.getSeconds();
/* 299 */     sessionManager.setDefaultSessionTimeout(sessionTimeout);
/* 300 */     return manager;
/*     */   }
/*     */   
/*     */   private boolean isZeroOrLess(Duration timeoutDuration) {
/* 304 */     return (timeoutDuration == null || timeoutDuration.isZero() || timeoutDuration.isNegative());
/*     */   }
/*     */   
/*     */   private void configureAccessLog(DeploymentInfo deploymentInfo) {
/*     */     try {
/* 309 */       createAccessLogDirectoryIfNecessary();
/* 310 */       XnioWorker worker = createWorker();
/* 311 */       String prefix = (this.accessLogPrefix != null) ? this.accessLogPrefix : "access_log.";
/* 312 */       DefaultAccessLogReceiver accessLogReceiver = new DefaultAccessLogReceiver((Executor)worker, this.accessLogDirectory, prefix, this.accessLogSuffix, this.accessLogRotate);
/*     */       
/* 314 */       AccessLogShutdownListener accessLogShutdownListener = new AccessLogShutdownListener(worker, accessLogReceiver);
/* 315 */       deploymentInfo.addListener(new ListenerInfo(AccessLogShutdownListener.class, (InstanceFactory)new ImmediateInstanceFactory(accessLogShutdownListener)));
/*     */       
/* 317 */       deploymentInfo
/* 318 */         .addInitialHandlerChainWrapper(handler -> createAccessLogHandler(handler, (AccessLogReceiver)accessLogReceiver));
/*     */     }
/* 320 */     catch (IOException ex) {
/* 321 */       throw new IllegalStateException("Failed to create AccessLogHandler", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private AccessLogHandler createAccessLogHandler(HttpHandler handler, AccessLogReceiver accessLogReceiver) {
/* 326 */     createAccessLogDirectoryIfNecessary();
/* 327 */     String formatString = (this.accessLogPattern != null) ? this.accessLogPattern : "common";
/* 328 */     return new AccessLogHandler(handler, accessLogReceiver, formatString, Undertow.class.getClassLoader());
/*     */   }
/*     */   
/*     */   private void createAccessLogDirectoryIfNecessary() {
/* 332 */     Assert.state((this.accessLogDirectory != null), "Access log directory is not set");
/* 333 */     if (!this.accessLogDirectory.isDirectory() && !this.accessLogDirectory.mkdirs()) {
/* 334 */       throw new IllegalStateException("Failed to create access log directory '" + this.accessLogDirectory + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   private XnioWorker createWorker() throws IOException {
/* 339 */     Xnio xnio = Xnio.getInstance(Undertow.class.getClassLoader());
/* 340 */     return xnio.createWorker(OptionMap.builder().set(Options.THREAD_DAEMON, true).getMap());
/*     */   }
/*     */   
/*     */   private void addLocaleMappings(DeploymentInfo deployment) {
/* 344 */     getLocaleCharsetMappings().forEach((locale, charset) -> deployment.addLocaleCharsetMapping(locale.toString(), charset.toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerServletContainerInitializerToDriveServletContextInitializers(DeploymentInfo deployment, ServletContextInitializer... initializers) {
/* 350 */     ServletContextInitializer[] mergedInitializers = mergeInitializers(initializers);
/* 351 */     Initializer initializer = new Initializer(mergedInitializers);
/* 352 */     deployment.addServletContainerInitializer(new ServletContainerInitializerInfo(Initializer.class, (InstanceFactory)new ImmediateInstanceFactory(initializer), NO_CLASSES));
/*     */   }
/*     */ 
/*     */   
/*     */   private ClassLoader getServletClassLoader() {
/* 357 */     if (this.resourceLoader != null) {
/* 358 */       return this.resourceLoader.getClassLoader();
/*     */     }
/* 360 */     return getClass().getClassLoader();
/*     */   }
/*     */   
/*     */   private ResourceManager getDocumentRootResourceManager() {
/* 364 */     File root = getValidDocumentRoot();
/* 365 */     File docBase = getCanonicalDocumentRoot(root);
/* 366 */     List<URL> metaInfResourceUrls = getUrlsOfJarsWithMetaInfResources();
/* 367 */     List<URL> resourceJarUrls = new ArrayList<>();
/* 368 */     List<ResourceManager> managers = new ArrayList<>();
/* 369 */     ResourceManager rootManager = docBase.isDirectory() ? (ResourceManager)new FileResourceManager(docBase, 0L) : new JarResourceManager(docBase);
/*     */     
/* 371 */     if (root != null) {
/* 372 */       rootManager = new LoaderHidingResourceManager(rootManager);
/*     */     }
/* 374 */     managers.add(rootManager);
/* 375 */     for (URL url : metaInfResourceUrls) {
/* 376 */       if ("file".equals(url.getProtocol())) {
/*     */         try {
/* 378 */           File file = new File(url.toURI());
/* 379 */           if (file.isFile()) {
/* 380 */             resourceJarUrls.add(new URL("jar:" + url + "!/"));
/*     */             continue;
/*     */           } 
/* 383 */           managers.add(new FileResourceManager(new File(file, "META-INF/resources"), 0L));
/*     */         
/*     */         }
/* 386 */         catch (Exception ex) {
/* 387 */           throw new RuntimeException(ex);
/*     */         } 
/*     */         continue;
/*     */       } 
/* 391 */       resourceJarUrls.add(url);
/*     */     } 
/*     */     
/* 394 */     managers.add(new MetaInfResourcesResourceManager(resourceJarUrls));
/* 395 */     return new CompositeResourceManager(managers.<ResourceManager>toArray(new ResourceManager[0]));
/*     */   }
/*     */   
/*     */   private File getCanonicalDocumentRoot(File docBase) {
/*     */     try {
/* 400 */       File root = (docBase != null) ? docBase : createTempDir("undertow-docbase");
/* 401 */       return root.getCanonicalFile();
/*     */     }
/* 403 */     catch (IOException ex) {
/* 404 */       throw new IllegalStateException("Cannot get canonical document root", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configureErrorPages(DeploymentInfo servletBuilder) {
/* 409 */     for (ErrorPage errorPage : getErrorPages()) {
/* 410 */       servletBuilder.addErrorPage(getUndertowErrorPage(errorPage));
/*     */     }
/*     */   }
/*     */   
/*     */   private ErrorPage getUndertowErrorPage(ErrorPage errorPage) {
/* 415 */     if (errorPage.getStatus() != null) {
/* 416 */       return new ErrorPage(errorPage.getPath(), errorPage.getStatusCode());
/*     */     }
/* 418 */     if (errorPage.getException() != null) {
/* 419 */       return new ErrorPage(errorPage.getPath(), errorPage.getException());
/*     */     }
/* 421 */     return new ErrorPage(errorPage.getPath());
/*     */   }
/*     */   
/*     */   private void configureMimeMappings(DeploymentInfo servletBuilder) {
/* 425 */     for (MimeMappings.Mapping mimeMapping : getMimeMappings()) {
/* 426 */       servletBuilder.addMimeMapping(new MimeMapping(mimeMapping.getExtension(), mimeMapping.getMimeType()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeSuperfluousMimeMappings(DeploymentImpl deployment, DeploymentInfo deploymentInfo) {
/* 433 */     Map<String, String> mappings = new HashMap<>();
/* 434 */     for (MimeMapping mapping : deploymentInfo.getMimeMappings()) {
/* 435 */       mappings.put(mapping.getExtension().toLowerCase(Locale.ENGLISH), mapping.getMimeType());
/*     */     }
/* 437 */     deployment.setMimeExtensionMappings(mappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UndertowServletWebServer getUndertowWebServer(Undertow.Builder builder, DeploymentManager manager, int port) {
/* 451 */     return new UndertowServletWebServer(builder, manager, getContextPath(), isUseForwardHeaders(), (port >= 0), 
/* 452 */         getCompression(), getServerHeader());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 457 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBufferSize(Integer bufferSize) {
/* 462 */     this.bufferSize = bufferSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIoThreads(Integer ioThreads) {
/* 467 */     this.ioThreads = ioThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWorkerThreads(Integer workerThreads) {
/* 472 */     this.workerThreads = workerThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseDirectBuffers(Boolean directBuffers) {
/* 477 */     this.directBuffers = directBuffers;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogDirectory(File accessLogDirectory) {
/* 482 */     this.accessLogDirectory = accessLogDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogPattern(String accessLogPattern) {
/* 487 */     this.accessLogPattern = accessLogPattern;
/*     */   }
/*     */   
/*     */   public String getAccessLogPrefix() {
/* 491 */     return this.accessLogPrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogPrefix(String accessLogPrefix) {
/* 496 */     this.accessLogPrefix = accessLogPrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogSuffix(String accessLogSuffix) {
/* 501 */     this.accessLogSuffix = accessLogSuffix;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogEnabled(boolean accessLogEnabled) {
/* 506 */     this.accessLogEnabled = accessLogEnabled;
/*     */   }
/*     */   
/*     */   public boolean isAccessLogEnabled() {
/* 510 */     return this.accessLogEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogRotate(boolean accessLogRotate) {
/* 515 */     this.accessLogRotate = accessLogRotate;
/*     */   }
/*     */   
/*     */   protected final boolean isUseForwardHeaders() {
/* 519 */     return this.useForwardHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders) {
/* 524 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEagerInitFilters() {
/* 533 */     return this.eagerInitFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEagerInitFilters(boolean eagerInitFilters) {
/* 543 */     this.eagerInitFilters = eagerInitFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MetaInfResourcesResourceManager
/*     */     implements ResourceManager
/*     */   {
/*     */     private final List<URL> metaInfResourceJarUrls;
/*     */ 
/*     */     
/*     */     private MetaInfResourcesResourceManager(List<URL> metaInfResourceJarUrls) {
/* 555 */       this.metaInfResourceJarUrls = metaInfResourceJarUrls;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() throws IOException {}
/*     */ 
/*     */     
/*     */     public Resource getResource(String path) {
/* 564 */       for (URL url : this.metaInfResourceJarUrls) {
/* 565 */         URLResource resource = getMetaInfResource(url, path);
/* 566 */         if (resource != null) {
/* 567 */           return (Resource)resource;
/*     */         }
/*     */       } 
/* 570 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isResourceChangeListenerSupported() {
/* 575 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void registerResourceChangeListener(ResourceChangeListener listener) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeResourceChangeListener(ResourceChangeListener listener) {}
/*     */ 
/*     */     
/*     */     private URLResource getMetaInfResource(URL resourceJar, String path) {
/*     */       try {
/* 589 */         String urlPath = URLEncoder.encode(UndertowServletWebServerFactory.ENCODED_SLASH.matcher(path).replaceAll("/"), "UTF-8");
/* 590 */         URL resourceUrl = new URL(resourceJar + "META-INF/resources" + urlPath);
/* 591 */         URLResource resource = new URLResource(resourceUrl, path);
/* 592 */         if (resource.getContentLength().longValue() < 0L) {
/* 593 */           return null;
/*     */         }
/* 595 */         return resource;
/*     */       }
/* 597 */       catch (Exception ex) {
/* 598 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Initializer
/*     */     implements ServletContainerInitializer
/*     */   {
/*     */     private final ServletContextInitializer[] initializers;
/*     */ 
/*     */ 
/*     */     
/*     */     Initializer(ServletContextInitializer[] initializers) {
/* 613 */       this.initializers = initializers;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStartup(Set<Class<?>> classes, ServletContext servletContext) throws ServletException {
/* 618 */       for (ServletContextInitializer initializer : this.initializers) {
/* 619 */         initializer.onStartup(servletContext);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class LoaderHidingResourceManager
/*     */     implements ResourceManager
/*     */   {
/*     */     private final ResourceManager delegate;
/*     */     
/*     */     private LoaderHidingResourceManager(ResourceManager delegate) {
/* 630 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public Resource getResource(String path) throws IOException {
/* 635 */       if (path.startsWith("/org/springframework/boot")) {
/* 636 */         return null;
/*     */       }
/* 638 */       return this.delegate.getResource(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isResourceChangeListenerSupported() {
/* 643 */       return this.delegate.isResourceChangeListenerSupported();
/*     */     }
/*     */ 
/*     */     
/*     */     public void registerResourceChangeListener(ResourceChangeListener listener) {
/* 648 */       this.delegate.registerResourceChangeListener(listener);
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeResourceChangeListener(ResourceChangeListener listener) {
/* 653 */       this.delegate.removeResourceChangeListener(listener);
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 658 */       this.delegate.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AccessLogShutdownListener
/*     */     implements ServletContextListener
/*     */   {
/*     */     private final XnioWorker worker;
/*     */     private final DefaultAccessLogReceiver accessLogReceiver;
/*     */     
/*     */     AccessLogShutdownListener(XnioWorker worker, DefaultAccessLogReceiver accessLogReceiver) {
/* 670 */       this.worker = worker;
/* 671 */       this.accessLogReceiver = accessLogReceiver;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void contextInitialized(ServletContextEvent sce) {}
/*     */ 
/*     */     
/*     */     public void contextDestroyed(ServletContextEvent sce) {
/*     */       try {
/* 681 */         this.accessLogReceiver.close();
/* 682 */         this.worker.shutdown();
/* 683 */         this.worker.awaitTermination(30L, TimeUnit.SECONDS);
/*     */       }
/* 685 */       catch (IOException ex) {
/* 686 */         throw new IllegalStateException(ex);
/*     */       }
/* 688 */       catch (InterruptedException ex) {
/* 689 */         Thread.currentThread().interrupt();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\UndertowServletWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.web.embedded.jetty;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import org.eclipse.jetty.webapp.AbstractConfiguration;
/*    */ import org.eclipse.jetty.webapp.WebAppContext;
/*    */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletContextInitializerConfiguration
/*    */   extends AbstractConfiguration
/*    */ {
/*    */   private final ServletContextInitializer[] initializers;
/*    */   
/*    */   public ServletContextInitializerConfiguration(ServletContextInitializer... initializers) {
/* 45 */     Assert.notNull(initializers, "Initializers must not be null");
/* 46 */     this.initializers = initializers;
/*    */   }
/*    */ 
/*    */   
/*    */   public void configure(WebAppContext context) throws Exception {
/* 51 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 52 */     Thread.currentThread().setContextClassLoader(context.getClassLoader());
/*    */     try {
/* 54 */       callInitializers(context);
/*    */     } finally {
/*    */       
/* 57 */       Thread.currentThread().setContextClassLoader(classLoader);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void callInitializers(WebAppContext context) throws ServletException {
/*    */     try {
/* 63 */       setExtendedListenerTypes(context, true);
/* 64 */       for (ServletContextInitializer initializer : this.initializers) {
/* 65 */         initializer.onStartup((ServletContext)context.getServletContext());
/*    */       }
/*    */     } finally {
/*    */       
/* 69 */       setExtendedListenerTypes(context, false);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void setExtendedListenerTypes(WebAppContext context, boolean extended) {
/*    */     try {
/* 75 */       context.getServletContext().setExtendedListenerTypes(extended);
/*    */     }
/* 77 */     catch (NoSuchMethodError noSuchMethodError) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\ServletContextInitializerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
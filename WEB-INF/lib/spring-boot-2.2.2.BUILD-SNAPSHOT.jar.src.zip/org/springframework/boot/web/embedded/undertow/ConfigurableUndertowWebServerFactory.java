package org.springframework.boot.web.embedded.undertow;

import java.io.File;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;

public interface ConfigurableUndertowWebServerFactory extends ConfigurableWebServerFactory {
  void addBuilderCustomizers(UndertowBuilderCustomizer... paramVarArgs);
  
  void setBufferSize(Integer paramInteger);
  
  void setIoThreads(Integer paramInteger);
  
  void setWorkerThreads(Integer paramInteger);
  
  void setUseDirectBuffers(Boolean paramBoolean);
  
  void setAccessLogDirectory(File paramFile);
  
  void setAccessLogPattern(String paramString);
  
  void setAccessLogPrefix(String paramString);
  
  void setAccessLogSuffix(String paramString);
  
  void setAccessLogEnabled(boolean paramBoolean);
  
  void setAccessLogRotate(boolean paramBoolean);
  
  void setUseForwardHeaders(boolean paramBoolean);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\ConfigurableUndertowWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
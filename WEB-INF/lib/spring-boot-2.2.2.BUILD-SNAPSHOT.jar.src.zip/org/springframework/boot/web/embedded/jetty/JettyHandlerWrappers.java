/*    */ package org.springframework.boot.web.embedded.jetty;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.eclipse.jetty.http.HttpMethod;
/*    */ import org.eclipse.jetty.server.Request;
/*    */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*    */ import org.eclipse.jetty.server.handler.gzip.GzipHandler;
/*    */ import org.springframework.boot.web.server.Compression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JettyHandlerWrappers
/*    */ {
/*    */   static HandlerWrapper createGzipHandlerWrapper(Compression compression) {
/* 43 */     GzipHandler handler = new GzipHandler();
/* 44 */     handler.setMinGzipSize((int)compression.getMinResponseSize().toBytes());
/* 45 */     handler.setIncludedMimeTypes(compression.getMimeTypes());
/* 46 */     for (HttpMethod httpMethod : HttpMethod.values()) {
/* 47 */       handler.addIncludedMethods(new String[] { httpMethod.name() });
/*    */     } 
/* 49 */     if (compression.getExcludedUserAgents() != null) {
/* 50 */       handler.setExcludedAgentPatterns(compression.getExcludedUserAgents());
/*    */     }
/* 52 */     return (HandlerWrapper)handler;
/*    */   }
/*    */   
/*    */   static HandlerWrapper createServerHeaderHandlerWrapper(String header) {
/* 56 */     return new ServerHeaderHandler(header);
/*    */   }
/*    */ 
/*    */   
/*    */   private static class ServerHeaderHandler
/*    */     extends HandlerWrapper
/*    */   {
/*    */     private static final String SERVER_HEADER = "server";
/*    */     
/*    */     private final String value;
/*    */ 
/*    */     
/*    */     ServerHeaderHandler(String value) {
/* 69 */       this.value = value;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/* 75 */       if (!response.getHeaderNames().contains("server")) {
/* 76 */         response.setHeader("server", this.value);
/*    */       }
/* 78 */       super.handle(target, baseRequest, request, response);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\jetty\JettyHandlerWrappers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.attribute.ExchangeAttribute;
/*     */ import io.undertow.attribute.RequestHeaderAttribute;
/*     */ import io.undertow.predicate.Predicate;
/*     */ import io.undertow.predicate.Predicates;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import io.undertow.server.handlers.encoding.ContentEncodingProvider;
/*     */ import io.undertow.server.handlers.encoding.ContentEncodingRepository;
/*     */ import io.undertow.server.handlers.encoding.EncodingHandler;
/*     */ import io.undertow.server.handlers.encoding.GzipEncodingProvider;
/*     */ import io.undertow.util.Headers;
/*     */ import io.undertow.util.HttpString;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.web.server.Compression;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UndertowCompressionConfigurer
/*     */ {
/*     */   static HttpHandler configureCompression(Compression compression, HttpHandler httpHandler) {
/*  56 */     if (compression == null || !compression.getEnabled()) {
/*  57 */       return httpHandler;
/*     */     }
/*  59 */     ContentEncodingRepository repository = new ContentEncodingRepository();
/*  60 */     repository.addEncodingHandler("gzip", (ContentEncodingProvider)new GzipEncodingProvider(), 50, 
/*  61 */         Predicates.and(getCompressionPredicates(compression)));
/*  62 */     return (HttpHandler)(new EncodingHandler(repository)).setNext(httpHandler);
/*     */   }
/*     */   
/*     */   private static Predicate[] getCompressionPredicates(Compression compression) {
/*  66 */     List<Predicate> predicates = new ArrayList<>();
/*  67 */     predicates.add(new MaxSizePredicate((int)compression.getMinResponseSize().toBytes()));
/*  68 */     predicates.add(new CompressibleMimeTypePredicate(compression.getMimeTypes()));
/*  69 */     if (compression.getExcludedUserAgents() != null) {
/*  70 */       for (String agent : compression.getExcludedUserAgents()) {
/*  71 */         RequestHeaderAttribute agentHeader = new RequestHeaderAttribute(new HttpString("User-Agent"));
/*  72 */         predicates.add(Predicates.not(Predicates.regex((ExchangeAttribute)agentHeader, agent)));
/*     */       } 
/*     */     }
/*  75 */     return predicates.<Predicate>toArray(new Predicate[0]);
/*     */   }
/*     */   
/*     */   private static class CompressibleMimeTypePredicate
/*     */     implements Predicate {
/*     */     private final List<MimeType> mimeTypes;
/*     */     
/*     */     CompressibleMimeTypePredicate(String[] mimeTypes) {
/*  83 */       this.mimeTypes = new ArrayList<>(mimeTypes.length);
/*  84 */       for (String mimeTypeString : mimeTypes) {
/*  85 */         this.mimeTypes.add(MimeTypeUtils.parseMimeType(mimeTypeString));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean resolve(HttpServerExchange value) {
/*  91 */       String contentType = value.getResponseHeaders().getFirst("Content-Type");
/*  92 */       if (contentType != null) {
/*  93 */         for (MimeType mimeType : this.mimeTypes) {
/*  94 */           if (mimeType.isCompatibleWith(MimeTypeUtils.parseMimeType(contentType))) {
/*  95 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*  99 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MaxSizePredicate
/*     */     implements Predicate
/*     */   {
/*     */     private final Predicate maxContentSize;
/*     */ 
/*     */ 
/*     */     
/*     */     MaxSizePredicate(int size) {
/* 113 */       this.maxContentSize = Predicates.maxContentSize(size);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean resolve(HttpServerExchange value) {
/* 118 */       if (value.getResponseHeaders().contains(Headers.CONTENT_LENGTH)) {
/* 119 */         return this.maxContentSize.resolve(value);
/*     */       }
/* 121 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\UndertowCompressionConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.web.embedded.netty;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Predicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.web.server.PortInUseException;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.http.server.reactive.ReactorHttpHandlerAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.netty.ChannelBindException;
/*     */ import reactor.netty.DisposableServer;
/*     */ import reactor.netty.http.server.HttpServer;
/*     */ import reactor.netty.http.server.HttpServerRequest;
/*     */ import reactor.netty.http.server.HttpServerRoutes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NettyWebServer
/*     */   implements WebServer
/*     */ {
/*     */   private static final Predicate<HttpServerRequest> ALWAYS = r -> true;
/*  52 */   private static final Log logger = LogFactory.getLog(NettyWebServer.class);
/*     */   
/*     */   private final HttpServer httpServer;
/*     */   
/*     */   private final ReactorHttpHandlerAdapter handlerAdapter;
/*     */   
/*     */   private final Duration lifecycleTimeout;
/*     */   
/*  60 */   private List<NettyRouteProvider> routeProviders = Collections.emptyList();
/*     */   
/*     */   private DisposableServer disposableServer;
/*     */   
/*     */   public NettyWebServer(HttpServer httpServer, ReactorHttpHandlerAdapter handlerAdapter, Duration lifecycleTimeout) {
/*  65 */     Assert.notNull(httpServer, "HttpServer must not be null");
/*  66 */     Assert.notNull(handlerAdapter, "HandlerAdapter must not be null");
/*  67 */     this.httpServer = httpServer;
/*  68 */     this.handlerAdapter = handlerAdapter;
/*  69 */     this.lifecycleTimeout = lifecycleTimeout;
/*     */   }
/*     */   
/*     */   public void setRouteProviders(List<NettyRouteProvider> routeProviders) {
/*  73 */     this.routeProviders = routeProviders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() throws WebServerException {
/*  78 */     if (this.disposableServer == null) {
/*     */       try {
/*  80 */         this.disposableServer = startHttpServer();
/*     */       }
/*  82 */       catch (Exception ex) {
/*  83 */         ChannelBindException bindException = findBindException(ex);
/*  84 */         if (bindException != null) {
/*  85 */           throw new PortInUseException(bindException.localPort());
/*     */         }
/*  87 */         throw new WebServerException("Unable to start Netty", ex);
/*     */       } 
/*  89 */       logger.info("Netty started on port(s): " + getPort());
/*  90 */       startDaemonAwaitThread(this.disposableServer);
/*     */     } 
/*     */   }
/*     */   
/*     */   private DisposableServer startHttpServer() {
/*  95 */     HttpServer server = this.httpServer;
/*  96 */     if (this.routeProviders.isEmpty()) {
/*  97 */       server = server.handle((BiFunction)this.handlerAdapter);
/*     */     } else {
/*     */       
/* 100 */       server = server.route(this::applyRouteProviders);
/*     */     } 
/* 102 */     if (this.lifecycleTimeout != null) {
/* 103 */       return server.bindNow(this.lifecycleTimeout);
/*     */     }
/* 105 */     return server.bindNow();
/*     */   }
/*     */   
/*     */   private void applyRouteProviders(HttpServerRoutes routes) {
/* 109 */     for (NettyRouteProvider provider : this.routeProviders) {
/* 110 */       routes = provider.apply(routes);
/*     */     }
/* 112 */     routes.route(ALWAYS, (BiFunction)this.handlerAdapter);
/*     */   }
/*     */   
/*     */   private ChannelBindException findBindException(Exception ex) {
/* 116 */     Throwable candidate = ex;
/* 117 */     while (candidate != null) {
/* 118 */       if (candidate instanceof ChannelBindException) {
/* 119 */         return (ChannelBindException)candidate;
/*     */       }
/* 121 */       candidate = candidate.getCause();
/*     */     } 
/* 123 */     return null;
/*     */   }
/*     */   
/*     */   private void startDaemonAwaitThread(final DisposableServer disposableServer) {
/* 127 */     Thread awaitThread = new Thread("server")
/*     */       {
/*     */         public void run()
/*     */         {
/* 131 */           disposableServer.onDispose().block();
/*     */         }
/*     */       };
/*     */     
/* 135 */     awaitThread.setContextClassLoader(getClass().getClassLoader());
/* 136 */     awaitThread.setDaemon(false);
/* 137 */     awaitThread.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() throws WebServerException {
/* 142 */     if (this.disposableServer != null) {
/* 143 */       if (this.lifecycleTimeout != null) {
/* 144 */         this.disposableServer.disposeNow(this.lifecycleTimeout);
/*     */       } else {
/*     */         
/* 147 */         this.disposableServer.disposeNow();
/*     */       } 
/* 149 */       this.disposableServer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 155 */     if (this.disposableServer != null) {
/* 156 */       return this.disposableServer.port();
/*     */     }
/* 158 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\netty\NettyWebServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
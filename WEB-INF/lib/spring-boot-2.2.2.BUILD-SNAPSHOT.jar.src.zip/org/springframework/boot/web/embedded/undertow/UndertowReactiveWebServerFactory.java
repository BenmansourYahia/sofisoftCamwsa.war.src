/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Handlers;
/*     */ import io.undertow.Undertow;
/*     */ import io.undertow.UndertowOptions;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.handlers.ProxyPeerAddressHandler;
/*     */ import io.undertow.server.handlers.accesslog.AccessLogHandler;
/*     */ import io.undertow.server.handlers.accesslog.AccessLogReceiver;
/*     */ import io.undertow.server.handlers.accesslog.DefaultAccessLogReceiver;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.boot.web.reactive.server.AbstractReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.http.server.reactive.HttpHandler;
/*     */ import org.springframework.http.server.reactive.UndertowHttpHandlerAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.xnio.OptionMap;
/*     */ import org.xnio.Options;
/*     */ import org.xnio.Xnio;
/*     */ import org.xnio.XnioWorker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowReactiveWebServerFactory
/*     */   extends AbstractReactiveWebServerFactory
/*     */   implements ConfigurableUndertowWebServerFactory
/*     */ {
/*  54 */   private Set<UndertowBuilderCustomizer> builderCustomizers = new LinkedHashSet<>();
/*     */ 
/*     */   
/*     */   private Integer bufferSize;
/*     */ 
/*     */   
/*     */   private Integer ioThreads;
/*     */ 
/*     */   
/*     */   private Integer workerThreads;
/*     */ 
/*     */   
/*     */   private Boolean directBuffers;
/*     */ 
/*     */   
/*     */   private File accessLogDirectory;
/*     */ 
/*     */   
/*     */   private String accessLogPattern;
/*     */ 
/*     */   
/*     */   private String accessLogPrefix;
/*     */ 
/*     */   
/*     */   private String accessLogSuffix;
/*     */ 
/*     */   
/*     */   private boolean accessLogEnabled = false;
/*     */ 
/*     */   
/*     */   private boolean accessLogRotate = true;
/*     */   
/*     */   private boolean useForwardHeaders;
/*     */ 
/*     */   
/*     */   public UndertowReactiveWebServerFactory(int port) {
/*  90 */     super(port);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebServer getWebServer(HttpHandler httpHandler) {
/*  95 */     Undertow.Builder builder = createBuilder(getPort());
/*  96 */     Closeable closeable = configureHandler(builder, httpHandler);
/*  97 */     return new UndertowWebServer(builder, (getPort() >= 0), closeable);
/*     */   }
/*     */   
/*     */   private Undertow.Builder createBuilder(int port) {
/* 101 */     Undertow.Builder builder = Undertow.builder();
/* 102 */     if (this.bufferSize != null) {
/* 103 */       builder.setBufferSize(this.bufferSize.intValue());
/*     */     }
/* 105 */     if (this.ioThreads != null) {
/* 106 */       builder.setIoThreads(this.ioThreads.intValue());
/*     */     }
/* 108 */     if (this.workerThreads != null) {
/* 109 */       builder.setWorkerThreads(this.workerThreads.intValue());
/*     */     }
/* 111 */     if (this.directBuffers != null) {
/* 112 */       builder.setDirectBuffers(this.directBuffers.booleanValue());
/*     */     }
/* 114 */     if (getSsl() != null && getSsl().isEnabled()) {
/* 115 */       customizeSsl(builder);
/*     */     } else {
/*     */       
/* 118 */       builder.addHttpListener(port, getListenAddress());
/*     */     } 
/* 120 */     for (UndertowBuilderCustomizer customizer : this.builderCustomizers) {
/* 121 */       customizer.customize(builder);
/*     */     }
/* 123 */     return builder;
/*     */   }
/*     */   
/*     */   private Closeable configureHandler(Undertow.Builder builder, HttpHandler httpHandler) {
/*     */     ProxyPeerAddressHandler proxyPeerAddressHandler;
/* 128 */     UndertowHttpHandlerAdapter undertowHttpHandlerAdapter = new UndertowHttpHandlerAdapter(httpHandler);
/* 129 */     if (this.useForwardHeaders) {
/* 130 */       proxyPeerAddressHandler = Handlers.proxyPeerAddress((HttpHandler)undertowHttpHandlerAdapter);
/*     */     }
/* 132 */     HttpHandler httpHandler1 = UndertowCompressionConfigurer.configureCompression(getCompression(), (HttpHandler)proxyPeerAddressHandler);
/* 133 */     Closeable closeable = null;
/* 134 */     if (isAccessLogEnabled()) {
/* 135 */       closeable = configureAccessLogHandler(builder, httpHandler1);
/*     */     } else {
/*     */       
/* 138 */       builder.setHandler(httpHandler1);
/*     */     } 
/* 140 */     return closeable;
/*     */   }
/*     */   
/*     */   private Closeable configureAccessLogHandler(Undertow.Builder builder, HttpHandler handler) {
/*     */     try {
/* 145 */       createAccessLogDirectoryIfNecessary();
/* 146 */       XnioWorker worker = createWorker();
/* 147 */       String prefix = (this.accessLogPrefix != null) ? this.accessLogPrefix : "access_log.";
/* 148 */       DefaultAccessLogReceiver accessLogReceiver = new DefaultAccessLogReceiver((Executor)worker, this.accessLogDirectory, prefix, this.accessLogSuffix, this.accessLogRotate);
/*     */       
/* 150 */       String formatString = (this.accessLogPattern != null) ? this.accessLogPattern : "common";
/* 151 */       builder.setHandler((HttpHandler)new AccessLogHandler(handler, (AccessLogReceiver)accessLogReceiver, formatString, Undertow.class
/* 152 */             .getClassLoader()));
/* 153 */       return () -> {
/*     */           try {
/*     */             accessLogReceiver.close();
/*     */             
/*     */             worker.shutdown();
/*     */             worker.awaitTermination(30L, TimeUnit.SECONDS);
/* 159 */           } catch (IOException ex) {
/*     */             
/*     */             throw new IllegalStateException(ex);
/* 162 */           } catch (InterruptedException ex) {
/*     */             
/*     */             Thread.currentThread().interrupt();
/*     */           } 
/*     */         };
/* 167 */     } catch (IOException ex) {
/* 168 */       throw new IllegalStateException("Failed to create AccessLogHandler", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void createAccessLogDirectoryIfNecessary() {
/* 173 */     Assert.state((this.accessLogDirectory != null), "Access log directory is not set");
/* 174 */     if (!this.accessLogDirectory.isDirectory() && !this.accessLogDirectory.mkdirs()) {
/* 175 */       throw new IllegalStateException("Failed to create access log directory '" + this.accessLogDirectory + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   private XnioWorker createWorker() throws IOException {
/* 180 */     Xnio xnio = Xnio.getInstance(Undertow.class.getClassLoader());
/* 181 */     return xnio.createWorker(OptionMap.builder().set(Options.THREAD_DAEMON, true).getMap());
/*     */   }
/*     */   
/*     */   private void customizeSsl(Undertow.Builder builder) {
/* 185 */     (new SslBuilderCustomizer(getPort(), getAddress(), getSsl(), getSslStoreProvider())).customize(builder);
/* 186 */     if (getHttp2() != null) {
/* 187 */       builder.setServerOption(UndertowOptions.ENABLE_HTTP2, Boolean.valueOf(getHttp2().isEnabled()));
/*     */     }
/*     */   }
/*     */   
/*     */   private String getListenAddress() {
/* 192 */     if (getAddress() == null) {
/* 193 */       return "0.0.0.0";
/*     */     }
/* 195 */     return getAddress().getHostAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogDirectory(File accessLogDirectory) {
/* 200 */     this.accessLogDirectory = accessLogDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogPattern(String accessLogPattern) {
/* 205 */     this.accessLogPattern = accessLogPattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogPrefix(String accessLogPrefix) {
/* 210 */     this.accessLogPrefix = accessLogPrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogSuffix(String accessLogSuffix) {
/* 215 */     this.accessLogSuffix = accessLogSuffix;
/*     */   }
/*     */   
/*     */   public boolean isAccessLogEnabled() {
/* 219 */     return this.accessLogEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogEnabled(boolean accessLogEnabled) {
/* 224 */     this.accessLogEnabled = accessLogEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessLogRotate(boolean accessLogRotate) {
/* 229 */     this.accessLogRotate = accessLogRotate;
/*     */   }
/*     */   
/*     */   protected final boolean isUseForwardHeaders() {
/* 233 */     return this.useForwardHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders) {
/* 238 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBufferSize(Integer bufferSize) {
/* 243 */     this.bufferSize = bufferSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIoThreads(Integer ioThreads) {
/* 248 */     this.ioThreads = ioThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWorkerThreads(Integer workerThreads) {
/* 253 */     this.workerThreads = workerThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseDirectBuffers(Boolean directBuffers) {
/* 258 */     this.directBuffers = directBuffers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuilderCustomizers(Collection<? extends UndertowBuilderCustomizer> customizers) {
/* 268 */     Assert.notNull(customizers, "Customizers must not be null");
/* 269 */     this.builderCustomizers = new LinkedHashSet<>(customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<UndertowBuilderCustomizer> getBuilderCustomizers() {
/* 278 */     return this.builderCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBuilderCustomizers(UndertowBuilderCustomizer... customizers) {
/* 288 */     Assert.notNull(customizers, "Customizers must not be null");
/* 289 */     this.builderCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */   
/*     */   public UndertowReactiveWebServerFactory() {}
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\UndertowReactiveWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
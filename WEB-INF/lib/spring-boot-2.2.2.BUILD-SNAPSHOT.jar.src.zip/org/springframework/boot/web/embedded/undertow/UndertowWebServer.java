/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import java.io.Closeable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.BindException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.web.server.PortInUseException;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xnio.channels.BoundChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowWebServer
/*     */   implements WebServer
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(UndertowWebServer.class);
/*     */   
/*  54 */   private final Object monitor = new Object();
/*     */ 
/*     */   
/*     */   private final Undertow.Builder builder;
/*     */ 
/*     */   
/*     */   private final boolean autoStart;
/*     */ 
/*     */   
/*     */   private final Closeable closeable;
/*     */ 
/*     */   
/*     */   private Undertow undertow;
/*     */   
/*     */   private volatile boolean started = false;
/*     */ 
/*     */   
/*     */   public UndertowWebServer(Undertow.Builder builder, boolean autoStart) {
/*  72 */     this(builder, autoStart, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UndertowWebServer(Undertow.Builder builder, boolean autoStart, Closeable closeable) {
/*  83 */     this.builder = builder;
/*  84 */     this.autoStart = autoStart;
/*  85 */     this.closeable = closeable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() throws WebServerException {
/*  90 */     synchronized (this.monitor) {
/*  91 */       if (this.started) {
/*     */         return;
/*     */       }
/*     */       try {
/*  95 */         if (!this.autoStart) {
/*     */           return;
/*     */         }
/*  98 */         if (this.undertow == null) {
/*  99 */           this.undertow = this.builder.build();
/*     */         }
/* 101 */         this.undertow.start();
/* 102 */         this.started = true;
/* 103 */         logger.info("Undertow started on port(s) " + getPortsDescription());
/*     */       }
/* 105 */       catch (Exception ex) {
/*     */         try {
/* 107 */           if (findBindException(ex) != null) {
/* 108 */             List<Port> failedPorts = getConfiguredPorts();
/* 109 */             List<Port> actualPorts = getActualPorts();
/* 110 */             failedPorts.removeAll(actualPorts);
/* 111 */             if (failedPorts.size() == 1) {
/* 112 */               throw new PortInUseException(((Port)failedPorts.iterator().next()).getNumber());
/*     */             }
/*     */           } 
/* 115 */           throw new WebServerException("Unable to start embedded Undertow", ex);
/*     */         } finally {
/*     */           
/* 118 */           stopSilently();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void stopSilently() {
/*     */     try {
/* 126 */       if (this.undertow != null) {
/* 127 */         this.undertow.stop();
/* 128 */         this.closeable.close();
/*     */       }
/*     */     
/* 131 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BindException findBindException(Exception ex) {
/* 137 */     Throwable candidate = ex;
/* 138 */     while (candidate != null) {
/* 139 */       if (candidate instanceof BindException) {
/* 140 */         return (BindException)candidate;
/*     */       }
/* 142 */       candidate = candidate.getCause();
/*     */     } 
/* 144 */     return null;
/*     */   }
/*     */   
/*     */   private String getPortsDescription() {
/* 148 */     List<Port> ports = getActualPorts();
/* 149 */     if (!ports.isEmpty()) {
/* 150 */       return StringUtils.collectionToDelimitedString(ports, " ");
/*     */     }
/* 152 */     return "unknown";
/*     */   }
/*     */   
/*     */   private List<Port> getActualPorts() {
/* 156 */     List<Port> ports = new ArrayList<>();
/*     */     try {
/* 158 */       if (!this.autoStart) {
/* 159 */         ports.add(new Port(-1, "unknown"));
/*     */       } else {
/*     */         
/* 162 */         for (BoundChannel channel : extractChannels()) {
/* 163 */           ports.add(getPortFromChannel(channel));
/*     */         }
/*     */       }
/*     */     
/* 167 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 170 */     return ports;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<BoundChannel> extractChannels() {
/* 175 */     Field channelsField = ReflectionUtils.findField(Undertow.class, "channels");
/* 176 */     ReflectionUtils.makeAccessible(channelsField);
/* 177 */     return (List<BoundChannel>)ReflectionUtils.getField(channelsField, this.undertow);
/*     */   }
/*     */   
/*     */   private Port getPortFromChannel(BoundChannel channel) {
/* 181 */     SocketAddress socketAddress = channel.getLocalAddress();
/* 182 */     if (socketAddress instanceof InetSocketAddress) {
/* 183 */       Field sslField = ReflectionUtils.findField(channel.getClass(), "ssl");
/* 184 */       String protocol = (sslField != null) ? "https" : "http";
/* 185 */       return new Port(((InetSocketAddress)socketAddress).getPort(), protocol);
/*     */     } 
/* 187 */     return null;
/*     */   }
/*     */   
/*     */   private List<Port> getConfiguredPorts() {
/* 191 */     List<Port> ports = new ArrayList<>();
/* 192 */     for (Object listener : extractListeners()) {
/*     */       try {
/* 194 */         ports.add(getPortFromListener(listener));
/*     */       }
/* 196 */       catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 200 */     return ports;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Object> extractListeners() {
/* 205 */     Field listenersField = ReflectionUtils.findField(Undertow.class, "listeners");
/* 206 */     ReflectionUtils.makeAccessible(listenersField);
/* 207 */     return (List<Object>)ReflectionUtils.getField(listenersField, this.undertow);
/*     */   }
/*     */   
/*     */   private Port getPortFromListener(Object listener) {
/* 211 */     Field typeField = ReflectionUtils.findField(listener.getClass(), "type");
/* 212 */     ReflectionUtils.makeAccessible(typeField);
/* 213 */     String protocol = ReflectionUtils.getField(typeField, listener).toString();
/* 214 */     Field portField = ReflectionUtils.findField(listener.getClass(), "port");
/* 215 */     ReflectionUtils.makeAccessible(portField);
/* 216 */     int port = ((Integer)ReflectionUtils.getField(portField, listener)).intValue();
/* 217 */     return new Port(port, protocol);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() throws WebServerException {
/* 222 */     synchronized (this.monitor) {
/* 223 */       if (!this.started) {
/*     */         return;
/*     */       }
/* 226 */       this.started = false;
/*     */       try {
/* 228 */         this.undertow.stop();
/* 229 */         if (this.closeable != null) {
/* 230 */           this.closeable.close();
/*     */         }
/*     */       }
/* 233 */       catch (Exception ex) {
/* 234 */         throw new WebServerException("Unable to stop undertow", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 241 */     List<Port> ports = getActualPorts();
/* 242 */     if (ports.isEmpty()) {
/* 243 */       return 0;
/*     */     }
/* 245 */     return ((Port)ports.get(0)).getNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Port
/*     */   {
/*     */     private final int number;
/*     */     
/*     */     private final String protocol;
/*     */ 
/*     */     
/*     */     private Port(int number, String protocol) {
/* 258 */       this.number = number;
/* 259 */       this.protocol = protocol;
/*     */     }
/*     */     
/*     */     int getNumber() {
/* 263 */       return this.number;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 268 */       if (this == obj) {
/* 269 */         return true;
/*     */       }
/* 271 */       if (obj == null) {
/* 272 */         return false;
/*     */       }
/* 274 */       if (getClass() != obj.getClass()) {
/* 275 */         return false;
/*     */       }
/* 277 */       Port other = (Port)obj;
/* 278 */       return (this.number == other.number);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 283 */       return this.number;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 288 */       return this.number + " (" + this.protocol + ")";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedde\\undertow\UndertowWebServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
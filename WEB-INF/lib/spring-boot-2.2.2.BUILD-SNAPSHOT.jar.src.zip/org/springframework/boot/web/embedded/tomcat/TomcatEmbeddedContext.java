/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import java.util.stream.Stream;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.SessionIdGenerator;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.core.StandardContext;
/*     */ import org.apache.catalina.core.StandardWrapper;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TomcatEmbeddedContext
/*     */   extends StandardContext
/*     */ {
/*     */   private TomcatStarter starter;
/*     */   
/*     */   public boolean loadOnStartup(Container[] children) {
/*  52 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setManager(Manager manager) {
/*  57 */     if (manager instanceof org.apache.catalina.session.ManagerBase) {
/*  58 */       manager.setSessionIdGenerator((SessionIdGenerator)new LazySessionIdGenerator());
/*     */     }
/*  60 */     super.setManager(manager);
/*     */   }
/*     */   
/*     */   void deferredLoadOnStartup() throws LifecycleException {
/*  64 */     doWithThreadContextClassLoader(getLoader().getClassLoader(), () -> getLoadOnStartupWrappers(findChildren()).forEach(this::load));
/*     */   }
/*     */ 
/*     */   
/*     */   private Stream<Wrapper> getLoadOnStartupWrappers(Container[] children) {
/*  69 */     Map<Integer, List<Wrapper>> grouped = new TreeMap<>();
/*  70 */     for (Container child : children) {
/*  71 */       Wrapper wrapper = (Wrapper)child;
/*  72 */       int order = wrapper.getLoadOnStartup();
/*  73 */       if (order >= 0) {
/*  74 */         ((List<Wrapper>)grouped.computeIfAbsent(Integer.valueOf(order), o -> new ArrayList())).add(wrapper);
/*     */       }
/*     */     } 
/*  77 */     return grouped.values().stream().flatMap(Collection::stream);
/*     */   }
/*     */   
/*     */   private void load(Wrapper wrapper) {
/*     */     try {
/*  82 */       wrapper.load();
/*     */     }
/*  84 */     catch (ServletException ex) {
/*  85 */       String message = sm.getString("standardContext.loadOnStartup.loadException", new Object[] { getName(), wrapper.getName() });
/*  86 */       if (getComputedFailCtxIfServletStartFails()) {
/*  87 */         throw new WebServerException(message, ex);
/*     */       }
/*  89 */       getLogger().error(message, StandardWrapper.getRootCause(ex));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doWithThreadContextClassLoader(ClassLoader classLoader, Runnable code) {
/* 103 */     ClassLoader existingLoader = (classLoader != null) ? ClassUtils.overrideThreadContextClassLoader(classLoader) : null;
/*     */     
/*     */     try {
/* 106 */       code.run();
/*     */     } finally {
/*     */       
/* 109 */       if (existingLoader != null) {
/* 110 */         ClassUtils.overrideThreadContextClassLoader(existingLoader);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   void setStarter(TomcatStarter starter) {
/* 116 */     this.starter = starter;
/*     */   }
/*     */   
/*     */   TomcatStarter getStarter() {
/* 120 */     return this.starter;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\web\embedded\tomcat\TomcatEmbeddedContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
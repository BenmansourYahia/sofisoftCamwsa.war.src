/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.ansi.AnsiBackground;
/*     */ import org.springframework.boot.ansi.AnsiColor;
/*     */ import org.springframework.boot.ansi.AnsiColors;
/*     */ import org.springframework.boot.ansi.AnsiElement;
/*     */ import org.springframework.boot.ansi.AnsiOutput;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageBanner
/*     */   implements Banner
/*     */ {
/*     */   private static final String PROPERTY_PREFIX = "spring.banner.image.";
/*  62 */   private static final Log logger = LogFactory.getLog(ImageBanner.class);
/*     */   
/*  64 */   private static final double[] RGB_WEIGHT = new double[] { 0.2126D, 0.7152D, 0.0722D };
/*     */   
/*     */   private final Resource image;
/*     */   
/*     */   public ImageBanner(Resource image) {
/*  69 */     Assert.notNull(image, "Image must not be null");
/*  70 */     Assert.isTrue(image.exists(), "Image must exist");
/*  71 */     this.image = image;
/*     */   }
/*     */ 
/*     */   
/*     */   public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) {
/*  76 */     String headless = System.getProperty("java.awt.headless");
/*     */     try {
/*  78 */       System.setProperty("java.awt.headless", "true");
/*  79 */       printBanner(environment, out);
/*     */     }
/*  81 */     catch (Throwable ex) {
/*  82 */       logger.warn(LogMessage.format("Image banner not printable: %s (%s: '%s')", this.image, ex.getClass(), ex
/*  83 */             .getMessage()));
/*  84 */       logger.debug("Image banner printing failure", ex);
/*     */     } finally {
/*     */       
/*  87 */       if (headless == null) {
/*  88 */         System.clearProperty("java.awt.headless");
/*     */       } else {
/*     */         
/*  91 */         System.setProperty("java.awt.headless", headless);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void printBanner(Environment environment, PrintStream out) throws IOException {
/*  97 */     int width = ((Integer)getProperty(environment, "width", Integer.class, Integer.valueOf(76))).intValue();
/*  98 */     int height = ((Integer)getProperty(environment, "height", Integer.class, Integer.valueOf(0))).intValue();
/*  99 */     int margin = ((Integer)getProperty(environment, "margin", Integer.class, Integer.valueOf(2))).intValue();
/* 100 */     boolean invert = ((Boolean)getProperty(environment, "invert", Boolean.class, Boolean.valueOf(false))).booleanValue();
/* 101 */     AnsiColors.BitDepth bitDepth = getBitDepthProperty(environment);
/* 102 */     PixelMode pixelMode = getPixelModeProperty(environment);
/* 103 */     Frame[] frames = readFrames(width, height);
/* 104 */     for (int i = 0; i < frames.length; i++) {
/* 105 */       if (i > 0) {
/* 106 */         resetCursor(frames[i - 1].getImage(), out);
/*     */       }
/* 108 */       printBanner(frames[i].getImage(), margin, invert, bitDepth, pixelMode, out);
/* 109 */       sleep(frames[i].getDelayTime());
/*     */     } 
/*     */   }
/*     */   
/*     */   private AnsiColors.BitDepth getBitDepthProperty(Environment environment) {
/* 114 */     Integer bitDepth = getProperty(environment, "bitdepth", Integer.class, null);
/* 115 */     return (bitDepth != null) ? AnsiColors.BitDepth.of(bitDepth.intValue()) : AnsiColors.BitDepth.FOUR;
/*     */   }
/*     */   
/*     */   private PixelMode getPixelModeProperty(Environment environment) {
/* 119 */     String pixelMode = getProperty(environment, "pixelmode", String.class, null);
/* 120 */     return (pixelMode != null) ? PixelMode.valueOf(pixelMode.trim().toUpperCase()) : PixelMode.TEXT;
/*     */   }
/*     */   
/*     */   private <T> T getProperty(Environment environment, String name, Class<T> targetType, T defaultValue) {
/* 124 */     return (T)environment.getProperty("spring.banner.image." + name, targetType, defaultValue);
/*     */   }
/*     */   
/*     */   private Frame[] readFrames(int width, int height) throws IOException {
/* 128 */     try(InputStream inputStream = this.image.getInputStream(); 
/* 129 */         ImageInputStream imageStream = ImageIO.createImageInputStream(inputStream)) {
/* 130 */       return readFrames(width, height, imageStream);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Frame[] readFrames(int width, int height, ImageInputStream stream) throws IOException {
/* 136 */     Iterator<ImageReader> readers = ImageIO.getImageReaders(stream);
/* 137 */     Assert.state(readers.hasNext(), "Unable to read image banner source");
/* 138 */     ImageReader reader = readers.next();
/*     */     try {
/* 140 */       ImageReadParam readParam = reader.getDefaultReadParam();
/* 141 */       reader.setInput(stream);
/* 142 */       int frameCount = reader.getNumImages(true);
/* 143 */       Frame[] frames = new Frame[frameCount];
/* 144 */       for (int i = 0; i < frameCount; i++) {
/* 145 */         frames[i] = readFrame(width, height, reader, i, readParam);
/*     */       }
/* 147 */       return frames;
/*     */     } finally {
/*     */       
/* 150 */       reader.dispose();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Frame readFrame(int width, int height, ImageReader reader, int imageIndex, ImageReadParam readParam) throws IOException {
/* 156 */     BufferedImage image = reader.read(imageIndex, readParam);
/* 157 */     BufferedImage resized = resizeImage(image, width, height);
/* 158 */     int delayTime = getDelayTime(reader, imageIndex);
/* 159 */     return new Frame(resized, delayTime);
/*     */   }
/*     */   
/*     */   private int getDelayTime(ImageReader reader, int imageIndex) throws IOException {
/* 163 */     IIOMetadata metadata = reader.getImageMetadata(imageIndex);
/* 164 */     IIOMetadataNode root = (IIOMetadataNode)metadata.getAsTree(metadata.getNativeMetadataFormatName());
/* 165 */     IIOMetadataNode extension = findNode(root, "GraphicControlExtension");
/* 166 */     String attribute = (extension != null) ? extension.getAttribute("delayTime") : null;
/* 167 */     return (attribute != null) ? (Integer.parseInt(attribute) * 10) : 0;
/*     */   }
/*     */   
/*     */   private static IIOMetadataNode findNode(IIOMetadataNode rootNode, String nodeName) {
/* 171 */     if (rootNode == null) {
/* 172 */       return null;
/*     */     }
/* 174 */     for (int i = 0; i < rootNode.getLength(); i++) {
/* 175 */       if (rootNode.item(i).getNodeName().equalsIgnoreCase(nodeName)) {
/* 176 */         return (IIOMetadataNode)rootNode.item(i);
/*     */       }
/*     */     } 
/* 179 */     return null;
/*     */   }
/*     */   
/*     */   private BufferedImage resizeImage(BufferedImage image, int width, int height) {
/* 183 */     if (width < 1) {
/* 184 */       width = 1;
/*     */     }
/* 186 */     if (height <= 0) {
/* 187 */       double aspectRatio = width / image.getWidth() * 0.5D;
/* 188 */       height = (int)Math.ceil(image.getHeight() * aspectRatio);
/*     */     } 
/* 190 */     BufferedImage resized = new BufferedImage(width, height, 1);
/* 191 */     Image scaled = image.getScaledInstance(width, height, 1);
/* 192 */     resized.getGraphics().drawImage(scaled, 0, 0, null);
/* 193 */     return resized;
/*     */   }
/*     */   
/*     */   private void resetCursor(BufferedImage image, PrintStream out) {
/* 197 */     int lines = image.getHeight() + 3;
/* 198 */     out.print("\033[" + lines + "A\r");
/*     */   }
/*     */ 
/*     */   
/*     */   private void printBanner(BufferedImage image, int margin, boolean invert, AnsiColors.BitDepth bitDepth, PixelMode pixelMode, PrintStream out) {
/* 203 */     AnsiBackground ansiBackground = invert ? AnsiBackground.BLACK : AnsiBackground.DEFAULT;
/* 204 */     out.print(AnsiOutput.encode((AnsiElement)AnsiColor.DEFAULT));
/* 205 */     out.print(AnsiOutput.encode((AnsiElement)ansiBackground));
/* 206 */     out.println();
/* 207 */     out.println();
/* 208 */     AnsiColor ansiColor = AnsiColor.DEFAULT;
/* 209 */     AnsiColors colors = new AnsiColors(bitDepth);
/* 210 */     for (int y = 0; y < image.getHeight(); y++) {
/* 211 */       for (int i = 0; i < margin; i++) {
/* 212 */         out.print(" ");
/*     */       }
/* 214 */       for (int x = 0; x < image.getWidth(); x++) {
/* 215 */         Color color = new Color(image.getRGB(x, y), false);
/* 216 */         AnsiElement ansiElement = colors.findClosest(color);
/* 217 */         if (ansiElement != ansiColor) {
/* 218 */           out.print(AnsiOutput.encode(ansiElement));
/* 219 */           AnsiElement ansiElement1 = ansiElement;
/*     */         } 
/* 221 */         out.print(getAsciiPixel(color, invert, pixelMode));
/*     */       } 
/* 223 */       out.println();
/*     */     } 
/* 225 */     out.print(AnsiOutput.encode((AnsiElement)AnsiColor.DEFAULT));
/* 226 */     out.print(AnsiOutput.encode((AnsiElement)AnsiBackground.DEFAULT));
/* 227 */     out.println();
/*     */   }
/*     */   
/*     */   private char getAsciiPixel(Color color, boolean dark, PixelMode pixelMode) {
/* 231 */     char[] pixels = pixelMode.getPixels();
/* 232 */     int increment = 10 / pixels.length * 10;
/* 233 */     int start = increment * pixels.length;
/* 234 */     double luminance = getLuminance(color, dark);
/* 235 */     for (int i = 0; i < pixels.length; i++) {
/* 236 */       if (luminance >= (start - i * increment)) {
/* 237 */         return pixels[i];
/*     */       }
/*     */     } 
/* 240 */     return pixels[pixels.length - 1];
/*     */   }
/*     */   
/*     */   private int getLuminance(Color color, boolean inverse) {
/* 244 */     double luminance = 0.0D;
/* 245 */     luminance += getLuminance(color.getRed(), inverse, RGB_WEIGHT[0]);
/* 246 */     luminance += getLuminance(color.getGreen(), inverse, RGB_WEIGHT[1]);
/* 247 */     luminance += getLuminance(color.getBlue(), inverse, RGB_WEIGHT[2]);
/* 248 */     return (int)Math.ceil(luminance / 255.0D * 100.0D);
/*     */   }
/*     */   
/*     */   private double getLuminance(int component, boolean inverse, double weight) {
/* 252 */     return (inverse ? (255 - component) : component) * weight;
/*     */   }
/*     */   
/*     */   private void sleep(int delay) {
/*     */     try {
/* 257 */       Thread.sleep(delay);
/*     */     }
/* 259 */     catch (InterruptedException ex) {
/* 260 */       Thread.currentThread().interrupt();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Frame
/*     */   {
/*     */     private final BufferedImage image;
/*     */     private final int delayTime;
/*     */     
/*     */     Frame(BufferedImage image, int delayTime) {
/* 271 */       this.image = image;
/* 272 */       this.delayTime = delayTime;
/*     */     }
/*     */     
/*     */     BufferedImage getImage() {
/* 276 */       return this.image;
/*     */     }
/*     */     
/*     */     int getDelayTime() {
/* 280 */       return this.delayTime;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum PixelMode
/*     */   {
/* 293 */     TEXT((String)new char[] { ' ', '.', '*', ':', 'o', '&', '8', '#', '@'
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/* 298 */     BLOCK((String)new char[] { ' ', '░', '▒', '▓', '█' });
/*     */     
/*     */     private char[] pixels;
/*     */     
/*     */     PixelMode(char... pixels) {
/* 303 */       this.pixels = pixels;
/*     */     }
/*     */     
/*     */     char[] getPixels() {
/* 307 */       return this.pixels;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\ImageBanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.reactor;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.boot.env.EnvironmentPostProcessor;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugAgentEnvironmentPostProcessor
/*    */   implements EnvironmentPostProcessor, Ordered
/*    */ {
/*    */   private static final String REACTOR_DEBUGAGENT_CLASS = "reactor.tools.agent.ReactorDebugAgent";
/*    */   private static final String DEBUGAGENT_ENABLED_CONFIG_KEY = "spring.reactor.debug-agent.enabled";
/*    */   
/*    */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/* 44 */     if (ClassUtils.isPresent("reactor.tools.agent.ReactorDebugAgent", null)) {
/* 45 */       Boolean agentEnabled = (Boolean)environment.getProperty("spring.reactor.debug-agent.enabled", Boolean.class);
/* 46 */       if (agentEnabled != Boolean.FALSE) {
/*    */         try {
/* 48 */           Class<?> debugAgent = Class.forName("reactor.tools.agent.ReactorDebugAgent");
/* 49 */           debugAgent.getMethod("init", new Class[0]).invoke(null, new Object[0]);
/*    */         }
/* 51 */         catch (Exception ex) {
/* 52 */           throw new RuntimeException("Failed to init Reactor's debug agent");
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 60 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\reactor\DebugAgentEnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot;

import java.util.List;
import java.util.Set;

public interface ApplicationArguments {
  String[] getSourceArgs();
  
  Set<String> getOptionNames();
  
  boolean containsOption(String paramString);
  
  List<String> getOptionValues(String paramString);
  
  List<String> getNonOptionArgs();
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\ApplicationArguments.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.liquibase;
/*    */ 
/*    */ import liquibase.servicelocator.CustomResolverServiceLocator;
/*    */ import liquibase.servicelocator.PackageScanClassResolver;
/*    */ import liquibase.servicelocator.ServiceLocator;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.context.event.ApplicationStartingEvent;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LiquibaseServiceLocatorApplicationListener
/*    */   implements ApplicationListener<ApplicationStartingEvent>
/*    */ {
/* 38 */   private static final Log logger = LogFactory.getLog(LiquibaseServiceLocatorApplicationListener.class);
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(ApplicationStartingEvent event) {
/* 42 */     if (ClassUtils.isPresent("liquibase.servicelocator.CustomResolverServiceLocator", event
/* 43 */         .getSpringApplication().getClassLoader())) {
/* 44 */       (new LiquibasePresent()).replaceServiceLocator();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static class LiquibasePresent
/*    */   {
/*    */     private LiquibasePresent() {}
/*    */ 
/*    */     
/*    */     void replaceServiceLocator() {
/* 55 */       CustomResolverServiceLocator customResolverServiceLocator = new CustomResolverServiceLocator((PackageScanClassResolver)new SpringPackageScanClassResolver(LiquibaseServiceLocatorApplicationListener.logger));
/* 56 */       ServiceLocator.setInstance((ServiceLocator)customResolverServiceLocator);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\liquibase\LiquibaseServiceLocatorApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
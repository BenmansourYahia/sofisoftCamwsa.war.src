/*     */ package org.springframework.boot.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiConsumer;
/*     */ import javax.annotation.PostConstruct;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonComponentModule
/*     */   extends SimpleModule
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/*  60 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void registerJsonComponents() {
/*  65 */     BeanFactory beanFactory = this.beanFactory;
/*  66 */     while (beanFactory != null) {
/*  67 */       if (beanFactory instanceof ListableBeanFactory) {
/*  68 */         addJsonBeans((ListableBeanFactory)beanFactory);
/*     */       }
/*     */       
/*  71 */       beanFactory = (beanFactory instanceof HierarchicalBeanFactory) ? ((HierarchicalBeanFactory)beanFactory).getParentBeanFactory() : null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addJsonBeans(ListableBeanFactory beanFactory) {
/*  76 */     Map<String, Object> beans = beanFactory.getBeansWithAnnotation(JsonComponent.class);
/*  77 */     for (Object bean : beans.values()) {
/*  78 */       addJsonBean(bean);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addJsonBean(Object bean) {
/*  84 */     MergedAnnotation<JsonComponent> annotation = MergedAnnotations.from(bean.getClass(), MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(JsonComponent.class);
/*  85 */     Class<?>[] types = annotation.getClassArray("type");
/*  86 */     JsonComponent.Scope scope = (JsonComponent.Scope)annotation.getEnum("scope", JsonComponent.Scope.class);
/*  87 */     addJsonBean(bean, types, scope);
/*     */   }
/*     */   
/*     */   private void addJsonBean(Object bean, Class<?>[] types, JsonComponent.Scope scope) {
/*  91 */     if (bean instanceof JsonSerializer) {
/*  92 */       addJsonSerializerBean((JsonSerializer)bean, scope, types);
/*     */     }
/*  94 */     else if (bean instanceof JsonDeserializer) {
/*  95 */       addJsonDeserializerBean((JsonDeserializer)bean, types);
/*     */     }
/*  97 */     else if (bean instanceof KeyDeserializer) {
/*  98 */       addKeyDeserializerBean((KeyDeserializer)bean, types);
/*     */     } 
/* 100 */     for (Class<?> innerClass : bean.getClass().getDeclaredClasses()) {
/* 101 */       if (isSuitableInnerClass(innerClass)) {
/* 102 */         Object innerInstance = BeanUtils.instantiateClass(innerClass);
/* 103 */         addJsonBean(innerInstance, types, scope);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isSuitableInnerClass(Class<?> innerClass) {
/* 109 */     return (!Modifier.isAbstract(innerClass.getModifiers()) && (JsonSerializer.class.isAssignableFrom(innerClass) || JsonDeserializer.class
/* 110 */       .isAssignableFrom(innerClass) || KeyDeserializer.class
/* 111 */       .isAssignableFrom(innerClass)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void addJsonSerializerBean(JsonSerializer<T> serializer, JsonComponent.Scope scope, Class<?>[] types) {
/* 117 */     Class<T> baseType = ResolvableType.forClass(JsonSerializer.class, serializer.getClass()).resolveGeneric(new int[0]);
/* 118 */     addBeanToModule(serializer, baseType, types, (scope == JsonComponent.Scope.VALUES) ? this::addSerializer : this::addKeySerializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void addJsonDeserializerBean(JsonDeserializer<T> deserializer, Class<?>[] types) {
/* 126 */     Class<T> baseType = ResolvableType.forClass(JsonDeserializer.class, deserializer.getClass()).resolveGeneric(new int[0]);
/* 127 */     addBeanToModule(deserializer, baseType, types, this::addDeserializer);
/*     */   }
/*     */   
/*     */   private void addKeyDeserializerBean(KeyDeserializer deserializer, Class<?>[] types) {
/* 131 */     Assert.notEmpty((Object[])types, "Type must be specified for KeyDeserializer");
/* 132 */     addBeanToModule(deserializer, Object.class, types, this::addKeyDeserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <E, T> void addBeanToModule(E element, Class<T> baseType, Class<?>[] types, BiConsumer<Class<T>, E> consumer) {
/* 138 */     if (ObjectUtils.isEmpty((Object[])types)) {
/* 139 */       consumer.accept(baseType, element);
/*     */       return;
/*     */     } 
/* 142 */     for (Class<?> type : types) {
/* 143 */       Assert.isAssignable(baseType, type);
/* 144 */       consumer.accept(type, element);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jackson\JsonComponentModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
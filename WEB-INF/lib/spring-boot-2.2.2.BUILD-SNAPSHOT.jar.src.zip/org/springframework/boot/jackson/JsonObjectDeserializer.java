/*     */ package org.springframework.boot.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonObjectDeserializer<T>
/*     */   extends JsonDeserializer<T>
/*     */ {
/*     */   public final T deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*     */     try {
/*  48 */       ObjectCodec codec = jp.getCodec();
/*  49 */       JsonNode tree = (JsonNode)codec.readTree(jp);
/*  50 */       return deserializeObject(jp, ctxt, codec, tree);
/*     */     }
/*  52 */     catch (Exception ex) {
/*  53 */       if (ex instanceof IOException) {
/*  54 */         throw (IOException)ex;
/*     */       }
/*  56 */       throw new JsonMappingException(jp, "Object deserialize error", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T deserializeObject(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext, ObjectCodec paramObjectCodec, JsonNode paramJsonNode) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final <D> D nullSafeValue(JsonNode jsonNode, Class<D> type) {
/*  87 */     Assert.notNull(type, "Type must not be null");
/*  88 */     if (jsonNode == null) {
/*  89 */       return null;
/*     */     }
/*  91 */     if (type == String.class) {
/*  92 */       return (D)jsonNode.textValue();
/*     */     }
/*  94 */     if (type == Boolean.class) {
/*  95 */       return (D)Boolean.valueOf(jsonNode.booleanValue());
/*     */     }
/*  97 */     if (type == Long.class) {
/*  98 */       return (D)Long.valueOf(jsonNode.longValue());
/*     */     }
/* 100 */     if (type == Integer.class) {
/* 101 */       return (D)Integer.valueOf(jsonNode.intValue());
/*     */     }
/* 103 */     if (type == Short.class) {
/* 104 */       return (D)Short.valueOf(jsonNode.shortValue());
/*     */     }
/* 106 */     if (type == Double.class) {
/* 107 */       return (D)Double.valueOf(jsonNode.doubleValue());
/*     */     }
/* 109 */     if (type == Float.class) {
/* 110 */       return (D)Float.valueOf(jsonNode.floatValue());
/*     */     }
/* 112 */     if (type == BigDecimal.class) {
/* 113 */       return (D)jsonNode.decimalValue();
/*     */     }
/* 115 */     if (type == BigInteger.class) {
/* 116 */       return (D)jsonNode.bigIntegerValue();
/*     */     }
/* 118 */     throw new IllegalArgumentException("Unsupported value type " + type.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode getRequiredNode(JsonNode tree, String fieldName) {
/* 128 */     Assert.notNull(tree, "Tree must not be null");
/* 129 */     JsonNode node = tree.get(fieldName);
/* 130 */     Assert.state((node != null && !(node instanceof com.fasterxml.jackson.databind.node.NullNode)), () -> "Missing JSON field '" + fieldName + "'");
/* 131 */     return node;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\jackson\JsonObjectDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
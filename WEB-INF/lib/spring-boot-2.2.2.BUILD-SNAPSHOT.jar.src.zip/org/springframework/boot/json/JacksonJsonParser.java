/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ import com.fasterxml.jackson.core.type.TypeReference;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JacksonJsonParser
/*    */   extends AbstractJsonParser
/*    */ {
/* 34 */   private static final MapTypeReference MAP_TYPE = new MapTypeReference();
/*    */   
/* 36 */   private static final ListTypeReference LIST_TYPE = new ListTypeReference();
/*    */ 
/*    */ 
/*    */   
/*    */   private ObjectMapper objectMapper;
/*    */ 
/*    */ 
/*    */   
/*    */   public JacksonJsonParser(ObjectMapper objectMapper) {
/* 45 */     this.objectMapper = objectMapper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JacksonJsonParser() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> parseMap(String json) {
/* 56 */     return tryParse(() -> (Map)getObjectMapper().readValue(json, MAP_TYPE), Exception.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Object> parseList(String json) {
/* 61 */     return tryParse(() -> (List)getObjectMapper().readValue(json, LIST_TYPE), Exception.class);
/*    */   }
/*    */   
/*    */   private ObjectMapper getObjectMapper() {
/* 65 */     if (this.objectMapper == null) {
/* 66 */       this.objectMapper = new ObjectMapper();
/*    */     }
/* 68 */     return this.objectMapper;
/*    */   }
/*    */   
/*    */   private static class MapTypeReference extends TypeReference<Map<String, Object>> {
/*    */     private MapTypeReference() {}
/*    */   }
/*    */   
/*    */   private static class ListTypeReference extends TypeReference<List<Object>> {
/*    */     private ListTypeReference() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\json\JacksonJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
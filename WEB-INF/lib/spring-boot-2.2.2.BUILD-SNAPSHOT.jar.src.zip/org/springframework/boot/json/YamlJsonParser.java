/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.yaml.snakeyaml.Yaml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YamlJsonParser
/*    */   extends AbstractJsonParser
/*    */ {
/*    */   public Map<String, Object> parseMap(String json) {
/* 37 */     return parseMap(json, trimmed -> (Map)(new Yaml()).loadAs(trimmed, Map.class));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Object> parseList(String json) {
/* 43 */     return parseList(json, trimmed -> (List)(new Yaml()).loadAs(trimmed, List.class));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\json\YamlJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
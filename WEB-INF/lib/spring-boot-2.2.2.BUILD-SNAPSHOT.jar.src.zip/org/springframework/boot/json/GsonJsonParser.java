/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.reflect.TypeToken;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GsonJsonParser
/*    */   extends AbstractJsonParser
/*    */ {
/* 36 */   private static final TypeToken<?> MAP_TYPE = new MapTypeToken();
/*    */   
/* 38 */   private static final TypeToken<?> LIST_TYPE = new ListTypeToken();
/*    */   
/* 40 */   private Gson gson = (new GsonBuilder()).create();
/*    */ 
/*    */   
/*    */   public Map<String, Object> parseMap(String json) {
/* 44 */     return parseMap(json, trimmed -> (Map)this.gson.fromJson(trimmed, MAP_TYPE.getType()));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Object> parseList(String json) {
/* 49 */     return parseList(json, trimmed -> (List)this.gson.fromJson(trimmed, LIST_TYPE.getType()));
/*    */   }
/*    */   
/*    */   private static final class MapTypeToken extends TypeToken<Map<String, Object>> {
/*    */     private MapTypeToken() {}
/*    */   }
/*    */   
/*    */   private static final class ListTypeToken extends TypeToken<List<Object>> {
/*    */     private ListTypeToken() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\json\GsonJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
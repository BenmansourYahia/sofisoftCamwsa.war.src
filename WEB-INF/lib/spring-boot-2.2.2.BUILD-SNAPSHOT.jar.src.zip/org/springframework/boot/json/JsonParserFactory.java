/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JsonParserFactory
/*    */ {
/*    */   public static JsonParser getJsonParser() {
/* 39 */     if (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", null)) {
/* 40 */       return new JacksonJsonParser();
/*    */     }
/* 42 */     if (ClassUtils.isPresent("com.google.gson.Gson", null)) {
/* 43 */       return new GsonJsonParser();
/*    */     }
/* 45 */     if (ClassUtils.isPresent("org.yaml.snakeyaml.Yaml", null)) {
/* 46 */       return new YamlJsonParser();
/*    */     }
/* 48 */     return new BasicJsonParser();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\json\JsonParserFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
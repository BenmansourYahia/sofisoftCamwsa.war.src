package org.springframework.boot.json;

import java.util.List;
import java.util.Map;

public interface JsonParser {
  Map<String, Object> parseMap(String paramString) throws JsonParseException;
  
  List<Object> parseList(String paramString) throws JsonParseException;
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\json\JsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
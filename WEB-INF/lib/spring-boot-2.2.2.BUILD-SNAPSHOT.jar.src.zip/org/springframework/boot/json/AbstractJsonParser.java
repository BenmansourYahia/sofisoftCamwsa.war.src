/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractJsonParser
/*    */   implements JsonParser
/*    */ {
/*    */   protected final Map<String, Object> parseMap(String json, Function<String, Map<String, Object>> parser) {
/* 36 */     return trimParse(json, "{", parser);
/*    */   }
/*    */   
/*    */   protected final List<Object> parseList(String json, Function<String, List<Object>> parser) {
/* 40 */     return trimParse(json, "[", parser);
/*    */   }
/*    */   
/*    */   protected final <T> T trimParse(String json, String prefix, Function<String, T> parser) {
/* 44 */     String trimmed = (json != null) ? json.trim() : "";
/* 45 */     if (trimmed.startsWith(prefix)) {
/* 46 */       return parser.apply(trimmed);
/*    */     }
/* 48 */     throw new JsonParseException();
/*    */   }
/*    */   
/*    */   protected final <T> T tryParse(Callable<T> parser, Class<? extends Exception> check) {
/*    */     try {
/* 53 */       return parser.call();
/*    */     }
/* 55 */     catch (Exception ex) {
/* 56 */       if (check.isAssignableFrom(ex.getClass())) {
/* 57 */         throw new JsonParseException(ex);
/*    */       }
/* 59 */       ReflectionUtils.rethrowRuntimeException(ex);
/* 60 */       throw new IllegalStateException(ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\json\AbstractJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
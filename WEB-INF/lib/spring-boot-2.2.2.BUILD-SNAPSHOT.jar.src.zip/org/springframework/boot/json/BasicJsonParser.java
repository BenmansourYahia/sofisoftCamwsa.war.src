/*     */ package org.springframework.boot.json;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicJsonParser
/*     */   extends AbstractJsonParser
/*     */ {
/*     */   public Map<String, Object> parseMap(String json) {
/*  42 */     return parseMap(json, this::parseMapInternal);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Object> parseList(String json) {
/*  47 */     return parseList(json, this::parseListInternal);
/*     */   }
/*     */   
/*     */   private List<Object> parseListInternal(String json) {
/*  51 */     List<Object> list = new ArrayList();
/*  52 */     json = trimLeadingCharacter(trimTrailingCharacter(json, ']'), '[').trim();
/*  53 */     for (String value : tokenize(json)) {
/*  54 */       list.add(parseInternal(value));
/*     */     }
/*  56 */     return list;
/*     */   }
/*     */   
/*     */   private Object parseInternal(String json) {
/*  60 */     if (json.startsWith("[")) {
/*  61 */       return parseListInternal(json);
/*     */     }
/*  63 */     if (json.startsWith("{")) {
/*  64 */       return parseMapInternal(json);
/*     */     }
/*  66 */     if (json.startsWith("\"")) {
/*  67 */       return trimTrailingCharacter(trimLeadingCharacter(json, '"'), '"');
/*     */     }
/*     */     try {
/*  70 */       return Long.valueOf(json);
/*     */     }
/*  72 */     catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */       
/*     */       try {
/*  76 */         return Double.valueOf(json);
/*     */       }
/*  78 */       catch (NumberFormatException numberFormatException1) {
/*     */ 
/*     */         
/*  81 */         return json;
/*     */       } 
/*     */     } 
/*     */   } private static String trimTrailingCharacter(String string, char c) {
/*  85 */     if (!string.isEmpty() && string.charAt(string.length() - 1) == c) {
/*  86 */       return string.substring(0, string.length() - 1);
/*     */     }
/*  88 */     return string;
/*     */   }
/*     */   
/*     */   private static String trimLeadingCharacter(String string, char c) {
/*  92 */     if (!string.isEmpty() && string.charAt(0) == c) {
/*  93 */       return string.substring(1);
/*     */     }
/*  95 */     return string;
/*     */   }
/*     */   
/*     */   private Map<String, Object> parseMapInternal(String json) {
/*  99 */     Map<String, Object> map = new LinkedHashMap<>();
/* 100 */     json = trimLeadingCharacter(trimTrailingCharacter(json, '}'), '{').trim();
/* 101 */     for (String pair : tokenize(json)) {
/* 102 */       String[] values = StringUtils.trimArrayElements(StringUtils.split(pair, ":"));
/* 103 */       String key = trimLeadingCharacter(trimTrailingCharacter(values[0], '"'), '"');
/* 104 */       Object value = parseInternal(values[1]);
/* 105 */       map.put(key, value);
/*     */     } 
/* 107 */     return map;
/*     */   }
/*     */   
/*     */   private List<String> tokenize(String json) {
/* 111 */     List<String> list = new ArrayList<>();
/* 112 */     int index = 0;
/* 113 */     int inObject = 0;
/* 114 */     int inList = 0;
/* 115 */     boolean inValue = false;
/* 116 */     boolean inEscape = false;
/* 117 */     StringBuilder build = new StringBuilder();
/* 118 */     while (index < json.length()) {
/* 119 */       char current = json.charAt(index);
/* 120 */       if (inEscape) {
/* 121 */         build.append(current);
/* 122 */         index++;
/* 123 */         inEscape = false;
/*     */         continue;
/*     */       } 
/* 126 */       if (current == '{') {
/* 127 */         inObject++;
/*     */       }
/* 129 */       if (current == '}') {
/* 130 */         inObject--;
/*     */       }
/* 132 */       if (current == '[') {
/* 133 */         inList++;
/*     */       }
/* 135 */       if (current == ']') {
/* 136 */         inList--;
/*     */       }
/* 138 */       if (current == '"') {
/* 139 */         inValue = !inValue;
/*     */       }
/* 141 */       if (current == ',' && inObject == 0 && inList == 0 && !inValue) {
/* 142 */         list.add(build.toString());
/* 143 */         build.setLength(0);
/*     */       }
/* 145 */       else if (current == '\\') {
/* 146 */         inEscape = true;
/*     */       } else {
/*     */         
/* 149 */         build.append(current);
/*     */       } 
/* 151 */       index++;
/*     */     } 
/* 153 */     if (build.length() > 0) {
/* 154 */       list.add(build.toString().trim());
/*     */     }
/* 156 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\json\BasicJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
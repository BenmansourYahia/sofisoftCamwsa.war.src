/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.time.Instant;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GitProperties
/*     */   extends InfoProperties
/*     */ {
/*     */   public GitProperties(Properties entries) {
/*  33 */     super(processEntries(entries));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBranch() {
/*  41 */     return get("branch");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommitId() {
/*  49 */     return get("commit.id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getShortCommitId() {
/*  57 */     String shortId = get("commit.id.abbrev");
/*  58 */     if (shortId != null) {
/*  59 */       return shortId;
/*     */     }
/*  61 */     String id = getCommitId();
/*  62 */     if (id == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     return (id.length() > 7) ? id.substring(0, 7) : id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getCommitTime() {
/*  77 */     return getInstant("commit.time");
/*     */   }
/*     */   
/*     */   private static Properties processEntries(Properties properties) {
/*  81 */     coercePropertyToEpoch(properties, "commit.time");
/*  82 */     coercePropertyToEpoch(properties, "build.time");
/*  83 */     Object commitId = properties.get("commit.id");
/*  84 */     if (commitId != null)
/*     */     {
/*  86 */       properties.put("commit.id.full", commitId);
/*     */     }
/*  88 */     return properties;
/*     */   }
/*     */   
/*     */   private static void coercePropertyToEpoch(Properties properties, String key) {
/*  92 */     String value = properties.getProperty(key);
/*  93 */     if (value != null) {
/*  94 */       properties.setProperty(key, coerceToEpoch(value));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String coerceToEpoch(String s) {
/* 107 */     Long epoch = parseEpochSecond(s);
/* 108 */     if (epoch != null) {
/* 109 */       return String.valueOf(epoch);
/*     */     }
/* 111 */     SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
/*     */     try {
/* 113 */       return String.valueOf(format.parse(s).getTime());
/*     */     }
/* 115 */     catch (ParseException ex) {
/* 116 */       return s;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Long parseEpochSecond(String s) {
/*     */     try {
/* 122 */       return Long.valueOf(Long.parseLong(s) * 1000L);
/*     */     }
/* 124 */     catch (NumberFormatException ex) {
/* 125 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\info\GitProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoProperties
/*     */   implements Iterable<InfoProperties.Entry>
/*     */ {
/*     */   private final Properties entries;
/*     */   
/*     */   public InfoProperties(Properties entries) {
/*  44 */     Assert.notNull(entries, "Entries must not be null");
/*  45 */     this.entries = copy(entries);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(String key) {
/*  54 */     return this.entries.getProperty(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getInstant(String key) {
/*  64 */     String s = get(key);
/*  65 */     if (s != null) {
/*     */       try {
/*  67 */         return Instant.ofEpochMilli(Long.parseLong(s));
/*     */       }
/*  69 */       catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */     
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Entry> iterator() {
/*  78 */     return new PropertiesIterator(this.entries);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertySource<?> toPropertySource() {
/*  86 */     return (PropertySource<?>)new PropertiesPropertySource(getClass().getSimpleName(), copy(this.entries));
/*     */   }
/*     */   
/*     */   private Properties copy(Properties properties) {
/*  90 */     Properties copy = new Properties();
/*  91 */     copy.putAll(properties);
/*  92 */     return copy;
/*     */   }
/*     */   
/*     */   private final class PropertiesIterator
/*     */     implements Iterator<Entry> {
/*     */     private final Iterator<Map.Entry<Object, Object>> iterator;
/*     */     
/*     */     private PropertiesIterator(Properties properties) {
/* 100 */       this.iterator = properties.entrySet().iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 105 */       return this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public InfoProperties.Entry next() {
/* 110 */       Map.Entry<Object, Object> entry = this.iterator.next();
/* 111 */       return new InfoProperties.Entry((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 116 */       throw new UnsupportedOperationException("InfoProperties are immutable.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Entry
/*     */   {
/*     */     private final String key;
/*     */ 
/*     */     
/*     */     private final String value;
/*     */ 
/*     */     
/*     */     private Entry(String key, String value) {
/* 131 */       this.key = key;
/* 132 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String getKey() {
/* 136 */       return this.key;
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 140 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\info\InfoProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
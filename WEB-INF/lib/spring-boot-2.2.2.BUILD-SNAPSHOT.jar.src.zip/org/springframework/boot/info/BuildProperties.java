/*    */ package org.springframework.boot.info;
/*    */ 
/*    */ import java.time.DateTimeException;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuildProperties
/*    */   extends InfoProperties
/*    */ {
/*    */   public BuildProperties(Properties entries) {
/* 37 */     super(processEntries(entries));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getGroup() {
/* 45 */     return get("group");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getArtifact() {
/* 53 */     return get("artifact");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 61 */     return get("name");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getVersion() {
/* 69 */     return get("version");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Instant getTime() {
/* 81 */     return getInstant("time");
/*    */   }
/*    */   
/*    */   private static Properties processEntries(Properties properties) {
/* 85 */     coerceDate(properties, "time");
/* 86 */     return properties;
/*    */   }
/*    */   
/*    */   private static void coerceDate(Properties properties, String key) {
/* 90 */     String value = properties.getProperty(key);
/* 91 */     if (value != null)
/*    */       
/*    */       try {
/* 94 */         String updatedValue = String.valueOf(((Instant)DateTimeFormatter.ISO_INSTANT.<Instant>parse(value, Instant::from)).toEpochMilli());
/* 95 */         properties.setProperty(key, updatedValue);
/*    */       }
/* 97 */       catch (DateTimeException dateTimeException) {} 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\info\BuildProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
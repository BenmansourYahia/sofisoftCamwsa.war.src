/*    */ package org.springframework.boot.orm.jpa.hibernate;
/*    */ 
/*    */ import org.hibernate.boot.model.naming.Identifier;
/*    */ import org.hibernate.boot.model.naming.ImplicitJoinTableNameSource;
/*    */ import org.hibernate.boot.model.naming.ImplicitNamingStrategyJpaCompliantImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringImplicitNamingStrategy
/*    */   extends ImplicitNamingStrategyJpaCompliantImpl
/*    */ {
/*    */   public Identifier determineJoinTableName(ImplicitJoinTableNameSource source) {
/* 39 */     String name = source.getOwningPhysicalTableName() + "_" + source.getAssociationOwningAttributePath().getProperty();
/* 40 */     return toIdentifier(name, source.getBuildingContext());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\orm\jpa\hibernate\SpringImplicitNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.orm.jpa;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.orm.jpa.JpaVendorAdapter;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityManagerFactoryBuilder
/*     */ {
/*     */   private final JpaVendorAdapter jpaVendorAdapter;
/*     */   private final PersistenceUnitManager persistenceUnitManager;
/*     */   private final Map<String, Object> jpaProperties;
/*     */   private final URL persistenceUnitRootLocation;
/*     */   private AsyncTaskExecutor bootstrapExecutor;
/*     */   
/*     */   public EntityManagerFactoryBuilder(JpaVendorAdapter jpaVendorAdapter, Map<String, ?> jpaProperties, PersistenceUnitManager persistenceUnitManager) {
/*  71 */     this(jpaVendorAdapter, jpaProperties, persistenceUnitManager, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityManagerFactoryBuilder(JpaVendorAdapter jpaVendorAdapter, Map<String, ?> jpaProperties, PersistenceUnitManager persistenceUnitManager, URL persistenceUnitRootLocation) {
/*  87 */     this.jpaVendorAdapter = jpaVendorAdapter;
/*  88 */     this.persistenceUnitManager = persistenceUnitManager;
/*  89 */     this.jpaProperties = new LinkedHashMap<>(jpaProperties);
/*  90 */     this.persistenceUnitRootLocation = persistenceUnitRootLocation;
/*     */   }
/*     */   
/*     */   public Builder dataSource(DataSource dataSource) {
/*  94 */     return new Builder(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBootstrapExecutor(AsyncTaskExecutor bootstrapExecutor) {
/* 104 */     this.bootstrapExecutor = bootstrapExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Builder
/*     */   {
/*     */     private DataSource dataSource;
/*     */ 
/*     */     
/*     */     private String[] packagesToScan;
/*     */     
/*     */     private String persistenceUnit;
/*     */     
/* 118 */     private Map<String, Object> properties = new HashMap<>();
/*     */     
/*     */     private String[] mappingResources;
/*     */     
/*     */     private boolean jta;
/*     */     
/*     */     private Builder(DataSource dataSource) {
/* 125 */       this.dataSource = dataSource;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder packages(String... packagesToScan) {
/* 134 */       this.packagesToScan = packagesToScan;
/* 135 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder packages(Class<?>... basePackageClasses) {
/* 144 */       Set<String> packages = new HashSet<>();
/* 145 */       for (Class<?> type : basePackageClasses) {
/* 146 */         packages.add(ClassUtils.getPackageName(type));
/*     */       }
/* 148 */       this.packagesToScan = StringUtils.toStringArray(packages);
/* 149 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder persistenceUnit(String persistenceUnit) {
/* 160 */       this.persistenceUnit = persistenceUnit;
/* 161 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder properties(Map<String, ?> properties) {
/* 171 */       this.properties.putAll(properties);
/* 172 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder mappingResources(String... mappingResources) {
/* 186 */       this.mappingResources = mappingResources;
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder jta(boolean jta) {
/* 201 */       this.jta = jta;
/* 202 */       return this;
/*     */     }
/*     */     
/*     */     public LocalContainerEntityManagerFactoryBean build() {
/* 206 */       LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
/* 207 */       if (EntityManagerFactoryBuilder.this.persistenceUnitManager != null) {
/* 208 */         entityManagerFactoryBean
/* 209 */           .setPersistenceUnitManager(EntityManagerFactoryBuilder.this.persistenceUnitManager);
/*     */       }
/* 211 */       if (this.persistenceUnit != null) {
/* 212 */         entityManagerFactoryBean.setPersistenceUnitName(this.persistenceUnit);
/*     */       }
/* 214 */       entityManagerFactoryBean.setJpaVendorAdapter(EntityManagerFactoryBuilder.this.jpaVendorAdapter);
/*     */       
/* 216 */       if (this.jta) {
/* 217 */         entityManagerFactoryBean.setJtaDataSource(this.dataSource);
/*     */       } else {
/*     */         
/* 220 */         entityManagerFactoryBean.setDataSource(this.dataSource);
/*     */       } 
/* 222 */       entityManagerFactoryBean.setPackagesToScan(this.packagesToScan);
/* 223 */       entityManagerFactoryBean.getJpaPropertyMap().putAll(EntityManagerFactoryBuilder.this.jpaProperties);
/* 224 */       entityManagerFactoryBean.getJpaPropertyMap().putAll(this.properties);
/* 225 */       if (!ObjectUtils.isEmpty((Object[])this.mappingResources)) {
/* 226 */         entityManagerFactoryBean.setMappingResources(this.mappingResources);
/*     */       }
/* 228 */       URL rootLocation = EntityManagerFactoryBuilder.this.persistenceUnitRootLocation;
/* 229 */       if (rootLocation != null) {
/* 230 */         entityManagerFactoryBean.setPersistenceUnitRootLocation(rootLocation.toString());
/*     */       }
/* 232 */       if (EntityManagerFactoryBuilder.this.bootstrapExecutor != null) {
/* 233 */         entityManagerFactoryBean.setBootstrapExecutor(EntityManagerFactoryBuilder.this.bootstrapExecutor);
/*     */       }
/* 235 */       return entityManagerFactoryBean;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\orm\jpa\EntityManagerFactoryBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
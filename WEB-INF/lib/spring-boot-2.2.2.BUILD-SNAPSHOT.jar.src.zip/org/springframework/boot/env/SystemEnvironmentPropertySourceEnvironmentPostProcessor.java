/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.boot.origin.OriginLookup;
/*    */ import org.springframework.boot.origin.SystemEnvironmentOrigin;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.env.SystemEnvironmentPropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemEnvironmentPropertySourceEnvironmentPostProcessor
/*    */   implements EnvironmentPostProcessor, Ordered
/*    */ {
/*    */   public static final int DEFAULT_ORDER = -2147483644;
/* 47 */   private int order = -2147483644;
/*    */ 
/*    */   
/*    */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/* 51 */     String sourceName = "systemEnvironment";
/* 52 */     PropertySource<?> propertySource = environment.getPropertySources().get(sourceName);
/* 53 */     if (propertySource != null) {
/* 54 */       replacePropertySource(environment, sourceName, propertySource);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void replacePropertySource(ConfigurableEnvironment environment, String sourceName, PropertySource<?> propertySource) {
/* 61 */     Map<String, Object> originalSource = (Map<String, Object>)propertySource.getSource();
/* 62 */     SystemEnvironmentPropertySource source = new OriginAwareSystemEnvironmentPropertySource(sourceName, originalSource);
/*    */     
/* 64 */     environment.getPropertySources().replace(sourceName, (PropertySource)source);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 69 */     return this.order;
/*    */   }
/*    */   
/*    */   public void setOrder(int order) {
/* 73 */     this.order = order;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected static class OriginAwareSystemEnvironmentPropertySource
/*    */     extends SystemEnvironmentPropertySource
/*    */     implements OriginLookup<String>
/*    */   {
/*    */     OriginAwareSystemEnvironmentPropertySource(String name, Map<String, Object> source) {
/* 83 */       super(name, source);
/*    */     }
/*    */ 
/*    */     
/*    */     public Origin getOrigin(String key) {
/* 88 */       String property = resolvePropertyName(key);
/* 89 */       if (containsProperty(property)) {
/* 90 */         return (Origin)new SystemEnvironmentOrigin(property);
/*    */       }
/* 92 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\env\SystemEnvironmentPropertySourceEnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
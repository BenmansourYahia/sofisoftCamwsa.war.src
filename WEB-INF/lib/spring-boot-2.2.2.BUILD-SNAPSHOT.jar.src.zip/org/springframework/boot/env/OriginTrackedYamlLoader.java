/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.factory.config.YamlProcessor;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginTrackedValue;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.Yaml;
/*     */ import org.yaml.snakeyaml.constructor.BaseConstructor;
/*     */ import org.yaml.snakeyaml.constructor.Constructor;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.representer.Representer;
/*     */ import org.yaml.snakeyaml.resolver.Resolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OriginTrackedYamlLoader
/*     */   extends YamlProcessor
/*     */ {
/*     */   private final Resource resource;
/*     */   
/*     */   OriginTrackedYamlLoader(Resource resource) {
/*  58 */     this.resource = resource;
/*  59 */     setResources(new Resource[] { resource });
/*     */   }
/*     */ 
/*     */   
/*     */   protected Yaml createYaml() {
/*  64 */     OriginTrackingConstructor originTrackingConstructor = new OriginTrackingConstructor();
/*  65 */     Representer representer = new Representer();
/*  66 */     DumperOptions dumperOptions = new DumperOptions();
/*  67 */     LimitedResolver resolver = new LimitedResolver();
/*  68 */     LoaderOptions loaderOptions = new LoaderOptions();
/*  69 */     loaderOptions.setAllowDuplicateKeys(false);
/*  70 */     return new Yaml((BaseConstructor)originTrackingConstructor, representer, dumperOptions, loaderOptions, resolver);
/*     */   }
/*     */   
/*     */   List<Map<String, Object>> load() {
/*  74 */     List<Map<String, Object>> result = new ArrayList<>();
/*  75 */     process((properties, map) -> result.add(getFlattenedMap(map)));
/*  76 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private class OriginTrackingConstructor
/*     */     extends Constructor
/*     */   {
/*     */     private OriginTrackingConstructor() {}
/*     */     
/*     */     protected Object constructObject(Node node) {
/*  86 */       if (node instanceof ScalarNode) {
/*  87 */         if (!(node instanceof OriginTrackedYamlLoader.KeyScalarNode)) {
/*  88 */           return constructTrackedObject(node, super.constructObject(node));
/*     */         }
/*     */       }
/*  91 */       else if (node instanceof MappingNode) {
/*  92 */         replaceMappingNodeKeys((MappingNode)node);
/*     */       } 
/*  94 */       return super.constructObject(node);
/*     */     }
/*     */     
/*     */     private void replaceMappingNodeKeys(MappingNode node) {
/*  98 */       node.setValue((List)node.getValue().stream().map(OriginTrackedYamlLoader.KeyScalarNode::get).collect(Collectors.toList()));
/*     */     }
/*     */     
/*     */     private Object constructTrackedObject(Node node, Object value) {
/* 102 */       Origin origin = getOrigin(node);
/* 103 */       return OriginTrackedValue.of(getValue(value), origin);
/*     */     }
/*     */     
/*     */     private Object getValue(Object value) {
/* 107 */       return (value != null) ? value : "";
/*     */     }
/*     */     
/*     */     private Origin getOrigin(Node node) {
/* 111 */       Mark mark = node.getStartMark();
/* 112 */       TextResourceOrigin.Location location = new TextResourceOrigin.Location(mark.getLine(), mark.getColumn());
/* 113 */       return (Origin)new TextResourceOrigin(OriginTrackedYamlLoader.this.resource, location);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KeyScalarNode
/*     */     extends ScalarNode
/*     */   {
/*     */     KeyScalarNode(ScalarNode node) {
/* 124 */       super(node.getTag(), node.getValue(), node.getStartMark(), node.getEndMark(), node.getScalarStyle());
/*     */     }
/*     */     
/*     */     static NodeTuple get(NodeTuple nodeTuple) {
/* 128 */       Node keyNode = nodeTuple.getKeyNode();
/* 129 */       Node valueNode = nodeTuple.getValueNode();
/* 130 */       return new NodeTuple(get(keyNode), valueNode);
/*     */     }
/*     */     
/*     */     private static Node get(Node node) {
/* 134 */       if (node instanceof ScalarNode) {
/* 135 */         return (Node)new KeyScalarNode((ScalarNode)node);
/*     */       }
/* 137 */       return node;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LimitedResolver
/*     */     extends Resolver
/*     */   {
/*     */     private LimitedResolver() {}
/*     */ 
/*     */     
/*     */     public void addImplicitResolver(Tag tag, Pattern regexp, String first) {
/* 149 */       if (tag == Tag.TIMESTAMP) {
/*     */         return;
/*     */       }
/* 152 */       super.addImplicitResolver(tag, regexp, first);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\env\OriginTrackedYamlLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
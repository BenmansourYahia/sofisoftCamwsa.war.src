/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesPropertySourceLoader
/*    */   implements PropertySourceLoader
/*    */ {
/*    */   private static final String XML_FILE_EXTENSION = ".xml";
/*    */   
/*    */   public String[] getFileExtensions() {
/* 42 */     return new String[] { "properties", "xml" };
/*    */   }
/*    */ 
/*    */   
/*    */   public List<PropertySource<?>> load(String name, Resource resource) throws IOException {
/* 47 */     Map<String, ?> properties = loadProperties(resource);
/* 48 */     if (properties.isEmpty()) {
/* 49 */       return Collections.emptyList();
/*    */     }
/* 51 */     return 
/* 52 */       (List)Collections.singletonList(new OriginTrackedMapPropertySource(name, Collections.unmodifiableMap(properties), true));
/*    */   }
/*    */ 
/*    */   
/*    */   private Map<String, ?> loadProperties(Resource resource) throws IOException {
/* 57 */     String filename = resource.getFilename();
/* 58 */     if (filename != null && filename.endsWith(".xml")) {
/* 59 */       return PropertiesLoaderUtils.loadProperties(resource);
/*    */     }
/* 61 */     return (new OriginTrackedPropertiesLoader(resource)).load();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\env\PropertiesPropertySourceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
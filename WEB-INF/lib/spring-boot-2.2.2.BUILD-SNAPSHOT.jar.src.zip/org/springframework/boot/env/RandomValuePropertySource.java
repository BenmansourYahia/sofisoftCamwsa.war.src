/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.DigestUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomValuePropertySource
/*     */   extends PropertySource<Random>
/*     */ {
/*     */   public static final String RANDOM_PROPERTY_SOURCE_NAME = "random";
/*     */   private static final String PREFIX = "random.";
/*  63 */   private static final Log logger = LogFactory.getLog(RandomValuePropertySource.class);
/*     */   
/*     */   public RandomValuePropertySource(String name) {
/*  66 */     super(name, new Random());
/*     */   }
/*     */   
/*     */   public RandomValuePropertySource() {
/*  70 */     this("random");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) {
/*  75 */     if (!name.startsWith("random.")) {
/*  76 */       return null;
/*     */     }
/*  78 */     if (logger.isTraceEnabled()) {
/*  79 */       logger.trace("Generating random property for '" + name + "'");
/*     */     }
/*  81 */     return getRandomValue(name.substring("random.".length()));
/*     */   }
/*     */   
/*     */   private Object getRandomValue(String type) {
/*  85 */     if (type.equals("int")) {
/*  86 */       return Integer.valueOf(((Random)getSource()).nextInt());
/*     */     }
/*  88 */     if (type.equals("long")) {
/*  89 */       return Long.valueOf(((Random)getSource()).nextLong());
/*     */     }
/*  91 */     String range = getRange(type, "int");
/*  92 */     if (range != null) {
/*  93 */       return Integer.valueOf(getNextIntInRange(range));
/*     */     }
/*  95 */     range = getRange(type, "long");
/*  96 */     if (range != null) {
/*  97 */       return Long.valueOf(getNextLongInRange(range));
/*     */     }
/*  99 */     if (type.equals("uuid")) {
/* 100 */       return UUID.randomUUID().toString();
/*     */     }
/* 102 */     return getRandomBytes();
/*     */   }
/*     */   
/*     */   private String getRange(String type, String prefix) {
/* 106 */     if (type.startsWith(prefix)) {
/* 107 */       int startIndex = prefix.length() + 1;
/* 108 */       if (type.length() > startIndex) {
/* 109 */         return type.substring(startIndex, type.length() - 1);
/*     */       }
/*     */     } 
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   private int getNextIntInRange(String range) {
/* 116 */     String[] tokens = StringUtils.commaDelimitedListToStringArray(range);
/* 117 */     int start = Integer.parseInt(tokens[0]);
/* 118 */     if (tokens.length == 1) {
/* 119 */       return ((Random)getSource()).nextInt(start);
/*     */     }
/* 121 */     return start + ((Random)getSource()).nextInt(Integer.parseInt(tokens[1]) - start);
/*     */   }
/*     */   
/*     */   private long getNextLongInRange(String range) {
/* 125 */     String[] tokens = StringUtils.commaDelimitedListToStringArray(range);
/* 126 */     if (tokens.length == 1) {
/* 127 */       return Math.abs(((Random)getSource()).nextLong() % Long.parseLong(tokens[0]));
/*     */     }
/* 129 */     long lowerBound = Long.parseLong(tokens[0]);
/* 130 */     long upperBound = Long.parseLong(tokens[1]) - lowerBound;
/* 131 */     return lowerBound + Math.abs(((Random)getSource()).nextLong() % upperBound);
/*     */   }
/*     */   
/*     */   private Object getRandomBytes() {
/* 135 */     byte[] bytes = new byte[32];
/* 136 */     ((Random)getSource()).nextBytes(bytes);
/* 137 */     return DigestUtils.md5DigestAsHex(bytes);
/*     */   }
/*     */   
/*     */   public static void addToEnvironment(ConfigurableEnvironment environment) {
/* 141 */     environment.getPropertySources().addAfter("systemEnvironment", new RandomValuePropertySource("random"));
/*     */     
/* 143 */     logger.trace("RandomValuePropertySource add to Environment");
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\env\RandomValuePropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
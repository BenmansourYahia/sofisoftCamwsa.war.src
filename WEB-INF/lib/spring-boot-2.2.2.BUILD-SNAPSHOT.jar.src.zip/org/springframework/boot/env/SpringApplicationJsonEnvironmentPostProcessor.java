/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.json.JsonParser;
/*     */ import org.springframework.boot.json.JsonParserFactory;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringApplicationJsonEnvironmentPostProcessor
/*     */   implements EnvironmentPostProcessor, Ordered
/*     */ {
/*     */   public static final String SPRING_APPLICATION_JSON_PROPERTY = "spring.application.json";
/*     */   public static final String SPRING_APPLICATION_JSON_ENVIRONMENT_VARIABLE = "SPRING_APPLICATION_JSON";
/*     */   private static final String SERVLET_ENVIRONMENT_CLASS = "org.springframework.web.context.support.StandardServletEnvironment";
/*  71 */   private static final Set<String> SERVLET_ENVIRONMENT_PROPERTY_SOURCES = new LinkedHashSet<>(
/*  72 */       Arrays.asList(new String[] { "jndiProperties", "servletContextInitParams", "servletConfigInitParams" }));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_ORDER = -2147483643;
/*     */ 
/*     */ 
/*     */   
/*  81 */   private int order = -2147483643;
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  85 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  89 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/*  94 */     MutablePropertySources propertySources = environment.getPropertySources();
/*  95 */     propertySources.stream().map(JsonPropertyValue::get).filter(Objects::nonNull).findFirst()
/*  96 */       .ifPresent(v -> processJson(environment, v));
/*     */   }
/*     */   
/*     */   private void processJson(ConfigurableEnvironment environment, JsonPropertyValue propertyValue) {
/* 100 */     JsonParser parser = JsonParserFactory.getJsonParser();
/* 101 */     Map<String, Object> map = parser.parseMap(propertyValue.getJson());
/* 102 */     if (!map.isEmpty()) {
/* 103 */       addJsonPropertySource(environment, (PropertySource<?>)new JsonPropertySource(propertyValue, flatten(map)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> flatten(Map<String, Object> map) {
/* 113 */     Map<String, Object> result = new LinkedHashMap<>();
/* 114 */     flatten(null, result, map);
/* 115 */     return result;
/*     */   }
/*     */   
/*     */   private void flatten(String prefix, Map<String, Object> result, Map<String, Object> map) {
/* 119 */     String namePrefix = (prefix != null) ? (prefix + ".") : "";
/* 120 */     map.forEach((key, value) -> extract(namePrefix + key, result, value));
/*     */   }
/*     */ 
/*     */   
/*     */   private void extract(String name, Map<String, Object> result, Object value) {
/* 125 */     if (value instanceof Map) {
/* 126 */       flatten(name, result, (Map<String, Object>)value);
/*     */     }
/* 128 */     else if (value instanceof java.util.Collection) {
/* 129 */       int index = 0;
/* 130 */       for (Object object : value) {
/* 131 */         extract(name + "[" + index + "]", result, object);
/* 132 */         index++;
/*     */       } 
/*     */     } else {
/*     */       
/* 136 */       result.put(name, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addJsonPropertySource(ConfigurableEnvironment environment, PropertySource<?> source) {
/* 141 */     MutablePropertySources sources = environment.getPropertySources();
/* 142 */     String name = findPropertySource(sources);
/* 143 */     if (sources.contains(name)) {
/* 144 */       sources.addBefore(name, source);
/*     */     } else {
/*     */       
/* 147 */       sources.addFirst(source);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String findPropertySource(MutablePropertySources sources) {
/* 152 */     if (ClassUtils.isPresent("org.springframework.web.context.support.StandardServletEnvironment", null)) {
/*     */ 
/*     */       
/* 155 */       PropertySource<?> servletPropertySource = sources.stream().filter(source -> SERVLET_ENVIRONMENT_PROPERTY_SOURCES.contains(source.getName())).findFirst().orElse(null);
/* 156 */       if (servletPropertySource != null) {
/* 157 */         return servletPropertySource.getName();
/*     */       }
/*     */     } 
/* 160 */     return "systemProperties";
/*     */   }
/*     */   
/*     */   private static class JsonPropertySource
/*     */     extends MapPropertySource implements OriginLookup<String> {
/*     */     private final SpringApplicationJsonEnvironmentPostProcessor.JsonPropertyValue propertyValue;
/*     */     
/*     */     JsonPropertySource(SpringApplicationJsonEnvironmentPostProcessor.JsonPropertyValue propertyValue, Map<String, Object> source) {
/* 168 */       super("spring.application.json", source);
/* 169 */       this.propertyValue = propertyValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public Origin getOrigin(String key) {
/* 174 */       return this.propertyValue.getOrigin();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class JsonPropertyValue
/*     */   {
/* 181 */     private static final String[] CANDIDATES = new String[] { "spring.application.json", "SPRING_APPLICATION_JSON" };
/*     */     
/*     */     private final PropertySource<?> propertySource;
/*     */     
/*     */     private final String propertyName;
/*     */     
/*     */     private final String json;
/*     */ 
/*     */     
/*     */     JsonPropertyValue(PropertySource<?> propertySource, String propertyName, String json) {
/* 191 */       this.propertySource = propertySource;
/* 192 */       this.propertyName = propertyName;
/* 193 */       this.json = json;
/*     */     }
/*     */     
/*     */     String getJson() {
/* 197 */       return this.json;
/*     */     }
/*     */     
/*     */     Origin getOrigin() {
/* 201 */       return PropertySourceOrigin.get(this.propertySource, this.propertyName);
/*     */     }
/*     */     
/*     */     static JsonPropertyValue get(PropertySource<?> propertySource) {
/* 205 */       for (String candidate : CANDIDATES) {
/* 206 */         Object value = propertySource.getProperty(candidate);
/* 207 */         if (value instanceof String && StringUtils.hasLength((String)value)) {
/* 208 */           return new JsonPropertyValue(propertySource, candidate, (String)value);
/*     */         }
/*     */       } 
/* 211 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\env\SpringApplicationJsonEnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
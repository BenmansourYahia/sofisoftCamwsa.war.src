/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.LineNumberReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginTrackedValue;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OriginTrackedPropertiesLoader
/*     */ {
/*     */   private final Resource resource;
/*     */   
/*     */   OriginTrackedPropertiesLoader(Resource resource) {
/*  52 */     Assert.notNull(resource, "Resource must not be null");
/*  53 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, OriginTrackedValue> load() throws IOException {
/*  63 */     return load(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, OriginTrackedValue> load(boolean expandLists) throws IOException {
/*  74 */     try (CharacterReader reader = new CharacterReader(this.resource)) {
/*  75 */       Map<String, OriginTrackedValue> result = new LinkedHashMap<>();
/*  76 */       StringBuilder buffer = new StringBuilder();
/*  77 */       label39: while (reader.read()) {
/*  78 */         String key = loadKey(buffer, reader).trim();
/*  79 */         if (expandLists && key.endsWith("[]")) {
/*  80 */           key = key.substring(0, key.length() - 2);
/*  81 */           int index = 0;
/*     */           while (true) {
/*  83 */             OriginTrackedValue originTrackedValue = loadValue(buffer, reader, true);
/*  84 */             put(result, key + "[" + index++ + "]", originTrackedValue);
/*  85 */             if (!reader.isEndOfLine()) {
/*  86 */               reader.read();
/*     */             }
/*     */             
/*  89 */             if (reader.isEndOfLine())
/*     */               continue label39; 
/*     */           } 
/*  92 */         }  OriginTrackedValue value = loadValue(buffer, reader, false);
/*  93 */         put(result, key, value);
/*     */       } 
/*     */       
/*  96 */       return result;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void put(Map<String, OriginTrackedValue> result, String key, OriginTrackedValue value) {
/* 101 */     if (!key.isEmpty()) {
/* 102 */       result.put(key, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private String loadKey(StringBuilder buffer, CharacterReader reader) throws IOException {
/* 107 */     buffer.setLength(0);
/* 108 */     boolean previousWhitespace = false;
/* 109 */     while (!reader.isEndOfLine()) {
/* 110 */       if (reader.isPropertyDelimiter()) {
/* 111 */         reader.read();
/* 112 */         return buffer.toString();
/*     */       } 
/* 114 */       if (!reader.isWhiteSpace() && previousWhitespace) {
/* 115 */         return buffer.toString();
/*     */       }
/* 117 */       previousWhitespace = reader.isWhiteSpace();
/* 118 */       buffer.append(reader.getCharacter());
/* 119 */       reader.read();
/*     */     } 
/* 121 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private OriginTrackedValue loadValue(StringBuilder buffer, CharacterReader reader, boolean splitLists) throws IOException {
/* 126 */     buffer.setLength(0);
/* 127 */     while (reader.isWhiteSpace() && !reader.isEndOfLine()) {
/* 128 */       reader.read();
/*     */     }
/* 130 */     TextResourceOrigin.Location location = reader.getLocation();
/* 131 */     while (!reader.isEndOfLine() && (!splitLists || !reader.isListDelimiter())) {
/* 132 */       buffer.append(reader.getCharacter());
/* 133 */       reader.read();
/*     */     } 
/* 135 */     TextResourceOrigin textResourceOrigin = new TextResourceOrigin(this.resource, location);
/* 136 */     return OriginTrackedValue.of(buffer.toString(), (Origin)textResourceOrigin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CharacterReader
/*     */     implements Closeable
/*     */   {
/* 145 */     private static final String[] ESCAPES = new String[] { "trnf", "\t\r\n\f" };
/*     */     
/*     */     private final LineNumberReader reader;
/*     */     
/* 149 */     private int columnNumber = -1;
/*     */     
/*     */     private boolean escaped;
/*     */     
/*     */     private int character;
/*     */     
/*     */     CharacterReader(Resource resource) throws IOException {
/* 156 */       this
/* 157 */         .reader = new LineNumberReader(new InputStreamReader(resource.getInputStream(), StandardCharsets.ISO_8859_1));
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 162 */       this.reader.close();
/*     */     }
/*     */     
/*     */     boolean read() throws IOException {
/* 166 */       return read(false);
/*     */     }
/*     */     
/*     */     boolean read(boolean wrappedLine) throws IOException {
/* 170 */       this.escaped = false;
/* 171 */       this.character = this.reader.read();
/* 172 */       this.columnNumber++;
/* 173 */       if (this.columnNumber == 0) {
/* 174 */         skipLeadingWhitespace();
/* 175 */         if (!wrappedLine) {
/* 176 */           skipComment();
/*     */         }
/*     */       } 
/* 179 */       if (this.character == 92) {
/* 180 */         this.escaped = true;
/* 181 */         readEscaped();
/*     */       }
/* 183 */       else if (this.character == 10) {
/* 184 */         this.columnNumber = -1;
/*     */       } 
/* 186 */       return !isEndOfFile();
/*     */     }
/*     */     
/*     */     private void skipLeadingWhitespace() throws IOException {
/* 190 */       while (isWhiteSpace()) {
/* 191 */         this.character = this.reader.read();
/* 192 */         this.columnNumber++;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void skipComment() throws IOException {
/* 197 */       if (this.character == 35 || this.character == 33) {
/* 198 */         while (this.character != 10 && this.character != -1) {
/* 199 */           this.character = this.reader.read();
/*     */         }
/* 201 */         this.columnNumber = -1;
/* 202 */         read();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void readEscaped() throws IOException {
/* 207 */       this.character = this.reader.read();
/* 208 */       int escapeIndex = ESCAPES[0].indexOf(this.character);
/* 209 */       if (escapeIndex != -1) {
/* 210 */         this.character = ESCAPES[1].charAt(escapeIndex);
/*     */       }
/* 212 */       else if (this.character == 10) {
/* 213 */         this.columnNumber = -1;
/* 214 */         read(true);
/*     */       }
/* 216 */       else if (this.character == 117) {
/* 217 */         readUnicode();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void readUnicode() throws IOException {
/* 222 */       this.character = 0;
/* 223 */       for (int i = 0; i < 4; i++) {
/* 224 */         int digit = this.reader.read();
/* 225 */         if (digit >= 48 && digit <= 57) {
/* 226 */           this.character = (this.character << 4) + digit - 48;
/*     */         }
/* 228 */         else if (digit >= 97 && digit <= 102) {
/* 229 */           this.character = (this.character << 4) + digit - 97 + 10;
/*     */         }
/* 231 */         else if (digit >= 65 && digit <= 70) {
/* 232 */           this.character = (this.character << 4) + digit - 65 + 10;
/*     */         } else {
/*     */           
/* 235 */           throw new IllegalStateException("Malformed \\uxxxx encoding.");
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean isWhiteSpace() {
/* 241 */       return (!this.escaped && (this.character == 32 || this.character == 9 || this.character == 12));
/*     */     }
/*     */     
/*     */     boolean isEndOfFile() {
/* 245 */       return (this.character == -1);
/*     */     }
/*     */     
/*     */     boolean isEndOfLine() {
/* 249 */       return (this.character == -1 || (!this.escaped && this.character == 10));
/*     */     }
/*     */     
/*     */     boolean isListDelimiter() {
/* 253 */       return (!this.escaped && this.character == 44);
/*     */     }
/*     */     
/*     */     boolean isPropertyDelimiter() {
/* 257 */       return (!this.escaped && (this.character == 61 || this.character == 58));
/*     */     }
/*     */     
/*     */     char getCharacter() {
/* 261 */       return (char)this.character;
/*     */     }
/*     */     
/*     */     TextResourceOrigin.Location getLocation() {
/* 265 */       return new TextResourceOrigin.Location(this.reader.getLineNumber(), this.columnNumber);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\env\OriginTrackedPropertiesLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
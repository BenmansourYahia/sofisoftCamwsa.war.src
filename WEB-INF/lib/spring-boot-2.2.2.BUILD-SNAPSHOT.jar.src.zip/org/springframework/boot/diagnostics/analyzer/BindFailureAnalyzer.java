/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.context.properties.bind.BindException;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BindFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<BindException>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, BindException cause) {
/*  46 */     Throwable rootCause = cause.getCause();
/*  47 */     if (rootCause instanceof org.springframework.boot.context.properties.bind.validation.BindValidationException || rootCause instanceof org.springframework.boot.context.properties.bind.UnboundConfigurationPropertiesException)
/*     */     {
/*  49 */       return null;
/*     */     }
/*  51 */     return analyzeGenericBindException(cause);
/*     */   }
/*     */   
/*     */   private FailureAnalysis analyzeGenericBindException(BindException cause) {
/*  55 */     StringBuilder description = new StringBuilder(String.format("%s:%n", new Object[] { cause.getMessage() }));
/*  56 */     ConfigurationProperty property = cause.getProperty();
/*  57 */     buildDescription(description, property);
/*  58 */     description.append(String.format("%n    Reason: %s", new Object[] { getMessage(cause) }));
/*  59 */     return getFailureAnalysis(description, cause);
/*     */   }
/*     */   
/*     */   private void buildDescription(StringBuilder description, ConfigurationProperty property) {
/*  63 */     if (property != null) {
/*  64 */       description.append(String.format("%n    Property: %s", new Object[] { property.getName() }));
/*  65 */       description.append(String.format("%n    Value: %s", new Object[] { property.getValue() }));
/*  66 */       description.append(String.format("%n    Origin: %s", new Object[] { property.getOrigin() }));
/*     */     } 
/*     */   }
/*     */   private String getMessage(BindException cause) {
/*     */     Throwable throwable;
/*  71 */     ConversionFailedException conversionFailure = (ConversionFailedException)findCause((Throwable)cause, ConversionFailedException.class);
/*  72 */     if (conversionFailure != null) {
/*  73 */       return "failed to convert " + conversionFailure.getSourceType() + " to " + conversionFailure
/*  74 */         .getTargetType();
/*     */     }
/*  76 */     BindException bindException = cause;
/*  77 */     while (bindException.getCause() != null) {
/*  78 */       throwable = bindException.getCause();
/*     */     }
/*  80 */     return StringUtils.hasText(throwable.getMessage()) ? throwable.getMessage() : cause.getMessage();
/*     */   }
/*     */   
/*     */   private FailureAnalysis getFailureAnalysis(Object description, BindException cause) {
/*  84 */     StringBuilder message = new StringBuilder("Update your application's configuration");
/*  85 */     Collection<String> validValues = findValidValues(cause);
/*  86 */     if (!validValues.isEmpty()) {
/*  87 */       message.append(String.format(". The following values are valid:%n", new Object[0]));
/*  88 */       validValues.forEach(value -> message.append(String.format("%n    %s", new Object[] { value })));
/*     */     } 
/*  90 */     return new FailureAnalysis(description.toString(), message.toString(), (Throwable)cause);
/*     */   }
/*     */   
/*     */   private Collection<String> findValidValues(BindException ex) {
/*  94 */     ConversionFailedException conversionFailure = (ConversionFailedException)findCause((Throwable)ex, ConversionFailedException.class);
/*  95 */     if (conversionFailure != null) {
/*  96 */       Object[] enumConstants = conversionFailure.getTargetType().getType().getEnumConstants();
/*  97 */       if (enumConstants != null) {
/*  98 */         return (Collection<String>)Stream.<Object>of(enumConstants).map(Object::toString).collect(Collectors.toCollection(java.util.TreeSet::new));
/*     */       }
/*     */     } 
/* 101 */     return Collections.emptySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\BindFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
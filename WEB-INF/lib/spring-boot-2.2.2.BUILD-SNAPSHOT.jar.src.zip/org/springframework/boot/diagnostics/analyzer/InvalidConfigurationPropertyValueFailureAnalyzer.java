/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*     */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InvalidConfigurationPropertyValueFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<InvalidConfigurationPropertyValueException>
/*     */   implements EnvironmentAware
/*     */ {
/*     */   private ConfigurableEnvironment environment;
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/*  49 */     this.environment = (ConfigurableEnvironment)environment;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, InvalidConfigurationPropertyValueException cause) {
/*  54 */     List<Descriptor> descriptors = getDescriptors(cause.getName());
/*  55 */     if (descriptors.isEmpty()) {
/*  56 */       return null;
/*     */     }
/*  58 */     StringBuilder description = new StringBuilder();
/*  59 */     appendDetails(description, cause, descriptors);
/*  60 */     appendReason(description, cause);
/*  61 */     appendAdditionalProperties(description, descriptors);
/*  62 */     return new FailureAnalysis(description.toString(), getAction(cause), (Throwable)cause);
/*     */   }
/*     */   
/*     */   private List<Descriptor> getDescriptors(String propertyName) {
/*  66 */     return (List<Descriptor>)getPropertySources().filter(source -> source.containsProperty(propertyName))
/*  67 */       .map(source -> Descriptor.get(source, propertyName)).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   private Stream<PropertySource<?>> getPropertySources() {
/*  71 */     if (this.environment == null) {
/*  72 */       return Stream.empty();
/*     */     }
/*  74 */     return this.environment.getPropertySources().stream()
/*  75 */       .filter(source -> !ConfigurationPropertySources.isAttachedConfigurationPropertySource(source));
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendDetails(StringBuilder message, InvalidConfigurationPropertyValueException cause, List<Descriptor> descriptors) {
/*  80 */     Descriptor mainDescriptor = descriptors.get(0);
/*  81 */     message.append("Invalid value '").append(mainDescriptor.getValue()).append("' for configuration property '");
/*  82 */     message.append(cause.getName()).append("'");
/*  83 */     mainDescriptor.appendOrigin(message);
/*  84 */     message.append(".");
/*     */   }
/*     */   
/*     */   private void appendReason(StringBuilder message, InvalidConfigurationPropertyValueException cause) {
/*  88 */     if (StringUtils.hasText(cause.getReason())) {
/*  89 */       message.append(String.format(" Validation failed for the following reason:%n%n", new Object[0]));
/*  90 */       message.append(cause.getReason());
/*     */     } else {
/*     */       
/*  93 */       message.append(" No reason was provided.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void appendAdditionalProperties(StringBuilder message, List<Descriptor> descriptors) {
/*  98 */     List<Descriptor> others = descriptors.subList(1, descriptors.size());
/*  99 */     if (!others.isEmpty()) {
/* 100 */       message.append(
/* 101 */           String.format("%n%nAdditionally, this property is also set in the following property %s:%n%n", new Object[] {
/* 102 */               (others.size() > 1) ? "sources" : "source" }));
/* 103 */       for (Descriptor other : others) {
/* 104 */         message.append("\t- In '").append(other.getPropertySource()).append("'");
/* 105 */         message.append(" with the value '").append(other.getValue()).append("'");
/* 106 */         other.appendOrigin(message);
/* 107 */         message.append(String.format(".%n", new Object[0]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getAction(InvalidConfigurationPropertyValueException cause) {
/* 113 */     StringBuilder action = new StringBuilder();
/* 114 */     action.append("Review the value of the property");
/* 115 */     if (cause.getReason() != null) {
/* 116 */       action.append(" with the provided reason");
/*     */     }
/* 118 */     action.append(".");
/* 119 */     return action.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Descriptor
/*     */   {
/*     */     private final String propertySource;
/*     */     
/*     */     private final Object value;
/*     */     private final Origin origin;
/*     */     
/*     */     private Descriptor(String propertySource, Object value, Origin origin) {
/* 131 */       this.propertySource = propertySource;
/* 132 */       this.value = value;
/* 133 */       this.origin = origin;
/*     */     }
/*     */     
/*     */     String getPropertySource() {
/* 137 */       return this.propertySource;
/*     */     }
/*     */     
/*     */     Object getValue() {
/* 141 */       return this.value;
/*     */     }
/*     */     
/*     */     void appendOrigin(StringBuilder message) {
/* 145 */       if (this.origin != null) {
/* 146 */         message.append(" (originating from '").append(this.origin).append("')");
/*     */       }
/*     */     }
/*     */     
/*     */     static Descriptor get(PropertySource<?> source, String propertyName) {
/* 151 */       Object value = source.getProperty(propertyName);
/* 152 */       Origin origin = OriginLookup.getOrigin(source, propertyName);
/* 153 */       return new Descriptor(source.getName(), value, origin);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\InvalidConfigurationPropertyValueFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
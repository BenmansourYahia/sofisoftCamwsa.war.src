/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import javax.validation.ValidationException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ValidationExceptionFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<ValidationException>
/*    */ {
/*    */   private static final String MISSING_IMPLEMENTATION_MESSAGE = "Unable to create a Configuration, because no Bean Validation provider could be found";
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, ValidationException cause) {
/* 38 */     if (cause.getMessage().startsWith("Unable to create a Configuration, because no Bean Validation provider could be found")) {
/* 39 */       return new FailureAnalysis("The Bean Validation API is on the classpath but no implementation could be found", "Add an implementation, such as Hibernate Validator, to the classpath", (Throwable)cause);
/*    */     }
/*    */ 
/*    */     
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\ValidationExceptionFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NoSuchMethodFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<NoSuchMethodError>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchMethodError cause) {
/*  40 */     NoSuchMethodDescriptor descriptor = getNoSuchMethodDescriptor(cause.getMessage());
/*  41 */     if (descriptor == null) {
/*  42 */       return null;
/*     */     }
/*  44 */     String description = getDescription(cause, descriptor);
/*  45 */     return new FailureAnalysis(description, "Correct the classpath of your application so that it contains a single, compatible version of " + descriptor
/*     */         
/*  47 */         .getClassName(), cause);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NoSuchMethodDescriptor getNoSuchMethodDescriptor(String cause) {
/*  52 */     String message = cleanMessage(cause);
/*  53 */     String className = extractClassName(message);
/*  54 */     if (className == null) {
/*  55 */       return null;
/*     */     }
/*  57 */     List<URL> candidates = findCandidates(className);
/*  58 */     if (candidates == null) {
/*  59 */       return null;
/*     */     }
/*  61 */     URL actual = getActual(className);
/*  62 */     if (actual == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     return new NoSuchMethodDescriptor(message, className, candidates, actual);
/*     */   }
/*     */   
/*     */   private String cleanMessage(String message) {
/*  69 */     int loadedFromIndex = message.indexOf(" (loaded from");
/*  70 */     if (loadedFromIndex == -1) {
/*  71 */       return message;
/*     */     }
/*  73 */     return message.substring(0, loadedFromIndex);
/*     */   }
/*     */   
/*     */   private String extractClassName(String message) {
/*  77 */     if (message.startsWith("'") && message.endsWith("'")) {
/*  78 */       int splitIndex = message.indexOf(' ');
/*  79 */       if (splitIndex == -1) {
/*  80 */         return null;
/*     */       }
/*  82 */       message = message.substring(splitIndex + 1);
/*     */     } 
/*  84 */     int descriptorIndex = message.indexOf('(');
/*  85 */     if (descriptorIndex == -1) {
/*  86 */       return null;
/*     */     }
/*  88 */     String classAndMethodName = message.substring(0, descriptorIndex);
/*  89 */     int methodNameIndex = classAndMethodName.lastIndexOf('.');
/*  90 */     if (methodNameIndex == -1) {
/*  91 */       return null;
/*     */     }
/*  93 */     String className = classAndMethodName.substring(0, methodNameIndex);
/*  94 */     return className.replace('/', '.');
/*     */   }
/*     */   
/*     */   private List<URL> findCandidates(String className) {
/*     */     try {
/*  99 */       return Collections.list(NoSuchMethodFailureAnalyzer.class.getClassLoader()
/* 100 */           .getResources(ClassUtils.convertClassNameToResourcePath(className) + ".class"));
/*     */     }
/* 102 */     catch (Throwable ex) {
/* 103 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private URL getActual(String className) {
/*     */     try {
/* 109 */       return getClass().getClassLoader().loadClass(className).getProtectionDomain().getCodeSource().getLocation();
/*     */     }
/* 111 */     catch (Throwable ex) {
/* 112 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getDescription(NoSuchMethodError cause, NoSuchMethodDescriptor descriptor) {
/* 117 */     StringWriter description = new StringWriter();
/* 118 */     PrintWriter writer = new PrintWriter(description);
/* 119 */     writer.println("An attempt was made to call a method that does not exist. The attempt was made from the following location:");
/*     */     
/* 121 */     writer.println();
/* 122 */     writer.print("    ");
/* 123 */     writer.println(cause.getStackTrace()[0]);
/* 124 */     writer.println();
/* 125 */     writer.println("The following method did not exist:");
/* 126 */     writer.println();
/* 127 */     writer.print("    ");
/* 128 */     writer.println(descriptor.getErrorMessage());
/* 129 */     writer.println();
/* 130 */     writer.println("The method's class, " + descriptor
/* 131 */         .getClassName() + ", is available from the following locations:");
/* 132 */     writer.println();
/* 133 */     for (URL candidate : descriptor.getCandidateLocations()) {
/* 134 */       writer.print("    ");
/* 135 */       writer.println(candidate);
/*     */     } 
/* 137 */     writer.println();
/* 138 */     writer.println("It was loaded from the following location:");
/* 139 */     writer.println();
/* 140 */     writer.print("    ");
/* 141 */     writer.println(descriptor.getActualLocation());
/* 142 */     return description.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class NoSuchMethodDescriptor
/*     */   {
/*     */     private final String errorMessage;
/*     */     
/*     */     private final String className;
/*     */     
/*     */     private final List<URL> candidateLocations;
/*     */     
/*     */     private final URL actualLocation;
/*     */     
/*     */     public NoSuchMethodDescriptor(String errorMessage, String className, List<URL> candidateLocations, URL actualLocation) {
/* 157 */       this.errorMessage = errorMessage;
/* 158 */       this.className = className;
/* 159 */       this.candidateLocations = candidateLocations;
/* 160 */       this.actualLocation = actualLocation;
/*     */     }
/*     */     
/*     */     public String getErrorMessage() {
/* 164 */       return this.errorMessage;
/*     */     }
/*     */     
/*     */     public String getClassName() {
/* 168 */       return this.className;
/*     */     }
/*     */     
/*     */     public List<URL> getCandidateLocations() {
/* 172 */       return this.candidateLocations;
/*     */     }
/*     */     
/*     */     public URL getActualLocation() {
/* 176 */       return this.actualLocation;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\NoSuchMethodFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
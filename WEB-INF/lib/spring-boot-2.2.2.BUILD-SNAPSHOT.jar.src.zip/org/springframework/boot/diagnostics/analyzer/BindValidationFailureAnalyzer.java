/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.bind.BindException;
/*     */ import org.springframework.boot.context.properties.bind.validation.BindValidationException;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.FieldError;
/*     */ import org.springframework.validation.ObjectError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BindValidationFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<Throwable>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, Throwable cause) {
/*  40 */     ExceptionDetails details = getBindValidationExceptionDetails(rootFailure);
/*  41 */     if (details == null) {
/*  42 */       return null;
/*     */     }
/*  44 */     return analyzeBindValidationException(details);
/*     */   }
/*     */   
/*     */   private ExceptionDetails getBindValidationExceptionDetails(Throwable rootFailure) {
/*  48 */     BindValidationException validationException = (BindValidationException)findCause(rootFailure, BindValidationException.class);
/*  49 */     if (validationException != null) {
/*  50 */       BindException target = (BindException)findCause(rootFailure, BindException.class);
/*  51 */       List<ObjectError> errors = validationException.getValidationErrors().getAllErrors();
/*  52 */       return new ExceptionDetails(errors, target, (Throwable)validationException);
/*     */     } 
/*  54 */     BindException bindException = (BindException)findCause(rootFailure, BindException.class);
/*     */     
/*  56 */     if (bindException != null) {
/*  57 */       List<ObjectError> errors = bindException.getAllErrors();
/*  58 */       return new ExceptionDetails(errors, bindException.getTarget(), (Throwable)bindException);
/*     */     } 
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private FailureAnalysis analyzeBindValidationException(ExceptionDetails details) {
/*  65 */     StringBuilder description = new StringBuilder(String.format("Binding to target %s failed:%n", new Object[] { details.getTarget() }));
/*  66 */     for (ObjectError error : details.getErrors()) {
/*  67 */       if (error instanceof FieldError) {
/*  68 */         appendFieldError(description, (FieldError)error);
/*     */       }
/*  70 */       description.append(String.format("%n    Reason: %s%n", new Object[] { error.getDefaultMessage() }));
/*     */     } 
/*  72 */     return getFailureAnalysis(description, details.getCause());
/*     */   }
/*     */   
/*     */   private void appendFieldError(StringBuilder description, FieldError error) {
/*  76 */     Origin origin = Origin.from(error);
/*  77 */     description.append(String.format("%n    Property: %s", new Object[] { error.getObjectName() + "." + error.getField() }));
/*  78 */     description.append(String.format("%n    Value: %s", new Object[] { error.getRejectedValue() }));
/*  79 */     if (origin != null) {
/*  80 */       description.append(String.format("%n    Origin: %s", new Object[] { origin }));
/*     */     }
/*     */   }
/*     */   
/*     */   private FailureAnalysis getFailureAnalysis(Object description, Throwable cause) {
/*  85 */     return new FailureAnalysis(description.toString(), "Update your application's configuration", cause);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ExceptionDetails
/*     */   {
/*     */     private List<ObjectError> errors;
/*     */     
/*     */     private Object target;
/*     */     private Throwable cause;
/*     */     
/*     */     ExceptionDetails(List<ObjectError> errors, Object target, Throwable cause) {
/*  97 */       this.errors = errors;
/*  98 */       this.target = target;
/*  99 */       this.cause = cause;
/*     */     }
/*     */     
/*     */     Object getTarget() {
/* 103 */       return this.target;
/*     */     }
/*     */     
/*     */     List<ObjectError> getErrors() {
/* 107 */       return this.errors;
/*     */     }
/*     */     
/*     */     Throwable getCause() {
/* 111 */       return this.cause;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\BindValidationFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
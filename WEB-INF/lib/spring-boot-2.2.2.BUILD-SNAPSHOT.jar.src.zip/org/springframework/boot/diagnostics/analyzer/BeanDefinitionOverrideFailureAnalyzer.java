/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionOverrideException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BeanDefinitionOverrideFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<BeanDefinitionOverrideException>
/*    */ {
/*    */   private static final String ACTION = "Consider renaming one of the beans or enabling overriding by setting spring.main.allow-bean-definition-overriding=true";
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, BeanDefinitionOverrideException cause) {
/* 39 */     return new FailureAnalysis(getDescription(cause), "Consider renaming one of the beans or enabling overriding by setting spring.main.allow-bean-definition-overriding=true", (Throwable)cause);
/*    */   }
/*    */   
/*    */   private String getDescription(BeanDefinitionOverrideException ex) {
/* 43 */     StringWriter description = new StringWriter();
/* 44 */     PrintWriter printer = new PrintWriter(description);
/* 45 */     printer.printf("The bean '%s'", new Object[] { ex.getBeanName() });
/* 46 */     if (ex.getBeanDefinition().getResourceDescription() != null) {
/* 47 */       printer.printf(", defined in %s,", new Object[] { ex.getBeanDefinition().getResourceDescription() });
/*    */     }
/* 49 */     printer.printf(" could not be registered. A bean with that name has already been defined ", new Object[0]);
/* 50 */     if (ex.getExistingDefinition().getResourceDescription() != null) {
/* 51 */       printer.printf("in %s ", new Object[] { ex.getExistingDefinition().getResourceDescription() });
/*    */     }
/* 53 */     printer.printf("and overriding is disabled.", new Object[0]);
/* 54 */     return description.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\BeanDefinitionOverrideFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.boot.web.embedded.tomcat.ConnectorStartFailedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConnectorStartFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<ConnectorStartFailedException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, ConnectorStartFailedException cause) {
/* 32 */     return new FailureAnalysis("The Tomcat connector configured to listen on port " + cause
/* 33 */         .getPort() + " failed to start. The port may already be in use or the connector may be misconfigured.", "Verify the connector's configuration, identify and stop any process that's listening on port " + cause
/*    */ 
/*    */         
/* 36 */         .getPort() + ", or configure this application to listen on another port.", (Throwable)cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\ConnectorStartFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
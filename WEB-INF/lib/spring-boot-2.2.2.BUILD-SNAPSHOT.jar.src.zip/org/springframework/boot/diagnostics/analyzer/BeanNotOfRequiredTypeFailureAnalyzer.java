/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.lang.reflect.Proxy;
/*    */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanNotOfRequiredTypeFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<BeanNotOfRequiredTypeException>
/*    */ {
/*    */   private static final String ACTION = "Consider injecting the bean as one of its interfaces or forcing the use of CGLib-based proxies by setting proxyTargetClass=true on @EnableAsync and/or @EnableCaching.";
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, BeanNotOfRequiredTypeException cause) {
/* 42 */     if (!Proxy.isProxyClass(cause.getActualType())) {
/* 43 */       return null;
/*    */     }
/* 45 */     return new FailureAnalysis(getDescription(cause), "Consider injecting the bean as one of its interfaces or forcing the use of CGLib-based proxies by setting proxyTargetClass=true on @EnableAsync and/or @EnableCaching.", (Throwable)cause);
/*    */   }
/*    */   
/*    */   private String getDescription(BeanNotOfRequiredTypeException ex) {
/* 49 */     StringWriter description = new StringWriter();
/* 50 */     PrintWriter printer = new PrintWriter(description);
/* 51 */     printer.printf("The bean '%s' could not be injected as a '%s' because it is a JDK dynamic proxy that implements:%n", new Object[] { ex
/* 52 */           .getBeanName(), ex.getRequiredType().getName() });
/* 53 */     for (Class<?> requiredTypeInterface : ex.getRequiredType().getInterfaces()) {
/* 54 */       printer.println("\t" + requiredTypeInterface.getName());
/*    */     }
/* 56 */     return description.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\BeanNotOfRequiredTypeFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
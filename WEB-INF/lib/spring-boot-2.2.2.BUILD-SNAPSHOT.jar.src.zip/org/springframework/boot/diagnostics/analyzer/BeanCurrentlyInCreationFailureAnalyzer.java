/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanCurrentlyInCreationFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<BeanCurrentlyInCreationException>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, BeanCurrentlyInCreationException cause) {
/*  40 */     DependencyCycle dependencyCycle = findCycle(rootFailure);
/*  41 */     if (dependencyCycle == null) {
/*  42 */       return null;
/*     */     }
/*  44 */     return new FailureAnalysis(buildMessage(dependencyCycle), null, (Throwable)cause);
/*     */   }
/*     */   
/*     */   private DependencyCycle findCycle(Throwable rootFailure) {
/*  48 */     List<BeanInCycle> beansInCycle = new ArrayList<>();
/*  49 */     Throwable candidate = rootFailure;
/*  50 */     int cycleStart = -1;
/*  51 */     while (candidate != null) {
/*  52 */       BeanInCycle beanInCycle = BeanInCycle.get(candidate);
/*  53 */       if (beanInCycle != null) {
/*  54 */         int index = beansInCycle.indexOf(beanInCycle);
/*  55 */         if (index == -1) {
/*  56 */           beansInCycle.add(beanInCycle);
/*     */         }
/*  58 */         cycleStart = (cycleStart != -1) ? cycleStart : index;
/*     */       } 
/*  60 */       candidate = candidate.getCause();
/*     */     } 
/*  62 */     if (cycleStart == -1) {
/*  63 */       return null;
/*     */     }
/*  65 */     return new DependencyCycle(beansInCycle, cycleStart);
/*     */   }
/*     */   
/*     */   private String buildMessage(DependencyCycle dependencyCycle) {
/*  69 */     StringBuilder message = new StringBuilder();
/*  70 */     message.append(
/*  71 */         String.format("The dependencies of some of the beans in the application context form a cycle:%n%n", new Object[0]));
/*  72 */     List<BeanInCycle> beansInCycle = dependencyCycle.getBeansInCycle();
/*  73 */     int cycleStart = dependencyCycle.getCycleStart();
/*  74 */     for (int i = 0; i < beansInCycle.size(); i++) {
/*  75 */       BeanInCycle beanInCycle = beansInCycle.get(i);
/*  76 */       if (i == cycleStart) {
/*  77 */         message.append(String.format("┌─────┐%n", new Object[0]));
/*     */       }
/*  79 */       else if (i > 0) {
/*  80 */         String str = (i < cycleStart) ? " " : "↑";
/*  81 */         message.append(String.format("%s     ↓%n", new Object[] { str }));
/*     */       } 
/*  83 */       String leftSide = (i < cycleStart) ? " " : "|";
/*  84 */       message.append(String.format("%s  %s%n", new Object[] { leftSide, beanInCycle }));
/*     */     } 
/*  86 */     message.append(String.format("└─────┘%n", new Object[0]));
/*  87 */     return message.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class DependencyCycle
/*     */   {
/*     */     private final List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> beansInCycle;
/*     */     private final int cycleStart;
/*     */     
/*     */     private DependencyCycle(List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> beansInCycle, int cycleStart) {
/*  97 */       this.beansInCycle = beansInCycle;
/*  98 */       this.cycleStart = cycleStart;
/*     */     }
/*     */     
/*     */     List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> getBeansInCycle() {
/* 102 */       return this.beansInCycle;
/*     */     }
/*     */     
/*     */     int getCycleStart() {
/* 106 */       return this.cycleStart;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class BeanInCycle
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final String description;
/*     */     
/*     */     private BeanInCycle(BeanCreationException ex) {
/* 118 */       this.name = ex.getBeanName();
/* 119 */       this.description = determineDescription(ex);
/*     */     }
/*     */     
/*     */     private String determineDescription(BeanCreationException ex) {
/* 123 */       if (StringUtils.hasText(ex.getResourceDescription())) {
/* 124 */         return String.format(" defined in %s", new Object[] { ex.getResourceDescription() });
/*     */       }
/* 126 */       InjectionPoint failedInjectionPoint = findFailedInjectionPoint(ex);
/* 127 */       if (failedInjectionPoint != null && failedInjectionPoint.getField() != null) {
/* 128 */         return String.format(" (field %s)", new Object[] { failedInjectionPoint.getField() });
/*     */       }
/* 130 */       return "";
/*     */     }
/*     */     
/*     */     private InjectionPoint findFailedInjectionPoint(BeanCreationException ex) {
/* 134 */       if (!(ex instanceof UnsatisfiedDependencyException)) {
/* 135 */         return null;
/*     */       }
/* 137 */       return ((UnsatisfiedDependencyException)ex).getInjectionPoint();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 142 */       if (this == obj) {
/* 143 */         return true;
/*     */       }
/* 145 */       if (obj == null || getClass() != obj.getClass()) {
/* 146 */         return false;
/*     */       }
/* 148 */       return this.name.equals(((BeanInCycle)obj).name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 153 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 158 */       return this.name + this.description;
/*     */     }
/*     */     
/*     */     static BeanInCycle get(Throwable ex) {
/* 162 */       if (ex instanceof BeanCreationException) {
/* 163 */         return get((BeanCreationException)ex);
/*     */       }
/* 165 */       return null;
/*     */     }
/*     */     
/*     */     private static BeanInCycle get(BeanCreationException ex) {
/* 169 */       if (StringUtils.hasText(ex.getBeanName())) {
/* 170 */         return new BeanInCycle(ex);
/*     */       }
/* 172 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\BeanCurrentlyInCreationFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
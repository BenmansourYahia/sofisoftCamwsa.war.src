/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.beans.factory.BeanCreationException;
/*    */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyNameException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InvalidConfigurationPropertyNameFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<InvalidConfigurationPropertyNameException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, InvalidConfigurationPropertyNameException cause) {
/* 37 */     BeanCreationException exception = (BeanCreationException)findCause(rootFailure, BeanCreationException.class);
/* 38 */     String action = String.format("Modify '%s' so that it conforms to the canonical names requirements.", new Object[] { cause
/* 39 */           .getName() });
/* 40 */     return new FailureAnalysis(buildDescription(cause, exception), action, (Throwable)cause);
/*    */   }
/*    */ 
/*    */   
/*    */   private String buildDescription(InvalidConfigurationPropertyNameException cause, BeanCreationException exception) {
/* 45 */     StringBuilder description = new StringBuilder(String.format("Configuration property name '%s' is not valid:%n", new Object[] { cause.getName() }));
/* 46 */     String invalid = cause.getInvalidCharacters().stream().map(this::quote).collect(Collectors.joining(", "));
/* 47 */     description.append(String.format("%n    Invalid characters: %s", new Object[] { invalid }));
/* 48 */     if (exception != null) {
/* 49 */       description.append(String.format("%n    Bean: %s", new Object[] { exception.getBeanName() }));
/*    */     }
/* 51 */     description.append(String.format("%n    Reason: Canonical names should be kebab-case ('-' separated), lowercase alpha-numeric characters and must start with a letter", new Object[0]));
/*    */     
/* 53 */     return description.toString();
/*    */   }
/*    */   
/*    */   private String quote(Character c) {
/* 57 */     return "'" + c + "'";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\analyzer\InvalidConfigurationPropertyNameFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.diagnostics;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.boot.SpringBootExceptionReporter;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FailureAnalyzers
/*     */   implements SpringBootExceptionReporter
/*     */ {
/*  53 */   private static final Log logger = LogFactory.getLog(FailureAnalyzers.class);
/*     */   
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   private final List<FailureAnalyzer> analyzers;
/*     */   
/*     */   FailureAnalyzers(ConfigurableApplicationContext context) {
/*  60 */     this(context, null);
/*     */   }
/*     */   
/*     */   FailureAnalyzers(ConfigurableApplicationContext context, ClassLoader classLoader) {
/*  64 */     Assert.notNull(context, "Context must not be null");
/*  65 */     this.classLoader = (classLoader != null) ? classLoader : context.getClassLoader();
/*  66 */     this.analyzers = loadFailureAnalyzers(this.classLoader);
/*  67 */     prepareFailureAnalyzers(this.analyzers, context);
/*     */   }
/*     */   
/*     */   private List<FailureAnalyzer> loadFailureAnalyzers(ClassLoader classLoader) {
/*  71 */     List<String> analyzerNames = SpringFactoriesLoader.loadFactoryNames(FailureAnalyzer.class, classLoader);
/*  72 */     List<FailureAnalyzer> analyzers = new ArrayList<>();
/*  73 */     for (String analyzerName : analyzerNames) {
/*     */       try {
/*  75 */         Constructor<?> constructor = ClassUtils.forName(analyzerName, classLoader).getDeclaredConstructor(new Class[0]);
/*  76 */         ReflectionUtils.makeAccessible(constructor);
/*  77 */         analyzers.add((FailureAnalyzer)constructor.newInstance(new Object[0]));
/*     */       }
/*  79 */       catch (Throwable ex) {
/*  80 */         logger.trace(LogMessage.format("Failed to load %s", analyzerName), ex);
/*     */       } 
/*     */     } 
/*  83 */     AnnotationAwareOrderComparator.sort(analyzers);
/*  84 */     return analyzers;
/*     */   }
/*     */   
/*     */   private void prepareFailureAnalyzers(List<FailureAnalyzer> analyzers, ConfigurableApplicationContext context) {
/*  88 */     for (FailureAnalyzer analyzer : analyzers) {
/*  89 */       prepareAnalyzer(context, analyzer);
/*     */     }
/*     */   }
/*     */   
/*     */   private void prepareAnalyzer(ConfigurableApplicationContext context, FailureAnalyzer analyzer) {
/*  94 */     if (analyzer instanceof BeanFactoryAware) {
/*  95 */       ((BeanFactoryAware)analyzer).setBeanFactory((BeanFactory)context.getBeanFactory());
/*     */     }
/*  97 */     if (analyzer instanceof EnvironmentAware) {
/*  98 */       ((EnvironmentAware)analyzer).setEnvironment((Environment)context.getEnvironment());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reportException(Throwable failure) {
/* 104 */     FailureAnalysis analysis = analyze(failure, this.analyzers);
/* 105 */     return report(analysis, this.classLoader);
/*     */   }
/*     */   
/*     */   private FailureAnalysis analyze(Throwable failure, List<FailureAnalyzer> analyzers) {
/* 109 */     for (FailureAnalyzer analyzer : analyzers) {
/*     */       try {
/* 111 */         FailureAnalysis analysis = analyzer.analyze(failure);
/* 112 */         if (analysis != null) {
/* 113 */           return analysis;
/*     */         }
/*     */       }
/* 116 */       catch (Throwable ex) {
/* 117 */         logger.debug(LogMessage.format("FailureAnalyzer %s failed", analyzer), ex);
/*     */       } 
/*     */     } 
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   private boolean report(FailureAnalysis analysis, ClassLoader classLoader) {
/* 124 */     List<FailureAnalysisReporter> reporters = SpringFactoriesLoader.loadFactories(FailureAnalysisReporter.class, classLoader);
/*     */     
/* 126 */     if (analysis == null || reporters.isEmpty()) {
/* 127 */       return false;
/*     */     }
/* 129 */     for (FailureAnalysisReporter reporter : reporters) {
/* 130 */       reporter.report(analysis);
/*     */     }
/* 132 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\FailureAnalyzers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
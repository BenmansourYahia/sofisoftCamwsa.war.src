/*    */ package org.springframework.boot.diagnostics;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoggingFailureAnalysisReporter
/*    */   implements FailureAnalysisReporter
/*    */ {
/* 32 */   private static final Log logger = LogFactory.getLog(LoggingFailureAnalysisReporter.class);
/*    */ 
/*    */   
/*    */   public void report(FailureAnalysis failureAnalysis) {
/* 36 */     if (logger.isDebugEnabled()) {
/* 37 */       logger.debug("Application failed to start due to an exception", failureAnalysis.getCause());
/*    */     }
/* 39 */     if (logger.isErrorEnabled()) {
/* 40 */       logger.error(buildMessage(failureAnalysis));
/*    */     }
/*    */   }
/*    */   
/*    */   private String buildMessage(FailureAnalysis failureAnalysis) {
/* 45 */     StringBuilder builder = new StringBuilder();
/* 46 */     builder.append(String.format("%n%n", new Object[0]));
/* 47 */     builder.append(String.format("***************************%n", new Object[0]));
/* 48 */     builder.append(String.format("APPLICATION FAILED TO START%n", new Object[0]));
/* 49 */     builder.append(String.format("***************************%n%n", new Object[0]));
/* 50 */     builder.append(String.format("Description:%n%n", new Object[0]));
/* 51 */     builder.append(String.format("%s%n", new Object[] { failureAnalysis.getDescription() }));
/* 52 */     if (StringUtils.hasText(failureAnalysis.getAction())) {
/* 53 */       builder.append(String.format("%nAction:%n%n", new Object[0]));
/* 54 */       builder.append(String.format("%s%n", new Object[] { failureAnalysis.getAction() }));
/*    */     } 
/* 56 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\diagnostics\LoggingFailureAnalysisReporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.security.servlet;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ApplicationContextRequestMatcher<C>
/*    */   implements RequestMatcher
/*    */ {
/*    */   private final Class<? extends C> contextClass;
/*    */   private volatile boolean initialized;
/* 48 */   private final Object initializeLock = new Object();
/*    */   
/*    */   public ApplicationContextRequestMatcher(Class<? extends C> contextClass) {
/* 51 */     Assert.notNull(contextClass, "Context class must not be null");
/* 52 */     this.contextClass = contextClass;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean matches(HttpServletRequest request) {
/* 58 */     WebApplicationContext webApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
/* 59 */     if (ignoreApplicationContext(webApplicationContext)) {
/* 60 */       return false;
/*    */     }
/* 62 */     Supplier<C> context = () -> getContext(webApplicationContext);
/* 63 */     if (!this.initialized) {
/* 64 */       synchronized (this.initializeLock) {
/* 65 */         if (!this.initialized) {
/* 66 */           initialized(context);
/* 67 */           this.initialized = true;
/*    */         } 
/*    */       } 
/*    */     }
/* 71 */     return matches(request, context);
/*    */   }
/*    */ 
/*    */   
/*    */   private C getContext(WebApplicationContext webApplicationContext) {
/* 76 */     if (this.contextClass.isInstance(webApplicationContext)) {
/* 77 */       return (C)webApplicationContext;
/*    */     }
/* 79 */     return (C)webApplicationContext.getBean(this.contextClass);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean ignoreApplicationContext(WebApplicationContext webApplicationContext) {
/* 91 */     return false;
/*    */   }
/*    */   
/*    */   protected void initialized(Supplier<C> context) {}
/*    */   
/*    */   protected abstract boolean matches(HttpServletRequest paramHttpServletRequest, Supplier<C> paramSupplier);
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\security\servlet\ApplicationContextRequestMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.security.reactive;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ApplicationContextServerWebExchangeMatcher<C>
/*    */   implements ServerWebExchangeMatcher
/*    */ {
/*    */   private final Class<? extends C> contextClass;
/*    */   private volatile Supplier<C> context;
/* 47 */   private final Object contextLock = new Object();
/*    */   
/*    */   public ApplicationContextServerWebExchangeMatcher(Class<? extends C> contextClass) {
/* 50 */     Assert.notNull(contextClass, "Context class must not be null");
/* 51 */     this.contextClass = contextClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 56 */     return matches(exchange, getContext(exchange));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Supplier<C> getContext(ServerWebExchange exchange) {
/* 68 */     if (this.context == null) {
/* 69 */       synchronized (this.contextLock) {
/* 70 */         if (this.context == null) {
/* 71 */           Supplier<C> createdContext = createContext(exchange);
/* 72 */           initialized(createdContext);
/* 73 */           this.context = createdContext;
/*    */         } 
/*    */       } 
/*    */     }
/* 77 */     return this.context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void initialized(Supplier<C> context) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Supplier<C> createContext(ServerWebExchange exchange) {
/* 89 */     ApplicationContext context = exchange.getApplicationContext();
/* 90 */     Assert.state((context != null), "No ApplicationContext found on ServerWebExchange.");
/* 91 */     if (this.contextClass.isInstance(context)) {
/* 92 */       return () -> context;
/*    */     }
/* 94 */     return () -> context.getBean(this.contextClass);
/*    */   }
/*    */   
/*    */   protected abstract Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange paramServerWebExchange, Supplier<C> paramSupplier);
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\security\reactive\ApplicationContextServerWebExchangeMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.admin;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.boot.context.event.ApplicationReadyEvent;
/*     */ import org.springframework.boot.web.context.WebServerInitializedEvent;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.event.GenericApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringApplicationAdminMXBeanRegistrar
/*     */   implements ApplicationContextAware, GenericApplicationListener, EnvironmentAware, InitializingBean, DisposableBean
/*     */ {
/*  56 */   private static final Log logger = LogFactory.getLog(SpringApplicationAdmin.class);
/*     */   
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */   
/*  60 */   private Environment environment = (Environment)new StandardEnvironment();
/*     */   
/*     */   private final ObjectName objectName;
/*     */   
/*     */   private boolean ready = false;
/*     */   
/*     */   private boolean embeddedWebApplication = false;
/*     */   
/*     */   public SpringApplicationAdminMXBeanRegistrar(String name) throws MalformedObjectNameException {
/*  69 */     this.objectName = new ObjectName(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/*  74 */     Assert.state(applicationContext instanceof ConfigurableApplicationContext, "ApplicationContext does not implement ConfigurableApplicationContext");
/*     */     
/*  76 */     this.applicationContext = (ConfigurableApplicationContext)applicationContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/*  81 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(ResolvableType eventType) {
/*  86 */     Class<?> type = eventType.getRawClass();
/*  87 */     if (type == null) {
/*  88 */       return false;
/*     */     }
/*  90 */     return (ApplicationReadyEvent.class.isAssignableFrom(type) || WebServerInitializedEvent.class
/*  91 */       .isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsSourceType(Class<?> sourceType) {
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/* 101 */     if (event instanceof ApplicationReadyEvent) {
/* 102 */       onApplicationReadyEvent((ApplicationReadyEvent)event);
/*     */     }
/* 104 */     if (event instanceof WebServerInitializedEvent) {
/* 105 */       onWebServerInitializedEvent((WebServerInitializedEvent)event);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 111 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   void onApplicationReadyEvent(ApplicationReadyEvent event) {
/* 115 */     if (this.applicationContext.equals(event.getApplicationContext())) {
/* 116 */       this.ready = true;
/*     */     }
/*     */   }
/*     */   
/*     */   void onWebServerInitializedEvent(WebServerInitializedEvent event) {
/* 121 */     if (this.applicationContext.equals(event.getApplicationContext())) {
/* 122 */       this.embeddedWebApplication = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 128 */     MBeanServer server = ManagementFactory.getPlatformMBeanServer();
/* 129 */     server.registerMBean(new SpringApplicationAdmin(), this.objectName);
/* 130 */     if (logger.isDebugEnabled()) {
/* 131 */       logger.debug("Application Admin MBean registered with name '" + this.objectName + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/* 137 */     ManagementFactory.getPlatformMBeanServer().unregisterMBean(this.objectName);
/*     */   }
/*     */   
/*     */   private class SpringApplicationAdmin implements SpringApplicationAdminMXBean {
/*     */     private SpringApplicationAdmin() {}
/*     */     
/*     */     public boolean isReady() {
/* 144 */       return SpringApplicationAdminMXBeanRegistrar.this.ready;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmbeddedWebApplication() {
/* 149 */       return SpringApplicationAdminMXBeanRegistrar.this.embeddedWebApplication;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getProperty(String key) {
/* 154 */       return SpringApplicationAdminMXBeanRegistrar.this.environment.getProperty(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void shutdown() {
/* 159 */       SpringApplicationAdminMXBeanRegistrar.logger.info("Application shutdown requested.");
/* 160 */       SpringApplicationAdminMXBeanRegistrar.this.applicationContext.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\admin\SpringApplicationAdminMXBeanRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package org.springframework.boot.admin;

public interface SpringApplicationAdminMXBean {
  boolean isReady();
  
  boolean isEmbeddedWebApplication();
  
  String getProperty(String paramString);
  
  void shutdown();
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\admin\SpringApplicationAdminMXBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import freemarker.template.Configuration;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.template.TemplateLocation;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.core.io.support.ResourcePatternResolver;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Configuration.class, FreeMarkerConfigurationFactory.class})
/*    */ @EnableConfigurationProperties({FreeMarkerProperties.class})
/*    */ @Import({FreeMarkerServletWebConfiguration.class, FreeMarkerReactiveWebConfiguration.class, FreeMarkerNonWebConfiguration.class})
/*    */ public class FreeMarkerAutoConfiguration
/*    */ {
/* 51 */   private static final Log logger = LogFactory.getLog(FreeMarkerAutoConfiguration.class);
/*    */   
/*    */   private final ApplicationContext applicationContext;
/*    */   
/*    */   private final FreeMarkerProperties properties;
/*    */   
/*    */   public FreeMarkerAutoConfiguration(ApplicationContext applicationContext, FreeMarkerProperties properties) {
/* 58 */     this.applicationContext = applicationContext;
/* 59 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @PostConstruct
/*    */   public void checkTemplateLocationExists() {
/* 64 */     if (logger.isWarnEnabled() && this.properties.isCheckTemplateLocation()) {
/* 65 */       List<TemplateLocation> locations = getLocations();
/* 66 */       if (locations.stream().noneMatch(this::locationExists)) {
/* 67 */         logger.warn("Cannot find template location(s): " + locations + " (please add some templates, check your FreeMarker configuration, or set spring.freemarker.checkTemplateLocation=false)");
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private List<TemplateLocation> getLocations() {
/* 75 */     List<TemplateLocation> locations = new ArrayList<>();
/* 76 */     for (String templateLoaderPath : this.properties.getTemplateLoaderPath()) {
/* 77 */       TemplateLocation location = new TemplateLocation(templateLoaderPath);
/* 78 */       locations.add(location);
/*    */     } 
/* 80 */     return locations;
/*    */   }
/*    */   
/*    */   private boolean locationExists(TemplateLocation location) {
/* 84 */     return location.exists((ResourcePatternResolver)this.applicationContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
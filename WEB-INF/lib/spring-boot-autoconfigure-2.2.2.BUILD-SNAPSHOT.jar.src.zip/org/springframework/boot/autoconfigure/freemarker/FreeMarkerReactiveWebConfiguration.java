/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import freemarker.template.Configuration;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.web.reactive.WebFluxAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ import org.springframework.web.reactive.result.view.freemarker.FreeMarkerConfig;
/*    */ import org.springframework.web.reactive.result.view.freemarker.FreeMarkerConfigurer;
/*    */ import org.springframework.web.reactive.result.view.freemarker.FreeMarkerViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*    */ @AutoConfigureAfter({WebFluxAutoConfiguration.class})
/*    */ class FreeMarkerReactiveWebConfiguration
/*    */   extends AbstractFreeMarkerConfiguration
/*    */ {
/*    */   FreeMarkerReactiveWebConfiguration(FreeMarkerProperties properties) {
/* 42 */     super(properties);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({FreeMarkerConfig.class})
/*    */   FreeMarkerConfigurer freeMarkerConfigurer() {
/* 48 */     FreeMarkerConfigurer configurer = new FreeMarkerConfigurer();
/* 49 */     applyProperties((FreeMarkerConfigurationFactory)configurer);
/* 50 */     return configurer;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   Configuration freeMarkerConfiguration(FreeMarkerConfig configurer) {
/* 55 */     return configurer.getConfiguration();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"freeMarkerViewResolver"})
/*    */   @ConditionalOnProperty(name = {"spring.freemarker.enabled"}, matchIfMissing = true)
/*    */   FreeMarkerViewResolver freeMarkerViewResolver() {
/* 62 */     FreeMarkerViewResolver resolver = new FreeMarkerViewResolver();
/* 63 */     resolver.setPrefix(getProperties().getPrefix());
/* 64 */     resolver.setSuffix(getProperties().getSuffix());
/* 65 */     resolver.setRequestContextAttribute(getProperties().getRequestContextAttribute());
/* 66 */     resolver.setViewNames(getProperties().getViewNames());
/* 67 */     return resolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerReactiveWebConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
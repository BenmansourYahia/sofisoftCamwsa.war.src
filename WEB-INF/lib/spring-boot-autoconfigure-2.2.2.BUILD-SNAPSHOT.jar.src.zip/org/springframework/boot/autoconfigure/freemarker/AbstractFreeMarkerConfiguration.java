/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractFreeMarkerConfiguration
/*    */ {
/*    */   private final FreeMarkerProperties properties;
/*    */   
/*    */   protected AbstractFreeMarkerConfiguration(FreeMarkerProperties properties) {
/* 33 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   protected final FreeMarkerProperties getProperties() {
/* 37 */     return this.properties;
/*    */   }
/*    */   
/*    */   protected void applyProperties(FreeMarkerConfigurationFactory factory) {
/* 41 */     factory.setTemplateLoaderPaths(this.properties.getTemplateLoaderPath());
/* 42 */     factory.setPreferFileSystemAccess(this.properties.isPreferFileSystemAccess());
/* 43 */     factory.setDefaultEncoding(this.properties.getCharsetName());
/* 44 */     Properties settings = new Properties();
/* 45 */     settings.put("recognize_standard_file_extensions", "true");
/* 46 */     settings.putAll(this.properties.getSettings());
/* 47 */     factory.setFreemarkerSettings(settings);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\freemarker\AbstractFreeMarkerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.webservices;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import javax.servlet.Servlet;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.ServletWebServerFactoryAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.ws.config.annotation.EnableWs;
/*     */ import org.springframework.ws.config.annotation.WsConfigurationSupport;
/*     */ import org.springframework.ws.transport.http.MessageDispatcherServlet;
/*     */ import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
/*     */ import org.springframework.xml.xsd.SimpleXsdSchema;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @ConditionalOnClass({MessageDispatcherServlet.class})
/*     */ @ConditionalOnMissingBean({WsConfigurationSupport.class})
/*     */ @EnableConfigurationProperties({WebServicesProperties.class})
/*     */ @AutoConfigureAfter({ServletWebServerFactoryAutoConfiguration.class})
/*     */ public class WebServicesAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   public ServletRegistrationBean<MessageDispatcherServlet> messageDispatcherServlet(ApplicationContext applicationContext, WebServicesProperties properties) {
/*  72 */     MessageDispatcherServlet servlet = new MessageDispatcherServlet();
/*  73 */     servlet.setApplicationContext(applicationContext);
/*  74 */     String path = properties.getPath();
/*  75 */     String urlMapping = path + (path.endsWith("/") ? "*" : "/*");
/*  76 */     ServletRegistrationBean<MessageDispatcherServlet> registration = new ServletRegistrationBean((Servlet)servlet, new String[] { urlMapping });
/*     */     
/*  78 */     WebServicesProperties.Servlet servletProperties = properties.getServlet();
/*  79 */     registration.setLoadOnStartup(servletProperties.getLoadOnStartup());
/*  80 */     servletProperties.getInit().forEach(registration::addInitParameter);
/*  81 */     return registration;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Conditional({OnWsdlLocationsCondition.class})
/*     */   public static WsdlDefinitionBeanFactoryPostProcessor wsdlDefinitionBeanFactoryPostProcessor() {
/*  87 */     return new WsdlDefinitionBeanFactoryPostProcessor();
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @EnableWs
/*     */   protected static class WsConfiguration {}
/*     */   
/*     */   private static class WsdlDefinitionBeanFactoryPostProcessor
/*     */     implements BeanDefinitionRegistryPostProcessor, ApplicationContextAware
/*     */   {
/*     */     private ApplicationContext applicationContext;
/*     */     
/*     */     private WsdlDefinitionBeanFactoryPostProcessor() {}
/*     */     
/*     */     public void setApplicationContext(ApplicationContext applicationContext) {
/* 103 */       this.applicationContext = applicationContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 108 */       Binder binder = Binder.get(this.applicationContext.getEnvironment());
/*     */       
/* 110 */       List<String> wsdlLocations = (List<String>)binder.bind("spring.webservices.wsdl-locations", Bindable.listOf(String.class)).orElse(Collections.emptyList());
/* 111 */       for (String wsdlLocation : wsdlLocations) {
/* 112 */         registerBeans(wsdlLocation, "*.wsdl", SimpleWsdl11Definition.class, SimpleWsdl11Definition::new, registry);
/*     */         
/* 114 */         registerBeans(wsdlLocation, "*.xsd", SimpleXsdSchema.class, SimpleXsdSchema::new, registry);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */     
/*     */     private <T> void registerBeans(String location, String pattern, Class<T> type, Function<Resource, T> beanSupplier, BeanDefinitionRegistry registry) {
/* 124 */       for (Resource resource : getResources(location, pattern)) {
/*     */         
/* 126 */         AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.genericBeanDefinition(type, () -> beanSupplier.apply(resource)).getBeanDefinition();
/* 127 */         registry.registerBeanDefinition(StringUtils.stripFilenameExtension(resource.getFilename()), (BeanDefinition)abstractBeanDefinition);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private Resource[] getResources(String location, String pattern) {
/*     */       try {
/* 134 */         return this.applicationContext.getResources(ensureTrailingSlash(location) + pattern);
/*     */       }
/* 136 */       catch (IOException ex) {
/* 137 */         return new Resource[0];
/*     */       } 
/*     */     }
/*     */     
/*     */     private String ensureTrailingSlash(String path) {
/* 142 */       return path.endsWith("/") ? path : (path + "/");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\webservices\WebServicesAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.webservices;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.OnPropertyListCondition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnWsdlLocationsCondition
/*    */   extends OnPropertyListCondition
/*    */ {
/*    */   OnWsdlLocationsCondition() {
/* 31 */     super("spring.webservices.wsdl-locations", () -> ConditionMessage.forCondition("WSDL locations", new Object[0]));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\webservices\OnWsdlLocationsCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
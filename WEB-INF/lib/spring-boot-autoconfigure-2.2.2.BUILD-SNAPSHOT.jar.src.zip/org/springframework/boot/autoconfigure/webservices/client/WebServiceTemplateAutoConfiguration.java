/*    */ package org.springframework.boot.autoconfigure.webservices.client;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.webservices.client.WebServiceTemplateBuilder;
/*    */ import org.springframework.boot.webservices.client.WebServiceTemplateCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.oxm.Marshaller;
/*    */ import org.springframework.oxm.Unmarshaller;
/*    */ import org.springframework.ws.client.core.WebServiceTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({WebServiceTemplate.class, Unmarshaller.class, Marshaller.class})
/*    */ public class WebServiceTemplateAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public WebServiceTemplateBuilder webServiceTemplateBuilder(ObjectProvider<WebServiceTemplateCustomizer> webServiceTemplateCustomizers) {
/* 48 */     WebServiceTemplateBuilder builder = new WebServiceTemplateBuilder(new WebServiceTemplateCustomizer[0]);
/*    */     
/* 50 */     List<WebServiceTemplateCustomizer> customizers = (List<WebServiceTemplateCustomizer>)webServiceTemplateCustomizers.orderedStream().collect(Collectors.toList());
/* 51 */     if (!customizers.isEmpty()) {
/* 52 */       builder = builder.customizers(customizers);
/*    */     }
/* 54 */     return builder;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\webservices\client\WebServiceTemplateAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
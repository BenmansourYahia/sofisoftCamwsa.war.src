/*     */ package org.springframework.boot.autoconfigure.cassandra;
/*     */ 
/*     */ import com.datastax.driver.core.ConsistencyLevel;
/*     */ import com.datastax.driver.core.ProtocolOptions;
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.data.cassandra")
/*     */ public class CassandraProperties
/*     */ {
/*     */   private String keyspaceName;
/*     */   private String clusterName;
/*  58 */   private final List<String> contactPoints = new ArrayList<>(Collections.singleton("localhost"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private int port = 9042;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String username;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private ProtocolOptions.Compression compression = ProtocolOptions.Compression.NONE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConsistencyLevel consistencyLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConsistencyLevel serialConsistencyLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private int fetchSize = 5000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration connectTimeout;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration readTimeout;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private String schemaAction = "none";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ssl = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean jmxEnabled;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private final Pool pool = new Pool();
/*     */   
/*     */   public String getKeyspaceName() {
/* 127 */     return this.keyspaceName;
/*     */   }
/*     */   
/*     */   public void setKeyspaceName(String keyspaceName) {
/* 131 */     this.keyspaceName = keyspaceName;
/*     */   }
/*     */   
/*     */   public String getClusterName() {
/* 135 */     return this.clusterName;
/*     */   }
/*     */   
/*     */   public void setClusterName(String clusterName) {
/* 139 */     this.clusterName = clusterName;
/*     */   }
/*     */   
/*     */   public List<String> getContactPoints() {
/* 143 */     return this.contactPoints;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 147 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 151 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 155 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 159 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 163 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 167 */     this.password = password;
/*     */   }
/*     */   
/*     */   public ProtocolOptions.Compression getCompression() {
/* 171 */     return this.compression;
/*     */   }
/*     */   
/*     */   public void setCompression(ProtocolOptions.Compression compression) {
/* 175 */     this.compression = compression;
/*     */   }
/*     */   
/*     */   public ConsistencyLevel getConsistencyLevel() {
/* 179 */     return this.consistencyLevel;
/*     */   }
/*     */   
/*     */   public void setConsistencyLevel(ConsistencyLevel consistency) {
/* 183 */     this.consistencyLevel = consistency;
/*     */   }
/*     */   
/*     */   public ConsistencyLevel getSerialConsistencyLevel() {
/* 187 */     return this.serialConsistencyLevel;
/*     */   }
/*     */   
/*     */   public void setSerialConsistencyLevel(ConsistencyLevel serialConsistency) {
/* 191 */     this.serialConsistencyLevel = serialConsistency;
/*     */   }
/*     */   
/*     */   public int getFetchSize() {
/* 195 */     return this.fetchSize;
/*     */   }
/*     */   
/*     */   public void setFetchSize(int fetchSize) {
/* 199 */     this.fetchSize = fetchSize;
/*     */   }
/*     */   
/*     */   public Duration getConnectTimeout() {
/* 203 */     return this.connectTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/* 207 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */   
/*     */   public Duration getReadTimeout() {
/* 211 */     return this.readTimeout;
/*     */   }
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/* 215 */     this.readTimeout = readTimeout;
/*     */   }
/*     */   
/*     */   public boolean isSsl() {
/* 219 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSsl(boolean ssl) {
/* 223 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */   public boolean isJmxEnabled() {
/* 227 */     return this.jmxEnabled;
/*     */   }
/*     */   
/*     */   public void setJmxEnabled(boolean jmxEnabled) {
/* 231 */     this.jmxEnabled = jmxEnabled;
/*     */   }
/*     */   
/*     */   public String getSchemaAction() {
/* 235 */     return this.schemaAction;
/*     */   }
/*     */   
/*     */   public void setSchemaAction(String schemaAction) {
/* 239 */     this.schemaAction = schemaAction;
/*     */   }
/*     */   
/*     */   public Pool getPool() {
/* 243 */     return this.pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pool
/*     */   {
/*     */     @DurationUnit(ChronoUnit.SECONDS)
/* 256 */     private Duration idleTimeout = Duration.ofSeconds(120L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     private Duration poolTimeout = Duration.ofMillis(5000L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @DurationUnit(ChronoUnit.SECONDS)
/* 269 */     private Duration heartbeatInterval = Duration.ofSeconds(30L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     private int maxQueueSize = 256;
/*     */     
/*     */     public Duration getIdleTimeout() {
/* 277 */       return this.idleTimeout;
/*     */     }
/*     */     
/*     */     public void setIdleTimeout(Duration idleTimeout) {
/* 281 */       this.idleTimeout = idleTimeout;
/*     */     }
/*     */     
/*     */     public Duration getPoolTimeout() {
/* 285 */       return this.poolTimeout;
/*     */     }
/*     */     
/*     */     public void setPoolTimeout(Duration poolTimeout) {
/* 289 */       this.poolTimeout = poolTimeout;
/*     */     }
/*     */     
/*     */     public Duration getHeartbeatInterval() {
/* 293 */       return this.heartbeatInterval;
/*     */     }
/*     */     
/*     */     public void setHeartbeatInterval(Duration heartbeatInterval) {
/* 297 */       this.heartbeatInterval = heartbeatInterval;
/*     */     }
/*     */     
/*     */     public int getMaxQueueSize() {
/* 301 */       return this.maxQueueSize;
/*     */     }
/*     */     
/*     */     public void setMaxQueueSize(int maxQueueSize) {
/* 305 */       this.maxQueueSize = maxQueueSize;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
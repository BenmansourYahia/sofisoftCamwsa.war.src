/*     */ package org.springframework.boot.autoconfigure.cassandra;
/*     */ 
/*     */ import com.datastax.driver.core.Cluster;
/*     */ import com.datastax.driver.core.PoolingOptions;
/*     */ import com.datastax.driver.core.QueryOptions;
/*     */ import com.datastax.driver.core.SocketOptions;
/*     */ import java.time.Duration;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({Cluster.class})
/*     */ @EnableConfigurationProperties({CassandraProperties.class})
/*     */ public class CassandraAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public Cluster cassandraCluster(CassandraProperties properties, ObjectProvider<ClusterBuilderCustomizer> builderCustomizers, ObjectProvider<ClusterFactory> clusterFactory) {
/*  56 */     PropertyMapper map = PropertyMapper.get();
/*     */     
/*  58 */     Cluster.Builder builder = Cluster.builder().withClusterName(properties.getClusterName()).withPort(properties.getPort());
/*  59 */     map.from(properties::getUsername).whenNonNull()
/*  60 */       .to(username -> builder.withCredentials(username, properties.getPassword()));
/*  61 */     map.from(properties::getCompression).whenNonNull().to(builder::withCompression);
/*  62 */     QueryOptions queryOptions = getQueryOptions(properties);
/*  63 */     map.from(queryOptions).to(builder::withQueryOptions);
/*  64 */     SocketOptions socketOptions = getSocketOptions(properties);
/*  65 */     map.from(socketOptions).to(builder::withSocketOptions);
/*  66 */     map.from(properties::isSsl).whenTrue().toCall(builder::withSSL);
/*  67 */     PoolingOptions poolingOptions = getPoolingOptions(properties);
/*  68 */     map.from(poolingOptions).to(builder::withPoolingOptions);
/*  69 */     map.from(properties::getContactPoints).as(StringUtils::toStringArray).to(builder::addContactPoints);
/*  70 */     map.from(properties::isJmxEnabled).whenFalse().toCall(builder::withoutJMXReporting);
/*  71 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/*  72 */     return ((ClusterFactory)clusterFactory.getIfAvailable(() -> Cluster::buildFrom)).create((Cluster.Initializer)builder);
/*     */   }
/*     */   
/*     */   private QueryOptions getQueryOptions(CassandraProperties properties) {
/*  76 */     PropertyMapper map = PropertyMapper.get();
/*  77 */     QueryOptions options = new QueryOptions();
/*  78 */     map.from(properties::getConsistencyLevel).whenNonNull().to(options::setConsistencyLevel);
/*  79 */     map.from(properties::getSerialConsistencyLevel).whenNonNull().to(options::setSerialConsistencyLevel);
/*  80 */     map.from(properties::getFetchSize).to(options::setFetchSize);
/*  81 */     return options;
/*     */   }
/*     */   
/*     */   private SocketOptions getSocketOptions(CassandraProperties properties) {
/*  85 */     PropertyMapper map = PropertyMapper.get();
/*  86 */     SocketOptions options = new SocketOptions();
/*  87 */     map.from(properties::getConnectTimeout).whenNonNull().asInt(Duration::toMillis)
/*  88 */       .to(options::setConnectTimeoutMillis);
/*  89 */     map.from(properties::getReadTimeout).whenNonNull().asInt(Duration::toMillis).to(options::setReadTimeoutMillis);
/*  90 */     return options;
/*     */   }
/*     */   
/*     */   private PoolingOptions getPoolingOptions(CassandraProperties properties) {
/*  94 */     PropertyMapper map = PropertyMapper.get();
/*  95 */     CassandraProperties.Pool poolProperties = properties.getPool();
/*  96 */     PoolingOptions options = new PoolingOptions();
/*  97 */     map.from(poolProperties::getIdleTimeout).whenNonNull().asInt(Duration::getSeconds)
/*  98 */       .to(options::setIdleTimeoutSeconds);
/*  99 */     map.from(poolProperties::getPoolTimeout).whenNonNull().asInt(Duration::toMillis)
/* 100 */       .to(options::setPoolTimeoutMillis);
/* 101 */     map.from(poolProperties::getHeartbeatInterval).whenNonNull().asInt(Duration::getSeconds)
/* 102 */       .to(options::setHeartbeatIntervalSeconds);
/* 103 */     map.from(poolProperties::getMaxQueueSize).to(options::setMaxQueueSize);
/* 104 */     return options;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
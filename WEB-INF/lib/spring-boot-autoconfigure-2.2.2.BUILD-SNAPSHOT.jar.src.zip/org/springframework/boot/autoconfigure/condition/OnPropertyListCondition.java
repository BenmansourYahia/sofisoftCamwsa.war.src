/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.boot.context.properties.bind.BindResult;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnPropertyListCondition
/*    */   extends SpringBootCondition
/*    */ {
/* 39 */   private static final Bindable<List<String>> STRING_LIST = Bindable.listOf(String.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private final String propertyName;
/*    */ 
/*    */ 
/*    */   
/*    */   private final Supplier<ConditionMessage.Builder> messageBuilder;
/*    */ 
/*    */ 
/*    */   
/*    */   protected OnPropertyListCondition(String propertyName, Supplier<ConditionMessage.Builder> messageBuilder) {
/* 52 */     this.propertyName = propertyName;
/* 53 */     this.messageBuilder = messageBuilder;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 58 */     BindResult<?> property = Binder.get(context.getEnvironment()).bind(this.propertyName, STRING_LIST);
/* 59 */     ConditionMessage.Builder messageBuilder = this.messageBuilder.get();
/* 60 */     if (property.isBound()) {
/* 61 */       return ConditionOutcome.match(messageBuilder.found("property").items(new Object[] { this.propertyName }));
/*    */     }
/* 63 */     return ConditionOutcome.noMatch(messageBuilder.didNotFind("property").items(new Object[] { this.propertyName }));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\OnPropertyListCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
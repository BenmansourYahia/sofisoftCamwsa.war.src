/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.ClassMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpringBootCondition
/*     */   implements Condition
/*     */ {
/*  41 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   public final boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  45 */     String classOrMethodName = getClassOrMethodName(metadata);
/*     */     try {
/*  47 */       ConditionOutcome outcome = getMatchOutcome(context, metadata);
/*  48 */       logOutcome(classOrMethodName, outcome);
/*  49 */       recordEvaluation(context, classOrMethodName, outcome);
/*  50 */       return outcome.isMatch();
/*     */     }
/*  52 */     catch (NoClassDefFoundError ex) {
/*  53 */       throw new IllegalStateException("Could not evaluate condition on " + classOrMethodName + " due to " + ex
/*  54 */           .getMessage() + " not found. Make sure your own configuration does not rely on that class. This can also happen if you are @ComponentScanning a springframework package (e.g. if you put a @ComponentScan in the default package by mistake)", ex);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  59 */     catch (RuntimeException ex) {
/*  60 */       throw new IllegalStateException("Error processing condition on " + getName(metadata), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getName(AnnotatedTypeMetadata metadata) {
/*  65 */     if (metadata instanceof AnnotationMetadata) {
/*  66 */       return ((AnnotationMetadata)metadata).getClassName();
/*     */     }
/*  68 */     if (metadata instanceof MethodMetadata) {
/*  69 */       MethodMetadata methodMetadata = (MethodMetadata)metadata;
/*  70 */       return methodMetadata.getDeclaringClassName() + "." + methodMetadata.getMethodName();
/*     */     } 
/*  72 */     return metadata.toString();
/*     */   }
/*     */   
/*     */   private static String getClassOrMethodName(AnnotatedTypeMetadata metadata) {
/*  76 */     if (metadata instanceof ClassMetadata) {
/*  77 */       ClassMetadata classMetadata = (ClassMetadata)metadata;
/*  78 */       return classMetadata.getClassName();
/*     */     } 
/*  80 */     MethodMetadata methodMetadata = (MethodMetadata)metadata;
/*  81 */     return methodMetadata.getDeclaringClassName() + "#" + methodMetadata.getMethodName();
/*     */   }
/*     */   
/*     */   protected final void logOutcome(String classOrMethodName, ConditionOutcome outcome) {
/*  85 */     if (this.logger.isTraceEnabled()) {
/*  86 */       this.logger.trace(getLogMessage(classOrMethodName, outcome));
/*     */     }
/*     */   }
/*     */   
/*     */   private StringBuilder getLogMessage(String classOrMethodName, ConditionOutcome outcome) {
/*  91 */     StringBuilder message = new StringBuilder();
/*  92 */     message.append("Condition ");
/*  93 */     message.append(ClassUtils.getShortName(getClass()));
/*  94 */     message.append(" on ");
/*  95 */     message.append(classOrMethodName);
/*  96 */     message.append(outcome.isMatch() ? " matched" : " did not match");
/*  97 */     if (StringUtils.hasLength(outcome.getMessage())) {
/*  98 */       message.append(" due to ");
/*  99 */       message.append(outcome.getMessage());
/*     */     } 
/* 101 */     return message;
/*     */   }
/*     */   
/*     */   private void recordEvaluation(ConditionContext context, String classOrMethodName, ConditionOutcome outcome) {
/* 105 */     if (context.getBeanFactory() != null) {
/* 106 */       ConditionEvaluationReport.get(context.getBeanFactory()).recordConditionEvaluation(classOrMethodName, this, outcome);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ConditionOutcome getMatchOutcome(ConditionContext paramConditionContext, AnnotatedTypeMetadata paramAnnotatedTypeMetadata);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean anyMatches(ConditionContext context, AnnotatedTypeMetadata metadata, Condition... conditions) {
/* 128 */     for (Condition condition : conditions) {
/* 129 */       if (matches(context, metadata, condition)) {
/* 130 */         return true;
/*     */       }
/*     */     } 
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata, Condition condition) {
/* 144 */     if (condition instanceof SpringBootCondition) {
/* 145 */       return ((SpringBootCondition)condition).getMatchOutcome(context, metadata).isMatch();
/*     */     }
/* 147 */     return condition.matches(context, metadata);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\SpringBootCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
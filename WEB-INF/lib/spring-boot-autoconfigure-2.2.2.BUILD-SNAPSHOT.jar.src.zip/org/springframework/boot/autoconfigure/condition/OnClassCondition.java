/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.security.AccessControlException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483648)
/*     */ class OnClassCondition
/*     */   extends FilteringSpringBootCondition
/*     */ {
/*     */   protected final ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  52 */     if (Runtime.getRuntime().availableProcessors() > 1) {
/*  53 */       return resolveOutcomesThreaded(autoConfigurationClasses, autoConfigurationMetadata);
/*     */     }
/*     */ 
/*     */     
/*  57 */     OutcomesResolver outcomesResolver = new StandardOutcomesResolver(autoConfigurationClasses, 0, autoConfigurationClasses.length, autoConfigurationMetadata, getBeanClassLoader());
/*  58 */     return outcomesResolver.resolveOutcomes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConditionOutcome[] resolveOutcomesThreaded(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  64 */     int split = autoConfigurationClasses.length / 2;
/*  65 */     OutcomesResolver firstHalfResolver = createOutcomesResolver(autoConfigurationClasses, 0, split, autoConfigurationMetadata);
/*     */ 
/*     */     
/*  68 */     OutcomesResolver secondHalfResolver = new StandardOutcomesResolver(autoConfigurationClasses, split, autoConfigurationClasses.length, autoConfigurationMetadata, getBeanClassLoader());
/*  69 */     ConditionOutcome[] secondHalf = secondHalfResolver.resolveOutcomes();
/*  70 */     ConditionOutcome[] firstHalf = firstHalfResolver.resolveOutcomes();
/*  71 */     ConditionOutcome[] outcomes = new ConditionOutcome[autoConfigurationClasses.length];
/*  72 */     System.arraycopy(firstHalf, 0, outcomes, 0, firstHalf.length);
/*  73 */     System.arraycopy(secondHalf, 0, outcomes, split, secondHalf.length);
/*  74 */     return outcomes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private OutcomesResolver createOutcomesResolver(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  80 */     OutcomesResolver outcomesResolver = new StandardOutcomesResolver(autoConfigurationClasses, start, end, autoConfigurationMetadata, getBeanClassLoader());
/*     */     try {
/*  82 */       return new ThreadedOutcomesResolver(outcomesResolver);
/*     */     }
/*  84 */     catch (AccessControlException ex) {
/*  85 */       return outcomesResolver;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  91 */     ClassLoader classLoader = context.getClassLoader();
/*  92 */     ConditionMessage matchMessage = ConditionMessage.empty();
/*  93 */     List<String> onClasses = getCandidates(metadata, ConditionalOnClass.class);
/*  94 */     if (onClasses != null) {
/*  95 */       List<String> missing = filter(onClasses, FilteringSpringBootCondition.ClassNameFilter.MISSING, classLoader);
/*  96 */       if (!missing.isEmpty()) {
/*  97 */         return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnClass.class, new Object[0])
/*  98 */             .didNotFind("required class", "required classes").items(ConditionMessage.Style.QUOTE, missing));
/*     */       }
/*     */ 
/*     */       
/* 102 */       matchMessage = matchMessage.andCondition((Class)ConditionalOnClass.class, new Object[0]).found("required class", "required classes").items(ConditionMessage.Style.QUOTE, filter(onClasses, FilteringSpringBootCondition.ClassNameFilter.PRESENT, classLoader));
/*     */     } 
/* 104 */     List<String> onMissingClasses = getCandidates(metadata, ConditionalOnMissingClass.class);
/* 105 */     if (onMissingClasses != null) {
/* 106 */       List<String> present = filter(onMissingClasses, FilteringSpringBootCondition.ClassNameFilter.PRESENT, classLoader);
/* 107 */       if (!present.isEmpty()) {
/* 108 */         return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnMissingClass.class, new Object[0])
/* 109 */             .found("unwanted class", "unwanted classes").items(ConditionMessage.Style.QUOTE, present));
/*     */       }
/*     */ 
/*     */       
/* 113 */       matchMessage = matchMessage.andCondition((Class)ConditionalOnMissingClass.class, new Object[0]).didNotFind("unwanted class", "unwanted classes").items(ConditionMessage.Style.QUOTE, filter(onMissingClasses, FilteringSpringBootCondition.ClassNameFilter.MISSING, classLoader));
/*     */     } 
/* 115 */     return ConditionOutcome.match(matchMessage);
/*     */   }
/*     */   
/*     */   private List<String> getCandidates(AnnotatedTypeMetadata metadata, Class<?> annotationType) {
/* 119 */     MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(annotationType.getName(), true);
/* 120 */     if (attributes == null) {
/* 121 */       return null;
/*     */     }
/* 123 */     List<String> candidates = new ArrayList<>();
/* 124 */     addAll(candidates, (List<Object>)attributes.get("value"));
/* 125 */     addAll(candidates, (List<Object>)attributes.get("name"));
/* 126 */     return candidates;
/*     */   }
/*     */   
/*     */   private void addAll(List<String> list, List<Object> itemsToAdd) {
/* 130 */     if (itemsToAdd != null) {
/* 131 */       for (Object item : itemsToAdd) {
/* 132 */         Collections.addAll(list, (String[])item);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static interface OutcomesResolver
/*     */   {
/*     */     ConditionOutcome[] resolveOutcomes();
/*     */   }
/*     */   
/*     */   private static final class ThreadedOutcomesResolver
/*     */     implements OutcomesResolver
/*     */   {
/*     */     private final Thread thread;
/*     */     private volatile ConditionOutcome[] outcomes;
/*     */     
/*     */     private ThreadedOutcomesResolver(OnClassCondition.OutcomesResolver outcomesResolver) {
/* 150 */       this.thread = new Thread(() -> this.outcomes = outcomesResolver.resolveOutcomes());
/* 151 */       this.thread.start();
/*     */     }
/*     */ 
/*     */     
/*     */     public ConditionOutcome[] resolveOutcomes() {
/*     */       try {
/* 157 */         this.thread.join();
/*     */       }
/* 159 */       catch (InterruptedException ex) {
/* 160 */         Thread.currentThread().interrupt();
/*     */       } 
/* 162 */       return this.outcomes;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class StandardOutcomesResolver
/*     */     implements OutcomesResolver
/*     */   {
/*     */     private final String[] autoConfigurationClasses;
/*     */     
/*     */     private final int start;
/*     */     
/*     */     private final int end;
/*     */     
/*     */     private final AutoConfigurationMetadata autoConfigurationMetadata;
/*     */     
/*     */     private final ClassLoader beanClassLoader;
/*     */     
/*     */     private StandardOutcomesResolver(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata, ClassLoader beanClassLoader) {
/* 181 */       this.autoConfigurationClasses = autoConfigurationClasses;
/* 182 */       this.start = start;
/* 183 */       this.end = end;
/* 184 */       this.autoConfigurationMetadata = autoConfigurationMetadata;
/* 185 */       this.beanClassLoader = beanClassLoader;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConditionOutcome[] resolveOutcomes() {
/* 190 */       return getOutcomes(this.autoConfigurationClasses, this.start, this.end, this.autoConfigurationMetadata);
/*     */     }
/*     */ 
/*     */     
/*     */     private ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata) {
/* 195 */       ConditionOutcome[] outcomes = new ConditionOutcome[end - start];
/* 196 */       for (int i = start; i < end; i++) {
/* 197 */         String autoConfigurationClass = autoConfigurationClasses[i];
/* 198 */         if (autoConfigurationClass != null) {
/* 199 */           String candidates = autoConfigurationMetadata.get(autoConfigurationClass, "ConditionalOnClass");
/* 200 */           if (candidates != null) {
/* 201 */             outcomes[i - start] = getOutcome(candidates);
/*     */           }
/*     */         } 
/*     */       } 
/* 205 */       return outcomes;
/*     */     }
/*     */     
/*     */     private ConditionOutcome getOutcome(String candidates) {
/*     */       try {
/* 210 */         if (!candidates.contains(",")) {
/* 211 */           return getOutcome(candidates, this.beanClassLoader);
/*     */         }
/* 213 */         for (String candidate : StringUtils.commaDelimitedListToStringArray(candidates)) {
/* 214 */           ConditionOutcome outcome = getOutcome(candidate, this.beanClassLoader);
/* 215 */           if (outcome != null) {
/* 216 */             return outcome;
/*     */           }
/*     */         }
/*     */       
/* 220 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 223 */       return null;
/*     */     }
/*     */     
/*     */     private ConditionOutcome getOutcome(String className, ClassLoader classLoader) {
/* 227 */       if (FilteringSpringBootCondition.ClassNameFilter.MISSING.matches(className, classLoader)) {
/* 228 */         return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnClass.class, new Object[0])
/* 229 */             .didNotFind("required class").items(ConditionMessage.Style.QUOTE, new Object[] { className }));
/*     */       }
/* 231 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\OnClassCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
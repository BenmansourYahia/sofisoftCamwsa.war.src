/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConditionEvaluationReport
/*     */ {
/*     */   private static final String BEAN_NAME = "autoConfigurationReport";
/*  54 */   private static final AncestorsMatchedCondition ANCESTOR_CONDITION = new AncestorsMatchedCondition();
/*     */   
/*  56 */   private final SortedMap<String, ConditionAndOutcomes> outcomes = new TreeMap<>();
/*     */   
/*     */   private boolean addedAncestorOutcomes;
/*     */   
/*     */   private ConditionEvaluationReport parent;
/*     */   
/*  62 */   private final List<String> exclusions = new ArrayList<>();
/*     */   
/*  64 */   private final Set<String> unconditionalClasses = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConditionEvaluation(String source, Condition condition, ConditionOutcome outcome) {
/*  80 */     Assert.notNull(source, "Source must not be null");
/*  81 */     Assert.notNull(condition, "Condition must not be null");
/*  82 */     Assert.notNull(outcome, "Outcome must not be null");
/*  83 */     this.unconditionalClasses.remove(source);
/*  84 */     if (!this.outcomes.containsKey(source)) {
/*  85 */       this.outcomes.put(source, new ConditionAndOutcomes());
/*     */     }
/*  87 */     ((ConditionAndOutcomes)this.outcomes.get(source)).add(condition, outcome);
/*  88 */     this.addedAncestorOutcomes = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordExclusions(Collection<String> exclusions) {
/*  96 */     Assert.notNull(exclusions, "exclusions must not be null");
/*  97 */     this.exclusions.addAll(exclusions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordEvaluationCandidates(List<String> evaluationCandidates) {
/* 106 */     Assert.notNull(evaluationCandidates, "evaluationCandidates must not be null");
/* 107 */     this.unconditionalClasses.addAll(evaluationCandidates);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ConditionAndOutcomes> getConditionAndOutcomesBySource() {
/* 115 */     if (!this.addedAncestorOutcomes) {
/* 116 */       this.outcomes.forEach((source, sourceOutcomes) -> {
/*     */             if (!sourceOutcomes.isFullMatch()) {
/*     */               addNoMatchOutcomeToAncestors(source);
/*     */             }
/*     */           });
/* 121 */       this.addedAncestorOutcomes = true;
/*     */     } 
/* 123 */     return Collections.unmodifiableMap(this.outcomes);
/*     */   }
/*     */   
/*     */   private void addNoMatchOutcomeToAncestors(String source) {
/* 127 */     String prefix = source + "$";
/* 128 */     this.outcomes.forEach((candidateSource, sourceOutcomes) -> {
/*     */           if (candidateSource.startsWith(prefix)) {
/*     */             ConditionOutcome outcome = ConditionOutcome.noMatch(ConditionMessage.forCondition("Ancestor " + source, new Object[0]).because("did not match"));
/*     */             sourceOutcomes.add(ANCESTOR_CONDITION, outcome);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getExclusions() {
/* 142 */     return Collections.unmodifiableList(this.exclusions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getUnconditionalClasses() {
/* 150 */     Set<String> filtered = new HashSet<>(this.unconditionalClasses);
/* 151 */     filtered.removeAll(this.exclusions);
/* 152 */     return Collections.unmodifiableSet(filtered);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionEvaluationReport getParent() {
/* 160 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionEvaluationReport find(BeanFactory beanFactory) {
/* 170 */     if (beanFactory != null && beanFactory instanceof org.springframework.beans.factory.config.ConfigurableBeanFactory) {
/* 171 */       return get((ConfigurableListableBeanFactory)beanFactory);
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionEvaluationReport get(ConfigurableListableBeanFactory beanFactory) {
/* 182 */     synchronized (beanFactory) {
/*     */       ConditionEvaluationReport report;
/* 184 */       if (beanFactory.containsSingleton("autoConfigurationReport")) {
/* 185 */         report = (ConditionEvaluationReport)beanFactory.getBean("autoConfigurationReport", ConditionEvaluationReport.class);
/*     */       } else {
/*     */         
/* 188 */         report = new ConditionEvaluationReport();
/* 189 */         beanFactory.registerSingleton("autoConfigurationReport", report);
/*     */       } 
/* 191 */       locateParent(beanFactory.getParentBeanFactory(), report);
/* 192 */       return report;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void locateParent(BeanFactory beanFactory, ConditionEvaluationReport report) {
/* 197 */     if (beanFactory != null && report.parent == null && beanFactory.containsBean("autoConfigurationReport")) {
/* 198 */       report.parent = (ConditionEvaluationReport)beanFactory.getBean("autoConfigurationReport", ConditionEvaluationReport.class);
/*     */     }
/*     */   }
/*     */   
/*     */   public ConditionEvaluationReport getDelta(ConditionEvaluationReport previousReport) {
/* 203 */     ConditionEvaluationReport delta = new ConditionEvaluationReport();
/* 204 */     this.outcomes.forEach((source, sourceOutcomes) -> {
/*     */           ConditionAndOutcomes previous = previousReport.outcomes.get(source);
/*     */           
/*     */           if (previous == null || previous.isFullMatch() != sourceOutcomes.isFullMatch()) {
/*     */             sourceOutcomes.forEach(());
/*     */           }
/*     */         });
/* 211 */     List<String> newExclusions = new ArrayList<>(this.exclusions);
/* 212 */     newExclusions.removeAll(previousReport.getExclusions());
/* 213 */     delta.recordExclusions(newExclusions);
/* 214 */     List<String> newUnconditionalClasses = new ArrayList<>(this.unconditionalClasses);
/* 215 */     newUnconditionalClasses.removeAll(previousReport.unconditionalClasses);
/* 216 */     delta.unconditionalClasses.addAll(newUnconditionalClasses);
/* 217 */     return delta;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConditionAndOutcomes
/*     */     implements Iterable<ConditionAndOutcome>
/*     */   {
/* 225 */     private final Set<ConditionEvaluationReport.ConditionAndOutcome> outcomes = new LinkedHashSet<>();
/*     */     
/*     */     public void add(Condition condition, ConditionOutcome outcome) {
/* 228 */       this.outcomes.add(new ConditionEvaluationReport.ConditionAndOutcome(condition, outcome));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isFullMatch() {
/* 236 */       for (ConditionEvaluationReport.ConditionAndOutcome conditionAndOutcomes : this) {
/* 237 */         if (!conditionAndOutcomes.getOutcome().isMatch()) {
/* 238 */           return false;
/*     */         }
/*     */       } 
/* 241 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<ConditionEvaluationReport.ConditionAndOutcome> iterator() {
/* 246 */       return Collections.<ConditionEvaluationReport.ConditionAndOutcome>unmodifiableSet(this.outcomes).iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConditionAndOutcome
/*     */   {
/*     */     private final Condition condition;
/*     */ 
/*     */     
/*     */     private final ConditionOutcome outcome;
/*     */ 
/*     */     
/*     */     public ConditionAndOutcome(Condition condition, ConditionOutcome outcome) {
/* 261 */       this.condition = condition;
/* 262 */       this.outcome = outcome;
/*     */     }
/*     */     
/*     */     public Condition getCondition() {
/* 266 */       return this.condition;
/*     */     }
/*     */     
/*     */     public ConditionOutcome getOutcome() {
/* 270 */       return this.outcome;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 275 */       if (this == obj) {
/* 276 */         return true;
/*     */       }
/* 278 */       if (obj == null || getClass() != obj.getClass()) {
/* 279 */         return false;
/*     */       }
/* 281 */       ConditionAndOutcome other = (ConditionAndOutcome)obj;
/* 282 */       return (ObjectUtils.nullSafeEquals(this.condition.getClass(), other.condition.getClass()) && 
/* 283 */         ObjectUtils.nullSafeEquals(this.outcome, other.outcome));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 288 */       return this.condition.getClass().hashCode() * 31 + this.outcome.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 293 */       return this.condition.getClass() + " " + this.outcome;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AncestorsMatchedCondition
/*     */     implements Condition {
/*     */     private AncestorsMatchedCondition() {}
/*     */     
/*     */     public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 302 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\ConditionEvaluationReport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
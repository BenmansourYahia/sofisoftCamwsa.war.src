/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotationCollectors;
/*     */ import org.springframework.core.annotation.MergedAnnotationPredicates;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(2147483647)
/*     */ class OnBeanCondition
/*     */   extends FilteringSpringBootCondition
/*     */   implements ConfigurationCondition
/*     */ {
/*     */   public ConfigurationCondition.ConfigurationPhase getConfigurationPhase() {
/*  79 */     return ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  85 */     ConditionOutcome[] outcomes = new ConditionOutcome[autoConfigurationClasses.length];
/*  86 */     for (int i = 0; i < outcomes.length; i++) {
/*  87 */       String autoConfigurationClass = autoConfigurationClasses[i];
/*  88 */       if (autoConfigurationClass != null) {
/*  89 */         Set<String> onBeanTypes = autoConfigurationMetadata.getSet(autoConfigurationClass, "ConditionalOnBean");
/*  90 */         outcomes[i] = getOutcome(onBeanTypes, (Class)ConditionalOnBean.class);
/*  91 */         if (outcomes[i] == null) {
/*  92 */           Set<String> onSingleCandidateTypes = autoConfigurationMetadata.getSet(autoConfigurationClass, "ConditionalOnSingleCandidate");
/*     */           
/*  94 */           outcomes[i] = getOutcome(onSingleCandidateTypes, (Class)ConditionalOnSingleCandidate.class);
/*     */         } 
/*     */       } 
/*     */     } 
/*  98 */     return outcomes;
/*     */   }
/*     */   
/*     */   private ConditionOutcome getOutcome(Set<String> requiredBeanTypes, Class<? extends Annotation> annotation) {
/* 102 */     List<String> missing = filter(requiredBeanTypes, FilteringSpringBootCondition.ClassNameFilter.MISSING, getBeanClassLoader());
/* 103 */     if (!missing.isEmpty()) {
/*     */       
/* 105 */       ConditionMessage message = ConditionMessage.forCondition(annotation, new Object[0]).didNotFind("required type", "required types").items(ConditionMessage.Style.QUOTE, missing);
/* 106 */       return ConditionOutcome.noMatch(message);
/*     */     } 
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 113 */     ConditionMessage matchMessage = ConditionMessage.empty();
/* 114 */     MergedAnnotations annotations = metadata.getAnnotations();
/* 115 */     if (annotations.isPresent(ConditionalOnBean.class)) {
/* 116 */       Spec<ConditionalOnBean> spec = new Spec<>(context, metadata, annotations, ConditionalOnBean.class);
/* 117 */       MatchResult matchResult = getMatchingBeans(context, spec);
/* 118 */       if (!matchResult.isAllMatched()) {
/* 119 */         String reason = createOnBeanNoMatchReason(matchResult);
/* 120 */         return ConditionOutcome.noMatch(spec.message().because(reason));
/*     */       } 
/* 122 */       matchMessage = spec.message(matchMessage).found("bean", "beans").items(ConditionMessage.Style.QUOTE, matchResult
/* 123 */           .getNamesOfAllMatches());
/*     */     } 
/* 125 */     if (metadata.isAnnotated(ConditionalOnSingleCandidate.class.getName())) {
/* 126 */       Spec<ConditionalOnSingleCandidate> spec = new SingleCandidateSpec(context, metadata, annotations);
/* 127 */       MatchResult matchResult = getMatchingBeans(context, spec);
/* 128 */       if (!matchResult.isAllMatched()) {
/* 129 */         return ConditionOutcome.noMatch(spec.message().didNotFind("any beans").atAll());
/*     */       }
/* 131 */       if (!hasSingleAutowireCandidate(context.getBeanFactory(), matchResult.getNamesOfAllMatches(), 
/* 132 */           (spec.getStrategy() == SearchStrategy.ALL))) {
/* 133 */         return ConditionOutcome.noMatch(spec.message().didNotFind("a primary bean from beans")
/* 134 */             .items(ConditionMessage.Style.QUOTE, matchResult.getNamesOfAllMatches()));
/*     */       }
/* 136 */       matchMessage = spec.message(matchMessage).found("a primary bean from beans").items(ConditionMessage.Style.QUOTE, matchResult
/* 137 */           .getNamesOfAllMatches());
/*     */     } 
/* 139 */     if (metadata.isAnnotated(ConditionalOnMissingBean.class.getName())) {
/* 140 */       Spec<ConditionalOnMissingBean> spec = new Spec<>(context, metadata, annotations, ConditionalOnMissingBean.class);
/*     */       
/* 142 */       MatchResult matchResult = getMatchingBeans(context, spec);
/* 143 */       if (matchResult.isAnyMatched()) {
/* 144 */         String reason = createOnMissingBeanNoMatchReason(matchResult);
/* 145 */         return ConditionOutcome.noMatch(spec.message().because(reason));
/*     */       } 
/* 147 */       matchMessage = spec.message(matchMessage).didNotFind("any beans").atAll();
/*     */     } 
/* 149 */     return ConditionOutcome.match(matchMessage);
/*     */   }
/*     */   
/*     */   protected final MatchResult getMatchingBeans(ConditionContext context, Spec<?> spec) {
/* 153 */     ClassLoader classLoader = context.getClassLoader();
/* 154 */     ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/* 155 */     boolean considerHierarchy = (spec.getStrategy() != SearchStrategy.CURRENT);
/* 156 */     Set<Class<?>> parameterizedContainers = spec.getParameterizedContainers();
/* 157 */     if (spec.getStrategy() == SearchStrategy.ANCESTORS) {
/* 158 */       BeanFactory parent = beanFactory.getParentBeanFactory();
/* 159 */       Assert.isInstanceOf(ConfigurableListableBeanFactory.class, parent, "Unable to use SearchStrategy.ANCESTORS");
/*     */       
/* 161 */       beanFactory = (ConfigurableListableBeanFactory)parent;
/*     */     } 
/* 163 */     MatchResult result = new MatchResult();
/* 164 */     Set<String> beansIgnoredByType = getNamesOfBeansIgnoredByType(classLoader, (ListableBeanFactory)beanFactory, considerHierarchy, spec
/* 165 */         .getIgnoredTypes(), parameterizedContainers);
/* 166 */     for (String type : spec.getTypes()) {
/* 167 */       Collection<String> typeMatches = getBeanNamesForType(classLoader, considerHierarchy, (ListableBeanFactory)beanFactory, type, parameterizedContainers);
/*     */       
/* 169 */       typeMatches.removeAll(beansIgnoredByType);
/* 170 */       if (typeMatches.isEmpty()) {
/* 171 */         result.recordUnmatchedType(type);
/*     */         continue;
/*     */       } 
/* 174 */       result.recordMatchedType(type, typeMatches);
/*     */     } 
/*     */     
/* 177 */     for (String annotation : spec.getAnnotations()) {
/* 178 */       Set<String> annotationMatches = getBeanNamesForAnnotation(classLoader, beanFactory, annotation, considerHierarchy);
/*     */       
/* 180 */       annotationMatches.removeAll(beansIgnoredByType);
/* 181 */       if (annotationMatches.isEmpty()) {
/* 182 */         result.recordUnmatchedAnnotation(annotation);
/*     */         continue;
/*     */       } 
/* 185 */       result.recordMatchedAnnotation(annotation, annotationMatches);
/*     */     } 
/*     */     
/* 188 */     for (String beanName : spec.getNames()) {
/* 189 */       if (!beansIgnoredByType.contains(beanName) && containsBean(beanFactory, beanName, considerHierarchy)) {
/* 190 */         result.recordMatchedName(beanName);
/*     */         continue;
/*     */       } 
/* 193 */       result.recordUnmatchedName(beanName);
/*     */     } 
/*     */     
/* 196 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getNamesOfBeansIgnoredByType(ClassLoader classLoader, ListableBeanFactory beanFactory, boolean considerHierarchy, Set<String> ignoredTypes, Set<Class<?>> parameterizedContainers) {
/* 201 */     Set<String> result = null;
/* 202 */     for (String ignoredType : ignoredTypes) {
/* 203 */       Collection<String> ignoredNames = getBeanNamesForType(classLoader, considerHierarchy, beanFactory, ignoredType, parameterizedContainers);
/*     */       
/* 205 */       result = addAll(result, ignoredNames);
/*     */     } 
/* 207 */     return (result != null) ? result : Collections.<String>emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getBeanNamesForType(ClassLoader classLoader, boolean considerHierarchy, ListableBeanFactory beanFactory, String type, Set<Class<?>> parameterizedContainers) throws LinkageError {
/*     */     try {
/* 213 */       return getBeanNamesForType(beanFactory, considerHierarchy, resolve(type, classLoader), parameterizedContainers);
/*     */     
/*     */     }
/* 216 */     catch (ClassNotFoundException|NoClassDefFoundError ex) {
/* 217 */       return Collections.emptySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getBeanNamesForType(ListableBeanFactory beanFactory, boolean considerHierarchy, Class<?> type, Set<Class<?>> parameterizedContainers) {
/* 223 */     Set<String> result = collectBeanNamesForType(beanFactory, considerHierarchy, type, parameterizedContainers, (Set<String>)null);
/*     */     
/* 225 */     return (result != null) ? result : Collections.<String>emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> collectBeanNamesForType(ListableBeanFactory beanFactory, boolean considerHierarchy, Class<?> type, Set<Class<?>> parameterizedContainers, Set<String> result) {
/* 230 */     result = addAll(result, beanFactory.getBeanNamesForType(type, true, false));
/* 231 */     for (Class<?> container : parameterizedContainers) {
/* 232 */       ResolvableType generic = ResolvableType.forClassWithGenerics(container, new Class[] { type });
/* 233 */       result = addAll(result, beanFactory.getBeanNamesForType(generic, true, false));
/*     */     } 
/* 235 */     if (considerHierarchy && beanFactory instanceof HierarchicalBeanFactory) {
/* 236 */       BeanFactory parent = ((HierarchicalBeanFactory)beanFactory).getParentBeanFactory();
/* 237 */       if (parent instanceof ListableBeanFactory) {
/* 238 */         result = collectBeanNamesForType((ListableBeanFactory)parent, considerHierarchy, type, parameterizedContainers, result);
/*     */       }
/*     */     } 
/*     */     
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getBeanNamesForAnnotation(ClassLoader classLoader, ConfigurableListableBeanFactory beanFactory, String type, boolean considerHierarchy) throws LinkageError {
/* 247 */     Set<String> result = null;
/*     */     try {
/* 249 */       result = collectBeanNamesForAnnotation((ListableBeanFactory)beanFactory, resolveAnnotationType(classLoader, type), considerHierarchy, result);
/*     */     
/*     */     }
/* 252 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 255 */     return (result != null) ? result : Collections.<String>emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<? extends Annotation> resolveAnnotationType(ClassLoader classLoader, String type) throws ClassNotFoundException {
/* 261 */     return (Class)resolve(type, classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> collectBeanNamesForAnnotation(ListableBeanFactory beanFactory, Class<? extends Annotation> annotationType, boolean considerHierarchy, Set<String> result) {
/* 266 */     result = addAll(result, beanFactory.getBeanNamesForAnnotation(annotationType));
/* 267 */     if (considerHierarchy) {
/* 268 */       BeanFactory parent = ((HierarchicalBeanFactory)beanFactory).getParentBeanFactory();
/* 269 */       if (parent instanceof ListableBeanFactory) {
/* 270 */         result = collectBeanNamesForAnnotation((ListableBeanFactory)parent, annotationType, considerHierarchy, result);
/*     */       }
/*     */     } 
/*     */     
/* 274 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean containsBean(ConfigurableListableBeanFactory beanFactory, String beanName, boolean considerHierarchy) {
/* 279 */     if (considerHierarchy) {
/* 280 */       return beanFactory.containsBean(beanName);
/*     */     }
/* 282 */     return beanFactory.containsLocalBean(beanName);
/*     */   }
/*     */   
/*     */   private String createOnBeanNoMatchReason(MatchResult matchResult) {
/* 286 */     StringBuilder reason = new StringBuilder();
/* 287 */     appendMessageForNoMatches(reason, matchResult.getUnmatchedAnnotations(), "annotated with");
/* 288 */     appendMessageForNoMatches(reason, matchResult.getUnmatchedTypes(), "of type");
/* 289 */     appendMessageForNoMatches(reason, matchResult.getUnmatchedNames(), "named");
/* 290 */     return reason.toString();
/*     */   }
/*     */   
/*     */   private void appendMessageForNoMatches(StringBuilder reason, Collection<String> unmatched, String description) {
/* 294 */     if (!unmatched.isEmpty()) {
/* 295 */       if (reason.length() > 0) {
/* 296 */         reason.append(" and ");
/*     */       }
/* 298 */       reason.append("did not find any beans ");
/* 299 */       reason.append(description);
/* 300 */       reason.append(" ");
/* 301 */       reason.append(StringUtils.collectionToDelimitedString(unmatched, ", "));
/*     */     } 
/*     */   }
/*     */   
/*     */   private String createOnMissingBeanNoMatchReason(MatchResult matchResult) {
/* 306 */     StringBuilder reason = new StringBuilder();
/* 307 */     appendMessageForMatches(reason, matchResult.getMatchedAnnotations(), "annotated with");
/* 308 */     appendMessageForMatches(reason, matchResult.getMatchedTypes(), "of type");
/* 309 */     if (!matchResult.getMatchedNames().isEmpty()) {
/* 310 */       if (reason.length() > 0) {
/* 311 */         reason.append(" and ");
/*     */       }
/* 313 */       reason.append("found beans named ");
/* 314 */       reason.append(StringUtils.collectionToDelimitedString(matchResult.getMatchedNames(), ", "));
/*     */     } 
/* 316 */     return reason.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendMessageForMatches(StringBuilder reason, Map<String, Collection<String>> matches, String description) {
/* 321 */     if (!matches.isEmpty()) {
/* 322 */       matches.forEach((key, value) -> {
/*     */             if (reason.length() > 0) {
/*     */               reason.append(" and ");
/*     */             }
/*     */             reason.append("found beans ");
/*     */             reason.append(description);
/*     */             reason.append(" '");
/*     */             reason.append(key);
/*     */             reason.append("' ");
/*     */             reason.append(StringUtils.collectionToDelimitedString(value, ", "));
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasSingleAutowireCandidate(ConfigurableListableBeanFactory beanFactory, Set<String> beanNames, boolean considerHierarchy) {
/* 338 */     return (beanNames.size() == 1 || getPrimaryBeans(beanFactory, beanNames, considerHierarchy).size() == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<String> getPrimaryBeans(ConfigurableListableBeanFactory beanFactory, Set<String> beanNames, boolean considerHierarchy) {
/* 343 */     List<String> primaryBeans = new ArrayList<>();
/* 344 */     for (String beanName : beanNames) {
/* 345 */       BeanDefinition beanDefinition = findBeanDefinition(beanFactory, beanName, considerHierarchy);
/* 346 */       if (beanDefinition != null && beanDefinition.isPrimary()) {
/* 347 */         primaryBeans.add(beanName);
/*     */       }
/*     */     } 
/* 350 */     return primaryBeans;
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanDefinition findBeanDefinition(ConfigurableListableBeanFactory beanFactory, String beanName, boolean considerHierarchy) {
/* 355 */     if (beanFactory.containsBeanDefinition(beanName)) {
/* 356 */       return beanFactory.getBeanDefinition(beanName);
/*     */     }
/* 358 */     if (considerHierarchy && beanFactory.getParentBeanFactory() instanceof ConfigurableListableBeanFactory) {
/* 359 */       return findBeanDefinition((ConfigurableListableBeanFactory)beanFactory.getParentBeanFactory(), beanName, considerHierarchy);
/*     */     }
/*     */     
/* 362 */     return null;
/*     */   }
/*     */   
/*     */   private static Set<String> addAll(Set<String> result, Collection<String> additional) {
/* 366 */     if (CollectionUtils.isEmpty(additional)) {
/* 367 */       return result;
/*     */     }
/* 369 */     result = (result != null) ? result : new LinkedHashSet<>();
/* 370 */     result.addAll(additional);
/* 371 */     return result;
/*     */   }
/*     */   
/*     */   private static Set<String> addAll(Set<String> result, String[] additional) {
/* 375 */     if (ObjectUtils.isEmpty((Object[])additional)) {
/* 376 */       return result;
/*     */     }
/* 378 */     result = (result != null) ? result : new LinkedHashSet<>();
/* 379 */     Collections.addAll(result, additional);
/* 380 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Spec<A extends Annotation>
/*     */   {
/*     */     private final ClassLoader classLoader;
/*     */ 
/*     */     
/*     */     private final Class<?> annotationType;
/*     */ 
/*     */     
/*     */     private final Set<String> names;
/*     */ 
/*     */     
/*     */     private final Set<String> types;
/*     */     
/*     */     private final Set<String> annotations;
/*     */     
/*     */     private final Set<String> ignoredTypes;
/*     */     
/*     */     private final Set<Class<?>> parameterizedContainers;
/*     */     
/*     */     private final SearchStrategy strategy;
/*     */ 
/*     */     
/*     */     Spec(ConditionContext context, AnnotatedTypeMetadata metadata, MergedAnnotations annotations, Class<A> annotationType) {
/* 408 */       MultiValueMap<String, Object> attributes = (MultiValueMap<String, Object>)annotations.stream(annotationType).filter(MergedAnnotationPredicates.unique(MergedAnnotation::getMetaTypes)).collect(MergedAnnotationCollectors.toMultiValueMap(new MergedAnnotation.Adapt[] { MergedAnnotation.Adapt.CLASS_TO_STRING }));
/* 409 */       MergedAnnotation<A> annotation = annotations.get(annotationType);
/* 410 */       this.classLoader = context.getClassLoader();
/* 411 */       this.annotationType = annotationType;
/* 412 */       this.names = extract(attributes, new String[] { "name" });
/* 413 */       this.annotations = extract(attributes, new String[] { "annotation" });
/* 414 */       this.ignoredTypes = extract(attributes, new String[] { "ignored", "ignoredType" });
/* 415 */       this.parameterizedContainers = resolveWhenPossible(extract(attributes, new String[] { "parameterizedContainer" }));
/* 416 */       this.strategy = annotation.getValue("search", SearchStrategy.class).orElse(null);
/* 417 */       Set<String> types = extractTypes(attributes);
/* 418 */       OnBeanCondition.BeanTypeDeductionException deductionException = null;
/* 419 */       if (types.isEmpty() && this.names.isEmpty()) {
/*     */         try {
/* 421 */           types = deducedBeanType(context, metadata);
/*     */         }
/* 423 */         catch (BeanTypeDeductionException ex) {
/* 424 */           deductionException = ex;
/*     */         } 
/*     */       }
/* 427 */       this.types = types;
/* 428 */       validate(deductionException);
/*     */     }
/*     */     
/*     */     protected Set<String> extractTypes(MultiValueMap<String, Object> attributes) {
/* 432 */       return extract(attributes, new String[] { "value", "type" });
/*     */     }
/*     */     
/*     */     private Set<String> extract(MultiValueMap<String, Object> attributes, String... attributeNames) {
/* 436 */       if (attributes.isEmpty()) {
/* 437 */         return Collections.emptySet();
/*     */       }
/* 439 */       Set<String> result = new LinkedHashSet<>();
/* 440 */       for (String attributeName : attributeNames) {
/* 441 */         List<Object> values = (List<Object>)attributes.getOrDefault(attributeName, Collections.emptyList());
/* 442 */         for (Object value : values) {
/* 443 */           if (value instanceof String[]) {
/* 444 */             merge(result, (String[])value); continue;
/*     */           } 
/* 446 */           if (value instanceof String) {
/* 447 */             merge(result, new String[] { (String)value });
/*     */           }
/*     */         } 
/*     */       } 
/* 451 */       return result.isEmpty() ? Collections.<String>emptySet() : result;
/*     */     }
/*     */     
/*     */     private void merge(Set<String> result, String... additional) {
/* 455 */       Collections.addAll(result, additional);
/*     */     }
/*     */     
/*     */     private Set<Class<?>> resolveWhenPossible(Set<String> classNames) {
/* 459 */       if (classNames.isEmpty()) {
/* 460 */         return Collections.emptySet();
/*     */       }
/* 462 */       Set<Class<?>> resolved = new LinkedHashSet<>(classNames.size());
/* 463 */       for (String className : classNames) {
/*     */         try {
/* 465 */           resolved.add(FilteringSpringBootCondition.resolve(className, this.classLoader));
/*     */         }
/* 467 */         catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {}
/*     */       } 
/*     */       
/* 470 */       return resolved;
/*     */     }
/*     */     
/*     */     protected void validate(OnBeanCondition.BeanTypeDeductionException ex) {
/* 474 */       if (!hasAtLeastOneElement((Set<?>[])new Set[] { this.types, this.names, this.annotations })) {
/* 475 */         String message = getAnnotationName() + " did not specify a bean using type, name or annotation";
/* 476 */         if (ex == null) {
/* 477 */           throw new IllegalStateException(message);
/*     */         }
/* 479 */         throw new IllegalStateException(message + " and the attempt to deduce the bean's type failed", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean hasAtLeastOneElement(Set<?>... sets) {
/* 484 */       for (Set<?> set : sets) {
/* 485 */         if (!set.isEmpty()) {
/* 486 */           return true;
/*     */         }
/*     */       } 
/* 489 */       return false;
/*     */     }
/*     */     
/*     */     protected final String getAnnotationName() {
/* 493 */       return "@" + ClassUtils.getShortName(this.annotationType);
/*     */     }
/*     */     
/*     */     private Set<String> deducedBeanType(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 497 */       if (metadata instanceof MethodMetadata && metadata.isAnnotated(Bean.class.getName())) {
/* 498 */         return deducedBeanTypeForBeanMethod(context, (MethodMetadata)metadata);
/*     */       }
/* 500 */       return Collections.emptySet();
/*     */     }
/*     */     
/*     */     private Set<String> deducedBeanTypeForBeanMethod(ConditionContext context, MethodMetadata metadata) {
/*     */       try {
/* 505 */         Class<?> returnType = getReturnType(context, metadata);
/* 506 */         return Collections.singleton(returnType.getName());
/*     */       }
/* 508 */       catch (Throwable ex) {
/* 509 */         throw new OnBeanCondition.BeanTypeDeductionException(metadata.getDeclaringClassName(), metadata.getMethodName(), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Class<?> getReturnType(ConditionContext context, MethodMetadata metadata) throws ClassNotFoundException, LinkageError {
/* 516 */       ClassLoader classLoader = context.getClassLoader();
/* 517 */       Class<?> returnType = FilteringSpringBootCondition.resolve(metadata.getReturnTypeName(), classLoader);
/* 518 */       if (isParameterizedContainer(returnType)) {
/* 519 */         returnType = getReturnTypeGeneric(metadata, classLoader);
/*     */       }
/* 521 */       return returnType;
/*     */     }
/*     */     
/*     */     private boolean isParameterizedContainer(Class<?> type) {
/* 525 */       for (Class<?> parameterizedContainer : this.parameterizedContainers) {
/* 526 */         if (parameterizedContainer.isAssignableFrom(type)) {
/* 527 */           return true;
/*     */         }
/*     */       } 
/* 530 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     private Class<?> getReturnTypeGeneric(MethodMetadata metadata, ClassLoader classLoader) throws ClassNotFoundException, LinkageError {
/* 535 */       Class<?> declaringClass = FilteringSpringBootCondition.resolve(metadata.getDeclaringClassName(), classLoader);
/* 536 */       Method beanMethod = findBeanMethod(declaringClass, metadata.getMethodName());
/* 537 */       return ResolvableType.forMethodReturnType(beanMethod).resolveGeneric(new int[0]);
/*     */     }
/*     */     
/*     */     private Method findBeanMethod(Class<?> declaringClass, String methodName) {
/* 541 */       Method method = ReflectionUtils.findMethod(declaringClass, methodName);
/* 542 */       if (isBeanMethod(method)) {
/* 543 */         return method;
/*     */       }
/* 545 */       Method[] candidates = ReflectionUtils.getAllDeclaredMethods(declaringClass);
/* 546 */       for (Method candidate : candidates) {
/* 547 */         if (candidate.getName().equals(methodName) && isBeanMethod(candidate)) {
/* 548 */           return candidate;
/*     */         }
/*     */       } 
/* 551 */       throw new IllegalStateException("Unable to find bean method " + methodName);
/*     */     }
/*     */     
/*     */     private boolean isBeanMethod(Method method) {
/* 555 */       return (method != null && MergedAnnotations.from(method, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/* 556 */         .isPresent(Bean.class));
/*     */     }
/*     */     
/*     */     private SearchStrategy getStrategy() {
/* 560 */       return (this.strategy != null) ? this.strategy : SearchStrategy.ALL;
/*     */     }
/*     */     
/*     */     Set<String> getNames() {
/* 564 */       return this.names;
/*     */     }
/*     */     
/*     */     Set<String> getTypes() {
/* 568 */       return this.types;
/*     */     }
/*     */     
/*     */     Set<String> getAnnotations() {
/* 572 */       return this.annotations;
/*     */     }
/*     */     
/*     */     Set<String> getIgnoredTypes() {
/* 576 */       return this.ignoredTypes;
/*     */     }
/*     */     
/*     */     Set<Class<?>> getParameterizedContainers() {
/* 580 */       return this.parameterizedContainers;
/*     */     }
/*     */     
/*     */     ConditionMessage.Builder message() {
/* 584 */       return ConditionMessage.forCondition((Class)ConditionalOnBean.class, new Object[] { this });
/*     */     }
/*     */     
/*     */     ConditionMessage.Builder message(ConditionMessage message) {
/* 588 */       return message.andCondition((Class)ConditionalOnBean.class, new Object[] { this });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 593 */       boolean hasNames = !this.names.isEmpty();
/* 594 */       boolean hasTypes = !this.types.isEmpty();
/* 595 */       boolean hasIgnoredTypes = !this.ignoredTypes.isEmpty();
/* 596 */       StringBuilder string = new StringBuilder();
/* 597 */       string.append("(");
/* 598 */       if (hasNames) {
/* 599 */         string.append("names: ");
/* 600 */         string.append(StringUtils.collectionToCommaDelimitedString(this.names));
/* 601 */         string.append(hasTypes ? " " : "; ");
/*     */       } 
/* 603 */       if (hasTypes) {
/* 604 */         string.append("types: ");
/* 605 */         string.append(StringUtils.collectionToCommaDelimitedString(this.types));
/* 606 */         string.append(hasIgnoredTypes ? " " : "; ");
/*     */       } 
/* 608 */       if (hasIgnoredTypes) {
/* 609 */         string.append("ignored: ");
/* 610 */         string.append(StringUtils.collectionToCommaDelimitedString(this.ignoredTypes));
/* 611 */         string.append("; ");
/*     */       } 
/* 613 */       string.append("SearchStrategy: ");
/* 614 */       string.append(this.strategy.toString().toLowerCase(Locale.ENGLISH));
/* 615 */       string.append(")");
/* 616 */       return string.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SingleCandidateSpec
/*     */     extends Spec<ConditionalOnSingleCandidate>
/*     */   {
/* 627 */     private static final Collection<String> FILTERED_TYPES = Arrays.asList(new String[] { "", Object.class.getName() });
/*     */     
/*     */     SingleCandidateSpec(ConditionContext context, AnnotatedTypeMetadata metadata, MergedAnnotations annotations) {
/* 630 */       super(context, metadata, annotations, ConditionalOnSingleCandidate.class);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Set<String> extractTypes(MultiValueMap<String, Object> attributes) {
/* 635 */       Set<String> types = super.extractTypes(attributes);
/* 636 */       types.removeAll(FILTERED_TYPES);
/* 637 */       return types;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void validate(OnBeanCondition.BeanTypeDeductionException ex) {
/* 642 */       Assert.isTrue((getTypes().size() == 1), () -> getAnnotationName() + " annotations must specify only one type (got " + StringUtils.collectionToCommaDelimitedString(getTypes()) + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MatchResult
/*     */   {
/* 654 */     private final Map<String, Collection<String>> matchedAnnotations = new HashMap<>();
/*     */     
/* 656 */     private final List<String> matchedNames = new ArrayList<>();
/*     */     
/* 658 */     private final Map<String, Collection<String>> matchedTypes = new HashMap<>();
/*     */     
/* 660 */     private final List<String> unmatchedAnnotations = new ArrayList<>();
/*     */     
/* 662 */     private final List<String> unmatchedNames = new ArrayList<>();
/*     */     
/* 664 */     private final List<String> unmatchedTypes = new ArrayList<>();
/*     */     
/* 666 */     private final Set<String> namesOfAllMatches = new HashSet<>();
/*     */     
/*     */     private void recordMatchedName(String name) {
/* 669 */       this.matchedNames.add(name);
/* 670 */       this.namesOfAllMatches.add(name);
/*     */     }
/*     */     
/*     */     private void recordUnmatchedName(String name) {
/* 674 */       this.unmatchedNames.add(name);
/*     */     }
/*     */     
/*     */     private void recordMatchedAnnotation(String annotation, Collection<String> matchingNames) {
/* 678 */       this.matchedAnnotations.put(annotation, matchingNames);
/* 679 */       this.namesOfAllMatches.addAll(matchingNames);
/*     */     }
/*     */     
/*     */     private void recordUnmatchedAnnotation(String annotation) {
/* 683 */       this.unmatchedAnnotations.add(annotation);
/*     */     }
/*     */     
/*     */     private void recordMatchedType(String type, Collection<String> matchingNames) {
/* 687 */       this.matchedTypes.put(type, matchingNames);
/* 688 */       this.namesOfAllMatches.addAll(matchingNames);
/*     */     }
/*     */     
/*     */     private void recordUnmatchedType(String type) {
/* 692 */       this.unmatchedTypes.add(type);
/*     */     }
/*     */     
/*     */     boolean isAllMatched() {
/* 696 */       return (this.unmatchedAnnotations.isEmpty() && this.unmatchedNames.isEmpty() && this.unmatchedTypes
/* 697 */         .isEmpty());
/*     */     }
/*     */     
/*     */     boolean isAnyMatched() {
/* 701 */       return (!this.matchedAnnotations.isEmpty() || !this.matchedNames.isEmpty() || 
/* 702 */         !this.matchedTypes.isEmpty());
/*     */     }
/*     */     
/*     */     Map<String, Collection<String>> getMatchedAnnotations() {
/* 706 */       return this.matchedAnnotations;
/*     */     }
/*     */     
/*     */     List<String> getMatchedNames() {
/* 710 */       return this.matchedNames;
/*     */     }
/*     */     
/*     */     Map<String, Collection<String>> getMatchedTypes() {
/* 714 */       return this.matchedTypes;
/*     */     }
/*     */     
/*     */     List<String> getUnmatchedAnnotations() {
/* 718 */       return this.unmatchedAnnotations;
/*     */     }
/*     */     
/*     */     List<String> getUnmatchedNames() {
/* 722 */       return this.unmatchedNames;
/*     */     }
/*     */     
/*     */     List<String> getUnmatchedTypes() {
/* 726 */       return this.unmatchedTypes;
/*     */     }
/*     */     
/*     */     Set<String> getNamesOfAllMatches() {
/* 730 */       return this.namesOfAllMatches;
/*     */     }
/*     */ 
/*     */     
/*     */     private MatchResult() {}
/*     */   }
/*     */   
/*     */   static final class BeanTypeDeductionException
/*     */     extends RuntimeException
/*     */   {
/*     */     private BeanTypeDeductionException(String className, String beanMethodName, Throwable cause) {
/* 741 */       super("Failed to deduce bean type for " + className + "." + beanMethodName, cause);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\OnBeanCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionOutcome
/*     */ {
/*     */   private final boolean match;
/*     */   private final ConditionMessage message;
/*     */   
/*     */   public ConditionOutcome(boolean match, String message) {
/*  42 */     this(match, ConditionMessage.of(message, new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionOutcome(boolean match, ConditionMessage message) {
/*  51 */     Assert.notNull(message, "ConditionMessage must not be null");
/*  52 */     this.match = match;
/*  53 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionOutcome match() {
/*  61 */     return match(ConditionMessage.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionOutcome match(String message) {
/*  71 */     return new ConditionOutcome(true, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionOutcome match(ConditionMessage message) {
/*  80 */     return new ConditionOutcome(true, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionOutcome noMatch(String message) {
/*  90 */     return new ConditionOutcome(false, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionOutcome noMatch(ConditionMessage message) {
/*  99 */     return new ConditionOutcome(false, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMatch() {
/* 107 */     return this.match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 115 */     return this.message.isEmpty() ? null : this.message.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionMessage getConditionMessage() {
/* 123 */     return this.message;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 128 */     if (this == obj) {
/* 129 */       return true;
/*     */     }
/* 131 */     if (obj == null) {
/* 132 */       return false;
/*     */     }
/* 134 */     if (getClass() == obj.getClass()) {
/* 135 */       ConditionOutcome other = (ConditionOutcome)obj;
/* 136 */       return (this.match == other.match && ObjectUtils.nullSafeEquals(this.message, other.message));
/*     */     } 
/* 138 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 143 */     return Boolean.hashCode(this.match) * 31 + ObjectUtils.nullSafeHashCode(this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return (this.message != null) ? this.message.toString() : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionOutcome inverse(ConditionOutcome outcome) {
/* 158 */     return new ConditionOutcome(!outcome.isMatch(), outcome.getConditionMessage());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\ConditionOutcome.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
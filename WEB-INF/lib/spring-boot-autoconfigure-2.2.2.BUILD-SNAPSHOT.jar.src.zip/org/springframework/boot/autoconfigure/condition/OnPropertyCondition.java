/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483608)
/*     */ class OnPropertyCondition
/*     */   extends SpringBootCondition
/*     */ {
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  50 */     List<AnnotationAttributes> allAnnotationAttributes = annotationAttributesFromMultiValueMap(metadata
/*  51 */         .getAllAnnotationAttributes(ConditionalOnProperty.class.getName()));
/*  52 */     List<ConditionMessage> noMatch = new ArrayList<>();
/*  53 */     List<ConditionMessage> match = new ArrayList<>();
/*  54 */     for (AnnotationAttributes annotationAttributes : allAnnotationAttributes) {
/*  55 */       ConditionOutcome outcome = determineOutcome(annotationAttributes, (PropertyResolver)context.getEnvironment());
/*  56 */       (outcome.isMatch() ? match : noMatch).add(outcome.getConditionMessage());
/*     */     } 
/*  58 */     if (!noMatch.isEmpty()) {
/*  59 */       return ConditionOutcome.noMatch(ConditionMessage.of(noMatch));
/*     */     }
/*  61 */     return ConditionOutcome.match(ConditionMessage.of(match));
/*     */   }
/*     */ 
/*     */   
/*     */   private List<AnnotationAttributes> annotationAttributesFromMultiValueMap(MultiValueMap<String, Object> multiValueMap) {
/*  66 */     List<Map<String, Object>> maps = new ArrayList<>();
/*  67 */     multiValueMap.forEach((key, value) -> {
/*     */           for (int i = 0; i < value.size(); i++) {
/*     */             Map<String, Object> map;
/*     */             
/*     */             if (i < maps.size()) {
/*     */               map = maps.get(i);
/*     */             } else {
/*     */               map = new HashMap<>();
/*     */               maps.add(map);
/*     */             } 
/*     */             map.put(key, value.get(i));
/*     */           } 
/*     */         });
/*  80 */     List<AnnotationAttributes> annotationAttributes = new ArrayList<>(maps.size());
/*  81 */     for (Map<String, Object> map : maps) {
/*  82 */       annotationAttributes.add(AnnotationAttributes.fromMap(map));
/*     */     }
/*  84 */     return annotationAttributes;
/*     */   }
/*     */   
/*     */   private ConditionOutcome determineOutcome(AnnotationAttributes annotationAttributes, PropertyResolver resolver) {
/*  88 */     Spec spec = new Spec(annotationAttributes);
/*  89 */     List<String> missingProperties = new ArrayList<>();
/*  90 */     List<String> nonMatchingProperties = new ArrayList<>();
/*  91 */     spec.collectProperties(resolver, missingProperties, nonMatchingProperties);
/*  92 */     if (!missingProperties.isEmpty()) {
/*  93 */       return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnProperty.class, new Object[] { spec
/*  94 */             }).didNotFind("property", "properties").items(ConditionMessage.Style.QUOTE, missingProperties));
/*     */     }
/*  96 */     if (!nonMatchingProperties.isEmpty()) {
/*  97 */       return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnProperty.class, new Object[] { spec
/*  98 */             }).found("different value in property", "different value in properties")
/*  99 */           .items(ConditionMessage.Style.QUOTE, nonMatchingProperties));
/*     */     }
/* 101 */     return 
/* 102 */       ConditionOutcome.match(ConditionMessage.forCondition((Class)ConditionalOnProperty.class, new Object[] { spec }).because("matched"));
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Spec
/*     */   {
/*     */     private final String prefix;
/*     */     
/*     */     private final String havingValue;
/*     */     
/*     */     private final String[] names;
/*     */     private final boolean matchIfMissing;
/*     */     
/*     */     Spec(AnnotationAttributes annotationAttributes) {
/* 116 */       String prefix = annotationAttributes.getString("prefix").trim();
/* 117 */       if (StringUtils.hasText(prefix) && !prefix.endsWith(".")) {
/* 118 */         prefix = prefix + ".";
/*     */       }
/* 120 */       this.prefix = prefix;
/* 121 */       this.havingValue = annotationAttributes.getString("havingValue");
/* 122 */       this.names = getNames((Map<String, Object>)annotationAttributes);
/* 123 */       this.matchIfMissing = annotationAttributes.getBoolean("matchIfMissing");
/*     */     }
/*     */     
/*     */     private String[] getNames(Map<String, Object> annotationAttributes) {
/* 127 */       String[] value = (String[])annotationAttributes.get("value");
/* 128 */       String[] name = (String[])annotationAttributes.get("name");
/* 129 */       Assert.state((value.length > 0 || name.length > 0), "The name or value attribute of @ConditionalOnProperty must be specified");
/*     */       
/* 131 */       Assert.state((value.length == 0 || name.length == 0), "The name and value attributes of @ConditionalOnProperty are exclusive");
/*     */       
/* 133 */       return (value.length > 0) ? value : name;
/*     */     }
/*     */     
/*     */     private void collectProperties(PropertyResolver resolver, List<String> missing, List<String> nonMatching) {
/* 137 */       for (String name : this.names) {
/* 138 */         String key = this.prefix + name;
/* 139 */         if (resolver.containsProperty(key)) {
/* 140 */           if (!isMatch(resolver.getProperty(key), this.havingValue)) {
/* 141 */             nonMatching.add(name);
/*     */           
/*     */           }
/*     */         }
/* 145 */         else if (!this.matchIfMissing) {
/* 146 */           missing.add(name);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isMatch(String value, String requiredValue) {
/* 153 */       if (StringUtils.hasLength(requiredValue)) {
/* 154 */         return requiredValue.equalsIgnoreCase(value);
/*     */       }
/* 156 */       return !"false".equalsIgnoreCase(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 161 */       StringBuilder result = new StringBuilder();
/* 162 */       result.append("(");
/* 163 */       result.append(this.prefix);
/* 164 */       if (this.names.length == 1) {
/* 165 */         result.append(this.names[0]);
/*     */       } else {
/*     */         
/* 168 */         result.append("[");
/* 169 */         result.append(StringUtils.arrayToCommaDelimitedString((Object[])this.names));
/* 170 */         result.append("]");
/*     */       } 
/* 172 */       if (StringUtils.hasLength(this.havingValue)) {
/* 173 */         result.append("=").append(this.havingValue);
/*     */       }
/* 175 */       result.append(")");
/* 176 */       return result.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\OnPropertyCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
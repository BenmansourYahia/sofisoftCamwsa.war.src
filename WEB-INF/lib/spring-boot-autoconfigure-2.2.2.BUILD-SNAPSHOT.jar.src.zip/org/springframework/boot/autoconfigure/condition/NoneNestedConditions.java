/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NoneNestedConditions
/*    */   extends AbstractNestedCondition
/*    */ {
/*    */   public NoneNestedConditions(ConfigurationCondition.ConfigurationPhase configurationPhase) {
/* 58 */     super(configurationPhase);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ConditionOutcome getFinalMatchOutcome(AbstractNestedCondition.MemberMatchOutcomes memberOutcomes) {
/* 63 */     boolean match = memberOutcomes.getMatches().isEmpty();
/* 64 */     List<ConditionMessage> messages = new ArrayList<>();
/* 65 */     messages.add(ConditionMessage.forCondition("NoneNestedConditions", new Object[0]).because(memberOutcomes
/* 66 */           .getMatches().size() + " matched " + memberOutcomes.getNonMatches().size() + " did not"));
/* 67 */     for (ConditionOutcome outcome : memberOutcomes.getAll()) {
/* 68 */       messages.add(outcome.getConditionMessage());
/*    */     }
/* 70 */     return new ConditionOutcome(match, ConditionMessage.of(messages));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\condition\NoneNestedConditions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
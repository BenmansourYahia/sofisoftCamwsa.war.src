/*     */ package org.springframework.boot.autoconfigure.info;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Properties;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnResource;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.info.BuildProperties;
/*     */ import org.springframework.boot.info.GitProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({ProjectInfoProperties.class})
/*     */ public class ProjectInfoAutoConfiguration
/*     */ {
/*     */   private final ProjectInfoProperties properties;
/*     */   
/*     */   public ProjectInfoAutoConfiguration(ProjectInfoProperties properties) {
/*  57 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Conditional({GitResourceAvailableCondition.class})
/*     */   @ConditionalOnMissingBean
/*     */   @Bean
/*     */   public GitProperties gitProperties() throws Exception {
/*  64 */     return new GitProperties(
/*  65 */         loadFrom(this.properties.getGit().getLocation(), "git", this.properties.getGit().getEncoding()));
/*     */   }
/*     */   
/*     */   @ConditionalOnResource(resources = {"${spring.info.build.location:classpath:META-INF/build-info.properties}"})
/*     */   @ConditionalOnMissingBean
/*     */   @Bean
/*     */   public BuildProperties buildProperties() throws Exception {
/*  72 */     return new BuildProperties(
/*  73 */         loadFrom(this.properties.getBuild().getLocation(), "build", this.properties.getBuild().getEncoding()));
/*     */   }
/*     */   
/*     */   protected Properties loadFrom(Resource location, String prefix, Charset encoding) throws IOException {
/*  77 */     prefix = prefix.endsWith(".") ? prefix : (prefix + ".");
/*  78 */     Properties source = loadSource(location, encoding);
/*  79 */     Properties target = new Properties();
/*  80 */     for (String key : source.stringPropertyNames()) {
/*  81 */       if (key.startsWith(prefix)) {
/*  82 */         target.put(key.substring(prefix.length()), source.get(key));
/*     */       }
/*     */     } 
/*  85 */     return target;
/*     */   }
/*     */   
/*     */   private Properties loadSource(Resource location, Charset encoding) throws IOException {
/*  89 */     if (encoding != null) {
/*  90 */       return PropertiesLoaderUtils.loadProperties(new EncodedResource(location, encoding));
/*     */     }
/*  92 */     return PropertiesLoaderUtils.loadProperties(location);
/*     */   }
/*     */   
/*     */   static class GitResourceAvailableCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  99 */       ResourceLoader loader = context.getResourceLoader();
/* 100 */       Environment environment = context.getEnvironment();
/* 101 */       String location = environment.getProperty("spring.info.git.location");
/* 102 */       if (location == null) {
/* 103 */         location = "classpath:git.properties";
/*     */       }
/* 105 */       ConditionMessage.Builder message = ConditionMessage.forCondition("GitResource", new Object[0]);
/* 106 */       if (loader.getResource(location).exists()) {
/* 107 */         return ConditionOutcome.match(message.found("git info at").items(new Object[] { location }));
/*     */       }
/* 109 */       return ConditionOutcome.noMatch(message.didNotFind("git info at").items(new Object[] { location }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\info\ProjectInfoAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
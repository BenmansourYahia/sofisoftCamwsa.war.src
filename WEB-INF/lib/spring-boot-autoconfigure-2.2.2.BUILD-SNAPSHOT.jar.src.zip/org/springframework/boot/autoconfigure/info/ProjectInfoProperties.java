/*     */ package org.springframework.boot.autoconfigure.info;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.info")
/*     */ public class ProjectInfoProperties
/*     */ {
/*  35 */   private final Build build = new Build();
/*     */   
/*  37 */   private final Git git = new Git();
/*     */   
/*     */   public Build getBuild() {
/*  40 */     return this.build;
/*     */   }
/*     */   
/*     */   public Git getGit() {
/*  44 */     return this.git;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Build
/*     */   {
/*  55 */     private Resource location = (Resource)new ClassPathResource("META-INF/build-info.properties");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     private Charset encoding = StandardCharsets.UTF_8;
/*     */     
/*     */     public Resource getLocation() {
/*  63 */       return this.location;
/*     */     }
/*     */     
/*     */     public void setLocation(Resource location) {
/*  67 */       this.location = location;
/*     */     }
/*     */     
/*     */     public Charset getEncoding() {
/*  71 */       return this.encoding;
/*     */     }
/*     */     
/*     */     public void setEncoding(Charset encoding) {
/*  75 */       this.encoding = encoding;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Git
/*     */   {
/*  88 */     private Resource location = (Resource)new ClassPathResource("git.properties");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     private Charset encoding = StandardCharsets.UTF_8;
/*     */     
/*     */     public Resource getLocation() {
/*  96 */       return this.location;
/*     */     }
/*     */     
/*     */     public void setLocation(Resource location) {
/* 100 */       this.location = location;
/*     */     }
/*     */     
/*     */     public Charset getEncoding() {
/* 104 */       return this.encoding;
/*     */     }
/*     */     
/*     */     public void setEncoding(Charset encoding) {
/* 108 */       this.encoding = encoding;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\info\ProjectInfoProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
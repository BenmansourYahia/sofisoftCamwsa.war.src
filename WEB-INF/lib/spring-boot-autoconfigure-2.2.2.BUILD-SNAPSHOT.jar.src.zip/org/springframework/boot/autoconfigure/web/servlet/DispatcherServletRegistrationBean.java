/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import javax.servlet.Servlet;
/*    */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.DispatcherServlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DispatcherServletRegistrationBean
/*    */   extends ServletRegistrationBean<DispatcherServlet>
/*    */   implements DispatcherServletPath
/*    */ {
/*    */   private final String path;
/*    */   
/*    */   public DispatcherServletRegistrationBean(DispatcherServlet servlet, String path) {
/* 44 */     super((Servlet)servlet, new String[0]);
/* 45 */     Assert.notNull(path, "Path must not be null");
/* 46 */     this.path = path;
/* 47 */     super.addUrlMappings(new String[] { getServletUrlMapping() });
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPath() {
/* 52 */     return this.path;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUrlMappings(Collection<String> urlMappings) {
/* 57 */     throw new UnsupportedOperationException("URL Mapping cannot be changed on a DispatcherServlet registration");
/*    */   }
/*    */ 
/*    */   
/*    */   public void addUrlMappings(String... urlMappings) {
/* 62 */     throw new UnsupportedOperationException("URL Mapping cannot be changed on a DispatcherServlet registration");
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\DispatcherServletRegistrationBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
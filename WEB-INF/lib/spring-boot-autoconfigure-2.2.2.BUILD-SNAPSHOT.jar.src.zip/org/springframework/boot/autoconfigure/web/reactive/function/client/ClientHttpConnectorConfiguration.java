/*    */ package org.springframework.boot.autoconfigure.web.reactive.function.client;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.eclipse.jetty.client.HttpClient;
/*    */ import org.eclipse.jetty.reactive.client.ReactiveRequest;
/*    */ import org.eclipse.jetty.util.ssl.SslContextFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.http.client.reactive.ClientHttpConnector;
/*    */ import org.springframework.http.client.reactive.JettyClientHttpConnector;
/*    */ import org.springframework.http.client.reactive.JettyResourceFactory;
/*    */ import org.springframework.http.client.reactive.ReactorClientHttpConnector;
/*    */ import org.springframework.http.client.reactive.ReactorResourceFactory;
/*    */ import reactor.netty.http.client.HttpClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class ClientHttpConnectorConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({HttpClient.class})
/*    */   @ConditionalOnMissingBean({ClientHttpConnector.class})
/*    */   public static class ReactorNetty
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     public ReactorResourceFactory reactorClientResourceFactory() {
/* 53 */       return new ReactorResourceFactory();
/*    */     }
/*    */     
/*    */     @Bean
/*    */     public ReactorClientHttpConnector reactorClientHttpConnector(ReactorResourceFactory reactorResourceFactory) {
/* 58 */       return new ReactorClientHttpConnector(reactorResourceFactory, Function.identity());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({ReactiveRequest.class})
/*    */   @ConditionalOnMissingBean({ClientHttpConnector.class})
/*    */   public static class JettyClient
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     public JettyResourceFactory jettyClientResourceFactory() {
/* 71 */       return new JettyResourceFactory();
/*    */     }
/*    */     
/*    */     @Bean
/*    */     public JettyClientHttpConnector jettyClientHttpConnector(JettyResourceFactory jettyResourceFactory) {
/* 76 */       SslContextFactory.Client client = new SslContextFactory.Client();
/* 77 */       HttpClient httpClient = new HttpClient((SslContextFactory)client);
/* 78 */       return new JettyClientHttpConnector(httpClient, jettyResourceFactory);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\function\client\ClientHttpConnectorConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
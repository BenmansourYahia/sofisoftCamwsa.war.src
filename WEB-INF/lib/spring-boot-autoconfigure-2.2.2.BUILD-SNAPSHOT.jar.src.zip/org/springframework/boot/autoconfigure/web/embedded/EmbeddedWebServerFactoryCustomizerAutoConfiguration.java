/*     */ package org.springframework.boot.autoconfigure.web.embedded;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.apache.coyote.UpgradeProtocol;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.util.Loader;
/*     */ import org.eclipse.jetty.webapp.WebAppContext;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.xnio.SslClientAuthMode;
/*     */ import reactor.netty.http.server.HttpServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnWebApplication
/*     */ @EnableConfigurationProperties({ServerProperties.class})
/*     */ public class EmbeddedWebServerFactoryCustomizerAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Tomcat.class, UpgradeProtocol.class})
/*     */   public static class TomcatWebServerFactoryCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     public TomcatWebServerFactoryCustomizer tomcatWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/*  59 */       return new TomcatWebServerFactoryCustomizer(environment, serverProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Server.class, Loader.class, WebAppContext.class})
/*     */   public static class JettyWebServerFactoryCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     public JettyWebServerFactoryCustomizer jettyWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/*  74 */       return new JettyWebServerFactoryCustomizer(environment, serverProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Undertow.class, SslClientAuthMode.class})
/*     */   public static class UndertowWebServerFactoryCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     public UndertowWebServerFactoryCustomizer undertowWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/*  89 */       return new UndertowWebServerFactoryCustomizer(environment, serverProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({HttpServer.class})
/*     */   public static class NettyWebServerFactoryCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     public NettyWebServerFactoryCustomizer nettyWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/* 104 */       return new NettyWebServerFactoryCustomizer(environment, serverProperties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\embedded\EmbeddedWebServerFactoryCustomizerAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
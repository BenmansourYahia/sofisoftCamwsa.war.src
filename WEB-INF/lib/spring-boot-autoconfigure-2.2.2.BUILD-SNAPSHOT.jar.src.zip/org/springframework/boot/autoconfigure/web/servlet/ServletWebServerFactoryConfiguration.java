/*     */ package org.springframework.boot.autoconfigure.web.servlet;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import java.util.Collection;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.apache.coyote.UpgradeProtocol;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.util.Loader;
/*     */ import org.eclipse.jetty.webapp.WebAppContext;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.web.embedded.jetty.JettyServerCustomizer;
/*     */ import org.springframework.boot.web.embedded.jetty.JettyServletWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatContextCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatProtocolHandlerCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.undertow.UndertowBuilderCustomizer;
/*     */ import org.springframework.boot.web.embedded.undertow.UndertowDeploymentInfoCustomizer;
/*     */ import org.springframework.boot.web.embedded.undertow.UndertowServletWebServerFactory;
/*     */ import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.xnio.SslClientAuthMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class ServletWebServerFactoryConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Servlet.class, Tomcat.class, UpgradeProtocol.class})
/*     */   @ConditionalOnMissingBean(value = {ServletWebServerFactory.class}, search = SearchStrategy.CURRENT)
/*     */   public static class EmbeddedTomcat
/*     */   {
/*     */     @Bean
/*     */     public TomcatServletWebServerFactory tomcatServletWebServerFactory(ObjectProvider<TomcatConnectorCustomizer> connectorCustomizers, ObjectProvider<TomcatContextCustomizer> contextCustomizers, ObjectProvider<TomcatProtocolHandlerCustomizer<?>> protocolHandlerCustomizers) {
/*  75 */       TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
/*  76 */       factory.getTomcatConnectorCustomizers()
/*  77 */         .addAll((Collection)connectorCustomizers.orderedStream().collect(Collectors.toList()));
/*  78 */       factory.getTomcatContextCustomizers()
/*  79 */         .addAll((Collection)contextCustomizers.orderedStream().collect(Collectors.toList()));
/*  80 */       factory.getTomcatProtocolHandlerCustomizers()
/*  81 */         .addAll((Collection)protocolHandlerCustomizers.orderedStream().collect(Collectors.toList()));
/*  82 */       return factory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Servlet.class, Server.class, Loader.class, WebAppContext.class})
/*     */   @ConditionalOnMissingBean(value = {ServletWebServerFactory.class}, search = SearchStrategy.CURRENT)
/*     */   public static class EmbeddedJetty
/*     */   {
/*     */     @Bean
/*     */     public JettyServletWebServerFactory JettyServletWebServerFactory(ObjectProvider<JettyServerCustomizer> serverCustomizers) {
/*  98 */       JettyServletWebServerFactory factory = new JettyServletWebServerFactory();
/*  99 */       factory.getServerCustomizers().addAll((Collection)serverCustomizers.orderedStream().collect(Collectors.toList()));
/* 100 */       return factory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Servlet.class, Undertow.class, SslClientAuthMode.class})
/*     */   @ConditionalOnMissingBean(value = {ServletWebServerFactory.class}, search = SearchStrategy.CURRENT)
/*     */   public static class EmbeddedUndertow
/*     */   {
/*     */     @Bean
/*     */     public UndertowServletWebServerFactory undertowServletWebServerFactory(ObjectProvider<UndertowDeploymentInfoCustomizer> deploymentInfoCustomizers, ObjectProvider<UndertowBuilderCustomizer> builderCustomizers) {
/* 117 */       UndertowServletWebServerFactory factory = new UndertowServletWebServerFactory();
/* 118 */       factory.getDeploymentInfoCustomizers()
/* 119 */         .addAll((Collection)deploymentInfoCustomizers.orderedStream().collect(Collectors.toList()));
/* 120 */       factory.getBuilderCustomizers().addAll((Collection)builderCustomizers.orderedStream().collect(Collectors.toList()));
/* 121 */       return factory;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\ServletWebServerFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
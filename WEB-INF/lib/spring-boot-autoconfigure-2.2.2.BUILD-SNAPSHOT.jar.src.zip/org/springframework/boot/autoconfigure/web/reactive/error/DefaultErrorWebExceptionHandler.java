/*     */ package org.springframework.boot.autoconfigure.web.reactive.error;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.boot.autoconfigure.web.ErrorProperties;
/*     */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*     */ import org.springframework.boot.web.reactive.error.ErrorAttributes;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.reactive.function.BodyInserters;
/*     */ import org.springframework.web.reactive.function.server.RequestPredicate;
/*     */ import org.springframework.web.reactive.function.server.RequestPredicates;
/*     */ import org.springframework.web.reactive.function.server.RouterFunction;
/*     */ import org.springframework.web.reactive.function.server.RouterFunctions;
/*     */ import org.springframework.web.reactive.function.server.ServerRequest;
/*     */ import org.springframework.web.reactive.function.server.ServerResponse;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultErrorWebExceptionHandler
/*     */   extends AbstractErrorWebExceptionHandler
/*     */ {
/*  78 */   private static final MediaType TEXT_HTML_UTF8 = new MediaType("text", "html", StandardCharsets.UTF_8);
/*     */   private static final Map<HttpStatus.Series, String> SERIES_VIEWS;
/*     */   private final ErrorProperties errorProperties;
/*     */   
/*     */   static {
/*  83 */     Map<HttpStatus.Series, String> views = new EnumMap<>(HttpStatus.Series.class);
/*  84 */     views.put(HttpStatus.Series.CLIENT_ERROR, "4xx");
/*  85 */     views.put(HttpStatus.Series.SERVER_ERROR, "5xx");
/*  86 */     SERIES_VIEWS = Collections.unmodifiableMap(views);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultErrorWebExceptionHandler(ErrorAttributes errorAttributes, ResourceProperties resourceProperties, ErrorProperties errorProperties, ApplicationContext applicationContext) {
/* 100 */     super(errorAttributes, resourceProperties, applicationContext);
/* 101 */     this.errorProperties = errorProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   protected RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes errorAttributes) {
/* 106 */     return RouterFunctions.route(acceptsTextHtml(), this::renderErrorView).andRoute(RequestPredicates.all(), this::renderErrorResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<ServerResponse> renderErrorView(ServerRequest request) {
/* 115 */     boolean includeStackTrace = isIncludeStackTrace(request, MediaType.TEXT_HTML);
/* 116 */     Map<String, Object> error = getErrorAttributes(request, includeStackTrace);
/* 117 */     int errorStatus = getHttpStatus(error);
/* 118 */     ServerResponse.BodyBuilder responseBody = ServerResponse.status(errorStatus).contentType(TEXT_HTML_UTF8);
/* 119 */     return Flux.just(getData(errorStatus).toArray((Object[])new String[0]))
/* 120 */       .flatMap(viewName -> renderErrorView(viewName, responseBody, error))
/* 121 */       .switchIfEmpty(this.errorProperties.getWhitelabel().isEnabled() ? (Publisher)
/* 122 */         renderDefaultErrorView(responseBody, error) : (Publisher)Mono.error(getError(request)))
/* 123 */       .next();
/*     */   }
/*     */   
/*     */   private List<String> getData(int errorStatus) {
/* 127 */     List<String> data = new ArrayList<>();
/* 128 */     data.add("error/" + errorStatus);
/* 129 */     HttpStatus.Series series = HttpStatus.Series.resolve(errorStatus);
/* 130 */     if (series != null) {
/* 131 */       data.add("error/" + (String)SERIES_VIEWS.get(series));
/*     */     }
/* 133 */     data.add("error/error");
/* 134 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<ServerResponse> renderErrorResponse(ServerRequest request) {
/* 143 */     boolean includeStackTrace = isIncludeStackTrace(request, MediaType.ALL);
/* 144 */     Map<String, Object> error = getErrorAttributes(request, includeStackTrace);
/* 145 */     return ServerResponse.status(getHttpStatus(error)).contentType(MediaType.APPLICATION_JSON)
/* 146 */       .body(BodyInserters.fromValue(error));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isIncludeStackTrace(ServerRequest request, MediaType produces) {
/* 156 */     ErrorProperties.IncludeStacktrace include = this.errorProperties.getIncludeStacktrace();
/* 157 */     if (include == ErrorProperties.IncludeStacktrace.ALWAYS) {
/* 158 */       return true;
/*     */     }
/* 160 */     if (include == ErrorProperties.IncludeStacktrace.ON_TRACE_PARAM) {
/* 161 */       return isTraceEnabled(request);
/*     */     }
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getHttpStatus(Map<String, Object> errorAttributes) {
/* 172 */     return ((Integer)errorAttributes.get("status")).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RequestPredicate acceptsTextHtml() {
/* 183 */     return serverRequest -> {
/*     */         try {
/*     */           List<MediaType> acceptedMediaTypes = serverRequest.headers().accept();
/*     */           
/*     */           acceptedMediaTypes.remove(MediaType.ALL);
/*     */           MediaType.sortBySpecificityAndQuality(acceptedMediaTypes);
/*     */           return acceptedMediaTypes.stream().anyMatch(MediaType.TEXT_HTML::isCompatibleWith);
/* 190 */         } catch (InvalidMediaTypeException ex) {
/*     */           return false;
/*     */         } 
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\error\DefaultErrorWebExceptionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
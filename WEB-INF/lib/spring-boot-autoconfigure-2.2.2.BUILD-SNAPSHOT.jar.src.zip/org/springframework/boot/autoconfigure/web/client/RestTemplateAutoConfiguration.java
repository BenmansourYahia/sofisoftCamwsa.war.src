/*    */ package org.springframework.boot.autoconfigure.web.client;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.function.BiFunction;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.NoneNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConvertersAutoConfiguration;
/*    */ import org.springframework.boot.web.client.RestTemplateBuilder;
/*    */ import org.springframework.boot.web.client.RestTemplateCustomizer;
/*    */ import org.springframework.boot.web.client.RestTemplateRequestCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.web.client.RestTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @AutoConfigureAfter({HttpMessageConvertersAutoConfiguration.class})
/*    */ @ConditionalOnClass({RestTemplate.class})
/*    */ @Conditional({RestTemplateAutoConfiguration.NotReactiveWebApplicationCondition.class})
/*    */ public class RestTemplateAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public RestTemplateBuilder restTemplateBuilder(ObjectProvider<HttpMessageConverters> messageConverters, ObjectProvider<RestTemplateCustomizer> restTemplateCustomizers, ObjectProvider<RestTemplateRequestCustomizer<?>> restTemplateRequestCustomizers) {
/* 61 */     RestTemplateBuilder builder = new RestTemplateBuilder(new RestTemplateCustomizer[0]);
/* 62 */     HttpMessageConverters converters = (HttpMessageConverters)messageConverters.getIfUnique();
/* 63 */     if (converters != null) {
/* 64 */       builder = builder.messageConverters(converters.getConverters());
/*    */     }
/* 66 */     builder = addCustomizers(builder, restTemplateCustomizers, RestTemplateBuilder::customizers);
/* 67 */     builder = addCustomizers(builder, restTemplateRequestCustomizers, RestTemplateBuilder::requestCustomizers);
/* 68 */     return builder;
/*    */   }
/*    */ 
/*    */   
/*    */   private <T> RestTemplateBuilder addCustomizers(RestTemplateBuilder builder, ObjectProvider<T> objectProvider, BiFunction<RestTemplateBuilder, Collection<T>, RestTemplateBuilder> method) {
/* 73 */     List<T> customizers = (List<T>)objectProvider.orderedStream().collect(Collectors.toList());
/* 74 */     if (!customizers.isEmpty()) {
/* 75 */       return method.apply(builder, customizers);
/*    */     }
/* 77 */     return builder;
/*    */   }
/*    */   
/*    */   static class NotReactiveWebApplicationCondition
/*    */     extends NoneNestedConditions {
/*    */     NotReactiveWebApplicationCondition() {
/* 83 */       super(ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION);
/*    */     }
/*    */     
/*    */     @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*    */     private static class ReactiveWebApplication {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\client\RestTemplateAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
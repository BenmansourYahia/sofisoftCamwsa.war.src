/*    */ package org.springframework.boot.autoconfigure.web;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnEnabledResourceChainCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private static final String WEBJAR_ASSET_LOCATOR = "org.webjars.WebJarAssetLocator";
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 43 */     ConfigurableEnvironment environment = (ConfigurableEnvironment)context.getEnvironment();
/* 44 */     boolean fixed = getEnabledProperty(environment, "strategy.fixed.", Boolean.valueOf(false)).booleanValue();
/* 45 */     boolean content = getEnabledProperty(environment, "strategy.content.", Boolean.valueOf(false)).booleanValue();
/* 46 */     Boolean chain = getEnabledProperty(environment, "", null);
/* 47 */     Boolean match = ResourceProperties.Chain.getEnabled(fixed, content, chain);
/* 48 */     ConditionMessage.Builder message = ConditionMessage.forCondition(ConditionalOnEnabledResourceChain.class, new Object[0]);
/* 49 */     if (match == null) {
/* 50 */       if (ClassUtils.isPresent("org.webjars.WebJarAssetLocator", getClass().getClassLoader())) {
/* 51 */         return ConditionOutcome.match(message.found("class").items(new Object[] { "org.webjars.WebJarAssetLocator" }));
/*    */       }
/* 53 */       return ConditionOutcome.noMatch(message.didNotFind("class").items(new Object[] { "org.webjars.WebJarAssetLocator" }));
/*    */     } 
/* 55 */     if (match.booleanValue()) {
/* 56 */       return ConditionOutcome.match(message.because("enabled"));
/*    */     }
/* 58 */     return ConditionOutcome.noMatch(message.because("disabled"));
/*    */   }
/*    */   
/*    */   private Boolean getEnabledProperty(ConfigurableEnvironment environment, String key, Boolean defaultValue) {
/* 62 */     String name = "spring.resources.chain." + key + "enabled";
/* 63 */     return (Boolean)environment.getProperty(name, Boolean.class, defaultValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\OnEnabledResourceChainCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import io.undertow.servlet.api.DeploymentInfo;
/*    */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*    */ import org.springframework.boot.web.embedded.undertow.UndertowDeploymentInfoCustomizer;
/*    */ import org.springframework.boot.web.embedded.undertow.UndertowServletWebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UndertowServletWebServerFactoryCustomizer
/*    */   implements WebServerFactoryCustomizer<UndertowServletWebServerFactory>
/*    */ {
/*    */   private final ServerProperties serverProperties;
/*    */   
/*    */   public UndertowServletWebServerFactoryCustomizer(ServerProperties serverProperties) {
/* 36 */     this.serverProperties = serverProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(UndertowServletWebServerFactory factory) {
/* 41 */     factory.addDeploymentInfoCustomizers(new UndertowDeploymentInfoCustomizer[] { deploymentInfo -> deploymentInfo.setEagerFilterInit(this.serverProperties.getUndertow().isEagerFilterInit()) });
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\UndertowServletWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
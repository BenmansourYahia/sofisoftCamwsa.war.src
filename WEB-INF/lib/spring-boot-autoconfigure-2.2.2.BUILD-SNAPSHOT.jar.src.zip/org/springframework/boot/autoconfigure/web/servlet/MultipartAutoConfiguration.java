/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import javax.servlet.MultipartConfigElement;
/*    */ import javax.servlet.Servlet;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.web.multipart.MultipartResolver;
/*    */ import org.springframework.web.multipart.commons.CommonsMultipartResolver;
/*    */ import org.springframework.web.multipart.support.StandardServletMultipartResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Servlet.class, StandardServletMultipartResolver.class, MultipartConfigElement.class})
/*    */ @ConditionalOnProperty(prefix = "spring.servlet.multipart", name = {"enabled"}, matchIfMissing = true)
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @EnableConfigurationProperties({MultipartProperties.class})
/*    */ public class MultipartAutoConfiguration
/*    */ {
/*    */   private final MultipartProperties multipartProperties;
/*    */   
/*    */   public MultipartAutoConfiguration(MultipartProperties multipartProperties) {
/* 62 */     this.multipartProperties = multipartProperties;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({MultipartConfigElement.class, CommonsMultipartResolver.class})
/*    */   public MultipartConfigElement multipartConfigElement() {
/* 68 */     return this.multipartProperties.createMultipartConfig();
/*    */   }
/*    */   
/*    */   @Bean(name = {"multipartResolver"})
/*    */   @ConditionalOnMissingBean({MultipartResolver.class})
/*    */   public StandardServletMultipartResolver multipartResolver() {
/* 74 */     StandardServletMultipartResolver multipartResolver = new StandardServletMultipartResolver();
/* 75 */     multipartResolver.setResolveLazily(this.multipartProperties.isResolveLazily());
/* 76 */     return multipartResolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\MultipartAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
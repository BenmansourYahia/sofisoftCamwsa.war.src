/*     */ package org.springframework.boot.autoconfigure.web.reactive.error;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProviders;
/*     */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*     */ import org.springframework.boot.web.reactive.error.ErrorAttributes;
/*     */ import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.NestedExceptionUtils;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.codec.HttpMessageReader;
/*     */ import org.springframework.http.codec.HttpMessageWriter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.reactive.function.BodyInserters;
/*     */ import org.springframework.web.reactive.function.server.HandlerFunction;
/*     */ import org.springframework.web.reactive.function.server.RouterFunction;
/*     */ import org.springframework.web.reactive.function.server.ServerRequest;
/*     */ import org.springframework.web.reactive.function.server.ServerResponse;
/*     */ import org.springframework.web.reactive.result.view.ViewResolver;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractErrorWebExceptionHandler
/*     */   implements ErrorWebExceptionHandler, InitializingBean
/*     */ {
/*     */   private static final Set<String> DISCONNECTED_CLIENT_EXCEPTIONS;
/*     */   
/*     */   static {
/*  68 */     Set<String> exceptions = new HashSet<>();
/*  69 */     exceptions.add("AbortedException");
/*  70 */     exceptions.add("ClientAbortException");
/*  71 */     exceptions.add("EOFException");
/*  72 */     exceptions.add("EofException");
/*  73 */     DISCONNECTED_CLIENT_EXCEPTIONS = Collections.unmodifiableSet(exceptions);
/*     */   }
/*     */   
/*  76 */   private static final Log logger = HttpLogging.forLogName(AbstractErrorWebExceptionHandler.class);
/*     */   
/*     */   private final ApplicationContext applicationContext;
/*     */   
/*     */   private final ErrorAttributes errorAttributes;
/*     */   
/*     */   private final ResourceProperties resourceProperties;
/*     */   
/*     */   private final TemplateAvailabilityProviders templateAvailabilityProviders;
/*     */   
/*  86 */   private List<HttpMessageReader<?>> messageReaders = Collections.emptyList();
/*     */   
/*  88 */   private List<HttpMessageWriter<?>> messageWriters = Collections.emptyList();
/*     */   
/*  90 */   private List<ViewResolver> viewResolvers = Collections.emptyList();
/*     */ 
/*     */   
/*     */   public AbstractErrorWebExceptionHandler(ErrorAttributes errorAttributes, ResourceProperties resourceProperties, ApplicationContext applicationContext) {
/*  94 */     Assert.notNull(errorAttributes, "ErrorAttributes must not be null");
/*  95 */     Assert.notNull(resourceProperties, "ResourceProperties must not be null");
/*  96 */     Assert.notNull(applicationContext, "ApplicationContext must not be null");
/*  97 */     this.errorAttributes = errorAttributes;
/*  98 */     this.resourceProperties = resourceProperties;
/*  99 */     this.applicationContext = applicationContext;
/* 100 */     this.templateAvailabilityProviders = new TemplateAvailabilityProviders(applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageWriters(List<HttpMessageWriter<?>> messageWriters) {
/* 108 */     Assert.notNull(messageWriters, "'messageWriters' must not be null");
/* 109 */     this.messageWriters = messageWriters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageReaders(List<HttpMessageReader<?>> messageReaders) {
/* 117 */     Assert.notNull(messageReaders, "'messageReaders' must not be null");
/* 118 */     this.messageReaders = messageReaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewResolvers(List<ViewResolver> viewResolvers) {
/* 126 */     this.viewResolvers = viewResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, Object> getErrorAttributes(ServerRequest request, boolean includeStackTrace) {
/* 137 */     return this.errorAttributes.getErrorAttributes(request, includeStackTrace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Throwable getError(ServerRequest request) {
/* 146 */     return this.errorAttributes.getError(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isTraceEnabled(ServerRequest request) {
/* 155 */     String parameter = request.queryParam("trace").orElse("false");
/* 156 */     return !"false".equalsIgnoreCase(parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<ServerResponse> renderErrorView(String viewName, ServerResponse.BodyBuilder responseBody, Map<String, Object> error) {
/* 170 */     if (isTemplateAvailable(viewName)) {
/* 171 */       return responseBody.render(viewName, error);
/*     */     }
/* 173 */     Resource resource = resolveResource(viewName);
/* 174 */     if (resource != null) {
/* 175 */       return responseBody.body(BodyInserters.fromResource(resource));
/*     */     }
/* 177 */     return Mono.empty();
/*     */   }
/*     */   
/*     */   private boolean isTemplateAvailable(String viewName) {
/* 181 */     return (this.templateAvailabilityProviders.getProvider(viewName, this.applicationContext) != null);
/*     */   }
/*     */   
/*     */   private Resource resolveResource(String viewName) {
/* 185 */     for (String location : this.resourceProperties.getStaticLocations()) {
/*     */       try {
/* 187 */         Resource resource = this.applicationContext.getResource(location);
/* 188 */         resource = resource.createRelative(viewName + ".html");
/* 189 */         if (resource.exists()) {
/* 190 */           return resource;
/*     */         }
/*     */       }
/* 193 */       catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<ServerResponse> renderDefaultErrorView(ServerResponse.BodyBuilder responseBody, Map<String, Object> error) {
/* 210 */     StringBuilder builder = new StringBuilder();
/* 211 */     Date timestamp = (Date)error.get("timestamp");
/* 212 */     Object message = error.get("message");
/* 213 */     Object trace = error.get("trace");
/* 214 */     Object requestId = error.get("requestId");
/* 215 */     builder.append("<html><body><h1>Whitelabel Error Page</h1>")
/* 216 */       .append("<p>This application has no configured error view, so you are seeing this as a fallback.</p>")
/* 217 */       .append("<div id='created'>").append(timestamp).append("</div>").append("<div>[").append(requestId)
/* 218 */       .append("] There was an unexpected error (type=").append(htmlEscape(error.get("error")))
/* 219 */       .append(", status=").append(htmlEscape(error.get("status"))).append(").</div>");
/* 220 */     if (message != null) {
/* 221 */       builder.append("<div>").append(htmlEscape(message)).append("</div>");
/*     */     }
/* 223 */     if (trace != null) {
/* 224 */       builder.append("<div style='white-space:pre-wrap;'>").append(htmlEscape(trace)).append("</div>");
/*     */     }
/* 226 */     builder.append("</body></html>");
/* 227 */     return responseBody.bodyValue(builder.toString());
/*     */   }
/*     */   
/*     */   private String htmlEscape(Object input) {
/* 231 */     return (input != null) ? HtmlUtils.htmlEscape(input.toString()) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 236 */     if (CollectionUtils.isEmpty(this.messageWriters)) {
/* 237 */       throw new IllegalArgumentException("Property 'messageWriters' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> handle(ServerWebExchange exchange, Throwable throwable) {
/* 256 */     if (exchange.getResponse().isCommitted() || isDisconnectedClientError(throwable)) {
/* 257 */       return Mono.error(throwable);
/*     */     }
/* 259 */     this.errorAttributes.storeErrorInformation(throwable, exchange);
/* 260 */     ServerRequest request = ServerRequest.create(exchange, this.messageReaders);
/* 261 */     return getRoutingFunction(this.errorAttributes).route(request).switchIfEmpty(Mono.error(throwable))
/* 262 */       .flatMap(handler -> handler.handle(request))
/* 263 */       .doOnNext(response -> logError(request, response, throwable))
/* 264 */       .flatMap(response -> write(exchange, response));
/*     */   }
/*     */   
/*     */   private boolean isDisconnectedClientError(Throwable ex) {
/* 268 */     return (DISCONNECTED_CLIENT_EXCEPTIONS.contains(ex.getClass().getSimpleName()) || 
/* 269 */       isDisconnectedClientErrorMessage(NestedExceptionUtils.getMostSpecificCause(ex).getMessage()));
/*     */   }
/*     */   
/*     */   private boolean isDisconnectedClientErrorMessage(String message) {
/* 273 */     message = (message != null) ? message.toLowerCase() : "";
/* 274 */     return (message.contains("broken pipe") || message.contains("connection reset by peer"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logError(ServerRequest request, ServerResponse response, Throwable throwable) {
/* 287 */     if (logger.isDebugEnabled()) {
/* 288 */       logger.debug(request.exchange().getLogPrefix() + formatError(throwable, request));
/*     */     }
/* 290 */     if (HttpStatus.resolve(response.rawStatusCode()) != null && response
/* 291 */       .statusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
/* 292 */       logger.error(LogMessage.of(() -> String.format("%s 500 Server Error for %s", new Object[] { request.exchange().getLogPrefix(), formatRequest(request) })), throwable);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private String formatError(Throwable ex, ServerRequest request) {
/* 298 */     String reason = ex.getClass().getSimpleName() + ": " + ex.getMessage();
/* 299 */     return "Resolved [" + reason + "] for HTTP " + request.methodName() + " " + request.path();
/*     */   }
/*     */   
/*     */   private String formatRequest(ServerRequest request) {
/* 303 */     String rawQuery = request.uri().getRawQuery();
/* 304 */     String query = StringUtils.hasText(rawQuery) ? ("?" + rawQuery) : "";
/* 305 */     return "HTTP " + request.methodName() + " \"" + request.path() + query + "\"";
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<? extends Void> write(ServerWebExchange exchange, ServerResponse response) {
/* 310 */     exchange.getResponse().getHeaders().setContentType(response.headers().getContentType());
/* 311 */     return response.writeTo(exchange, new ResponseContext());
/*     */   }
/*     */   
/*     */   protected abstract RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes paramErrorAttributes);
/*     */   
/*     */   private class ResponseContext implements ServerResponse.Context {
/*     */     public List<HttpMessageWriter<?>> messageWriters() {
/* 318 */       return AbstractErrorWebExceptionHandler.this.messageWriters;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<ViewResolver> viewResolvers() {
/* 323 */       return AbstractErrorWebExceptionHandler.this.viewResolvers;
/*     */     }
/*     */     
/*     */     private ResponseContext() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\error\AbstractErrorWebExceptionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.web.reactive;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import java.util.Collection;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.web.embedded.jetty.JettyReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.jetty.JettyServerCustomizer;
/*     */ import org.springframework.boot.web.embedded.netty.NettyReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.netty.NettyRouteProvider;
/*     */ import org.springframework.boot.web.embedded.netty.NettyServerCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatContextCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatProtocolHandlerCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.undertow.UndertowBuilderCustomizer;
/*     */ import org.springframework.boot.web.embedded.undertow.UndertowReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.reactive.server.ReactiveWebServerFactory;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.http.client.reactive.JettyResourceFactory;
/*     */ import org.springframework.http.client.reactive.ReactorResourceFactory;
/*     */ import reactor.netty.http.server.HttpServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ReactiveWebServerFactoryConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({ReactiveWebServerFactory.class})
/*     */   @ConditionalOnClass({HttpServer.class})
/*     */   static class EmbeddedNetty
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ReactorResourceFactory reactorServerResourceFactory() {
/*  64 */       return new ReactorResourceFactory();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     NettyReactiveWebServerFactory nettyReactiveWebServerFactory(ReactorResourceFactory resourceFactory, ObjectProvider<NettyRouteProvider> routes, ObjectProvider<NettyServerCustomizer> serverCustomizers) {
/*  70 */       NettyReactiveWebServerFactory serverFactory = new NettyReactiveWebServerFactory();
/*  71 */       serverFactory.setResourceFactory(resourceFactory);
/*  72 */       routes.orderedStream().forEach(xva$0 -> rec$.addRouteProviders(new NettyRouteProvider[] { xva$0 }));
/*  73 */       serverFactory.getServerCustomizers().addAll((Collection)serverCustomizers.orderedStream().collect(Collectors.toList()));
/*  74 */       return serverFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({ReactiveWebServerFactory.class})
/*     */   @ConditionalOnClass({Tomcat.class})
/*     */   static class EmbeddedTomcat
/*     */   {
/*     */     @Bean
/*     */     TomcatReactiveWebServerFactory tomcatReactiveWebServerFactory(ObjectProvider<TomcatConnectorCustomizer> connectorCustomizers, ObjectProvider<TomcatContextCustomizer> contextCustomizers, ObjectProvider<TomcatProtocolHandlerCustomizer<?>> protocolHandlerCustomizers) {
/*  89 */       TomcatReactiveWebServerFactory factory = new TomcatReactiveWebServerFactory();
/*  90 */       factory.getTomcatConnectorCustomizers()
/*  91 */         .addAll((Collection)connectorCustomizers.orderedStream().collect(Collectors.toList()));
/*  92 */       factory.getTomcatContextCustomizers()
/*  93 */         .addAll((Collection)contextCustomizers.orderedStream().collect(Collectors.toList()));
/*  94 */       factory.getTomcatProtocolHandlerCustomizers()
/*  95 */         .addAll((Collection)protocolHandlerCustomizers.orderedStream().collect(Collectors.toList()));
/*  96 */       return factory;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({ReactiveWebServerFactory.class})
/*     */   @ConditionalOnClass({Server.class})
/*     */   static class EmbeddedJetty
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     JettyResourceFactory jettyServerResourceFactory() {
/* 109 */       return new JettyResourceFactory();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     JettyReactiveWebServerFactory jettyReactiveWebServerFactory(JettyResourceFactory resourceFactory, ObjectProvider<JettyServerCustomizer> serverCustomizers) {
/* 115 */       JettyReactiveWebServerFactory serverFactory = new JettyReactiveWebServerFactory();
/* 116 */       serverFactory.getServerCustomizers().addAll((Collection)serverCustomizers.orderedStream().collect(Collectors.toList()));
/* 117 */       serverFactory.setResourceFactory(resourceFactory);
/* 118 */       return serverFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({ReactiveWebServerFactory.class})
/*     */   @ConditionalOnClass({Undertow.class})
/*     */   static class EmbeddedUndertow
/*     */   {
/*     */     @Bean
/*     */     UndertowReactiveWebServerFactory undertowReactiveWebServerFactory(ObjectProvider<UndertowBuilderCustomizer> builderCustomizers) {
/* 131 */       UndertowReactiveWebServerFactory factory = new UndertowReactiveWebServerFactory();
/* 132 */       factory.getBuilderCustomizers().addAll((Collection)builderCustomizers.orderedStream().collect(Collectors.toList()));
/* 133 */       return factory;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\ReactiveWebServerFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
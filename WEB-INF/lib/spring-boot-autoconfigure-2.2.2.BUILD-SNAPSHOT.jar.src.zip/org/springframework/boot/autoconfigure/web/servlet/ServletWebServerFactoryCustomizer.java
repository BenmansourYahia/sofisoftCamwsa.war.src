/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletWebServerFactoryCustomizer
/*    */   implements WebServerFactoryCustomizer<ConfigurableServletWebServerFactory>, Ordered
/*    */ {
/*    */   private final ServerProperties serverProperties;
/*    */   
/*    */   public ServletWebServerFactoryCustomizer(ServerProperties serverProperties) {
/* 41 */     this.serverProperties = serverProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 46 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(ConfigurableServletWebServerFactory factory) {
/* 51 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 52 */     map.from(this.serverProperties::getPort).to(factory::setPort);
/* 53 */     map.from(this.serverProperties::getAddress).to(factory::setAddress);
/* 54 */     map.from(this.serverProperties.getServlet()::getContextPath).to(factory::setContextPath);
/* 55 */     map.from(this.serverProperties.getServlet()::getApplicationDisplayName).to(factory::setDisplayName);
/* 56 */     map.from(this.serverProperties.getServlet()::getSession).to(factory::setSession);
/* 57 */     map.from(this.serverProperties::getSsl).to(factory::setSsl);
/* 58 */     map.from(this.serverProperties.getServlet()::getJsp).to(factory::setJsp);
/* 59 */     map.from(this.serverProperties::getCompression).to(factory::setCompression);
/* 60 */     map.from(this.serverProperties::getHttp2).to(factory::setHttp2);
/* 61 */     map.from(this.serverProperties::getServerHeader).to(factory::setServerHeader);
/* 62 */     map.from(this.serverProperties.getServlet()::getContextParameters).to(factory::setInitParameters);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\ServletWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
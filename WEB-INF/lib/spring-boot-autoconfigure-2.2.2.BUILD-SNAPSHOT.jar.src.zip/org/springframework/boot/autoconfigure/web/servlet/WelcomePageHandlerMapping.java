/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProviders;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.servlet.handler.AbstractUrlHandlerMapping;
/*    */ import org.springframework.web.servlet.mvc.ParameterizableViewController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WelcomePageHandlerMapping
/*    */   extends AbstractUrlHandlerMapping
/*    */ {
/* 47 */   private static final Log logger = LogFactory.getLog(WelcomePageHandlerMapping.class);
/*    */   
/* 49 */   private static final List<MediaType> MEDIA_TYPES_ALL = Collections.singletonList(MediaType.ALL);
/*    */ 
/*    */   
/*    */   WelcomePageHandlerMapping(TemplateAvailabilityProviders templateAvailabilityProviders, ApplicationContext applicationContext, Optional<Resource> welcomePage, String staticPathPattern) {
/* 53 */     if (welcomePage.isPresent() && "/**".equals(staticPathPattern)) {
/* 54 */       logger.info("Adding welcome page: " + welcomePage.get());
/* 55 */       setRootViewName("forward:index.html");
/*    */     }
/* 57 */     else if (welcomeTemplateExists(templateAvailabilityProviders, applicationContext)) {
/* 58 */       logger.info("Adding welcome page template: index");
/* 59 */       setRootViewName("index");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean welcomeTemplateExists(TemplateAvailabilityProviders templateAvailabilityProviders, ApplicationContext applicationContext) {
/* 65 */     return (templateAvailabilityProviders.getProvider("index", applicationContext) != null);
/*    */   }
/*    */   
/*    */   private void setRootViewName(String viewName) {
/* 69 */     ParameterizableViewController controller = new ParameterizableViewController();
/* 70 */     controller.setViewName(viewName);
/* 71 */     setRootHandler(controller);
/* 72 */     setOrder(2);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getHandlerInternal(HttpServletRequest request) throws Exception {
/* 77 */     for (MediaType mediaType : getAcceptedMediaTypes(request)) {
/* 78 */       if (mediaType.includes(MediaType.TEXT_HTML)) {
/* 79 */         return super.getHandlerInternal(request);
/*    */       }
/*    */     } 
/* 82 */     return null;
/*    */   }
/*    */   
/*    */   private List<MediaType> getAcceptedMediaTypes(HttpServletRequest request) {
/* 86 */     String acceptHeader = request.getHeader("Accept");
/* 87 */     if (StringUtils.hasText(acceptHeader)) {
/* 88 */       return MediaType.parseMediaTypes(acceptHeader);
/*    */     }
/* 90 */     return MEDIA_TYPES_ALL;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\WelcomePageHandlerMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
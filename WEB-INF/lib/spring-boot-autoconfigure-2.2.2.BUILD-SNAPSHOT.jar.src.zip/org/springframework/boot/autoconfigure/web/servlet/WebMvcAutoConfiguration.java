/*     */ package org.springframework.boot.autoconfigure.web.servlet;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.annotation.Qualifier;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
/*     */ import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProviders;
/*     */ import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.validation.ValidatorAdapter;
/*     */ import org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain;
/*     */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*     */ import org.springframework.boot.autoconfigure.web.format.WebConversionService;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.boot.web.servlet.filter.OrderedFormContentFilter;
/*     */ import org.springframework.boot.web.servlet.filter.OrderedHiddenHttpMethodFilter;
/*     */ import org.springframework.boot.web.servlet.filter.OrderedRequestContextFilter;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.support.FormattingConversionService;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.validation.DefaultMessageCodesResolver;
/*     */ import org.springframework.validation.MessageCodeFormatter;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ import org.springframework.web.accept.PathExtensionContentNegotiationStrategy;
/*     */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.RequestContextListener;
/*     */ import org.springframework.web.filter.FormContentFilter;
/*     */ import org.springframework.web.filter.HiddenHttpMethodFilter;
/*     */ import org.springframework.web.filter.RequestContextFilter;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;
/*     */ import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
/*     */ import org.springframework.web.servlet.config.annotation.DelegatingWebMvcConfiguration;
/*     */ import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
/*     */ import org.springframework.web.servlet.config.annotation.ResourceChainRegistration;
/*     */ import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistration;
/*     */ import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/*     */ import org.springframework.web.servlet.i18n.FixedLocaleResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.AppCacheManifestTransformer;
/*     */ import org.springframework.web.servlet.resource.EncodedResourceResolver;
/*     */ import org.springframework.web.servlet.resource.ResourceResolver;
/*     */ import org.springframework.web.servlet.resource.ResourceTransformer;
/*     */ import org.springframework.web.servlet.resource.ResourceUrlProvider;
/*     */ import org.springframework.web.servlet.resource.VersionResourceResolver;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
/*     */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @ConditionalOnClass({Servlet.class, DispatcherServlet.class, WebMvcConfigurer.class})
/*     */ @ConditionalOnMissingBean({WebMvcConfigurationSupport.class})
/*     */ @AutoConfigureOrder(-2147483638)
/*     */ @AutoConfigureAfter({DispatcherServletAutoConfiguration.class, TaskExecutionAutoConfiguration.class, ValidationAutoConfiguration.class})
/*     */ public class WebMvcAutoConfiguration
/*     */ {
/*     */   public static final String DEFAULT_PREFIX = "";
/*     */   public static final String DEFAULT_SUFFIX = "";
/* 148 */   private static final String[] SERVLET_LOCATIONS = new String[] { "/" };
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({HiddenHttpMethodFilter.class})
/*     */   @ConditionalOnProperty(prefix = "spring.mvc.hiddenmethod.filter", name = {"enabled"}, matchIfMissing = false)
/*     */   public OrderedHiddenHttpMethodFilter hiddenHttpMethodFilter() {
/* 154 */     return new OrderedHiddenHttpMethodFilter();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({FormContentFilter.class})
/*     */   @ConditionalOnProperty(prefix = "spring.mvc.formcontent.filter", name = {"enabled"}, matchIfMissing = true)
/*     */   public OrderedFormContentFilter formContentFilter() {
/* 161 */     return new OrderedFormContentFilter();
/*     */   }
/*     */   
/*     */   static String[] getResourceLocations(String[] staticLocations) {
/* 165 */     String[] locations = new String[staticLocations.length + SERVLET_LOCATIONS.length];
/* 166 */     System.arraycopy(staticLocations, 0, locations, 0, staticLocations.length);
/* 167 */     System.arraycopy(SERVLET_LOCATIONS, 0, locations, staticLocations.length, SERVLET_LOCATIONS.length);
/* 168 */     return locations;
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Import({EnableWebMvcConfiguration.class})
/*     */   @EnableConfigurationProperties({WebMvcProperties.class, ResourceProperties.class})
/*     */   @Order(0)
/*     */   public static class WebMvcAutoConfigurationAdapter
/*     */     implements WebMvcConfigurer
/*     */   {
/* 179 */     private static final Log logger = LogFactory.getLog(WebMvcConfigurer.class);
/*     */ 
/*     */     
/*     */     private final ResourceProperties resourceProperties;
/*     */     
/*     */     private final WebMvcProperties mvcProperties;
/*     */     
/*     */     private final ListableBeanFactory beanFactory;
/*     */     
/*     */     private final ObjectProvider<HttpMessageConverters> messageConvertersProvider;
/*     */     
/*     */     final WebMvcAutoConfiguration.ResourceHandlerRegistrationCustomizer resourceHandlerRegistrationCustomizer;
/*     */ 
/*     */     
/*     */     public WebMvcAutoConfigurationAdapter(ResourceProperties resourceProperties, WebMvcProperties mvcProperties, ListableBeanFactory beanFactory, ObjectProvider<HttpMessageConverters> messageConvertersProvider, ObjectProvider<WebMvcAutoConfiguration.ResourceHandlerRegistrationCustomizer> resourceHandlerRegistrationCustomizerProvider) {
/* 194 */       this.resourceProperties = resourceProperties;
/* 195 */       this.mvcProperties = mvcProperties;
/* 196 */       this.beanFactory = beanFactory;
/* 197 */       this.messageConvertersProvider = messageConvertersProvider;
/* 198 */       this.resourceHandlerRegistrationCustomizer = (WebMvcAutoConfiguration.ResourceHandlerRegistrationCustomizer)resourceHandlerRegistrationCustomizerProvider.getIfAvailable();
/*     */     }
/*     */ 
/*     */     
/*     */     public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
/* 203 */       this.messageConvertersProvider
/* 204 */         .ifAvailable(customConverters -> converters.addAll(customConverters.getConverters()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void configureAsyncSupport(AsyncSupportConfigurer configurer) {
/* 209 */       if (this.beanFactory.containsBean("applicationTaskExecutor")) {
/*     */         
/* 211 */         Object taskExecutor = this.beanFactory.getBean("applicationTaskExecutor");
/* 212 */         if (taskExecutor instanceof AsyncTaskExecutor) {
/* 213 */           configurer.setTaskExecutor((AsyncTaskExecutor)taskExecutor);
/*     */         }
/*     */       } 
/* 216 */       Duration timeout = this.mvcProperties.getAsync().getRequestTimeout();
/* 217 */       if (timeout != null) {
/* 218 */         configurer.setDefaultTimeout(timeout.toMillis());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void configurePathMatch(PathMatchConfigurer configurer) {
/* 224 */       configurer.setUseSuffixPatternMatch(Boolean.valueOf(this.mvcProperties.getPathmatch().isUseSuffixPattern()));
/* 225 */       configurer.setUseRegisteredSuffixPatternMatch(
/* 226 */           Boolean.valueOf(this.mvcProperties.getPathmatch().isUseRegisteredSuffixPattern()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
/* 231 */       WebMvcProperties.Contentnegotiation contentnegotiation = this.mvcProperties.getContentnegotiation();
/* 232 */       configurer.favorPathExtension(contentnegotiation.isFavorPathExtension());
/* 233 */       configurer.favorParameter(contentnegotiation.isFavorParameter());
/* 234 */       if (contentnegotiation.getParameterName() != null) {
/* 235 */         configurer.parameterName(contentnegotiation.getParameterName());
/*     */       }
/* 237 */       Map<String, MediaType> mediaTypes = this.mvcProperties.getContentnegotiation().getMediaTypes();
/* 238 */       mediaTypes.forEach(configurer::mediaType);
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public InternalResourceViewResolver defaultViewResolver() {
/* 244 */       InternalResourceViewResolver resolver = new InternalResourceViewResolver();
/* 245 */       resolver.setPrefix(this.mvcProperties.getView().getPrefix());
/* 246 */       resolver.setSuffix(this.mvcProperties.getView().getSuffix());
/* 247 */       return resolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnBean({View.class})
/*     */     @ConditionalOnMissingBean
/*     */     public BeanNameViewResolver beanNameViewResolver() {
/* 254 */       BeanNameViewResolver resolver = new BeanNameViewResolver();
/* 255 */       resolver.setOrder(2147483637);
/* 256 */       return resolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnBean({ViewResolver.class})
/*     */     @ConditionalOnMissingBean(name = {"viewResolver"}, value = {ContentNegotiatingViewResolver.class})
/*     */     public ContentNegotiatingViewResolver viewResolver(BeanFactory beanFactory) {
/* 263 */       ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
/* 264 */       resolver.setContentNegotiationManager((ContentNegotiationManager)beanFactory.getBean(ContentNegotiationManager.class));
/*     */ 
/*     */       
/* 267 */       resolver.setOrder(-2147483648);
/* 268 */       return resolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     @ConditionalOnProperty(prefix = "spring.mvc", name = {"locale"})
/*     */     public LocaleResolver localeResolver() {
/* 275 */       if (this.mvcProperties.getLocaleResolver() == WebMvcProperties.LocaleResolver.FIXED) {
/* 276 */         return (LocaleResolver)new FixedLocaleResolver(this.mvcProperties.getLocale());
/*     */       }
/* 278 */       AcceptHeaderLocaleResolver localeResolver = new AcceptHeaderLocaleResolver();
/* 279 */       localeResolver.setDefaultLocale(this.mvcProperties.getLocale());
/* 280 */       return (LocaleResolver)localeResolver;
/*     */     }
/*     */ 
/*     */     
/*     */     public MessageCodesResolver getMessageCodesResolver() {
/* 285 */       if (this.mvcProperties.getMessageCodesResolverFormat() != null) {
/* 286 */         DefaultMessageCodesResolver resolver = new DefaultMessageCodesResolver();
/* 287 */         resolver.setMessageCodeFormatter((MessageCodeFormatter)this.mvcProperties.getMessageCodesResolverFormat());
/* 288 */         return (MessageCodesResolver)resolver;
/*     */       } 
/* 290 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addFormatters(FormatterRegistry registry) {
/* 295 */       ApplicationConversionService.addBeans(registry, this.beanFactory);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addResourceHandlers(ResourceHandlerRegistry registry) {
/* 300 */       if (!this.resourceProperties.isAddMappings()) {
/* 301 */         logger.debug("Default resource handling disabled");
/*     */         return;
/*     */       } 
/* 304 */       Duration cachePeriod = this.resourceProperties.getCache().getPeriod();
/* 305 */       CacheControl cacheControl = this.resourceProperties.getCache().getCachecontrol().toHttpCacheControl();
/* 306 */       if (!registry.hasMappingForPattern("/webjars/**")) {
/* 307 */         customizeResourceHandlerRegistration(registry.addResourceHandler(new String[] { "/webjars/**"
/* 308 */               }).addResourceLocations(new String[] { "classpath:/META-INF/resources/webjars/"
/* 309 */               }).setCachePeriod(getSeconds(cachePeriod)).setCacheControl(cacheControl));
/*     */       }
/* 311 */       String staticPathPattern = this.mvcProperties.getStaticPathPattern();
/* 312 */       if (!registry.hasMappingForPattern(staticPathPattern)) {
/* 313 */         customizeResourceHandlerRegistration(registry.addResourceHandler(new String[] { staticPathPattern
/* 314 */               }).addResourceLocations(WebMvcAutoConfiguration.getResourceLocations(this.resourceProperties.getStaticLocations()))
/* 315 */             .setCachePeriod(getSeconds(cachePeriod)).setCacheControl(cacheControl));
/*     */       }
/*     */     }
/*     */     
/*     */     private Integer getSeconds(Duration cachePeriod) {
/* 320 */       return (cachePeriod != null) ? Integer.valueOf((int)cachePeriod.getSeconds()) : null;
/*     */     }
/*     */     
/*     */     private void customizeResourceHandlerRegistration(ResourceHandlerRegistration registration) {
/* 324 */       if (this.resourceHandlerRegistrationCustomizer != null) {
/* 325 */         this.resourceHandlerRegistrationCustomizer.customize(registration);
/*     */       }
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({RequestContextListener.class, RequestContextFilter.class})
/*     */     @ConditionalOnMissingFilterBean({RequestContextFilter.class})
/*     */     public static RequestContextFilter requestContextFilter() {
/* 333 */       return (RequestContextFilter)new OrderedRequestContextFilter();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   public static class EnableWebMvcConfiguration
/*     */     extends DelegatingWebMvcConfiguration
/*     */     implements ResourceLoaderAware
/*     */   {
/*     */     private final ResourceProperties resourceProperties;
/*     */ 
/*     */     
/*     */     private final WebMvcProperties mvcProperties;
/*     */     
/*     */     private final ListableBeanFactory beanFactory;
/*     */     
/*     */     private final WebMvcRegistrations mvcRegistrations;
/*     */     
/*     */     private ResourceLoader resourceLoader;
/*     */ 
/*     */     
/*     */     public EnableWebMvcConfiguration(ResourceProperties resourceProperties, ObjectProvider<WebMvcProperties> mvcPropertiesProvider, ObjectProvider<WebMvcRegistrations> mvcRegistrationsProvider, ListableBeanFactory beanFactory) {
/* 357 */       this.resourceProperties = resourceProperties;
/* 358 */       this.mvcProperties = (WebMvcProperties)mvcPropertiesProvider.getIfAvailable();
/* 359 */       this.mvcRegistrations = (WebMvcRegistrations)mvcRegistrationsProvider.getIfUnique();
/* 360 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public RequestMappingHandlerAdapter requestMappingHandlerAdapter(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcValidator") Validator validator) {
/* 369 */       RequestMappingHandlerAdapter adapter = super.requestMappingHandlerAdapter(contentNegotiationManager, conversionService, validator);
/*     */       
/* 371 */       adapter.setIgnoreDefaultModelOnRedirect((this.mvcProperties == null || this.mvcProperties
/* 372 */           .isIgnoreDefaultModelOnRedirect()));
/* 373 */       return adapter;
/*     */     }
/*     */ 
/*     */     
/*     */     protected RequestMappingHandlerAdapter createRequestMappingHandlerAdapter() {
/* 378 */       if (this.mvcRegistrations != null && this.mvcRegistrations.getRequestMappingHandlerAdapter() != null) {
/* 379 */         return this.mvcRegistrations.getRequestMappingHandlerAdapter();
/*     */       }
/* 381 */       return super.createRequestMappingHandlerAdapter();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @Primary
/*     */     public RequestMappingHandlerMapping requestMappingHandlerMapping(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider) {
/* 392 */       return super.requestMappingHandlerMapping(contentNegotiationManager, conversionService, resourceUrlProvider);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public WelcomePageHandlerMapping welcomePageHandlerMapping(ApplicationContext applicationContext, FormattingConversionService mvcConversionService, ResourceUrlProvider mvcResourceUrlProvider) {
/* 401 */       WelcomePageHandlerMapping welcomePageHandlerMapping = new WelcomePageHandlerMapping(new TemplateAvailabilityProviders(applicationContext), applicationContext, getWelcomePage(), this.mvcProperties.getStaticPathPattern());
/* 402 */       welcomePageHandlerMapping.setInterceptors(getInterceptors(mvcConversionService, mvcResourceUrlProvider));
/* 403 */       return welcomePageHandlerMapping;
/*     */     }
/*     */     
/*     */     private Optional<Resource> getWelcomePage() {
/* 407 */       String[] locations = WebMvcAutoConfiguration.getResourceLocations(this.resourceProperties.getStaticLocations());
/* 408 */       return Arrays.<String>stream(locations).map(this::getIndexHtml).filter(this::isReadable).findFirst();
/*     */     }
/*     */     
/*     */     private Resource getIndexHtml(String location) {
/* 412 */       return this.resourceLoader.getResource(location + "index.html");
/*     */     }
/*     */     
/*     */     private boolean isReadable(Resource resource) {
/*     */       try {
/* 417 */         return (resource.exists() && resource.getURL() != null);
/*     */       }
/* 419 */       catch (Exception ex) {
/* 420 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public FormattingConversionService mvcConversionService() {
/* 427 */       WebConversionService conversionService = new WebConversionService(this.mvcProperties.getDateFormat());
/* 428 */       addFormatters((FormatterRegistry)conversionService);
/* 429 */       return (FormattingConversionService)conversionService;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public Validator mvcValidator() {
/* 435 */       if (!ClassUtils.isPresent("javax.validation.Validator", getClass().getClassLoader())) {
/* 436 */         return super.mvcValidator();
/*     */       }
/* 438 */       return ValidatorAdapter.get(getApplicationContext(), getValidator());
/*     */     }
/*     */ 
/*     */     
/*     */     protected RequestMappingHandlerMapping createRequestMappingHandlerMapping() {
/* 443 */       if (this.mvcRegistrations != null && this.mvcRegistrations.getRequestMappingHandlerMapping() != null) {
/* 444 */         return this.mvcRegistrations.getRequestMappingHandlerMapping();
/*     */       }
/* 446 */       return super.createRequestMappingHandlerMapping();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected ConfigurableWebBindingInitializer getConfigurableWebBindingInitializer(FormattingConversionService mvcConversionService, Validator mvcValidator) {
/*     */       try {
/* 453 */         return (ConfigurableWebBindingInitializer)this.beanFactory.getBean(ConfigurableWebBindingInitializer.class);
/*     */       }
/* 455 */       catch (NoSuchBeanDefinitionException ex) {
/* 456 */         return super.getConfigurableWebBindingInitializer(mvcConversionService, mvcValidator);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExceptionHandlerExceptionResolver createExceptionHandlerExceptionResolver() {
/* 462 */       if (this.mvcRegistrations != null && this.mvcRegistrations.getExceptionHandlerExceptionResolver() != null) {
/* 463 */         return this.mvcRegistrations.getExceptionHandlerExceptionResolver();
/*     */       }
/* 465 */       return super.createExceptionHandlerExceptionResolver();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
/* 470 */       super.extendHandlerExceptionResolvers(exceptionResolvers);
/* 471 */       if (this.mvcProperties.isLogResolvedException()) {
/* 472 */         for (HandlerExceptionResolver resolver : exceptionResolvers) {
/* 473 */           if (resolver instanceof AbstractHandlerExceptionResolver) {
/* 474 */             ((AbstractHandlerExceptionResolver)resolver).setWarnLogCategory(resolver.getClass().getName());
/*     */           }
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public ContentNegotiationManager mvcContentNegotiationManager() {
/* 483 */       ContentNegotiationManager manager = super.mvcContentNegotiationManager();
/* 484 */       List<ContentNegotiationStrategy> strategies = manager.getStrategies();
/* 485 */       ListIterator<ContentNegotiationStrategy> iterator = strategies.listIterator();
/* 486 */       while (iterator.hasNext()) {
/* 487 */         ContentNegotiationStrategy strategy = iterator.next();
/* 488 */         if (strategy instanceof PathExtensionContentNegotiationStrategy) {
/* 489 */           iterator.set(new WebMvcAutoConfiguration.OptionalPathExtensionContentNegotiationStrategy(strategy));
/*     */         }
/*     */       } 
/* 492 */       return manager;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setResourceLoader(ResourceLoader resourceLoader) {
/* 497 */       this.resourceLoader = resourceLoader;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnEnabledResourceChain
/*     */   static class ResourceChainCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     WebMvcAutoConfiguration.ResourceChainResourceHandlerRegistrationCustomizer resourceHandlerRegistrationCustomizer() {
/* 508 */       return new WebMvcAutoConfiguration.ResourceChainResourceHandlerRegistrationCustomizer();
/*     */     }
/*     */   }
/*     */   
/*     */   static interface ResourceHandlerRegistrationCustomizer
/*     */   {
/*     */     void customize(ResourceHandlerRegistration param1ResourceHandlerRegistration);
/*     */   }
/*     */   
/*     */   static class ResourceChainResourceHandlerRegistrationCustomizer
/*     */     implements ResourceHandlerRegistrationCustomizer
/*     */   {
/*     */     @Autowired
/* 521 */     private ResourceProperties resourceProperties = new ResourceProperties();
/*     */ 
/*     */ 
/*     */     
/*     */     public void customize(ResourceHandlerRegistration registration) {
/* 526 */       ResourceProperties.Chain properties = this.resourceProperties.getChain();
/* 527 */       configureResourceChain(properties, registration.resourceChain(properties.isCache()));
/*     */     }
/*     */     
/*     */     private void configureResourceChain(ResourceProperties.Chain properties, ResourceChainRegistration chain) {
/* 531 */       ResourceProperties.Strategy strategy = properties.getStrategy();
/* 532 */       if (properties.isCompressed()) {
/* 533 */         chain.addResolver((ResourceResolver)new EncodedResourceResolver());
/*     */       }
/* 535 */       if (strategy.getFixed().isEnabled() || strategy.getContent().isEnabled()) {
/* 536 */         chain.addResolver(getVersionResourceResolver(strategy));
/*     */       }
/* 538 */       if (properties.isHtmlApplicationCache()) {
/* 539 */         chain.addTransformer((ResourceTransformer)new AppCacheManifestTransformer());
/*     */       }
/*     */     }
/*     */     
/*     */     private ResourceResolver getVersionResourceResolver(ResourceProperties.Strategy properties) {
/* 544 */       VersionResourceResolver resolver = new VersionResourceResolver();
/* 545 */       if (properties.getFixed().isEnabled()) {
/* 546 */         String version = properties.getFixed().getVersion();
/* 547 */         String[] paths = properties.getFixed().getPaths();
/* 548 */         resolver.addFixedVersionStrategy(version, paths);
/*     */       } 
/* 550 */       if (properties.getContent().isEnabled()) {
/* 551 */         String[] paths = properties.getContent().getPaths();
/* 552 */         resolver.addContentVersionStrategy(paths);
/*     */       } 
/* 554 */       return (ResourceResolver)resolver;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class OptionalPathExtensionContentNegotiationStrategy
/*     */     implements ContentNegotiationStrategy
/*     */   {
/* 565 */     private static final String SKIP_ATTRIBUTE = PathExtensionContentNegotiationStrategy.class.getName() + ".SKIP";
/*     */     
/*     */     private final ContentNegotiationStrategy delegate;
/*     */     
/*     */     OptionalPathExtensionContentNegotiationStrategy(ContentNegotiationStrategy delegate) {
/* 570 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest) throws HttpMediaTypeNotAcceptableException {
/* 576 */       Object skip = webRequest.getAttribute(SKIP_ATTRIBUTE, 0);
/* 577 */       if (skip != null && Boolean.parseBoolean(skip.toString())) {
/* 578 */         return MEDIA_TYPE_ALL_LIST;
/*     */       }
/* 580 */       return this.delegate.resolveMediaTypes(webRequest);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\WebMvcAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
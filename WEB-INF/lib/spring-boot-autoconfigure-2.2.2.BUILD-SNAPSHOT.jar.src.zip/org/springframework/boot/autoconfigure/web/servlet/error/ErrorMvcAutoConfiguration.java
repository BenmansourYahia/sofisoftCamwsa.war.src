/*     */ package org.springframework.boot.autoconfigure.web.servlet.error;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProvider;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProviders;
/*     */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.DispatcherServletPath;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.WebMvcProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.server.ErrorPage;
/*     */ import org.springframework.boot.web.server.ErrorPageRegistrar;
/*     */ import org.springframework.boot.web.server.ErrorPageRegistry;
/*     */ import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
/*     */ import org.springframework.boot.web.servlet.error.ErrorAttributes;
/*     */ import org.springframework.boot.web.servlet.error.ErrorController;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @ConditionalOnClass({Servlet.class, DispatcherServlet.class})
/*     */ @AutoConfigureBefore({WebMvcAutoConfiguration.class})
/*     */ @EnableConfigurationProperties({ServerProperties.class, ResourceProperties.class, WebMvcProperties.class})
/*     */ public class ErrorMvcAutoConfiguration
/*     */ {
/*     */   private final ServerProperties serverProperties;
/*     */   
/*     */   public ErrorMvcAutoConfiguration(ServerProperties serverProperties) {
/*  97 */     this.serverProperties = serverProperties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(value = {ErrorAttributes.class}, search = SearchStrategy.CURRENT)
/*     */   public DefaultErrorAttributes errorAttributes() {
/* 103 */     return new DefaultErrorAttributes(this.serverProperties.getError().isIncludeException());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(value = {ErrorController.class}, search = SearchStrategy.CURRENT)
/*     */   public BasicErrorController basicErrorController(ErrorAttributes errorAttributes, ObjectProvider<ErrorViewResolver> errorViewResolvers) {
/* 110 */     return new BasicErrorController(errorAttributes, this.serverProperties.getError(), (List<ErrorViewResolver>)errorViewResolvers
/* 111 */         .orderedStream().collect(Collectors.toList()));
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public ErrorPageCustomizer errorPageCustomizer(DispatcherServletPath dispatcherServletPath) {
/* 116 */     return new ErrorPageCustomizer(this.serverProperties, dispatcherServletPath);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public static PreserveErrorControllerTargetClassPostProcessor preserveErrorControllerTargetClassPostProcessor() {
/* 121 */     return new PreserveErrorControllerTargetClassPostProcessor();
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class DefaultErrorViewResolverConfiguration
/*     */   {
/*     */     private final ApplicationContext applicationContext;
/*     */     
/*     */     private final ResourceProperties resourceProperties;
/*     */     
/*     */     DefaultErrorViewResolverConfiguration(ApplicationContext applicationContext, ResourceProperties resourceProperties) {
/* 133 */       this.applicationContext = applicationContext;
/* 134 */       this.resourceProperties = resourceProperties;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnBean({DispatcherServlet.class})
/*     */     @ConditionalOnMissingBean({ErrorViewResolver.class})
/*     */     DefaultErrorViewResolver conventionErrorViewResolver() {
/* 141 */       return new DefaultErrorViewResolver(this.applicationContext, this.resourceProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnProperty(prefix = "server.error.whitelabel", name = {"enabled"}, matchIfMissing = true)
/*     */   @Conditional({ErrorTemplateMissingCondition.class})
/*     */   protected static class WhitelabelErrorViewConfiguration
/*     */   {
/* 151 */     private final ErrorMvcAutoConfiguration.StaticView defaultErrorView = new ErrorMvcAutoConfiguration.StaticView();
/*     */     
/*     */     @Bean(name = {"error"})
/*     */     @ConditionalOnMissingBean(name = {"error"})
/*     */     public View defaultErrorView() {
/* 156 */       return this.defaultErrorView;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public BeanNameViewResolver beanNameViewResolver() {
/* 164 */       BeanNameViewResolver resolver = new BeanNameViewResolver();
/* 165 */       resolver.setOrder(2147483637);
/* 166 */       return resolver;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ErrorTemplateMissingCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 178 */       ConditionMessage.Builder message = ConditionMessage.forCondition("ErrorTemplate Missing", new Object[0]);
/* 179 */       TemplateAvailabilityProviders providers = new TemplateAvailabilityProviders(context.getClassLoader());
/* 180 */       TemplateAvailabilityProvider provider = providers.getProvider("error", context.getEnvironment(), context
/* 181 */           .getClassLoader(), context.getResourceLoader());
/* 182 */       if (provider != null) {
/* 183 */         return ConditionOutcome.noMatch(message.foundExactly("template from " + provider));
/*     */       }
/* 185 */       return ConditionOutcome.match(message.didNotFind("error template view").atAll());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StaticView
/*     */     implements View
/*     */   {
/*     */     private StaticView() {}
/*     */     
/* 195 */     private static final MediaType TEXT_HTML_UTF8 = new MediaType("text", "html", StandardCharsets.UTF_8);
/*     */     
/* 197 */     private static final Log logger = LogFactory.getLog(StaticView.class);
/*     */ 
/*     */ 
/*     */     
/*     */     public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 202 */       if (response.isCommitted()) {
/* 203 */         String str = getMessage(model);
/* 204 */         logger.error(str);
/*     */         return;
/*     */       } 
/* 207 */       response.setContentType(TEXT_HTML_UTF8.toString());
/* 208 */       StringBuilder builder = new StringBuilder();
/* 209 */       Date timestamp = (Date)model.get("timestamp");
/* 210 */       Object message = model.get("message");
/* 211 */       Object trace = model.get("trace");
/* 212 */       if (response.getContentType() == null) {
/* 213 */         response.setContentType(getContentType());
/*     */       }
/* 215 */       builder.append("<html><body><h1>Whitelabel Error Page</h1>").append("<p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p>")
/*     */         
/* 217 */         .append("<div id='created'>").append(timestamp).append("</div>")
/* 218 */         .append("<div>There was an unexpected error (type=").append(htmlEscape(model.get("error")))
/* 219 */         .append(", status=").append(htmlEscape(model.get("status"))).append(").</div>");
/* 220 */       if (message != null) {
/* 221 */         builder.append("<div>").append(htmlEscape(message)).append("</div>");
/*     */       }
/* 223 */       if (trace != null) {
/* 224 */         builder.append("<div style='white-space:pre-wrap;'>").append(htmlEscape(trace)).append("</div>");
/*     */       }
/* 226 */       builder.append("</body></html>");
/* 227 */       response.getWriter().append(builder.toString());
/*     */     }
/*     */     
/*     */     private String htmlEscape(Object input) {
/* 231 */       return (input != null) ? HtmlUtils.htmlEscape(input.toString()) : null;
/*     */     }
/*     */     
/*     */     private String getMessage(Map<String, ?> model) {
/* 235 */       Object path = model.get("path");
/* 236 */       String message = "Cannot render error page for request [" + path + "]";
/* 237 */       if (model.get("message") != null) {
/* 238 */         message = message + " and exception [" + model.get("message") + "]";
/*     */       }
/* 240 */       message = message + " as the response has already been committed.";
/* 241 */       message = message + " As a result, the response may have the wrong status code.";
/* 242 */       return message;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContentType() {
/* 247 */       return "text/html";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ErrorPageCustomizer
/*     */     implements ErrorPageRegistrar, Ordered
/*     */   {
/*     */     private final ServerProperties properties;
/*     */     
/*     */     private final DispatcherServletPath dispatcherServletPath;
/*     */ 
/*     */     
/*     */     protected ErrorPageCustomizer(ServerProperties properties, DispatcherServletPath dispatcherServletPath) {
/* 262 */       this.properties = properties;
/* 263 */       this.dispatcherServletPath = dispatcherServletPath;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void registerErrorPages(ErrorPageRegistry errorPageRegistry) {
/* 269 */       ErrorPage errorPage = new ErrorPage(this.dispatcherServletPath.getRelativePath(this.properties.getError().getPath()));
/* 270 */       errorPageRegistry.addErrorPages(new ErrorPage[] { errorPage });
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 275 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class PreserveErrorControllerTargetClassPostProcessor
/*     */     implements BeanFactoryPostProcessor
/*     */   {
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/* 288 */       String[] errorControllerBeans = beanFactory.getBeanNamesForType(ErrorController.class, false, false);
/* 289 */       for (String errorControllerBean : errorControllerBeans) {
/*     */         try {
/* 291 */           beanFactory.getBeanDefinition(errorControllerBean)
/* 292 */             .setAttribute(AutoProxyUtils.PRESERVE_TARGET_CLASS_ATTRIBUTE, Boolean.TRUE);
/*     */         }
/* 294 */         catch (Throwable throwable) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\error\ErrorMvcAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
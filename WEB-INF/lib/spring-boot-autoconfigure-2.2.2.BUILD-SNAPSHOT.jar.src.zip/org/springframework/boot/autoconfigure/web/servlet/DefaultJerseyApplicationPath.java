/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import javax.ws.rs.ApplicationPath;
/*    */ import org.glassfish.jersey.server.ResourceConfig;
/*    */ import org.springframework.core.annotation.MergedAnnotations;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultJerseyApplicationPath
/*    */   implements JerseyApplicationPath
/*    */ {
/*    */   private final String applicationPath;
/*    */   private final ResourceConfig config;
/*    */   
/*    */   public DefaultJerseyApplicationPath(String applicationPath, ResourceConfig config) {
/* 42 */     this.applicationPath = applicationPath;
/* 43 */     this.config = config;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPath() {
/* 48 */     return resolveApplicationPath();
/*    */   }
/*    */   
/*    */   private String resolveApplicationPath() {
/* 52 */     if (StringUtils.hasLength(this.applicationPath)) {
/* 53 */       return this.applicationPath;
/*    */     }
/*    */     
/* 56 */     return MergedAnnotations.from(this.config.getApplication().getClass(), MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/* 57 */       .get(ApplicationPath.class).getValue("value", String.class).orElse("/*");
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\DefaultJerseyApplicationPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
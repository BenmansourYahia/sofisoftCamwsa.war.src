/*     */ package org.springframework.boot.autoconfigure.web.servlet.error;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProvider;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProviders;
/*     */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultErrorViewResolver
/*     */   implements ErrorViewResolver, Ordered
/*     */ {
/*     */   private static final Map<HttpStatus.Series, String> SERIES_VIEWS;
/*     */   private ApplicationContext applicationContext;
/*     */   private final ResourceProperties resourceProperties;
/*     */   private final TemplateAvailabilityProviders templateAvailabilityProviders;
/*     */   
/*     */   static {
/*  63 */     Map<HttpStatus.Series, String> views = new EnumMap<>(HttpStatus.Series.class);
/*  64 */     views.put(HttpStatus.Series.CLIENT_ERROR, "4xx");
/*  65 */     views.put(HttpStatus.Series.SERVER_ERROR, "5xx");
/*  66 */     SERIES_VIEWS = Collections.unmodifiableMap(views);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private int order = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultErrorViewResolver(ApplicationContext applicationContext, ResourceProperties resourceProperties) {
/*  83 */     Assert.notNull(applicationContext, "ApplicationContext must not be null");
/*  84 */     Assert.notNull(resourceProperties, "ResourceProperties must not be null");
/*  85 */     this.applicationContext = applicationContext;
/*  86 */     this.resourceProperties = resourceProperties;
/*  87 */     this.templateAvailabilityProviders = new TemplateAvailabilityProviders(applicationContext);
/*     */   }
/*     */ 
/*     */   
/*     */   DefaultErrorViewResolver(ApplicationContext applicationContext, ResourceProperties resourceProperties, TemplateAvailabilityProviders templateAvailabilityProviders) {
/*  92 */     Assert.notNull(applicationContext, "ApplicationContext must not be null");
/*  93 */     Assert.notNull(resourceProperties, "ResourceProperties must not be null");
/*  94 */     this.applicationContext = applicationContext;
/*  95 */     this.resourceProperties = resourceProperties;
/*  96 */     this.templateAvailabilityProviders = templateAvailabilityProviders;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelAndView resolveErrorView(HttpServletRequest request, HttpStatus status, Map<String, Object> model) {
/* 101 */     ModelAndView modelAndView = resolve(String.valueOf(status.value()), model);
/* 102 */     if (modelAndView == null && SERIES_VIEWS.containsKey(status.series())) {
/* 103 */       modelAndView = resolve(SERIES_VIEWS.get(status.series()), model);
/*     */     }
/* 105 */     return modelAndView;
/*     */   }
/*     */   
/*     */   private ModelAndView resolve(String viewName, Map<String, Object> model) {
/* 109 */     String errorViewName = "error/" + viewName;
/* 110 */     TemplateAvailabilityProvider provider = this.templateAvailabilityProviders.getProvider(errorViewName, this.applicationContext);
/*     */     
/* 112 */     if (provider != null) {
/* 113 */       return new ModelAndView(errorViewName, model);
/*     */     }
/* 115 */     return resolveResource(errorViewName, model);
/*     */   }
/*     */   
/*     */   private ModelAndView resolveResource(String viewName, Map<String, Object> model) {
/* 119 */     for (String location : this.resourceProperties.getStaticLocations()) {
/*     */       try {
/* 121 */         Resource resource = this.applicationContext.getResource(location);
/* 122 */         resource = resource.createRelative(viewName + ".html");
/* 123 */         if (resource.exists()) {
/* 124 */           return new ModelAndView(new HtmlResourceView(resource), model);
/*     */         }
/*     */       }
/* 127 */       catch (Exception exception) {}
/*     */     } 
/*     */     
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 135 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 139 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HtmlResourceView
/*     */     implements View
/*     */   {
/*     */     private Resource resource;
/*     */ 
/*     */     
/*     */     HtmlResourceView(Resource resource) {
/* 150 */       this.resource = resource;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContentType() {
/* 155 */       return "text/html";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 161 */       response.setContentType(getContentType());
/* 162 */       FileCopyUtils.copy(this.resource.getInputStream(), (OutputStream)response.getOutputStream());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\error\DefaultErrorViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
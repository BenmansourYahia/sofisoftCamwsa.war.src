/*    */ package org.springframework.boot.autoconfigure.web.reactive;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.boot.web.reactive.server.ConfigurableReactiveWebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactiveWebServerFactoryCustomizer
/*    */   implements WebServerFactoryCustomizer<ConfigurableReactiveWebServerFactory>, Ordered
/*    */ {
/*    */   private final ServerProperties serverProperties;
/*    */   
/*    */   public ReactiveWebServerFactoryCustomizer(ServerProperties serverProperties) {
/* 39 */     this.serverProperties = serverProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 44 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(ConfigurableReactiveWebServerFactory factory) {
/* 49 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 50 */     map.from(this.serverProperties::getPort).to(factory::setPort);
/* 51 */     map.from(this.serverProperties::getAddress).to(factory::setAddress);
/* 52 */     map.from(this.serverProperties::getSsl).to(factory::setSsl);
/* 53 */     map.from(this.serverProperties::getCompression).to(factory::setCompression);
/* 54 */     map.from(this.serverProperties::getHttp2).to(factory::setHttp2);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\ReactiveWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import org.apache.catalina.Context;
/*    */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*    */ import org.springframework.boot.web.embedded.tomcat.ConfigurableTomcatWebServerFactory;
/*    */ import org.springframework.boot.web.embedded.tomcat.TomcatContextCustomizer;
/*    */ import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TomcatServletWebServerFactoryCustomizer
/*    */   implements WebServerFactoryCustomizer<TomcatServletWebServerFactory>, Ordered
/*    */ {
/*    */   private final ServerProperties serverProperties;
/*    */   
/*    */   public TomcatServletWebServerFactoryCustomizer(ServerProperties serverProperties) {
/* 40 */     this.serverProperties = serverProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 45 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(TomcatServletWebServerFactory factory) {
/* 50 */     ServerProperties.Tomcat tomcatProperties = this.serverProperties.getTomcat();
/* 51 */     if (!ObjectUtils.isEmpty(tomcatProperties.getAdditionalTldSkipPatterns())) {
/* 52 */       factory.getTldSkipPatterns().addAll(tomcatProperties.getAdditionalTldSkipPatterns());
/*    */     }
/* 54 */     if (tomcatProperties.getRedirectContextRoot() != null) {
/* 55 */       customizeRedirectContextRoot((ConfigurableTomcatWebServerFactory)factory, tomcatProperties.getRedirectContextRoot().booleanValue());
/*    */     }
/* 57 */     if (tomcatProperties.getUseRelativeRedirects() != null) {
/* 58 */       customizeUseRelativeRedirects((ConfigurableTomcatWebServerFactory)factory, tomcatProperties.getUseRelativeRedirects().booleanValue());
/*    */     }
/* 60 */     factory.setDisableMBeanRegistry(!tomcatProperties.getMbeanregistry().isEnabled());
/*    */   }
/*    */   
/*    */   private void customizeRedirectContextRoot(ConfigurableTomcatWebServerFactory factory, boolean redirectContextRoot) {
/* 64 */     factory.addContextCustomizers(new TomcatContextCustomizer[] { context -> context.setMapperContextRootRedirectEnabled(redirectContextRoot) });
/*    */   }
/*    */ 
/*    */   
/*    */   private void customizeUseRelativeRedirects(ConfigurableTomcatWebServerFactory factory, boolean useRelativeRedirects) {
/* 69 */     factory.addContextCustomizers(new TomcatContextCustomizer[] { context -> context.setUseRelativeRedirects(useRelativeRedirects) });
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\TomcatServletWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
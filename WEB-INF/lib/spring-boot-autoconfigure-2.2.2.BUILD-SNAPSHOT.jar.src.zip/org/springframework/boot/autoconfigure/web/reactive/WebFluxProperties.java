/*    */ package org.springframework.boot.autoconfigure.web.reactive;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.webflux")
/*    */ public class WebFluxProperties
/*    */ {
/*    */   private String dateFormat;
/* 38 */   private String staticPathPattern = "/**";
/*    */   
/*    */   public String getDateFormat() {
/* 41 */     return this.dateFormat;
/*    */   }
/*    */   
/*    */   public void setDateFormat(String dateFormat) {
/* 45 */     this.dateFormat = dateFormat;
/*    */   }
/*    */   
/*    */   public String getStaticPathPattern() {
/* 49 */     return this.staticPathPattern;
/*    */   }
/*    */   
/*    */   public void setStaticPathPattern(String staticPathPattern) {
/* 53 */     this.staticPathPattern = staticPathPattern;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\WebFluxProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
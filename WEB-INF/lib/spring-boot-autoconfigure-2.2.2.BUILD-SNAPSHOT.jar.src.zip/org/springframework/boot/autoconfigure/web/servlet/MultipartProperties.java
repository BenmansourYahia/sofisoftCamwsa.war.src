/*     */ package org.springframework.boot.autoconfigure.web.servlet;
/*     */ 
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.web.servlet.MultipartConfigFactory;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.servlet.multipart", ignoreUnknownFields = false)
/*     */ public class MultipartProperties
/*     */ {
/*     */   private boolean enabled = true;
/*     */   private String location;
/*  64 */   private DataSize maxFileSize = DataSize.ofMegabytes(1L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private DataSize maxRequestSize = DataSize.ofMegabytes(10L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private DataSize fileSizeThreshold = DataSize.ofBytes(0L);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean resolveLazily = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getEnabled() {
/*  83 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  87 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public String getLocation() {
/*  91 */     return this.location;
/*     */   }
/*     */   
/*     */   public void setLocation(String location) {
/*  95 */     this.location = location;
/*     */   }
/*     */   
/*     */   public DataSize getMaxFileSize() {
/*  99 */     return this.maxFileSize;
/*     */   }
/*     */   
/*     */   public void setMaxFileSize(DataSize maxFileSize) {
/* 103 */     this.maxFileSize = maxFileSize;
/*     */   }
/*     */   
/*     */   public DataSize getMaxRequestSize() {
/* 107 */     return this.maxRequestSize;
/*     */   }
/*     */   
/*     */   public void setMaxRequestSize(DataSize maxRequestSize) {
/* 111 */     this.maxRequestSize = maxRequestSize;
/*     */   }
/*     */   
/*     */   public DataSize getFileSizeThreshold() {
/* 115 */     return this.fileSizeThreshold;
/*     */   }
/*     */   
/*     */   public void setFileSizeThreshold(DataSize fileSizeThreshold) {
/* 119 */     this.fileSizeThreshold = fileSizeThreshold;
/*     */   }
/*     */   
/*     */   public boolean isResolveLazily() {
/* 123 */     return this.resolveLazily;
/*     */   }
/*     */   
/*     */   public void setResolveLazily(boolean resolveLazily) {
/* 127 */     this.resolveLazily = resolveLazily;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartConfigElement createMultipartConfig() {
/* 135 */     MultipartConfigFactory factory = new MultipartConfigFactory();
/* 136 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 137 */     map.from(this.fileSizeThreshold).to(factory::setFileSizeThreshold);
/* 138 */     map.from(this.location).whenHasText().to(factory::setLocation);
/* 139 */     map.from(this.maxRequestSize).to(factory::setMaxRequestSize);
/* 140 */     map.from(this.maxFileSize).to(factory::setMaxFileSize);
/* 141 */     return factory.createMultipartConfig();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\MultipartProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
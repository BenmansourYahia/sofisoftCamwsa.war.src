/*     */ package org.springframework.boot.autoconfigure.web.embedded;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.jetty.server.AbstractConnector;
/*     */ import org.eclipse.jetty.server.ConnectionFactory;
/*     */ import org.eclipse.jetty.server.Connector;
/*     */ import org.eclipse.jetty.server.CustomRequestLog;
/*     */ import org.eclipse.jetty.server.Handler;
/*     */ import org.eclipse.jetty.server.HttpConfiguration;
/*     */ import org.eclipse.jetty.server.RequestLog;
/*     */ import org.eclipse.jetty.server.RequestLogWriter;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.server.handler.ContextHandler;
/*     */ import org.eclipse.jetty.server.handler.HandlerCollection;
/*     */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*     */ import org.eclipse.jetty.util.thread.QueuedThreadPool;
/*     */ import org.eclipse.jetty.util.thread.ThreadPool;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.cloud.CloudPlatform;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.web.embedded.jetty.ConfigurableJettyWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.jetty.JettyServerCustomizer;
/*     */ import org.springframework.boot.web.server.WebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyWebServerFactoryCustomizer
/*     */   implements WebServerFactoryCustomizer<ConfigurableJettyWebServerFactory>, Ordered
/*     */ {
/*     */   private final Environment environment;
/*     */   private final ServerProperties serverProperties;
/*     */   
/*     */   public JettyWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/*  64 */     this.environment = environment;
/*  65 */     this.serverProperties = serverProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  70 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void customize(ConfigurableJettyWebServerFactory factory) {
/*  75 */     ServerProperties properties = this.serverProperties;
/*  76 */     ServerProperties.Jetty jettyProperties = properties.getJetty();
/*  77 */     factory.setUseForwardHeaders(getOrDeduceUseForwardHeaders());
/*  78 */     PropertyMapper propertyMapper = PropertyMapper.get();
/*  79 */     propertyMapper.from(jettyProperties::getAcceptors).whenNonNull().to(factory::setAcceptors);
/*  80 */     propertyMapper.from(jettyProperties::getSelectors).whenNonNull().to(factory::setSelectors);
/*  81 */     propertyMapper.from(properties::getMaxHttpHeaderSize).whenNonNull().asInt(DataSize::toBytes)
/*  82 */       .when(this::isPositive).to(maxHttpHeaderSize -> factory.addServerCustomizers(new JettyServerCustomizer[] { new MaxHttpHeaderSizeCustomizer(maxHttpHeaderSize.intValue()) }));
/*     */     
/*  84 */     propertyMapper.from(jettyProperties::getMaxHttpFormPostSize).asInt(DataSize::toBytes).when(this::isPositive)
/*  85 */       .to(maxHttpFormPostSize -> customizeMaxHttpFormPostSize(factory, maxHttpFormPostSize.intValue()));
/*  86 */     propertyMapper.from(jettyProperties::getMaxThreads).when(this::isPositive)
/*  87 */       .to(maxThreads -> customizeThreadPool(factory, ()));
/*  88 */     propertyMapper.from(jettyProperties::getMinThreads).when(this::isPositive)
/*  89 */       .to(minThreads -> customizeThreadPool(factory, ()));
/*  90 */     propertyMapper.from(jettyProperties::getThreadIdleTimeout).whenNonNull().asInt(Duration::toMillis).to(idleTimeout -> customizeThreadPool(factory, ()));
/*     */     
/*  92 */     propertyMapper.from(properties::getConnectionTimeout).whenNonNull()
/*  93 */       .to(connectionTimeout -> customizeIdleTimeout(factory, connectionTimeout));
/*  94 */     propertyMapper.from(jettyProperties::getConnectionIdleTimeout).whenNonNull()
/*  95 */       .to(idleTimeout -> customizeIdleTimeout(factory, idleTimeout));
/*  96 */     propertyMapper.from(jettyProperties::getAccesslog).when(ServerProperties.Jetty.Accesslog::isEnabled)
/*  97 */       .to(accesslog -> customizeAccessLog(factory, accesslog));
/*     */   }
/*     */   
/*     */   private boolean isPositive(Integer value) {
/* 101 */     return (value.intValue() > 0);
/*     */   }
/*     */   
/*     */   private boolean getOrDeduceUseForwardHeaders() {
/* 105 */     if (this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NONE)) {
/* 106 */       CloudPlatform platform = CloudPlatform.getActive(this.environment);
/* 107 */       return (platform != null && platform.isUsingForwardHeaders());
/*     */     } 
/* 109 */     return this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NATIVE);
/*     */   }
/*     */   
/*     */   private void customizeIdleTimeout(ConfigurableJettyWebServerFactory factory, Duration connectionTimeout) {
/* 113 */     factory.addServerCustomizers(new JettyServerCustomizer[] { server -> {
/*     */             for (Connector connector : server.getConnectors()) {
/*     */               if (connector instanceof AbstractConnector) {
/*     */                 ((AbstractConnector)connector).setIdleTimeout(connectionTimeout.toMillis());
/*     */               }
/*     */             } 
/*     */           } });
/*     */   }
/*     */   
/*     */   private void customizeMaxHttpFormPostSize(ConfigurableJettyWebServerFactory factory, final int maxHttpFormPostSize) {
/* 123 */     factory.addServerCustomizers(new JettyServerCustomizer[] { new JettyServerCustomizer()
/*     */           {
/*     */             public void customize(Server server)
/*     */             {
/* 127 */               setHandlerMaxHttpFormPostSize(server.getHandlers());
/*     */             }
/*     */             
/*     */             private void setHandlerMaxHttpFormPostSize(Handler... handlers) {
/* 131 */               for (Handler handler : handlers) {
/* 132 */                 if (handler instanceof ContextHandler) {
/* 133 */                   ((ContextHandler)handler).setMaxFormContentSize(maxHttpFormPostSize);
/*     */                 }
/* 135 */                 else if (handler instanceof HandlerWrapper) {
/* 136 */                   setHandlerMaxHttpFormPostSize(new Handler[] { ((HandlerWrapper)handler).getHandler() });
/*     */                 }
/* 138 */                 else if (handler instanceof HandlerCollection) {
/* 139 */                   setHandlerMaxHttpFormPostSize(((HandlerCollection)handler).getHandlers());
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } });
/*     */   }
/*     */ 
/*     */   
/*     */   private void customizeThreadPool(ConfigurableJettyWebServerFactory factory, Consumer<QueuedThreadPool> customizer) {
/* 148 */     factory.addServerCustomizers(new JettyServerCustomizer[] { connector -> {
/*     */             ThreadPool threadPool = connector.getThreadPool();
/*     */             if (threadPool instanceof QueuedThreadPool) {
/*     */               customizer.accept((QueuedThreadPool)threadPool);
/*     */             }
/*     */           } });
/*     */   }
/*     */ 
/*     */   
/*     */   private void customizeAccessLog(ConfigurableJettyWebServerFactory factory, ServerProperties.Jetty.Accesslog properties) {
/* 158 */     factory.addServerCustomizers(new JettyServerCustomizer[] { server -> {
/*     */             RequestLogWriter logWriter = new RequestLogWriter();
/*     */             String format = getLogFormat(properties);
/*     */             CustomRequestLog log = new CustomRequestLog((RequestLog.Writer)logWriter, format);
/*     */             if (!CollectionUtils.isEmpty(properties.getIgnorePaths())) {
/*     */               log.setIgnorePaths((String[])properties.getIgnorePaths().toArray((Object[])new String[0]));
/*     */             }
/*     */             if (properties.getFilename() != null) {
/*     */               logWriter.setFilename(properties.getFilename());
/*     */             }
/*     */             if (properties.getFileDateFormat() != null) {
/*     */               logWriter.setFilenameDateFormat(properties.getFileDateFormat());
/*     */             }
/*     */             logWriter.setRetainDays(properties.getRetentionPeriod());
/*     */             logWriter.setAppend(properties.isAppend());
/*     */             server.setRequestLog((RequestLog)log);
/*     */           } });
/*     */   }
/*     */   
/*     */   private String getLogFormat(ServerProperties.Jetty.Accesslog properties) {
/* 178 */     if (properties.getCustomFormat() != null) {
/* 179 */       return properties.getCustomFormat();
/*     */     }
/* 181 */     if (ServerProperties.Jetty.Accesslog.FORMAT.EXTENDED_NCSA.equals(properties.getFormat())) {
/* 182 */       return "%{client}a - %u %t \"%r\" %s %O \"%{Referer}i\" \"%{User-Agent}i\"";
/*     */     }
/* 184 */     return "%{client}a - %u %t \"%r\" %s %O";
/*     */   }
/*     */   
/*     */   private static class MaxHttpHeaderSizeCustomizer
/*     */     implements JettyServerCustomizer {
/*     */     private final int maxHttpHeaderSize;
/*     */     
/*     */     MaxHttpHeaderSizeCustomizer(int maxHttpHeaderSize) {
/* 192 */       this.maxHttpHeaderSize = maxHttpHeaderSize;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(Server server) {
/* 197 */       Arrays.<Connector>stream(server.getConnectors()).forEach(this::customize);
/*     */     }
/*     */     
/*     */     private void customize(Connector connector) {
/* 201 */       connector.getConnectionFactories().forEach(this::customize);
/*     */     }
/*     */     
/*     */     private void customize(ConnectionFactory factory) {
/* 205 */       if (factory instanceof HttpConfiguration.ConnectionFactory)
/* 206 */         ((HttpConfiguration.ConnectionFactory)factory).getHttpConfiguration()
/* 207 */           .setRequestHeaderSize(this.maxHttpHeaderSize); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\embedded\JettyWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
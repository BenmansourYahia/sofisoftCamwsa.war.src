/*     */ package org.springframework.boot.autoconfigure.web.servlet;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.DefaultMessageCodesResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.mvc")
/*     */ public class WebMvcProperties
/*     */ {
/*     */   private DefaultMessageCodesResolver.Format messageCodesResolverFormat;
/*     */   private Locale locale;
/*  56 */   private LocaleResolver localeResolver = LocaleResolver.ACCEPT_HEADER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String dateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dispatchTraceRequest = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dispatchOptionsRequest = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreDefaultModelOnRedirect = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean publishRequestHandledEvents = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean throwExceptionIfNoHandlerFound = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean logResolvedException = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private String staticPathPattern = "/**";
/*     */   
/* 101 */   private final Async async = new Async();
/*     */   
/* 103 */   private final Servlet servlet = new Servlet();
/*     */   
/* 105 */   private final View view = new View();
/*     */   
/* 107 */   private final Contentnegotiation contentnegotiation = new Contentnegotiation();
/*     */   
/* 109 */   private final Pathmatch pathmatch = new Pathmatch();
/*     */   
/*     */   public DefaultMessageCodesResolver.Format getMessageCodesResolverFormat() {
/* 112 */     return this.messageCodesResolverFormat;
/*     */   }
/*     */   
/*     */   public void setMessageCodesResolverFormat(DefaultMessageCodesResolver.Format messageCodesResolverFormat) {
/* 116 */     this.messageCodesResolverFormat = messageCodesResolverFormat;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 120 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 124 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public LocaleResolver getLocaleResolver() {
/* 128 */     return this.localeResolver;
/*     */   }
/*     */   
/*     */   public void setLocaleResolver(LocaleResolver localeResolver) {
/* 132 */     this.localeResolver = localeResolver;
/*     */   }
/*     */   
/*     */   public String getDateFormat() {
/* 136 */     return this.dateFormat;
/*     */   }
/*     */   
/*     */   public void setDateFormat(String dateFormat) {
/* 140 */     this.dateFormat = dateFormat;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreDefaultModelOnRedirect() {
/* 144 */     return this.ignoreDefaultModelOnRedirect;
/*     */   }
/*     */   
/*     */   public void setIgnoreDefaultModelOnRedirect(boolean ignoreDefaultModelOnRedirect) {
/* 148 */     this.ignoreDefaultModelOnRedirect = ignoreDefaultModelOnRedirect;
/*     */   }
/*     */   
/*     */   public boolean isPublishRequestHandledEvents() {
/* 152 */     return this.publishRequestHandledEvents;
/*     */   }
/*     */   
/*     */   public void setPublishRequestHandledEvents(boolean publishRequestHandledEvents) {
/* 156 */     this.publishRequestHandledEvents = publishRequestHandledEvents;
/*     */   }
/*     */   
/*     */   public boolean isThrowExceptionIfNoHandlerFound() {
/* 160 */     return this.throwExceptionIfNoHandlerFound;
/*     */   }
/*     */   
/*     */   public void setThrowExceptionIfNoHandlerFound(boolean throwExceptionIfNoHandlerFound) {
/* 164 */     this.throwExceptionIfNoHandlerFound = throwExceptionIfNoHandlerFound;
/*     */   }
/*     */   
/*     */   public boolean isLogResolvedException() {
/* 168 */     return this.logResolvedException;
/*     */   }
/*     */   
/*     */   public void setLogResolvedException(boolean logResolvedException) {
/* 172 */     this.logResolvedException = logResolvedException;
/*     */   }
/*     */   
/*     */   public boolean isDispatchOptionsRequest() {
/* 176 */     return this.dispatchOptionsRequest;
/*     */   }
/*     */   
/*     */   public void setDispatchOptionsRequest(boolean dispatchOptionsRequest) {
/* 180 */     this.dispatchOptionsRequest = dispatchOptionsRequest;
/*     */   }
/*     */   
/*     */   public boolean isDispatchTraceRequest() {
/* 184 */     return this.dispatchTraceRequest;
/*     */   }
/*     */   
/*     */   public void setDispatchTraceRequest(boolean dispatchTraceRequest) {
/* 188 */     this.dispatchTraceRequest = dispatchTraceRequest;
/*     */   }
/*     */   
/*     */   public String getStaticPathPattern() {
/* 192 */     return this.staticPathPattern;
/*     */   }
/*     */   
/*     */   public void setStaticPathPattern(String staticPathPattern) {
/* 196 */     this.staticPathPattern = staticPathPattern;
/*     */   }
/*     */   
/*     */   public Async getAsync() {
/* 200 */     return this.async;
/*     */   }
/*     */   
/*     */   public Servlet getServlet() {
/* 204 */     return this.servlet;
/*     */   }
/*     */   
/*     */   public View getView() {
/* 208 */     return this.view;
/*     */   }
/*     */   
/*     */   public Contentnegotiation getContentnegotiation() {
/* 212 */     return this.contentnegotiation;
/*     */   }
/*     */   
/*     */   public Pathmatch getPathmatch() {
/* 216 */     return this.pathmatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Async
/*     */   {
/*     */     private Duration requestTimeout;
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getRequestTimeout() {
/* 229 */       return this.requestTimeout;
/*     */     }
/*     */     
/*     */     public void setRequestTimeout(Duration requestTimeout) {
/* 233 */       this.requestTimeout = requestTimeout;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Servlet
/*     */   {
/* 243 */     private String path = "/";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     private int loadOnStartup = -1;
/*     */     
/*     */     public String getPath() {
/* 251 */       return this.path;
/*     */     }
/*     */     
/*     */     public void setPath(String path) {
/* 255 */       Assert.notNull(path, "Path must not be null");
/* 256 */       Assert.isTrue(!path.contains("*"), "Path must not contain wildcards");
/* 257 */       this.path = path;
/*     */     }
/*     */     
/*     */     public int getLoadOnStartup() {
/* 261 */       return this.loadOnStartup;
/*     */     }
/*     */     
/*     */     public void setLoadOnStartup(int loadOnStartup) {
/* 265 */       this.loadOnStartup = loadOnStartup;
/*     */     }
/*     */     
/*     */     public String getServletMapping() {
/* 269 */       if (this.path.equals("") || this.path.equals("/")) {
/* 270 */         return "/";
/*     */       }
/* 272 */       if (this.path.endsWith("/")) {
/* 273 */         return this.path + "*";
/*     */       }
/* 275 */       return this.path + "/*";
/*     */     }
/*     */     
/*     */     public String getPath(String path) {
/* 279 */       String prefix = getServletPrefix();
/* 280 */       if (!path.startsWith("/")) {
/* 281 */         path = "/" + path;
/*     */       }
/* 283 */       return prefix + path;
/*     */     }
/*     */     
/*     */     public String getServletPrefix() {
/* 287 */       String result = this.path;
/* 288 */       int index = result.indexOf('*');
/* 289 */       if (index != -1) {
/* 290 */         result = result.substring(0, index);
/*     */       }
/* 292 */       if (result.endsWith("/")) {
/* 293 */         result = result.substring(0, result.length() - 1);
/*     */       }
/* 295 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class View
/*     */   {
/*     */     private String prefix;
/*     */ 
/*     */ 
/*     */     
/*     */     private String suffix;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getPrefix() {
/* 313 */       return this.prefix;
/*     */     }
/*     */     
/*     */     public void setPrefix(String prefix) {
/* 317 */       this.prefix = prefix;
/*     */     }
/*     */     
/*     */     public String getSuffix() {
/* 321 */       return this.suffix;
/*     */     }
/*     */     
/*     */     public void setSuffix(String suffix) {
/* 325 */       this.suffix = suffix;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Contentnegotiation
/*     */   {
/*     */     private boolean favorPathExtension = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean favorParameter = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 349 */     private Map<String, MediaType> mediaTypes = new LinkedHashMap<>();
/*     */ 
/*     */     
/*     */     private String parameterName;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isFavorPathExtension() {
/* 357 */       return this.favorPathExtension;
/*     */     }
/*     */     
/*     */     public void setFavorPathExtension(boolean favorPathExtension) {
/* 361 */       this.favorPathExtension = favorPathExtension;
/*     */     }
/*     */     
/*     */     public boolean isFavorParameter() {
/* 365 */       return this.favorParameter;
/*     */     }
/*     */     
/*     */     public void setFavorParameter(boolean favorParameter) {
/* 369 */       this.favorParameter = favorParameter;
/*     */     }
/*     */     
/*     */     public Map<String, MediaType> getMediaTypes() {
/* 373 */       return this.mediaTypes;
/*     */     }
/*     */     
/*     */     public void setMediaTypes(Map<String, MediaType> mediaTypes) {
/* 377 */       this.mediaTypes = mediaTypes;
/*     */     }
/*     */     
/*     */     public String getParameterName() {
/* 381 */       return this.parameterName;
/*     */     }
/*     */     
/*     */     public void setParameterName(String parameterName) {
/* 385 */       this.parameterName = parameterName;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pathmatch
/*     */   {
/*     */     private boolean useSuffixPattern = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean useRegisteredSuffixPattern = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isUseSuffixPattern() {
/* 407 */       return this.useSuffixPattern;
/*     */     }
/*     */     
/*     */     public void setUseSuffixPattern(boolean useSuffixPattern) {
/* 411 */       this.useSuffixPattern = useSuffixPattern;
/*     */     }
/*     */     
/*     */     public boolean isUseRegisteredSuffixPattern() {
/* 415 */       return this.useRegisteredSuffixPattern;
/*     */     }
/*     */     
/*     */     public void setUseRegisteredSuffixPattern(boolean useRegisteredSuffixPattern) {
/* 419 */       this.useRegisteredSuffixPattern = useRegisteredSuffixPattern;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum LocaleResolver
/*     */   {
/* 429 */     FIXED,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 435 */     ACCEPT_HEADER;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\WebMvcProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
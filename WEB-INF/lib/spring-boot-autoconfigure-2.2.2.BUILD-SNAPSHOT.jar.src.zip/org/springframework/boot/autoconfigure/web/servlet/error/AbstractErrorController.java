/*     */ package org.springframework.boot.autoconfigure.web.servlet.error;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.boot.web.servlet.error.ErrorAttributes;
/*     */ import org.springframework.boot.web.servlet.error.ErrorController;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractErrorController
/*     */   implements ErrorController
/*     */ {
/*     */   private final ErrorAttributes errorAttributes;
/*     */   private final List<ErrorViewResolver> errorViewResolvers;
/*     */   
/*     */   public AbstractErrorController(ErrorAttributes errorAttributes) {
/*  51 */     this(errorAttributes, null);
/*     */   }
/*     */   
/*     */   public AbstractErrorController(ErrorAttributes errorAttributes, List<ErrorViewResolver> errorViewResolvers) {
/*  55 */     Assert.notNull(errorAttributes, "ErrorAttributes must not be null");
/*  56 */     this.errorAttributes = errorAttributes;
/*  57 */     this.errorViewResolvers = sortErrorViewResolvers(errorViewResolvers);
/*     */   }
/*     */   
/*     */   private List<ErrorViewResolver> sortErrorViewResolvers(List<ErrorViewResolver> resolvers) {
/*  61 */     List<ErrorViewResolver> sorted = new ArrayList<>();
/*  62 */     if (resolvers != null) {
/*  63 */       sorted.addAll(resolvers);
/*  64 */       AnnotationAwareOrderComparator.sortIfNecessary(sorted);
/*     */     } 
/*  66 */     return sorted;
/*     */   }
/*     */   
/*     */   protected Map<String, Object> getErrorAttributes(HttpServletRequest request, boolean includeStackTrace) {
/*  70 */     ServletWebRequest servletWebRequest = new ServletWebRequest(request);
/*  71 */     return this.errorAttributes.getErrorAttributes((WebRequest)servletWebRequest, includeStackTrace);
/*     */   }
/*     */   
/*     */   protected boolean getTraceParameter(HttpServletRequest request) {
/*  75 */     String parameter = request.getParameter("trace");
/*  76 */     if (parameter == null) {
/*  77 */       return false;
/*     */     }
/*  79 */     return !"false".equalsIgnoreCase(parameter);
/*     */   }
/*     */   
/*     */   protected HttpStatus getStatus(HttpServletRequest request) {
/*  83 */     Integer statusCode = (Integer)request.getAttribute("javax.servlet.error.status_code");
/*  84 */     if (statusCode == null) {
/*  85 */       return HttpStatus.INTERNAL_SERVER_ERROR;
/*     */     }
/*     */     try {
/*  88 */       return HttpStatus.valueOf(statusCode.intValue());
/*     */     }
/*  90 */     catch (Exception ex) {
/*  91 */       return HttpStatus.INTERNAL_SERVER_ERROR;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView resolveErrorView(HttpServletRequest request, HttpServletResponse response, HttpStatus status, Map<String, Object> model) {
/* 108 */     for (ErrorViewResolver resolver : this.errorViewResolvers) {
/* 109 */       ModelAndView modelAndView = resolver.resolveErrorView(request, status, model);
/* 110 */       if (modelAndView != null) {
/* 111 */         return modelAndView;
/*     */       }
/*     */     } 
/* 114 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\error\AbstractErrorController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
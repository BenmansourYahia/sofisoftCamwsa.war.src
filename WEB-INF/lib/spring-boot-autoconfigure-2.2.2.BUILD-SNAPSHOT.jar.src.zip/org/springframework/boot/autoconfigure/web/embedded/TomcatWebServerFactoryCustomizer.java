/*     */ package org.springframework.boot.autoconfigure.web.embedded;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.valves.AccessLogValve;
/*     */ import org.apache.catalina.valves.ErrorReportValve;
/*     */ import org.apache.catalina.valves.RemoteIpValve;
/*     */ import org.apache.coyote.AbstractProtocol;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.coyote.http11.AbstractHttp11Protocol;
/*     */ import org.springframework.boot.autoconfigure.web.ErrorProperties;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.cloud.CloudPlatform;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.web.embedded.tomcat.ConfigurableTomcatWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
/*     */ import org.springframework.boot.web.embedded.tomcat.TomcatContextCustomizer;
/*     */ import org.springframework.boot.web.server.WebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatWebServerFactoryCustomizer
/*     */   implements WebServerFactoryCustomizer<ConfigurableTomcatWebServerFactory>, Ordered
/*     */ {
/*     */   private final Environment environment;
/*     */   private final ServerProperties serverProperties;
/*     */   
/*     */   public TomcatWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/*  68 */     this.environment = environment;
/*  69 */     this.serverProperties = serverProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  74 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void customize(ConfigurableTomcatWebServerFactory factory) {
/*  79 */     ServerProperties properties = this.serverProperties;
/*  80 */     ServerProperties.Tomcat tomcatProperties = properties.getTomcat();
/*  81 */     PropertyMapper propertyMapper = PropertyMapper.get();
/*  82 */     propertyMapper.from(tomcatProperties::getBasedir).whenNonNull().to(factory::setBaseDirectory);
/*  83 */     propertyMapper.from(tomcatProperties::getBackgroundProcessorDelay).whenNonNull().as(Duration::getSeconds)
/*  84 */       .as(Long::intValue).to(factory::setBackgroundProcessorDelay);
/*  85 */     customizeRemoteIpValve(factory);
/*  86 */     propertyMapper.from(tomcatProperties::getMaxThreads).when(this::isPositive)
/*  87 */       .to(maxThreads -> customizeMaxThreads(factory, tomcatProperties.getMaxThreads()));
/*  88 */     propertyMapper.from(tomcatProperties::getMinSpareThreads).when(this::isPositive)
/*  89 */       .to(minSpareThreads -> customizeMinThreads(factory, minSpareThreads.intValue()));
/*  90 */     propertyMapper.from(this.serverProperties.getMaxHttpHeaderSize()).whenNonNull().asInt(DataSize::toBytes)
/*  91 */       .when(this::isPositive)
/*  92 */       .to(maxHttpHeaderSize -> customizeMaxHttpHeaderSize(factory, maxHttpHeaderSize.intValue()));
/*  93 */     propertyMapper.from(tomcatProperties::getMaxSwallowSize).whenNonNull().asInt(DataSize::toBytes)
/*  94 */       .to(maxSwallowSize -> customizeMaxSwallowSize(factory, maxSwallowSize.intValue()));
/*  95 */     propertyMapper.from(tomcatProperties::getMaxHttpFormPostSize).asInt(DataSize::toBytes)
/*  96 */       .when(maxHttpFormPostSize -> (maxHttpFormPostSize.intValue() != 0))
/*  97 */       .to(maxHttpFormPostSize -> customizeMaxHttpFormPostSize(factory, maxHttpFormPostSize.intValue()));
/*  98 */     propertyMapper.from(tomcatProperties::getAccesslog).when(ServerProperties.Tomcat.Accesslog::isEnabled)
/*  99 */       .to(enabled -> customizeAccessLog(factory));
/* 100 */     propertyMapper.from(tomcatProperties::getUriEncoding).whenNonNull().to(factory::setUriEncoding);
/* 101 */     propertyMapper.from(properties::getConnectionTimeout).whenNonNull()
/* 102 */       .to(connectionTimeout -> customizeConnectionTimeout(factory, connectionTimeout));
/* 103 */     propertyMapper.from(tomcatProperties::getConnectionTimeout).whenNonNull()
/* 104 */       .to(connectionTimeout -> customizeConnectionTimeout(factory, connectionTimeout));
/* 105 */     propertyMapper.from(tomcatProperties::getMaxConnections).when(this::isPositive)
/* 106 */       .to(maxConnections -> customizeMaxConnections(factory, maxConnections.intValue()));
/* 107 */     propertyMapper.from(tomcatProperties::getAcceptCount).when(this::isPositive)
/* 108 */       .to(acceptCount -> customizeAcceptCount(factory, acceptCount.intValue()));
/* 109 */     propertyMapper.from(tomcatProperties::getProcessorCache)
/* 110 */       .to(processorCache -> customizeProcessorCache(factory, processorCache.intValue()));
/* 111 */     propertyMapper.from(tomcatProperties::getRelaxedPathChars).as(this::joinCharacters).whenHasText()
/* 112 */       .to(relaxedChars -> customizeRelaxedPathChars(factory, relaxedChars));
/* 113 */     propertyMapper.from(tomcatProperties::getRelaxedQueryChars).as(this::joinCharacters).whenHasText()
/* 114 */       .to(relaxedChars -> customizeRelaxedQueryChars(factory, relaxedChars));
/* 115 */     customizeStaticResources(factory);
/* 116 */     customizeErrorReportValve(properties.getError(), factory);
/*     */   }
/*     */   
/*     */   private boolean isPositive(int value) {
/* 120 */     return (value > 0);
/*     */   }
/*     */   
/*     */   private void customizeAcceptCount(ConfigurableTomcatWebServerFactory factory, int acceptCount) {
/* 124 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractProtocol) {
/*     */               AbstractProtocol<?> protocol = (AbstractProtocol)handler;
/*     */               protocol.setAcceptCount(acceptCount);
/*     */             } 
/*     */           } });
/*     */   }
/*     */   
/*     */   private void customizeProcessorCache(ConfigurableTomcatWebServerFactory factory, int processorCache) {
/* 134 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractProtocol) {
/*     */               ((AbstractProtocol)handler).setProcessorCache(processorCache);
/*     */             }
/*     */           } });
/*     */   }
/*     */   
/*     */   private void customizeMaxConnections(ConfigurableTomcatWebServerFactory factory, int maxConnections) {
/* 143 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractProtocol) {
/*     */               AbstractProtocol<?> protocol = (AbstractProtocol)handler;
/*     */               protocol.setMaxConnections(maxConnections);
/*     */             } 
/*     */           } });
/*     */   }
/*     */   
/*     */   private void customizeConnectionTimeout(ConfigurableTomcatWebServerFactory factory, Duration connectionTimeout) {
/* 153 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractProtocol) {
/*     */               AbstractProtocol<?> protocol = (AbstractProtocol)handler;
/*     */               protocol.setConnectionTimeout((int)connectionTimeout.toMillis());
/*     */             } 
/*     */           } });
/*     */   }
/*     */   
/*     */   private void customizeRelaxedPathChars(ConfigurableTomcatWebServerFactory factory, String relaxedChars) {
/* 163 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> connector.setAttribute("relaxedPathChars", relaxedChars) });
/*     */   }
/*     */   
/*     */   private void customizeRelaxedQueryChars(ConfigurableTomcatWebServerFactory factory, String relaxedChars) {
/* 167 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> connector.setAttribute("relaxedQueryChars", relaxedChars) });
/*     */   }
/*     */   
/*     */   private String joinCharacters(List<Character> content) {
/* 171 */     return content.stream().map(String::valueOf).collect(Collectors.joining());
/*     */   }
/*     */   
/*     */   private void customizeRemoteIpValve(ConfigurableTomcatWebServerFactory factory) {
/* 175 */     ServerProperties.Tomcat tomcatProperties = this.serverProperties.getTomcat();
/* 176 */     String protocolHeader = tomcatProperties.getProtocolHeader();
/* 177 */     String remoteIpHeader = tomcatProperties.getRemoteIpHeader();
/*     */     
/* 179 */     if (StringUtils.hasText(protocolHeader) || StringUtils.hasText(remoteIpHeader) || 
/* 180 */       getOrDeduceUseForwardHeaders()) {
/* 181 */       RemoteIpValve valve = new RemoteIpValve();
/* 182 */       valve.setProtocolHeader(StringUtils.hasLength(protocolHeader) ? protocolHeader : "X-Forwarded-Proto");
/* 183 */       if (StringUtils.hasLength(remoteIpHeader)) {
/* 184 */         valve.setRemoteIpHeader(remoteIpHeader);
/*     */       }
/*     */ 
/*     */       
/* 188 */       valve.setInternalProxies(tomcatProperties.getInternalProxies());
/* 189 */       valve.setHostHeader(tomcatProperties.getHostHeader());
/* 190 */       valve.setPortHeader(tomcatProperties.getPortHeader());
/* 191 */       valve.setProtocolHeaderHttpsValue(tomcatProperties.getProtocolHeaderHttpsValue());
/*     */       
/* 193 */       factory.addEngineValves(new Valve[] { (Valve)valve });
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean getOrDeduceUseForwardHeaders() {
/* 198 */     if (this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NONE)) {
/* 199 */       CloudPlatform platform = CloudPlatform.getActive(this.environment);
/* 200 */       return (platform != null && platform.isUsingForwardHeaders());
/*     */     } 
/* 202 */     return this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NATIVE);
/*     */   }
/*     */ 
/*     */   
/*     */   private void customizeMaxThreads(ConfigurableTomcatWebServerFactory factory, int maxThreads) {
/* 207 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractProtocol) {
/*     */               AbstractProtocol protocol = (AbstractProtocol)handler;
/*     */               protocol.setMaxThreads(maxThreads);
/*     */             } 
/*     */           } });
/*     */   }
/*     */ 
/*     */   
/*     */   private void customizeMinThreads(ConfigurableTomcatWebServerFactory factory, int minSpareThreads) {
/* 218 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractProtocol) {
/*     */               AbstractProtocol protocol = (AbstractProtocol)handler;
/*     */               protocol.setMinSpareThreads(minSpareThreads);
/*     */             } 
/*     */           } });
/*     */   }
/*     */ 
/*     */   
/*     */   private void customizeMaxHttpHeaderSize(ConfigurableTomcatWebServerFactory factory, int maxHttpHeaderSize) {
/* 229 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractHttp11Protocol) {
/*     */               AbstractHttp11Protocol protocol = (AbstractHttp11Protocol)handler;
/*     */               protocol.setMaxHttpHeaderSize(maxHttpHeaderSize);
/*     */             } 
/*     */           } });
/*     */   }
/*     */   
/*     */   private void customizeMaxSwallowSize(ConfigurableTomcatWebServerFactory factory, int maxSwallowSize) {
/* 239 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> {
/*     */             ProtocolHandler handler = connector.getProtocolHandler();
/*     */             if (handler instanceof AbstractHttp11Protocol) {
/*     */               AbstractHttp11Protocol<?> protocol = (AbstractHttp11Protocol)handler;
/*     */               protocol.setMaxSwallowSize(maxSwallowSize);
/*     */             } 
/*     */           } });
/*     */   }
/*     */   
/*     */   private void customizeMaxHttpFormPostSize(ConfigurableTomcatWebServerFactory factory, int maxHttpFormPostSize) {
/* 249 */     factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { connector -> connector.setMaxPostSize(maxHttpFormPostSize) });
/*     */   }
/*     */   
/*     */   private void customizeAccessLog(ConfigurableTomcatWebServerFactory factory) {
/* 253 */     ServerProperties.Tomcat tomcatProperties = this.serverProperties.getTomcat();
/* 254 */     AccessLogValve valve = new AccessLogValve();
/* 255 */     PropertyMapper map = PropertyMapper.get();
/* 256 */     ServerProperties.Tomcat.Accesslog accessLogConfig = tomcatProperties.getAccesslog();
/* 257 */     map.from(accessLogConfig.getConditionIf()).to(valve::setConditionIf);
/* 258 */     map.from(accessLogConfig.getConditionUnless()).to(valve::setConditionUnless);
/* 259 */     map.from(accessLogConfig.getPattern()).to(valve::setPattern);
/* 260 */     map.from(accessLogConfig.getDirectory()).to(valve::setDirectory);
/* 261 */     map.from(accessLogConfig.getPrefix()).to(valve::setPrefix);
/* 262 */     map.from(accessLogConfig.getSuffix()).to(valve::setSuffix);
/* 263 */     map.from(accessLogConfig.getEncoding()).whenHasText().to(valve::setEncoding);
/* 264 */     map.from(accessLogConfig.getLocale()).whenHasText().to(valve::setLocale);
/* 265 */     map.from(Boolean.valueOf(accessLogConfig.isCheckExists())).to(valve::setCheckExists);
/* 266 */     map.from(Boolean.valueOf(accessLogConfig.isRotate())).to(valve::setRotatable);
/* 267 */     map.from(Boolean.valueOf(accessLogConfig.isRenameOnRotate())).to(valve::setRenameOnRotate);
/* 268 */     map.from(Integer.valueOf(accessLogConfig.getMaxDays())).to(valve::setMaxDays);
/* 269 */     map.from(accessLogConfig.getFileDateFormat()).to(valve::setFileDateFormat);
/* 270 */     map.from(Boolean.valueOf(accessLogConfig.isIpv6Canonical())).to(valve::setIpv6Canonical);
/* 271 */     map.from(Boolean.valueOf(accessLogConfig.isRequestAttributesEnabled())).to(valve::setRequestAttributesEnabled);
/* 272 */     map.from(Boolean.valueOf(accessLogConfig.isBuffered())).to(valve::setBuffered);
/* 273 */     factory.addEngineValves(new Valve[] { (Valve)valve });
/*     */   }
/*     */   
/*     */   private void customizeStaticResources(ConfigurableTomcatWebServerFactory factory) {
/* 277 */     ServerProperties.Tomcat.Resource resource = this.serverProperties.getTomcat().getResource();
/* 278 */     factory.addContextCustomizers(new TomcatContextCustomizer[] { context -> context.addLifecycleListener(()) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void customizeErrorReportValve(ErrorProperties error, ConfigurableTomcatWebServerFactory factory) {
/* 292 */     if (error.getIncludeStacktrace() == ErrorProperties.IncludeStacktrace.NEVER)
/* 293 */       factory.addContextCustomizers(new TomcatContextCustomizer[] { context -> {
/*     */               ErrorReportValve valve = new ErrorReportValve();
/*     */               valve.setShowServerInfo(false);
/*     */               valve.setShowReport(false);
/*     */               context.getParent().getPipeline().addValve((Valve)valve);
/*     */             } }); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\embedded\TomcatWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
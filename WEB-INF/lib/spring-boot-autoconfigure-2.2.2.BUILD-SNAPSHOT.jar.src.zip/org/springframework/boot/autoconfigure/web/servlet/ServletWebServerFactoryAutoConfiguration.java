/*     */ package org.springframework.boot.autoconfigure.web.servlet;
/*     */ 
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.ServletRequest;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.server.ErrorPageRegistrarBeanPostProcessor;
/*     */ import org.springframework.boot.web.server.WebServerFactoryCustomizerBeanPostProcessor;
/*     */ import org.springframework.boot.web.servlet.FilterRegistrationBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.filter.ForwardedHeaderFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @AutoConfigureOrder(-2147483648)
/*     */ @ConditionalOnClass({ServletRequest.class})
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @EnableConfigurationProperties({ServerProperties.class})
/*     */ @Import({ServletWebServerFactoryAutoConfiguration.BeanPostProcessorsRegistrar.class, ServletWebServerFactoryConfiguration.EmbeddedTomcat.class, ServletWebServerFactoryConfiguration.EmbeddedJetty.class, ServletWebServerFactoryConfiguration.EmbeddedUndertow.class})
/*     */ public class ServletWebServerFactoryAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   public ServletWebServerFactoryCustomizer servletWebServerFactoryCustomizer(ServerProperties serverProperties) {
/*  71 */     return new ServletWebServerFactoryCustomizer(serverProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnClass(name = {"org.apache.catalina.startup.Tomcat"})
/*     */   public TomcatServletWebServerFactoryCustomizer tomcatServletWebServerFactoryCustomizer(ServerProperties serverProperties) {
/*  78 */     return new TomcatServletWebServerFactoryCustomizer(serverProperties);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingFilterBean({ForwardedHeaderFilter.class})
/*     */   @ConditionalOnProperty(value = {"server.forward-headers-strategy"}, havingValue = "framework")
/*     */   public FilterRegistrationBean<ForwardedHeaderFilter> forwardedHeaderFilter() {
/*  85 */     ForwardedHeaderFilter filter = new ForwardedHeaderFilter();
/*  86 */     FilterRegistrationBean<ForwardedHeaderFilter> registration = new FilterRegistrationBean((Filter)filter, new org.springframework.boot.web.servlet.ServletRegistrationBean[0]);
/*  87 */     registration.setDispatcherTypes(DispatcherType.REQUEST, new DispatcherType[] { DispatcherType.ASYNC, DispatcherType.ERROR });
/*  88 */     registration.setOrder(-2147483648);
/*  89 */     return registration;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class BeanPostProcessorsRegistrar
/*     */     implements ImportBeanDefinitionRegistrar, BeanFactoryAware
/*     */   {
/*     */     private ConfigurableListableBeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 102 */       if (beanFactory instanceof ConfigurableListableBeanFactory) {
/* 103 */         this.beanFactory = (ConfigurableListableBeanFactory)beanFactory;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 110 */       if (this.beanFactory == null) {
/*     */         return;
/*     */       }
/* 113 */       registerSyntheticBeanIfMissing(registry, "webServerFactoryCustomizerBeanPostProcessor", WebServerFactoryCustomizerBeanPostProcessor.class);
/*     */       
/* 115 */       registerSyntheticBeanIfMissing(registry, "errorPageRegistrarBeanPostProcessor", ErrorPageRegistrarBeanPostProcessor.class);
/*     */     }
/*     */ 
/*     */     
/*     */     private void registerSyntheticBeanIfMissing(BeanDefinitionRegistry registry, String name, Class<?> beanClass) {
/* 120 */       if (ObjectUtils.isEmpty((Object[])this.beanFactory.getBeanNamesForType(beanClass, true, false))) {
/* 121 */         RootBeanDefinition beanDefinition = new RootBeanDefinition(beanClass);
/* 122 */         beanDefinition.setSynthetic(true);
/* 123 */         registry.registerBeanDefinition(name, (BeanDefinition)beanDefinition);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\ServletWebServerFactoryAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.web.embedded;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import io.undertow.UndertowOptions;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.nio.charset.Charset;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.cloud.CloudPlatform;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.web.embedded.undertow.ConfigurableUndertowWebServerFactory;
/*     */ import org.springframework.boot.web.embedded.undertow.UndertowBuilderCustomizer;
/*     */ import org.springframework.boot.web.server.WebServerFactory;
/*     */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ import org.xnio.Option;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowWebServerFactoryCustomizer
/*     */   implements WebServerFactoryCustomizer<ConfigurableUndertowWebServerFactory>, Ordered
/*     */ {
/*     */   private final Environment environment;
/*     */   private final ServerProperties serverProperties;
/*     */   
/*     */   public UndertowWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/*  65 */     this.environment = environment;
/*  66 */     this.serverProperties = serverProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  71 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void customize(ConfigurableUndertowWebServerFactory factory) {
/*  76 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  77 */     FactoryOptions options = new FactoryOptions(factory);
/*  78 */     ServerProperties properties = this.serverProperties;
/*  79 */     map.from(properties::getMaxHttpHeaderSize).asInt(DataSize::toBytes).when(this::isPositive)
/*  80 */       .to(options.server(UndertowOptions.MAX_HEADER_SIZE));
/*  81 */     map.from(properties::getConnectionTimeout).asInt(Duration::toMillis)
/*  82 */       .to(options.server(UndertowOptions.NO_REQUEST_TIMEOUT));
/*  83 */     mapUndertowProperties(factory, options);
/*  84 */     mapAccessLogProperties(factory);
/*  85 */     map.from(this::getOrDeduceUseForwardHeaders).to(factory::setUseForwardHeaders);
/*     */   }
/*     */   
/*     */   private void mapUndertowProperties(ConfigurableUndertowWebServerFactory factory, FactoryOptions options) {
/*  89 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  90 */     ServerProperties.Undertow properties = this.serverProperties.getUndertow();
/*  91 */     map.from(properties::getBufferSize).whenNonNull().asInt(DataSize::toBytes).to(factory::setBufferSize);
/*  92 */     map.from(properties::getIoThreads).to(factory::setIoThreads);
/*  93 */     map.from(properties::getWorkerThreads).to(factory::setWorkerThreads);
/*  94 */     map.from(properties::getDirectBuffers).to(factory::setUseDirectBuffers);
/*  95 */     map.from(properties::getMaxHttpPostSize).as(DataSize::toBytes).when(this::isPositive)
/*  96 */       .to(options.server(UndertowOptions.MAX_ENTITY_SIZE));
/*  97 */     map.from(properties::getMaxParameters).to(options.server(UndertowOptions.MAX_PARAMETERS));
/*  98 */     map.from(properties::getMaxHeaders).to(options.server(UndertowOptions.MAX_HEADERS));
/*  99 */     map.from(properties::getMaxCookies).to(options.server(UndertowOptions.MAX_COOKIES));
/* 100 */     map.from(properties::isAllowEncodedSlash).to(options.server(UndertowOptions.ALLOW_ENCODED_SLASH));
/* 101 */     map.from(properties::isDecodeUrl).to(options.server(UndertowOptions.DECODE_URL));
/* 102 */     map.from(properties::getUrlCharset).as(Charset::name).to(options.server(UndertowOptions.URL_CHARSET));
/* 103 */     map.from(properties::isAlwaysSetKeepAlive).to(options.server(UndertowOptions.ALWAYS_SET_KEEP_ALIVE));
/* 104 */     map.from(properties::getNoRequestTimeout).asInt(Duration::toMillis)
/* 105 */       .to(options.server(UndertowOptions.NO_REQUEST_TIMEOUT));
/* 106 */     map.from(properties.getOptions()::getServer).to(options.forEach(options::server));
/* 107 */     map.from(properties.getOptions()::getSocket).to(options.forEach(options::socket));
/*     */   }
/*     */   
/*     */   private boolean isPositive(Number value) {
/* 111 */     return (value.longValue() > 0L);
/*     */   }
/*     */   
/*     */   private void mapAccessLogProperties(ConfigurableUndertowWebServerFactory factory) {
/* 115 */     ServerProperties.Undertow.Accesslog properties = this.serverProperties.getUndertow().getAccesslog();
/* 116 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 117 */     map.from(properties::isEnabled).to(factory::setAccessLogEnabled);
/* 118 */     map.from(properties::getDir).to(factory::setAccessLogDirectory);
/* 119 */     map.from(properties::getPattern).to(factory::setAccessLogPattern);
/* 120 */     map.from(properties::getPrefix).to(factory::setAccessLogPrefix);
/* 121 */     map.from(properties::getSuffix).to(factory::setAccessLogSuffix);
/* 122 */     map.from(properties::isRotate).to(factory::setAccessLogRotate);
/*     */   }
/*     */   
/*     */   private boolean getOrDeduceUseForwardHeaders() {
/* 126 */     if (this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NONE)) {
/* 127 */       CloudPlatform platform = CloudPlatform.getActive(this.environment);
/* 128 */       return (platform != null && platform.isUsingForwardHeaders());
/*     */     } 
/* 130 */     return this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NATIVE);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class FactoryOptions
/*     */   {
/*     */     private static final Map<String, Option<?>> NAME_LOOKUP;
/*     */     
/*     */     private final ConfigurableUndertowWebServerFactory factory;
/*     */     
/*     */     static {
/* 141 */       Map<String, Option<?>> lookup = new HashMap<>();
/* 142 */       ReflectionUtils.doWithLocalFields(UndertowOptions.class, field -> {
/*     */             int modifiers = field.getModifiers();
/*     */             
/*     */             if (Modifier.isPublic(modifiers) && Modifier.isStatic(modifiers) && Option.class.isAssignableFrom(field.getType())) {
/*     */               try {
/*     */                 Option<?> option = (Option)field.get(null);
/*     */                 
/*     */                 lookup.put(getCanonicalName(field.getName()), option);
/* 150 */               } catch (IllegalAccessException illegalAccessException) {}
/*     */             }
/*     */           });
/*     */       
/* 154 */       NAME_LOOKUP = Collections.unmodifiableMap(lookup);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     FactoryOptions(ConfigurableUndertowWebServerFactory factory) {
/* 160 */       this.factory = factory;
/*     */     }
/*     */     
/*     */     <T> Consumer<T> server(Option<T> option) {
/* 164 */       return value -> this.factory.addBuilderCustomizers(new UndertowBuilderCustomizer[] { () });
/*     */     }
/*     */     
/*     */     <T> Consumer<T> socket(Option<T> option) {
/* 168 */       return value -> this.factory.addBuilderCustomizers(new UndertowBuilderCustomizer[] { () });
/*     */     }
/*     */ 
/*     */     
/*     */     <T> Consumer<Map<String, String>> forEach(Function<Option<T>, Consumer<T>> function) {
/* 173 */       return map -> map.forEach(());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static String getCanonicalName(String name) {
/* 184 */       StringBuilder canonicalName = new StringBuilder(name.length());
/* 185 */       name.chars().filter(Character::isLetterOrDigit).map(Character::toLowerCase)
/* 186 */         .forEach(c -> canonicalName.append((char)c));
/* 187 */       return canonicalName.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\embedded\UndertowWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
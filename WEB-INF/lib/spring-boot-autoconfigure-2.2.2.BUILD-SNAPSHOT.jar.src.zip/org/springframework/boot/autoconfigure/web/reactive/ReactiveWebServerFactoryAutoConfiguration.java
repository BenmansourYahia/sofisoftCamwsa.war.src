/*     */ package org.springframework.boot.autoconfigure.web.reactive;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.server.WebServerFactoryCustomizerBeanPostProcessor;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.http.ReactiveHttpInputMessage;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.server.adapter.ForwardedHeaderTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfigureOrder(-2147483648)
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({ReactiveHttpInputMessage.class})
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*     */ @EnableConfigurationProperties({ServerProperties.class})
/*     */ @Import({ReactiveWebServerFactoryAutoConfiguration.BeanPostProcessorsRegistrar.class, ReactiveWebServerFactoryConfiguration.EmbeddedTomcat.class, ReactiveWebServerFactoryConfiguration.EmbeddedJetty.class, ReactiveWebServerFactoryConfiguration.EmbeddedUndertow.class, ReactiveWebServerFactoryConfiguration.EmbeddedNetty.class})
/*     */ public class ReactiveWebServerFactoryAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   public ReactiveWebServerFactoryCustomizer reactiveWebServerFactoryCustomizer(ServerProperties serverProperties) {
/*  64 */     return new ReactiveWebServerFactoryCustomizer(serverProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnClass(name = {"org.apache.catalina.startup.Tomcat"})
/*     */   public TomcatReactiveWebServerFactoryCustomizer tomcatReactiveWebServerFactoryCustomizer(ServerProperties serverProperties) {
/*  71 */     return new TomcatReactiveWebServerFactoryCustomizer(serverProperties);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnProperty(value = {"server.forward-headers-strategy"}, havingValue = "framework")
/*     */   public ForwardedHeaderTransformer forwardedHeaderTransformer() {
/*  78 */     return new ForwardedHeaderTransformer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class BeanPostProcessorsRegistrar
/*     */     implements ImportBeanDefinitionRegistrar, BeanFactoryAware
/*     */   {
/*     */     private ConfigurableListableBeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/*  91 */       if (beanFactory instanceof ConfigurableListableBeanFactory) {
/*  92 */         this.beanFactory = (ConfigurableListableBeanFactory)beanFactory;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/*  99 */       if (this.beanFactory == null) {
/*     */         return;
/*     */       }
/* 102 */       registerSyntheticBeanIfMissing(registry, "webServerFactoryCustomizerBeanPostProcessor", WebServerFactoryCustomizerBeanPostProcessor.class);
/*     */     }
/*     */ 
/*     */     
/*     */     private void registerSyntheticBeanIfMissing(BeanDefinitionRegistry registry, String name, Class<?> beanClass) {
/* 107 */       if (ObjectUtils.isEmpty((Object[])this.beanFactory.getBeanNamesForType(beanClass, true, false))) {
/* 108 */         RootBeanDefinition beanDefinition = new RootBeanDefinition(beanClass);
/* 109 */         beanDefinition.setSynthetic(true);
/* 110 */         registry.registerBeanDefinition(name, (BeanDefinition)beanDefinition);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\ReactiveWebServerFactoryAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.web.servlet.error;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.boot.autoconfigure.web.ErrorProperties;
/*     */ import org.springframework.boot.web.servlet.error.ErrorAttributes;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Controller
/*     */ @RequestMapping({"${server.error.path:${error.path:/error}}"})
/*     */ public class BasicErrorController
/*     */   extends AbstractErrorController
/*     */ {
/*     */   private final ErrorProperties errorProperties;
/*     */   
/*     */   public BasicErrorController(ErrorAttributes errorAttributes, ErrorProperties errorProperties) {
/*  64 */     this(errorAttributes, errorProperties, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicErrorController(ErrorAttributes errorAttributes, ErrorProperties errorProperties, List<ErrorViewResolver> errorViewResolvers) {
/*  75 */     super(errorAttributes, errorViewResolvers);
/*  76 */     Assert.notNull(errorProperties, "ErrorProperties must not be null");
/*  77 */     this.errorProperties = errorProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErrorPath() {
/*  82 */     return this.errorProperties.getPath();
/*     */   }
/*     */   
/*     */   @RequestMapping(produces = {"text/html"})
/*     */   public ModelAndView errorHtml(HttpServletRequest request, HttpServletResponse response) {
/*  87 */     HttpStatus status = getStatus(request);
/*     */     
/*  89 */     Map<String, Object> model = Collections.unmodifiableMap(getErrorAttributes(request, isIncludeStackTrace(request, MediaType.TEXT_HTML)));
/*  90 */     response.setStatus(status.value());
/*  91 */     ModelAndView modelAndView = resolveErrorView(request, response, status, model);
/*  92 */     return (modelAndView != null) ? modelAndView : new ModelAndView("error", model);
/*     */   }
/*     */   
/*     */   @RequestMapping
/*     */   public ResponseEntity<Map<String, Object>> error(HttpServletRequest request) {
/*  97 */     HttpStatus status = getStatus(request);
/*  98 */     if (status == HttpStatus.NO_CONTENT) {
/*  99 */       return new ResponseEntity(status);
/*     */     }
/* 101 */     Map<String, Object> body = getErrorAttributes(request, isIncludeStackTrace(request, MediaType.ALL));
/* 102 */     return new ResponseEntity(body, status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isIncludeStackTrace(HttpServletRequest request, MediaType produces) {
/* 112 */     ErrorProperties.IncludeStacktrace include = getErrorProperties().getIncludeStacktrace();
/* 113 */     if (include == ErrorProperties.IncludeStacktrace.ALWAYS) {
/* 114 */       return true;
/*     */     }
/* 116 */     if (include == ErrorProperties.IncludeStacktrace.ON_TRACE_PARAM) {
/* 117 */       return getTraceParameter(request);
/*     */     }
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ErrorProperties getErrorProperties() {
/* 127 */     return this.errorProperties;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\error\BasicErrorController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
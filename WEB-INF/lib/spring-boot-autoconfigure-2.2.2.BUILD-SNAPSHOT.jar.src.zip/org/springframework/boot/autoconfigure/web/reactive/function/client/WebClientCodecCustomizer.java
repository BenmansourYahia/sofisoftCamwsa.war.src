/*    */ package org.springframework.boot.autoconfigure.web.reactive.function.client;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.web.codec.CodecCustomizer;
/*    */ import org.springframework.boot.web.reactive.function.client.WebClientCustomizer;
/*    */ import org.springframework.http.codec.ClientCodecConfigurer;
/*    */ import org.springframework.http.codec.CodecConfigurer;
/*    */ import org.springframework.web.reactive.function.client.ExchangeStrategies;
/*    */ import org.springframework.web.reactive.function.client.WebClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebClientCodecCustomizer
/*    */   implements WebClientCustomizer
/*    */ {
/*    */   private final List<CodecCustomizer> codecCustomizers;
/*    */   
/*    */   public WebClientCodecCustomizer(List<CodecCustomizer> codecCustomizers) {
/* 37 */     this.codecCustomizers = codecCustomizers;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(WebClient.Builder webClientBuilder) {
/* 42 */     webClientBuilder.exchangeStrategies(ExchangeStrategies.builder()
/* 43 */         .codecs(codecs -> this.codecCustomizers.forEach(()))
/* 44 */         .build());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\function\client\WebClientCodecCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
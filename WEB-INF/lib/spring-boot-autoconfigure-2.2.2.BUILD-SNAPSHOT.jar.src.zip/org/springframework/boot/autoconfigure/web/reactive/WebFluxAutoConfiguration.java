/*     */ package org.springframework.boot.autoconfigure.web.reactive;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.http.codec.CodecsAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.validation.ValidatorAdapter;
/*     */ import org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain;
/*     */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*     */ import org.springframework.boot.autoconfigure.web.format.WebConversionService;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.boot.web.codec.CodecCustomizer;
/*     */ import org.springframework.boot.web.reactive.filter.OrderedHiddenHttpMethodFilter;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.support.FormattingConversionService;
/*     */ import org.springframework.http.codec.CodecConfigurer;
/*     */ import org.springframework.http.codec.ServerCodecConfigurer;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.filter.reactive.HiddenHttpMethodFilter;
/*     */ import org.springframework.web.reactive.config.DelegatingWebFluxConfiguration;
/*     */ import org.springframework.web.reactive.config.ResourceHandlerRegistration;
/*     */ import org.springframework.web.reactive.config.ResourceHandlerRegistry;
/*     */ import org.springframework.web.reactive.config.ViewResolverRegistry;
/*     */ import org.springframework.web.reactive.config.WebFluxConfigurationSupport;
/*     */ import org.springframework.web.reactive.config.WebFluxConfigurer;
/*     */ import org.springframework.web.reactive.result.method.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.reactive.result.method.annotation.ArgumentResolverConfigurer;
/*     */ import org.springframework.web.reactive.result.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.reactive.result.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.reactive.result.view.ViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*     */ @ConditionalOnClass({WebFluxConfigurer.class})
/*     */ @ConditionalOnMissingBean({WebFluxConfigurationSupport.class})
/*     */ @AutoConfigureAfter({ReactiveWebServerFactoryAutoConfiguration.class, CodecsAutoConfiguration.class, ValidationAutoConfiguration.class})
/*     */ @AutoConfigureOrder(-2147483638)
/*     */ public class WebFluxAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({HiddenHttpMethodFilter.class})
/*     */   @ConditionalOnProperty(prefix = "spring.webflux.hiddenmethod.filter", name = {"enabled"}, matchIfMissing = false)
/*     */   public OrderedHiddenHttpMethodFilter hiddenHttpMethodFilter() {
/*  91 */     return new OrderedHiddenHttpMethodFilter();
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @EnableConfigurationProperties({ResourceProperties.class, WebFluxProperties.class})
/*     */   @Import({EnableWebFluxConfiguration.class})
/*     */   public static class WebFluxConfig
/*     */     implements WebFluxConfigurer {
/*  99 */     private static final Log logger = LogFactory.getLog(WebFluxConfig.class);
/*     */ 
/*     */     
/*     */     private final ResourceProperties resourceProperties;
/*     */ 
/*     */     
/*     */     private final WebFluxProperties webFluxProperties;
/*     */ 
/*     */     
/*     */     private final ListableBeanFactory beanFactory;
/*     */     
/*     */     private final ObjectProvider<HandlerMethodArgumentResolver> argumentResolvers;
/*     */     
/*     */     private final ObjectProvider<CodecCustomizer> codecCustomizers;
/*     */     
/*     */     private final ResourceHandlerRegistrationCustomizer resourceHandlerRegistrationCustomizer;
/*     */     
/*     */     private final ObjectProvider<ViewResolver> viewResolvers;
/*     */ 
/*     */     
/*     */     public WebFluxConfig(ResourceProperties resourceProperties, WebFluxProperties webFluxProperties, ListableBeanFactory beanFactory, ObjectProvider<HandlerMethodArgumentResolver> resolvers, ObjectProvider<CodecCustomizer> codecCustomizers, ObjectProvider<ResourceHandlerRegistrationCustomizer> resourceHandlerRegistrationCustomizer, ObjectProvider<ViewResolver> viewResolvers) {
/* 120 */       this.resourceProperties = resourceProperties;
/* 121 */       this.webFluxProperties = webFluxProperties;
/* 122 */       this.beanFactory = beanFactory;
/* 123 */       this.argumentResolvers = resolvers;
/* 124 */       this.codecCustomizers = codecCustomizers;
/* 125 */       this.resourceHandlerRegistrationCustomizer = (ResourceHandlerRegistrationCustomizer)resourceHandlerRegistrationCustomizer.getIfAvailable();
/* 126 */       this.viewResolvers = viewResolvers;
/*     */     }
/*     */ 
/*     */     
/*     */     public void configureArgumentResolvers(ArgumentResolverConfigurer configurer) {
/* 131 */       this.argumentResolvers.orderedStream().forEach(xva$0 -> rec$.addCustomResolver(new HandlerMethodArgumentResolver[] { xva$0 }));
/*     */     }
/*     */ 
/*     */     
/*     */     public void configureHttpMessageCodecs(ServerCodecConfigurer configurer) {
/* 136 */       this.codecCustomizers.orderedStream().forEach(customizer -> customizer.customize((CodecConfigurer)configurer));
/*     */     }
/*     */ 
/*     */     
/*     */     public void addResourceHandlers(ResourceHandlerRegistry registry) {
/* 141 */       if (!this.resourceProperties.isAddMappings()) {
/* 142 */         logger.debug("Default resource handling disabled");
/*     */         return;
/*     */       } 
/* 145 */       if (!registry.hasMappingForPattern("/webjars/**")) {
/*     */         
/* 147 */         ResourceHandlerRegistration registration = registry.addResourceHandler(new String[] { "/webjars/**" }).addResourceLocations(new String[] { "classpath:/META-INF/resources/webjars/" });
/* 148 */         configureResourceCaching(registration);
/* 149 */         customizeResourceHandlerRegistration(registration);
/*     */       } 
/* 151 */       String staticPathPattern = this.webFluxProperties.getStaticPathPattern();
/* 152 */       if (!registry.hasMappingForPattern(staticPathPattern)) {
/*     */         
/* 154 */         ResourceHandlerRegistration registration = registry.addResourceHandler(new String[] { staticPathPattern }).addResourceLocations(this.resourceProperties.getStaticLocations());
/* 155 */         configureResourceCaching(registration);
/* 156 */         customizeResourceHandlerRegistration(registration);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void configureResourceCaching(ResourceHandlerRegistration registration) {
/* 161 */       Duration cachePeriod = this.resourceProperties.getCache().getPeriod();
/* 162 */       ResourceProperties.Cache.Cachecontrol cacheControl = this.resourceProperties.getCache().getCachecontrol();
/* 163 */       if (cachePeriod != null && cacheControl.getMaxAge() == null) {
/* 164 */         cacheControl.setMaxAge(cachePeriod);
/*     */       }
/* 166 */       registration.setCacheControl(cacheControl.toHttpCacheControl());
/*     */     }
/*     */ 
/*     */     
/*     */     public void configureViewResolvers(ViewResolverRegistry registry) {
/* 171 */       this.viewResolvers.orderedStream().forEach(registry::viewResolver);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addFormatters(FormatterRegistry registry) {
/* 176 */       ApplicationConversionService.addBeans(registry, this.beanFactory);
/*     */     }
/*     */     
/*     */     private void customizeResourceHandlerRegistration(ResourceHandlerRegistration registration) {
/* 180 */       if (this.resourceHandlerRegistrationCustomizer != null) {
/* 181 */         this.resourceHandlerRegistrationCustomizer.customize(registration);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   public static class EnableWebFluxConfiguration
/*     */     extends DelegatingWebFluxConfiguration
/*     */   {
/*     */     private final WebFluxProperties webFluxProperties;
/*     */ 
/*     */     
/*     */     private final WebFluxRegistrations webFluxRegistrations;
/*     */ 
/*     */     
/*     */     public EnableWebFluxConfiguration(WebFluxProperties webFluxProperties, ObjectProvider<WebFluxRegistrations> webFluxRegistrations) {
/* 199 */       this.webFluxProperties = webFluxProperties;
/* 200 */       this.webFluxRegistrations = (WebFluxRegistrations)webFluxRegistrations.getIfUnique();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public FormattingConversionService webFluxConversionService() {
/* 206 */       WebConversionService conversionService = new WebConversionService(this.webFluxProperties.getDateFormat());
/* 207 */       addFormatters((FormatterRegistry)conversionService);
/* 208 */       return (FormattingConversionService)conversionService;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public Validator webFluxValidator() {
/* 214 */       if (!ClassUtils.isPresent("javax.validation.Validator", getClass().getClassLoader())) {
/* 215 */         return super.webFluxValidator();
/*     */       }
/* 217 */       return ValidatorAdapter.get(getApplicationContext(), getValidator());
/*     */     }
/*     */ 
/*     */     
/*     */     protected RequestMappingHandlerAdapter createRequestMappingHandlerAdapter() {
/* 222 */       if (this.webFluxRegistrations != null && this.webFluxRegistrations
/* 223 */         .getRequestMappingHandlerAdapter() != null) {
/* 224 */         return this.webFluxRegistrations.getRequestMappingHandlerAdapter();
/*     */       }
/* 226 */       return super.createRequestMappingHandlerAdapter();
/*     */     }
/*     */ 
/*     */     
/*     */     protected RequestMappingHandlerMapping createRequestMappingHandlerMapping() {
/* 231 */       if (this.webFluxRegistrations != null && this.webFluxRegistrations
/* 232 */         .getRequestMappingHandlerMapping() != null) {
/* 233 */         return this.webFluxRegistrations.getRequestMappingHandlerMapping();
/*     */       }
/* 235 */       return super.createRequestMappingHandlerMapping();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnEnabledResourceChain
/*     */   static class ResourceChainCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     ResourceChainResourceHandlerRegistrationCustomizer resourceHandlerRegistrationCustomizer() {
/* 246 */       return new ResourceChainResourceHandlerRegistrationCustomizer();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\WebFluxAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
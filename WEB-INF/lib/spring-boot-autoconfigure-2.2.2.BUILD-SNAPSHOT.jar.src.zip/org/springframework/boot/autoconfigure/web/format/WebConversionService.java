/*     */ package org.springframework.boot.autoconfigure.web.format;
/*     */ 
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.ResolverStyle;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.joda.time.format.DateTimeFormatterBuilder;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.datetime.DateFormatter;
/*     */ import org.springframework.format.datetime.DateFormatterRegistrar;
/*     */ import org.springframework.format.datetime.joda.JodaTimeFormatterRegistrar;
/*     */ import org.springframework.format.datetime.standard.DateTimeFormatterRegistrar;
/*     */ import org.springframework.format.number.NumberFormatAnnotationFormatterFactory;
/*     */ import org.springframework.format.number.money.CurrencyUnitFormatter;
/*     */ import org.springframework.format.number.money.Jsr354NumberFormatAnnotationFormatterFactory;
/*     */ import org.springframework.format.number.money.MonetaryAmountFormatter;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebConversionService
/*     */   extends DefaultFormattingConversionService
/*     */ {
/*  51 */   private static final boolean JSR_354_PRESENT = ClassUtils.isPresent("javax.money.MonetaryAmount", WebConversionService.class
/*  52 */       .getClassLoader());
/*     */   
/*     */   @Deprecated
/*  55 */   private static final boolean JODA_TIME_PRESENT = ClassUtils.isPresent("org.joda.time.LocalDate", WebConversionService.class
/*  56 */       .getClassLoader());
/*     */   
/*  58 */   private static final Log logger = LogFactory.getLog(WebConversionService.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final String dateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebConversionService(String dateFormat) {
/*  68 */     super(false);
/*  69 */     this.dateFormat = StringUtils.hasText(dateFormat) ? dateFormat : null;
/*  70 */     if (this.dateFormat != null) {
/*  71 */       addFormatters();
/*     */     } else {
/*     */       
/*  74 */       addDefaultFormatters((FormatterRegistry)this);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addFormatters() {
/*  79 */     addFormatterForFieldAnnotation((AnnotationFormatterFactory)new NumberFormatAnnotationFormatterFactory());
/*  80 */     if (JSR_354_PRESENT) {
/*  81 */       addFormatter((Formatter)new CurrencyUnitFormatter());
/*  82 */       addFormatter((Formatter)new MonetaryAmountFormatter());
/*  83 */       addFormatterForFieldAnnotation((AnnotationFormatterFactory)new Jsr354NumberFormatAnnotationFormatterFactory());
/*     */     } 
/*  85 */     registerJsr310();
/*  86 */     if (JODA_TIME_PRESENT) {
/*  87 */       registerJodaTime();
/*     */     }
/*  89 */     registerJavaDate();
/*     */   }
/*     */   
/*     */   private void registerJsr310() {
/*  93 */     DateTimeFormatterRegistrar dateTime = new DateTimeFormatterRegistrar();
/*  94 */     if (this.dateFormat != null) {
/*  95 */       dateTime.setDateFormatter(
/*  96 */           DateTimeFormatter.ofPattern(this.dateFormat).withResolverStyle(ResolverStyle.SMART));
/*     */     }
/*  98 */     dateTime.registerFormatters((FormatterRegistry)this);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   private void registerJodaTime() {
/* 103 */     logger.warn("Auto-configuration of Joda-Time formatters is deprecated in favor of using java.time (JSR-310).");
/* 104 */     JodaTimeFormatterRegistrar jodaTime = new JodaTimeFormatterRegistrar();
/* 105 */     if (this.dateFormat != null) {
/* 106 */       jodaTime.setDateFormatter((new DateTimeFormatterBuilder()).appendPattern(this.dateFormat).toFormatter());
/*     */     }
/* 108 */     jodaTime.registerFormatters((FormatterRegistry)this);
/*     */   }
/*     */   
/*     */   private void registerJavaDate() {
/* 112 */     DateFormatterRegistrar dateFormatterRegistrar = new DateFormatterRegistrar();
/* 113 */     if (this.dateFormat != null) {
/* 114 */       DateFormatter dateFormatter = new DateFormatter(this.dateFormat);
/* 115 */       dateFormatterRegistrar.setFormatter(dateFormatter);
/*     */     } 
/* 117 */     dateFormatterRegistrar.registerFormatters((FormatterRegistry)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\format\WebConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
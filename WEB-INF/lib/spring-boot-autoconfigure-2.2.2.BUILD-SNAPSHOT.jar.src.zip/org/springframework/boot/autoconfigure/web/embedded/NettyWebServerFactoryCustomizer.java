/*    */ package org.springframework.boot.autoconfigure.web.embedded;
/*    */ 
/*    */ import io.netty.channel.ChannelOption;
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*    */ import org.springframework.boot.cloud.CloudPlatform;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.boot.web.embedded.netty.NettyReactiveWebServerFactory;
/*    */ import org.springframework.boot.web.embedded.netty.NettyServerCustomizer;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.util.unit.DataSize;
/*    */ import reactor.netty.http.server.HttpRequestDecoderSpec;
/*    */ import reactor.netty.http.server.HttpServer;
/*    */ import reactor.netty.tcp.TcpServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NettyWebServerFactoryCustomizer
/*    */   implements WebServerFactoryCustomizer<NettyReactiveWebServerFactory>, Ordered
/*    */ {
/*    */   private final Environment environment;
/*    */   private final ServerProperties serverProperties;
/*    */   
/*    */   public NettyWebServerFactoryCustomizer(Environment environment, ServerProperties serverProperties) {
/* 48 */     this.environment = environment;
/* 49 */     this.serverProperties = serverProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 54 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(NettyReactiveWebServerFactory factory) {
/* 59 */     factory.setUseForwardHeaders(getOrDeduceUseForwardHeaders());
/* 60 */     PropertyMapper propertyMapper = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 61 */     propertyMapper.from(this.serverProperties::getMaxHttpHeaderSize)
/* 62 */       .to(maxHttpRequestHeaderSize -> customizeMaxHttpHeaderSize(factory, maxHttpRequestHeaderSize));
/* 63 */     propertyMapper.from(this.serverProperties::getConnectionTimeout)
/* 64 */       .to(connectionTimeout -> customizeGenericConnectionTimeout(factory, connectionTimeout));
/* 65 */     ServerProperties.Netty nettyProperties = this.serverProperties.getNetty();
/* 66 */     propertyMapper.from(nettyProperties::getConnectionTimeout).whenNonNull()
/* 67 */       .to(connectionTimeout -> customizeConnectionTimeout(factory, connectionTimeout));
/*    */   }
/*    */   
/*    */   private boolean getOrDeduceUseForwardHeaders() {
/* 71 */     if (this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NONE)) {
/* 72 */       CloudPlatform platform = CloudPlatform.getActive(this.environment);
/* 73 */       return (platform != null && platform.isUsingForwardHeaders());
/*    */     } 
/* 75 */     return this.serverProperties.getForwardHeadersStrategy().equals(ServerProperties.ForwardHeadersStrategy.NATIVE);
/*    */   }
/*    */   
/*    */   private void customizeMaxHttpHeaderSize(NettyReactiveWebServerFactory factory, DataSize maxHttpHeaderSize) {
/* 79 */     factory.addServerCustomizers(new NettyServerCustomizer[] { httpServer -> httpServer.httpRequestDecoder(()) });
/*    */   }
/*    */ 
/*    */   
/*    */   private void customizeGenericConnectionTimeout(NettyReactiveWebServerFactory factory, Duration connectionTimeout) {
/* 84 */     if (!connectionTimeout.isZero()) {
/* 85 */       long timeoutMillis = connectionTimeout.isNegative() ? 0L : connectionTimeout.toMillis();
/* 86 */       factory.addServerCustomizers(new NettyServerCustomizer[] { httpServer -> httpServer.tcpConfiguration(()) });
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void customizeConnectionTimeout(NettyReactiveWebServerFactory factory, Duration connectionTimeout) {
/* 92 */     factory.addServerCustomizers(new NettyServerCustomizer[] { httpServer -> httpServer.tcpConfiguration(()) });
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\embedded\NettyWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
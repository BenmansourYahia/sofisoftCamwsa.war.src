/*     */ package org.springframework.boot.autoconfigure.web.servlet;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import javax.servlet.ServletRegistration;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.http.HttpProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.web.multipart.MultipartResolver;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfigureOrder(-2147483648)
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @ConditionalOnClass({DispatcherServlet.class})
/*     */ @AutoConfigureAfter({ServletWebServerFactoryAutoConfiguration.class})
/*     */ public class DispatcherServletAutoConfiguration
/*     */ {
/*     */   public static final String DEFAULT_DISPATCHER_SERVLET_BEAN_NAME = "dispatcherServlet";
/*     */   public static final String DEFAULT_DISPATCHER_SERVLET_REGISTRATION_BEAN_NAME = "dispatcherServletRegistration";
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Conditional({DefaultDispatcherServletCondition.class})
/*     */   @ConditionalOnClass({ServletRegistration.class})
/*     */   @EnableConfigurationProperties({HttpProperties.class, WebMvcProperties.class})
/*     */   protected static class DispatcherServletConfiguration
/*     */   {
/*     */     @Bean(name = {"dispatcherServlet"})
/*     */     public DispatcherServlet dispatcherServlet(HttpProperties httpProperties, WebMvcProperties webMvcProperties) {
/*  91 */       DispatcherServlet dispatcherServlet = new DispatcherServlet();
/*  92 */       dispatcherServlet.setDispatchOptionsRequest(webMvcProperties.isDispatchOptionsRequest());
/*  93 */       dispatcherServlet.setDispatchTraceRequest(webMvcProperties.isDispatchTraceRequest());
/*  94 */       dispatcherServlet.setThrowExceptionIfNoHandlerFound(webMvcProperties.isThrowExceptionIfNoHandlerFound());
/*  95 */       dispatcherServlet.setPublishEvents(webMvcProperties.isPublishRequestHandledEvents());
/*  96 */       dispatcherServlet.setEnableLoggingRequestDetails(httpProperties.isLogRequestDetails());
/*  97 */       return dispatcherServlet;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnBean({MultipartResolver.class})
/*     */     @ConditionalOnMissingBean(name = {"multipartResolver"})
/*     */     public MultipartResolver multipartResolver(MultipartResolver resolver) {
/* 105 */       return resolver;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Conditional({DispatcherServletRegistrationCondition.class})
/*     */   @ConditionalOnClass({ServletRegistration.class})
/*     */   @EnableConfigurationProperties({WebMvcProperties.class})
/*     */   @Import({DispatcherServletConfiguration.class})
/*     */   protected static class DispatcherServletRegistrationConfiguration
/*     */   {
/*     */     @Bean(name = {"dispatcherServletRegistration"})
/*     */     @ConditionalOnBean(value = {DispatcherServlet.class}, name = {"dispatcherServlet"})
/*     */     public DispatcherServletRegistrationBean dispatcherServletRegistration(DispatcherServlet dispatcherServlet, WebMvcProperties webMvcProperties, ObjectProvider<MultipartConfigElement> multipartConfig) {
/* 122 */       DispatcherServletRegistrationBean registration = new DispatcherServletRegistrationBean(dispatcherServlet, webMvcProperties.getServlet().getPath());
/* 123 */       registration.setName("dispatcherServlet");
/* 124 */       registration.setLoadOnStartup(webMvcProperties.getServlet().getLoadOnStartup());
/* 125 */       multipartConfig.ifAvailable(registration::setMultipartConfig);
/* 126 */       return registration;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Order(2147483637)
/*     */   private static class DefaultDispatcherServletCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 136 */       ConditionMessage.Builder message = ConditionMessage.forCondition("Default DispatcherServlet", new Object[0]);
/* 137 */       ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/*     */       
/* 139 */       List<String> dispatchServletBeans = Arrays.asList(beanFactory.getBeanNamesForType(DispatcherServlet.class, false, false));
/* 140 */       if (dispatchServletBeans.contains("dispatcherServlet")) {
/* 141 */         return 
/* 142 */           ConditionOutcome.noMatch(message.found("dispatcher servlet bean").items(new Object[] { "dispatcherServlet" }));
/*     */       }
/* 144 */       if (beanFactory.containsBean("dispatcherServlet")) {
/* 145 */         return ConditionOutcome.noMatch(message
/* 146 */             .found("non dispatcher servlet bean").items(new Object[] { "dispatcherServlet" }));
/*     */       }
/* 148 */       if (dispatchServletBeans.isEmpty()) {
/* 149 */         return ConditionOutcome.match(message.didNotFind("dispatcher servlet beans").atAll());
/*     */       }
/* 151 */       return ConditionOutcome.match(message.found("dispatcher servlet bean", "dispatcher servlet beans")
/* 152 */           .items(ConditionMessage.Style.QUOTE, dispatchServletBeans)
/* 153 */           .append("and none is named dispatcherServlet"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Order(2147483637)
/*     */   private static class DispatcherServletRegistrationCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 163 */       ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/* 164 */       ConditionOutcome outcome = checkDefaultDispatcherName(beanFactory);
/* 165 */       if (!outcome.isMatch()) {
/* 166 */         return outcome;
/*     */       }
/* 168 */       return checkServletRegistration(beanFactory);
/*     */     }
/*     */ 
/*     */     
/*     */     private ConditionOutcome checkDefaultDispatcherName(ConfigurableListableBeanFactory beanFactory) {
/* 173 */       List<String> servlets = Arrays.asList(beanFactory.getBeanNamesForType(DispatcherServlet.class, false, false));
/* 174 */       boolean containsDispatcherBean = beanFactory.containsBean("dispatcherServlet");
/* 175 */       if (containsDispatcherBean && !servlets.contains("dispatcherServlet")) {
/* 176 */         return ConditionOutcome.noMatch(
/* 177 */             startMessage().found("non dispatcher servlet").items(new Object[] { "dispatcherServlet" }));
/*     */       }
/* 179 */       return ConditionOutcome.match();
/*     */     }
/*     */     
/*     */     private ConditionOutcome checkServletRegistration(ConfigurableListableBeanFactory beanFactory) {
/* 183 */       ConditionMessage.Builder message = startMessage();
/*     */       
/* 185 */       List<String> registrations = Arrays.asList(beanFactory.getBeanNamesForType(ServletRegistrationBean.class, false, false));
/*     */       
/* 187 */       boolean containsDispatcherRegistrationBean = beanFactory.containsBean("dispatcherServletRegistration");
/* 188 */       if (registrations.isEmpty()) {
/* 189 */         if (containsDispatcherRegistrationBean) {
/* 190 */           return ConditionOutcome.noMatch(message.found("non servlet registration bean")
/* 191 */               .items(new Object[] { "dispatcherServletRegistration" }));
/*     */         }
/* 193 */         return ConditionOutcome.match(message.didNotFind("servlet registration bean").atAll());
/*     */       } 
/* 195 */       if (registrations.contains("dispatcherServletRegistration")) {
/* 196 */         return ConditionOutcome.noMatch(message.found("servlet registration bean")
/* 197 */             .items(new Object[] { "dispatcherServletRegistration" }));
/*     */       }
/* 199 */       if (containsDispatcherRegistrationBean) {
/* 200 */         return ConditionOutcome.noMatch(message.found("non servlet registration bean")
/* 201 */             .items(new Object[] { "dispatcherServletRegistration" }));
/*     */       }
/* 203 */       return ConditionOutcome.match(message.found("servlet registration beans").items(ConditionMessage.Style.QUOTE, registrations)
/* 204 */           .append("and none is named dispatcherServletRegistration"));
/*     */     }
/*     */     
/*     */     private ConditionMessage.Builder startMessage() {
/* 208 */       return ConditionMessage.forCondition("DispatcherServlet Registration", new Object[0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\DispatcherServletAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
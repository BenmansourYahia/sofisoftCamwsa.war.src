/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.http.HttpProperties;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ import org.springframework.boot.web.servlet.filter.OrderedCharacterEncodingFilter;
/*    */ import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.web.filter.CharacterEncodingFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @EnableConfigurationProperties({HttpProperties.class})
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnClass({CharacterEncodingFilter.class})
/*    */ @ConditionalOnProperty(prefix = "spring.http.encoding", value = {"enabled"}, matchIfMissing = true)
/*    */ public class HttpEncodingAutoConfiguration
/*    */ {
/*    */   private final HttpProperties.Encoding properties;
/*    */   
/*    */   public HttpEncodingAutoConfiguration(HttpProperties properties) {
/* 53 */     this.properties = properties.getEncoding();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public CharacterEncodingFilter characterEncodingFilter() {
/* 59 */     OrderedCharacterEncodingFilter orderedCharacterEncodingFilter = new OrderedCharacterEncodingFilter();
/* 60 */     orderedCharacterEncodingFilter.setEncoding(this.properties.getCharset().name());
/* 61 */     orderedCharacterEncodingFilter.setForceRequestEncoding(this.properties.shouldForce(HttpProperties.Encoding.Type.REQUEST));
/* 62 */     orderedCharacterEncodingFilter.setForceResponseEncoding(this.properties.shouldForce(HttpProperties.Encoding.Type.RESPONSE));
/* 63 */     return (CharacterEncodingFilter)orderedCharacterEncodingFilter;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   public LocaleCharsetMappingsCustomizer localeCharsetMappingsCustomizer() {
/* 68 */     return new LocaleCharsetMappingsCustomizer(this.properties);
/*    */   }
/*    */   
/*    */   private static class LocaleCharsetMappingsCustomizer
/*    */     implements WebServerFactoryCustomizer<ConfigurableServletWebServerFactory>, Ordered
/*    */   {
/*    */     private final HttpProperties.Encoding properties;
/*    */     
/*    */     LocaleCharsetMappingsCustomizer(HttpProperties.Encoding properties) {
/* 77 */       this.properties = properties;
/*    */     }
/*    */ 
/*    */     
/*    */     public void customize(ConfigurableServletWebServerFactory factory) {
/* 82 */       if (this.properties.getMapping() != null) {
/* 83 */         factory.setLocaleCharsetMappings(this.properties.getMapping());
/*    */       }
/*    */     }
/*    */ 
/*    */     
/*    */     public int getOrder() {
/* 89 */       return 0;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\HttpEncodingAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.web;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ import org.springframework.http.CacheControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.resources", ignoreUnknownFields = false)
/*     */ public class ResourceProperties
/*     */ {
/*  41 */   private static final String[] CLASSPATH_RESOURCE_LOCATIONS = new String[] { "classpath:/META-INF/resources/", "classpath:/resources/", "classpath:/static/", "classpath:/public/" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private String[] staticLocations = CLASSPATH_RESOURCE_LOCATIONS;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean addMappings = true;
/*     */ 
/*     */   
/*  55 */   private final Chain chain = new Chain();
/*     */   
/*  57 */   private final Cache cache = new Cache();
/*     */   
/*     */   public String[] getStaticLocations() {
/*  60 */     return this.staticLocations;
/*     */   }
/*     */   
/*     */   public void setStaticLocations(String[] staticLocations) {
/*  64 */     this.staticLocations = appendSlashIfNecessary(staticLocations);
/*     */   }
/*     */   
/*     */   private String[] appendSlashIfNecessary(String[] staticLocations) {
/*  68 */     String[] normalized = new String[staticLocations.length];
/*  69 */     for (int i = 0; i < staticLocations.length; i++) {
/*  70 */       String location = staticLocations[i];
/*  71 */       normalized[i] = location.endsWith("/") ? location : (location + "/");
/*     */     } 
/*  73 */     return normalized;
/*     */   }
/*     */   
/*     */   public boolean isAddMappings() {
/*  77 */     return this.addMappings;
/*     */   }
/*     */   
/*     */   public void setAddMappings(boolean addMappings) {
/*  81 */     this.addMappings = addMappings;
/*     */   }
/*     */   
/*     */   public Chain getChain() {
/*  85 */     return this.chain;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/*  89 */     return this.cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Chain
/*     */   {
/*     */     private Boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean cache = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean htmlApplicationCache = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean compressed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     private final ResourceProperties.Strategy strategy = new ResourceProperties.Strategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getEnabled() {
/* 128 */       return getEnabled(getStrategy().getFixed().isEnabled(), getStrategy().getContent().isEnabled(), this.enabled);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 133 */       this.enabled = Boolean.valueOf(enabled);
/*     */     }
/*     */     
/*     */     public boolean isCache() {
/* 137 */       return this.cache;
/*     */     }
/*     */     
/*     */     public void setCache(boolean cache) {
/* 141 */       this.cache = cache;
/*     */     }
/*     */     
/*     */     public ResourceProperties.Strategy getStrategy() {
/* 145 */       return this.strategy;
/*     */     }
/*     */     
/*     */     public boolean isHtmlApplicationCache() {
/* 149 */       return this.htmlApplicationCache;
/*     */     }
/*     */     
/*     */     public void setHtmlApplicationCache(boolean htmlApplicationCache) {
/* 153 */       this.htmlApplicationCache = htmlApplicationCache;
/*     */     }
/*     */     
/*     */     public boolean isCompressed() {
/* 157 */       return this.compressed;
/*     */     }
/*     */     
/*     */     public void setCompressed(boolean compressed) {
/* 161 */       this.compressed = compressed;
/*     */     }
/*     */     
/*     */     static Boolean getEnabled(boolean fixedEnabled, boolean contentEnabled, Boolean chainEnabled) {
/* 165 */       return (fixedEnabled || contentEnabled) ? Boolean.TRUE : chainEnabled;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Strategy
/*     */   {
/* 175 */     private final ResourceProperties.Fixed fixed = new ResourceProperties.Fixed();
/*     */     
/* 177 */     private final ResourceProperties.Content content = new ResourceProperties.Content();
/*     */     
/*     */     public ResourceProperties.Fixed getFixed() {
/* 180 */       return this.fixed;
/*     */     }
/*     */     
/*     */     public ResourceProperties.Content getContent() {
/* 184 */       return this.content;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Content
/*     */   {
/*     */     private boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     private String[] paths = new String[] { "/**" };
/*     */     
/*     */     public boolean isEnabled() {
/* 205 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 209 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String[] getPaths() {
/* 213 */       return this.paths;
/*     */     }
/*     */     
/*     */     public void setPaths(String[] paths) {
/* 217 */       this.paths = paths;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Fixed
/*     */   {
/*     */     private boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     private String[] paths = new String[] { "/**" };
/*     */ 
/*     */     
/*     */     private String version;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 243 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 247 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String[] getPaths() {
/* 251 */       return this.paths;
/*     */     }
/*     */     
/*     */     public void setPaths(String[] paths) {
/* 255 */       this.paths = paths;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 259 */       return this.version;
/*     */     }
/*     */     
/*     */     public void setVersion(String version) {
/* 263 */       this.version = version;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Cache
/*     */   {
/*     */     @DurationUnit(ChronoUnit.SECONDS)
/*     */     private Duration period;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     private final Cachecontrol cachecontrol = new Cachecontrol();
/*     */     
/*     */     public Duration getPeriod() {
/* 288 */       return this.period;
/*     */     }
/*     */     
/*     */     public void setPeriod(Duration period) {
/* 292 */       this.period = period;
/*     */     }
/*     */     
/*     */     public Cachecontrol getCachecontrol() {
/* 296 */       return this.cachecontrol;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Cachecontrol
/*     */     {
/*     */       @DurationUnit(ChronoUnit.SECONDS)
/*     */       private Duration maxAge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Boolean noCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Boolean noStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Boolean mustRevalidate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Boolean noTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Boolean cachePublic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Boolean cachePrivate;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Boolean proxyRevalidate;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @DurationUnit(ChronoUnit.SECONDS)
/*     */       private Duration staleWhileRevalidate;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @DurationUnit(ChronoUnit.SECONDS)
/*     */       private Duration staleIfError;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @DurationUnit(ChronoUnit.SECONDS)
/*     */       private Duration sMaxAge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Duration getMaxAge() {
/* 373 */         return this.maxAge;
/*     */       }
/*     */       
/*     */       public void setMaxAge(Duration maxAge) {
/* 377 */         this.maxAge = maxAge;
/*     */       }
/*     */       
/*     */       public Boolean getNoCache() {
/* 381 */         return this.noCache;
/*     */       }
/*     */       
/*     */       public void setNoCache(Boolean noCache) {
/* 385 */         this.noCache = noCache;
/*     */       }
/*     */       
/*     */       public Boolean getNoStore() {
/* 389 */         return this.noStore;
/*     */       }
/*     */       
/*     */       public void setNoStore(Boolean noStore) {
/* 393 */         this.noStore = noStore;
/*     */       }
/*     */       
/*     */       public Boolean getMustRevalidate() {
/* 397 */         return this.mustRevalidate;
/*     */       }
/*     */       
/*     */       public void setMustRevalidate(Boolean mustRevalidate) {
/* 401 */         this.mustRevalidate = mustRevalidate;
/*     */       }
/*     */       
/*     */       public Boolean getNoTransform() {
/* 405 */         return this.noTransform;
/*     */       }
/*     */       
/*     */       public void setNoTransform(Boolean noTransform) {
/* 409 */         this.noTransform = noTransform;
/*     */       }
/*     */       
/*     */       public Boolean getCachePublic() {
/* 413 */         return this.cachePublic;
/*     */       }
/*     */       
/*     */       public void setCachePublic(Boolean cachePublic) {
/* 417 */         this.cachePublic = cachePublic;
/*     */       }
/*     */       
/*     */       public Boolean getCachePrivate() {
/* 421 */         return this.cachePrivate;
/*     */       }
/*     */       
/*     */       public void setCachePrivate(Boolean cachePrivate) {
/* 425 */         this.cachePrivate = cachePrivate;
/*     */       }
/*     */       
/*     */       public Boolean getProxyRevalidate() {
/* 429 */         return this.proxyRevalidate;
/*     */       }
/*     */       
/*     */       public void setProxyRevalidate(Boolean proxyRevalidate) {
/* 433 */         this.proxyRevalidate = proxyRevalidate;
/*     */       }
/*     */       
/*     */       public Duration getStaleWhileRevalidate() {
/* 437 */         return this.staleWhileRevalidate;
/*     */       }
/*     */       
/*     */       public void setStaleWhileRevalidate(Duration staleWhileRevalidate) {
/* 441 */         this.staleWhileRevalidate = staleWhileRevalidate;
/*     */       }
/*     */       
/*     */       public Duration getStaleIfError() {
/* 445 */         return this.staleIfError;
/*     */       }
/*     */       
/*     */       public void setStaleIfError(Duration staleIfError) {
/* 449 */         this.staleIfError = staleIfError;
/*     */       }
/*     */       
/*     */       public Duration getSMaxAge() {
/* 453 */         return this.sMaxAge;
/*     */       }
/*     */       
/*     */       public void setSMaxAge(Duration sMaxAge) {
/* 457 */         this.sMaxAge = sMaxAge;
/*     */       }
/*     */       
/*     */       public CacheControl toHttpCacheControl() {
/* 461 */         PropertyMapper map = PropertyMapper.get();
/* 462 */         CacheControl control = createCacheControl();
/* 463 */         map.from(this::getMustRevalidate).whenTrue().toCall(control::mustRevalidate);
/* 464 */         map.from(this::getNoTransform).whenTrue().toCall(control::noTransform);
/* 465 */         map.from(this::getCachePublic).whenTrue().toCall(control::cachePublic);
/* 466 */         map.from(this::getCachePrivate).whenTrue().toCall(control::cachePrivate);
/* 467 */         map.from(this::getProxyRevalidate).whenTrue().toCall(control::proxyRevalidate);
/* 468 */         map.from(this::getStaleWhileRevalidate).whenNonNull()
/* 469 */           .to(duration -> control.staleWhileRevalidate(duration.getSeconds(), TimeUnit.SECONDS));
/* 470 */         map.from(this::getStaleIfError).whenNonNull()
/* 471 */           .to(duration -> control.staleIfError(duration.getSeconds(), TimeUnit.SECONDS));
/* 472 */         map.from(this::getSMaxAge).whenNonNull()
/* 473 */           .to(duration -> control.sMaxAge(duration.getSeconds(), TimeUnit.SECONDS));
/*     */         
/* 475 */         if (control.getHeaderValue() == null) {
/* 476 */           return null;
/*     */         }
/* 478 */         return control;
/*     */       }
/*     */       
/*     */       private CacheControl createCacheControl() {
/* 482 */         if (Boolean.TRUE.equals(this.noStore)) {
/* 483 */           return CacheControl.noStore();
/*     */         }
/* 485 */         if (Boolean.TRUE.equals(this.noCache)) {
/* 486 */           return CacheControl.noCache();
/*     */         }
/* 488 */         if (this.maxAge != null) {
/* 489 */           return CacheControl.maxAge(this.maxAge.getSeconds(), TimeUnit.SECONDS);
/*     */         }
/* 491 */         return CacheControl.empty();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\ResourceProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
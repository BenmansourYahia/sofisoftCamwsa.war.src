/*    */ package org.springframework.boot.autoconfigure.web.reactive;
/*    */ 
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*    */ import org.springframework.web.reactive.config.ResourceChainRegistration;
/*    */ import org.springframework.web.reactive.config.ResourceHandlerRegistration;
/*    */ import org.springframework.web.reactive.resource.AppCacheManifestTransformer;
/*    */ import org.springframework.web.reactive.resource.EncodedResourceResolver;
/*    */ import org.springframework.web.reactive.resource.ResourceResolver;
/*    */ import org.springframework.web.reactive.resource.ResourceTransformer;
/*    */ import org.springframework.web.reactive.resource.VersionResourceResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ResourceChainResourceHandlerRegistrationCustomizer
/*    */   implements ResourceHandlerRegistrationCustomizer
/*    */ {
/*    */   @Autowired
/* 36 */   private ResourceProperties resourceProperties = new ResourceProperties();
/*    */ 
/*    */ 
/*    */   
/*    */   public void customize(ResourceHandlerRegistration registration) {
/* 41 */     ResourceProperties.Chain properties = this.resourceProperties.getChain();
/* 42 */     configureResourceChain(properties, registration.resourceChain(properties.isCache()));
/*    */   }
/*    */   
/*    */   private void configureResourceChain(ResourceProperties.Chain properties, ResourceChainRegistration chain) {
/* 46 */     ResourceProperties.Strategy strategy = properties.getStrategy();
/* 47 */     if (properties.isCompressed()) {
/* 48 */       chain.addResolver((ResourceResolver)new EncodedResourceResolver());
/*    */     }
/* 50 */     if (strategy.getFixed().isEnabled() || strategy.getContent().isEnabled()) {
/* 51 */       chain.addResolver(getVersionResourceResolver(strategy));
/*    */     }
/* 53 */     if (properties.isHtmlApplicationCache()) {
/* 54 */       chain.addTransformer((ResourceTransformer)new AppCacheManifestTransformer());
/*    */     }
/*    */   }
/*    */   
/*    */   private ResourceResolver getVersionResourceResolver(ResourceProperties.Strategy properties) {
/* 59 */     VersionResourceResolver resolver = new VersionResourceResolver();
/* 60 */     if (properties.getFixed().isEnabled()) {
/* 61 */       String version = properties.getFixed().getVersion();
/* 62 */       String[] paths = properties.getFixed().getPaths();
/* 63 */       resolver.addFixedVersionStrategy(version, paths);
/*    */     } 
/* 65 */     if (properties.getContent().isEnabled()) {
/* 66 */       String[] paths = properties.getContent().getPaths();
/* 67 */       resolver.addContentVersionStrategy(paths);
/*    */     } 
/* 69 */     return (ResourceResolver)resolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\ResourceChainResourceHandlerRegistrationCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.web;
/*     */ 
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorProperties
/*     */ {
/*     */   @Value("${error.path:/error}")
/*  34 */   private String path = "/error";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean includeException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private IncludeStacktrace includeStacktrace = IncludeStacktrace.NEVER;
/*     */   
/*  47 */   private final Whitelabel whitelabel = new Whitelabel();
/*     */   
/*     */   public String getPath() {
/*  50 */     return this.path;
/*     */   }
/*     */   
/*     */   public void setPath(String path) {
/*  54 */     this.path = path;
/*     */   }
/*     */   
/*     */   public boolean isIncludeException() {
/*  58 */     return this.includeException;
/*     */   }
/*     */   
/*     */   public void setIncludeException(boolean includeException) {
/*  62 */     this.includeException = includeException;
/*     */   }
/*     */   
/*     */   public IncludeStacktrace getIncludeStacktrace() {
/*  66 */     return this.includeStacktrace;
/*     */   }
/*     */   
/*     */   public void setIncludeStacktrace(IncludeStacktrace includeStacktrace) {
/*  70 */     this.includeStacktrace = includeStacktrace;
/*     */   }
/*     */   
/*     */   public Whitelabel getWhitelabel() {
/*  74 */     return this.whitelabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum IncludeStacktrace
/*     */   {
/*  85 */     NEVER,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     ALWAYS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     ON_TRACE_PARAM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Whitelabel
/*     */   {
/*     */     private boolean enabled = true;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 108 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 112 */       this.enabled = enabled;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\ErrorProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
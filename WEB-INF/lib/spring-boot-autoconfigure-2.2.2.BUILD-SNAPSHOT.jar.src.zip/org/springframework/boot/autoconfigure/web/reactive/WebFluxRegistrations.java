/*    */ package org.springframework.boot.autoconfigure.web.reactive;
/*    */ 
/*    */ import org.springframework.web.reactive.result.method.annotation.RequestMappingHandlerAdapter;
/*    */ import org.springframework.web.reactive.result.method.annotation.RequestMappingHandlerMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebFluxRegistrations
/*    */ {
/*    */   default RequestMappingHandlerMapping getRequestMappingHandlerMapping() {
/* 41 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default RequestMappingHandlerAdapter getRequestMappingHandlerAdapter() {
/* 50 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\WebFluxRegistrations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
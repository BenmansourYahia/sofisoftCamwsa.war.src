/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface JerseyApplicationPath
/*    */ {
/*    */   String getPath();
/*    */   
/*    */   default String getRelativePath(String path) {
/* 42 */     String prefix = getPrefix();
/* 43 */     if (!path.startsWith("/")) {
/* 44 */       path = "/" + path;
/*    */     }
/* 46 */     return prefix + path;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getPrefix() {
/* 56 */     String result = getPath();
/* 57 */     int index = result.indexOf('*');
/* 58 */     if (index != -1) {
/* 59 */       result = result.substring(0, index);
/*    */     }
/* 61 */     if (result.endsWith("/")) {
/* 62 */       result = result.substring(0, result.length() - 1);
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getUrlMapping() {
/* 73 */     String path = getPath();
/* 74 */     if (!path.startsWith("/")) {
/* 75 */       path = "/" + path;
/*    */     }
/* 77 */     if (path.equals("/")) {
/* 78 */       return "/*";
/*    */     }
/* 80 */     if (path.contains("*")) {
/* 81 */       return path;
/*    */     }
/* 83 */     if (path.endsWith("/")) {
/* 84 */       return path + "*";
/*    */     }
/* 86 */     return path + "/*";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\JerseyApplicationPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
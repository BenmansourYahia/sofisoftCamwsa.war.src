/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.security.AccessControlException;
/*    */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProvider;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JspTemplateAvailabilityProvider
/*    */   implements TemplateAvailabilityProvider
/*    */ {
/*    */   public boolean isTemplateAvailable(String view, Environment environment, ClassLoader classLoader, ResourceLoader resourceLoader) {
/* 41 */     if (ClassUtils.isPresent("org.apache.jasper.compiler.JspConfig", classLoader)) {
/* 42 */       String resourceName = getResourceName(view, environment);
/* 43 */       if (resourceLoader.getResource(resourceName).exists()) {
/* 44 */         return true;
/*    */       }
/*    */       try {
/* 47 */         return (new File("src/main/webapp", resourceName)).exists();
/*    */       }
/* 49 */       catch (AccessControlException accessControlException) {}
/*    */     } 
/*    */     
/* 52 */     return false;
/*    */   }
/*    */   
/*    */   private String getResourceName(String view, Environment environment) {
/* 56 */     String prefix = environment.getProperty("spring.mvc.view.prefix", "");
/* 57 */     String suffix = environment.getProperty("spring.mvc.view.suffix", "");
/* 58 */     return prefix + view + suffix;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\JspTemplateAvailabilityProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
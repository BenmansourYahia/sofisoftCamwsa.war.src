/*    */ package org.springframework.boot.autoconfigure.web.servlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface DispatcherServletPath
/*    */ {
/*    */   String getPath();
/*    */   
/*    */   default String getRelativePath(String path) {
/* 46 */     String prefix = getPrefix();
/* 47 */     if (!path.startsWith("/")) {
/* 48 */       path = "/" + path;
/*    */     }
/* 50 */     return prefix + path;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getPrefix() {
/* 60 */     String result = getPath();
/* 61 */     int index = result.indexOf('*');
/* 62 */     if (index != -1) {
/* 63 */       result = result.substring(0, index);
/*    */     }
/* 65 */     if (result.endsWith("/")) {
/* 66 */       result = result.substring(0, result.length() - 1);
/*    */     }
/* 68 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getServletUrlMapping() {
/* 77 */     if (getPath().equals("") || getPath().equals("/")) {
/* 78 */       return "/";
/*    */     }
/* 80 */     if (getPath().contains("*")) {
/* 81 */       return getPath();
/*    */     }
/* 83 */     if (getPath().endsWith("/")) {
/* 84 */       return getPath() + "*";
/*    */     }
/* 86 */     return getPath() + "/*";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\servlet\DispatcherServletPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
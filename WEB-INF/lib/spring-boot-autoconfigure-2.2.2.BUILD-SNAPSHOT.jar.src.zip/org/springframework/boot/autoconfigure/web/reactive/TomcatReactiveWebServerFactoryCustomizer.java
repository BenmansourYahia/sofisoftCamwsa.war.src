/*    */ package org.springframework.boot.autoconfigure.web.reactive;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*    */ import org.springframework.boot.web.embedded.tomcat.TomcatReactiveWebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TomcatReactiveWebServerFactoryCustomizer
/*    */   implements WebServerFactoryCustomizer<TomcatReactiveWebServerFactory>
/*    */ {
/*    */   private final ServerProperties serverProperties;
/*    */   
/*    */   public TomcatReactiveWebServerFactoryCustomizer(ServerProperties serverProperties) {
/* 36 */     this.serverProperties = serverProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(TomcatReactiveWebServerFactory factory) {
/* 41 */     factory.setDisableMBeanRegistry(!this.serverProperties.getTomcat().getMbeanregistry().isEnabled());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\reactive\TomcatReactiveWebServerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
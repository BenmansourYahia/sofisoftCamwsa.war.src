/*      */ package org.springframework.boot.autoconfigure.web;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.net.InetAddress;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.time.Duration;
/*      */ import java.time.temporal.ChronoUnit;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*      */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*      */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*      */ import org.springframework.boot.convert.DurationUnit;
/*      */ import org.springframework.boot.web.server.Compression;
/*      */ import org.springframework.boot.web.server.Http2;
/*      */ import org.springframework.boot.web.server.Ssl;
/*      */ import org.springframework.boot.web.servlet.server.Jsp;
/*      */ import org.springframework.boot.web.servlet.server.Session;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.unit.DataSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @ConfigurationProperties(prefix = "server", ignoreUnknownFields = true)
/*      */ public class ServerProperties
/*      */ {
/*      */   private Integer port;
/*      */   private InetAddress address;
/*      */   @NestedConfigurationProperty
/*   81 */   private final ErrorProperties error = new ErrorProperties();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   87 */   private ForwardHeadersStrategy forwardHeadersStrategy = ForwardHeadersStrategy.NONE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String serverHeader;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   private DataSize maxHttpHeaderSize = DataSize.ofKilobytes(8L);
/*      */ 
/*      */ 
/*      */   
/*      */   private Duration connectionTimeout;
/*      */ 
/*      */   
/*      */   @NestedConfigurationProperty
/*      */   private Ssl ssl;
/*      */ 
/*      */   
/*      */   @NestedConfigurationProperty
/*  109 */   private final Compression compression = new Compression();
/*      */   
/*      */   @NestedConfigurationProperty
/*  112 */   private final Http2 http2 = new Http2();
/*      */ 
/*      */   
/*  115 */   private final Servlet servlet = new Servlet();
/*      */   
/*  117 */   private final Tomcat tomcat = new Tomcat();
/*      */   
/*  119 */   private final Jetty jetty = new Jetty();
/*      */   
/*  121 */   private final Netty netty = new Netty();
/*      */   
/*  123 */   private final Undertow undertow = new Undertow();
/*      */   
/*      */   public Integer getPort() {
/*  126 */     return this.port;
/*      */   }
/*      */   
/*      */   public void setPort(Integer port) {
/*  130 */     this.port = port;
/*      */   }
/*      */   
/*      */   public InetAddress getAddress() {
/*  134 */     return this.address;
/*      */   }
/*      */   
/*      */   public void setAddress(InetAddress address) {
/*  138 */     this.address = address;
/*      */   }
/*      */ 
/*      */   
/*      */   @DeprecatedConfigurationProperty(reason = "replaced to support additional strategies", replacement = "server.forward-headers-strategy")
/*      */   public Boolean isUseForwardHeaders() {
/*  144 */     return Boolean.valueOf(ForwardHeadersStrategy.NATIVE.equals(this.forwardHeadersStrategy));
/*      */   }
/*      */   
/*      */   public void setUseForwardHeaders(Boolean useForwardHeaders) {
/*  148 */     this.forwardHeadersStrategy = Boolean.TRUE.equals(useForwardHeaders) ? ForwardHeadersStrategy.NATIVE : ForwardHeadersStrategy.NONE;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getServerHeader() {
/*  153 */     return this.serverHeader;
/*      */   }
/*      */   
/*      */   public void setServerHeader(String serverHeader) {
/*  157 */     this.serverHeader = serverHeader;
/*      */   }
/*      */   
/*      */   public DataSize getMaxHttpHeaderSize() {
/*  161 */     return this.maxHttpHeaderSize;
/*      */   }
/*      */   
/*      */   public void setMaxHttpHeaderSize(DataSize maxHttpHeaderSize) {
/*  165 */     this.maxHttpHeaderSize = maxHttpHeaderSize;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @DeprecatedConfigurationProperty(reason = "Each server behaves differently. Use server specific properties instead.")
/*      */   public Duration getConnectionTimeout() {
/*  172 */     return this.connectionTimeout;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void setConnectionTimeout(Duration connectionTimeout) {
/*  177 */     this.connectionTimeout = connectionTimeout;
/*      */   }
/*      */   
/*      */   public ErrorProperties getError() {
/*  181 */     return this.error;
/*      */   }
/*      */   
/*      */   public Ssl getSsl() {
/*  185 */     return this.ssl;
/*      */   }
/*      */   
/*      */   public void setSsl(Ssl ssl) {
/*  189 */     this.ssl = ssl;
/*      */   }
/*      */   
/*      */   public Compression getCompression() {
/*  193 */     return this.compression;
/*      */   }
/*      */   
/*      */   public Http2 getHttp2() {
/*  197 */     return this.http2;
/*      */   }
/*      */   
/*      */   public Servlet getServlet() {
/*  201 */     return this.servlet;
/*      */   }
/*      */   
/*      */   public Tomcat getTomcat() {
/*  205 */     return this.tomcat;
/*      */   }
/*      */   
/*      */   public Jetty getJetty() {
/*  209 */     return this.jetty;
/*      */   }
/*      */   
/*      */   public Netty getNetty() {
/*  213 */     return this.netty;
/*      */   }
/*      */   
/*      */   public Undertow getUndertow() {
/*  217 */     return this.undertow;
/*      */   }
/*      */   
/*      */   public ForwardHeadersStrategy getForwardHeadersStrategy() {
/*  221 */     return this.forwardHeadersStrategy;
/*      */   }
/*      */   
/*      */   public void setForwardHeadersStrategy(ForwardHeadersStrategy forwardHeadersStrategy) {
/*  225 */     this.forwardHeadersStrategy = forwardHeadersStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Servlet
/*      */   {
/*  236 */     private final Map<String, String> contextParameters = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String contextPath;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  246 */     private String applicationDisplayName = "application";
/*      */     @NestedConfigurationProperty
/*  248 */     private final Jsp jsp = new Jsp();
/*      */     
/*      */     @NestedConfigurationProperty
/*  251 */     private final Session session = new Session();
/*      */ 
/*      */     
/*      */     public String getContextPath() {
/*  255 */       return this.contextPath;
/*      */     }
/*      */     
/*      */     public void setContextPath(String contextPath) {
/*  259 */       this.contextPath = cleanContextPath(contextPath);
/*      */     }
/*      */     
/*      */     private String cleanContextPath(String contextPath) {
/*  263 */       String candidate = StringUtils.trimWhitespace(contextPath);
/*  264 */       if (StringUtils.hasText(candidate) && candidate.endsWith("/")) {
/*  265 */         return candidate.substring(0, candidate.length() - 1);
/*      */       }
/*  267 */       return candidate;
/*      */     }
/*      */     
/*      */     public String getApplicationDisplayName() {
/*  271 */       return this.applicationDisplayName;
/*      */     }
/*      */     
/*      */     public void setApplicationDisplayName(String displayName) {
/*  275 */       this.applicationDisplayName = displayName;
/*      */     }
/*      */     
/*      */     public Map<String, String> getContextParameters() {
/*  279 */       return this.contextParameters;
/*      */     }
/*      */     
/*      */     public Jsp getJsp() {
/*  283 */       return this.jsp;
/*      */     }
/*      */     
/*      */     public Session getSession() {
/*  287 */       return this.session;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Tomcat
/*      */   {
/*  300 */     private final Accesslog accesslog = new Accesslog();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  305 */     private String internalProxies = "10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.1[6-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.2[0-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.3[0-1]{1}\\.\\d{1,3}\\.\\d{1,3}|0:0:0:0:0:0:0:1|::1";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String protocolHeader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     private String protocolHeaderHttpsValue = "https";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  326 */     private String portHeader = "X-Forwarded-Port";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String remoteIpHeader;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  337 */     private String hostHeader = "X-Forwarded-Host";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private File basedir;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @DurationUnit(ChronoUnit.SECONDS)
/*  349 */     private Duration backgroundProcessorDelay = Duration.ofSeconds(10L);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  354 */     private int maxThreads = 200;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  359 */     private int minSpareThreads = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  364 */     private DataSize maxHttpFormPostSize = DataSize.ofMegabytes(2L);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  369 */     private DataSize maxSwallowSize = DataSize.ofMegabytes(2L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  375 */     private Boolean redirectContextRoot = Boolean.valueOf(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean useRelativeRedirects;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  386 */     private Charset uriEncoding = StandardCharsets.UTF_8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  393 */     private int maxConnections = 10000;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  399 */     private int acceptCount = 100;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  406 */     private int processorCache = 200;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  413 */     private List<String> additionalTldSkipPatterns = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  419 */     private List<Character> relaxedPathChars = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  425 */     private List<Character> relaxedQueryChars = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration connectionTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  436 */     private final Resource resource = new Resource();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  441 */     private final Mbeanregistry mbeanregistry = new Mbeanregistry();
/*      */     
/*      */     public int getMaxThreads() {
/*  444 */       return this.maxThreads;
/*      */     }
/*      */     
/*      */     public void setMaxThreads(int maxThreads) {
/*  448 */       this.maxThreads = maxThreads;
/*      */     }
/*      */     
/*      */     public int getMinSpareThreads() {
/*  452 */       return this.minSpareThreads;
/*      */     }
/*      */     
/*      */     public void setMinSpareThreads(int minSpareThreads) {
/*  456 */       this.minSpareThreads = minSpareThreads;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @DeprecatedConfigurationProperty(replacement = "server.tomcat.max-http-form-post-size")
/*      */     public DataSize getMaxHttpPostSize() {
/*  462 */       return this.maxHttpFormPostSize;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public void setMaxHttpPostSize(DataSize maxHttpPostSize) {
/*  467 */       this.maxHttpFormPostSize = maxHttpPostSize;
/*      */     }
/*      */     
/*      */     public DataSize getMaxHttpFormPostSize() {
/*  471 */       return this.maxHttpFormPostSize;
/*      */     }
/*      */     
/*      */     public void setMaxHttpFormPostSize(DataSize maxHttpFormPostSize) {
/*  475 */       this.maxHttpFormPostSize = maxHttpFormPostSize;
/*      */     }
/*      */     
/*      */     public Accesslog getAccesslog() {
/*  479 */       return this.accesslog;
/*      */     }
/*      */     
/*      */     public Duration getBackgroundProcessorDelay() {
/*  483 */       return this.backgroundProcessorDelay;
/*      */     }
/*      */     
/*      */     public void setBackgroundProcessorDelay(Duration backgroundProcessorDelay) {
/*  487 */       this.backgroundProcessorDelay = backgroundProcessorDelay;
/*      */     }
/*      */     
/*      */     public File getBasedir() {
/*  491 */       return this.basedir;
/*      */     }
/*      */     
/*      */     public void setBasedir(File basedir) {
/*  495 */       this.basedir = basedir;
/*      */     }
/*      */     
/*      */     public String getInternalProxies() {
/*  499 */       return this.internalProxies;
/*      */     }
/*      */     
/*      */     public void setInternalProxies(String internalProxies) {
/*  503 */       this.internalProxies = internalProxies;
/*      */     }
/*      */     
/*      */     public String getProtocolHeader() {
/*  507 */       return this.protocolHeader;
/*      */     }
/*      */     
/*      */     public void setProtocolHeader(String protocolHeader) {
/*  511 */       this.protocolHeader = protocolHeader;
/*      */     }
/*      */     
/*      */     public String getProtocolHeaderHttpsValue() {
/*  515 */       return this.protocolHeaderHttpsValue;
/*      */     }
/*      */     
/*      */     public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue) {
/*  519 */       this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
/*      */     }
/*      */     
/*      */     public String getPortHeader() {
/*  523 */       return this.portHeader;
/*      */     }
/*      */     
/*      */     public void setPortHeader(String portHeader) {
/*  527 */       this.portHeader = portHeader;
/*      */     }
/*      */     
/*      */     public Boolean getRedirectContextRoot() {
/*  531 */       return this.redirectContextRoot;
/*      */     }
/*      */     
/*      */     public void setRedirectContextRoot(Boolean redirectContextRoot) {
/*  535 */       this.redirectContextRoot = redirectContextRoot;
/*      */     }
/*      */     
/*      */     public Boolean getUseRelativeRedirects() {
/*  539 */       return this.useRelativeRedirects;
/*      */     }
/*      */     
/*      */     public void setUseRelativeRedirects(Boolean useRelativeRedirects) {
/*  543 */       this.useRelativeRedirects = useRelativeRedirects;
/*      */     }
/*      */     
/*      */     public String getRemoteIpHeader() {
/*  547 */       return this.remoteIpHeader;
/*      */     }
/*      */     
/*      */     public void setRemoteIpHeader(String remoteIpHeader) {
/*  551 */       this.remoteIpHeader = remoteIpHeader;
/*      */     }
/*      */     
/*      */     public String getHostHeader() {
/*  555 */       return this.hostHeader;
/*      */     }
/*      */     
/*      */     public void setHostHeader(String hostHeader) {
/*  559 */       this.hostHeader = hostHeader;
/*      */     }
/*      */     
/*      */     public Charset getUriEncoding() {
/*  563 */       return this.uriEncoding;
/*      */     }
/*      */     
/*      */     public void setUriEncoding(Charset uriEncoding) {
/*  567 */       this.uriEncoding = uriEncoding;
/*      */     }
/*      */     
/*      */     public int getMaxConnections() {
/*  571 */       return this.maxConnections;
/*      */     }
/*      */     
/*      */     public void setMaxConnections(int maxConnections) {
/*  575 */       this.maxConnections = maxConnections;
/*      */     }
/*      */     
/*      */     public DataSize getMaxSwallowSize() {
/*  579 */       return this.maxSwallowSize;
/*      */     }
/*      */     
/*      */     public void setMaxSwallowSize(DataSize maxSwallowSize) {
/*  583 */       this.maxSwallowSize = maxSwallowSize;
/*      */     }
/*      */     
/*      */     public int getAcceptCount() {
/*  587 */       return this.acceptCount;
/*      */     }
/*      */     
/*      */     public void setAcceptCount(int acceptCount) {
/*  591 */       this.acceptCount = acceptCount;
/*      */     }
/*      */     
/*      */     public int getProcessorCache() {
/*  595 */       return this.processorCache;
/*      */     }
/*      */     
/*      */     public void setProcessorCache(int processorCache) {
/*  599 */       this.processorCache = processorCache;
/*      */     }
/*      */     
/*      */     public List<String> getAdditionalTldSkipPatterns() {
/*  603 */       return this.additionalTldSkipPatterns;
/*      */     }
/*      */     
/*      */     public void setAdditionalTldSkipPatterns(List<String> additionalTldSkipPatterns) {
/*  607 */       this.additionalTldSkipPatterns = additionalTldSkipPatterns;
/*      */     }
/*      */     
/*      */     public List<Character> getRelaxedPathChars() {
/*  611 */       return this.relaxedPathChars;
/*      */     }
/*      */     
/*      */     public void setRelaxedPathChars(List<Character> relaxedPathChars) {
/*  615 */       this.relaxedPathChars = relaxedPathChars;
/*      */     }
/*      */     
/*      */     public List<Character> getRelaxedQueryChars() {
/*  619 */       return this.relaxedQueryChars;
/*      */     }
/*      */     
/*      */     public void setRelaxedQueryChars(List<Character> relaxedQueryChars) {
/*  623 */       this.relaxedQueryChars = relaxedQueryChars;
/*      */     }
/*      */     
/*      */     public Duration getConnectionTimeout() {
/*  627 */       return this.connectionTimeout;
/*      */     }
/*      */     
/*      */     public void setConnectionTimeout(Duration connectionTimeout) {
/*  631 */       this.connectionTimeout = connectionTimeout;
/*      */     }
/*      */     
/*      */     public Resource getResource() {
/*  635 */       return this.resource;
/*      */     }
/*      */     
/*      */     public Mbeanregistry getMbeanregistry() {
/*  639 */       return this.mbeanregistry;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Accesslog
/*      */     {
/*      */       private boolean enabled = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private String conditionIf;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private String conditionUnless;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  667 */       private String pattern = "common";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  673 */       private String directory = "logs";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  678 */       protected String prefix = "access_log";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  683 */       private String suffix = ".log";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private String encoding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private String locale;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private boolean checkExists = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private boolean rotate = true;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private boolean renameOnRotate = false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  717 */       private int maxDays = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  722 */       private String fileDateFormat = ".yyyy-MM-dd";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private boolean ipv6Canonical = false;
/*      */ 
/*      */ 
/*      */       
/*      */       private boolean requestAttributesEnabled = false;
/*      */ 
/*      */ 
/*      */       
/*      */       private boolean buffered = true;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isEnabled() {
/*  741 */         return this.enabled;
/*      */       }
/*      */       
/*      */       public void setEnabled(boolean enabled) {
/*  745 */         this.enabled = enabled;
/*      */       }
/*      */       
/*      */       public String getConditionIf() {
/*  749 */         return this.conditionIf;
/*      */       }
/*      */       
/*      */       public void setConditionIf(String conditionIf) {
/*  753 */         this.conditionIf = conditionIf;
/*      */       }
/*      */       
/*      */       public String getConditionUnless() {
/*  757 */         return this.conditionUnless;
/*      */       }
/*      */       
/*      */       public void setConditionUnless(String conditionUnless) {
/*  761 */         this.conditionUnless = conditionUnless;
/*      */       }
/*      */       
/*      */       public String getPattern() {
/*  765 */         return this.pattern;
/*      */       }
/*      */       
/*      */       public void setPattern(String pattern) {
/*  769 */         this.pattern = pattern;
/*      */       }
/*      */       
/*      */       public String getDirectory() {
/*  773 */         return this.directory;
/*      */       }
/*      */       
/*      */       public void setDirectory(String directory) {
/*  777 */         this.directory = directory;
/*      */       }
/*      */       
/*      */       public String getPrefix() {
/*  781 */         return this.prefix;
/*      */       }
/*      */       
/*      */       public void setPrefix(String prefix) {
/*  785 */         this.prefix = prefix;
/*      */       }
/*      */       
/*      */       public String getSuffix() {
/*  789 */         return this.suffix;
/*      */       }
/*      */       
/*      */       public void setSuffix(String suffix) {
/*  793 */         this.suffix = suffix;
/*      */       }
/*      */       
/*      */       public String getEncoding() {
/*  797 */         return this.encoding;
/*      */       }
/*      */       
/*      */       public void setEncoding(String encoding) {
/*  801 */         this.encoding = encoding;
/*      */       }
/*      */       
/*      */       public String getLocale() {
/*  805 */         return this.locale;
/*      */       }
/*      */       
/*      */       public void setLocale(String locale) {
/*  809 */         this.locale = locale;
/*      */       }
/*      */       
/*      */       public boolean isCheckExists() {
/*  813 */         return this.checkExists;
/*      */       }
/*      */       
/*      */       public void setCheckExists(boolean checkExists) {
/*  817 */         this.checkExists = checkExists;
/*      */       }
/*      */       
/*      */       public boolean isRotate() {
/*  821 */         return this.rotate;
/*      */       }
/*      */       
/*      */       public void setRotate(boolean rotate) {
/*  825 */         this.rotate = rotate;
/*      */       }
/*      */       
/*      */       public boolean isRenameOnRotate() {
/*  829 */         return this.renameOnRotate;
/*      */       }
/*      */       
/*      */       public void setRenameOnRotate(boolean renameOnRotate) {
/*  833 */         this.renameOnRotate = renameOnRotate;
/*      */       }
/*      */       
/*      */       public int getMaxDays() {
/*  837 */         return this.maxDays;
/*      */       }
/*      */       
/*      */       public void setMaxDays(int maxDays) {
/*  841 */         this.maxDays = maxDays;
/*      */       }
/*      */       
/*      */       public String getFileDateFormat() {
/*  845 */         return this.fileDateFormat;
/*      */       }
/*      */       
/*      */       public void setFileDateFormat(String fileDateFormat) {
/*  849 */         this.fileDateFormat = fileDateFormat;
/*      */       }
/*      */       
/*      */       public boolean isIpv6Canonical() {
/*  853 */         return this.ipv6Canonical;
/*      */       }
/*      */       
/*      */       public void setIpv6Canonical(boolean ipv6Canonical) {
/*  857 */         this.ipv6Canonical = ipv6Canonical;
/*      */       }
/*      */       
/*      */       public boolean isRequestAttributesEnabled() {
/*  861 */         return this.requestAttributesEnabled;
/*      */       }
/*      */       
/*      */       public void setRequestAttributesEnabled(boolean requestAttributesEnabled) {
/*  865 */         this.requestAttributesEnabled = requestAttributesEnabled;
/*      */       }
/*      */       
/*      */       public boolean isBuffered() {
/*  869 */         return this.buffered;
/*      */       }
/*      */       
/*      */       public void setBuffered(boolean buffered) {
/*  873 */         this.buffered = buffered;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Resource
/*      */     {
/*      */       private boolean allowCaching = true;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private Duration cacheTtl;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isAllowCaching() {
/*  894 */         return this.allowCaching;
/*      */       }
/*      */       
/*      */       public void setAllowCaching(boolean allowCaching) {
/*  898 */         this.allowCaching = allowCaching;
/*      */       }
/*      */       
/*      */       public Duration getCacheTtl() {
/*  902 */         return this.cacheTtl;
/*      */       }
/*      */       
/*      */       public void setCacheTtl(Duration cacheTtl) {
/*  906 */         this.cacheTtl = cacheTtl;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Mbeanregistry
/*      */     {
/*      */       private boolean enabled;
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isEnabled() {
/*  919 */         return this.enabled;
/*      */       }
/*      */       
/*      */       public void setEnabled(boolean enabled) {
/*  923 */         this.enabled = enabled;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Jetty
/*      */   {
/*  938 */     private final Accesslog accesslog = new Accesslog();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  943 */     private DataSize maxHttpFormPostSize = DataSize.ofBytes(200000L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  949 */     private Integer acceptors = Integer.valueOf(-1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  955 */     private Integer selectors = Integer.valueOf(-1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  960 */     private Integer maxThreads = Integer.valueOf(200);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  965 */     private Integer minThreads = Integer.valueOf(8);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  970 */     private Duration threadIdleTimeout = Duration.ofMillis(60000L);
/*      */ 
/*      */     
/*      */     private Duration connectionIdleTimeout;
/*      */ 
/*      */ 
/*      */     
/*      */     public Accesslog getAccesslog() {
/*  978 */       return this.accesslog;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @DeprecatedConfigurationProperty(replacement = "server.jetty.max-http-form-post-size")
/*      */     public DataSize getMaxHttpPostSize() {
/*  984 */       return this.maxHttpFormPostSize;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public void setMaxHttpPostSize(DataSize maxHttpPostSize) {
/*  989 */       this.maxHttpFormPostSize = maxHttpPostSize;
/*      */     }
/*      */     
/*      */     public DataSize getMaxHttpFormPostSize() {
/*  993 */       return this.maxHttpFormPostSize;
/*      */     }
/*      */     
/*      */     public void setMaxHttpFormPostSize(DataSize maxHttpFormPostSize) {
/*  997 */       this.maxHttpFormPostSize = maxHttpFormPostSize;
/*      */     }
/*      */     
/*      */     public Integer getAcceptors() {
/* 1001 */       return this.acceptors;
/*      */     }
/*      */     
/*      */     public void setAcceptors(Integer acceptors) {
/* 1005 */       this.acceptors = acceptors;
/*      */     }
/*      */     
/*      */     public Integer getSelectors() {
/* 1009 */       return this.selectors;
/*      */     }
/*      */     
/*      */     public void setSelectors(Integer selectors) {
/* 1013 */       this.selectors = selectors;
/*      */     }
/*      */     
/*      */     public void setMinThreads(Integer minThreads) {
/* 1017 */       this.minThreads = minThreads;
/*      */     }
/*      */     
/*      */     public Integer getMinThreads() {
/* 1021 */       return this.minThreads;
/*      */     }
/*      */     
/*      */     public void setMaxThreads(Integer maxThreads) {
/* 1025 */       this.maxThreads = maxThreads;
/*      */     }
/*      */     
/*      */     public Integer getMaxThreads() {
/* 1029 */       return this.maxThreads;
/*      */     }
/*      */     
/*      */     public void setThreadIdleTimeout(Duration threadIdleTimeout) {
/* 1033 */       this.threadIdleTimeout = threadIdleTimeout;
/*      */     }
/*      */     
/*      */     public Duration getThreadIdleTimeout() {
/* 1037 */       return this.threadIdleTimeout;
/*      */     }
/*      */     
/*      */     public Duration getConnectionIdleTimeout() {
/* 1041 */       return this.connectionIdleTimeout;
/*      */     }
/*      */     
/*      */     public void setConnectionIdleTimeout(Duration connectionIdleTimeout) {
/* 1045 */       this.connectionIdleTimeout = connectionIdleTimeout;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Accesslog
/*      */     {
/*      */       private boolean enabled = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1061 */       private FORMAT format = FORMAT.NCSA;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private String customFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private String filename;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private String fileDateFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1082 */       private int retentionPeriod = 31;
/*      */ 
/*      */ 
/*      */       
/*      */       private boolean append;
/*      */ 
/*      */ 
/*      */       
/*      */       private List<String> ignorePaths;
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isEnabled() {
/* 1095 */         return this.enabled;
/*      */       }
/*      */       
/*      */       public void setEnabled(boolean enabled) {
/* 1099 */         this.enabled = enabled;
/*      */       }
/*      */       
/*      */       public FORMAT getFormat() {
/* 1103 */         return this.format;
/*      */       }
/*      */       
/*      */       public void setFormat(FORMAT format) {
/* 1107 */         this.format = format;
/*      */       }
/*      */       
/*      */       public String getCustomFormat() {
/* 1111 */         return this.customFormat;
/*      */       }
/*      */       
/*      */       public void setCustomFormat(String customFormat) {
/* 1115 */         this.customFormat = customFormat;
/*      */       }
/*      */       
/*      */       public String getFilename() {
/* 1119 */         return this.filename;
/*      */       }
/*      */       
/*      */       public void setFilename(String filename) {
/* 1123 */         this.filename = filename;
/*      */       }
/*      */       
/*      */       public String getFileDateFormat() {
/* 1127 */         return this.fileDateFormat;
/*      */       }
/*      */       
/*      */       public void setFileDateFormat(String fileDateFormat) {
/* 1131 */         this.fileDateFormat = fileDateFormat;
/*      */       }
/*      */       
/*      */       public int getRetentionPeriod() {
/* 1135 */         return this.retentionPeriod;
/*      */       }
/*      */       
/*      */       public void setRetentionPeriod(int retentionPeriod) {
/* 1139 */         this.retentionPeriod = retentionPeriod;
/*      */       }
/*      */       
/*      */       public boolean isAppend() {
/* 1143 */         return this.append;
/*      */       }
/*      */       
/*      */       public void setAppend(boolean append) {
/* 1147 */         this.append = append;
/*      */       }
/*      */       
/*      */       public List<String> getIgnorePaths() {
/* 1151 */         return this.ignorePaths;
/*      */       }
/*      */       
/*      */       public void setIgnorePaths(List<String> ignorePaths) {
/* 1155 */         this.ignorePaths = ignorePaths;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum FORMAT
/*      */       {
/* 1166 */         NCSA,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1172 */         EXTENDED_NCSA;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Netty
/*      */   {
/*      */     private Duration connectionTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Duration getConnectionTimeout() {
/* 1191 */       return this.connectionTimeout;
/*      */     }
/*      */     
/*      */     public void setConnectionTimeout(Duration connectionTimeout) {
/* 1195 */       this.connectionTimeout = connectionTimeout;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Undertow
/*      */   {
/* 1209 */     private DataSize maxHttpPostSize = DataSize.ofBytes(-1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DataSize bufferSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer ioThreads;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer workerThreads;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean directBuffers;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean eagerFilterInit = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1243 */     private int maxParameters = 1000;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1249 */     private int maxHeaders = 200;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1255 */     private int maxCookies = 200;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean allowEncodedSlash = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean decodeUrl = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1274 */     private Charset urlCharset = StandardCharsets.UTF_8;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean alwaysSetKeepAlive = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration noRequestTimeout;
/*      */ 
/*      */ 
/*      */     
/* 1288 */     private final Accesslog accesslog = new Accesslog();
/*      */     
/* 1290 */     private final Options options = new Options();
/*      */     
/*      */     public DataSize getMaxHttpPostSize() {
/* 1293 */       return this.maxHttpPostSize;
/*      */     }
/*      */     
/*      */     public void setMaxHttpPostSize(DataSize maxHttpPostSize) {
/* 1297 */       this.maxHttpPostSize = maxHttpPostSize;
/*      */     }
/*      */     
/*      */     public DataSize getBufferSize() {
/* 1301 */       return this.bufferSize;
/*      */     }
/*      */     
/*      */     public void setBufferSize(DataSize bufferSize) {
/* 1305 */       this.bufferSize = bufferSize;
/*      */     }
/*      */     
/*      */     public Integer getIoThreads() {
/* 1309 */       return this.ioThreads;
/*      */     }
/*      */     
/*      */     public void setIoThreads(Integer ioThreads) {
/* 1313 */       this.ioThreads = ioThreads;
/*      */     }
/*      */     
/*      */     public Integer getWorkerThreads() {
/* 1317 */       return this.workerThreads;
/*      */     }
/*      */     
/*      */     public void setWorkerThreads(Integer workerThreads) {
/* 1321 */       this.workerThreads = workerThreads;
/*      */     }
/*      */     
/*      */     public Boolean getDirectBuffers() {
/* 1325 */       return this.directBuffers;
/*      */     }
/*      */     
/*      */     public void setDirectBuffers(Boolean directBuffers) {
/* 1329 */       this.directBuffers = directBuffers;
/*      */     }
/*      */     
/*      */     public boolean isEagerFilterInit() {
/* 1333 */       return this.eagerFilterInit;
/*      */     }
/*      */     
/*      */     public void setEagerFilterInit(boolean eagerFilterInit) {
/* 1337 */       this.eagerFilterInit = eagerFilterInit;
/*      */     }
/*      */     
/*      */     public int getMaxParameters() {
/* 1341 */       return this.maxParameters;
/*      */     }
/*      */     
/*      */     public void setMaxParameters(Integer maxParameters) {
/* 1345 */       this.maxParameters = maxParameters.intValue();
/*      */     }
/*      */     
/*      */     public int getMaxHeaders() {
/* 1349 */       return this.maxHeaders;
/*      */     }
/*      */     
/*      */     public void setMaxHeaders(int maxHeaders) {
/* 1353 */       this.maxHeaders = maxHeaders;
/*      */     }
/*      */     
/*      */     public Integer getMaxCookies() {
/* 1357 */       return Integer.valueOf(this.maxCookies);
/*      */     }
/*      */     
/*      */     public void setMaxCookies(Integer maxCookies) {
/* 1361 */       this.maxCookies = maxCookies.intValue();
/*      */     }
/*      */     
/*      */     public boolean isAllowEncodedSlash() {
/* 1365 */       return this.allowEncodedSlash;
/*      */     }
/*      */     
/*      */     public void setAllowEncodedSlash(boolean allowEncodedSlash) {
/* 1369 */       this.allowEncodedSlash = allowEncodedSlash;
/*      */     }
/*      */     
/*      */     public boolean isDecodeUrl() {
/* 1373 */       return this.decodeUrl;
/*      */     }
/*      */     
/*      */     public void setDecodeUrl(Boolean decodeUrl) {
/* 1377 */       this.decodeUrl = decodeUrl.booleanValue();
/*      */     }
/*      */     
/*      */     public Charset getUrlCharset() {
/* 1381 */       return this.urlCharset;
/*      */     }
/*      */     
/*      */     public void setUrlCharset(Charset urlCharset) {
/* 1385 */       this.urlCharset = urlCharset;
/*      */     }
/*      */     
/*      */     public boolean isAlwaysSetKeepAlive() {
/* 1389 */       return this.alwaysSetKeepAlive;
/*      */     }
/*      */     
/*      */     public void setAlwaysSetKeepAlive(boolean alwaysSetKeepAlive) {
/* 1393 */       this.alwaysSetKeepAlive = alwaysSetKeepAlive;
/*      */     }
/*      */     
/*      */     public Duration getNoRequestTimeout() {
/* 1397 */       return this.noRequestTimeout;
/*      */     }
/*      */     
/*      */     public void setNoRequestTimeout(Duration noRequestTimeout) {
/* 1401 */       this.noRequestTimeout = noRequestTimeout;
/*      */     }
/*      */     
/*      */     public Accesslog getAccesslog() {
/* 1405 */       return this.accesslog;
/*      */     }
/*      */     
/*      */     public Options getOptions() {
/* 1409 */       return this.options;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Accesslog
/*      */     {
/*      */       private boolean enabled = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1425 */       private String pattern = "common";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1430 */       protected String prefix = "access_log.";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1435 */       private String suffix = "log";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1440 */       private File dir = new File("logs");
/*      */ 
/*      */       
/*      */       private boolean rotate = true;
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isEnabled() {
/* 1448 */         return this.enabled;
/*      */       }
/*      */       
/*      */       public void setEnabled(boolean enabled) {
/* 1452 */         this.enabled = enabled;
/*      */       }
/*      */       
/*      */       public String getPattern() {
/* 1456 */         return this.pattern;
/*      */       }
/*      */       
/*      */       public void setPattern(String pattern) {
/* 1460 */         this.pattern = pattern;
/*      */       }
/*      */       
/*      */       public String getPrefix() {
/* 1464 */         return this.prefix;
/*      */       }
/*      */       
/*      */       public void setPrefix(String prefix) {
/* 1468 */         this.prefix = prefix;
/*      */       }
/*      */       
/*      */       public String getSuffix() {
/* 1472 */         return this.suffix;
/*      */       }
/*      */       
/*      */       public void setSuffix(String suffix) {
/* 1476 */         this.suffix = suffix;
/*      */       }
/*      */       
/*      */       public File getDir() {
/* 1480 */         return this.dir;
/*      */       }
/*      */       
/*      */       public void setDir(File dir) {
/* 1484 */         this.dir = dir;
/*      */       }
/*      */       
/*      */       public boolean isRotate() {
/* 1488 */         return this.rotate;
/*      */       }
/*      */       
/*      */       public void setRotate(boolean rotate) {
/* 1492 */         this.rotate = rotate;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public static class Options
/*      */     {
/* 1499 */       private Map<String, String> socket = new LinkedHashMap<>();
/*      */       
/* 1501 */       private Map<String, String> server = new LinkedHashMap<>();
/*      */       
/*      */       public Map<String, String> getServer() {
/* 1504 */         return this.server;
/*      */       }
/*      */       
/*      */       public Map<String, String> getSocket() {
/* 1508 */         return this.socket;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum ForwardHeadersStrategy
/*      */   {
/* 1523 */     NATIVE,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1528 */     FRAMEWORK,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1533 */     NONE;
/*      */   }
/*      */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\web\ServerProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
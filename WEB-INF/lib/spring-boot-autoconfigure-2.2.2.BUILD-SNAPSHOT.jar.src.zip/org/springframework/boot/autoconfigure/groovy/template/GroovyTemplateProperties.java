/*    */ package org.springframework.boot.autoconfigure.groovy.template;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.template.AbstractTemplateViewResolverProperties;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.groovy.template", ignoreUnknownFields = true)
/*    */ public class GroovyTemplateProperties
/*    */   extends AbstractTemplateViewResolverProperties
/*    */ {
/*    */   public static final String DEFAULT_RESOURCE_LOADER_PATH = "classpath:/templates/";
/*    */   public static final String DEFAULT_PREFIX = "";
/*    */   public static final String DEFAULT_SUFFIX = ".tpl";
/*    */   public static final String DEFAULT_REQUEST_CONTEXT_ATTRIBUTE = "spring";
/* 44 */   private String resourceLoaderPath = "classpath:/templates/";
/*    */   
/*    */   public GroovyTemplateProperties() {
/* 47 */     super("", ".tpl");
/* 48 */     setRequestContextAttribute("spring");
/*    */   }
/*    */   
/*    */   public String getResourceLoaderPath() {
/* 52 */     return this.resourceLoaderPath;
/*    */   }
/*    */   
/*    */   public void setResourceLoaderPath(String resourceLoaderPath) {
/* 56 */     this.resourceLoaderPath = resourceLoaderPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\groovy\template\GroovyTemplateProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
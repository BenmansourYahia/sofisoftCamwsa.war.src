/*    */ package org.springframework.boot.autoconfigure.influx;
/*    */ 
/*    */ import okhttp3.OkHttpClient;
/*    */ import org.influxdb.InfluxDB;
/*    */ import org.influxdb.impl.InfluxDBImpl;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({InfluxDB.class})
/*    */ @EnableConfigurationProperties({InfluxDbProperties.class})
/*    */ public class InfluxDbAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   @ConditionalOnProperty({"spring.influx.url"})
/*    */   public InfluxDB influxDb(InfluxDbProperties properties, ObjectProvider<InfluxDbOkHttpClientBuilderProvider> builder) {
/* 50 */     return (InfluxDB)new InfluxDBImpl(properties.getUrl(), properties.getUser(), properties.getPassword(), 
/* 51 */         determineBuilder((InfluxDbOkHttpClientBuilderProvider)builder.getIfAvailable()));
/*    */   }
/*    */   
/*    */   private static OkHttpClient.Builder determineBuilder(InfluxDbOkHttpClientBuilderProvider builder) {
/* 55 */     if (builder != null) {
/* 56 */       return builder.get();
/*    */     }
/* 58 */     return new OkHttpClient.Builder();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\influx\InfluxDbAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
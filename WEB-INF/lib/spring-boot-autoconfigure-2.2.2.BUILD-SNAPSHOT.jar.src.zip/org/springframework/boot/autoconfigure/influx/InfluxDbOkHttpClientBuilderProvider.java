package org.springframework.boot.autoconfigure.influx;

import java.util.function.Supplier;
import okhttp3.OkHttpClient;

@FunctionalInterface
public interface InfluxDbOkHttpClientBuilderProvider extends Supplier<OkHttpClient.Builder> {}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\influx\InfluxDbOkHttpClientBuilderProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.Message;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.jms.core.JmsMessageOperations;
/*     */ import org.springframework.jms.core.JmsMessagingTemplate;
/*     */ import org.springframework.jms.core.JmsOperations;
/*     */ import org.springframework.jms.core.JmsTemplate;
/*     */ import org.springframework.jms.support.converter.MessageConverter;
/*     */ import org.springframework.jms.support.destination.DestinationResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({Message.class, JmsTemplate.class})
/*     */ @ConditionalOnBean({ConnectionFactory.class})
/*     */ @EnableConfigurationProperties({JmsProperties.class})
/*     */ @Import({JmsAnnotationDrivenConfiguration.class})
/*     */ public class JmsAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   protected static class JmsTemplateConfiguration
/*     */   {
/*     */     private final JmsProperties properties;
/*     */     private final ObjectProvider<DestinationResolver> destinationResolver;
/*     */     private final ObjectProvider<MessageConverter> messageConverter;
/*     */     
/*     */     public JmsTemplateConfiguration(JmsProperties properties, ObjectProvider<DestinationResolver> destinationResolver, ObjectProvider<MessageConverter> messageConverter) {
/*  70 */       this.properties = properties;
/*  71 */       this.destinationResolver = destinationResolver;
/*  72 */       this.messageConverter = messageConverter;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({JmsOperations.class})
/*     */     @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*     */     public JmsTemplate jmsTemplate(ConnectionFactory connectionFactory) {
/*  79 */       PropertyMapper map = PropertyMapper.get();
/*  80 */       JmsTemplate template = new JmsTemplate(connectionFactory);
/*  81 */       template.setPubSubDomain(this.properties.isPubSubDomain());
/*  82 */       map.from(this.destinationResolver::getIfUnique).whenNonNull().to(template::setDestinationResolver);
/*  83 */       map.from(this.messageConverter::getIfUnique).whenNonNull().to(template::setMessageConverter);
/*  84 */       mapTemplateProperties(this.properties.getTemplate(), template);
/*  85 */       return template;
/*     */     }
/*     */     
/*     */     private void mapTemplateProperties(JmsProperties.Template properties, JmsTemplate template) {
/*  89 */       PropertyMapper map = PropertyMapper.get();
/*  90 */       map.from(properties::getDefaultDestination).whenNonNull().to(template::setDefaultDestinationName);
/*  91 */       map.from(properties::getDeliveryDelay).whenNonNull().as(Duration::toMillis).to(template::setDeliveryDelay);
/*  92 */       map.from(properties::determineQosEnabled).to(template::setExplicitQosEnabled);
/*  93 */       map.from(properties::getDeliveryMode).whenNonNull().as(JmsProperties.DeliveryMode::getValue)
/*  94 */         .to(template::setDeliveryMode);
/*  95 */       map.from(properties::getPriority).whenNonNull().to(template::setPriority);
/*  96 */       map.from(properties::getTimeToLive).whenNonNull().as(Duration::toMillis).to(template::setTimeToLive);
/*  97 */       map.from(properties::getReceiveTimeout).whenNonNull().as(Duration::toMillis)
/*  98 */         .to(template::setReceiveTimeout);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({JmsMessagingTemplate.class})
/*     */   @Import({JmsTemplateConfiguration.class})
/*     */   protected static class MessagingTemplateConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({JmsMessageOperations.class})
/*     */     @ConditionalOnSingleCandidate(JmsTemplate.class)
/*     */     public JmsMessagingTemplate jmsMessagingTemplate(JmsProperties properties, JmsTemplate jmsTemplate) {
/* 112 */       JmsMessagingTemplate messagingTemplate = new JmsMessagingTemplate(jmsTemplate);
/* 113 */       mapTemplateProperties(properties.getTemplate(), messagingTemplate);
/* 114 */       return messagingTemplate;
/*     */     }
/*     */     
/*     */     private void mapTemplateProperties(JmsProperties.Template properties, JmsMessagingTemplate messagingTemplate) {
/* 118 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 119 */       map.from(properties::getDefaultDestination).to(messagingTemplate::setDefaultDestinationName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\JmsAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
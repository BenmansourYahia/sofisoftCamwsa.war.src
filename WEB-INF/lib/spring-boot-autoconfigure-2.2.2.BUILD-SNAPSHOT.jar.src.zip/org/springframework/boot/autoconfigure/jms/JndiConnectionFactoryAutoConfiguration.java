/*    */ package org.springframework.boot.autoconfigure.jms;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.naming.NamingException;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnJndi;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.jms.core.JmsTemplate;
/*    */ import org.springframework.jndi.JndiLocatorDelegate;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @AutoConfigureBefore({JmsAutoConfiguration.class})
/*    */ @ConditionalOnClass({JmsTemplate.class})
/*    */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*    */ @Conditional({JndiConnectionFactoryAutoConfiguration.JndiOrPropertyCondition.class})
/*    */ @EnableConfigurationProperties({JmsProperties.class})
/*    */ public class JndiConnectionFactoryAutoConfiguration
/*    */ {
/* 55 */   private static final String[] JNDI_LOCATIONS = new String[] { "java:/JmsXA", "java:/XAConnectionFactory" };
/*    */   
/*    */   @Bean
/*    */   public ConnectionFactory connectionFactory(JmsProperties properties) throws NamingException {
/* 59 */     JndiLocatorDelegate jndiLocatorDelegate = JndiLocatorDelegate.createDefaultResourceRefLocator();
/* 60 */     if (StringUtils.hasLength(properties.getJndiName())) {
/* 61 */       return (ConnectionFactory)jndiLocatorDelegate.lookup(properties.getJndiName(), ConnectionFactory.class);
/*    */     }
/* 63 */     return findJndiConnectionFactory(jndiLocatorDelegate);
/*    */   }
/*    */   
/*    */   private ConnectionFactory findJndiConnectionFactory(JndiLocatorDelegate jndiLocatorDelegate) {
/* 67 */     for (String name : JNDI_LOCATIONS) {
/*    */       try {
/* 69 */         return (ConnectionFactory)jndiLocatorDelegate.lookup(name, ConnectionFactory.class);
/*    */       }
/* 71 */       catch (NamingException namingException) {}
/*    */     } 
/*    */ 
/*    */     
/* 75 */     throw new IllegalStateException("Unable to find ConnectionFactory in JNDI locations " + 
/* 76 */         Arrays.asList(JNDI_LOCATIONS));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static class JndiOrPropertyCondition
/*    */     extends AnyNestedCondition
/*    */   {
/*    */     JndiOrPropertyCondition() {
/* 85 */       super(ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION);
/*    */     }
/*    */     
/*    */     @ConditionalOnJndi({"java:/JmsXA", "java:/XAConnectionFactory"})
/*    */     static class Jndi {}
/*    */     
/*    */     @ConditionalOnProperty(prefix = "spring.jms", name = {"jndi-name"})
/*    */     static class Property {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\JndiConnectionFactoryAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
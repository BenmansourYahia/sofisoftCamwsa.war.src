/*     */ package org.springframework.boot.autoconfigure.jms.artemis;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsPoolConnectionFactoryProperties;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.artemis")
/*     */ public class ArtemisProperties
/*     */ {
/*     */   private ArtemisMode mode;
/*  48 */   private String host = "localhost";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private int port = 61616;
/*     */ 
/*     */ 
/*     */   
/*     */   private String user;
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */   
/*  65 */   private final Embedded embedded = new Embedded();
/*     */   @NestedConfigurationProperty
/*  67 */   private final JmsPoolConnectionFactoryProperties pool = new JmsPoolConnectionFactoryProperties();
/*     */ 
/*     */   
/*     */   public ArtemisMode getMode() {
/*  71 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(ArtemisMode mode) {
/*  75 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public String getHost() {
/*  79 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/*  83 */     this.host = host;
/*     */   }
/*     */   
/*     */   public int getPort() {
/*  87 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  91 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getUser() {
/*  95 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/*  99 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 103 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 107 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Embedded getEmbedded() {
/* 111 */     return this.embedded;
/*     */   }
/*     */   
/*     */   public JmsPoolConnectionFactoryProperties getPool() {
/* 115 */     return this.pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Embedded
/*     */   {
/* 123 */     private static final AtomicInteger serverIdCounter = new AtomicInteger();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     private int serverId = serverIdCounter.getAndIncrement();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean enabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean persistent;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String dataDirectory;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     private String[] queues = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     private String[] topics = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     private String clusterPassword = UUID.randomUUID().toString();
/*     */     
/*     */     private boolean defaultClusterPassword = true;
/*     */     
/*     */     public int getServerId() {
/* 163 */       return this.serverId;
/*     */     }
/*     */     
/*     */     public void setServerId(int serverId) {
/* 167 */       this.serverId = serverId;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 171 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 175 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public boolean isPersistent() {
/* 179 */       return this.persistent;
/*     */     }
/*     */     
/*     */     public void setPersistent(boolean persistent) {
/* 183 */       this.persistent = persistent;
/*     */     }
/*     */     
/*     */     public String getDataDirectory() {
/* 187 */       return this.dataDirectory;
/*     */     }
/*     */     
/*     */     public void setDataDirectory(String dataDirectory) {
/* 191 */       this.dataDirectory = dataDirectory;
/*     */     }
/*     */     
/*     */     public String[] getQueues() {
/* 195 */       return this.queues;
/*     */     }
/*     */     
/*     */     public void setQueues(String[] queues) {
/* 199 */       this.queues = queues;
/*     */     }
/*     */     
/*     */     public String[] getTopics() {
/* 203 */       return this.topics;
/*     */     }
/*     */     
/*     */     public void setTopics(String[] topics) {
/* 207 */       this.topics = topics;
/*     */     }
/*     */     
/*     */     public String getClusterPassword() {
/* 211 */       return this.clusterPassword;
/*     */     }
/*     */     
/*     */     public void setClusterPassword(String clusterPassword) {
/* 215 */       this.clusterPassword = clusterPassword;
/* 216 */       this.defaultClusterPassword = false;
/*     */     }
/*     */     
/*     */     public boolean isDefaultClusterPassword() {
/* 220 */       return this.defaultClusterPassword;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<String, Object> generateTransportParameters() {
/* 230 */       Map<String, Object> parameters = new HashMap<>();
/* 231 */       parameters.put("serverId", Integer.valueOf(getServerId()));
/* 232 */       return parameters;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
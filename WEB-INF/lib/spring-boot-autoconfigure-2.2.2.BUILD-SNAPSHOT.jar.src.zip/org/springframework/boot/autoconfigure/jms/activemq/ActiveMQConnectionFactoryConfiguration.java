/*     */ package org.springframework.boot.autoconfigure.jms.activemq;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import org.apache.activemq.ActiveMQConnectionFactory;
/*     */ import org.apache.commons.pool2.PooledObject;
/*     */ import org.messaginghub.pooled.jms.JmsPoolConnectionFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsPoolConnectionFactoryFactory;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.jms.connection.CachingConnectionFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*     */ class ActiveMQConnectionFactoryConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnProperty(prefix = "spring.activemq.pool", name = {"enabled"}, havingValue = "false", matchIfMissing = true)
/*     */   static class SimpleConnectionFactoryConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnProperty(prefix = "spring.jms.cache", name = {"enabled"}, havingValue = "false")
/*     */     ActiveMQConnectionFactory jmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers) {
/*  59 */       return createJmsConnectionFactory(properties, factoryCustomizers);
/*     */     }
/*     */ 
/*     */     
/*     */     private static ActiveMQConnectionFactory createJmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers) {
/*  64 */       return (new ActiveMQConnectionFactoryFactory(properties, (List<ActiveMQConnectionFactoryCustomizer>)factoryCustomizers
/*  65 */           .orderedStream().collect(Collectors.toList())))
/*  66 */         .createConnectionFactory(ActiveMQConnectionFactory.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     @ConditionalOnClass({CachingConnectionFactory.class})
/*     */     @ConditionalOnProperty(prefix = "spring.jms.cache", name = {"enabled"}, havingValue = "true", matchIfMissing = true)
/*     */     static class CachingConnectionFactoryConfiguration
/*     */     {
/*     */       @Bean
/*     */       CachingConnectionFactory cachingJmsConnectionFactory(JmsProperties jmsProperties, ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers) {
/*  79 */         JmsProperties.Cache cacheProperties = jmsProperties.getCache();
/*     */         
/*  81 */         CachingConnectionFactory connectionFactory = new CachingConnectionFactory((ConnectionFactory)ActiveMQConnectionFactoryConfiguration.SimpleConnectionFactoryConfiguration.createJmsConnectionFactory(properties, factoryCustomizers));
/*  82 */         connectionFactory.setCacheConsumers(cacheProperties.isConsumers());
/*  83 */         connectionFactory.setCacheProducers(cacheProperties.isProducers());
/*  84 */         connectionFactory.setSessionCacheSize(cacheProperties.getSessionCacheSize());
/*  85 */         return connectionFactory;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({JmsPoolConnectionFactory.class, PooledObject.class})
/*     */   static class PooledConnectionFactoryConfiguration
/*     */   {
/*     */     @Bean(destroyMethod = "stop")
/*     */     @ConditionalOnProperty(prefix = "spring.activemq.pool", name = {"enabled"}, havingValue = "true")
/*     */     JmsPoolConnectionFactory pooledJmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers) {
/* 102 */       ActiveMQConnectionFactory connectionFactory = (new ActiveMQConnectionFactoryFactory(properties, (List<ActiveMQConnectionFactoryCustomizer>)factoryCustomizers.orderedStream().collect(Collectors.toList()))).createConnectionFactory(ActiveMQConnectionFactory.class);
/* 103 */       return (new JmsPoolConnectionFactoryFactory(properties.getPool()))
/* 104 */         .createPooledConnectionFactory((ConnectionFactory)connectionFactory);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQConnectionFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
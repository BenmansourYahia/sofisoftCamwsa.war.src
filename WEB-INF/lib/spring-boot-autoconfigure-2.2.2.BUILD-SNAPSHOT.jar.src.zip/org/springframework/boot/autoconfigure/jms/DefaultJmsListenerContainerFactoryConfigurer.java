/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
/*     */ import org.springframework.jms.support.converter.MessageConverter;
/*     */ import org.springframework.jms.support.destination.DestinationResolver;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultJmsListenerContainerFactoryConfigurer
/*     */ {
/*     */   private DestinationResolver destinationResolver;
/*     */   private MessageConverter messageConverter;
/*     */   private JtaTransactionManager transactionManager;
/*     */   private JmsProperties jmsProperties;
/*     */   
/*     */   void setDestinationResolver(DestinationResolver destinationResolver) {
/*  51 */     this.destinationResolver = destinationResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessageConverter(MessageConverter messageConverter) {
/*  60 */     this.messageConverter = messageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTransactionManager(JtaTransactionManager transactionManager) {
/*  69 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setJmsProperties(JmsProperties jmsProperties) {
/*  77 */     this.jmsProperties = jmsProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(DefaultJmsListenerContainerFactory factory, ConnectionFactory connectionFactory) {
/*  87 */     Assert.notNull(factory, "Factory must not be null");
/*  88 */     Assert.notNull(connectionFactory, "ConnectionFactory must not be null");
/*  89 */     factory.setConnectionFactory(connectionFactory);
/*  90 */     factory.setPubSubDomain(Boolean.valueOf(this.jmsProperties.isPubSubDomain()));
/*  91 */     if (this.transactionManager != null) {
/*  92 */       factory.setTransactionManager((PlatformTransactionManager)this.transactionManager);
/*     */     } else {
/*     */       
/*  95 */       factory.setSessionTransacted(Boolean.valueOf(true));
/*     */     } 
/*  97 */     if (this.destinationResolver != null) {
/*  98 */       factory.setDestinationResolver(this.destinationResolver);
/*     */     }
/* 100 */     if (this.messageConverter != null) {
/* 101 */       factory.setMessageConverter(this.messageConverter);
/*     */     }
/* 103 */     JmsProperties.Listener listener = this.jmsProperties.getListener();
/* 104 */     factory.setAutoStartup(listener.isAutoStartup());
/* 105 */     if (listener.getAcknowledgeMode() != null) {
/* 106 */       factory.setSessionAcknowledgeMode(Integer.valueOf(listener.getAcknowledgeMode().getMode()));
/*     */     }
/* 108 */     String concurrency = listener.formatConcurrency();
/* 109 */     if (concurrency != null) {
/* 110 */       factory.setConcurrency(concurrency);
/*     */     }
/* 112 */     Duration receiveTimeout = listener.getReceiveTimeout();
/* 113 */     if (receiveTimeout != null)
/* 114 */       factory.setReceiveTimeout(Long.valueOf(receiveTimeout.toMillis())); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\DefaultJmsListenerContainerFactoryConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
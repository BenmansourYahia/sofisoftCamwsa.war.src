/*     */ package org.springframework.boot.autoconfigure.jms.artemis;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.activemq.artemis.api.core.TransportConfiguration;
/*     */ import org.apache.activemq.artemis.api.core.client.ActiveMQClient;
/*     */ import org.apache.activemq.artemis.api.core.client.ServerLocator;
/*     */ import org.apache.activemq.artemis.core.remoting.impl.invm.InVMConnectorFactory;
/*     */ import org.apache.activemq.artemis.core.remoting.impl.netty.NettyConnectorFactory;
/*     */ import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArtemisConnectionFactoryFactory
/*     */ {
/*  46 */   static final String[] EMBEDDED_JMS_CLASSES = new String[] { "org.apache.activemq.artemis.jms.server.embedded.EmbeddedJMS", "org.apache.activemq.artemis.core.server.embedded.EmbeddedActiveMQ" };
/*     */   
/*     */   private final ArtemisProperties properties;
/*     */   
/*     */   private final ListableBeanFactory beanFactory;
/*     */ 
/*     */   
/*     */   ArtemisConnectionFactoryFactory(ListableBeanFactory beanFactory, ArtemisProperties properties) {
/*  54 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*  55 */     Assert.notNull(properties, "Properties must not be null");
/*  56 */     this.beanFactory = beanFactory;
/*  57 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   <T extends ActiveMQConnectionFactory> T createConnectionFactory(Class<T> factoryClass) {
/*     */     try {
/*  62 */       startEmbeddedJms();
/*  63 */       return doCreateConnectionFactory(factoryClass);
/*     */     }
/*  65 */     catch (Exception ex) {
/*  66 */       throw new IllegalStateException("Unable to create ActiveMQConnectionFactory", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void startEmbeddedJms() {
/*  71 */     for (int i = 0; i < EMBEDDED_JMS_CLASSES.length; i++) {
/*  72 */       if (ClassUtils.isPresent(EMBEDDED_JMS_CLASSES[i], null)) {
/*     */         try {
/*  74 */           this.beanFactory.getBeansOfType(Class.forName(EMBEDDED_JMS_CLASSES[i]));
/*     */         }
/*  76 */         catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T doCreateConnectionFactory(Class<T> factoryClass) throws Exception {
/*  84 */     ArtemisMode mode = this.properties.getMode();
/*  85 */     if (mode == null) {
/*  86 */       mode = deduceMode();
/*     */     }
/*  88 */     if (mode == ArtemisMode.EMBEDDED) {
/*  89 */       return createEmbeddedConnectionFactory(factoryClass);
/*     */     }
/*  91 */     return createNativeConnectionFactory(factoryClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArtemisMode deduceMode() {
/*  99 */     if (this.properties.getEmbedded().isEnabled() && isEmbeddedJmsClassPresent()) {
/* 100 */       return ArtemisMode.EMBEDDED;
/*     */     }
/* 102 */     return ArtemisMode.NATIVE;
/*     */   }
/*     */   
/*     */   private boolean isEmbeddedJmsClassPresent() {
/* 106 */     for (int i = 0; i < EMBEDDED_JMS_CLASSES.length; i++) {
/* 107 */       if (ClassUtils.isPresent(EMBEDDED_JMS_CLASSES[i], null)) {
/* 108 */         return true;
/*     */       }
/*     */     } 
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T createEmbeddedConnectionFactory(Class<T> factoryClass) throws Exception {
/*     */     try {
/* 118 */       TransportConfiguration transportConfiguration = new TransportConfiguration(InVMConnectorFactory.class.getName(), this.properties.getEmbedded().generateTransportParameters());
/* 119 */       ServerLocator serviceLocator = ActiveMQClient.createServerLocatorWithoutHA(new TransportConfiguration[] { transportConfiguration });
/* 120 */       return (T)factoryClass.getConstructor(new Class[] { ServerLocator.class }).newInstance(new Object[] { serviceLocator });
/*     */     }
/* 122 */     catch (NoClassDefFoundError ex) {
/* 123 */       throw new IllegalStateException("Unable to create InVM Artemis connection, ensure that artemis-jms-server.jar is in the classpath", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T createNativeConnectionFactory(Class<T> factoryClass) throws Exception {
/* 130 */     Map<String, Object> params = new HashMap<>();
/* 131 */     params.put("host", this.properties.getHost());
/* 132 */     params.put("port", Integer.valueOf(this.properties.getPort()));
/*     */     
/* 134 */     TransportConfiguration transportConfiguration = new TransportConfiguration(NettyConnectorFactory.class.getName(), params);
/* 135 */     Constructor<T> constructor = factoryClass.getConstructor(new Class[] { boolean.class, TransportConfiguration[].class });
/* 136 */     ActiveMQConnectionFactory activeMQConnectionFactory = (ActiveMQConnectionFactory)constructor.newInstance(new Object[] { Boolean.valueOf(false), { transportConfiguration } });
/* 137 */     String user = this.properties.getUser();
/* 138 */     if (StringUtils.hasText(user)) {
/* 139 */       activeMQConnectionFactory.setUser(user);
/* 140 */       activeMQConnectionFactory.setPassword(this.properties.getPassword());
/*     */     } 
/* 142 */     return (T)activeMQConnectionFactory;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisConnectionFactoryFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
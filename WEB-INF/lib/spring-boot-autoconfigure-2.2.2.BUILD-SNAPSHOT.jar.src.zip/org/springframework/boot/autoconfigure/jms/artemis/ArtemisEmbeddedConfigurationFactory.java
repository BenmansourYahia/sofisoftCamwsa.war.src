/*    */ package org.springframework.boot.autoconfigure.jms.artemis;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.apache.activemq.artemis.api.core.RoutingType;
/*    */ import org.apache.activemq.artemis.api.core.SimpleString;
/*    */ import org.apache.activemq.artemis.api.core.TransportConfiguration;
/*    */ import org.apache.activemq.artemis.core.config.Configuration;
/*    */ import org.apache.activemq.artemis.core.config.CoreAddressConfiguration;
/*    */ import org.apache.activemq.artemis.core.config.CoreQueueConfiguration;
/*    */ import org.apache.activemq.artemis.core.config.impl.ConfigurationImpl;
/*    */ import org.apache.activemq.artemis.core.remoting.impl.invm.InVMAcceptorFactory;
/*    */ import org.apache.activemq.artemis.core.server.JournalType;
/*    */ import org.apache.activemq.artemis.core.settings.impl.AddressSettings;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ArtemisEmbeddedConfigurationFactory
/*    */ {
/* 43 */   private static final Log logger = LogFactory.getLog(ArtemisEmbeddedConfigurationFactory.class);
/*    */   
/*    */   private final ArtemisProperties.Embedded properties;
/*    */   
/*    */   ArtemisEmbeddedConfigurationFactory(ArtemisProperties properties) {
/* 48 */     this.properties = properties.getEmbedded();
/*    */   }
/*    */   
/*    */   Configuration createConfiguration() {
/* 52 */     ConfigurationImpl configuration = new ConfigurationImpl();
/* 53 */     configuration.setSecurityEnabled(false);
/* 54 */     configuration.setPersistenceEnabled(this.properties.isPersistent());
/* 55 */     String dataDir = getDataDir();
/* 56 */     configuration.setJournalDirectory(dataDir + "/journal");
/* 57 */     if (this.properties.isPersistent()) {
/* 58 */       configuration.setJournalType(JournalType.NIO);
/* 59 */       configuration.setLargeMessagesDirectory(dataDir + "/largemessages");
/* 60 */       configuration.setBindingsDirectory(dataDir + "/bindings");
/* 61 */       configuration.setPagingDirectory(dataDir + "/paging");
/*    */     } 
/*    */     
/* 64 */     TransportConfiguration transportConfiguration = new TransportConfiguration(InVMAcceptorFactory.class.getName(), this.properties.generateTransportParameters());
/* 65 */     configuration.getAcceptorConfigurations().add(transportConfiguration);
/* 66 */     if (this.properties.isDefaultClusterPassword() && logger.isDebugEnabled()) {
/* 67 */       logger.debug("Using default Artemis cluster password: " + this.properties.getClusterPassword());
/*    */     }
/* 69 */     configuration.setClusterPassword(this.properties.getClusterPassword());
/* 70 */     configuration.addAddressConfiguration(createAddressConfiguration("DLQ"));
/* 71 */     configuration.addAddressConfiguration(createAddressConfiguration("ExpiryQueue"));
/* 72 */     configuration.addAddressesSetting("#", (new AddressSettings())
/* 73 */         .setDeadLetterAddress(SimpleString.toSimpleString("DLQ"))
/* 74 */         .setExpiryAddress(SimpleString.toSimpleString("ExpiryQueue")));
/* 75 */     return (Configuration)configuration;
/*    */   }
/*    */   
/*    */   private CoreAddressConfiguration createAddressConfiguration(String name) {
/* 79 */     return (new CoreAddressConfiguration()).setName(name).addRoutingType(RoutingType.ANYCAST).addQueueConfiguration((new CoreQueueConfiguration())
/* 80 */         .setName(name).setRoutingType(RoutingType.ANYCAST).setAddress(name));
/*    */   }
/*    */   
/*    */   private String getDataDir() {
/* 84 */     if (this.properties.getDataDirectory() != null) {
/* 85 */       return this.properties.getDataDirectory();
/*    */     }
/* 87 */     String tempDirectory = System.getProperty("java.io.tmpdir");
/* 88 */     return (new File(tempDirectory, "artemis-data")).getAbsolutePath();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisEmbeddedConfigurationFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
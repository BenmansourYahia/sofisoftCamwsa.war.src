/*     */ package org.springframework.boot.autoconfigure.jms.artemis;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.activemq.artemis.api.core.RoutingType;
/*     */ import org.apache.activemq.artemis.core.config.Configuration;
/*     */ import org.apache.activemq.artemis.core.config.CoreAddressConfiguration;
/*     */ import org.apache.activemq.artemis.core.config.CoreQueueConfiguration;
/*     */ import org.apache.activemq.artemis.core.server.embedded.EmbeddedActiveMQ;
/*     */ import org.apache.activemq.artemis.jms.server.config.JMSConfiguration;
/*     */ import org.apache.activemq.artemis.jms.server.config.JMSQueueConfiguration;
/*     */ import org.apache.activemq.artemis.jms.server.config.TopicConfiguration;
/*     */ import org.apache.activemq.artemis.jms.server.config.impl.JMSConfigurationImpl;
/*     */ import org.apache.activemq.artemis.jms.server.config.impl.JMSQueueConfigurationImpl;
/*     */ import org.apache.activemq.artemis.jms.server.config.impl.TopicConfigurationImpl;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({EmbeddedActiveMQ.class})
/*     */ @ConditionalOnProperty(prefix = "spring.artemis.embedded", name = {"enabled"}, havingValue = "true", matchIfMissing = true)
/*     */ class ArtemisEmbeddedServerConfiguration
/*     */ {
/*     */   private final ArtemisProperties properties;
/*     */   
/*     */   ArtemisEmbeddedServerConfiguration(ArtemisProperties properties) {
/*  56 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   Configuration artemisConfiguration() {
/*  62 */     return (new ArtemisEmbeddedConfigurationFactory(this.properties)).createConfiguration();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean(initMethod = "start", destroyMethod = "stop")
/*     */   @ConditionalOnMissingBean
/*     */   EmbeddedActiveMQ embeddedActiveMq(Configuration configuration, JMSConfiguration jmsConfiguration, ObjectProvider<ArtemisConfigurationCustomizer> configurationCustomizers) throws Exception {
/*  70 */     for (JMSQueueConfiguration queueConfiguration : jmsConfiguration.getQueueConfigurations()) {
/*  71 */       String queueName = queueConfiguration.getName();
/*  72 */       configuration.addAddressConfiguration((new CoreAddressConfiguration())
/*  73 */           .setName(queueName).addRoutingType(RoutingType.ANYCAST)
/*  74 */           .addQueueConfiguration((new CoreQueueConfiguration()).setAddress(queueName).setName(queueName)
/*  75 */             .setFilterString(queueConfiguration.getSelector())
/*  76 */             .setDurable(queueConfiguration.isDurable()).setRoutingType(RoutingType.ANYCAST)));
/*     */     } 
/*  78 */     for (TopicConfiguration topicConfiguration : jmsConfiguration.getTopicConfigurations()) {
/*  79 */       configuration.addAddressConfiguration((new CoreAddressConfiguration()).setName(topicConfiguration.getName())
/*  80 */           .addRoutingType(RoutingType.MULTICAST));
/*     */     }
/*  82 */     configurationCustomizers.orderedStream().forEach(customizer -> customizer.customize(configuration));
/*  83 */     EmbeddedActiveMQ embeddedActiveMq = new EmbeddedActiveMQ();
/*  84 */     embeddedActiveMq.setConfiguration(configuration);
/*  85 */     return embeddedActiveMq;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   JMSConfiguration artemisJmsConfiguration(ObjectProvider<JMSQueueConfiguration> queuesConfiguration, ObjectProvider<TopicConfiguration> topicsConfiguration) {
/*  92 */     JMSConfigurationImpl jMSConfigurationImpl = new JMSConfigurationImpl();
/*  93 */     addAll(jMSConfigurationImpl.getQueueConfigurations(), queuesConfiguration);
/*  94 */     addAll(jMSConfigurationImpl.getTopicConfigurations(), topicsConfiguration);
/*  95 */     addQueues((JMSConfiguration)jMSConfigurationImpl, this.properties.getEmbedded().getQueues());
/*  96 */     addTopics((JMSConfiguration)jMSConfigurationImpl, this.properties.getEmbedded().getTopics());
/*  97 */     return (JMSConfiguration)jMSConfigurationImpl;
/*     */   }
/*     */   
/*     */   private <T> void addAll(List<T> list, ObjectProvider<T> items) {
/* 101 */     if (items != null) {
/* 102 */       list.addAll((Collection<? extends T>)items.orderedStream().collect(Collectors.toList()));
/*     */     }
/*     */   }
/*     */   
/*     */   private void addQueues(JMSConfiguration configuration, String[] queues) {
/* 107 */     boolean persistent = this.properties.getEmbedded().isPersistent();
/* 108 */     for (String queue : queues) {
/* 109 */       JMSQueueConfigurationImpl jmsQueueConfiguration = new JMSQueueConfigurationImpl();
/* 110 */       jmsQueueConfiguration.setName(queue);
/* 111 */       jmsQueueConfiguration.setDurable(persistent);
/* 112 */       jmsQueueConfiguration.setBindings(new String[] { "/queue/" + queue });
/* 113 */       configuration.getQueueConfigurations().add(jmsQueueConfiguration);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addTopics(JMSConfiguration configuration, String[] topics) {
/* 118 */     for (String topic : topics) {
/* 119 */       TopicConfigurationImpl topicConfiguration = new TopicConfigurationImpl();
/* 120 */       topicConfiguration.setName(topic);
/* 121 */       topicConfiguration.setBindings(new String[] { "/topic/" + topic });
/* 122 */       configuration.getTopicConfigurations().add(topicConfiguration);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisEmbeddedServerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
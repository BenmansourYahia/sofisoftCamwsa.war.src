/*    */ package org.springframework.boot.autoconfigure.jms;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import org.messaginghub.pooled.jms.JmsPoolConnectionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JmsPoolConnectionFactoryFactory
/*    */ {
/*    */   private final JmsPoolConnectionFactoryProperties properties;
/*    */   
/*    */   public JmsPoolConnectionFactoryFactory(JmsPoolConnectionFactoryProperties properties) {
/* 35 */     this.properties = properties;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JmsPoolConnectionFactory createPooledConnectionFactory(ConnectionFactory connectionFactory) {
/* 45 */     JmsPoolConnectionFactory pooledConnectionFactory = new JmsPoolConnectionFactory();
/* 46 */     pooledConnectionFactory.setConnectionFactory(connectionFactory);
/*    */     
/* 48 */     pooledConnectionFactory.setBlockIfSessionPoolIsFull(this.properties.isBlockIfFull());
/* 49 */     if (this.properties.getBlockIfFullTimeout() != null) {
/* 50 */       pooledConnectionFactory
/* 51 */         .setBlockIfSessionPoolIsFullTimeout(this.properties.getBlockIfFullTimeout().toMillis());
/*    */     }
/* 53 */     if (this.properties.getIdleTimeout() != null) {
/* 54 */       pooledConnectionFactory.setConnectionIdleTimeout((int)this.properties.getIdleTimeout().toMillis());
/*    */     }
/* 56 */     pooledConnectionFactory.setMaxConnections(this.properties.getMaxConnections());
/* 57 */     pooledConnectionFactory.setMaxSessionsPerConnection(this.properties.getMaxSessionsPerConnection());
/* 58 */     if (this.properties.getTimeBetweenExpirationCheck() != null) {
/* 59 */       pooledConnectionFactory
/* 60 */         .setConnectionCheckInterval(this.properties.getTimeBetweenExpirationCheck().toMillis());
/*    */     }
/* 62 */     pooledConnectionFactory.setUseAnonymousProducers(this.properties.isUseAnonymousProducers());
/* 63 */     return pooledConnectionFactory;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\JmsPoolConnectionFactoryFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
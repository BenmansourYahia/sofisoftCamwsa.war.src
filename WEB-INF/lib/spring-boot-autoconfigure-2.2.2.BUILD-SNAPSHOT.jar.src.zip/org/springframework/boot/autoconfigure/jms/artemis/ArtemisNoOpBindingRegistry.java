/*    */ package org.springframework.boot.autoconfigure.jms.artemis;
/*    */ 
/*    */ import org.apache.activemq.artemis.spi.core.naming.BindingRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArtemisNoOpBindingRegistry
/*    */   implements BindingRegistry
/*    */ {
/*    */   public Object lookup(String s) {
/* 32 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean bind(String s, Object o) {
/* 37 */     return false;
/*    */   }
/*    */   
/*    */   public void unbind(String s) {}
/*    */   
/*    */   public void close() {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisNoOpBindingRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.jms.activemq;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.XAConnectionFactory;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.apache.activemq.ActiveMQConnectionFactory;
/*    */ import org.apache.activemq.ActiveMQXAConnectionFactory;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.jms.XAConnectionFactoryWrapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Primary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({TransactionManager.class})
/*    */ @ConditionalOnBean({XAConnectionFactoryWrapper.class})
/*    */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*    */ class ActiveMQXAConnectionFactoryConfiguration
/*    */ {
/*    */   @Primary
/*    */   @Bean(name = {"jmsConnectionFactory", "xaJmsConnectionFactory"})
/*    */   ConnectionFactory jmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers, XAConnectionFactoryWrapper wrapper) throws Exception {
/* 56 */     ActiveMQXAConnectionFactory connectionFactory = (new ActiveMQConnectionFactoryFactory(properties, (List<ActiveMQConnectionFactoryCustomizer>)factoryCustomizers.orderedStream().collect(Collectors.toList()))).<ActiveMQXAConnectionFactory>createConnectionFactory(ActiveMQXAConnectionFactory.class);
/* 57 */     return wrapper.wrapConnectionFactory((XAConnectionFactory)connectionFactory);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnProperty(prefix = "spring.activemq.pool", name = {"enabled"}, havingValue = "false", matchIfMissing = true)
/*    */   ActiveMQConnectionFactory nonXaJmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers) {
/* 65 */     return (new ActiveMQConnectionFactoryFactory(properties, (List<ActiveMQConnectionFactoryCustomizer>)factoryCustomizers
/* 66 */         .orderedStream().collect(Collectors.toList())))
/* 67 */       .createConnectionFactory(ActiveMQConnectionFactory.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQXAConnectionFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
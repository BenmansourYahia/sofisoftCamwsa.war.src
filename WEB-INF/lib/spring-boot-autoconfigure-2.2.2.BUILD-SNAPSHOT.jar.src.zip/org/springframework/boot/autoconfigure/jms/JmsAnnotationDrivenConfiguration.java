/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import javax.jms.ConnectionFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnJndi;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.jms.annotation.EnableJms;
/*     */ import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
/*     */ import org.springframework.jms.support.converter.MessageConverter;
/*     */ import org.springframework.jms.support.destination.DestinationResolver;
/*     */ import org.springframework.jms.support.destination.JndiDestinationResolver;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({EnableJms.class})
/*     */ class JmsAnnotationDrivenConfiguration
/*     */ {
/*     */   private final ObjectProvider<DestinationResolver> destinationResolver;
/*     */   private final ObjectProvider<JtaTransactionManager> transactionManager;
/*     */   private final ObjectProvider<MessageConverter> messageConverter;
/*     */   private final JmsProperties properties;
/*     */   
/*     */   JmsAnnotationDrivenConfiguration(ObjectProvider<DestinationResolver> destinationResolver, ObjectProvider<JtaTransactionManager> transactionManager, ObjectProvider<MessageConverter> messageConverter, JmsProperties properties) {
/*  57 */     this.destinationResolver = destinationResolver;
/*  58 */     this.transactionManager = transactionManager;
/*  59 */     this.messageConverter = messageConverter;
/*  60 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   DefaultJmsListenerContainerFactoryConfigurer jmsListenerContainerFactoryConfigurer() {
/*  66 */     DefaultJmsListenerContainerFactoryConfigurer configurer = new DefaultJmsListenerContainerFactoryConfigurer();
/*  67 */     configurer.setDestinationResolver((DestinationResolver)this.destinationResolver.getIfUnique());
/*  68 */     configurer.setTransactionManager((JtaTransactionManager)this.transactionManager.getIfUnique());
/*  69 */     configurer.setMessageConverter((MessageConverter)this.messageConverter.getIfUnique());
/*  70 */     configurer.setJmsProperties(this.properties);
/*  71 */     return configurer;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*     */   @ConditionalOnMissingBean(name = {"jmsListenerContainerFactory"})
/*     */   DefaultJmsListenerContainerFactory jmsListenerContainerFactory(DefaultJmsListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory) {
/*  79 */     DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
/*  80 */     configurer.configure(factory, connectionFactory);
/*  81 */     return factory;
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @EnableJms
/*     */   @ConditionalOnMissingBean(name = {"org.springframework.jms.config.internalJmsListenerAnnotationProcessor"})
/*     */   static class EnableJmsConfiguration {}
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnJndi
/*     */   static class JndiConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({DestinationResolver.class})
/*     */     JndiDestinationResolver destinationResolver() {
/*  98 */       JndiDestinationResolver resolver = new JndiDestinationResolver();
/*  99 */       resolver.setFallbackToDynamicDestination(true);
/* 100 */       return resolver;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jms\JmsAnnotationDrivenConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
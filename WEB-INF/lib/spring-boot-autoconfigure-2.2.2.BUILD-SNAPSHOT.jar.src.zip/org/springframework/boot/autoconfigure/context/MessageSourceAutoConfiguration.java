/*     */ package org.springframework.boot.autoconfigure.context;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.support.ResourceBundleMessageSource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnMissingBean(name = {"messageSource"}, search = SearchStrategy.CURRENT)
/*     */ @AutoConfigureOrder(-2147483648)
/*     */ @Conditional({MessageSourceAutoConfiguration.ResourceBundleCondition.class})
/*     */ @EnableConfigurationProperties
/*     */ public class MessageSourceAutoConfiguration
/*     */ {
/*  60 */   private static final Resource[] NO_RESOURCES = new Resource[0];
/*     */   
/*     */   @Bean
/*     */   @ConfigurationProperties(prefix = "spring.messages")
/*     */   public MessageSourceProperties messageSourceProperties() {
/*  65 */     return new MessageSourceProperties();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public MessageSource messageSource(MessageSourceProperties properties) {
/*  70 */     ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
/*  71 */     if (StringUtils.hasText(properties.getBasename())) {
/*  72 */       messageSource.setBasenames(
/*  73 */           StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(properties.getBasename())));
/*     */     }
/*  75 */     if (properties.getEncoding() != null) {
/*  76 */       messageSource.setDefaultEncoding(properties.getEncoding().name());
/*     */     }
/*  78 */     messageSource.setFallbackToSystemLocale(properties.isFallbackToSystemLocale());
/*  79 */     Duration cacheDuration = properties.getCacheDuration();
/*  80 */     if (cacheDuration != null) {
/*  81 */       messageSource.setCacheMillis(cacheDuration.toMillis());
/*     */     }
/*  83 */     messageSource.setAlwaysUseMessageFormat(properties.isAlwaysUseMessageFormat());
/*  84 */     messageSource.setUseCodeAsDefaultMessage(properties.isUseCodeAsDefaultMessage());
/*  85 */     return (MessageSource)messageSource;
/*     */   }
/*     */   
/*     */   protected static class ResourceBundleCondition
/*     */     extends SpringBootCondition {
/*  90 */     private static ConcurrentReferenceHashMap<String, ConditionOutcome> cache = new ConcurrentReferenceHashMap();
/*     */ 
/*     */     
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  94 */       String basename = context.getEnvironment().getProperty("spring.messages.basename", "messages");
/*  95 */       ConditionOutcome outcome = (ConditionOutcome)cache.get(basename);
/*  96 */       if (outcome == null) {
/*  97 */         outcome = getMatchOutcomeForBasename(context, basename);
/*  98 */         cache.put(basename, outcome);
/*     */       } 
/* 100 */       return outcome;
/*     */     }
/*     */     
/*     */     private ConditionOutcome getMatchOutcomeForBasename(ConditionContext context, String basename) {
/* 104 */       ConditionMessage.Builder message = ConditionMessage.forCondition("ResourceBundle", new Object[0]);
/* 105 */       for (String name : StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(basename))) {
/* 106 */         for (Resource resource : getResources(context.getClassLoader(), name)) {
/* 107 */           if (resource.exists()) {
/* 108 */             return ConditionOutcome.match(message.found("bundle").items(new Object[] { resource }));
/*     */           }
/*     */         } 
/*     */       } 
/* 112 */       return ConditionOutcome.noMatch(message.didNotFind("bundle with basename " + basename).atAll());
/*     */     }
/*     */     
/*     */     private Resource[] getResources(ClassLoader classLoader, String name) {
/* 116 */       String target = name.replace('.', '/');
/*     */       try {
/* 118 */         return (new PathMatchingResourcePatternResolver(classLoader))
/* 119 */           .getResources("classpath*:" + target + ".properties");
/*     */       }
/* 121 */       catch (Exception ex) {
/* 122 */         return MessageSourceAutoConfiguration.NO_RESOURCES;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\context\MessageSourceAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.integration;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.integration.annotation.IntegrationComponentScan;
/*    */ import org.springframework.integration.config.IntegrationComponentScanRegistrar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IntegrationAutoConfigurationScanRegistrar
/*    */   extends IntegrationComponentScanRegistrar
/*    */   implements BeanFactoryAware
/*    */ {
/*    */   private BeanFactory beanFactory;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 44 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 50 */     super.registerBeanDefinitions(AnnotationMetadata.introspect(IntegrationComponentScanConfiguration.class), registry);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Collection<String> getBasePackages(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 57 */     return AutoConfigurationPackages.has(this.beanFactory) ? AutoConfigurationPackages.get(this.beanFactory) : 
/* 58 */       Collections.<String>emptyList();
/*    */   }
/*    */   
/*    */   @IntegrationComponentScan
/*    */   private static class IntegrationComponentScanConfiguration {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\integration\IntegrationAutoConfigurationScanRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
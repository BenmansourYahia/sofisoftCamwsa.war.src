/*    */ package org.springframework.boot.autoconfigure.integration;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.integration")
/*    */ public class IntegrationProperties
/*    */ {
/* 32 */   private final Jdbc jdbc = new Jdbc();
/*    */   
/*    */   public Jdbc getJdbc() {
/* 35 */     return this.jdbc;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Jdbc
/*    */   {
/*    */     private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/integration/jdbc/schema-@@platform@@.sql";
/*    */ 
/*    */     
/* 46 */     private String schema = "classpath:org/springframework/integration/jdbc/schema-@@platform@@.sql";
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 51 */     private DataSourceInitializationMode initializeSchema = DataSourceInitializationMode.EMBEDDED;
/*    */     
/*    */     public String getSchema() {
/* 54 */       return this.schema;
/*    */     }
/*    */     
/*    */     public void setSchema(String schema) {
/* 58 */       this.schema = schema;
/*    */     }
/*    */     
/*    */     public DataSourceInitializationMode getInitializeSchema() {
/* 62 */       return this.initializeSchema;
/*    */     }
/*    */     
/*    */     public void setInitializeSchema(DataSourceInitializationMode initializeSchema) {
/* 66 */       this.initializeSchema = initializeSchema;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\integration\IntegrationProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
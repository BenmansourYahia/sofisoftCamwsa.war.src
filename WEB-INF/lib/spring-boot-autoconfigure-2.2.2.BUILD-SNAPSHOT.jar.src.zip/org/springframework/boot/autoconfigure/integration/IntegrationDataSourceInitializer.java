/*    */ package org.springframework.boot.autoconfigure.integration;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.jdbc.AbstractDataSourceInitializer;
/*    */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegrationDataSourceInitializer
/*    */   extends AbstractDataSourceInitializer
/*    */ {
/*    */   private final IntegrationProperties.Jdbc properties;
/*    */   
/*    */   public IntegrationDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader, IntegrationProperties properties) {
/* 38 */     super(dataSource, resourceLoader);
/* 39 */     Assert.notNull(properties, "IntegrationProperties must not be null");
/* 40 */     this.properties = properties.getJdbc();
/*    */   }
/*    */ 
/*    */   
/*    */   protected DataSourceInitializationMode getMode() {
/* 45 */     return this.properties.getInitializeSchema();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getSchemaLocation() {
/* 50 */     return this.properties.getSchema();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\integration\IntegrationDataSourceInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
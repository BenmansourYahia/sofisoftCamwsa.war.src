/*     */ package org.springframework.boot.autoconfigure.integration;
/*     */ 
/*     */ import javax.management.MBeanServer;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.integration.config.EnableIntegration;
/*     */ import org.springframework.integration.config.EnableIntegrationManagement;
/*     */ import org.springframework.integration.config.IntegrationManagementConfigurer;
/*     */ import org.springframework.integration.gateway.GatewayProxyFactoryBean;
/*     */ import org.springframework.integration.jdbc.store.JdbcMessageStore;
/*     */ import org.springframework.integration.jmx.config.EnableIntegrationMBeanExport;
/*     */ import org.springframework.integration.monitor.IntegrationMBeanExporter;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({EnableIntegration.class})
/*     */ @EnableConfigurationProperties({IntegrationProperties.class})
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, JmxAutoConfiguration.class})
/*     */ public class IntegrationAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @EnableIntegration
/*     */   protected static class IntegrationConfiguration {}
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({EnableIntegrationMBeanExport.class})
/*     */   @ConditionalOnMissingBean(value = {IntegrationMBeanExporter.class}, search = SearchStrategy.CURRENT)
/*     */   @ConditionalOnBean({MBeanServer.class})
/*     */   @ConditionalOnProperty(prefix = "spring.jmx", name = {"enabled"}, havingValue = "true", matchIfMissing = true)
/*     */   protected static class IntegrationJmxConfiguration
/*     */   {
/*     */     @Bean
/*     */     public IntegrationMBeanExporter integrationMbeanExporter(BeanFactory beanFactory, Environment environment) {
/*  85 */       IntegrationMBeanExporter exporter = new IntegrationMBeanExporter();
/*  86 */       String defaultDomain = environment.getProperty("spring.jmx.default-domain");
/*  87 */       if (StringUtils.hasLength(defaultDomain)) {
/*  88 */         exporter.setDefaultDomain(defaultDomain);
/*     */       }
/*  90 */       String serverBean = environment.getProperty("spring.jmx.server", "mbeanServer");
/*  91 */       exporter.setServer((MBeanServer)beanFactory.getBean(serverBean, MBeanServer.class));
/*  92 */       return exporter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({EnableIntegrationManagement.class})
/*     */   @ConditionalOnMissingBean(value = {IntegrationManagementConfigurer.class}, name = {"integrationManagementConfigurer"}, search = SearchStrategy.CURRENT)
/*     */   protected static class IntegrationManagementConfiguration
/*     */   {
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     @EnableIntegrationManagement(defaultCountsEnabled = "true")
/*     */     protected static class EnableIntegrationManagementConfiguration {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({GatewayProxyFactoryBean.class})
/*     */   @Import({IntegrationAutoConfigurationScanRegistrar.class})
/*     */   protected static class IntegrationComponentScanConfiguration {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({JdbcMessageStore.class})
/*     */   @ConditionalOnSingleCandidate(DataSource.class)
/*     */   protected static class IntegrationJdbcConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public IntegrationDataSourceInitializer integrationDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader, IntegrationProperties properties) {
/* 136 */       return new IntegrationDataSourceInitializer(dataSource, resourceLoader, properties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\integration\IntegrationAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
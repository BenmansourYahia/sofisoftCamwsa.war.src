/*    */ package org.springframework.boot.autoconfigure.admin;
/*    */ 
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.admin.SpringApplicationAdminMXBeanRegistrar;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.jmx.export.MBeanExporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @AutoConfigureAfter({JmxAutoConfiguration.class})
/*    */ @ConditionalOnProperty(prefix = "spring.application.admin", value = {"enabled"}, havingValue = "true", matchIfMissing = false)
/*    */ public class SpringApplicationAdminJmxAutoConfiguration
/*    */ {
/*    */   private static final String JMX_NAME_PROPERTY = "spring.application.admin.jmx-name";
/*    */   private static final String DEFAULT_JMX_NAME = "org.springframework.boot:type=Admin,name=SpringApplication";
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SpringApplicationAdminMXBeanRegistrar springApplicationAdminRegistrar(ObjectProvider<MBeanExporter> mbeanExporters, Environment environment) throws MalformedObjectNameException {
/* 63 */     String jmxName = environment.getProperty("spring.application.admin.jmx-name", "org.springframework.boot:type=Admin,name=SpringApplication");
/* 64 */     if (mbeanExporters != null) {
/* 65 */       for (MBeanExporter mbeanExporter : mbeanExporters) {
/* 66 */         mbeanExporter.addExcludedBean(jmxName);
/*    */       }
/*    */     }
/* 69 */     return new SpringApplicationAdminMXBeanRegistrar(jmxName);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\admin\SpringApplicationAdminJmxAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
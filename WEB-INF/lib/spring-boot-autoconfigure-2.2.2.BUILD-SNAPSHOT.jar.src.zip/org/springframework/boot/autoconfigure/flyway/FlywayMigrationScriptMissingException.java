/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlywayMigrationScriptMissingException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final List<String> locations;
/*    */   
/*    */   FlywayMigrationScriptMissingException(List<String> locations) {
/* 34 */     super(locations.isEmpty() ? "Migration script locations not configured" : ("Cannot find migration scripts in: " + locations + " (please add migration scripts or check your Flyway configuration)"));
/*    */     
/* 36 */     this.locations = new ArrayList<>(locations);
/*    */   }
/*    */   
/*    */   public List<String> getLocations() {
/* 40 */     return this.locations;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\flyway\FlywayMigrationScriptMissingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
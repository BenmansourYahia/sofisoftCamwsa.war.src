/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import java.util.stream.StreamSupport;
/*    */ import javax.sql.DataSource;
/*    */ import org.flywaydb.core.Flyway;
/*    */ import org.springframework.boot.jdbc.SchemaManagement;
/*    */ import org.springframework.boot.jdbc.SchemaManagementProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FlywaySchemaManagementProvider
/*    */   implements SchemaManagementProvider
/*    */ {
/*    */   private final Iterable<Flyway> flywayInstances;
/*    */   
/*    */   FlywaySchemaManagementProvider(Iterable<Flyway> flywayInstances) {
/* 39 */     this.flywayInstances = flywayInstances;
/*    */   }
/*    */ 
/*    */   
/*    */   public SchemaManagement getSchemaManagement(DataSource dataSource) {
/* 44 */     return StreamSupport.stream(this.flywayInstances.spliterator(), false)
/* 45 */       .map(flyway -> flyway.getConfiguration().getDataSource()).filter(dataSource::equals).findFirst()
/* 46 */       .map(managedDataSource -> SchemaManagement.MANAGED).orElse(SchemaManagement.UNMANAGED);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\flyway\FlywaySchemaManagementProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FlywayMigrationScriptMissingFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<FlywayMigrationScriptMissingException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, FlywayMigrationScriptMissingException cause) {
/* 34 */     StringBuilder description = new StringBuilder("Flyway failed to initialize: ");
/* 35 */     if (cause.getLocations().isEmpty()) {
/* 36 */       return new FailureAnalysis(description.append("no migration scripts location is configured").toString(), "Check your Flyway configuration", cause);
/*    */     }
/*    */     
/* 39 */     description.append(String.format("none of the following migration scripts locations could be found:%n%n", new Object[0]));
/* 40 */     cause.getLocations().forEach(location -> description.append(String.format("\t- %s%n", new Object[] { location })));
/* 41 */     return new FailureAnalysis(description.toString(), "Review the locations above or check your Flyway configuration", cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\flyway\FlywayMigrationScriptMissingFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
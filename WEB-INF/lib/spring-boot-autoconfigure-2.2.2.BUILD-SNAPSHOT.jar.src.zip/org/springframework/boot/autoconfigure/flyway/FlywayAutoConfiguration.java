/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.sql.DataSource;
/*     */ import org.flywaydb.core.Flyway;
/*     */ import org.flywaydb.core.api.MigrationVersion;
/*     */ import org.flywaydb.core.api.callback.Callback;
/*     */ import org.flywaydb.core.api.configuration.FluentConfiguration;
/*     */ import org.flywaydb.core.api.migration.JavaMigration;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.data.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
/*     */ import org.springframework.boot.autoconfigure.jdbc.JdbcOperationsDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.NamedParameterJdbcOperationsDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.jdbc.core.JdbcOperations;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.MetaDataAccessException;
/*     */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({Flyway.class})
/*     */ @Conditional({FlywayAutoConfiguration.FlywayDataSourceCondition.class})
/*     */ @ConditionalOnProperty(prefix = "spring.flyway", name = {"enabled"}, matchIfMissing = true)
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, JdbcTemplateAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*     */ @Import({FlywayAutoConfiguration.FlywayEntityManagerFactoryDependsOnPostProcessor.class, FlywayAutoConfiguration.FlywayJdbcOperationsDependsOnPostProcessor.class, FlywayAutoConfiguration.FlywayNamedParameterJdbcOperationsDependencyConfiguration.class})
/*     */ public class FlywayAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConfigurationPropertiesBinding
/*     */   public StringOrNumberToMigrationVersionConverter stringOrNumberMigrationVersionConverter() {
/* 104 */     return new StringOrNumberToMigrationVersionConverter();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public FlywaySchemaManagementProvider flywayDefaultDdlModeProvider(ObjectProvider<Flyway> flyways) {
/* 109 */     return new FlywaySchemaManagementProvider((Iterable<Flyway>)flyways);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({Flyway.class})
/*     */   @EnableConfigurationProperties({DataSourceProperties.class, FlywayProperties.class})
/*     */   @Import({FlywayMigrationInitializerEntityManagerFactoryDependsOnPostProcessor.class, FlywayMigrationInitializerJdbcOperationsDependsOnPostProcessor.class, FlywayMigrationInitializerNamedParameterJdbcOperationsDependsOnPostProcessor.class})
/*     */   public static class FlywayConfiguration
/*     */   {
/*     */     @Bean
/*     */     public Flyway flyway(FlywayProperties properties, DataSourceProperties dataSourceProperties, ResourceLoader resourceLoader, ObjectProvider<DataSource> dataSource, @FlywayDataSource ObjectProvider<DataSource> flywayDataSource, ObjectProvider<FlywayConfigurationCustomizer> fluentConfigurationCustomizers, ObjectProvider<JavaMigration> javaMigrations, ObjectProvider<Callback> callbacks) {
/* 126 */       FluentConfiguration configuration = new FluentConfiguration(resourceLoader.getClassLoader());
/* 127 */       DataSource dataSourceToMigrate = configureDataSource(configuration, properties, dataSourceProperties, (DataSource)flywayDataSource
/* 128 */           .getIfAvailable(), (DataSource)dataSource.getIfAvailable());
/* 129 */       checkLocationExists(dataSourceToMigrate, properties, resourceLoader);
/* 130 */       configureProperties(configuration, properties);
/* 131 */       List<Callback> orderedCallbacks = (List<Callback>)callbacks.orderedStream().collect(Collectors.toList());
/* 132 */       configureCallbacks(configuration, orderedCallbacks);
/* 133 */       fluentConfigurationCustomizers.orderedStream().forEach(customizer -> customizer.customize(configuration));
/* 134 */       configureFlywayCallbacks(configuration, orderedCallbacks);
/* 135 */       List<JavaMigration> migrations = (List<JavaMigration>)javaMigrations.stream().collect(Collectors.toList());
/* 136 */       configureJavaMigrations(configuration, migrations);
/* 137 */       return configuration.load();
/*     */     }
/*     */ 
/*     */     
/*     */     private DataSource configureDataSource(FluentConfiguration configuration, FlywayProperties properties, DataSourceProperties dataSourceProperties, DataSource flywayDataSource, DataSource dataSource) {
/* 142 */       if (properties.isCreateDataSource()) {
/* 143 */         String url = getProperty(properties::getUrl, dataSourceProperties::determineUrl);
/* 144 */         String user = getProperty(properties::getUser, dataSourceProperties::determineUsername);
/* 145 */         String password = getProperty(properties::getPassword, dataSourceProperties::determinePassword);
/* 146 */         configuration.dataSource(url, user, password);
/* 147 */         if (!CollectionUtils.isEmpty(properties.getInitSqls())) {
/* 148 */           String initSql = StringUtils.collectionToDelimitedString(properties.getInitSqls(), "\n");
/* 149 */           configuration.initSql(initSql);
/*     */         }
/*     */       
/* 152 */       } else if (flywayDataSource != null) {
/* 153 */         configuration.dataSource(flywayDataSource);
/*     */       } else {
/*     */         
/* 156 */         configuration.dataSource(dataSource);
/*     */       } 
/* 158 */       return configuration.getDataSource();
/*     */     }
/*     */ 
/*     */     
/*     */     private void checkLocationExists(DataSource dataSource, FlywayProperties properties, ResourceLoader resourceLoader) {
/* 163 */       if (properties.isCheckLocation()) {
/* 164 */         List<String> locations = (new FlywayAutoConfiguration.LocationResolver(dataSource)).resolveLocations(properties.getLocations());
/* 165 */         if (!hasAtLeastOneLocation(resourceLoader, locations)) {
/* 166 */           throw new FlywayMigrationScriptMissingException(locations);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private void configureProperties(FluentConfiguration configuration, FlywayProperties properties) {
/* 172 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*     */       
/* 174 */       String[] locations = (new FlywayAutoConfiguration.LocationResolver(configuration.getDataSource())).resolveLocations(properties.getLocations()).<String>toArray(new String[0]);
/* 175 */       map.from(locations).to(configuration::locations);
/* 176 */       map.from(properties.getEncoding()).to(configuration::encoding);
/* 177 */       map.from(Integer.valueOf(properties.getConnectRetries())).to(configuration::connectRetries);
/* 178 */       map.from(properties.getSchemas()).as(StringUtils::toStringArray).to(configuration::schemas);
/* 179 */       map.from(properties.getTable()).to(configuration::table);
/*     */       
/* 181 */       map.from(properties.getTablespace()).whenNonNull().to(tablespace -> configuration.tablespace(tablespace));
/* 182 */       map.from(properties.getBaselineDescription()).to(configuration::baselineDescription);
/* 183 */       map.from(properties.getBaselineVersion()).to(configuration::baselineVersion);
/* 184 */       map.from(properties.getInstalledBy()).to(configuration::installedBy);
/* 185 */       map.from(properties.getPlaceholders()).to(configuration::placeholders);
/* 186 */       map.from(properties.getPlaceholderPrefix()).to(configuration::placeholderPrefix);
/* 187 */       map.from(properties.getPlaceholderSuffix()).to(configuration::placeholderSuffix);
/* 188 */       map.from(Boolean.valueOf(properties.isPlaceholderReplacement())).to(configuration::placeholderReplacement);
/* 189 */       map.from(properties.getSqlMigrationPrefix()).to(configuration::sqlMigrationPrefix);
/* 190 */       map.from(properties.getSqlMigrationSuffixes()).as(StringUtils::toStringArray)
/* 191 */         .to(configuration::sqlMigrationSuffixes);
/* 192 */       map.from(properties.getSqlMigrationSeparator()).to(configuration::sqlMigrationSeparator);
/* 193 */       map.from(properties.getRepeatableSqlMigrationPrefix()).to(configuration::repeatableSqlMigrationPrefix);
/* 194 */       map.from(properties.getTarget()).to(configuration::target);
/* 195 */       map.from(Boolean.valueOf(properties.isBaselineOnMigrate())).to(configuration::baselineOnMigrate);
/* 196 */       map.from(Boolean.valueOf(properties.isCleanDisabled())).to(configuration::cleanDisabled);
/* 197 */       map.from(Boolean.valueOf(properties.isCleanOnValidationError())).to(configuration::cleanOnValidationError);
/* 198 */       map.from(Boolean.valueOf(properties.isGroup())).to(configuration::group);
/* 199 */       map.from(Boolean.valueOf(properties.isIgnoreMissingMigrations())).to(configuration::ignoreMissingMigrations);
/* 200 */       map.from(Boolean.valueOf(properties.isIgnoreIgnoredMigrations())).to(configuration::ignoreIgnoredMigrations);
/* 201 */       map.from(Boolean.valueOf(properties.isIgnorePendingMigrations())).to(configuration::ignorePendingMigrations);
/* 202 */       map.from(Boolean.valueOf(properties.isIgnoreFutureMigrations())).to(configuration::ignoreFutureMigrations);
/* 203 */       map.from(Boolean.valueOf(properties.isMixed())).to(configuration::mixed);
/* 204 */       map.from(Boolean.valueOf(properties.isOutOfOrder())).to(configuration::outOfOrder);
/* 205 */       map.from(Boolean.valueOf(properties.isSkipDefaultCallbacks())).to(configuration::skipDefaultCallbacks);
/* 206 */       map.from(Boolean.valueOf(properties.isSkipDefaultResolvers())).to(configuration::skipDefaultResolvers);
/* 207 */       map.from(Boolean.valueOf(properties.isValidateOnMigrate())).to(configuration::validateOnMigrate);
/*     */       
/* 209 */       map.from(properties.getBatch()).whenNonNull().to(configuration::batch);
/* 210 */       map.from(properties.getDryRunOutput()).whenNonNull().to(configuration::dryRunOutput);
/* 211 */       map.from(properties.getErrorOverrides()).whenNonNull().to(configuration::errorOverrides);
/* 212 */       map.from(properties.getLicenseKey()).whenNonNull().to(configuration::licenseKey);
/* 213 */       map.from(properties.getOracleSqlplus()).whenNonNull().to(configuration::oracleSqlplus);
/*     */       
/* 215 */       map.from(properties.getOracleSqlplusWarn()).whenNonNull()
/* 216 */         .to(oracleSqlplusWarn -> configuration.oracleSqlplusWarn(oracleSqlplusWarn.booleanValue()));
/* 217 */       map.from(properties.getStream()).whenNonNull().to(configuration::stream);
/* 218 */       map.from(properties.getUndoSqlMigrationPrefix()).whenNonNull().to(configuration::undoSqlMigrationPrefix);
/*     */     }
/*     */     
/*     */     private void configureCallbacks(FluentConfiguration configuration, List<Callback> callbacks) {
/* 222 */       if (!callbacks.isEmpty()) {
/* 223 */         configuration.callbacks(callbacks.<Callback>toArray(new Callback[0]));
/*     */       }
/*     */     }
/*     */     
/*     */     private void configureFlywayCallbacks(FluentConfiguration flyway, List<Callback> callbacks) {
/* 228 */       if (!callbacks.isEmpty()) {
/* 229 */         flyway.callbacks(callbacks.<Callback>toArray(new Callback[0]));
/*     */       }
/*     */     }
/*     */     
/*     */     private void configureJavaMigrations(FluentConfiguration flyway, List<JavaMigration> migrations) {
/* 234 */       if (!migrations.isEmpty()) {
/*     */         try {
/* 236 */           flyway.javaMigrations(migrations.<JavaMigration>toArray(new JavaMigration[0]));
/*     */         }
/* 238 */         catch (NoSuchMethodError noSuchMethodError) {}
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private String getProperty(Supplier<String> property, Supplier<String> defaultValue) {
/* 245 */       String value = property.get();
/* 246 */       return (value != null) ? value : defaultValue.get();
/*     */     }
/*     */     
/*     */     private boolean hasAtLeastOneLocation(ResourceLoader resourceLoader, Collection<String> locations) {
/* 250 */       for (String location : locations) {
/* 251 */         if (resourceLoader.getResource(normalizePrefix(location)).exists()) {
/* 252 */           return true;
/*     */         }
/*     */       } 
/* 255 */       return false;
/*     */     }
/*     */     
/*     */     private String normalizePrefix(String location) {
/* 259 */       return location.replace("filesystem:", "file:");
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public FlywayMigrationInitializer flywayInitializer(Flyway flyway, ObjectProvider<FlywayMigrationStrategy> migrationStrategy) {
/* 266 */       return new FlywayMigrationInitializer(flyway, (FlywayMigrationStrategy)migrationStrategy.getIfAvailable());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   static class FlywayMigrationInitializerEntityManagerFactoryDependsOnPostProcessor
/*     */     extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     FlywayMigrationInitializerEntityManagerFactoryDependsOnPostProcessor() {
/* 281 */       super(new Class[] { FlywayMigrationInitializer.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({JdbcOperations.class})
/*     */   @ConditionalOnBean({JdbcOperations.class})
/*     */   static class FlywayMigrationInitializerJdbcOperationsDependsOnPostProcessor
/*     */     extends JdbcOperationsDependsOnPostProcessor
/*     */   {
/*     */     FlywayMigrationInitializerJdbcOperationsDependsOnPostProcessor() {
/* 296 */       super(new Class[] { FlywayMigrationInitializer.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({NamedParameterJdbcOperations.class})
/*     */   @ConditionalOnBean({NamedParameterJdbcOperations.class})
/*     */   static class FlywayMigrationInitializerNamedParameterJdbcOperationsDependsOnPostProcessor
/*     */     extends NamedParameterJdbcOperationsDependsOnPostProcessor
/*     */   {
/*     */     FlywayMigrationInitializerNamedParameterJdbcOperationsDependsOnPostProcessor() {
/* 311 */       super(new Class[] { FlywayMigrationInitializer.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   static class FlywayEntityManagerFactoryDependsOnPostProcessor
/*     */     extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     FlywayEntityManagerFactoryDependsOnPostProcessor() {
/* 325 */       super(new Class[] { Flyway.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({JdbcOperations.class})
/*     */   @ConditionalOnBean({JdbcOperations.class})
/*     */   static class FlywayJdbcOperationsDependsOnPostProcessor
/*     */     extends JdbcOperationsDependsOnPostProcessor
/*     */   {
/*     */     FlywayJdbcOperationsDependsOnPostProcessor() {
/* 339 */       super(new Class[] { Flyway.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({NamedParameterJdbcOperations.class})
/*     */   @ConditionalOnBean({NamedParameterJdbcOperations.class})
/*     */   protected static class FlywayNamedParameterJdbcOperationsDependencyConfiguration
/*     */     extends NamedParameterJdbcOperationsDependsOnPostProcessor
/*     */   {
/*     */     public FlywayNamedParameterJdbcOperationsDependencyConfiguration() {
/* 354 */       super(new Class[] { Flyway.class });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LocationResolver
/*     */   {
/*     */     private static final String VENDOR_PLACEHOLDER = "{vendor}";
/*     */     
/*     */     private final DataSource dataSource;
/*     */     
/*     */     LocationResolver(DataSource dataSource) {
/* 366 */       this.dataSource = dataSource;
/*     */     }
/*     */     
/*     */     List<String> resolveLocations(List<String> locations) {
/* 370 */       if (usesVendorLocation(locations)) {
/* 371 */         DatabaseDriver databaseDriver = getDatabaseDriver();
/* 372 */         return replaceVendorLocations(locations, databaseDriver);
/*     */       } 
/* 374 */       return locations;
/*     */     }
/*     */     
/*     */     private List<String> replaceVendorLocations(List<String> locations, DatabaseDriver databaseDriver) {
/* 378 */       if (databaseDriver == DatabaseDriver.UNKNOWN) {
/* 379 */         return locations;
/*     */       }
/* 381 */       String vendor = databaseDriver.getId();
/* 382 */       return (List<String>)locations.stream().map(location -> location.replace("{vendor}", vendor))
/* 383 */         .collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private DatabaseDriver getDatabaseDriver() {
/*     */       try {
/* 388 */         String url = (String)JdbcUtils.extractDatabaseMetaData(this.dataSource, "getURL");
/* 389 */         return DatabaseDriver.fromJdbcUrl(url);
/*     */       }
/* 391 */       catch (MetaDataAccessException ex) {
/* 392 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean usesVendorLocation(Collection<String> locations) {
/* 398 */       for (String location : locations) {
/* 399 */         if (location.contains("{vendor}")) {
/* 400 */           return true;
/*     */         }
/*     */       } 
/* 403 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StringOrNumberToMigrationVersionConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private static final Set<GenericConverter.ConvertiblePair> CONVERTIBLE_TYPES;
/*     */     
/*     */     private StringOrNumberToMigrationVersionConverter() {}
/*     */     
/*     */     static {
/* 416 */       Set<GenericConverter.ConvertiblePair> types = new HashSet<>(2);
/* 417 */       types.add(new GenericConverter.ConvertiblePair(String.class, MigrationVersion.class));
/* 418 */       types.add(new GenericConverter.ConvertiblePair(Number.class, MigrationVersion.class));
/* 419 */       CONVERTIBLE_TYPES = Collections.unmodifiableSet(types);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 424 */       return CONVERTIBLE_TYPES;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 429 */       String value = ObjectUtils.nullSafeToString(source);
/* 430 */       return MigrationVersion.fromVersion(value);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class FlywayDataSourceCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     FlywayDataSourceCondition() {
/* 438 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */     
/*     */     @ConditionalOnBean({DataSource.class})
/*     */     private static final class DataSourceBeanCondition {}
/*     */     
/*     */     @ConditionalOnProperty(prefix = "spring.flyway", name = {"url"}, matchIfMissing = false)
/*     */     private static final class FlywayUrlCondition {}
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\flyway\FlywayAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
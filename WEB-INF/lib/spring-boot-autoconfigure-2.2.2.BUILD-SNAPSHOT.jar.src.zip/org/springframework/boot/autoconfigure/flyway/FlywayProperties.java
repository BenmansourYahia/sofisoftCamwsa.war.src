/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.flyway")
/*     */ public class FlywayProperties
/*     */ {
/*     */   private boolean enabled = true;
/*     */   private boolean checkLocation = true;
/*  55 */   private List<String> locations = new ArrayList<>(Collections.singletonList("classpath:db/migration"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private Charset encoding = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int connectRetries;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private List<String> schemas = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private String table = "flyway_schema_history";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String tablespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private String baselineDescription = "<< Flyway Baseline >>";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private String baselineVersion = "1";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String installedBy;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private Map<String, String> placeholders = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   private String placeholderPrefix = "${";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private String placeholderSuffix = "}";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean placeholderReplacement = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private String sqlMigrationPrefix = "V";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   private List<String> sqlMigrationSuffixes = new ArrayList<>(Collections.singleton(".sql"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   private String sqlMigrationSeparator = "__";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   private String repeatableSqlMigrationPrefix = "R";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String target;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String user;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private List<String> initSqls = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean baselineOnMigrate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean cleanDisabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean cleanOnValidationError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean group;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreMissingMigrations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreIgnoredMigrations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignorePendingMigrations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreFutureMigrations = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mixed;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean outOfOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean skipDefaultCallbacks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean skipDefaultResolvers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateOnMigrate = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean batch;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File dryRunOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] errorOverrides;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String licenseKey;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean oracleSqlplus;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean oracleSqlplusWarn;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean stream;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String undoSqlMigrationPrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 280 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 284 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public boolean isCheckLocation() {
/* 288 */     return this.checkLocation;
/*     */   }
/*     */   
/*     */   public void setCheckLocation(boolean checkLocation) {
/* 292 */     this.checkLocation = checkLocation;
/*     */   }
/*     */   
/*     */   public List<String> getLocations() {
/* 296 */     return this.locations;
/*     */   }
/*     */   
/*     */   public void setLocations(List<String> locations) {
/* 300 */     this.locations = locations;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/* 304 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/* 308 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public int getConnectRetries() {
/* 312 */     return this.connectRetries;
/*     */   }
/*     */   
/*     */   public void setConnectRetries(int connectRetries) {
/* 316 */     this.connectRetries = connectRetries;
/*     */   }
/*     */   
/*     */   public List<String> getSchemas() {
/* 320 */     return this.schemas;
/*     */   }
/*     */   
/*     */   public void setSchemas(List<String> schemas) {
/* 324 */     this.schemas = schemas;
/*     */   }
/*     */   
/*     */   public String getTable() {
/* 328 */     return this.table;
/*     */   }
/*     */   
/*     */   public void setTable(String table) {
/* 332 */     this.table = table;
/*     */   }
/*     */   
/*     */   public String getTablespace() {
/* 336 */     return this.tablespace;
/*     */   }
/*     */   
/*     */   public void setTablespace(String tablespace) {
/* 340 */     this.tablespace = tablespace;
/*     */   }
/*     */   
/*     */   public String getBaselineDescription() {
/* 344 */     return this.baselineDescription;
/*     */   }
/*     */   
/*     */   public void setBaselineDescription(String baselineDescription) {
/* 348 */     this.baselineDescription = baselineDescription;
/*     */   }
/*     */   
/*     */   public String getBaselineVersion() {
/* 352 */     return this.baselineVersion;
/*     */   }
/*     */   
/*     */   public void setBaselineVersion(String baselineVersion) {
/* 356 */     this.baselineVersion = baselineVersion;
/*     */   }
/*     */   
/*     */   public String getInstalledBy() {
/* 360 */     return this.installedBy;
/*     */   }
/*     */   
/*     */   public void setInstalledBy(String installedBy) {
/* 364 */     this.installedBy = installedBy;
/*     */   }
/*     */   
/*     */   public Map<String, String> getPlaceholders() {
/* 368 */     return this.placeholders;
/*     */   }
/*     */   
/*     */   public void setPlaceholders(Map<String, String> placeholders) {
/* 372 */     this.placeholders = placeholders;
/*     */   }
/*     */   
/*     */   public String getPlaceholderPrefix() {
/* 376 */     return this.placeholderPrefix;
/*     */   }
/*     */   
/*     */   public void setPlaceholderPrefix(String placeholderPrefix) {
/* 380 */     this.placeholderPrefix = placeholderPrefix;
/*     */   }
/*     */   
/*     */   public String getPlaceholderSuffix() {
/* 384 */     return this.placeholderSuffix;
/*     */   }
/*     */   
/*     */   public void setPlaceholderSuffix(String placeholderSuffix) {
/* 388 */     this.placeholderSuffix = placeholderSuffix;
/*     */   }
/*     */   
/*     */   public boolean isPlaceholderReplacement() {
/* 392 */     return this.placeholderReplacement;
/*     */   }
/*     */   
/*     */   public void setPlaceholderReplacement(boolean placeholderReplacement) {
/* 396 */     this.placeholderReplacement = placeholderReplacement;
/*     */   }
/*     */   
/*     */   public String getSqlMigrationPrefix() {
/* 400 */     return this.sqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationPrefix(String sqlMigrationPrefix) {
/* 404 */     this.sqlMigrationPrefix = sqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public List<String> getSqlMigrationSuffixes() {
/* 408 */     return this.sqlMigrationSuffixes;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationSuffixes(List<String> sqlMigrationSuffixes) {
/* 412 */     this.sqlMigrationSuffixes = sqlMigrationSuffixes;
/*     */   }
/*     */   
/*     */   public String getSqlMigrationSeparator() {
/* 416 */     return this.sqlMigrationSeparator;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationSeparator(String sqlMigrationSeparator) {
/* 420 */     this.sqlMigrationSeparator = sqlMigrationSeparator;
/*     */   }
/*     */   
/*     */   public String getRepeatableSqlMigrationPrefix() {
/* 424 */     return this.repeatableSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setRepeatableSqlMigrationPrefix(String repeatableSqlMigrationPrefix) {
/* 428 */     this.repeatableSqlMigrationPrefix = repeatableSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public String getTarget() {
/* 432 */     return this.target;
/*     */   }
/*     */   
/*     */   public void setTarget(String target) {
/* 436 */     this.target = target;
/*     */   }
/*     */   
/*     */   public boolean isCreateDataSource() {
/* 440 */     return (this.url != null || this.user != null);
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 444 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 448 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 452 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 456 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 460 */     return (this.password != null) ? this.password : "";
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 464 */     this.password = password;
/*     */   }
/*     */   
/*     */   public List<String> getInitSqls() {
/* 468 */     return this.initSqls;
/*     */   }
/*     */   
/*     */   public void setInitSqls(List<String> initSqls) {
/* 472 */     this.initSqls = initSqls;
/*     */   }
/*     */   
/*     */   public boolean isBaselineOnMigrate() {
/* 476 */     return this.baselineOnMigrate;
/*     */   }
/*     */   
/*     */   public void setBaselineOnMigrate(boolean baselineOnMigrate) {
/* 480 */     this.baselineOnMigrate = baselineOnMigrate;
/*     */   }
/*     */   
/*     */   public boolean isCleanDisabled() {
/* 484 */     return this.cleanDisabled;
/*     */   }
/*     */   
/*     */   public void setCleanDisabled(boolean cleanDisabled) {
/* 488 */     this.cleanDisabled = cleanDisabled;
/*     */   }
/*     */   
/*     */   public boolean isCleanOnValidationError() {
/* 492 */     return this.cleanOnValidationError;
/*     */   }
/*     */   
/*     */   public void setCleanOnValidationError(boolean cleanOnValidationError) {
/* 496 */     this.cleanOnValidationError = cleanOnValidationError;
/*     */   }
/*     */   
/*     */   public boolean isGroup() {
/* 500 */     return this.group;
/*     */   }
/*     */   
/*     */   public void setGroup(boolean group) {
/* 504 */     this.group = group;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreMissingMigrations() {
/* 508 */     return this.ignoreMissingMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnoreMissingMigrations(boolean ignoreMissingMigrations) {
/* 512 */     this.ignoreMissingMigrations = ignoreMissingMigrations;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreIgnoredMigrations() {
/* 516 */     return this.ignoreIgnoredMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnoreIgnoredMigrations(boolean ignoreIgnoredMigrations) {
/* 520 */     this.ignoreIgnoredMigrations = ignoreIgnoredMigrations;
/*     */   }
/*     */   
/*     */   public boolean isIgnorePendingMigrations() {
/* 524 */     return this.ignorePendingMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnorePendingMigrations(boolean ignorePendingMigrations) {
/* 528 */     this.ignorePendingMigrations = ignorePendingMigrations;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreFutureMigrations() {
/* 532 */     return this.ignoreFutureMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnoreFutureMigrations(boolean ignoreFutureMigrations) {
/* 536 */     this.ignoreFutureMigrations = ignoreFutureMigrations;
/*     */   }
/*     */   
/*     */   public boolean isMixed() {
/* 540 */     return this.mixed;
/*     */   }
/*     */   
/*     */   public void setMixed(boolean mixed) {
/* 544 */     this.mixed = mixed;
/*     */   }
/*     */   
/*     */   public boolean isOutOfOrder() {
/* 548 */     return this.outOfOrder;
/*     */   }
/*     */   
/*     */   public void setOutOfOrder(boolean outOfOrder) {
/* 552 */     this.outOfOrder = outOfOrder;
/*     */   }
/*     */   
/*     */   public boolean isSkipDefaultCallbacks() {
/* 556 */     return this.skipDefaultCallbacks;
/*     */   }
/*     */   
/*     */   public void setSkipDefaultCallbacks(boolean skipDefaultCallbacks) {
/* 560 */     this.skipDefaultCallbacks = skipDefaultCallbacks;
/*     */   }
/*     */   
/*     */   public boolean isSkipDefaultResolvers() {
/* 564 */     return this.skipDefaultResolvers;
/*     */   }
/*     */   
/*     */   public void setSkipDefaultResolvers(boolean skipDefaultResolvers) {
/* 568 */     this.skipDefaultResolvers = skipDefaultResolvers;
/*     */   }
/*     */   
/*     */   public boolean isValidateOnMigrate() {
/* 572 */     return this.validateOnMigrate;
/*     */   }
/*     */   
/*     */   public void setValidateOnMigrate(boolean validateOnMigrate) {
/* 576 */     this.validateOnMigrate = validateOnMigrate;
/*     */   }
/*     */   
/*     */   public Boolean getBatch() {
/* 580 */     return this.batch;
/*     */   }
/*     */   
/*     */   public void setBatch(Boolean batch) {
/* 584 */     this.batch = batch;
/*     */   }
/*     */   
/*     */   public File getDryRunOutput() {
/* 588 */     return this.dryRunOutput;
/*     */   }
/*     */   
/*     */   public void setDryRunOutput(File dryRunOutput) {
/* 592 */     this.dryRunOutput = dryRunOutput;
/*     */   }
/*     */   
/*     */   public String[] getErrorOverrides() {
/* 596 */     return this.errorOverrides;
/*     */   }
/*     */   
/*     */   public void setErrorOverrides(String[] errorOverrides) {
/* 600 */     this.errorOverrides = errorOverrides;
/*     */   }
/*     */   
/*     */   public String getLicenseKey() {
/* 604 */     return this.licenseKey;
/*     */   }
/*     */   
/*     */   public void setLicenseKey(String licenseKey) {
/* 608 */     this.licenseKey = licenseKey;
/*     */   }
/*     */   
/*     */   public Boolean getOracleSqlplus() {
/* 612 */     return this.oracleSqlplus;
/*     */   }
/*     */   
/*     */   public void setOracleSqlplus(Boolean oracleSqlplus) {
/* 616 */     this.oracleSqlplus = oracleSqlplus;
/*     */   }
/*     */   
/*     */   public Boolean getOracleSqlplusWarn() {
/* 620 */     return this.oracleSqlplusWarn;
/*     */   }
/*     */   
/*     */   public void setOracleSqlplusWarn(Boolean oracleSqlplusWarn) {
/* 624 */     this.oracleSqlplusWarn = oracleSqlplusWarn;
/*     */   }
/*     */   
/*     */   public Boolean getStream() {
/* 628 */     return this.stream;
/*     */   }
/*     */   
/*     */   public void setStream(Boolean stream) {
/* 632 */     this.stream = stream;
/*     */   }
/*     */   
/*     */   public String getUndoSqlMigrationPrefix() {
/* 636 */     return this.undoSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setUndoSqlMigrationPrefix(String undoSqlMigrationPrefix) {
/* 640 */     this.undoSqlMigrationPrefix = undoSqlMigrationPrefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\flyway\FlywayProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
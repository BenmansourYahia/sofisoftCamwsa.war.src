/*     */ package org.springframework.boot.autoconfigure.ldap.embedded;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.convert.Delimiter;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.ldap.embedded")
/*     */ public class EmbeddedLdapProperties
/*     */ {
/*  39 */   private int port = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   private Credential credential = new Credential();
/*     */ 
/*     */ 
/*     */   
/*     */   @Delimiter("")
/*  49 */   private List<String> baseDn = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private String ldif = "classpath:schema.ldif";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private Validation validation = new Validation();
/*     */   
/*     */   public int getPort() {
/*  63 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  67 */     this.port = port;
/*     */   }
/*     */   
/*     */   public Credential getCredential() {
/*  71 */     return this.credential;
/*     */   }
/*     */   
/*     */   public void setCredential(Credential credential) {
/*  75 */     this.credential = credential;
/*     */   }
/*     */   
/*     */   public List<String> getBaseDn() {
/*  79 */     return this.baseDn;
/*     */   }
/*     */   
/*     */   public void setBaseDn(List<String> baseDn) {
/*  83 */     this.baseDn = baseDn;
/*     */   }
/*     */   
/*     */   public String getLdif() {
/*  87 */     return this.ldif;
/*     */   }
/*     */   
/*     */   public void setLdif(String ldif) {
/*  91 */     this.ldif = ldif;
/*     */   }
/*     */   
/*     */   public Validation getValidation() {
/*  95 */     return this.validation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Credential
/*     */   {
/*     */     private String username;
/*     */ 
/*     */     
/*     */     private String password;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUsername() {
/* 111 */       return this.username;
/*     */     }
/*     */     
/*     */     public void setUsername(String username) {
/* 115 */       this.username = username;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 119 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 123 */       this.password = password;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Validation
/*     */   {
/*     */     private boolean enabled = true;
/*     */ 
/*     */ 
/*     */     
/*     */     private Resource schema;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 141 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 145 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public Resource getSchema() {
/* 149 */       return this.schema;
/*     */     }
/*     */     
/*     */     public void setSchema(Resource schema) {
/* 153 */       this.schema = schema;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\ldap\embedded\EmbeddedLdapProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
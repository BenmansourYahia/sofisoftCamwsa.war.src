/*     */ package org.springframework.boot.autoconfigure.ldap;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.ldap")
/*     */ public class LdapProperties
/*     */ {
/*     */   private static final int DEFAULT_PORT = 389;
/*     */   private String[] urls;
/*     */   private String base;
/*     */   private String username;
/*     */   private String password;
/*     */   private boolean anonymousReadOnly;
/*  66 */   private final Map<String, String> baseEnvironment = new HashMap<>();
/*     */   
/*     */   public String[] getUrls() {
/*  69 */     return this.urls;
/*     */   }
/*     */   
/*     */   public void setUrls(String[] urls) {
/*  73 */     this.urls = urls;
/*     */   }
/*     */   
/*     */   public String getBase() {
/*  77 */     return this.base;
/*     */   }
/*     */   
/*     */   public void setBase(String base) {
/*  81 */     this.base = base;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  85 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  89 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  93 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  97 */     this.password = password;
/*     */   }
/*     */   
/*     */   public boolean getAnonymousReadOnly() {
/* 101 */     return this.anonymousReadOnly;
/*     */   }
/*     */   
/*     */   public void setAnonymousReadOnly(boolean anonymousReadOnly) {
/* 105 */     this.anonymousReadOnly = anonymousReadOnly;
/*     */   }
/*     */   
/*     */   public Map<String, String> getBaseEnvironment() {
/* 109 */     return this.baseEnvironment;
/*     */   }
/*     */   
/*     */   public String[] determineUrls(Environment environment) {
/* 113 */     if (ObjectUtils.isEmpty((Object[])this.urls)) {
/* 114 */       return new String[] { "ldap://localhost:" + determinePort(environment) };
/*     */     }
/* 116 */     return this.urls;
/*     */   }
/*     */   
/*     */   private int determinePort(Environment environment) {
/* 120 */     Assert.notNull(environment, "Environment must not be null");
/* 121 */     String localPort = environment.getProperty("local.ldap.port");
/* 122 */     if (localPort != null) {
/* 123 */       return Integer.valueOf(localPort).intValue();
/*     */     }
/* 125 */     return 389;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\ldap\LdapProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
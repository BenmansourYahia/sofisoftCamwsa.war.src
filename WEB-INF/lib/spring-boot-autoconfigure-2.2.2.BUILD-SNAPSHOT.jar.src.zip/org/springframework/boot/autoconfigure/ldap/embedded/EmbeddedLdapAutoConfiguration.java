/*     */ package org.springframework.boot.autoconfigure.ldap.embedded;
/*     */ 
/*     */ import com.unboundid.ldap.listener.InMemoryDirectoryServer;
/*     */ import com.unboundid.ldap.listener.InMemoryDirectoryServerConfig;
/*     */ import com.unboundid.ldap.listener.InMemoryListenerConfig;
/*     */ import com.unboundid.ldap.sdk.LDAPException;
/*     */ import com.unboundid.ldap.sdk.schema.Schema;
/*     */ import com.unboundid.ldif.LDIFReader;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.PreDestroy;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.ldap.LdapAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.ldap.LdapProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.DependsOn;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.ldap.core.support.LdapContextSource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({LdapProperties.class, EmbeddedLdapProperties.class})
/*     */ @AutoConfigureBefore({LdapAutoConfiguration.class})
/*     */ @ConditionalOnClass({InMemoryDirectoryServer.class})
/*     */ @Conditional({EmbeddedLdapAutoConfiguration.EmbeddedLdapCondition.class})
/*     */ public class EmbeddedLdapAutoConfiguration
/*     */ {
/*     */   private static final String PROPERTY_SOURCE_NAME = "ldap.ports";
/*     */   private final EmbeddedLdapProperties embeddedProperties;
/*     */   private InMemoryDirectoryServer server;
/*     */   
/*     */   public EmbeddedLdapAutoConfiguration(EmbeddedLdapProperties embeddedProperties) {
/*  86 */     this.embeddedProperties = embeddedProperties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @DependsOn({"directoryServer"})
/*     */   @ConditionalOnMissingBean
/*     */   public LdapContextSource ldapContextSource(Environment environment, LdapProperties properties) {
/*  93 */     LdapContextSource source = new LdapContextSource();
/*  94 */     if (hasCredentials(this.embeddedProperties.getCredential())) {
/*  95 */       source.setUserDn(this.embeddedProperties.getCredential().getUsername());
/*  96 */       source.setPassword(this.embeddedProperties.getCredential().getPassword());
/*     */     } 
/*  98 */     source.setUrls(properties.determineUrls(environment));
/*  99 */     return source;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public InMemoryDirectoryServer directoryServer(ApplicationContext applicationContext) throws LDAPException {
/* 104 */     String[] baseDn = StringUtils.toStringArray(this.embeddedProperties.getBaseDn());
/* 105 */     InMemoryDirectoryServerConfig config = new InMemoryDirectoryServerConfig(baseDn);
/* 106 */     if (hasCredentials(this.embeddedProperties.getCredential())) {
/* 107 */       config.addAdditionalBindCredentials(this.embeddedProperties.getCredential().getUsername(), this.embeddedProperties
/* 108 */           .getCredential().getPassword());
/*     */     }
/* 110 */     setSchema(config);
/* 111 */     InMemoryListenerConfig listenerConfig = InMemoryListenerConfig.createLDAPConfig("LDAP", this.embeddedProperties
/* 112 */         .getPort());
/* 113 */     config.setListenerConfigs(new InMemoryListenerConfig[] { listenerConfig });
/* 114 */     this.server = new InMemoryDirectoryServer(config);
/* 115 */     importLdif(applicationContext);
/* 116 */     this.server.startListening();
/* 117 */     setPortProperty(applicationContext, this.server.getListenPort());
/* 118 */     return this.server;
/*     */   }
/*     */   
/*     */   private void setSchema(InMemoryDirectoryServerConfig config) {
/* 122 */     if (!this.embeddedProperties.getValidation().isEnabled()) {
/* 123 */       config.setSchema(null);
/*     */       return;
/*     */     } 
/* 126 */     Resource schema = this.embeddedProperties.getValidation().getSchema();
/* 127 */     if (schema != null) {
/* 128 */       setSchema(config, schema);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setSchema(InMemoryDirectoryServerConfig config, Resource resource) {
/*     */     try {
/* 134 */       Schema defaultSchema = Schema.getDefaultStandardSchema();
/* 135 */       Schema schema = Schema.getSchema(resource.getInputStream());
/* 136 */       config.setSchema(Schema.mergeSchemas(new Schema[] { defaultSchema, schema }));
/*     */     }
/* 138 */     catch (Exception ex) {
/* 139 */       throw new IllegalStateException("Unable to load schema " + resource.getDescription(), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasCredentials(EmbeddedLdapProperties.Credential credential) {
/* 144 */     return (StringUtils.hasText(credential.getUsername()) && StringUtils.hasText(credential.getPassword()));
/*     */   }
/*     */   
/*     */   private void importLdif(ApplicationContext applicationContext) throws LDAPException {
/* 148 */     String location = this.embeddedProperties.getLdif();
/* 149 */     if (StringUtils.hasText(location)) {
/*     */       try {
/* 151 */         Resource resource = applicationContext.getResource(location);
/* 152 */         if (resource.exists()) {
/* 153 */           try (InputStream inputStream = resource.getInputStream()) {
/* 154 */             this.server.importFromLDIF(true, new LDIFReader(inputStream));
/*     */           }
/*     */         
/*     */         }
/* 158 */       } catch (Exception ex) {
/* 159 */         throw new IllegalStateException("Unable to load LDIF " + location, ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void setPortProperty(ApplicationContext context, int port) {
/* 165 */     if (context instanceof ConfigurableApplicationContext) {
/*     */       
/* 167 */       MutablePropertySources sources = ((ConfigurableApplicationContext)context).getEnvironment().getPropertySources();
/* 168 */       getLdapPorts(sources).put("local.ldap.port", Integer.valueOf(port));
/*     */     } 
/* 170 */     if (context.getParent() != null) {
/* 171 */       setPortProperty(context.getParent(), port);
/*     */     }
/*     */   }
/*     */   
/*     */   private Map<String, Object> getLdapPorts(MutablePropertySources sources) {
/*     */     MapPropertySource mapPropertySource;
/* 177 */     PropertySource<?> propertySource = sources.get("ldap.ports");
/* 178 */     if (propertySource == null) {
/* 179 */       mapPropertySource = new MapPropertySource("ldap.ports", new HashMap<>());
/* 180 */       sources.addFirst((PropertySource)mapPropertySource);
/*     */     } 
/* 182 */     return (Map<String, Object>)mapPropertySource.getSource();
/*     */   }
/*     */   
/*     */   @PreDestroy
/*     */   public void close() {
/* 187 */     if (this.server != null) {
/* 188 */       this.server.shutDown(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class EmbeddedLdapCondition
/*     */     extends SpringBootCondition
/*     */   {
/* 198 */     private static final Bindable<List<String>> STRING_LIST = Bindable.listOf(String.class);
/*     */ 
/*     */     
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 202 */       ConditionMessage.Builder message = ConditionMessage.forCondition("Embedded LDAP", new Object[0]);
/* 203 */       Environment environment = context.getEnvironment();
/* 204 */       if (environment != null && 
/* 205 */         !((List)Binder.get(environment).bind("spring.ldap.embedded.base-dn", STRING_LIST).orElseGet(Collections::emptyList)).isEmpty()) {
/* 206 */         return ConditionOutcome.match(message.because("Found base-dn property"));
/*     */       }
/* 208 */       return ConditionOutcome.noMatch(message.because("No base-dn property found"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\ldap\embedded\EmbeddedLdapAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
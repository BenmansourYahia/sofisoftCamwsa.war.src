/*    */ package org.springframework.boot.autoconfigure.ldap;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.ldap.core.ContextSource;
/*    */ import org.springframework.ldap.core.LdapOperations;
/*    */ import org.springframework.ldap.core.LdapTemplate;
/*    */ import org.springframework.ldap.core.support.LdapContextSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({ContextSource.class})
/*    */ @EnableConfigurationProperties({LdapProperties.class})
/*    */ public class LdapAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public LdapContextSource ldapContextSource(LdapProperties properties, Environment environment) {
/* 49 */     LdapContextSource source = new LdapContextSource();
/* 50 */     PropertyMapper propertyMapper = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 51 */     propertyMapper.from(properties.getUsername()).to(source::setUserDn);
/* 52 */     propertyMapper.from(properties.getPassword()).to(source::setPassword);
/* 53 */     propertyMapper.from(Boolean.valueOf(properties.getAnonymousReadOnly())).to(source::setAnonymousReadOnly);
/* 54 */     propertyMapper.from(properties.getBase()).to(source::setBase);
/* 55 */     propertyMapper.from(properties.determineUrls(environment)).to(source::setUrls);
/* 56 */     propertyMapper.from(properties.getBaseEnvironment()).to(baseEnvironment -> source.setBaseEnvironmentProperties(Collections.unmodifiableMap(baseEnvironment)));
/*    */     
/* 58 */     return source;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({LdapOperations.class})
/*    */   public LdapTemplate ldapTemplate(ContextSource contextSource) {
/* 64 */     return new LdapTemplate(contextSource);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\ldap\LdapAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
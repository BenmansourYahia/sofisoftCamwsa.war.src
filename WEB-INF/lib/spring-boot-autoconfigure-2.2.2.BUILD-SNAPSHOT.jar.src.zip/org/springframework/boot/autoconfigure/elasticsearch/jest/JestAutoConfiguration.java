/*    */ package org.springframework.boot.autoconfigure.elasticsearch.jest;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import io.searchbox.client.JestClient;
/*    */ import io.searchbox.client.JestClientFactory;
/*    */ import io.searchbox.client.config.HttpClientConfig;
/*    */ import java.time.Duration;
/*    */ import org.apache.http.HttpHost;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.gson.GsonAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({JestClient.class})
/*    */ @EnableConfigurationProperties({JestProperties.class})
/*    */ @AutoConfigureAfter({GsonAutoConfiguration.class})
/*    */ @Deprecated
/*    */ public class JestAutoConfiguration
/*    */ {
/*    */   @Bean(destroyMethod = "shutdownClient")
/*    */   @ConditionalOnMissingBean
/*    */   public JestClient jestClient(JestProperties properties, ObjectProvider<Gson> gson, ObjectProvider<HttpClientConfigBuilderCustomizer> builderCustomizers) {
/* 58 */     JestClientFactory factory = new JestClientFactory();
/* 59 */     factory.setHttpClientConfig(createHttpClientConfig(properties, gson, builderCustomizers));
/* 60 */     return factory.getObject();
/*    */   }
/*    */ 
/*    */   
/*    */   protected HttpClientConfig createHttpClientConfig(JestProperties properties, ObjectProvider<Gson> gson, ObjectProvider<HttpClientConfigBuilderCustomizer> builderCustomizers) {
/* 65 */     HttpClientConfig.Builder builder = new HttpClientConfig.Builder(properties.getUris());
/* 66 */     PropertyMapper map = PropertyMapper.get();
/* 67 */     map.from(properties::getUsername).whenHasText()
/* 68 */       .to(username -> builder.defaultCredentials(username, properties.getPassword()));
/* 69 */     JestProperties.Proxy proxy = properties.getProxy();
/* 70 */     map.from(proxy::getHost).whenHasText().to(host -> {
/*    */           Assert.notNull(proxy.getPort(), "Proxy port must not be null");
/*    */           builder.proxy(new HttpHost(host, proxy.getPort().intValue()));
/*    */         });
/* 74 */     map.from(gson::getIfUnique).whenNonNull().to(x$0 -> rec$.gson(x$0));
/* 75 */     map.from(properties::isMultiThreaded).to(x$0 -> rec$.multiThreaded(x$0));
/* 76 */     map.from(properties::getConnectionTimeout).whenNonNull().asInt(Duration::toMillis).to(x$0 -> rec$.connTimeout(x$0));
/* 77 */     map.from(properties::getReadTimeout).whenNonNull().asInt(Duration::toMillis).to(x$0 -> rec$.readTimeout(x$0));
/* 78 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 79 */     return builder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\elasticsearch\jest\JestAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
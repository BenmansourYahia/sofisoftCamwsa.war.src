/*     */ package org.springframework.boot.autoconfigure.elasticsearch.rest;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.apache.http.HttpHost;
/*     */ import org.apache.http.auth.AuthScope;
/*     */ import org.apache.http.auth.Credentials;
/*     */ import org.apache.http.auth.UsernamePasswordCredentials;
/*     */ import org.apache.http.client.CredentialsProvider;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.impl.client.BasicCredentialsProvider;
/*     */ import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
/*     */ import org.elasticsearch.client.RestClient;
/*     */ import org.elasticsearch.client.RestClientBuilder;
/*     */ import org.elasticsearch.client.RestHighLevelClient;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RestClientConfigurations
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class RestClientBuilderConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RestClientBuilder elasticsearchRestClientBuilder(RestClientProperties properties, ObjectProvider<RestClientBuilderCustomizer> builderCustomizers) {
/*  53 */       HttpHost[] hosts = (HttpHost[])properties.getUris().stream().map(HttpHost::create).toArray(x$0 -> new HttpHost[x$0]);
/*  54 */       RestClientBuilder builder = RestClient.builder(hosts);
/*  55 */       PropertyMapper map = PropertyMapper.get();
/*  56 */       map.from(properties::getUsername).whenHasText().to(username -> {
/*     */             BasicCredentialsProvider basicCredentialsProvider = new BasicCredentialsProvider();
/*     */             
/*     */             UsernamePasswordCredentials usernamePasswordCredentials = new UsernamePasswordCredentials(properties.getUsername(), properties.getPassword());
/*     */             
/*     */             basicCredentialsProvider.setCredentials(AuthScope.ANY, (Credentials)usernamePasswordCredentials);
/*     */             builder.setHttpClientConfigCallback(());
/*     */           });
/*  64 */       builder.setRequestConfigCallback(requestConfigBuilder -> {
/*     */             map.from(properties::getConnectionTimeout).whenNonNull().asInt(Duration::toMillis).to(requestConfigBuilder::setConnectTimeout);
/*     */             
/*     */             map.from(properties::getReadTimeout).whenNonNull().asInt(Duration::toMillis).to(requestConfigBuilder::setSocketTimeout);
/*     */             
/*     */             return requestConfigBuilder;
/*     */           });
/*  71 */       builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/*  72 */       return builder;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({RestHighLevelClient.class})
/*     */   static class RestHighLevelClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RestHighLevelClient elasticsearchRestHighLevelClient(RestClientBuilder restClientBuilder) {
/*  84 */       return new RestHighLevelClient(restClientBuilder);
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RestClient elasticsearchRestClient(RestClientBuilder builder, ObjectProvider<RestHighLevelClient> restHighLevelClient) {
/*  91 */       RestHighLevelClient client = (RestHighLevelClient)restHighLevelClient.getIfUnique();
/*  92 */       if (client != null) {
/*  93 */         return client.getLowLevelClient();
/*     */       }
/*  95 */       return builder.build();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class RestClientFallbackConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RestClient elasticsearchRestClient(RestClientBuilder builder) {
/* 106 */       return builder.build();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\elasticsearch\rest\RestClientConfigurations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
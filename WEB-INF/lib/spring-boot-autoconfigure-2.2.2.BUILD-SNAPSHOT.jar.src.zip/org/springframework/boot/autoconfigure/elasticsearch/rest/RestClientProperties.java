/*    */ package org.springframework.boot.autoconfigure.elasticsearch.rest;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.elasticsearch.rest")
/*    */ public class RestClientProperties
/*    */ {
/* 38 */   private List<String> uris = new ArrayList<>(Collections.singletonList("http://localhost:9200"));
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String username;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String password;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   private Duration connectionTimeout = Duration.ofSeconds(1L);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   private Duration readTimeout = Duration.ofSeconds(30L);
/*    */   
/*    */   public List<String> getUris() {
/* 61 */     return this.uris;
/*    */   }
/*    */   
/*    */   public void setUris(List<String> uris) {
/* 65 */     this.uris = uris;
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 69 */     return this.username;
/*    */   }
/*    */   
/*    */   public void setUsername(String username) {
/* 73 */     this.username = username;
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 77 */     return this.password;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 81 */     this.password = password;
/*    */   }
/*    */   
/*    */   public Duration getConnectionTimeout() {
/* 85 */     return this.connectionTimeout;
/*    */   }
/*    */   
/*    */   public void setConnectionTimeout(Duration connectionTimeout) {
/* 89 */     this.connectionTimeout = connectionTimeout;
/*    */   }
/*    */   
/*    */   public Duration getReadTimeout() {
/* 93 */     return this.readTimeout;
/*    */   }
/*    */   
/*    */   public void setReadTimeout(Duration readTimeout) {
/* 97 */     this.readTimeout = readTimeout;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\elasticsearch\rest\RestClientProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
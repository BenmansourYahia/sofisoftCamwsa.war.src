/*    */ package org.springframework.boot.autoconfigure.sendgrid;
/*    */ 
/*    */ import com.sendgrid.Client;
/*    */ import com.sendgrid.SendGrid;
/*    */ import com.sendgrid.SendGridAPI;
/*    */ import org.apache.http.HttpHost;
/*    */ import org.apache.http.impl.client.HttpClientBuilder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({SendGrid.class})
/*    */ @ConditionalOnProperty(prefix = "spring.sendgrid", value = {"api-key"})
/*    */ @EnableConfigurationProperties({SendGridProperties.class})
/*    */ public class SendGridAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({SendGridAPI.class})
/*    */   public SendGrid sendGrid(SendGridProperties properties) {
/* 50 */     if (properties.isProxyConfigured()) {
/* 51 */       HttpHost proxy = new HttpHost(properties.getProxy().getHost(), properties.getProxy().getPort().intValue());
/* 52 */       return new SendGrid(properties.getApiKey(), new Client(HttpClientBuilder.create().setProxy(proxy).build()));
/*    */     } 
/* 54 */     return new SendGrid(properties.getApiKey());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\sendgrid\SendGridAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.diagnostics.analyzer;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.ConstructorBinding;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.boot.diagnostics.analyzer.AbstractInjectionFailureAnalyzer;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NoSuchBeanDefinitionFailureAnalyzer
/*     */   extends AbstractInjectionFailureAnalyzer<NoSuchBeanDefinitionException>
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private ConfigurableListableBeanFactory beanFactory;
/*     */   private MetadataReaderFactory metadataReaderFactory;
/*     */   private ConditionEvaluationReport report;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/*  77 */     Assert.isInstanceOf(ConfigurableListableBeanFactory.class, beanFactory);
/*  78 */     this.beanFactory = (ConfigurableListableBeanFactory)beanFactory;
/*  79 */     this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory(this.beanFactory.getBeanClassLoader());
/*     */     
/*  81 */     this.report = ConditionEvaluationReport.get(this.beanFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchBeanDefinitionException cause, String description) {
/*  86 */     if (cause.getNumberOfBeansFound() != 0) {
/*  87 */       return null;
/*     */     }
/*  89 */     List<AutoConfigurationResult> autoConfigurationResults = getAutoConfigurationResults(cause);
/*  90 */     List<UserConfigurationResult> userConfigurationResults = getUserConfigurationResults(cause);
/*  91 */     StringBuilder message = new StringBuilder();
/*  92 */     message.append(String.format("%s required %s that could not be found.%n", new Object[] { (description != null) ? description : "A component", 
/*  93 */             getBeanDescription(cause) }));
/*  94 */     InjectionPoint injectionPoint = findInjectionPoint(rootFailure);
/*  95 */     if (injectionPoint != null) {
/*  96 */       Annotation[] injectionAnnotations = injectionPoint.getAnnotations();
/*  97 */       if (injectionAnnotations.length > 0) {
/*  98 */         message.append(String.format("%nThe injection point has the following annotations:%n", new Object[0]));
/*  99 */         for (Annotation injectionAnnotation : injectionAnnotations) {
/* 100 */           message.append(String.format("\t- %s%n", new Object[] { injectionAnnotation }));
/*     */         } 
/*     */       } 
/*     */     } 
/* 104 */     if (!autoConfigurationResults.isEmpty() || !userConfigurationResults.isEmpty()) {
/* 105 */       message.append(String.format("%nThe following candidates were found but could not be injected:%n", new Object[0]));
/* 106 */       for (AutoConfigurationResult result : autoConfigurationResults) {
/* 107 */         message.append(String.format("\t- %s%n", new Object[] { result }));
/*     */       } 
/* 109 */       for (UserConfigurationResult result : userConfigurationResults) {
/* 110 */         message.append(String.format("\t- %s%n", new Object[] { result }));
/*     */       } 
/*     */     } 
/* 113 */     String action = String.format("Consider %s %s in your configuration.", new Object[] { (
/* 114 */           !autoConfigurationResults.isEmpty() || !userConfigurationResults.isEmpty()) ? "revisiting the entries above or defining" : "defining", 
/*     */           
/* 116 */           getBeanDescription(cause) });
/* 117 */     if (injectionPoint != null && injectionPoint.getMember() instanceof Constructor) {
/* 118 */       Constructor<?> constructor = (Constructor)injectionPoint.getMember();
/* 119 */       Class<?> declaringClass = constructor.getDeclaringClass();
/*     */       
/* 121 */       MergedAnnotation<ConfigurationProperties> configurationProperties = MergedAnnotations.from(declaringClass).get(ConfigurationProperties.class);
/* 122 */       if (configurationProperties.isPresent()) {
/* 123 */         action = String.format("%s%nConsider adding @%s to %s if you intended to use constructor-based configuration property binding.", new Object[] { action, ConstructorBinding.class
/*     */ 
/*     */               
/* 126 */               .getSimpleName(), constructor.getName() });
/*     */       }
/*     */     } 
/* 129 */     return new FailureAnalysis(message.toString(), action, (Throwable)cause);
/*     */   }
/*     */   
/*     */   private String getBeanDescription(NoSuchBeanDefinitionException cause) {
/* 133 */     if (cause.getResolvableType() != null) {
/* 134 */       Class<?> type = extractBeanType(cause.getResolvableType());
/* 135 */       return "a bean of type '" + type.getName() + "'";
/*     */     } 
/* 137 */     return "a bean named '" + cause.getBeanName() + "'";
/*     */   }
/*     */   
/*     */   private Class<?> extractBeanType(ResolvableType resolvableType) {
/* 141 */     return resolvableType.getRawClass();
/*     */   }
/*     */   
/*     */   private List<AutoConfigurationResult> getAutoConfigurationResults(NoSuchBeanDefinitionException cause) {
/* 145 */     List<AutoConfigurationResult> results = new ArrayList<>();
/* 146 */     collectReportedConditionOutcomes(cause, results);
/* 147 */     collectExcludedAutoConfiguration(cause, results);
/* 148 */     return results;
/*     */   }
/*     */   
/*     */   private List<UserConfigurationResult> getUserConfigurationResults(NoSuchBeanDefinitionException cause) {
/* 152 */     ResolvableType type = cause.getResolvableType();
/* 153 */     if (type == null) {
/* 154 */       return Collections.emptyList();
/*     */     }
/* 156 */     String[] beanNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.beanFactory, type);
/* 157 */     return (List<UserConfigurationResult>)Arrays.<String>stream(beanNames)
/* 158 */       .map(beanName -> new UserConfigurationResult(getFactoryMethodMetadata(beanName), this.beanFactory.getBean(beanName).equals(null)))
/*     */       
/* 160 */       .collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   private MethodMetadata getFactoryMethodMetadata(String beanName) {
/* 164 */     BeanDefinition beanDefinition = this.beanFactory.getBeanDefinition(beanName);
/* 165 */     if (beanDefinition instanceof AnnotatedBeanDefinition) {
/* 166 */       return ((AnnotatedBeanDefinition)beanDefinition).getFactoryMethodMetadata();
/*     */     }
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void collectReportedConditionOutcomes(NoSuchBeanDefinitionException cause, List<AutoConfigurationResult> results) {
/* 173 */     this.report.getConditionAndOutcomesBySource()
/* 174 */       .forEach((source, sourceOutcomes) -> collectReportedConditionOutcomes(cause, new Source(source), sourceOutcomes, results));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void collectReportedConditionOutcomes(NoSuchBeanDefinitionException cause, Source source, ConditionEvaluationReport.ConditionAndOutcomes sourceOutcomes, List<AutoConfigurationResult> results) {
/* 180 */     if (sourceOutcomes.isFullMatch()) {
/*     */       return;
/*     */     }
/* 183 */     BeanMethods methods = new BeanMethods(source, cause);
/* 184 */     for (ConditionEvaluationReport.ConditionAndOutcome conditionAndOutcome : sourceOutcomes) {
/* 185 */       if (!conditionAndOutcome.getOutcome().isMatch()) {
/* 186 */         for (MethodMetadata method : methods) {
/* 187 */           results.add(new AutoConfigurationResult(method, conditionAndOutcome.getOutcome()));
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void collectExcludedAutoConfiguration(NoSuchBeanDefinitionException cause, List<AutoConfigurationResult> results) {
/* 195 */     for (String excludedClass : this.report.getExclusions()) {
/* 196 */       Source source = new Source(excludedClass);
/* 197 */       BeanMethods methods = new BeanMethods(source, cause);
/* 198 */       for (MethodMetadata method : methods) {
/* 199 */         String message = String.format("auto-configuration '%s' was excluded", new Object[] {
/* 200 */               ClassUtils.getShortName(excludedClass) });
/* 201 */         results.add(new AutoConfigurationResult(method, new ConditionOutcome(false, message)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private InjectionPoint findInjectionPoint(Throwable failure) {
/* 207 */     UnsatisfiedDependencyException unsatisfiedDependencyException = (UnsatisfiedDependencyException)findCause(failure, UnsatisfiedDependencyException.class);
/*     */     
/* 209 */     if (unsatisfiedDependencyException == null) {
/* 210 */       return null;
/*     */     }
/* 212 */     return unsatisfiedDependencyException.getInjectionPoint();
/*     */   }
/*     */ 
/*     */   
/*     */   private class Source
/*     */   {
/*     */     private final String className;
/*     */     private final String methodName;
/*     */     
/*     */     Source(String source) {
/* 222 */       String[] tokens = source.split("#");
/* 223 */       this.className = (tokens.length > 1) ? tokens[0] : source;
/* 224 */       this.methodName = (tokens.length != 2) ? null : tokens[1];
/*     */     }
/*     */     
/*     */     String getClassName() {
/* 228 */       return this.className;
/*     */     }
/*     */     
/*     */     String getMethodName() {
/* 232 */       return this.methodName;
/*     */     }
/*     */   }
/*     */   
/*     */   private class BeanMethods
/*     */     implements Iterable<MethodMetadata>
/*     */   {
/*     */     private final List<MethodMetadata> methods;
/*     */     
/*     */     BeanMethods(NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/* 242 */       this.methods = findBeanMethods(source, cause);
/*     */     }
/*     */ 
/*     */     
/*     */     private List<MethodMetadata> findBeanMethods(NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/*     */       try {
/* 248 */         MetadataReader classMetadata = NoSuchBeanDefinitionFailureAnalyzer.this.metadataReaderFactory.getMetadataReader(source.getClassName());
/*     */         
/* 250 */         Set<MethodMetadata> candidates = classMetadata.getAnnotationMetadata().getAnnotatedMethods(Bean.class.getName());
/* 251 */         List<MethodMetadata> result = new ArrayList<>();
/* 252 */         for (MethodMetadata candidate : candidates) {
/* 253 */           if (isMatch(candidate, source, cause)) {
/* 254 */             result.add(candidate);
/*     */           }
/*     */         } 
/* 257 */         return Collections.unmodifiableList(result);
/*     */       }
/* 259 */       catch (Exception ex) {
/* 260 */         return Collections.emptyList();
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isMatch(MethodMetadata candidate, NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/* 265 */       if (source.getMethodName() != null && !source.getMethodName().equals(candidate.getMethodName())) {
/* 266 */         return false;
/*     */       }
/* 268 */       String name = cause.getBeanName();
/* 269 */       ResolvableType resolvableType = cause.getResolvableType();
/* 270 */       return ((name != null && hasName(candidate, name)) || (resolvableType != null && 
/* 271 */         hasType(candidate, NoSuchBeanDefinitionFailureAnalyzer.this.extractBeanType(resolvableType))));
/*     */     }
/*     */     
/*     */     private boolean hasName(MethodMetadata methodMetadata, String name) {
/* 275 */       Map<String, Object> attributes = methodMetadata.getAnnotationAttributes(Bean.class.getName());
/* 276 */       String[] candidates = (attributes != null) ? (String[])attributes.get("name") : null;
/* 277 */       if (candidates != null) {
/* 278 */         for (String candidate : candidates) {
/* 279 */           if (candidate.equals(name)) {
/* 280 */             return true;
/*     */           }
/*     */         } 
/* 283 */         return false;
/*     */       } 
/* 285 */       return methodMetadata.getMethodName().equals(name);
/*     */     }
/*     */     
/*     */     private boolean hasType(MethodMetadata candidate, Class<?> type) {
/* 289 */       String returnTypeName = candidate.getReturnTypeName();
/* 290 */       if (type.getName().equals(returnTypeName)) {
/* 291 */         return true;
/*     */       }
/*     */       try {
/* 294 */         Class<?> returnType = ClassUtils.forName(returnTypeName, NoSuchBeanDefinitionFailureAnalyzer.this
/* 295 */             .beanFactory.getBeanClassLoader());
/* 296 */         return type.isAssignableFrom(returnType);
/*     */       }
/* 298 */       catch (Throwable ex) {
/* 299 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<MethodMetadata> iterator() {
/* 305 */       return this.methods.iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class AutoConfigurationResult
/*     */   {
/*     */     private final MethodMetadata methodMetadata;
/*     */     
/*     */     private final ConditionOutcome conditionOutcome;
/*     */     
/*     */     AutoConfigurationResult(MethodMetadata methodMetadata, ConditionOutcome conditionOutcome) {
/* 317 */       this.methodMetadata = methodMetadata;
/* 318 */       this.conditionOutcome = conditionOutcome;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 323 */       return String.format("Bean method '%s' in '%s' not loaded because %s", new Object[] { this.methodMetadata.getMethodName(), 
/* 324 */             ClassUtils.getShortName(this.methodMetadata.getDeclaringClassName()), this.conditionOutcome
/* 325 */             .getMessage() });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class UserConfigurationResult
/*     */   {
/*     */     private final MethodMetadata methodMetadata;
/*     */     
/*     */     private final boolean nullBean;
/*     */     
/*     */     UserConfigurationResult(MethodMetadata methodMetadata, boolean nullBean) {
/* 337 */       this.methodMetadata = methodMetadata;
/* 338 */       this.nullBean = nullBean;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 343 */       StringBuilder sb = new StringBuilder("User-defined bean");
/* 344 */       if (this.methodMetadata != null) {
/* 345 */         sb.append(String.format(" method '%s' in '%s'", new Object[] { this.methodMetadata.getMethodName(), 
/* 346 */                 ClassUtils.getShortName(this.methodMetadata.getDeclaringClassName()) }));
/*     */       }
/* 348 */       if (this.nullBean) {
/* 349 */         sb.append(" ignored as the bean value is null");
/*     */       }
/* 351 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\diagnostics\analyzer\NoSuchBeanDefinitionFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
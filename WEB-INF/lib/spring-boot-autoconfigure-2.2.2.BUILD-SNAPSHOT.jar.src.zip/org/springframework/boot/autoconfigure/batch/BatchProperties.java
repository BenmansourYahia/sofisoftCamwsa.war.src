/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.batch")
/*    */ public class BatchProperties
/*    */ {
/*    */   private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/* 39 */   private String schema = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String tablePrefix;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   private DataSourceInitializationMode initializeSchema = DataSourceInitializationMode.EMBEDDED;
/*    */   
/* 51 */   private final Job job = new Job();
/*    */   
/*    */   public String getSchema() {
/* 54 */     return this.schema;
/*    */   }
/*    */   
/*    */   public void setSchema(String schema) {
/* 58 */     this.schema = schema;
/*    */   }
/*    */   
/*    */   public String getTablePrefix() {
/* 62 */     return this.tablePrefix;
/*    */   }
/*    */   
/*    */   public void setTablePrefix(String tablePrefix) {
/* 66 */     this.tablePrefix = tablePrefix;
/*    */   }
/*    */   
/*    */   public DataSourceInitializationMode getInitializeSchema() {
/* 70 */     return this.initializeSchema;
/*    */   }
/*    */   
/*    */   public void setInitializeSchema(DataSourceInitializationMode initializeSchema) {
/* 74 */     this.initializeSchema = initializeSchema;
/*    */   }
/*    */   
/*    */   public Job getJob() {
/* 78 */     return this.job;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Job
/*    */   {
/* 87 */     private String names = "";
/*    */     
/*    */     public String getNames() {
/* 90 */       return this.names;
/*    */     }
/*    */     
/*    */     public void setNames(String names) {
/* 94 */       this.names = names;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\batch\BatchProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
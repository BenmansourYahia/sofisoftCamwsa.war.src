/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.launch.support.SimpleJobLauncher;
/*     */ import org.springframework.batch.core.repository.JobRepository;
/*     */ import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.jdbc.datasource.DataSourceTransactionManager;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicBatchConfigurer
/*     */   implements BatchConfigurer
/*     */ {
/*     */   private final BatchProperties properties;
/*     */   private final DataSource dataSource;
/*     */   private PlatformTransactionManager transactionManager;
/*     */   private final TransactionManagerCustomizers transactionManagerCustomizers;
/*     */   private JobRepository jobRepository;
/*     */   private JobLauncher jobLauncher;
/*     */   private JobExplorer jobExplorer;
/*     */   
/*     */   protected BasicBatchConfigurer(BatchProperties properties, DataSource dataSource, TransactionManagerCustomizers transactionManagerCustomizers) {
/*  68 */     this.properties = properties;
/*  69 */     this.dataSource = dataSource;
/*  70 */     this.transactionManagerCustomizers = transactionManagerCustomizers;
/*     */   }
/*     */ 
/*     */   
/*     */   public JobRepository getJobRepository() {
/*  75 */     return this.jobRepository;
/*     */   }
/*     */ 
/*     */   
/*     */   public PlatformTransactionManager getTransactionManager() {
/*  80 */     return this.transactionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public JobLauncher getJobLauncher() {
/*  85 */     return this.jobLauncher;
/*     */   }
/*     */ 
/*     */   
/*     */   public JobExplorer getJobExplorer() throws Exception {
/*  90 */     return this.jobExplorer;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void initialize() {
/*     */     try {
/*  96 */       this.transactionManager = buildTransactionManager();
/*  97 */       this.jobRepository = createJobRepository();
/*  98 */       this.jobLauncher = createJobLauncher();
/*  99 */       this.jobExplorer = createJobExplorer();
/*     */     }
/* 101 */     catch (Exception ex) {
/* 102 */       throw new IllegalStateException("Unable to initialize Spring Batch", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected JobExplorer createJobExplorer() throws Exception {
/* 107 */     PropertyMapper map = PropertyMapper.get();
/* 108 */     JobExplorerFactoryBean factory = new JobExplorerFactoryBean();
/* 109 */     factory.setDataSource(this.dataSource);
/* 110 */     map.from(this.properties::getTablePrefix).whenHasText().to(factory::setTablePrefix);
/* 111 */     factory.afterPropertiesSet();
/* 112 */     return factory.getObject();
/*     */   }
/*     */   
/*     */   protected JobLauncher createJobLauncher() throws Exception {
/* 116 */     SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
/* 117 */     jobLauncher.setJobRepository(getJobRepository());
/* 118 */     jobLauncher.afterPropertiesSet();
/* 119 */     return (JobLauncher)jobLauncher;
/*     */   }
/*     */   
/*     */   protected JobRepository createJobRepository() throws Exception {
/* 123 */     JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
/* 124 */     PropertyMapper map = PropertyMapper.get();
/* 125 */     map.from(this.dataSource).to(factory::setDataSource);
/* 126 */     map.from(this::determineIsolationLevel).whenNonNull().to(factory::setIsolationLevelForCreate);
/* 127 */     map.from(this.properties::getTablePrefix).whenHasText().to(factory::setTablePrefix);
/* 128 */     map.from(this::getTransactionManager).to(factory::setTransactionManager);
/* 129 */     factory.afterPropertiesSet();
/* 130 */     return factory.getObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String determineIsolationLevel() {
/* 138 */     return null;
/*     */   }
/*     */   
/*     */   protected PlatformTransactionManager createTransactionManager() {
/* 142 */     return (PlatformTransactionManager)new DataSourceTransactionManager(this.dataSource);
/*     */   }
/*     */   
/*     */   private PlatformTransactionManager buildTransactionManager() {
/* 146 */     PlatformTransactionManager transactionManager = createTransactionManager();
/* 147 */     if (this.transactionManagerCustomizers != null) {
/* 148 */       this.transactionManagerCustomizers.customize(transactionManager);
/*     */     }
/* 150 */     return transactionManager;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\batch\BasicBatchConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
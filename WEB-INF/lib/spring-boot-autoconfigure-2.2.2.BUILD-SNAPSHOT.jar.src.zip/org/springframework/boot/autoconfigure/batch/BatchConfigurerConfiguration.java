/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import javax.persistence.EntityManagerFactory;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnClass({PlatformTransactionManager.class})
/*    */ @ConditionalOnBean({DataSource.class})
/*    */ @ConditionalOnMissingBean({BatchConfigurer.class})
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class BatchConfigurerConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean(name = {"entityManagerFactory"})
/*    */   static class JdbcBatchConfiguration
/*    */   {
/*    */     @Bean
/*    */     BasicBatchConfigurer batchConfigurer(BatchProperties properties, DataSource dataSource, @BatchDataSource ObjectProvider<DataSource> batchDataSource, ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
/* 51 */       return new BasicBatchConfigurer(properties, (DataSource)batchDataSource.getIfAvailable(() -> dataSource), (TransactionManagerCustomizers)transactionManagerCustomizers
/* 52 */           .getIfAvailable());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({EntityManagerFactory.class})
/*    */   @ConditionalOnBean(name = {"entityManagerFactory"})
/*    */   static class JpaBatchConfiguration
/*    */   {
/*    */     @Bean
/*    */     JpaBatchConfigurer batchConfigurer(BatchProperties properties, DataSource dataSource, @BatchDataSource ObjectProvider<DataSource> batchDataSource, ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers, EntityManagerFactory entityManagerFactory) {
/* 67 */       return new JpaBatchConfigurer(properties, (DataSource)batchDataSource.getIfAvailable(() -> dataSource), (TransactionManagerCustomizers)transactionManagerCustomizers
/* 68 */           .getIfAvailable(), entityManagerFactory);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\batch\BatchConfigurerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
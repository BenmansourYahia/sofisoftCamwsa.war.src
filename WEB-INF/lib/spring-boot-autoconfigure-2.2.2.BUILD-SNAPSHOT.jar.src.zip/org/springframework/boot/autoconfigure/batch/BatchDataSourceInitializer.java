/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.jdbc.AbstractDataSourceInitializer;
/*    */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchDataSourceInitializer
/*    */   extends AbstractDataSourceInitializer
/*    */ {
/*    */   private final BatchProperties properties;
/*    */   
/*    */   public BatchDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader, BatchProperties properties) {
/* 39 */     super(dataSource, resourceLoader);
/* 40 */     Assert.notNull(properties, "BatchProperties must not be null");
/* 41 */     this.properties = properties;
/*    */   }
/*    */ 
/*    */   
/*    */   protected DataSourceInitializationMode getMode() {
/* 46 */     return this.properties.getInitializeSchema();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getSchemaLocation() {
/* 51 */     return this.properties.getSchema();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getDatabaseName() {
/* 56 */     String databaseName = super.getDatabaseName();
/* 57 */     if ("oracle".equals(databaseName)) {
/* 58 */       return "oracle10g";
/*    */     }
/* 60 */     return databaseName;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\batch\BatchDataSourceInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
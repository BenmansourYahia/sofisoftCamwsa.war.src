/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.batch.core.BatchStatus;
/*     */ import org.springframework.batch.core.Job;
/*     */ import org.springframework.batch.core.JobExecution;
/*     */ import org.springframework.batch.core.JobExecutionException;
/*     */ import org.springframework.batch.core.JobParameter;
/*     */ import org.springframework.batch.core.JobParameters;
/*     */ import org.springframework.batch.core.JobParametersBuilder;
/*     */ import org.springframework.batch.core.JobParametersInvalidException;
/*     */ import org.springframework.batch.core.configuration.JobRegistry;
/*     */ import org.springframework.batch.core.converter.DefaultJobParametersConverter;
/*     */ import org.springframework.batch.core.converter.JobParametersConverter;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.launch.JobParametersNotFoundException;
/*     */ import org.springframework.batch.core.launch.NoSuchJobException;
/*     */ import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
/*     */ import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
/*     */ import org.springframework.batch.core.repository.JobRepository;
/*     */ import org.springframework.batch.core.repository.JobRestartException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.CommandLineRunner;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobLauncherCommandLineRunner
/*     */   implements CommandLineRunner, Ordered, ApplicationEventPublisherAware
/*     */ {
/*     */   public static final int DEFAULT_ORDER = 0;
/*  76 */   private static final Log logger = LogFactory.getLog(JobLauncherCommandLineRunner.class);
/*     */   
/*  78 */   private JobParametersConverter converter = (JobParametersConverter)new DefaultJobParametersConverter();
/*     */   
/*     */   private final JobLauncher jobLauncher;
/*     */   
/*     */   private final JobExplorer jobExplorer;
/*     */   
/*     */   private final JobRepository jobRepository;
/*     */   
/*     */   private JobRegistry jobRegistry;
/*     */   
/*     */   private String jobNames;
/*     */   
/*  90 */   private Collection<Job> jobs = Collections.emptySet();
/*     */   
/*  92 */   private int order = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ApplicationEventPublisher publisher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JobLauncherCommandLineRunner(JobLauncher jobLauncher, JobExplorer jobExplorer, JobRepository jobRepository) {
/* 104 */     Assert.notNull(jobLauncher, "JobLauncher must not be null");
/* 105 */     Assert.notNull(jobExplorer, "JobExplorer must not be null");
/* 106 */     Assert.notNull(jobRepository, "JobRepository must not be null");
/* 107 */     this.jobLauncher = jobLauncher;
/* 108 */     this.jobExplorer = jobExplorer;
/* 109 */     this.jobRepository = jobRepository;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 113 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 118 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
/* 123 */     this.publisher = publisher;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setJobRegistry(JobRegistry jobRegistry) {
/* 128 */     this.jobRegistry = jobRegistry;
/*     */   }
/*     */   
/*     */   public void setJobNames(String jobNames) {
/* 132 */     this.jobNames = jobNames;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setJobParametersConverter(JobParametersConverter converter) {
/* 137 */     this.converter = converter;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setJobs(Collection<Job> jobs) {
/* 142 */     this.jobs = jobs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run(String... args) throws JobExecutionException {
/* 147 */     logger.info("Running default command line with: " + Arrays.<String>asList(args));
/* 148 */     launchJobFromProperties(StringUtils.splitArrayElementsIntoProperties(args, "="));
/*     */   }
/*     */   
/*     */   protected void launchJobFromProperties(Properties properties) throws JobExecutionException {
/* 152 */     JobParameters jobParameters = this.converter.getJobParameters(properties);
/* 153 */     executeLocalJobs(jobParameters);
/* 154 */     executeRegisteredJobs(jobParameters);
/*     */   }
/*     */   
/*     */   private void executeLocalJobs(JobParameters jobParameters) throws JobExecutionException {
/* 158 */     for (Job job : this.jobs) {
/* 159 */       if (StringUtils.hasText(this.jobNames)) {
/* 160 */         String[] jobsToRun = this.jobNames.split(",");
/* 161 */         if (!PatternMatchUtils.simpleMatch(jobsToRun, job.getName())) {
/* 162 */           logger.debug(LogMessage.format("Skipped job: %s", job.getName()));
/*     */           continue;
/*     */         } 
/*     */       } 
/* 166 */       execute(job, jobParameters);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void executeRegisteredJobs(JobParameters jobParameters) throws JobExecutionException {
/* 171 */     if (this.jobRegistry != null && StringUtils.hasText(this.jobNames)) {
/* 172 */       String[] jobsToRun = this.jobNames.split(",");
/* 173 */       for (String jobName : jobsToRun) {
/*     */         try {
/* 175 */           Job job = this.jobRegistry.getJob(jobName);
/* 176 */           if (!this.jobs.contains(job))
/*     */           {
/*     */             
/* 179 */             execute(job, jobParameters);
/*     */           }
/* 181 */         } catch (NoSuchJobException ex) {
/* 182 */           logger.debug(LogMessage.format("No job found in registry for job name: %s", jobName));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void execute(Job job, JobParameters jobParameters) throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException, JobParametersNotFoundException {
/* 191 */     JobParameters parameters = getNextJobParameters(job, jobParameters);
/* 192 */     JobExecution execution = this.jobLauncher.run(job, parameters);
/* 193 */     if (this.publisher != null) {
/* 194 */       this.publisher.publishEvent(new JobExecutionEvent(execution));
/*     */     }
/*     */   }
/*     */   
/*     */   private JobParameters getNextJobParameters(Job job, JobParameters jobParameters) {
/* 199 */     if (this.jobRepository != null && this.jobRepository.isJobInstanceExists(job.getName(), jobParameters)) {
/* 200 */       return getNextJobParametersForExisting(job, jobParameters);
/*     */     }
/* 202 */     if (job.getJobParametersIncrementer() == null) {
/* 203 */       return jobParameters;
/*     */     }
/*     */     
/* 206 */     JobParameters nextParameters = (new JobParametersBuilder(jobParameters, this.jobExplorer)).getNextJobParameters(job).toJobParameters();
/* 207 */     return merge(nextParameters, jobParameters);
/*     */   }
/*     */   
/*     */   private JobParameters getNextJobParametersForExisting(Job job, JobParameters jobParameters) {
/* 211 */     JobExecution lastExecution = this.jobRepository.getLastJobExecution(job.getName(), jobParameters);
/* 212 */     if (isStoppedOrFailed(lastExecution) && job.isRestartable()) {
/* 213 */       JobParameters previousIdentifyingParameters = getGetIdentifying(lastExecution.getJobParameters());
/* 214 */       return merge(previousIdentifyingParameters, jobParameters);
/*     */     } 
/* 216 */     return jobParameters;
/*     */   }
/*     */   
/*     */   private boolean isStoppedOrFailed(JobExecution execution) {
/* 220 */     BatchStatus status = (execution != null) ? execution.getStatus() : null;
/* 221 */     return (status == BatchStatus.STOPPED || status == BatchStatus.FAILED);
/*     */   }
/*     */   
/*     */   private JobParameters getGetIdentifying(JobParameters parameters) {
/* 225 */     HashMap<String, JobParameter> nonIdentifying = new LinkedHashMap<>(parameters.getParameters().size());
/* 226 */     parameters.getParameters().forEach((key, value) -> {
/*     */           if (value.isIdentifying()) {
/*     */             nonIdentifying.put(key, value);
/*     */           }
/*     */         });
/* 231 */     return new JobParameters(nonIdentifying);
/*     */   }
/*     */   
/*     */   private JobParameters merge(JobParameters parameters, JobParameters additionals) {
/* 235 */     Map<String, JobParameter> merged = new LinkedHashMap<>();
/* 236 */     merged.putAll(parameters.getParameters());
/* 237 */     merged.putAll(additionals.getParameters());
/* 238 */     return new JobParameters(merged);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\batch\JobLauncherCommandLineRunner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.batch.core.configuration.ListableJobLocator;
/*     */ import org.springframework.batch.core.converter.JobParametersConverter;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.launch.JobOperator;
/*     */ import org.springframework.batch.core.launch.support.SimpleJobOperator;
/*     */ import org.springframework.batch.core.repository.JobRepository;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.ExitCodeGenerator;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({JobLauncher.class, DataSource.class})
/*     */ @AutoConfigureAfter({HibernateJpaAutoConfiguration.class})
/*     */ @ConditionalOnBean({JobLauncher.class})
/*     */ @EnableConfigurationProperties({BatchProperties.class})
/*     */ @Import({BatchConfigurerConfiguration.class})
/*     */ public class BatchAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnProperty(prefix = "spring.batch.job", name = {"enabled"}, havingValue = "true", matchIfMissing = true)
/*     */   public JobLauncherCommandLineRunner jobLauncherCommandLineRunner(JobLauncher jobLauncher, JobExplorer jobExplorer, JobRepository jobRepository, BatchProperties properties) {
/*  75 */     JobLauncherCommandLineRunner runner = new JobLauncherCommandLineRunner(jobLauncher, jobExplorer, jobRepository);
/*  76 */     String jobNames = properties.getJob().getNames();
/*  77 */     if (StringUtils.hasText(jobNames)) {
/*  78 */       runner.setJobNames(jobNames);
/*     */     }
/*  80 */     return runner;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ExitCodeGenerator.class})
/*     */   public JobExecutionExitCodeGenerator jobExecutionExitCodeGenerator() {
/*  86 */     return new JobExecutionExitCodeGenerator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({JobOperator.class})
/*     */   public SimpleJobOperator jobOperator(ObjectProvider<JobParametersConverter> jobParametersConverter, JobExplorer jobExplorer, JobLauncher jobLauncher, ListableJobLocator jobRegistry, JobRepository jobRepository) throws Exception {
/*  94 */     SimpleJobOperator factory = new SimpleJobOperator();
/*  95 */     factory.setJobExplorer(jobExplorer);
/*  96 */     factory.setJobLauncher(jobLauncher);
/*  97 */     factory.setJobRegistry(jobRegistry);
/*  98 */     factory.setJobRepository(jobRepository);
/*  99 */     jobParametersConverter.ifAvailable(factory::setJobParametersConverter);
/* 100 */     return factory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnBean({DataSource.class})
/*     */   @ConditionalOnClass({DatabasePopulator.class})
/*     */   static class DataSourceInitializerConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     BatchDataSourceInitializer batchDataSourceInitializer(DataSource dataSource, @BatchDataSource ObjectProvider<DataSource> batchDataSource, ResourceLoader resourceLoader, BatchProperties properties) {
/* 113 */       return new BatchDataSourceInitializer((DataSource)batchDataSource.getIfAvailable(() -> dataSource), resourceLoader, properties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\batch\BatchAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
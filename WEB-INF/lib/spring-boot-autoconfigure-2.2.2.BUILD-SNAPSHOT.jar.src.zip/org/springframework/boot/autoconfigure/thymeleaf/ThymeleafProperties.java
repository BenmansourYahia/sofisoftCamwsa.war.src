/*     */ package org.springframework.boot.autoconfigure.thymeleaf;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.thymeleaf")
/*     */ public class ThymeleafProperties
/*     */ {
/*  40 */   private static final Charset DEFAULT_ENCODING = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_PREFIX = "classpath:/templates/";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_SUFFIX = ".html";
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkTemplate = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkTemplateLocation = true;
/*     */ 
/*     */   
/*  59 */   private String prefix = "classpath:/templates/";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private String suffix = ".html";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private String mode = "HTML";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private Charset encoding = DEFAULT_ENCODING;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean cache = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer templateResolverOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] viewNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] excludedViewNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enableSpringElCompiler;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean renderHiddenMarkersBeforeCheckboxes = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private final Servlet servlet = new Servlet();
/*     */   
/* 117 */   private final Reactive reactive = new Reactive();
/*     */   
/*     */   public boolean isEnabled() {
/* 120 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 124 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public boolean isCheckTemplate() {
/* 128 */     return this.checkTemplate;
/*     */   }
/*     */   
/*     */   public void setCheckTemplate(boolean checkTemplate) {
/* 132 */     this.checkTemplate = checkTemplate;
/*     */   }
/*     */   
/*     */   public boolean isCheckTemplateLocation() {
/* 136 */     return this.checkTemplateLocation;
/*     */   }
/*     */   
/*     */   public void setCheckTemplateLocation(boolean checkTemplateLocation) {
/* 140 */     this.checkTemplateLocation = checkTemplateLocation;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 144 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 148 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */   public String getSuffix() {
/* 152 */     return this.suffix;
/*     */   }
/*     */   
/*     */   public void setSuffix(String suffix) {
/* 156 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */   public String getMode() {
/* 160 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(String mode) {
/* 164 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/* 168 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/* 172 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public boolean isCache() {
/* 176 */     return this.cache;
/*     */   }
/*     */   
/*     */   public void setCache(boolean cache) {
/* 180 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public Integer getTemplateResolverOrder() {
/* 184 */     return this.templateResolverOrder;
/*     */   }
/*     */   
/*     */   public void setTemplateResolverOrder(Integer templateResolverOrder) {
/* 188 */     this.templateResolverOrder = templateResolverOrder;
/*     */   }
/*     */   
/*     */   public String[] getExcludedViewNames() {
/* 192 */     return this.excludedViewNames;
/*     */   }
/*     */   
/*     */   public void setExcludedViewNames(String[] excludedViewNames) {
/* 196 */     this.excludedViewNames = excludedViewNames;
/*     */   }
/*     */   
/*     */   public String[] getViewNames() {
/* 200 */     return this.viewNames;
/*     */   }
/*     */   
/*     */   public void setViewNames(String[] viewNames) {
/* 204 */     this.viewNames = viewNames;
/*     */   }
/*     */   
/*     */   public boolean isEnableSpringElCompiler() {
/* 208 */     return this.enableSpringElCompiler;
/*     */   }
/*     */   
/*     */   public void setEnableSpringElCompiler(boolean enableSpringElCompiler) {
/* 212 */     this.enableSpringElCompiler = enableSpringElCompiler;
/*     */   }
/*     */   
/*     */   public boolean isRenderHiddenMarkersBeforeCheckboxes() {
/* 216 */     return this.renderHiddenMarkersBeforeCheckboxes;
/*     */   }
/*     */   
/*     */   public void setRenderHiddenMarkersBeforeCheckboxes(boolean renderHiddenMarkersBeforeCheckboxes) {
/* 220 */     this.renderHiddenMarkersBeforeCheckboxes = renderHiddenMarkersBeforeCheckboxes;
/*     */   }
/*     */   
/*     */   public Reactive getReactive() {
/* 224 */     return this.reactive;
/*     */   }
/*     */   
/*     */   public Servlet getServlet() {
/* 228 */     return this.servlet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Servlet
/*     */   {
/* 236 */     private MimeType contentType = MimeType.valueOf("text/html");
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean producePartialOutputWhileProcessing = true;
/*     */ 
/*     */ 
/*     */     
/*     */     public MimeType getContentType() {
/* 245 */       return this.contentType;
/*     */     }
/*     */     
/*     */     public void setContentType(MimeType contentType) {
/* 249 */       this.contentType = contentType;
/*     */     }
/*     */     
/*     */     public boolean isProducePartialOutputWhileProcessing() {
/* 253 */       return this.producePartialOutputWhileProcessing;
/*     */     }
/*     */     
/*     */     public void setProducePartialOutputWhileProcessing(boolean producePartialOutputWhileProcessing) {
/* 257 */       this.producePartialOutputWhileProcessing = producePartialOutputWhileProcessing;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Reactive
/*     */   {
/* 268 */     private DataSize maxChunkSize = DataSize.ofBytes(0L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<MediaType> mediaTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String[] fullModeViewNames;
/*     */ 
/*     */ 
/*     */     
/*     */     private String[] chunkedModeViewNames;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MediaType> getMediaTypes() {
/* 288 */       return this.mediaTypes;
/*     */     }
/*     */     
/*     */     public void setMediaTypes(List<MediaType> mediaTypes) {
/* 292 */       this.mediaTypes = mediaTypes;
/*     */     }
/*     */     
/*     */     public DataSize getMaxChunkSize() {
/* 296 */       return this.maxChunkSize;
/*     */     }
/*     */     
/*     */     public void setMaxChunkSize(DataSize maxChunkSize) {
/* 300 */       this.maxChunkSize = maxChunkSize;
/*     */     }
/*     */     
/*     */     public String[] getFullModeViewNames() {
/* 304 */       return this.fullModeViewNames;
/*     */     }
/*     */     
/*     */     public void setFullModeViewNames(String[] fullModeViewNames) {
/* 308 */       this.fullModeViewNames = fullModeViewNames;
/*     */     }
/*     */     
/*     */     public String[] getChunkedModeViewNames() {
/* 312 */       return this.chunkedModeViewNames;
/*     */     }
/*     */     
/*     */     public void setChunkedModeViewNames(String[] chunkedModeViewNames) {
/* 316 */       this.chunkedModeViewNames = chunkedModeViewNames;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\thymeleaf\ThymeleafProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
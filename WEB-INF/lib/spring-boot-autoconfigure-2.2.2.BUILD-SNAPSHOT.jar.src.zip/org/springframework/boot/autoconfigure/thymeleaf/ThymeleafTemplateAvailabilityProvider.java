/*    */ package org.springframework.boot.autoconfigure.thymeleaf;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProvider;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThymeleafTemplateAvailabilityProvider
/*    */   implements TemplateAvailabilityProvider
/*    */ {
/*    */   public boolean isTemplateAvailable(String view, Environment environment, ClassLoader classLoader, ResourceLoader resourceLoader) {
/* 37 */     if (ClassUtils.isPresent("org.thymeleaf.spring5.SpringTemplateEngine", classLoader)) {
/* 38 */       String prefix = environment.getProperty("spring.thymeleaf.prefix", "classpath:/templates/");
/* 39 */       String suffix = environment.getProperty("spring.thymeleaf.suffix", ".html");
/* 40 */       return resourceLoader.getResource(prefix + view + suffix).exists();
/*    */     } 
/* 42 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\thymeleaf\ThymeleafTemplateAvailabilityProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
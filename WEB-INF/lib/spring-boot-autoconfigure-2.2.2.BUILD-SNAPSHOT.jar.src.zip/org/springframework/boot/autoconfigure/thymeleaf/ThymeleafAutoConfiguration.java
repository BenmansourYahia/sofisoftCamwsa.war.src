/*     */ package org.springframework.boot.autoconfigure.thymeleaf;
/*     */ 
/*     */ import com.github.mxab.thymeleaf.extras.dataattribute.dialect.DataAttributeDialect;
/*     */ import java.util.LinkedHashMap;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Filter;
/*     */ import nz.net.ultraq.thymeleaf.LayoutDialect;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateLocation;
/*     */ import org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain;
/*     */ import org.springframework.boot.autoconfigure.web.reactive.WebFluxAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.ConditionalOnMissingFilterBean;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.web.servlet.FilterRegistrationBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ import org.springframework.web.servlet.resource.ResourceUrlEncodingFilter;
/*     */ import org.thymeleaf.dialect.IDialect;
/*     */ import org.thymeleaf.extras.java8time.dialect.Java8TimeDialect;
/*     */ import org.thymeleaf.extras.springsecurity5.dialect.SpringSecurityDialect;
/*     */ import org.thymeleaf.spring5.ISpringTemplateEngine;
/*     */ import org.thymeleaf.spring5.ISpringWebFluxTemplateEngine;
/*     */ import org.thymeleaf.spring5.SpringTemplateEngine;
/*     */ import org.thymeleaf.spring5.SpringWebFluxTemplateEngine;
/*     */ import org.thymeleaf.spring5.templateresolver.SpringResourceTemplateResolver;
/*     */ import org.thymeleaf.spring5.view.ThymeleafViewResolver;
/*     */ import org.thymeleaf.spring5.view.reactive.ThymeleafReactiveViewResolver;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresolver.ITemplateResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({ThymeleafProperties.class})
/*     */ @ConditionalOnClass({TemplateMode.class, SpringTemplateEngine.class})
/*     */ @AutoConfigureAfter({WebMvcAutoConfiguration.class, WebFluxAutoConfiguration.class})
/*     */ public class ThymeleafAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean(name = {"defaultTemplateResolver"})
/*     */   static class DefaultTemplateResolverConfiguration
/*     */   {
/*  89 */     private static final Log logger = LogFactory.getLog(DefaultTemplateResolverConfiguration.class);
/*     */     
/*     */     private final ThymeleafProperties properties;
/*     */     
/*     */     private final ApplicationContext applicationContext;
/*     */     
/*     */     DefaultTemplateResolverConfiguration(ThymeleafProperties properties, ApplicationContext applicationContext) {
/*  96 */       this.properties = properties;
/*  97 */       this.applicationContext = applicationContext;
/*     */     }
/*     */     
/*     */     @PostConstruct
/*     */     void checkTemplateLocationExists() {
/* 102 */       boolean checkTemplateLocation = this.properties.isCheckTemplateLocation();
/* 103 */       if (checkTemplateLocation) {
/* 104 */         TemplateLocation location = new TemplateLocation(this.properties.getPrefix());
/* 105 */         if (!location.exists((ResourcePatternResolver)this.applicationContext)) {
/* 106 */           logger.warn("Cannot find template location: " + location + " (please add some templates or check your Thymeleaf configuration)");
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     SpringResourceTemplateResolver defaultTemplateResolver() {
/* 114 */       SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
/* 115 */       resolver.setApplicationContext(this.applicationContext);
/* 116 */       resolver.setPrefix(this.properties.getPrefix());
/* 117 */       resolver.setSuffix(this.properties.getSuffix());
/* 118 */       resolver.setTemplateMode(this.properties.getMode());
/* 119 */       if (this.properties.getEncoding() != null) {
/* 120 */         resolver.setCharacterEncoding(this.properties.getEncoding().name());
/*     */       }
/* 122 */       resolver.setCacheable(this.properties.isCache());
/* 123 */       Integer order = this.properties.getTemplateResolverOrder();
/* 124 */       if (order != null) {
/* 125 */         resolver.setOrder(order);
/*     */       }
/* 127 */       resolver.setCheckExistence(this.properties.isCheckTemplate());
/* 128 */       return resolver;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   protected static class ThymeleafDefaultConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({ISpringTemplateEngine.class})
/*     */     SpringTemplateEngine templateEngine(ThymeleafProperties properties, ObjectProvider<ITemplateResolver> templateResolvers, ObjectProvider<IDialect> dialects) {
/* 140 */       SpringTemplateEngine engine = new SpringTemplateEngine();
/* 141 */       engine.setEnableSpringELCompiler(properties.isEnableSpringElCompiler());
/* 142 */       engine.setRenderHiddenMarkersBeforeCheckboxes(properties.isRenderHiddenMarkersBeforeCheckboxes());
/* 143 */       templateResolvers.orderedStream().forEach(engine::addTemplateResolver);
/* 144 */       dialects.orderedStream().forEach(engine::addDialect);
/* 145 */       return engine;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */   @ConditionalOnProperty(name = {"spring.thymeleaf.enabled"}, matchIfMissing = true)
/*     */   static class ThymeleafWebMvcConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnEnabledResourceChain
/*     */     @ConditionalOnMissingFilterBean({ResourceUrlEncodingFilter.class})
/*     */     FilterRegistrationBean<ResourceUrlEncodingFilter> resourceUrlEncodingFilter() {
/* 159 */       FilterRegistrationBean<ResourceUrlEncodingFilter> registration = new FilterRegistrationBean((Filter)new ResourceUrlEncodingFilter(), new org.springframework.boot.web.servlet.ServletRegistrationBean[0]);
/*     */       
/* 161 */       registration.setDispatcherTypes(DispatcherType.REQUEST, new DispatcherType[] { DispatcherType.ERROR });
/* 162 */       return registration;
/*     */     }
/*     */ 
/*     */     
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     static class ThymeleafViewResolverConfiguration
/*     */     {
/*     */       @Bean
/*     */       @ConditionalOnMissingBean(name = {"thymeleafViewResolver"})
/*     */       ThymeleafViewResolver thymeleafViewResolver(ThymeleafProperties properties, SpringTemplateEngine templateEngine) {
/* 172 */         ThymeleafViewResolver resolver = new ThymeleafViewResolver();
/* 173 */         resolver.setTemplateEngine((ISpringTemplateEngine)templateEngine);
/* 174 */         resolver.setCharacterEncoding(properties.getEncoding().name());
/* 175 */         resolver.setContentType(
/* 176 */             appendCharset(properties.getServlet().getContentType(), resolver.getCharacterEncoding()));
/* 177 */         resolver.setProducePartialOutputWhileProcessing(properties
/* 178 */             .getServlet().isProducePartialOutputWhileProcessing());
/* 179 */         resolver.setExcludedViewNames(properties.getExcludedViewNames());
/* 180 */         resolver.setViewNames(properties.getViewNames());
/*     */ 
/*     */         
/* 183 */         resolver.setOrder(2147483642);
/* 184 */         resolver.setCache(properties.isCache());
/* 185 */         return resolver;
/*     */       }
/*     */       
/*     */       private String appendCharset(MimeType type, String charset) {
/* 189 */         if (type.getCharset() != null) {
/* 190 */           return type.toString();
/*     */         }
/* 192 */         LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
/* 193 */         parameters.put("charset", charset);
/* 194 */         parameters.putAll(type.getParameters());
/* 195 */         return (new MimeType(type, parameters)).toString();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*     */   @ConditionalOnProperty(name = {"spring.thymeleaf.enabled"}, matchIfMissing = true)
/*     */   static class ThymeleafReactiveConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({ISpringWebFluxTemplateEngine.class})
/*     */     SpringWebFluxTemplateEngine templateEngine(ThymeleafProperties properties, ObjectProvider<ITemplateResolver> templateResolvers, ObjectProvider<IDialect> dialects) {
/* 211 */       SpringWebFluxTemplateEngine engine = new SpringWebFluxTemplateEngine();
/* 212 */       engine.setEnableSpringELCompiler(properties.isEnableSpringElCompiler());
/* 213 */       engine.setRenderHiddenMarkersBeforeCheckboxes(properties.isRenderHiddenMarkersBeforeCheckboxes());
/* 214 */       templateResolvers.orderedStream().forEach(engine::addTemplateResolver);
/* 215 */       dialects.orderedStream().forEach(engine::addDialect);
/* 216 */       return engine;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*     */   @ConditionalOnProperty(name = {"spring.thymeleaf.enabled"}, matchIfMissing = true)
/*     */   static class ThymeleafWebFluxConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(name = {"thymeleafReactiveViewResolver"})
/*     */     ThymeleafReactiveViewResolver thymeleafViewResolver(ISpringWebFluxTemplateEngine templateEngine, ThymeleafProperties properties) {
/* 230 */       ThymeleafReactiveViewResolver resolver = new ThymeleafReactiveViewResolver();
/* 231 */       resolver.setTemplateEngine(templateEngine);
/* 232 */       mapProperties(properties, resolver);
/* 233 */       mapReactiveProperties(properties.getReactive(), resolver);
/*     */ 
/*     */       
/* 236 */       resolver.setOrder(2147483642);
/* 237 */       return resolver;
/*     */     }
/*     */     
/*     */     private void mapProperties(ThymeleafProperties properties, ThymeleafReactiveViewResolver resolver) {
/* 241 */       PropertyMapper map = PropertyMapper.get();
/* 242 */       map.from(properties::getEncoding).to(resolver::setDefaultCharset);
/* 243 */       resolver.setExcludedViewNames(properties.getExcludedViewNames());
/* 244 */       resolver.setViewNames(properties.getViewNames());
/*     */     }
/*     */     
/*     */     private void mapReactiveProperties(ThymeleafProperties.Reactive properties, ThymeleafReactiveViewResolver resolver) {
/* 248 */       PropertyMapper map = PropertyMapper.get();
/* 249 */       map.from(properties::getMediaTypes).whenNonNull().to(resolver::setSupportedMediaTypes);
/* 250 */       map.from(properties::getMaxChunkSize).asInt(DataSize::toBytes).when(size -> (size.intValue() > 0))
/* 251 */         .to(resolver::setResponseMaxChunkSizeBytes);
/* 252 */       map.from(properties::getFullModeViewNames).to(resolver::setFullModeViewNames);
/* 253 */       map.from(properties::getChunkedModeViewNames).to(resolver::setChunkedModeViewNames);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({LayoutDialect.class})
/*     */   static class ThymeleafWebLayoutConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     LayoutDialect layoutDialect() {
/* 265 */       return new LayoutDialect();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({DataAttributeDialect.class})
/*     */   static class DataAttributeDialectConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     DataAttributeDialect dialect() {
/* 277 */       return new DataAttributeDialect();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({SpringSecurityDialect.class})
/*     */   static class ThymeleafSecurityDialectConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     SpringSecurityDialect securityDialect() {
/* 289 */       return new SpringSecurityDialect();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Java8TimeDialect.class})
/*     */   static class ThymeleafJava8TimeDialect
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     Java8TimeDialect java8TimeDialect() {
/* 301 */       return new Java8TimeDialect();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\thymeleaf\ThymeleafAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
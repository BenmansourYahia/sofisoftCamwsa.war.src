/*    */ package org.springframework.boot.autoconfigure.rsocket;
/*    */ 
/*    */ import io.rsocket.RSocketFactory;
/*    */ import io.rsocket.SocketAcceptor;
/*    */ import io.rsocket.transport.ServerTransport;
/*    */ import io.rsocket.transport.netty.server.WebsocketRouteTransport;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collector;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.boot.rsocket.server.ServerRSocketFactoryProcessor;
/*    */ import org.springframework.boot.web.embedded.netty.NettyRouteProvider;
/*    */ import reactor.netty.http.server.HttpServerRoutes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RSocketWebSocketNettyRouteProvider
/*    */   implements NettyRouteProvider
/*    */ {
/*    */   private final String mappingPath;
/*    */   private final SocketAcceptor socketAcceptor;
/*    */   private final List<ServerRSocketFactoryProcessor> processors;
/*    */   
/*    */   RSocketWebSocketNettyRouteProvider(String mappingPath, SocketAcceptor socketAcceptor, Stream<ServerRSocketFactoryProcessor> processors) {
/* 47 */     this.mappingPath = mappingPath;
/* 48 */     this.socketAcceptor = socketAcceptor;
/* 49 */     this.processors = processors.collect((Collector)Collectors.toList());
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpServerRoutes apply(HttpServerRoutes httpServerRoutes) {
/* 54 */     RSocketFactory.ServerRSocketFactory server = RSocketFactory.receive();
/* 55 */     for (ServerRSocketFactoryProcessor processor : this.processors) {
/* 56 */       server = processor.process(server);
/*    */     }
/* 58 */     ServerTransport.ConnectionAcceptor acceptor = server.acceptor(this.socketAcceptor).toConnectionAcceptor();
/* 59 */     return httpServerRoutes.ws(this.mappingPath, WebsocketRouteTransport.newHandler(acceptor));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketWebSocketNettyRouteProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
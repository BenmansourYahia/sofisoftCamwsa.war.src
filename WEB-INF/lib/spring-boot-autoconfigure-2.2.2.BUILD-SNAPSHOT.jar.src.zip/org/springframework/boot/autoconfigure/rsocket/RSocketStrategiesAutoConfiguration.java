/*    */ package org.springframework.boot.autoconfigure.rsocket;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonFactory;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.dataformat.cbor.CBORFactory;
/*    */ import io.netty.buffer.PooledByteBufAllocator;
/*    */ import io.rsocket.RSocketFactory;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*    */ import org.springframework.boot.rsocket.messaging.RSocketStrategiesCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.codec.Decoder;
/*    */ import org.springframework.core.codec.Encoder;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.cbor.Jackson2CborDecoder;
/*    */ import org.springframework.http.codec.cbor.Jackson2CborEncoder;
/*    */ import org.springframework.http.codec.json.Jackson2JsonDecoder;
/*    */ import org.springframework.http.codec.json.Jackson2JsonEncoder;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.messaging.rsocket.RSocketStrategies;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.RouteMatcher;
/*    */ import org.springframework.web.util.pattern.PathPatternRouteMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({RSocketFactory.class, RSocketStrategies.class, PooledByteBufAllocator.class})
/*    */ @AutoConfigureAfter({JacksonAutoConfiguration.class})
/*    */ public class RSocketStrategiesAutoConfiguration
/*    */ {
/*    */   private static final String PATHPATTERN_ROUTEMATCHER_CLASS = "org.springframework.web.util.pattern.PathPatternRouteMatcher";
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public RSocketStrategies rSocketStrategies(ObjectProvider<RSocketStrategiesCustomizer> customizers) {
/* 61 */     RSocketStrategies.Builder builder = RSocketStrategies.builder();
/* 62 */     if (ClassUtils.isPresent("org.springframework.web.util.pattern.PathPatternRouteMatcher", null)) {
/* 63 */       builder.routeMatcher((RouteMatcher)new PathPatternRouteMatcher());
/*    */     }
/* 65 */     customizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 66 */     return builder.build();
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({ObjectMapper.class, CBORFactory.class})
/*    */   protected static class JacksonCborStrategyConfiguration
/*    */   {
/* 73 */     private static final MediaType[] SUPPORTED_TYPES = new MediaType[] { MediaType.APPLICATION_CBOR };
/*    */     
/*    */     @Bean
/*    */     @Order(0)
/*    */     @ConditionalOnBean({Jackson2ObjectMapperBuilder.class})
/*    */     public RSocketStrategiesCustomizer jacksonCborRSocketStrategyCustomizer(Jackson2ObjectMapperBuilder builder) {
/* 79 */       return strategy -> {
/*    */           ObjectMapper objectMapper = builder.createXmlMapper(false).factory((JsonFactory)new CBORFactory()).build();
/*    */           strategy.decoder(new Decoder[] { (Decoder)new Jackson2CborDecoder(objectMapper, (MimeType[])SUPPORTED_TYPES) });
/*    */           strategy.encoder(new Encoder[] { (Encoder)new Jackson2CborEncoder(objectMapper, (MimeType[])SUPPORTED_TYPES) });
/*    */         };
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({ObjectMapper.class})
/*    */   protected static class JacksonJsonStrategyConfiguration
/*    */   {
/* 92 */     private static final MediaType[] SUPPORTED_TYPES = new MediaType[] { MediaType.APPLICATION_JSON, new MediaType("application", "*+json") };
/*    */ 
/*    */     
/*    */     @Bean
/*    */     @Order(1)
/*    */     @ConditionalOnBean({ObjectMapper.class})
/*    */     public RSocketStrategiesCustomizer jacksonJsonRSocketStrategyCustomizer(ObjectMapper objectMapper) {
/* 99 */       return strategy -> {
/*    */           strategy.decoder(new Decoder[] { (Decoder)new Jackson2JsonDecoder(objectMapper, (MimeType[])SUPPORTED_TYPES) });
/*    */           strategy.encoder(new Encoder[] { (Encoder)new Jackson2JsonEncoder(objectMapper, (MimeType[])SUPPORTED_TYPES) });
/*    */         };
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketStrategiesAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
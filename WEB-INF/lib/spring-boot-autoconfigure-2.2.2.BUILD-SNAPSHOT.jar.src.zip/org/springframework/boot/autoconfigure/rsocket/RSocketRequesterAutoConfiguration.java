/*    */ package org.springframework.boot.autoconfigure.rsocket;
/*    */ 
/*    */ import io.rsocket.RSocketFactory;
/*    */ import io.rsocket.transport.netty.server.TcpServerTransport;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Scope;
/*    */ import org.springframework.messaging.rsocket.RSocketRequester;
/*    */ import org.springframework.messaging.rsocket.RSocketStrategies;
/*    */ import reactor.netty.http.server.HttpServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({RSocketRequester.class, RSocketFactory.class, HttpServer.class, TcpServerTransport.class})
/*    */ @AutoConfigureAfter({RSocketStrategiesAutoConfiguration.class})
/*    */ public class RSocketRequesterAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Scope("prototype")
/*    */   @ConditionalOnMissingBean
/*    */   public RSocketRequester.Builder rSocketRequesterBuilder(RSocketStrategies strategies) {
/* 52 */     return RSocketRequester.builder().rsocketStrategies(strategies);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketRequesterAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
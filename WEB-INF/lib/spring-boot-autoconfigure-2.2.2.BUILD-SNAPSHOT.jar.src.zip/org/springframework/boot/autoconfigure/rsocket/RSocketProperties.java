/*    */ package org.springframework.boot.autoconfigure.rsocket;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.boot.rsocket.server.RSocketServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.rsocket")
/*    */ public class RSocketProperties
/*    */ {
/* 33 */   private final Server server = new Server();
/*    */   
/*    */   public Server getServer() {
/* 36 */     return this.server;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Server
/*    */   {
/*    */     private Integer port;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     private InetAddress address;
/*    */ 
/*    */ 
/*    */     
/* 54 */     private RSocketServer.Transport transport = RSocketServer.Transport.TCP;
/*    */ 
/*    */ 
/*    */     
/*    */     private String mappingPath;
/*    */ 
/*    */ 
/*    */     
/*    */     public Integer getPort() {
/* 63 */       return this.port;
/*    */     }
/*    */     
/*    */     public void setPort(Integer port) {
/* 67 */       this.port = port;
/*    */     }
/*    */     
/*    */     public InetAddress getAddress() {
/* 71 */       return this.address;
/*    */     }
/*    */     
/*    */     public void setAddress(InetAddress address) {
/* 75 */       this.address = address;
/*    */     }
/*    */     
/*    */     public RSocketServer.Transport getTransport() {
/* 79 */       return this.transport;
/*    */     }
/*    */     
/*    */     public void setTransport(RSocketServer.Transport transport) {
/* 83 */       this.transport = transport;
/*    */     }
/*    */     
/*    */     public String getMappingPath() {
/* 87 */       return this.mappingPath;
/*    */     }
/*    */     
/*    */     public void setMappingPath(String mappingPath) {
/* 91 */       this.mappingPath = mappingPath;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
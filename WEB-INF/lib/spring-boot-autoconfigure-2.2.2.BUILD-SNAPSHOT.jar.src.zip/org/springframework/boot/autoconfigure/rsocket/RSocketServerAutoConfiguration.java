/*     */ package org.springframework.boot.autoconfigure.rsocket;
/*     */ 
/*     */ import io.rsocket.RSocketFactory;
/*     */ import io.rsocket.frame.decoder.PayloadDecoder;
/*     */ import io.rsocket.transport.netty.server.TcpServerTransport;
/*     */ import java.util.Collection;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.AllNestedConditions;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.rsocket.context.RSocketServerBootstrap;
/*     */ import org.springframework.boot.rsocket.netty.NettyRSocketServerFactory;
/*     */ import org.springframework.boot.rsocket.server.RSocketServerFactory;
/*     */ import org.springframework.boot.rsocket.server.ServerRSocketFactoryProcessor;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.http.client.reactive.ReactorResourceFactory;
/*     */ import org.springframework.messaging.rsocket.RSocketStrategies;
/*     */ import org.springframework.messaging.rsocket.annotation.support.RSocketMessageHandler;
/*     */ import reactor.netty.http.server.HttpServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({RSocketFactory.class, RSocketStrategies.class, HttpServer.class, TcpServerTransport.class})
/*     */ @ConditionalOnBean({RSocketMessageHandler.class})
/*     */ @AutoConfigureAfter({RSocketStrategiesAutoConfiguration.class})
/*     */ @EnableConfigurationProperties({RSocketProperties.class})
/*     */ public class RSocketServerAutoConfiguration
/*     */ {
/*     */   @Conditional({OnRSocketWebServerCondition.class})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class WebFluxServerAutoConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RSocketWebSocketNettyRouteProvider rSocketWebsocketRouteProvider(RSocketProperties properties, RSocketMessageHandler messageHandler, ObjectProvider<ServerRSocketFactoryProcessor> processors) {
/*  74 */       return new RSocketWebSocketNettyRouteProvider(properties.getServer().getMappingPath(), messageHandler
/*  75 */           .responder(), processors.orderedStream());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @ConditionalOnProperty(prefix = "spring.rsocket.server", name = {"port"})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class EmbeddedServerAutoConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ReactorResourceFactory reactorResourceFactory() {
/*  87 */       return new ReactorResourceFactory();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RSocketServerFactory rSocketServerFactory(RSocketProperties properties, ReactorResourceFactory resourceFactory, ObjectProvider<ServerRSocketFactoryProcessor> processors) {
/*  94 */       NettyRSocketServerFactory factory = new NettyRSocketServerFactory();
/*  95 */       factory.setResourceFactory(resourceFactory);
/*  96 */       factory.setTransport(properties.getServer().getTransport());
/*  97 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  98 */       map.from(properties.getServer().getAddress()).to(factory::setAddress);
/*  99 */       map.from(properties.getServer().getPort()).to(factory::setPort);
/* 100 */       factory.setSocketFactoryProcessors((Collection)processors.orderedStream().collect(Collectors.toList()));
/* 101 */       return (RSocketServerFactory)factory;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RSocketServerBootstrap rSocketServerBootstrap(RSocketServerFactory rSocketServerFactory, RSocketMessageHandler rSocketMessageHandler) {
/* 108 */       return new RSocketServerBootstrap(rSocketServerFactory, rSocketMessageHandler.responder());
/*     */     }
/*     */     
/*     */     @Bean
/*     */     ServerRSocketFactoryProcessor frameDecoderServerFactoryCustomizer(RSocketMessageHandler rSocketMessageHandler) {
/* 113 */       return serverRSocketFactory -> (rSocketMessageHandler.getRSocketStrategies().dataBufferFactory() instanceof org.springframework.core.io.buffer.NettyDataBufferFactory) ? serverRSocketFactory.frameDecoder(PayloadDecoder.ZERO_COPY) : serverRSocketFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class OnRSocketWebServerCondition
/*     */     extends AllNestedConditions
/*     */   {
/*     */     OnRSocketWebServerCondition() {
/* 127 */       super(ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION);
/*     */     }
/*     */     
/*     */     @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*     */     static class IsReactiveWebApplication {}
/*     */     
/*     */     @ConditionalOnProperty(prefix = "spring.rsocket.server", name = {"port"}, matchIfMissing = true)
/*     */     static class HasNoPortConfigured {}
/*     */     
/*     */     @ConditionalOnProperty(prefix = "spring.rsocket.server", name = {"mapping-path"})
/*     */     static class HasMappingPathConfigured {}
/*     */     
/*     */     @ConditionalOnProperty(prefix = "spring.rsocket.server", name = {"transport"}, havingValue = "websocket")
/*     */     static class HasWebsocketTransportConfigured {}
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketServerAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
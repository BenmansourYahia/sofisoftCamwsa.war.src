/*    */ package org.springframework.boot.autoconfigure.rsocket;
/*    */ 
/*    */ import io.rsocket.RSocketFactory;
/*    */ import io.rsocket.transport.netty.server.TcpServerTransport;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.messaging.rsocket.RSocketRequester;
/*    */ import org.springframework.messaging.rsocket.RSocketStrategies;
/*    */ import org.springframework.messaging.rsocket.annotation.support.RSocketMessageHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({RSocketRequester.class, RSocketFactory.class, TcpServerTransport.class})
/*    */ @AutoConfigureAfter({RSocketStrategiesAutoConfiguration.class})
/*    */ public class RSocketMessagingAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public RSocketMessageHandler messageHandler(RSocketStrategies rSocketStrategies) {
/* 47 */     RSocketMessageHandler messageHandler = new RSocketMessageHandler();
/* 48 */     messageHandler.setRSocketStrategies(rSocketStrategies);
/* 49 */     return messageHandler;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketMessagingAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
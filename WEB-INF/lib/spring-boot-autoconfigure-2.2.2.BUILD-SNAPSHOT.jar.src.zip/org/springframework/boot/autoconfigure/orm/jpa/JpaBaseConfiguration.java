/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.persistence.EntityManagerFactory;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.ConditionalOnMissingFilterBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ import org.springframework.orm.jpa.JpaTransactionManager;
/*     */ import org.springframework.orm.jpa.JpaVendorAdapter;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
/*     */ import org.springframework.orm.jpa.support.OpenEntityManagerInViewFilter;
/*     */ import org.springframework.orm.jpa.support.OpenEntityManagerInViewInterceptor;
/*     */ import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({JpaProperties.class})
/*     */ @Import({DataSourceInitializedPublisher.Registrar.class})
/*     */ public abstract class JpaBaseConfiguration
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private final DataSource dataSource;
/*     */   private final JpaProperties properties;
/*     */   private final JtaTransactionManager jtaTransactionManager;
/*     */   private ConfigurableListableBeanFactory beanFactory;
/*     */   
/*     */   protected JpaBaseConfiguration(DataSource dataSource, JpaProperties properties, ObjectProvider<JtaTransactionManager> jtaTransactionManager) {
/*  89 */     this.dataSource = dataSource;
/*  90 */     this.properties = properties;
/*  91 */     this.jtaTransactionManager = (JtaTransactionManager)jtaTransactionManager.getIfAvailable();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public PlatformTransactionManager transactionManager(ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
/*  98 */     JpaTransactionManager transactionManager = new JpaTransactionManager();
/*  99 */     transactionManagerCustomizers.ifAvailable(customizers -> customizers.customize((PlatformTransactionManager)transactionManager));
/* 100 */     return (PlatformTransactionManager)transactionManager;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public JpaVendorAdapter jpaVendorAdapter() {
/* 106 */     AbstractJpaVendorAdapter adapter = createJpaVendorAdapter();
/* 107 */     adapter.setShowSql(this.properties.isShowSql());
/* 108 */     if (this.properties.getDatabase() != null) {
/* 109 */       adapter.setDatabase(this.properties.getDatabase());
/*     */     }
/* 111 */     if (this.properties.getDatabasePlatform() != null) {
/* 112 */       adapter.setDatabasePlatform(this.properties.getDatabasePlatform());
/*     */     }
/* 114 */     adapter.setGenerateDdl(this.properties.isGenerateDdl());
/* 115 */     return (JpaVendorAdapter)adapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public EntityManagerFactoryBuilder entityManagerFactoryBuilder(JpaVendorAdapter jpaVendorAdapter, ObjectProvider<PersistenceUnitManager> persistenceUnitManager, ObjectProvider<EntityManagerFactoryBuilderCustomizer> customizers) {
/* 124 */     EntityManagerFactoryBuilder builder = new EntityManagerFactoryBuilder(jpaVendorAdapter, this.properties.getProperties(), (PersistenceUnitManager)persistenceUnitManager.getIfAvailable());
/* 125 */     customizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 126 */     return builder;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Primary
/*     */   @ConditionalOnMissingBean({LocalContainerEntityManagerFactoryBean.class, EntityManagerFactory.class})
/*     */   public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder factoryBuilder) {
/* 133 */     Map<String, Object> vendorProperties = getVendorProperties();
/* 134 */     customizeVendorProperties(vendorProperties);
/* 135 */     return factoryBuilder.dataSource(this.dataSource).packages(getPackagesToScan()).properties(vendorProperties)
/* 136 */       .mappingResources(getMappingResources()).jta(isJta()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customizeVendorProperties(Map<String, Object> vendorProperties) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getPackagesToScan() {
/* 152 */     List<String> packages = EntityScanPackages.get((BeanFactory)this.beanFactory).getPackageNames();
/* 153 */     if (packages.isEmpty() && AutoConfigurationPackages.has((BeanFactory)this.beanFactory)) {
/* 154 */       packages = AutoConfigurationPackages.get((BeanFactory)this.beanFactory);
/*     */     }
/* 156 */     return StringUtils.toStringArray(packages);
/*     */   }
/*     */   
/*     */   private String[] getMappingResources() {
/* 160 */     List<String> mappingResources = this.properties.getMappingResources();
/* 161 */     return !ObjectUtils.isEmpty(mappingResources) ? StringUtils.toStringArray(mappingResources) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JtaTransactionManager getJtaTransactionManager() {
/* 169 */     return this.jtaTransactionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isJta() {
/* 177 */     return (this.jtaTransactionManager != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JpaProperties getProperties() {
/* 185 */     return this.properties;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract AbstractJpaVendorAdapter createJpaVendorAdapter();
/*     */ 
/*     */   
/*     */   protected final DataSource getDataSource() {
/* 193 */     return this.dataSource;
/*     */   }
/*     */   protected abstract Map<String, Object> getVendorProperties();
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 198 */     this.beanFactory = (ConfigurableListableBeanFactory)beanFactory;
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */   @ConditionalOnClass({WebMvcConfigurer.class})
/*     */   @ConditionalOnMissingBean({OpenEntityManagerInViewInterceptor.class, OpenEntityManagerInViewFilter.class})
/*     */   @ConditionalOnMissingFilterBean({OpenEntityManagerInViewFilter.class})
/*     */   @ConditionalOnProperty(prefix = "spring.jpa", name = {"open-in-view"}, havingValue = "true", matchIfMissing = true)
/*     */   protected static class JpaWebConfiguration
/*     */   {
/* 209 */     private static final Log logger = LogFactory.getLog(JpaWebConfiguration.class);
/*     */     
/*     */     private final JpaProperties jpaProperties;
/*     */     
/*     */     protected JpaWebConfiguration(JpaProperties jpaProperties) {
/* 214 */       this.jpaProperties = jpaProperties;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public OpenEntityManagerInViewInterceptor openEntityManagerInViewInterceptor() {
/* 219 */       if (this.jpaProperties.getOpenInView() == null) {
/* 220 */         logger.warn("spring.jpa.open-in-view is enabled by default. Therefore, database queries may be performed during view rendering. Explicitly configure spring.jpa.open-in-view to disable this warning");
/*     */       }
/*     */ 
/*     */       
/* 224 */       return new OpenEntityManagerInViewInterceptor();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public WebMvcConfigurer openEntityManagerInViewInterceptorConfigurer(final OpenEntityManagerInViewInterceptor interceptor) {
/* 230 */       return new WebMvcConfigurer()
/*     */         {
/*     */           public void addInterceptors(InterceptorRegistry registry)
/*     */           {
/* 234 */             registry.addWebRequestInterceptor((WebRequestInterceptor)interceptor);
/*     */           }
/*     */         };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\orm\jpa\JpaBaseConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
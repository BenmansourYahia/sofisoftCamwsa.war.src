/*    */ package org.springframework.boot.autoconfigure.orm.jpa;
/*    */ 
/*    */ import java.util.stream.StreamSupport;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*    */ import org.springframework.boot.jdbc.SchemaManagement;
/*    */ import org.springframework.boot.jdbc.SchemaManagementProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HibernateDefaultDdlAutoProvider
/*    */   implements SchemaManagementProvider
/*    */ {
/*    */   private final Iterable<SchemaManagementProvider> providers;
/*    */   
/*    */   HibernateDefaultDdlAutoProvider(Iterable<SchemaManagementProvider> providers) {
/* 38 */     this.providers = providers;
/*    */   }
/*    */   
/*    */   String getDefaultDdlAuto(DataSource dataSource) {
/* 42 */     if (!EmbeddedDatabaseConnection.isEmbedded(dataSource)) {
/* 43 */       return "none";
/*    */     }
/* 45 */     SchemaManagement schemaManagement = getSchemaManagement(dataSource);
/* 46 */     if (SchemaManagement.MANAGED.equals(schemaManagement)) {
/* 47 */       return "none";
/*    */     }
/* 49 */     return "create-drop";
/*    */   }
/*    */ 
/*    */   
/*    */   public SchemaManagement getSchemaManagement(DataSource dataSource) {
/* 54 */     return StreamSupport.stream(this.providers.spliterator(), false)
/* 55 */       .map(provider -> provider.getSchemaManagement(dataSource)).filter(SchemaManagement.MANAGED::equals)
/* 56 */       .findFirst().orElse(SchemaManagement.UNMANAGED);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\orm\jpa\HibernateDefaultDdlAutoProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
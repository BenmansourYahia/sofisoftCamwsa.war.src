/*    */ package org.springframework.boot.autoconfigure.orm.jpa;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HibernateSettings
/*    */ {
/*    */   private Supplier<String> ddlAuto;
/*    */   private Collection<HibernatePropertiesCustomizer> hibernatePropertiesCustomizers;
/*    */   
/*    */   public HibernateSettings ddlAuto(Supplier<String> ddlAuto) {
/* 36 */     this.ddlAuto = ddlAuto;
/* 37 */     return this;
/*    */   }
/*    */   
/*    */   public String getDdlAuto() {
/* 41 */     return (this.ddlAuto != null) ? this.ddlAuto.get() : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public HibernateSettings hibernatePropertiesCustomizers(Collection<HibernatePropertiesCustomizer> hibernatePropertiesCustomizers) {
/* 46 */     this.hibernatePropertiesCustomizers = new ArrayList<>(hibernatePropertiesCustomizers);
/* 47 */     return this;
/*    */   }
/*    */   
/*    */   public Collection<HibernatePropertiesCustomizer> getHibernatePropertiesCustomizers() {
/* 51 */     return this.hibernatePropertiesCustomizers;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\orm\jpa\HibernateSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import javax.persistence.EntityManager;
/*     */ import javax.persistence.EntityManagerFactory;
/*     */ import javax.persistence.spi.PersistenceProvider;
/*     */ import javax.persistence.spi.PersistenceUnitInfo;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceSchemaCreatedEvent;
/*     */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.orm.jpa.JpaDialect;
/*     */ import org.springframework.orm.jpa.JpaVendorAdapter;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataSourceInitializedPublisher
/*     */   implements BeanPostProcessor
/*     */ {
/*     */   @Autowired
/*     */   private ApplicationContext applicationContext;
/*     */   private DataSource dataSource;
/*     */   private JpaProperties jpaProperties;
/*     */   private HibernateProperties hibernateProperties;
/*     */   private DataSourceSchemaCreatedPublisher schemaCreatedPublisher;
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/*  65 */     if (bean instanceof LocalContainerEntityManagerFactoryBean) {
/*  66 */       LocalContainerEntityManagerFactoryBean factory = (LocalContainerEntityManagerFactoryBean)bean;
/*  67 */       if (factory.getBootstrapExecutor() != null && factory.getJpaVendorAdapter() != null) {
/*  68 */         this.schemaCreatedPublisher = new DataSourceSchemaCreatedPublisher(factory);
/*  69 */         factory.setJpaVendorAdapter(this.schemaCreatedPublisher);
/*     */       } 
/*     */     } 
/*  72 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
/*  77 */     if (bean instanceof DataSource)
/*     */     {
/*  79 */       this.dataSource = (DataSource)bean;
/*     */     }
/*  81 */     if (bean instanceof JpaProperties) {
/*  82 */       this.jpaProperties = (JpaProperties)bean;
/*     */     }
/*  84 */     if (bean instanceof HibernateProperties) {
/*  85 */       this.hibernateProperties = (HibernateProperties)bean;
/*     */     }
/*  87 */     if (bean instanceof LocalContainerEntityManagerFactoryBean && this.schemaCreatedPublisher == null) {
/*  88 */       LocalContainerEntityManagerFactoryBean factoryBean = (LocalContainerEntityManagerFactoryBean)bean;
/*  89 */       EntityManagerFactory entityManagerFactory = factoryBean.getNativeEntityManagerFactory();
/*  90 */       publishEventIfRequired(factoryBean, entityManagerFactory);
/*     */     } 
/*  92 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   private void publishEventIfRequired(LocalContainerEntityManagerFactoryBean factoryBean, EntityManagerFactory entityManagerFactory) {
/*  97 */     DataSource dataSource = findDataSource(factoryBean, entityManagerFactory);
/*  98 */     if (dataSource != null && isInitializingDatabase(dataSource)) {
/*  99 */       this.applicationContext.publishEvent((ApplicationEvent)new DataSourceSchemaCreatedEvent(dataSource));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private DataSource findDataSource(LocalContainerEntityManagerFactoryBean factoryBean, EntityManagerFactory entityManagerFactory) {
/* 105 */     Object dataSource = entityManagerFactory.getProperties().get("javax.persistence.nonJtaDataSource");
/* 106 */     if (dataSource == null) {
/* 107 */       dataSource = factoryBean.getPersistenceUnitInfo().getNonJtaDataSource();
/*     */     }
/* 109 */     return (dataSource instanceof DataSource) ? (DataSource)dataSource : this.dataSource;
/*     */   }
/*     */   
/*     */   private boolean isInitializingDatabase(DataSource dataSource) {
/* 113 */     if (this.jpaProperties == null || this.hibernateProperties == null) {
/* 114 */       return true;
/*     */     }
/* 116 */     Supplier<String> defaultDdlAuto = () -> EmbeddedDatabaseConnection.isEmbedded(dataSource) ? "create-drop" : "none";
/*     */     
/* 118 */     Map<String, Object> hibernate = this.hibernateProperties.determineHibernateProperties(this.jpaProperties
/* 119 */         .getProperties(), (new HibernateSettings()).ddlAuto(defaultDdlAuto));
/* 120 */     return hibernate.containsKey("hibernate.hbm2ddl.auto");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Registrar
/*     */     implements ImportBeanDefinitionRegistrar
/*     */   {
/*     */     private static final String BEAN_NAME = "dataSourceInitializedPublisher";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 135 */       if (!registry.containsBeanDefinition("dataSourceInitializedPublisher")) {
/* 136 */         GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 137 */         beanDefinition.setBeanClass(DataSourceInitializedPublisher.class);
/* 138 */         beanDefinition.setRole(2);
/*     */ 
/*     */         
/* 141 */         beanDefinition.setSynthetic(true);
/* 142 */         registry.registerBeanDefinition("dataSourceInitializedPublisher", (BeanDefinition)beanDefinition);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final class DataSourceSchemaCreatedPublisher
/*     */     implements JpaVendorAdapter
/*     */   {
/*     */     private final LocalContainerEntityManagerFactoryBean factoryBean;
/*     */     private final JpaVendorAdapter delegate;
/*     */     
/*     */     private DataSourceSchemaCreatedPublisher(LocalContainerEntityManagerFactoryBean factoryBean) {
/* 155 */       this.factoryBean = factoryBean;
/* 156 */       this.delegate = factoryBean.getJpaVendorAdapter();
/*     */     }
/*     */ 
/*     */     
/*     */     public PersistenceProvider getPersistenceProvider() {
/* 161 */       return this.delegate.getPersistenceProvider();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPersistenceProviderRootPackage() {
/* 166 */       return this.delegate.getPersistenceProviderRootPackage();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, ?> getJpaPropertyMap(PersistenceUnitInfo pui) {
/* 171 */       return this.delegate.getJpaPropertyMap(pui);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, ?> getJpaPropertyMap() {
/* 176 */       return this.delegate.getJpaPropertyMap();
/*     */     }
/*     */ 
/*     */     
/*     */     public JpaDialect getJpaDialect() {
/* 181 */       return this.delegate.getJpaDialect();
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<? extends EntityManagerFactory> getEntityManagerFactoryInterface() {
/* 186 */       return this.delegate.getEntityManagerFactoryInterface();
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<? extends EntityManager> getEntityManagerInterface() {
/* 191 */       return this.delegate.getEntityManagerInterface();
/*     */     }
/*     */ 
/*     */     
/*     */     public void postProcessEntityManagerFactory(EntityManagerFactory entityManagerFactory) {
/* 196 */       this.delegate.postProcessEntityManagerFactory(entityManagerFactory);
/* 197 */       AsyncTaskExecutor bootstrapExecutor = this.factoryBean.getBootstrapExecutor();
/* 198 */       if (bootstrapExecutor != null)
/* 199 */         bootstrapExecutor.execute(() -> DataSourceInitializedPublisher.this.publishEventIfRequired(this.factoryBean, entityManagerFactory)); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\orm\jpa\DataSourceInitializedPublisher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
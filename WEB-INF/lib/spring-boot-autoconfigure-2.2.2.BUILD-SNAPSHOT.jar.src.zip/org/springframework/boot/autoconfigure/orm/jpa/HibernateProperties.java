/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.orm.jpa.hibernate.SpringImplicitNamingStrategy;
/*     */ import org.springframework.boot.orm.jpa.hibernate.SpringPhysicalNamingStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.jpa.hibernate")
/*     */ public class HibernateProperties
/*     */ {
/*     */   private static final String DISABLED_SCANNER_CLASS = "org.hibernate.boot.archive.scan.internal.DisabledScanner";
/*  46 */   private final Naming naming = new Naming();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String ddlAuto;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean useNewIdGeneratorMappings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDdlAuto() {
/*  63 */     return this.ddlAuto;
/*     */   }
/*     */   
/*     */   public void setDdlAuto(String ddlAuto) {
/*  67 */     this.ddlAuto = ddlAuto;
/*     */   }
/*     */   
/*     */   public Boolean isUseNewIdGeneratorMappings() {
/*  71 */     return this.useNewIdGeneratorMappings;
/*     */   }
/*     */   
/*     */   public void setUseNewIdGeneratorMappings(Boolean useNewIdGeneratorMappings) {
/*  75 */     this.useNewIdGeneratorMappings = useNewIdGeneratorMappings;
/*     */   }
/*     */   
/*     */   public Naming getNaming() {
/*  79 */     return this.naming;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> determineHibernateProperties(Map<String, String> jpaProperties, HibernateSettings settings) {
/*  92 */     Assert.notNull(jpaProperties, "JpaProperties must not be null");
/*  93 */     Assert.notNull(settings, "Settings must not be null");
/*  94 */     return getAdditionalProperties(jpaProperties, settings);
/*     */   }
/*     */   
/*     */   private Map<String, Object> getAdditionalProperties(Map<String, String> existing, HibernateSettings settings) {
/*  98 */     Map<String, Object> result = new HashMap<>(existing);
/*  99 */     applyNewIdGeneratorMappings(result);
/* 100 */     applyScanner(result);
/* 101 */     getNaming().applyNamingStrategies(result);
/* 102 */     String ddlAuto = determineDdlAuto(existing, settings::getDdlAuto);
/* 103 */     if (StringUtils.hasText(ddlAuto) && !"none".equals(ddlAuto)) {
/* 104 */       result.put("hibernate.hbm2ddl.auto", ddlAuto);
/*     */     } else {
/*     */       
/* 107 */       result.remove("hibernate.hbm2ddl.auto");
/*     */     } 
/* 109 */     Collection<HibernatePropertiesCustomizer> customizers = settings.getHibernatePropertiesCustomizers();
/* 110 */     if (!ObjectUtils.isEmpty(customizers)) {
/* 111 */       customizers.forEach(customizer -> customizer.customize(result));
/*     */     }
/* 113 */     return result;
/*     */   }
/*     */   
/*     */   private void applyNewIdGeneratorMappings(Map<String, Object> result) {
/* 117 */     if (this.useNewIdGeneratorMappings != null) {
/* 118 */       result.put("hibernate.id.new_generator_mappings", this.useNewIdGeneratorMappings.toString());
/*     */     }
/* 120 */     else if (!result.containsKey("hibernate.id.new_generator_mappings")) {
/* 121 */       result.put("hibernate.id.new_generator_mappings", "true");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void applyScanner(Map<String, Object> result) {
/* 126 */     if (!result.containsKey("hibernate.archive.scanner") && ClassUtils.isPresent("org.hibernate.boot.archive.scan.internal.DisabledScanner", null)) {
/* 127 */       result.put("hibernate.archive.scanner", "org.hibernate.boot.archive.scan.internal.DisabledScanner");
/*     */     }
/*     */   }
/*     */   
/*     */   private String determineDdlAuto(Map<String, String> existing, Supplier<String> defaultDdlAuto) {
/* 132 */     String ddlAuto = existing.get("hibernate.hbm2ddl.auto");
/* 133 */     if (ddlAuto != null) {
/* 134 */       return ddlAuto;
/*     */     }
/* 136 */     return (this.ddlAuto != null) ? this.ddlAuto : defaultDdlAuto.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Naming
/*     */   {
/*     */     private String implicitStrategy;
/*     */ 
/*     */     
/*     */     private String physicalStrategy;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getImplicitStrategy() {
/* 152 */       return this.implicitStrategy;
/*     */     }
/*     */     
/*     */     public void setImplicitStrategy(String implicitStrategy) {
/* 156 */       this.implicitStrategy = implicitStrategy;
/*     */     }
/*     */     
/*     */     public String getPhysicalStrategy() {
/* 160 */       return this.physicalStrategy;
/*     */     }
/*     */     
/*     */     public void setPhysicalStrategy(String physicalStrategy) {
/* 164 */       this.physicalStrategy = physicalStrategy;
/*     */     }
/*     */     
/*     */     private void applyNamingStrategies(Map<String, Object> properties) {
/* 168 */       applyNamingStrategy(properties, "hibernate.implicit_naming_strategy", this.implicitStrategy, SpringImplicitNamingStrategy.class
/* 169 */           .getName());
/* 170 */       applyNamingStrategy(properties, "hibernate.physical_naming_strategy", this.physicalStrategy, SpringPhysicalNamingStrategy.class
/* 171 */           .getName());
/*     */     }
/*     */ 
/*     */     
/*     */     private void applyNamingStrategy(Map<String, Object> properties, String key, Object strategy, Object defaultStrategy) {
/* 176 */       if (strategy != null) {
/* 177 */         properties.put(key, strategy);
/*     */       }
/* 179 */       else if (defaultStrategy != null && !properties.containsKey(key)) {
/* 180 */         properties.put(key, defaultStrategy);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\orm\jpa\HibernateProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
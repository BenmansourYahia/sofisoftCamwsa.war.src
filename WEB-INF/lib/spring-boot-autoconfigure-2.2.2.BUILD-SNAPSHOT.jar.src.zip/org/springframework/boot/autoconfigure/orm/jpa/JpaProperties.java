/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.orm.jpa.vendor.Database;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.jpa")
/*     */ public class JpaProperties
/*     */ {
/*  45 */   private Map<String, String> properties = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final List<String> mappingResources = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String databasePlatform;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Database database;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean generateDdl = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean showSql = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean openInView;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getProperties() {
/*  81 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Map<String, String> properties) {
/*  85 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   public List<String> getMappingResources() {
/*  89 */     return this.mappingResources;
/*     */   }
/*     */   
/*     */   public String getDatabasePlatform() {
/*  93 */     return this.databasePlatform;
/*     */   }
/*     */   
/*     */   public void setDatabasePlatform(String databasePlatform) {
/*  97 */     this.databasePlatform = databasePlatform;
/*     */   }
/*     */   
/*     */   public Database getDatabase() {
/* 101 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(Database database) {
/* 105 */     this.database = database;
/*     */   }
/*     */   
/*     */   public boolean isGenerateDdl() {
/* 109 */     return this.generateDdl;
/*     */   }
/*     */   
/*     */   public void setGenerateDdl(boolean generateDdl) {
/* 113 */     this.generateDdl = generateDdl;
/*     */   }
/*     */   
/*     */   public boolean isShowSql() {
/* 117 */     return this.showSql;
/*     */   }
/*     */   
/*     */   public void setShowSql(boolean showSql) {
/* 121 */     this.showSql = showSql;
/*     */   }
/*     */   
/*     */   public Boolean getOpenInView() {
/* 125 */     return this.openInView;
/*     */   }
/*     */   
/*     */   public void setOpenInView(Boolean openInView) {
/* 129 */     this.openInView = openInView;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Database determineDatabase(DataSource dataSource) {
/* 142 */     if (this.database != null) {
/* 143 */       return this.database;
/*     */     }
/* 145 */     return DatabaseLookup.getDatabase(dataSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\orm\jpa\JpaProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
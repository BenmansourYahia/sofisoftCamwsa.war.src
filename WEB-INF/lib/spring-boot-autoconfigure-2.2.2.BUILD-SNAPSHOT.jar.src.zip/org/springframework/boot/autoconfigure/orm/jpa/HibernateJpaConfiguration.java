/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.boot.model.naming.ImplicitNamingStrategy;
/*     */ import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.SchemaManagementProvider;
/*     */ import org.springframework.boot.jdbc.metadata.CompositeDataSourcePoolMetadataProvider;
/*     */ import org.springframework.boot.jdbc.metadata.DataSourcePoolMetadata;
/*     */ import org.springframework.boot.jdbc.metadata.DataSourcePoolMetadataProvider;
/*     */ import org.springframework.boot.orm.jpa.hibernate.SpringJtaPlatform;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.jndi.JndiLocatorDelegate;
/*     */ import org.springframework.orm.hibernate5.SpringBeanContainer;
/*     */ import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
/*     */ import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({HibernateProperties.class})
/*     */ @ConditionalOnSingleCandidate(DataSource.class)
/*     */ class HibernateJpaConfiguration
/*     */   extends JpaBaseConfiguration
/*     */ {
/*  67 */   private static final Log logger = LogFactory.getLog(HibernateJpaConfiguration.class);
/*     */ 
/*     */   
/*     */   private static final String JTA_PLATFORM = "hibernate.transaction.jta.platform";
/*     */ 
/*     */   
/*     */   private static final String PROVIDER_DISABLES_AUTOCOMMIT = "hibernate.connection.provider_disables_autocommit";
/*     */ 
/*     */   
/*  76 */   private static final String[] NO_JTA_PLATFORM_CLASSES = new String[] { "org.hibernate.engine.transaction.jta.platform.internal.NoJtaPlatform", "org.hibernate.service.jta.platform.internal.NoJtaPlatform" };
/*     */ 
/*     */ 
/*     */   
/*     */   private final HibernateProperties hibernateProperties;
/*     */ 
/*     */ 
/*     */   
/*     */   private final HibernateDefaultDdlAutoProvider defaultDdlAutoProvider;
/*     */ 
/*     */ 
/*     */   
/*     */   private DataSourcePoolMetadataProvider poolMetadataProvider;
/*     */ 
/*     */   
/*     */   private final List<HibernatePropertiesCustomizer> hibernatePropertiesCustomizers;
/*     */ 
/*     */ 
/*     */   
/*     */   HibernateJpaConfiguration(DataSource dataSource, JpaProperties jpaProperties, ConfigurableListableBeanFactory beanFactory, ObjectProvider<JtaTransactionManager> jtaTransactionManager, HibernateProperties hibernateProperties, ObjectProvider<Collection<DataSourcePoolMetadataProvider>> metadataProviders, ObjectProvider<SchemaManagementProvider> providers, ObjectProvider<PhysicalNamingStrategy> physicalNamingStrategy, ObjectProvider<ImplicitNamingStrategy> implicitNamingStrategy, ObjectProvider<HibernatePropertiesCustomizer> hibernatePropertiesCustomizers) {
/*  96 */     super(dataSource, jpaProperties, jtaTransactionManager);
/*  97 */     this.hibernateProperties = hibernateProperties;
/*  98 */     this.defaultDdlAutoProvider = new HibernateDefaultDdlAutoProvider((Iterable<SchemaManagementProvider>)providers);
/*  99 */     this.poolMetadataProvider = (DataSourcePoolMetadataProvider)new CompositeDataSourcePoolMetadataProvider((Collection)metadataProviders.getIfAvailable());
/* 100 */     this.hibernatePropertiesCustomizers = determineHibernatePropertiesCustomizers((PhysicalNamingStrategy)physicalNamingStrategy
/* 101 */         .getIfAvailable(), (ImplicitNamingStrategy)implicitNamingStrategy.getIfAvailable(), beanFactory, (List<HibernatePropertiesCustomizer>)hibernatePropertiesCustomizers
/* 102 */         .orderedStream().collect(Collectors.toList()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<HibernatePropertiesCustomizer> determineHibernatePropertiesCustomizers(PhysicalNamingStrategy physicalNamingStrategy, ImplicitNamingStrategy implicitNamingStrategy, ConfigurableListableBeanFactory beanFactory, List<HibernatePropertiesCustomizer> hibernatePropertiesCustomizers) {
/* 109 */     List<HibernatePropertiesCustomizer> customizers = new ArrayList<>();
/* 110 */     if (ClassUtils.isPresent("org.hibernate.resource.beans.container.spi.BeanContainer", 
/* 111 */         getClass().getClassLoader())) {
/* 112 */       customizers.add(properties -> properties.put("hibernate.resource.beans.container", new SpringBeanContainer(beanFactory)));
/*     */     }
/*     */     
/* 115 */     if (physicalNamingStrategy != null || implicitNamingStrategy != null) {
/* 116 */       customizers.add(new NamingStrategiesHibernatePropertiesCustomizer(physicalNamingStrategy, implicitNamingStrategy));
/*     */     }
/*     */     
/* 119 */     customizers.addAll(hibernatePropertiesCustomizers);
/* 120 */     return customizers;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractJpaVendorAdapter createJpaVendorAdapter() {
/* 125 */     return (AbstractJpaVendorAdapter)new HibernateJpaVendorAdapter();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<String, Object> getVendorProperties() {
/* 130 */     Supplier<String> defaultDdlMode = () -> this.defaultDdlAutoProvider.getDefaultDdlAuto(getDataSource());
/* 131 */     return new LinkedHashMap<>(this.hibernateProperties
/* 132 */         .determineHibernateProperties(getProperties().getProperties(), (new HibernateSettings())
/* 133 */           .ddlAuto(defaultDdlMode).hibernatePropertiesCustomizers(this.hibernatePropertiesCustomizers)));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void customizeVendorProperties(Map<String, Object> vendorProperties) {
/* 138 */     super.customizeVendorProperties(vendorProperties);
/* 139 */     if (!vendorProperties.containsKey("hibernate.transaction.jta.platform")) {
/* 140 */       configureJtaPlatform(vendorProperties);
/*     */     }
/* 142 */     if (!vendorProperties.containsKey("hibernate.connection.provider_disables_autocommit")) {
/* 143 */       configureProviderDisablesAutocommit(vendorProperties);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureJtaPlatform(Map<String, Object> vendorProperties) throws LinkageError {
/* 148 */     JtaTransactionManager jtaTransactionManager = getJtaTransactionManager();
/*     */     
/* 150 */     if (jtaTransactionManager == null) {
/* 151 */       vendorProperties.put("hibernate.transaction.jta.platform", getNoJtaPlatformManager());
/*     */ 
/*     */     
/*     */     }
/* 155 */     else if (!runningOnWebSphere()) {
/* 156 */       configureSpringJtaPlatform(vendorProperties, jtaTransactionManager);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configureProviderDisablesAutocommit(Map<String, Object> vendorProperties) {
/* 161 */     if (isDataSourceAutoCommitDisabled() && !isJta()) {
/* 162 */       vendorProperties.put("hibernate.connection.provider_disables_autocommit", "true");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDataSourceAutoCommitDisabled() {
/* 167 */     DataSourcePoolMetadata poolMetadata = this.poolMetadataProvider.getDataSourcePoolMetadata(getDataSource());
/* 168 */     return (poolMetadata != null && Boolean.FALSE.equals(poolMetadata.getDefaultAutoCommit()));
/*     */   }
/*     */   
/*     */   private boolean runningOnWebSphere() {
/* 172 */     return ClassUtils.isPresent("com.ibm.websphere.jtaextensions.ExtendedJTATransaction", 
/* 173 */         getClass().getClassLoader());
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureSpringJtaPlatform(Map<String, Object> vendorProperties, JtaTransactionManager jtaTransactionManager) {
/*     */     try {
/* 179 */       vendorProperties.put("hibernate.transaction.jta.platform", new SpringJtaPlatform(jtaTransactionManager));
/*     */     }
/* 181 */     catch (LinkageError ex) {
/*     */ 
/*     */       
/* 184 */       if (!isUsingJndi()) {
/* 185 */         throw new IllegalStateException("Unable to set Hibernate JTA platform, are you using the correct version of Hibernate?", ex);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 190 */       if (logger.isDebugEnabled()) {
/* 191 */         logger.debug("Unable to set Hibernate JTA platform : " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isUsingJndi() {
/*     */     try {
/* 198 */       return JndiLocatorDelegate.isDefaultJndiEnvironmentAvailable();
/*     */     }
/* 200 */     catch (Error ex) {
/* 201 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object getNoJtaPlatformManager() {
/* 206 */     for (String candidate : NO_JTA_PLATFORM_CLASSES) {
/*     */       try {
/* 208 */         return Class.forName(candidate).newInstance();
/*     */       }
/* 210 */       catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 214 */     throw new IllegalStateException("No available JtaPlatform candidates amongst " + 
/* 215 */         Arrays.toString(NO_JTA_PLATFORM_CLASSES));
/*     */   }
/*     */ 
/*     */   
/*     */   private static class NamingStrategiesHibernatePropertiesCustomizer
/*     */     implements HibernatePropertiesCustomizer
/*     */   {
/*     */     private final PhysicalNamingStrategy physicalNamingStrategy;
/*     */     private final ImplicitNamingStrategy implicitNamingStrategy;
/*     */     
/*     */     NamingStrategiesHibernatePropertiesCustomizer(PhysicalNamingStrategy physicalNamingStrategy, ImplicitNamingStrategy implicitNamingStrategy) {
/* 226 */       this.physicalNamingStrategy = physicalNamingStrategy;
/* 227 */       this.implicitNamingStrategy = implicitNamingStrategy;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(Map<String, Object> hibernateProperties) {
/* 232 */       if (this.physicalNamingStrategy != null) {
/* 233 */         hibernateProperties.put("hibernate.physical_naming_strategy", this.physicalNamingStrategy);
/*     */       }
/* 235 */       if (this.implicitNamingStrategy != null)
/* 236 */         hibernateProperties.put("hibernate.implicit_naming_strategy", this.implicitNamingStrategy); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\orm\jpa\HibernateJpaConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
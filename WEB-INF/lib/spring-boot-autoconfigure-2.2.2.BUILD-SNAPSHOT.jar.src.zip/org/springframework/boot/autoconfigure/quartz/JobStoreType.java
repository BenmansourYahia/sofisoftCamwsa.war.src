/*    */ package org.springframework.boot.autoconfigure.quartz;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JobStoreType
/*    */ {
/* 30 */   MEMORY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   JDBC;
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\quartz\JobStoreType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.quartz;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.quartz")
/*     */ public class QuartzProperties
/*     */ {
/*  42 */   private JobStoreType jobStoreType = JobStoreType.MEMORY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String schedulerName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean autoStartup = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private Duration startupDelay = Duration.ofSeconds(0L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean waitForJobsToCompleteOnShutdown = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean overwriteExistingJobs = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private final Map<String, String> properties = new HashMap<>();
/*     */   
/*  76 */   private final Jdbc jdbc = new Jdbc();
/*     */   
/*     */   public JobStoreType getJobStoreType() {
/*  79 */     return this.jobStoreType;
/*     */   }
/*     */   
/*     */   public void setJobStoreType(JobStoreType jobStoreType) {
/*  83 */     this.jobStoreType = jobStoreType;
/*     */   }
/*     */   
/*     */   public String getSchedulerName() {
/*  87 */     return this.schedulerName;
/*     */   }
/*     */   
/*     */   public void setSchedulerName(String schedulerName) {
/*  91 */     this.schedulerName = schedulerName;
/*     */   }
/*     */   
/*     */   public boolean isAutoStartup() {
/*  95 */     return this.autoStartup;
/*     */   }
/*     */   
/*     */   public void setAutoStartup(boolean autoStartup) {
/*  99 */     this.autoStartup = autoStartup;
/*     */   }
/*     */   
/*     */   public Duration getStartupDelay() {
/* 103 */     return this.startupDelay;
/*     */   }
/*     */   
/*     */   public void setStartupDelay(Duration startupDelay) {
/* 107 */     this.startupDelay = startupDelay;
/*     */   }
/*     */   
/*     */   public boolean isWaitForJobsToCompleteOnShutdown() {
/* 111 */     return this.waitForJobsToCompleteOnShutdown;
/*     */   }
/*     */   
/*     */   public void setWaitForJobsToCompleteOnShutdown(boolean waitForJobsToCompleteOnShutdown) {
/* 115 */     this.waitForJobsToCompleteOnShutdown = waitForJobsToCompleteOnShutdown;
/*     */   }
/*     */   
/*     */   public boolean isOverwriteExistingJobs() {
/* 119 */     return this.overwriteExistingJobs;
/*     */   }
/*     */   
/*     */   public void setOverwriteExistingJobs(boolean overwriteExistingJobs) {
/* 123 */     this.overwriteExistingJobs = overwriteExistingJobs;
/*     */   }
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 127 */     return this.properties;
/*     */   }
/*     */   
/*     */   public Jdbc getJdbc() {
/* 131 */     return this.jdbc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Jdbc
/*     */   {
/*     */     private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/quartz/impl/jdbcjobstore/tables_@@platform@@.sql";
/*     */ 
/*     */     
/* 142 */     private String schema = "classpath:org/quartz/impl/jdbcjobstore/tables_@@platform@@.sql";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     private DataSourceInitializationMode initializeSchema = DataSourceInitializationMode.EMBEDDED;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     private List<String> commentPrefix = new ArrayList<>(Arrays.asList(new String[] { "#", "--" }));
/*     */     
/*     */     public String getSchema() {
/* 155 */       return this.schema;
/*     */     }
/*     */     
/*     */     public void setSchema(String schema) {
/* 159 */       this.schema = schema;
/*     */     }
/*     */     
/*     */     public DataSourceInitializationMode getInitializeSchema() {
/* 163 */       return this.initializeSchema;
/*     */     }
/*     */     
/*     */     public void setInitializeSchema(DataSourceInitializationMode initializeSchema) {
/* 167 */       this.initializeSchema = initializeSchema;
/*     */     }
/*     */     
/*     */     public List<String> getCommentPrefix() {
/* 171 */       return this.commentPrefix;
/*     */     }
/*     */     
/*     */     public void setCommentPrefix(List<String> commentPrefix) {
/* 175 */       this.commentPrefix = commentPrefix;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\quartz\QuartzProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.quartz;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import liquibase.integration.spring.SpringLiquibase;
/*     */ import org.quartz.Calendar;
/*     */ import org.quartz.JobDetail;
/*     */ import org.quartz.Scheduler;
/*     */ import org.quartz.Trigger;
/*     */ import org.quartz.spi.JobFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AbstractDependsOnBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.flyway.FlywayMigrationInitializer;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.scheduling.quartz.SchedulerFactoryBean;
/*     */ import org.springframework.scheduling.quartz.SpringBeanJobFactory;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({Scheduler.class, SchedulerFactoryBean.class, PlatformTransactionManager.class})
/*     */ @EnableConfigurationProperties({QuartzProperties.class})
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class, LiquibaseAutoConfiguration.class, FlywayAutoConfiguration.class})
/*     */ public class QuartzAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public SchedulerFactoryBean quartzScheduler(QuartzProperties properties, ObjectProvider<SchedulerFactoryBeanCustomizer> customizers, ObjectProvider<JobDetail> jobDetails, Map<String, Calendar> calendars, ObjectProvider<Trigger> triggers, ApplicationContext applicationContext) {
/*  73 */     SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
/*  74 */     SpringBeanJobFactory jobFactory = new SpringBeanJobFactory();
/*  75 */     jobFactory.setApplicationContext(applicationContext);
/*  76 */     schedulerFactoryBean.setJobFactory((JobFactory)jobFactory);
/*  77 */     if (properties.getSchedulerName() != null) {
/*  78 */       schedulerFactoryBean.setSchedulerName(properties.getSchedulerName());
/*     */     }
/*  80 */     schedulerFactoryBean.setAutoStartup(properties.isAutoStartup());
/*  81 */     schedulerFactoryBean.setStartupDelay((int)properties.getStartupDelay().getSeconds());
/*  82 */     schedulerFactoryBean.setWaitForJobsToCompleteOnShutdown(properties.isWaitForJobsToCompleteOnShutdown());
/*  83 */     schedulerFactoryBean.setOverwriteExistingJobs(properties.isOverwriteExistingJobs());
/*  84 */     if (!properties.getProperties().isEmpty()) {
/*  85 */       schedulerFactoryBean.setQuartzProperties(asProperties(properties.getProperties()));
/*     */     }
/*  87 */     schedulerFactoryBean.setJobDetails((JobDetail[])jobDetails.orderedStream().toArray(x$0 -> new JobDetail[x$0]));
/*  88 */     schedulerFactoryBean.setCalendars(calendars);
/*  89 */     schedulerFactoryBean.setTriggers((Trigger[])triggers.orderedStream().toArray(x$0 -> new Trigger[x$0]));
/*  90 */     customizers.orderedStream().forEach(customizer -> customizer.customize(schedulerFactoryBean));
/*  91 */     return schedulerFactoryBean;
/*     */   }
/*     */   
/*     */   private Properties asProperties(Map<String, String> source) {
/*  95 */     Properties properties = new Properties();
/*  96 */     properties.putAll(source);
/*  97 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnSingleCandidate(DataSource.class)
/*     */   @ConditionalOnProperty(prefix = "spring.quartz", name = {"job-store-type"}, havingValue = "jdbc")
/*     */   protected static class JdbcStoreTypeConfiguration
/*     */   {
/*     */     @Bean
/*     */     @Order(0)
/*     */     public SchedulerFactoryBeanCustomizer dataSourceCustomizer(QuartzProperties properties, DataSource dataSource, @QuartzDataSource ObjectProvider<DataSource> quartzDataSource, ObjectProvider<PlatformTransactionManager> transactionManager) {
/* 110 */       return schedulerFactoryBean -> {
/*     */           DataSource dataSourceToUse = getDataSource(dataSource, quartzDataSource);
/*     */           schedulerFactoryBean.setDataSource(dataSourceToUse);
/*     */           PlatformTransactionManager txManager = (PlatformTransactionManager)transactionManager.getIfUnique();
/*     */           if (txManager != null) {
/*     */             schedulerFactoryBean.setTransactionManager(txManager);
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     private DataSource getDataSource(DataSource dataSource, ObjectProvider<DataSource> quartzDataSource) {
/* 121 */       DataSource dataSourceIfAvailable = (DataSource)quartzDataSource.getIfAvailable();
/* 122 */       return (dataSourceIfAvailable != null) ? dataSourceIfAvailable : dataSource;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public QuartzDataSourceInitializer quartzDataSourceInitializer(DataSource dataSource, @QuartzDataSource ObjectProvider<DataSource> quartzDataSource, ResourceLoader resourceLoader, QuartzProperties properties) {
/* 130 */       DataSource dataSourceToUse = getDataSource(dataSource, quartzDataSource);
/* 131 */       return new QuartzDataSourceInitializer(dataSourceToUse, resourceLoader, properties);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     static class QuartzSchedulerDependencyConfiguration
/*     */     {
/*     */       @Bean
/*     */       static QuartzAutoConfiguration.SchedulerDependsOnBeanFactoryPostProcessor quartzSchedulerDataSourceInitializerDependsOnBeanFactoryPostProcessor() {
/* 144 */         return new QuartzAutoConfiguration.SchedulerDependsOnBeanFactoryPostProcessor(new Class[] { QuartzDataSourceInitializer.class });
/*     */       }
/*     */       
/*     */       @Bean
/*     */       @ConditionalOnBean({FlywayMigrationInitializer.class})
/*     */       static QuartzAutoConfiguration.SchedulerDependsOnBeanFactoryPostProcessor quartzSchedulerFlywayDependsOnBeanFactoryPostProcessor() {
/* 150 */         return new QuartzAutoConfiguration.SchedulerDependsOnBeanFactoryPostProcessor(new Class[] { FlywayMigrationInitializer.class });
/*     */       }
/*     */       
/*     */       @Configuration(proxyBeanMethods = false)
/*     */       @ConditionalOnClass({SpringLiquibase.class})
/*     */       static class LiquibaseQuartzSchedulerDependencyConfiguration
/*     */       {
/*     */         @Bean
/*     */         @ConditionalOnBean({SpringLiquibase.class})
/*     */         static QuartzAutoConfiguration.SchedulerDependsOnBeanFactoryPostProcessor quartzSchedulerLiquibaseDependsOnBeanFactoryPostProcessor() {
/* 160 */           return new QuartzAutoConfiguration.SchedulerDependsOnBeanFactoryPostProcessor(new Class[] { SpringLiquibase.class });
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SchedulerDependsOnBeanFactoryPostProcessor
/*     */     extends AbstractDependsOnBeanFactoryPostProcessor
/*     */   {
/*     */     SchedulerDependsOnBeanFactoryPostProcessor(Class<?>... dependencyTypes) {
/* 176 */       super(Scheduler.class, SchedulerFactoryBean.class, dependencyTypes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\quartz\QuartzAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.quartz;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.jdbc.AbstractDataSourceInitializer;
/*    */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuartzDataSourceInitializer
/*    */   extends AbstractDataSourceInitializer
/*    */ {
/*    */   private final QuartzProperties properties;
/*    */   
/*    */   public QuartzDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader, QuartzProperties properties) {
/* 39 */     super(dataSource, resourceLoader);
/* 40 */     Assert.notNull(properties, "QuartzProperties must not be null");
/* 41 */     this.properties = properties;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void customize(ResourceDatabasePopulator populator) {
/* 46 */     populator.setCommentPrefixes(this.properties.getJdbc().getCommentPrefix().<String>toArray(new String[0]));
/*    */   }
/*    */ 
/*    */   
/*    */   protected DataSourceInitializationMode getMode() {
/* 51 */     return this.properties.getJdbc().getInitializeSchema();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getSchemaLocation() {
/* 56 */     return this.properties.getJdbc().getSchema();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getDatabaseName() {
/* 61 */     String databaseName = super.getDatabaseName();
/* 62 */     if ("db2".equals(databaseName)) {
/* 63 */       return "db2_v95";
/*    */     }
/* 65 */     if ("mysql".equals(databaseName)) {
/* 66 */       return "mysql_innodb";
/*    */     }
/* 68 */     if ("postgresql".equals(databaseName)) {
/* 69 */       return "postgres";
/*    */     }
/* 71 */     if ("sqlserver".equals(databaseName)) {
/* 72 */       return "sqlServer";
/*    */     }
/* 74 */     return databaseName;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\quartz\QuartzDataSourceInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.codec;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.util.unit.DataSize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.codec")
/*    */ public class CodecProperties
/*    */ {
/*    */   private DataSize maxInMemorySize;
/*    */   
/*    */   public DataSize getMaxInMemorySize() {
/* 39 */     return this.maxInMemorySize;
/*    */   }
/*    */   
/*    */   public void setMaxInMemorySize(DataSize maxInMemorySize) {
/* 43 */     this.maxInMemorySize = maxInMemorySize;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\codec\CodecProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.template;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.MimeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractViewResolverProperties
/*     */ {
/*  39 */   private static final MimeType DEFAULT_CONTENT_TYPE = MimeType.valueOf("text/html");
/*     */   
/*  41 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean cache;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private MimeType contentType = DEFAULT_CONTENT_TYPE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private Charset charset = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] viewNames;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkTemplateLocation = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  74 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  78 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setCheckTemplateLocation(boolean checkTemplateLocation) {
/*  82 */     this.checkTemplateLocation = checkTemplateLocation;
/*     */   }
/*     */   
/*     */   public boolean isCheckTemplateLocation() {
/*  86 */     return this.checkTemplateLocation;
/*     */   }
/*     */   
/*     */   public String[] getViewNames() {
/*  90 */     return this.viewNames;
/*     */   }
/*     */   
/*     */   public void setViewNames(String[] viewNames) {
/*  94 */     this.viewNames = viewNames;
/*     */   }
/*     */   
/*     */   public boolean isCache() {
/*  98 */     return this.cache;
/*     */   }
/*     */   
/*     */   public void setCache(boolean cache) {
/* 102 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public MimeType getContentType() {
/* 106 */     if (this.contentType.getCharset() == null) {
/* 107 */       Map<String, String> parameters = new LinkedHashMap<>();
/* 108 */       parameters.put("charset", this.charset.name());
/* 109 */       parameters.putAll(this.contentType.getParameters());
/* 110 */       return new MimeType(this.contentType, parameters);
/*     */     } 
/* 112 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void setContentType(MimeType contentType) {
/* 116 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */   public Charset getCharset() {
/* 120 */     return this.charset;
/*     */   }
/*     */   
/*     */   public String getCharsetName() {
/* 124 */     return (this.charset != null) ? this.charset.name() : null;
/*     */   }
/*     */   
/*     */   public void setCharset(Charset charset) {
/* 128 */     this.charset = charset;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\template\AbstractViewResolverProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
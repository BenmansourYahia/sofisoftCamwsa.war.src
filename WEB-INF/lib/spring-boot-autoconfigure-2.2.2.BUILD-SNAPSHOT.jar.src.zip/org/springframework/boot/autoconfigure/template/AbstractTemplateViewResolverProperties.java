/*     */ package org.springframework.boot.autoconfigure.template;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTemplateViewResolverProperties
/*     */   extends AbstractViewResolverProperties
/*     */ {
/*     */   private String prefix;
/*     */   private String suffix;
/*     */   private String requestContextAttribute;
/*     */   private boolean exposeRequestAttributes = false;
/*     */   private boolean exposeSessionAttributes = false;
/*     */   private boolean allowRequestOverride = false;
/*     */   private boolean exposeSpringMacroHelpers = true;
/*     */   private boolean allowSessionOverride = false;
/*     */   
/*     */   protected AbstractTemplateViewResolverProperties(String defaultPrefix, String defaultSuffix) {
/*  79 */     this.prefix = defaultPrefix;
/*  80 */     this.suffix = defaultSuffix;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  84 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/*  88 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */   public String getSuffix() {
/*  92 */     return this.suffix;
/*     */   }
/*     */   
/*     */   public void setSuffix(String suffix) {
/*  96 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */   public String getRequestContextAttribute() {
/* 100 */     return this.requestContextAttribute;
/*     */   }
/*     */   
/*     */   public void setRequestContextAttribute(String requestContextAttribute) {
/* 104 */     this.requestContextAttribute = requestContextAttribute;
/*     */   }
/*     */   
/*     */   public boolean isExposeRequestAttributes() {
/* 108 */     return this.exposeRequestAttributes;
/*     */   }
/*     */   
/*     */   public void setExposeRequestAttributes(boolean exposeRequestAttributes) {
/* 112 */     this.exposeRequestAttributes = exposeRequestAttributes;
/*     */   }
/*     */   
/*     */   public boolean isExposeSessionAttributes() {
/* 116 */     return this.exposeSessionAttributes;
/*     */   }
/*     */   
/*     */   public void setExposeSessionAttributes(boolean exposeSessionAttributes) {
/* 120 */     this.exposeSessionAttributes = exposeSessionAttributes;
/*     */   }
/*     */   
/*     */   public boolean isAllowRequestOverride() {
/* 124 */     return this.allowRequestOverride;
/*     */   }
/*     */   
/*     */   public void setAllowRequestOverride(boolean allowRequestOverride) {
/* 128 */     this.allowRequestOverride = allowRequestOverride;
/*     */   }
/*     */   
/*     */   public boolean isAllowSessionOverride() {
/* 132 */     return this.allowSessionOverride;
/*     */   }
/*     */   
/*     */   public void setAllowSessionOverride(boolean allowSessionOverride) {
/* 136 */     this.allowSessionOverride = allowSessionOverride;
/*     */   }
/*     */   
/*     */   public boolean isExposeSpringMacroHelpers() {
/* 140 */     return this.exposeSpringMacroHelpers;
/*     */   }
/*     */   
/*     */   public void setExposeSpringMacroHelpers(boolean exposeSpringMacroHelpers) {
/* 144 */     this.exposeSpringMacroHelpers = exposeSpringMacroHelpers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyToMvcViewResolver(Object viewResolver) {
/* 154 */     Assert.isInstanceOf(AbstractTemplateViewResolver.class, viewResolver, "ViewResolver is not an instance of AbstractTemplateViewResolver :" + viewResolver);
/*     */     
/* 156 */     AbstractTemplateViewResolver resolver = (AbstractTemplateViewResolver)viewResolver;
/* 157 */     resolver.setPrefix(getPrefix());
/* 158 */     resolver.setSuffix(getSuffix());
/* 159 */     resolver.setCache(isCache());
/* 160 */     if (getContentType() != null) {
/* 161 */       resolver.setContentType(getContentType().toString());
/*     */     }
/* 163 */     resolver.setViewNames(getViewNames());
/* 164 */     resolver.setExposeRequestAttributes(isExposeRequestAttributes());
/* 165 */     resolver.setAllowRequestOverride(isAllowRequestOverride());
/* 166 */     resolver.setAllowSessionOverride(isAllowSessionOverride());
/* 167 */     resolver.setExposeSessionAttributes(isExposeSessionAttributes());
/* 168 */     resolver.setExposeSpringMacroHelpers(isExposeSpringMacroHelpers());
/* 169 */     resolver.setRequestContextAttribute(getRequestContextAttribute());
/*     */ 
/*     */     
/* 172 */     resolver.setOrder(2147483642);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\template\AbstractTemplateViewResolverProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.retry.RetryPolicy;
/*    */ import org.springframework.retry.backoff.BackOffPolicy;
/*    */ import org.springframework.retry.backoff.ExponentialBackOffPolicy;
/*    */ import org.springframework.retry.policy.SimpleRetryPolicy;
/*    */ import org.springframework.retry.support.RetryTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RetryTemplateFactory
/*    */ {
/*    */   private final List<RabbitRetryTemplateCustomizer> customizers;
/*    */   
/*    */   RetryTemplateFactory(List<RabbitRetryTemplateCustomizer> customizers) {
/* 38 */     this.customizers = customizers;
/*    */   }
/*    */   
/*    */   RetryTemplate createRetryTemplate(RabbitProperties.Retry properties, RabbitRetryTemplateCustomizer.Target target) {
/* 42 */     PropertyMapper map = PropertyMapper.get();
/* 43 */     RetryTemplate template = new RetryTemplate();
/* 44 */     SimpleRetryPolicy policy = new SimpleRetryPolicy();
/* 45 */     map.from(properties::getMaxAttempts).to(policy::setMaxAttempts);
/* 46 */     template.setRetryPolicy((RetryPolicy)policy);
/* 47 */     ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
/* 48 */     map.from(properties::getInitialInterval).whenNonNull().as(Duration::toMillis)
/* 49 */       .to(backOffPolicy::setInitialInterval);
/* 50 */     map.from(properties::getMultiplier).to(backOffPolicy::setMultiplier);
/* 51 */     map.from(properties::getMaxInterval).whenNonNull().as(Duration::toMillis).to(backOffPolicy::setMaxInterval);
/* 52 */     template.setBackOffPolicy((BackOffPolicy)backOffPolicy);
/* 53 */     if (this.customizers != null) {
/* 54 */       for (RabbitRetryTemplateCustomizer customizer : this.customizers) {
/* 55 */         customizer.customize(target, template);
/*    */       }
/*    */     }
/* 58 */     return template;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\RetryTemplateFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
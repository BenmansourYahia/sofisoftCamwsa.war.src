/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import org.springframework.retry.support.RetryTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface RabbitRetryTemplateCustomizer
/*    */ {
/*    */   void customize(Target paramTarget, RetryTemplate paramRetryTemplate);
/*    */   
/*    */   public enum Target
/*    */   {
/* 49 */     SENDER,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 54 */     LISTENER;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\RabbitRetryTemplateCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
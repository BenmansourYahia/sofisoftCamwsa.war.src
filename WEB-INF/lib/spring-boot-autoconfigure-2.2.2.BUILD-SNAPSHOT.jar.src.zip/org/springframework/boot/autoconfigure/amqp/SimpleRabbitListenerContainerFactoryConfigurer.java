/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import org.springframework.amqp.rabbit.config.AbstractRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleRabbitListenerContainerFactoryConfigurer
/*    */   extends AbstractRabbitListenerContainerFactoryConfigurer<SimpleRabbitListenerContainerFactory>
/*    */ {
/*    */   public void configure(SimpleRabbitListenerContainerFactory factory, ConnectionFactory connectionFactory) {
/* 36 */     PropertyMapper map = PropertyMapper.get();
/* 37 */     RabbitProperties.SimpleContainer config = getRabbitProperties().getListener().getSimple();
/* 38 */     configure(factory, connectionFactory, config);
/* 39 */     map.from(config::getConcurrency).whenNonNull().to(factory::setConcurrentConsumers);
/* 40 */     map.from(config::getMaxConcurrency).whenNonNull().to(factory::setMaxConcurrentConsumers);
/* 41 */     map.from(config::getBatchSize).whenNonNull().to(factory::setBatchSize);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\SimpleRabbitListenerContainerFactoryConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
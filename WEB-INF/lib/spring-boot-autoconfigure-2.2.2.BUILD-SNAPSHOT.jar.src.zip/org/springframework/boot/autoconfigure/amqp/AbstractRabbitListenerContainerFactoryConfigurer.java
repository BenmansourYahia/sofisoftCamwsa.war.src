/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.amqp.rabbit.config.AbstractRabbitListenerContainerFactory;
/*     */ import org.springframework.amqp.rabbit.config.RetryInterceptorBuilder;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.retry.MessageRecoverer;
/*     */ import org.springframework.amqp.rabbit.retry.RejectAndDontRequeueRecoverer;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.retry.RetryOperations;
/*     */ import org.springframework.retry.support.RetryTemplate;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRabbitListenerContainerFactoryConfigurer<T extends AbstractRabbitListenerContainerFactory<?>>
/*     */ {
/*     */   private MessageConverter messageConverter;
/*     */   private MessageRecoverer messageRecoverer;
/*     */   private List<RabbitRetryTemplateCustomizer> retryTemplateCustomizers;
/*     */   private RabbitProperties rabbitProperties;
/*     */   
/*     */   protected void setMessageConverter(MessageConverter messageConverter) {
/*  56 */     this.messageConverter = messageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMessageRecoverer(MessageRecoverer messageRecoverer) {
/*  64 */     this.messageRecoverer = messageRecoverer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRetryTemplateCustomizers(List<RabbitRetryTemplateCustomizer> retryTemplateCustomizers) {
/*  72 */     this.retryTemplateCustomizers = retryTemplateCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRabbitProperties(RabbitProperties rabbitProperties) {
/*  80 */     this.rabbitProperties = rabbitProperties;
/*     */   }
/*     */   
/*     */   protected final RabbitProperties getRabbitProperties() {
/*  84 */     return this.rabbitProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void configure(T paramT, ConnectionFactory paramConnectionFactory);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configure(T factory, ConnectionFactory connectionFactory, RabbitProperties.AmqpContainer configuration) {
/*  98 */     Assert.notNull(factory, "Factory must not be null");
/*  99 */     Assert.notNull(connectionFactory, "ConnectionFactory must not be null");
/* 100 */     Assert.notNull(configuration, "Configuration must not be null");
/* 101 */     factory.setConnectionFactory(connectionFactory);
/* 102 */     if (this.messageConverter != null) {
/* 103 */       factory.setMessageConverter(this.messageConverter);
/*     */     }
/* 105 */     factory.setAutoStartup(Boolean.valueOf(configuration.isAutoStartup()));
/* 106 */     if (configuration.getAcknowledgeMode() != null) {
/* 107 */       factory.setAcknowledgeMode(configuration.getAcknowledgeMode());
/*     */     }
/* 109 */     if (configuration.getPrefetch() != null) {
/* 110 */       factory.setPrefetchCount(configuration.getPrefetch());
/*     */     }
/* 112 */     if (configuration.getDefaultRequeueRejected() != null) {
/* 113 */       factory.setDefaultRequeueRejected(configuration.getDefaultRequeueRejected());
/*     */     }
/* 115 */     if (configuration.getIdleEventInterval() != null) {
/* 116 */       factory.setIdleEventInterval(Long.valueOf(configuration.getIdleEventInterval().toMillis()));
/*     */     }
/* 118 */     factory.setMissingQueuesFatal(Boolean.valueOf(configuration.isMissingQueuesFatal()));
/* 119 */     RabbitProperties.ListenerRetry retryConfig = configuration.getRetry();
/* 120 */     if (retryConfig.isEnabled()) {
/*     */       
/* 122 */       RetryInterceptorBuilder<?, ?> builder = retryConfig.isStateless() ? (RetryInterceptorBuilder<?, ?>)RetryInterceptorBuilder.stateless() : (RetryInterceptorBuilder<?, ?>)RetryInterceptorBuilder.stateful();
/*     */       
/* 124 */       RetryTemplate retryTemplate = (new RetryTemplateFactory(this.retryTemplateCustomizers)).createRetryTemplate(retryConfig, RabbitRetryTemplateCustomizer.Target.LISTENER);
/* 125 */       builder.retryOperations((RetryOperations)retryTemplate);
/* 126 */       MessageRecoverer recoverer = (this.messageRecoverer != null) ? this.messageRecoverer : (MessageRecoverer)new RejectAndDontRequeueRecoverer();
/*     */       
/* 128 */       builder.recoverer(recoverer);
/* 129 */       factory.setAdviceChain(new Advice[] { (Advice)builder.build() });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\AbstractRabbitListenerContainerFactoryConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import com.rabbitmq.client.Channel;
/*     */ import com.rabbitmq.client.ConnectionFactory;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.amqp.core.AmqpAdmin;
/*     */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionNameStrategy;
/*     */ import org.springframework.amqp.rabbit.connection.RabbitConnectionFactoryBean;
/*     */ import org.springframework.amqp.rabbit.core.RabbitAdmin;
/*     */ import org.springframework.amqp.rabbit.core.RabbitMessagingTemplate;
/*     */ import org.springframework.amqp.rabbit.core.RabbitOperations;
/*     */ import org.springframework.amqp.rabbit.core.RabbitTemplate;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({RabbitTemplate.class, Channel.class})
/*     */ @EnableConfigurationProperties({RabbitProperties.class})
/*     */ @Import({RabbitAnnotationDrivenConfiguration.class})
/*     */ public class RabbitAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({ConnectionFactory.class})
/*     */   protected static class RabbitConnectionFactoryCreator
/*     */   {
/*     */     @Bean
/*     */     public CachingConnectionFactory rabbitConnectionFactory(RabbitProperties properties, ObjectProvider<ConnectionNameStrategy> connectionNameStrategy) throws Exception {
/*  99 */       PropertyMapper map = PropertyMapper.get();
/*     */       
/* 101 */       CachingConnectionFactory factory = new CachingConnectionFactory((ConnectionFactory)getRabbitConnectionFactoryBean(properties).getObject());
/* 102 */       map.from(properties::determineAddresses).to(factory::setAddresses);
/* 103 */       map.from(properties::isPublisherReturns).to(factory::setPublisherReturns);
/* 104 */       map.from(properties::getPublisherConfirmType).whenNonNull().to(factory::setPublisherConfirmType);
/* 105 */       RabbitProperties.Cache.Channel channel = properties.getCache().getChannel();
/* 106 */       map.from(channel::getSize).whenNonNull().to(factory::setChannelCacheSize);
/* 107 */       map.from(channel::getCheckoutTimeout).whenNonNull().as(Duration::toMillis)
/* 108 */         .to(factory::setChannelCheckoutTimeout);
/* 109 */       RabbitProperties.Cache.Connection connection = properties.getCache().getConnection();
/* 110 */       map.from(connection::getMode).whenNonNull().to(factory::setCacheMode);
/* 111 */       map.from(connection::getSize).whenNonNull().to(factory::setConnectionCacheSize);
/* 112 */       map.from(connectionNameStrategy::getIfUnique).whenNonNull().to(factory::setConnectionNameStrategy);
/* 113 */       return factory;
/*     */     }
/*     */ 
/*     */     
/*     */     private RabbitConnectionFactoryBean getRabbitConnectionFactoryBean(RabbitProperties properties) throws Exception {
/* 118 */       PropertyMapper map = PropertyMapper.get();
/* 119 */       RabbitConnectionFactoryBean factory = new RabbitConnectionFactoryBean();
/* 120 */       map.from(properties::determineHost).whenNonNull().to(factory::setHost);
/* 121 */       map.from(properties::determinePort).to(factory::setPort);
/* 122 */       map.from(properties::determineUsername).whenNonNull().to(factory::setUsername);
/* 123 */       map.from(properties::determinePassword).whenNonNull().to(factory::setPassword);
/* 124 */       map.from(properties::determineVirtualHost).whenNonNull().to(factory::setVirtualHost);
/* 125 */       map.from(properties::getRequestedHeartbeat).whenNonNull().asInt(Duration::getSeconds)
/* 126 */         .to(factory::setRequestedHeartbeat);
/* 127 */       RabbitProperties.Ssl ssl = properties.getSsl();
/* 128 */       if (ssl.determineEnabled()) {
/* 129 */         factory.setUseSSL(true);
/* 130 */         map.from(ssl::getAlgorithm).whenNonNull().to(factory::setSslAlgorithm);
/* 131 */         map.from(ssl::getKeyStoreType).to(factory::setKeyStoreType);
/* 132 */         map.from(ssl::getKeyStore).to(factory::setKeyStore);
/* 133 */         map.from(ssl::getKeyStorePassword).to(factory::setKeyStorePassphrase);
/* 134 */         map.from(ssl::getTrustStoreType).to(factory::setTrustStoreType);
/* 135 */         map.from(ssl::getTrustStore).to(factory::setTrustStore);
/* 136 */         map.from(ssl::getTrustStorePassword).to(factory::setTrustStorePassphrase);
/* 137 */         map.from(ssl::isValidateServerCertificate)
/* 138 */           .to(validate -> factory.setSkipServerCertificateValidation(!validate.booleanValue()));
/* 139 */         map.from(ssl::getVerifyHostname).to(factory::setEnableHostnameVerification);
/*     */       } 
/* 141 */       map.from(properties::getConnectionTimeout).whenNonNull().asInt(Duration::toMillis)
/* 142 */         .to(factory::setConnectionTimeout);
/* 143 */       factory.afterPropertiesSet();
/* 144 */       return factory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Import({RabbitConnectionFactoryCreator.class})
/*     */   protected static class RabbitTemplateConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*     */     @ConditionalOnMissingBean({RabbitOperations.class})
/*     */     public RabbitTemplate rabbitTemplate(RabbitProperties properties, ObjectProvider<MessageConverter> messageConverter, ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers, ConnectionFactory connectionFactory) {
/* 160 */       PropertyMapper map = PropertyMapper.get();
/* 161 */       RabbitTemplate template = new RabbitTemplate(connectionFactory);
/* 162 */       messageConverter.ifUnique(template::setMessageConverter);
/* 163 */       template.setMandatory(determineMandatoryFlag(properties));
/* 164 */       RabbitProperties.Template templateProperties = properties.getTemplate();
/* 165 */       if (templateProperties.getRetry().isEnabled()) {
/* 166 */         template.setRetryTemplate((new RetryTemplateFactory((List<RabbitRetryTemplateCustomizer>)retryTemplateCustomizers
/* 167 */               .orderedStream().collect(Collectors.toList())))
/* 168 */             .createRetryTemplate(templateProperties.getRetry(), RabbitRetryTemplateCustomizer.Target.SENDER));
/*     */       }
/*     */       
/* 171 */       map.from(templateProperties::getReceiveTimeout).whenNonNull().as(Duration::toMillis)
/* 172 */         .to(template::setReceiveTimeout);
/* 173 */       map.from(templateProperties::getReplyTimeout).whenNonNull().as(Duration::toMillis)
/* 174 */         .to(template::setReplyTimeout);
/* 175 */       map.from(templateProperties::getExchange).to(template::setExchange);
/* 176 */       map.from(templateProperties::getRoutingKey).to(template::setRoutingKey);
/* 177 */       map.from(templateProperties::getDefaultReceiveQueue).whenNonNull().to(template::setDefaultReceiveQueue);
/* 178 */       return template;
/*     */     }
/*     */     
/*     */     private boolean determineMandatoryFlag(RabbitProperties properties) {
/* 182 */       Boolean mandatory = properties.getTemplate().getMandatory();
/* 183 */       return (mandatory != null) ? mandatory.booleanValue() : properties.isPublisherReturns();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*     */     @ConditionalOnProperty(prefix = "spring.rabbitmq", name = {"dynamic"}, matchIfMissing = true)
/*     */     @ConditionalOnMissingBean
/*     */     public AmqpAdmin amqpAdmin(ConnectionFactory connectionFactory) {
/* 191 */       return (AmqpAdmin)new RabbitAdmin(connectionFactory);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({RabbitMessagingTemplate.class})
/*     */   @ConditionalOnMissingBean({RabbitMessagingTemplate.class})
/*     */   @Import({RabbitTemplateConfiguration.class})
/*     */   protected static class MessagingTemplateConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnSingleCandidate(RabbitTemplate.class)
/*     */     public RabbitMessagingTemplate rabbitMessagingTemplate(RabbitTemplate rabbitTemplate) {
/* 205 */       return new RabbitMessagingTemplate(rabbitTemplate);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\RabbitAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
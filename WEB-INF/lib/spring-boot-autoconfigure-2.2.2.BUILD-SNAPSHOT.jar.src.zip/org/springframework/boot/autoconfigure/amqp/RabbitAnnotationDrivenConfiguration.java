/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.amqp.rabbit.annotation.EnableRabbit;
/*     */ import org.springframework.amqp.rabbit.config.DirectRabbitListenerContainerFactory;
/*     */ import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.retry.MessageRecoverer;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({EnableRabbit.class})
/*     */ class RabbitAnnotationDrivenConfiguration
/*     */ {
/*     */   private final ObjectProvider<MessageConverter> messageConverter;
/*     */   private final ObjectProvider<MessageRecoverer> messageRecoverer;
/*     */   private final ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers;
/*     */   private final RabbitProperties properties;
/*     */   
/*     */   RabbitAnnotationDrivenConfiguration(ObjectProvider<MessageConverter> messageConverter, ObjectProvider<MessageRecoverer> messageRecoverer, ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers, RabbitProperties properties) {
/*  56 */     this.messageConverter = messageConverter;
/*  57 */     this.messageRecoverer = messageRecoverer;
/*  58 */     this.retryTemplateCustomizers = retryTemplateCustomizers;
/*  59 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   SimpleRabbitListenerContainerFactoryConfigurer simpleRabbitListenerContainerFactoryConfigurer() {
/*  65 */     SimpleRabbitListenerContainerFactoryConfigurer configurer = new SimpleRabbitListenerContainerFactoryConfigurer();
/*  66 */     configurer.setMessageConverter((MessageConverter)this.messageConverter.getIfUnique());
/*  67 */     configurer.setMessageRecoverer((MessageRecoverer)this.messageRecoverer.getIfUnique());
/*  68 */     configurer.setRetryTemplateCustomizers((List<RabbitRetryTemplateCustomizer>)this.retryTemplateCustomizers
/*  69 */         .orderedStream().collect(Collectors.toList()));
/*  70 */     configurer.setRabbitProperties(this.properties);
/*  71 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnMissingBean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnProperty(prefix = "spring.rabbitmq.listener", name = {"type"}, havingValue = "simple", matchIfMissing = true)
/*     */   SimpleRabbitListenerContainerFactory simpleRabbitListenerContainerFactory(SimpleRabbitListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory) {
/*  80 */     SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
/*  81 */     configurer.configure(factory, connectionFactory);
/*  82 */     return factory;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   DirectRabbitListenerContainerFactoryConfigurer directRabbitListenerContainerFactoryConfigurer() {
/*  88 */     DirectRabbitListenerContainerFactoryConfigurer configurer = new DirectRabbitListenerContainerFactoryConfigurer();
/*  89 */     configurer.setMessageConverter((MessageConverter)this.messageConverter.getIfUnique());
/*  90 */     configurer.setMessageRecoverer((MessageRecoverer)this.messageRecoverer.getIfUnique());
/*  91 */     configurer.setRetryTemplateCustomizers((List<RabbitRetryTemplateCustomizer>)this.retryTemplateCustomizers
/*  92 */         .orderedStream().collect(Collectors.toList()));
/*  93 */     configurer.setRabbitProperties(this.properties);
/*  94 */     return configurer;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnMissingBean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnProperty(prefix = "spring.rabbitmq.listener", name = {"type"}, havingValue = "direct")
/*     */   DirectRabbitListenerContainerFactory directRabbitListenerContainerFactory(DirectRabbitListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory) {
/* 102 */     DirectRabbitListenerContainerFactory factory = new DirectRabbitListenerContainerFactory();
/* 103 */     configurer.configure(factory, connectionFactory);
/* 104 */     return factory;
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @EnableRabbit
/*     */   @ConditionalOnMissingBean(name = {"org.springframework.amqp.rabbit.config.internalRabbitListenerAnnotationProcessor"})
/*     */   static class EnableRabbitConfiguration {}
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\RabbitAnnotationDrivenConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
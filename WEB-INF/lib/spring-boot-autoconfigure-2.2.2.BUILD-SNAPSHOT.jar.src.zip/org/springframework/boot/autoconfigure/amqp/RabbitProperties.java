/*      */ package org.springframework.boot.autoconfigure.amqp;
/*      */ 
/*      */ import java.time.Duration;
/*      */ import java.time.temporal.ChronoUnit;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.springframework.amqp.core.AcknowledgeMode;
/*      */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
/*      */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*      */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*      */ import org.springframework.boot.convert.DurationUnit;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @ConfigurationProperties(prefix = "spring.rabbitmq")
/*      */ public class RabbitProperties
/*      */ {
/*   51 */   private String host = "localhost";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   56 */   private int port = 5672;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   61 */   private String username = "guest";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   66 */   private String password = "guest";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   71 */   private final Ssl ssl = new Ssl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String virtualHost;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String addresses;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @DurationUnit(ChronoUnit.SECONDS)
/*      */   private Duration requestedHeartbeat;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean publisherReturns;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CachingConnectionFactory.ConfirmType publisherConfirmType;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Duration connectionTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  108 */   private final Cache cache = new Cache();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private final Listener listener = new Listener();
/*      */   
/*  115 */   private final Template template = new Template();
/*      */   
/*      */   private List<Address> parsedAddresses;
/*      */   
/*      */   public String getHost() {
/*  120 */     return this.host;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determineHost() {
/*  131 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  132 */       return getHost();
/*      */     }
/*  134 */     return (this.parsedAddresses.get(0)).host;
/*      */   }
/*      */   
/*      */   public void setHost(String host) {
/*  138 */     this.host = host;
/*      */   }
/*      */   
/*      */   public int getPort() {
/*  142 */     return this.port;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int determinePort() {
/*  153 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  154 */       return getPort();
/*      */     }
/*  156 */     Address address = this.parsedAddresses.get(0);
/*  157 */     return address.port;
/*      */   }
/*      */   
/*      */   public void setPort(int port) {
/*  161 */     this.port = port;
/*      */   }
/*      */   
/*      */   public String getAddresses() {
/*  165 */     return this.addresses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determineAddresses() {
/*  174 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  175 */       return this.host + ":" + this.port;
/*      */     }
/*  177 */     List<String> addressStrings = new ArrayList<>();
/*  178 */     for (Address parsedAddress : this.parsedAddresses) {
/*  179 */       addressStrings.add(parsedAddress.host + ":" + parsedAddress.port);
/*      */     }
/*  181 */     return StringUtils.collectionToCommaDelimitedString(addressStrings);
/*      */   }
/*      */   
/*      */   public void setAddresses(String addresses) {
/*  185 */     this.addresses = addresses;
/*  186 */     this.parsedAddresses = parseAddresses(addresses);
/*      */   }
/*      */   
/*      */   private List<Address> parseAddresses(String addresses) {
/*  190 */     List<Address> parsedAddresses = new ArrayList<>();
/*  191 */     for (String address : StringUtils.commaDelimitedListToStringArray(addresses)) {
/*  192 */       parsedAddresses.add(new Address(address));
/*      */     }
/*  194 */     return parsedAddresses;
/*      */   }
/*      */   
/*      */   public String getUsername() {
/*  198 */     return this.username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determineUsername() {
/*  209 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  210 */       return this.username;
/*      */     }
/*  212 */     Address address = this.parsedAddresses.get(0);
/*  213 */     return (address.username != null) ? address.username : this.username;
/*      */   }
/*      */   
/*      */   public void setUsername(String username) {
/*  217 */     this.username = username;
/*      */   }
/*      */   
/*      */   public String getPassword() {
/*  221 */     return this.password;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determinePassword() {
/*  232 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  233 */       return getPassword();
/*      */     }
/*  235 */     Address address = this.parsedAddresses.get(0);
/*  236 */     return (address.password != null) ? address.password : getPassword();
/*      */   }
/*      */   
/*      */   public void setPassword(String password) {
/*  240 */     this.password = password;
/*      */   }
/*      */   
/*      */   public Ssl getSsl() {
/*  244 */     return this.ssl;
/*      */   }
/*      */   
/*      */   public String getVirtualHost() {
/*  248 */     return this.virtualHost;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determineVirtualHost() {
/*  259 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  260 */       return getVirtualHost();
/*      */     }
/*  262 */     Address address = this.parsedAddresses.get(0);
/*  263 */     return (address.virtualHost != null) ? address.virtualHost : getVirtualHost();
/*      */   }
/*      */   
/*      */   public void setVirtualHost(String virtualHost) {
/*  267 */     this.virtualHost = "".equals(virtualHost) ? "/" : virtualHost;
/*      */   }
/*      */   
/*      */   public Duration getRequestedHeartbeat() {
/*  271 */     return this.requestedHeartbeat;
/*      */   }
/*      */   
/*      */   public void setRequestedHeartbeat(Duration requestedHeartbeat) {
/*  275 */     this.requestedHeartbeat = requestedHeartbeat;
/*      */   }
/*      */ 
/*      */   
/*      */   @DeprecatedConfigurationProperty(reason = "replaced to support additional confirm types", replacement = "spring.rabbitmq.publisher-confirm-type")
/*      */   public boolean isPublisherConfirms() {
/*  281 */     return CachingConnectionFactory.ConfirmType.CORRELATED.equals(this.publisherConfirmType);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void setPublisherConfirms(boolean publisherConfirms) {
/*  286 */     this.publisherConfirmType = publisherConfirms ? CachingConnectionFactory.ConfirmType.CORRELATED : CachingConnectionFactory.ConfirmType.NONE;
/*      */   }
/*      */   
/*      */   public boolean isPublisherReturns() {
/*  290 */     return this.publisherReturns;
/*      */   }
/*      */   
/*      */   public void setPublisherReturns(boolean publisherReturns) {
/*  294 */     this.publisherReturns = publisherReturns;
/*      */   }
/*      */   
/*      */   public Duration getConnectionTimeout() {
/*  298 */     return this.connectionTimeout;
/*      */   }
/*      */   
/*      */   public void setPublisherConfirmType(CachingConnectionFactory.ConfirmType publisherConfirmType) {
/*  302 */     this.publisherConfirmType = publisherConfirmType;
/*      */   }
/*      */   
/*      */   public CachingConnectionFactory.ConfirmType getPublisherConfirmType() {
/*  306 */     return this.publisherConfirmType;
/*      */   }
/*      */   
/*      */   public void setConnectionTimeout(Duration connectionTimeout) {
/*  310 */     this.connectionTimeout = connectionTimeout;
/*      */   }
/*      */   
/*      */   public Cache getCache() {
/*  314 */     return this.cache;
/*      */   }
/*      */   
/*      */   public Listener getListener() {
/*  318 */     return this.listener;
/*      */   }
/*      */   
/*      */   public Template getTemplate() {
/*  322 */     return this.template;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public class Ssl
/*      */   {
/*      */     private boolean enabled;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String keyStore;
/*      */ 
/*      */ 
/*      */     
/*  340 */     private String keyStoreType = "PKCS12";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String keyStorePassword;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String trustStore;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  355 */     private String trustStoreType = "JKS";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String trustStorePassword;
/*      */ 
/*      */ 
/*      */     
/*      */     private String algorithm;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean validateServerCertificate = true;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean verifyHostname = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEnabled() {
/*  378 */       return this.enabled;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean determineEnabled() {
/*  389 */       if (CollectionUtils.isEmpty(RabbitProperties.this.parsedAddresses)) {
/*  390 */         return isEnabled();
/*      */       }
/*  392 */       RabbitProperties.Address address = RabbitProperties.this.parsedAddresses.get(0);
/*  393 */       return address.secureConnection;
/*      */     }
/*      */     
/*      */     public void setEnabled(boolean enabled) {
/*  397 */       this.enabled = enabled;
/*      */     }
/*      */     
/*      */     public String getKeyStore() {
/*  401 */       return this.keyStore;
/*      */     }
/*      */     
/*      */     public void setKeyStore(String keyStore) {
/*  405 */       this.keyStore = keyStore;
/*      */     }
/*      */     
/*      */     public String getKeyStoreType() {
/*  409 */       return this.keyStoreType;
/*      */     }
/*      */     
/*      */     public void setKeyStoreType(String keyStoreType) {
/*  413 */       this.keyStoreType = keyStoreType;
/*      */     }
/*      */     
/*      */     public String getKeyStorePassword() {
/*  417 */       return this.keyStorePassword;
/*      */     }
/*      */     
/*      */     public void setKeyStorePassword(String keyStorePassword) {
/*  421 */       this.keyStorePassword = keyStorePassword;
/*      */     }
/*      */     
/*      */     public String getTrustStore() {
/*  425 */       return this.trustStore;
/*      */     }
/*      */     
/*      */     public void setTrustStore(String trustStore) {
/*  429 */       this.trustStore = trustStore;
/*      */     }
/*      */     
/*      */     public String getTrustStoreType() {
/*  433 */       return this.trustStoreType;
/*      */     }
/*      */     
/*      */     public void setTrustStoreType(String trustStoreType) {
/*  437 */       this.trustStoreType = trustStoreType;
/*      */     }
/*      */     
/*      */     public String getTrustStorePassword() {
/*  441 */       return this.trustStorePassword;
/*      */     }
/*      */     
/*      */     public void setTrustStorePassword(String trustStorePassword) {
/*  445 */       this.trustStorePassword = trustStorePassword;
/*      */     }
/*      */     
/*      */     public String getAlgorithm() {
/*  449 */       return this.algorithm;
/*      */     }
/*      */     
/*      */     public void setAlgorithm(String sslAlgorithm) {
/*  453 */       this.algorithm = sslAlgorithm;
/*      */     }
/*      */     
/*      */     public boolean isValidateServerCertificate() {
/*  457 */       return this.validateServerCertificate;
/*      */     }
/*      */     
/*      */     public void setValidateServerCertificate(boolean validateServerCertificate) {
/*  461 */       this.validateServerCertificate = validateServerCertificate;
/*      */     }
/*      */     
/*      */     public boolean getVerifyHostname() {
/*  465 */       return this.verifyHostname;
/*      */     }
/*      */     
/*      */     public void setVerifyHostname(boolean verifyHostname) {
/*  469 */       this.verifyHostname = verifyHostname;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class Cache
/*      */   {
/*  476 */     private final Channel channel = new Channel();
/*      */     
/*  478 */     private final Connection connection = new Connection();
/*      */     
/*      */     public Channel getChannel() {
/*  481 */       return this.channel;
/*      */     }
/*      */     
/*      */     public Connection getConnection() {
/*  485 */       return this.connection;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Channel
/*      */     {
/*      */       private Integer size;
/*      */ 
/*      */ 
/*      */       
/*      */       private Duration checkoutTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Integer getSize() {
/*  503 */         return this.size;
/*      */       }
/*      */       
/*      */       public void setSize(Integer size) {
/*  507 */         this.size = size;
/*      */       }
/*      */       
/*      */       public Duration getCheckoutTimeout() {
/*  511 */         return this.checkoutTimeout;
/*      */       }
/*      */       
/*      */       public void setCheckoutTimeout(Duration checkoutTimeout) {
/*  515 */         this.checkoutTimeout = checkoutTimeout;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Connection
/*      */     {
/*  525 */       private CachingConnectionFactory.CacheMode mode = CachingConnectionFactory.CacheMode.CHANNEL;
/*      */ 
/*      */       
/*      */       private Integer size;
/*      */ 
/*      */ 
/*      */       
/*      */       public CachingConnectionFactory.CacheMode getMode() {
/*  533 */         return this.mode;
/*      */       }
/*      */       
/*      */       public void setMode(CachingConnectionFactory.CacheMode mode) {
/*  537 */         this.mode = mode;
/*      */       }
/*      */       
/*      */       public Integer getSize() {
/*  541 */         return this.size;
/*      */       }
/*      */       
/*      */       public void setSize(Integer size) {
/*  545 */         this.size = size;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum ContainerType
/*      */   {
/*  557 */     SIMPLE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  563 */     DIRECT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Listener
/*      */   {
/*  572 */     private RabbitProperties.ContainerType type = RabbitProperties.ContainerType.SIMPLE;
/*      */     
/*  574 */     private final RabbitProperties.SimpleContainer simple = new RabbitProperties.SimpleContainer();
/*      */     
/*  576 */     private final RabbitProperties.DirectContainer direct = new RabbitProperties.DirectContainer();
/*      */     
/*      */     public RabbitProperties.ContainerType getType() {
/*  579 */       return this.type;
/*      */     }
/*      */     
/*      */     public void setType(RabbitProperties.ContainerType containerType) {
/*  583 */       this.type = containerType;
/*      */     }
/*      */     
/*      */     public RabbitProperties.SimpleContainer getSimple() {
/*  587 */       return this.simple;
/*      */     }
/*      */     
/*      */     public RabbitProperties.DirectContainer getDirect() {
/*  591 */       return this.direct;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AmqpContainer
/*      */   {
/*      */     private boolean autoStartup = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private AcknowledgeMode acknowledgeMode;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer prefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean defaultRequeueRejected;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration idleEventInterval;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  627 */     private final RabbitProperties.ListenerRetry retry = new RabbitProperties.ListenerRetry();
/*      */     
/*      */     public boolean isAutoStartup() {
/*  630 */       return this.autoStartup;
/*      */     }
/*      */     
/*      */     public void setAutoStartup(boolean autoStartup) {
/*  634 */       this.autoStartup = autoStartup;
/*      */     }
/*      */     
/*      */     public AcknowledgeMode getAcknowledgeMode() {
/*  638 */       return this.acknowledgeMode;
/*      */     }
/*      */     
/*      */     public void setAcknowledgeMode(AcknowledgeMode acknowledgeMode) {
/*  642 */       this.acknowledgeMode = acknowledgeMode;
/*      */     }
/*      */     
/*      */     public Integer getPrefetch() {
/*  646 */       return this.prefetch;
/*      */     }
/*      */     
/*      */     public void setPrefetch(Integer prefetch) {
/*  650 */       this.prefetch = prefetch;
/*      */     }
/*      */     
/*      */     public Boolean getDefaultRequeueRejected() {
/*  654 */       return this.defaultRequeueRejected;
/*      */     }
/*      */     
/*      */     public void setDefaultRequeueRejected(Boolean defaultRequeueRejected) {
/*  658 */       this.defaultRequeueRejected = defaultRequeueRejected;
/*      */     }
/*      */     
/*      */     public Duration getIdleEventInterval() {
/*  662 */       return this.idleEventInterval;
/*      */     }
/*      */     
/*      */     public void setIdleEventInterval(Duration idleEventInterval) {
/*  666 */       this.idleEventInterval = idleEventInterval;
/*      */     }
/*      */     
/*      */     public abstract boolean isMissingQueuesFatal();
/*      */     
/*      */     public RabbitProperties.ListenerRetry getRetry() {
/*  672 */       return this.retry;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SimpleContainer
/*      */     extends AmqpContainer
/*      */   {
/*      */     private Integer concurrency;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer maxConcurrency;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer batchSize;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean missingQueuesFatal = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Integer getConcurrency() {
/*  706 */       return this.concurrency;
/*      */     }
/*      */     
/*      */     public void setConcurrency(Integer concurrency) {
/*  710 */       this.concurrency = concurrency;
/*      */     }
/*      */     
/*      */     public Integer getMaxConcurrency() {
/*  714 */       return this.maxConcurrency;
/*      */     }
/*      */     
/*      */     public void setMaxConcurrency(Integer maxConcurrency) {
/*  718 */       this.maxConcurrency = maxConcurrency;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @DeprecatedConfigurationProperty(replacement = "spring.rabbitmq.listener.simple.batch-size")
/*      */     @Deprecated
/*      */     public Integer getTransactionSize() {
/*  729 */       return getBatchSize();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public void setTransactionSize(Integer transactionSize) {
/*  740 */       setBatchSize(transactionSize);
/*      */     }
/*      */     
/*      */     public Integer getBatchSize() {
/*  744 */       return this.batchSize;
/*      */     }
/*      */     
/*      */     public void setBatchSize(Integer batchSize) {
/*  748 */       this.batchSize = batchSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isMissingQueuesFatal() {
/*  753 */       return this.missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public void setMissingQueuesFatal(boolean missingQueuesFatal) {
/*  757 */       this.missingQueuesFatal = missingQueuesFatal;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DirectContainer
/*      */     extends AmqpContainer
/*      */   {
/*      */     private Integer consumersPerQueue;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean missingQueuesFatal = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Integer getConsumersPerQueue() {
/*  779 */       return this.consumersPerQueue;
/*      */     }
/*      */     
/*      */     public void setConsumersPerQueue(Integer consumersPerQueue) {
/*  783 */       this.consumersPerQueue = consumersPerQueue;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isMissingQueuesFatal() {
/*  788 */       return this.missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public void setMissingQueuesFatal(boolean missingQueuesFatal) {
/*  792 */       this.missingQueuesFatal = missingQueuesFatal;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class Template
/*      */   {
/*  799 */     private final RabbitProperties.Retry retry = new RabbitProperties.Retry();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean mandatory;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration receiveTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration replyTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  819 */     private String exchange = "";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  824 */     private String routingKey = "";
/*      */ 
/*      */ 
/*      */     
/*      */     private String defaultReceiveQueue;
/*      */ 
/*      */ 
/*      */     
/*      */     public RabbitProperties.Retry getRetry() {
/*  833 */       return this.retry;
/*      */     }
/*      */     
/*      */     public Boolean getMandatory() {
/*  837 */       return this.mandatory;
/*      */     }
/*      */     
/*      */     public void setMandatory(Boolean mandatory) {
/*  841 */       this.mandatory = mandatory;
/*      */     }
/*      */     
/*      */     public Duration getReceiveTimeout() {
/*  845 */       return this.receiveTimeout;
/*      */     }
/*      */     
/*      */     public void setReceiveTimeout(Duration receiveTimeout) {
/*  849 */       this.receiveTimeout = receiveTimeout;
/*      */     }
/*      */     
/*      */     public Duration getReplyTimeout() {
/*  853 */       return this.replyTimeout;
/*      */     }
/*      */     
/*      */     public void setReplyTimeout(Duration replyTimeout) {
/*  857 */       this.replyTimeout = replyTimeout;
/*      */     }
/*      */     
/*      */     public String getExchange() {
/*  861 */       return this.exchange;
/*      */     }
/*      */     
/*      */     public void setExchange(String exchange) {
/*  865 */       this.exchange = exchange;
/*      */     }
/*      */     
/*      */     public String getRoutingKey() {
/*  869 */       return this.routingKey;
/*      */     }
/*      */     
/*      */     public void setRoutingKey(String routingKey) {
/*  873 */       this.routingKey = routingKey;
/*      */     }
/*      */     
/*      */     public String getDefaultReceiveQueue() {
/*  877 */       return this.defaultReceiveQueue;
/*      */     }
/*      */     
/*      */     public void setDefaultReceiveQueue(String defaultReceiveQueue) {
/*  881 */       this.defaultReceiveQueue = defaultReceiveQueue;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Retry
/*      */   {
/*      */     private boolean enabled;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  896 */     private int maxAttempts = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  901 */     private Duration initialInterval = Duration.ofMillis(1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  906 */     private double multiplier = 1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  911 */     private Duration maxInterval = Duration.ofMillis(10000L);
/*      */     
/*      */     public boolean isEnabled() {
/*  914 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public void setEnabled(boolean enabled) {
/*  918 */       this.enabled = enabled;
/*      */     }
/*      */     
/*      */     public int getMaxAttempts() {
/*  922 */       return this.maxAttempts;
/*      */     }
/*      */     
/*      */     public void setMaxAttempts(int maxAttempts) {
/*  926 */       this.maxAttempts = maxAttempts;
/*      */     }
/*      */     
/*      */     public Duration getInitialInterval() {
/*  930 */       return this.initialInterval;
/*      */     }
/*      */     
/*      */     public void setInitialInterval(Duration initialInterval) {
/*  934 */       this.initialInterval = initialInterval;
/*      */     }
/*      */     
/*      */     public double getMultiplier() {
/*  938 */       return this.multiplier;
/*      */     }
/*      */     
/*      */     public void setMultiplier(double multiplier) {
/*  942 */       this.multiplier = multiplier;
/*      */     }
/*      */     
/*      */     public Duration getMaxInterval() {
/*  946 */       return this.maxInterval;
/*      */     }
/*      */     
/*      */     public void setMaxInterval(Duration maxInterval) {
/*  950 */       this.maxInterval = maxInterval;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ListenerRetry
/*      */     extends Retry
/*      */   {
/*      */     private boolean stateless = true;
/*      */ 
/*      */     
/*      */     public boolean isStateless() {
/*  963 */       return this.stateless;
/*      */     }
/*      */     
/*      */     public void setStateless(boolean stateless) {
/*  967 */       this.stateless = stateless;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class Address
/*      */   {
/*      */     private static final String PREFIX_AMQP = "amqp://";
/*      */     
/*      */     private static final int DEFAULT_PORT = 5672;
/*      */     
/*      */     private static final String PREFIX_AMQP_SECURE = "amqps://";
/*      */     
/*      */     private static final int DEFAULT_PORT_SECURE = 5671;
/*      */     
/*      */     private String host;
/*      */     
/*      */     private int port;
/*      */     
/*      */     private String username;
/*      */     
/*      */     private String password;
/*      */     
/*      */     private String virtualHost;
/*      */     
/*      */     private boolean secureConnection;
/*      */     
/*      */     private Address(String input) {
/*  995 */       input = input.trim();
/*  996 */       input = trimPrefix(input);
/*  997 */       input = parseUsernameAndPassword(input);
/*  998 */       input = parseVirtualHost(input);
/*  999 */       parseHostAndPort(input);
/*      */     }
/*      */     
/*      */     private String trimPrefix(String input) {
/* 1003 */       if (input.startsWith("amqps://")) {
/* 1004 */         this.secureConnection = true;
/* 1005 */         return input.substring("amqps://".length());
/*      */       } 
/* 1007 */       if (input.startsWith("amqp://")) {
/* 1008 */         input = input.substring("amqp://".length());
/*      */       }
/* 1010 */       return input;
/*      */     }
/*      */     
/*      */     private String parseUsernameAndPassword(String input) {
/* 1014 */       if (input.contains("@")) {
/* 1015 */         String[] split = StringUtils.split(input, "@");
/* 1016 */         String creds = split[0];
/* 1017 */         input = split[1];
/* 1018 */         split = StringUtils.split(creds, ":");
/* 1019 */         this.username = split[0];
/* 1020 */         if (split.length > 0) {
/* 1021 */           this.password = split[1];
/*      */         }
/*      */       } 
/* 1024 */       return input;
/*      */     }
/*      */     
/*      */     private String parseVirtualHost(String input) {
/* 1028 */       int hostIndex = input.indexOf('/');
/* 1029 */       if (hostIndex >= 0) {
/* 1030 */         this.virtualHost = input.substring(hostIndex + 1);
/* 1031 */         if (this.virtualHost.isEmpty()) {
/* 1032 */           this.virtualHost = "/";
/*      */         }
/* 1034 */         input = input.substring(0, hostIndex);
/*      */       } 
/* 1036 */       return input;
/*      */     }
/*      */     
/*      */     private void parseHostAndPort(String input) {
/* 1040 */       int portIndex = input.indexOf(':');
/* 1041 */       if (portIndex == -1) {
/* 1042 */         this.host = input;
/* 1043 */         this.port = this.secureConnection ? 5671 : 5672;
/*      */       } else {
/*      */         
/* 1046 */         this.host = input.substring(0, portIndex);
/* 1047 */         this.port = Integer.valueOf(input.substring(portIndex + 1)).intValue();
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\RabbitProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import org.springframework.amqp.rabbit.config.AbstractRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.config.DirectRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DirectRabbitListenerContainerFactoryConfigurer
/*    */   extends AbstractRabbitListenerContainerFactoryConfigurer<DirectRabbitListenerContainerFactory>
/*    */ {
/*    */   public void configure(DirectRabbitListenerContainerFactory factory, ConnectionFactory connectionFactory) {
/* 36 */     PropertyMapper map = PropertyMapper.get();
/* 37 */     RabbitProperties.DirectContainer config = getRabbitProperties().getListener().getDirect();
/* 38 */     configure(factory, connectionFactory, config);
/* 39 */     map.from(config::getConsumersPerQueue).whenNonNull().to(factory::setConsumersPerQueue);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\amqp\DirectRabbitListenerContainerFactoryConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.util.LambdaSafe;
/*    */ import org.springframework.cache.CacheManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheManagerCustomizers
/*    */ {
/*    */   private final List<CacheManagerCustomizer<?>> customizers;
/*    */   
/*    */   public CacheManagerCustomizers(List<? extends CacheManagerCustomizer<?>> customizers) {
/* 38 */     this.customizers = (customizers != null) ? new ArrayList<>(customizers) : Collections.<CacheManagerCustomizer<?>>emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends CacheManager> T customize(T cacheManager) {
/* 51 */     ((LambdaSafe.Callbacks)LambdaSafe.callbacks(CacheManagerCustomizer.class, this.customizers, cacheManager, new Object[0])
/* 52 */       .withLogger(CacheManagerCustomizers.class)).invoke(customizer -> customizer.customize(cacheManager));
/* 53 */     return cacheManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\CacheManagerCustomizers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
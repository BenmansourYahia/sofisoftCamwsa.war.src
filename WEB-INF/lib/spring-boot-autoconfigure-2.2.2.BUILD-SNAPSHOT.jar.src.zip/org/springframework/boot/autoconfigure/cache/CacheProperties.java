/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.cache")
/*     */ public class CacheProperties
/*     */ {
/*     */   private CacheType type;
/*  47 */   private List<String> cacheNames = new ArrayList<>();
/*     */   
/*  49 */   private final Caffeine caffeine = new Caffeine();
/*     */   
/*  51 */   private final Couchbase couchbase = new Couchbase();
/*     */   
/*  53 */   private final EhCache ehcache = new EhCache();
/*     */   
/*  55 */   private final Infinispan infinispan = new Infinispan();
/*     */   
/*  57 */   private final JCache jcache = new JCache();
/*     */   
/*  59 */   private final Redis redis = new Redis();
/*     */   
/*     */   public CacheType getType() {
/*  62 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(CacheType mode) {
/*  66 */     this.type = mode;
/*     */   }
/*     */   
/*     */   public List<String> getCacheNames() {
/*  70 */     return this.cacheNames;
/*     */   }
/*     */   
/*     */   public void setCacheNames(List<String> cacheNames) {
/*  74 */     this.cacheNames = cacheNames;
/*     */   }
/*     */   
/*     */   public Caffeine getCaffeine() {
/*  78 */     return this.caffeine;
/*     */   }
/*     */   
/*     */   public Couchbase getCouchbase() {
/*  82 */     return this.couchbase;
/*     */   }
/*     */   
/*     */   public EhCache getEhcache() {
/*  86 */     return this.ehcache;
/*     */   }
/*     */   
/*     */   public Infinispan getInfinispan() {
/*  90 */     return this.infinispan;
/*     */   }
/*     */   
/*     */   public JCache getJcache() {
/*  94 */     return this.jcache;
/*     */   }
/*     */   
/*     */   public Redis getRedis() {
/*  98 */     return this.redis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource resolveConfigLocation(Resource config) {
/* 109 */     if (config != null) {
/* 110 */       Assert.isTrue(config.exists(), () -> "Cache configuration does not exist '" + config.getDescription() + "'");
/*     */       
/* 112 */       return config;
/*     */     } 
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Caffeine
/*     */   {
/*     */     private String spec;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getSpec() {
/* 129 */       return this.spec;
/*     */     }
/*     */     
/*     */     public void setSpec(String spec) {
/* 133 */       this.spec = spec;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Couchbase
/*     */   {
/*     */     private Duration expiration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getExpiration() {
/* 150 */       return this.expiration;
/*     */     }
/*     */     
/*     */     public void setExpiration(Duration expiration) {
/* 154 */       this.expiration = expiration;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class EhCache
/*     */   {
/*     */     private Resource config;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Resource getConfig() {
/* 170 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 174 */       this.config = config;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Infinispan
/*     */   {
/*     */     private Resource config;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Resource getConfig() {
/* 190 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 194 */       this.config = config;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class JCache
/*     */   {
/*     */     private Resource config;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String provider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProvider() {
/* 218 */       return this.provider;
/*     */     }
/*     */     
/*     */     public void setProvider(String provider) {
/* 222 */       this.provider = provider;
/*     */     }
/*     */     
/*     */     public Resource getConfig() {
/* 226 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 230 */       this.config = config;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Redis
/*     */   {
/*     */     private Duration timeToLive;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean cacheNullValues = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String keyPrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean useKeyPrefix = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getTimeToLive() {
/* 261 */       return this.timeToLive;
/*     */     }
/*     */     
/*     */     public void setTimeToLive(Duration timeToLive) {
/* 265 */       this.timeToLive = timeToLive;
/*     */     }
/*     */     
/*     */     public boolean isCacheNullValues() {
/* 269 */       return this.cacheNullValues;
/*     */     }
/*     */     
/*     */     public void setCacheNullValues(boolean cacheNullValues) {
/* 273 */       this.cacheNullValues = cacheNullValues;
/*     */     }
/*     */     
/*     */     public String getKeyPrefix() {
/* 277 */       return this.keyPrefix;
/*     */     }
/*     */     
/*     */     public void setKeyPrefix(String keyPrefix) {
/* 281 */       this.keyPrefix = keyPrefix;
/*     */     }
/*     */     
/*     */     public boolean isUseKeyPrefix() {
/* 285 */       return this.useKeyPrefix;
/*     */     }
/*     */     
/*     */     public void setUseKeyPrefix(boolean useKeyPrefix) {
/* 289 */       this.useKeyPrefix = useKeyPrefix;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\CacheProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
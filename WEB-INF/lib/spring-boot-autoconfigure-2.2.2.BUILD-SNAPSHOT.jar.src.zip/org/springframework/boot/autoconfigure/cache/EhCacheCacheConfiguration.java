/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import net.sf.ehcache.Cache;
/*    */ import net.sf.ehcache.CacheManager;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ResourceCondition;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.cache.ehcache.EhCacheCacheManager;
/*    */ import org.springframework.cache.ehcache.EhCacheManagerUtils;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Cache.class, EhCacheCacheManager.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @Conditional({CacheCondition.class, EhCacheCacheConfiguration.ConfigAvailableCondition.class})
/*    */ class EhCacheCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   EhCacheCacheManager cacheManager(CacheManagerCustomizers customizers, CacheManager ehCacheCacheManager) {
/* 48 */     return customizers.<EhCacheCacheManager>customize(new EhCacheCacheManager(ehCacheCacheManager));
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   CacheManager ehCacheCacheManager(CacheProperties cacheProperties) {
/* 54 */     Resource location = cacheProperties.resolveConfigLocation(cacheProperties.getEhcache().getConfig());
/* 55 */     if (location != null) {
/* 56 */       return EhCacheManagerUtils.buildCacheManager(location);
/*    */     }
/* 58 */     return EhCacheManagerUtils.buildCacheManager();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static class ConfigAvailableCondition
/*    */     extends ResourceCondition
/*    */   {
/*    */     ConfigAvailableCondition() {
/* 69 */       super("EhCache", "spring.cache.ehcache.config", new String[] { "classpath:/ehcache.xml" });
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\EhCacheCacheConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
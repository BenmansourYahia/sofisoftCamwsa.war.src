/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.EnumMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CacheConfigurations
/*    */ {
/*    */   private static final Map<CacheType, Class<?>> MAPPINGS;
/*    */   
/*    */   static {
/* 36 */     Map<CacheType, Class<?>> mappings = new EnumMap<>(CacheType.class);
/* 37 */     mappings.put(CacheType.GENERIC, GenericCacheConfiguration.class);
/* 38 */     mappings.put(CacheType.EHCACHE, EhCacheCacheConfiguration.class);
/* 39 */     mappings.put(CacheType.HAZELCAST, HazelcastCacheConfiguration.class);
/* 40 */     mappings.put(CacheType.INFINISPAN, InfinispanCacheConfiguration.class);
/* 41 */     mappings.put(CacheType.JCACHE, JCacheCacheConfiguration.class);
/* 42 */     mappings.put(CacheType.COUCHBASE, CouchbaseCacheConfiguration.class);
/* 43 */     mappings.put(CacheType.REDIS, RedisCacheConfiguration.class);
/* 44 */     mappings.put(CacheType.CAFFEINE, CaffeineCacheConfiguration.class);
/* 45 */     mappings.put(CacheType.SIMPLE, SimpleCacheConfiguration.class);
/* 46 */     mappings.put(CacheType.NONE, NoOpCacheConfiguration.class);
/* 47 */     MAPPINGS = Collections.unmodifiableMap(mappings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String getConfigurationClass(CacheType cacheType) {
/* 54 */     Class<?> configurationClass = MAPPINGS.get(cacheType);
/* 55 */     Assert.state((configurationClass != null), () -> "Unknown cache type " + cacheType);
/* 56 */     return configurationClass.getName();
/*    */   }
/*    */   
/*    */   static CacheType getType(String configurationClassName) {
/* 60 */     for (Map.Entry<CacheType, Class<?>> entry : MAPPINGS.entrySet()) {
/* 61 */       if (((Class)entry.getValue()).getName().equals(configurationClassName)) {
/* 62 */         return entry.getKey();
/*    */       }
/*    */     } 
/* 65 */     throw new IllegalStateException("Unknown configuration class " + configurationClassName);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\CacheConfigurations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
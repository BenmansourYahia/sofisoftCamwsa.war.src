/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CacheType
/*    */ {
/* 32 */   GENERIC,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   JCACHE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   EHCACHE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   HAZELCAST,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   INFINISPAN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   COUCHBASE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   REDIS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   CAFFEINE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   SIMPLE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   NONE;
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\CacheType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
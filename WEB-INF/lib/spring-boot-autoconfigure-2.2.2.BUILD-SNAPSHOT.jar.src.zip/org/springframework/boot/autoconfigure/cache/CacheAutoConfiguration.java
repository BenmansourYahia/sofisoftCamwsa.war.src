/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.couchbase.CouchbaseAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.data.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.hazelcast.HazelcastAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.cache.interceptor.CacheAspectSupport;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportSelector;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({CacheManager.class})
/*     */ @ConditionalOnBean({CacheAspectSupport.class})
/*     */ @ConditionalOnMissingBean(value = {CacheManager.class}, name = {"cacheResolver"})
/*     */ @EnableConfigurationProperties({CacheProperties.class})
/*     */ @AutoConfigureAfter({CouchbaseAutoConfiguration.class, HazelcastAutoConfiguration.class, HibernateJpaAutoConfiguration.class, RedisAutoConfiguration.class})
/*     */ @Import({CacheAutoConfiguration.CacheConfigurationImportSelector.class, CacheAutoConfiguration.CacheManagerEntityManagerFactoryDependsOnPostProcessor.class})
/*     */ public class CacheAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CacheManagerCustomizers cacheManagerCustomizers(ObjectProvider<CacheManagerCustomizer<?>> customizers) {
/*  72 */     return new CacheManagerCustomizers((List<? extends CacheManagerCustomizer<?>>)customizers.orderedStream().collect(Collectors.toList()));
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public CacheManagerValidator cacheAutoConfigurationValidator(CacheProperties cacheProperties, ObjectProvider<CacheManager> cacheManager) {
/*  78 */     return new CacheManagerValidator(cacheProperties, cacheManager);
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   static class CacheManagerEntityManagerFactoryDependsOnPostProcessor
/*     */     extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     CacheManagerEntityManagerFactoryDependsOnPostProcessor() {
/*  87 */       super(new String[] { "cacheManager" });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CacheManagerValidator
/*     */     implements InitializingBean
/*     */   {
/*     */     private final CacheProperties cacheProperties;
/*     */ 
/*     */     
/*     */     private final ObjectProvider<CacheManager> cacheManager;
/*     */ 
/*     */     
/*     */     CacheManagerValidator(CacheProperties cacheProperties, ObjectProvider<CacheManager> cacheManager) {
/* 103 */       this.cacheProperties = cacheProperties;
/* 104 */       this.cacheManager = cacheManager;
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterPropertiesSet() {
/* 109 */       Assert.notNull(this.cacheManager.getIfAvailable(), () -> "No cache manager could be auto-configured, check your configuration (caching type is '" + this.cacheProperties.getType() + "')");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class CacheConfigurationImportSelector
/*     */     implements ImportSelector
/*     */   {
/*     */     public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 123 */       CacheType[] types = CacheType.values();
/* 124 */       String[] imports = new String[types.length];
/* 125 */       for (int i = 0; i < types.length; i++) {
/* 126 */         imports[i] = CacheConfigurations.getConfigurationClass(types[i]);
/*     */       }
/* 128 */       return imports;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\CacheAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
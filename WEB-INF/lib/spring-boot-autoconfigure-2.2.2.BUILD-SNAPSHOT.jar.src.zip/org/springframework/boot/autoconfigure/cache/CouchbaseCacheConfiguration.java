/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import com.couchbase.client.java.Bucket;
/*    */ import com.couchbase.client.spring.cache.CacheBuilder;
/*    */ import com.couchbase.client.spring.cache.CouchbaseCacheManager;
/*    */ import java.time.Duration;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Bucket.class, CouchbaseCacheManager.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @ConditionalOnSingleCandidate(Bucket.class)
/*    */ @Conditional({CacheCondition.class})
/*    */ public class CouchbaseCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   public CouchbaseCacheManager cacheManager(CacheProperties cacheProperties, CacheManagerCustomizers customizers, Bucket bucket) {
/* 53 */     List<String> cacheNames = cacheProperties.getCacheNames();
/* 54 */     CacheBuilder builder = CacheBuilder.newInstance(bucket);
/* 55 */     CacheProperties.Couchbase couchbase = cacheProperties.getCouchbase();
/* 56 */     PropertyMapper.get().from(couchbase::getExpiration).whenNonNull().asInt(Duration::getSeconds)
/* 57 */       .to(builder::withExpiration);
/* 58 */     String[] names = StringUtils.toStringArray(cacheNames);
/* 59 */     CouchbaseCacheManager cacheManager = new CouchbaseCacheManager(builder, names);
/* 60 */     return customizers.<CouchbaseCacheManager>customize(cacheManager);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\CouchbaseCacheConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
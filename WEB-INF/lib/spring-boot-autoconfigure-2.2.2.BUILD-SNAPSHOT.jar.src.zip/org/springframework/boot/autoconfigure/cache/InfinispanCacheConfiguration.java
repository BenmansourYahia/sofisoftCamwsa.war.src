/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.List;
/*    */ import org.infinispan.configuration.cache.Configuration;
/*    */ import org.infinispan.configuration.cache.ConfigurationBuilder;
/*    */ import org.infinispan.manager.DefaultCacheManager;
/*    */ import org.infinispan.manager.EmbeddedCacheManager;
/*    */ import org.infinispan.spring.embedded.provider.SpringEmbeddedCacheManager;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({SpringEmbeddedCacheManager.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @Conditional({CacheCondition.class})
/*    */ public class InfinispanCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   public SpringEmbeddedCacheManager cacheManager(CacheManagerCustomizers customizers, EmbeddedCacheManager embeddedCacheManager) {
/* 55 */     SpringEmbeddedCacheManager cacheManager = new SpringEmbeddedCacheManager(embeddedCacheManager);
/* 56 */     return customizers.<SpringEmbeddedCacheManager>customize(cacheManager);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean(destroyMethod = "stop")
/*    */   @ConditionalOnMissingBean
/*    */   public EmbeddedCacheManager infinispanCacheManager(CacheProperties cacheProperties, ObjectProvider<ConfigurationBuilder> defaultConfigurationBuilder) throws IOException {
/* 63 */     EmbeddedCacheManager cacheManager = createEmbeddedCacheManager(cacheProperties);
/* 64 */     List<String> cacheNames = cacheProperties.getCacheNames();
/* 65 */     if (!CollectionUtils.isEmpty(cacheNames)) {
/* 66 */       cacheNames.forEach(cacheName -> cacheManager.defineConfiguration(cacheName, getDefaultCacheConfiguration((ConfigurationBuilder)defaultConfigurationBuilder.getIfAvailable())));
/*    */     }
/*    */     
/* 69 */     return cacheManager;
/*    */   }
/*    */   
/*    */   private EmbeddedCacheManager createEmbeddedCacheManager(CacheProperties cacheProperties) throws IOException {
/* 73 */     Resource location = cacheProperties.resolveConfigLocation(cacheProperties.getInfinispan().getConfig());
/* 74 */     if (location != null) {
/* 75 */       try (InputStream in = location.getInputStream()) {
/* 76 */         return (EmbeddedCacheManager)new DefaultCacheManager(in);
/*    */       } 
/*    */     }
/* 79 */     return (EmbeddedCacheManager)new DefaultCacheManager();
/*    */   }
/*    */ 
/*    */   
/*    */   private Configuration getDefaultCacheConfiguration(ConfigurationBuilder defaultConfigurationBuilder) {
/* 84 */     if (defaultConfigurationBuilder != null) {
/* 85 */       return defaultConfigurationBuilder.build();
/*    */     }
/* 87 */     return (new ConfigurationBuilder()).build();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\InfinispanCacheConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
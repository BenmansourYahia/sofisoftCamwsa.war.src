/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.data.redis.cache.RedisCacheManager;
/*    */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*    */ import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
/*    */ import org.springframework.data.redis.serializer.RedisSerializationContext;
/*    */ import org.springframework.data.redis.serializer.RedisSerializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({RedisConnectionFactory.class})
/*    */ @AutoConfigureAfter({RedisAutoConfiguration.class})
/*    */ @ConditionalOnBean({RedisConnectionFactory.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @Conditional({CacheCondition.class})
/*    */ class RedisCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   RedisCacheManager cacheManager(CacheProperties cacheProperties, CacheManagerCustomizers cacheManagerCustomizers, ObjectProvider<org.springframework.data.redis.cache.RedisCacheConfiguration> redisCacheConfiguration, ObjectProvider<RedisCacheManagerBuilderCustomizer> redisCacheManagerBuilderCustomizers, RedisConnectionFactory redisConnectionFactory, ResourceLoader resourceLoader) {
/* 60 */     RedisCacheManager.RedisCacheManagerBuilder builder = RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(
/* 61 */         determineConfiguration(cacheProperties, redisCacheConfiguration, resourceLoader.getClassLoader()));
/* 62 */     List<String> cacheNames = cacheProperties.getCacheNames();
/* 63 */     if (!cacheNames.isEmpty()) {
/* 64 */       builder.initialCacheNames(new LinkedHashSet<>(cacheNames));
/*    */     }
/* 66 */     redisCacheManagerBuilderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 67 */     return cacheManagerCustomizers.<RedisCacheManager>customize(builder.build());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private org.springframework.data.redis.cache.RedisCacheConfiguration determineConfiguration(CacheProperties cacheProperties, ObjectProvider<org.springframework.data.redis.cache.RedisCacheConfiguration> redisCacheConfiguration, ClassLoader classLoader) {
/* 74 */     return (org.springframework.data.redis.cache.RedisCacheConfiguration)redisCacheConfiguration.getIfAvailable(() -> createConfiguration(cacheProperties, classLoader));
/*    */   }
/*    */ 
/*    */   
/*    */   private org.springframework.data.redis.cache.RedisCacheConfiguration createConfiguration(CacheProperties cacheProperties, ClassLoader classLoader) {
/* 79 */     CacheProperties.Redis redisProperties = cacheProperties.getRedis();
/*    */     
/* 81 */     org.springframework.data.redis.cache.RedisCacheConfiguration config = org.springframework.data.redis.cache.RedisCacheConfiguration.defaultCacheConfig();
/* 82 */     config = config.serializeValuesWith(
/* 83 */         RedisSerializationContext.SerializationPair.fromSerializer((RedisSerializer)new JdkSerializationRedisSerializer(classLoader)));
/* 84 */     if (redisProperties.getTimeToLive() != null) {
/* 85 */       config = config.entryTtl(redisProperties.getTimeToLive());
/*    */     }
/* 87 */     if (redisProperties.getKeyPrefix() != null) {
/* 88 */       config = config.prefixKeysWith(redisProperties.getKeyPrefix());
/*    */     }
/* 90 */     if (!redisProperties.isCacheNullValues()) {
/* 91 */       config = config.disableCachingNullValues();
/*    */     }
/* 93 */     if (!redisProperties.isUseKeyPrefix()) {
/* 94 */       config = config.disableKeyPrefix();
/*    */     }
/* 96 */     return config;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\RedisCacheConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
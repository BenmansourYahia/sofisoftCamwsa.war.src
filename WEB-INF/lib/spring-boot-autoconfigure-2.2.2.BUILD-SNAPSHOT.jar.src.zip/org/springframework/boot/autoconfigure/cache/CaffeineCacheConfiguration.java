/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import com.github.benmanes.caffeine.cache.CacheLoader;
/*    */ import com.github.benmanes.caffeine.cache.Caffeine;
/*    */ import com.github.benmanes.caffeine.cache.CaffeineSpec;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.cache.caffeine.CaffeineCacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Caffeine.class, CaffeineCacheManager.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @Conditional({CacheCondition.class})
/*    */ class CaffeineCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   CaffeineCacheManager cacheManager(CacheProperties cacheProperties, CacheManagerCustomizers customizers, ObjectProvider<Caffeine<Object, Object>> caffeine, ObjectProvider<CaffeineSpec> caffeineSpec, ObjectProvider<CacheLoader<Object, Object>> cacheLoader) {
/* 51 */     CaffeineCacheManager cacheManager = createCacheManager(cacheProperties, caffeine, caffeineSpec, cacheLoader);
/* 52 */     List<String> cacheNames = cacheProperties.getCacheNames();
/* 53 */     if (!CollectionUtils.isEmpty(cacheNames)) {
/* 54 */       cacheManager.setCacheNames(cacheNames);
/*    */     }
/* 56 */     return customizers.<CaffeineCacheManager>customize(cacheManager);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private CaffeineCacheManager createCacheManager(CacheProperties cacheProperties, ObjectProvider<Caffeine<Object, Object>> caffeine, ObjectProvider<CaffeineSpec> caffeineSpec, ObjectProvider<CacheLoader<Object, Object>> cacheLoader) {
/* 62 */     CaffeineCacheManager cacheManager = new CaffeineCacheManager();
/* 63 */     setCacheBuilder(cacheProperties, (CaffeineSpec)caffeineSpec.getIfAvailable(), (Caffeine<Object, Object>)caffeine.getIfAvailable(), cacheManager);
/* 64 */     cacheLoader.ifAvailable(cacheManager::setCacheLoader);
/* 65 */     return cacheManager;
/*    */   }
/*    */ 
/*    */   
/*    */   private void setCacheBuilder(CacheProperties cacheProperties, CaffeineSpec caffeineSpec, Caffeine<Object, Object> caffeine, CaffeineCacheManager cacheManager) {
/* 70 */     String specification = cacheProperties.getCaffeine().getSpec();
/* 71 */     if (StringUtils.hasText(specification)) {
/* 72 */       cacheManager.setCacheSpecification(specification);
/*    */     }
/* 74 */     else if (caffeineSpec != null) {
/* 75 */       cacheManager.setCaffeineSpec(caffeineSpec);
/*    */     }
/* 77 */     else if (caffeine != null) {
/* 78 */       cacheManager.setCaffeine(caffeine);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cache\CaffeineCacheConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.h2;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import javax.servlet.Servlet;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.h2.server.web.WebServlet;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnClass({WebServlet.class})
/*    */ @ConditionalOnProperty(prefix = "spring.h2.console", name = {"enabled"}, havingValue = "true", matchIfMissing = false)
/*    */ @AutoConfigureAfter({DataSourceAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({H2ConsoleProperties.class})
/*    */ public class H2ConsoleAutoConfiguration
/*    */ {
/* 57 */   private static final Log logger = LogFactory.getLog(H2ConsoleAutoConfiguration.class);
/*    */ 
/*    */   
/*    */   @Bean
/*    */   public ServletRegistrationBean<WebServlet> h2Console(H2ConsoleProperties properties, ObjectProvider<DataSource> dataSource) {
/* 62 */     String path = properties.getPath();
/* 63 */     String urlMapping = path + (path.endsWith("/") ? "*" : "/*");
/* 64 */     ServletRegistrationBean<WebServlet> registration = new ServletRegistrationBean((Servlet)new WebServlet(), new String[] { urlMapping });
/* 65 */     H2ConsoleProperties.Settings settings = properties.getSettings();
/* 66 */     if (settings.isTrace()) {
/* 67 */       registration.addInitParameter("trace", "");
/*    */     }
/* 69 */     if (settings.isWebAllowOthers()) {
/* 70 */       registration.addInitParameter("webAllowOthers", "");
/*    */     }
/* 72 */     dataSource.ifAvailable(available -> {
/*    */ 
/*    */           
/*    */           try (Connection connection = available.getConnection()) {
/*    */             logger.info("H2 console available at '" + path + "'. Database available at '" + connection.getMetaData().getURL() + "'");
/* 77 */           } catch (SQLException sQLException) {}
/*    */         });
/*    */ 
/*    */     
/* 81 */     return registration;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\h2\H2ConsoleAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
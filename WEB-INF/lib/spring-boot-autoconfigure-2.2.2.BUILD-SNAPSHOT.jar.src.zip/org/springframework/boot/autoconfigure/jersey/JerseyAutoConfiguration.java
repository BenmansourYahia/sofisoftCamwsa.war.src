/*     */ package org.springframework.boot.autoconfigure.jersey;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRegistration;
/*     */ import javax.ws.rs.ext.ContextResolver;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.glassfish.jersey.jackson.JacksonFeature;
/*     */ import org.glassfish.jersey.server.ResourceConfig;
/*     */ import org.glassfish.jersey.server.spring.SpringComponentProvider;
/*     */ import org.glassfish.jersey.servlet.ServletContainer;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.ConditionalOnMissingFilterBean;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.DefaultJerseyApplicationPath;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.DispatcherServletAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.JerseyApplicationPath;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.DynamicRegistrationBean;
/*     */ import org.springframework.boot.web.servlet.FilterRegistrationBean;
/*     */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.WebApplicationInitializer;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.filter.RequestContextFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({SpringComponentProvider.class, ServletRegistration.class})
/*     */ @ConditionalOnBean(type = {"org.glassfish.jersey.server.ResourceConfig"})
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @AutoConfigureOrder(-2147483648)
/*     */ @AutoConfigureBefore({DispatcherServletAutoConfiguration.class})
/*     */ @AutoConfigureAfter({JacksonAutoConfiguration.class})
/*     */ @EnableConfigurationProperties({JerseyProperties.class})
/*     */ public class JerseyAutoConfiguration
/*     */   implements ServletContextAware
/*     */ {
/*  92 */   private static final Log logger = LogFactory.getLog(JerseyAutoConfiguration.class);
/*     */   
/*     */   private final JerseyProperties jersey;
/*     */   
/*     */   private final ResourceConfig config;
/*     */   
/*     */   private final ObjectProvider<ResourceConfigCustomizer> customizers;
/*     */ 
/*     */   
/*     */   public JerseyAutoConfiguration(JerseyProperties jersey, ResourceConfig config, ObjectProvider<ResourceConfigCustomizer> customizers) {
/* 102 */     this.jersey = jersey;
/* 103 */     this.config = config;
/* 104 */     this.customizers = customizers;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void path() {
/* 109 */     customize();
/*     */   }
/*     */   
/*     */   private void customize() {
/* 113 */     this.customizers.orderedStream().forEach(customizer -> customizer.customize(this.config));
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingFilterBean({RequestContextFilter.class})
/*     */   public FilterRegistrationBean<RequestContextFilter> requestContextFilter() {
/* 119 */     FilterRegistrationBean<RequestContextFilter> registration = new FilterRegistrationBean();
/* 120 */     registration.setFilter((Filter)new RequestContextFilter());
/* 121 */     registration.setOrder(this.jersey.getFilter().getOrder() - 1);
/* 122 */     registration.setName("requestContextFilter");
/* 123 */     return registration;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public JerseyApplicationPath jerseyApplicationPath() {
/* 129 */     return (JerseyApplicationPath)new DefaultJerseyApplicationPath(this.jersey.getApplicationPath(), this.config);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(name = {"jerseyFilterRegistration"})
/*     */   @ConditionalOnProperty(prefix = "spring.jersey", name = {"type"}, havingValue = "filter")
/*     */   public FilterRegistrationBean<ServletContainer> jerseyFilterRegistration(JerseyApplicationPath applicationPath) {
/* 136 */     FilterRegistrationBean<ServletContainer> registration = new FilterRegistrationBean();
/* 137 */     registration.setFilter((Filter)new ServletContainer(this.config));
/* 138 */     registration.setUrlPatterns(Collections.singletonList(applicationPath.getUrlMapping()));
/* 139 */     registration.setOrder(this.jersey.getFilter().getOrder());
/* 140 */     registration.addInitParameter("jersey.config.servlet.filter.contextPath", stripPattern(applicationPath.getPath()));
/* 141 */     addInitParameters((DynamicRegistrationBean<?>)registration);
/* 142 */     registration.setName("jerseyFilter");
/* 143 */     registration.setDispatcherTypes(EnumSet.allOf(DispatcherType.class));
/* 144 */     return registration;
/*     */   }
/*     */   
/*     */   private String stripPattern(String path) {
/* 148 */     if (path.endsWith("/*")) {
/* 149 */       path = path.substring(0, path.lastIndexOf("/*"));
/*     */     }
/* 151 */     return path;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(name = {"jerseyServletRegistration"})
/*     */   @ConditionalOnProperty(prefix = "spring.jersey", name = {"type"}, havingValue = "servlet", matchIfMissing = true)
/*     */   public ServletRegistrationBean<ServletContainer> jerseyServletRegistration(JerseyApplicationPath applicationPath) {
/* 159 */     ServletRegistrationBean<ServletContainer> registration = new ServletRegistrationBean((Servlet)new ServletContainer(this.config), new String[] { applicationPath.getUrlMapping() });
/* 160 */     addInitParameters((DynamicRegistrationBean<?>)registration);
/* 161 */     registration.setName(getServletRegistrationName());
/* 162 */     registration.setLoadOnStartup(this.jersey.getServlet().getLoadOnStartup());
/* 163 */     return registration;
/*     */   }
/*     */   
/*     */   private String getServletRegistrationName() {
/* 167 */     return ClassUtils.getUserClass(this.config.getClass()).getName();
/*     */   }
/*     */   
/*     */   private void addInitParameters(DynamicRegistrationBean<?> registration) {
/* 171 */     this.jersey.getInit().forEach(registration::addInitParameter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServletContext(ServletContext servletContext) {
/* 176 */     String servletRegistrationName = getServletRegistrationName();
/* 177 */     ServletRegistration registration = servletContext.getServletRegistration(servletRegistrationName);
/* 178 */     if (registration != null) {
/* 179 */       if (logger.isInfoEnabled()) {
/* 180 */         logger.info("Configuring existing registration for Jersey servlet '" + servletRegistrationName + "'");
/*     */       }
/* 182 */       registration.setInitParameters(this.jersey.getInit());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Order(-2147483648)
/*     */   public static final class JerseyWebApplicationInitializer
/*     */     implements WebApplicationInitializer
/*     */   {
/*     */     public void onStartup(ServletContext servletContext) throws ServletException {
/* 193 */       servletContext.setInitParameter("contextConfigLocation", "<NONE>");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({JacksonFeature.class})
/*     */   @ConditionalOnSingleCandidate(ObjectMapper.class)
/*     */   static class JacksonResourceConfigCustomizer
/*     */   {
/*     */     @Bean
/*     */     ResourceConfigCustomizer resourceConfigCustomizer(ObjectMapper objectMapper) {
/* 205 */       return config -> {
/*     */           config.register(JacksonFeature.class);
/*     */           config.register(new ObjectMapperContextResolver(objectMapper), new Class[] { ContextResolver.class });
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     @ConditionalOnClass({JaxbAnnotationIntrospector.class, XmlElement.class})
/*     */     static class JaxbObjectMapperCustomizer
/*     */     {
/*     */       @Autowired
/*     */       void addJaxbAnnotationIntrospector(ObjectMapper objectMapper) {
/* 218 */         JaxbAnnotationIntrospector jaxbAnnotationIntrospector = new JaxbAnnotationIntrospector(objectMapper.getTypeFactory());
/* 219 */         objectMapper.setAnnotationIntrospectors(
/* 220 */             createPair((MapperConfig<?>)objectMapper.getSerializationConfig(), jaxbAnnotationIntrospector), 
/* 221 */             createPair((MapperConfig<?>)objectMapper.getDeserializationConfig(), jaxbAnnotationIntrospector));
/*     */       }
/*     */ 
/*     */       
/*     */       private AnnotationIntrospector createPair(MapperConfig<?> config, JaxbAnnotationIntrospector jaxbAnnotationIntrospector) {
/* 226 */         return AnnotationIntrospector.pair(config.getAnnotationIntrospector(), (AnnotationIntrospector)jaxbAnnotationIntrospector);
/*     */       }
/*     */     }
/*     */     
/*     */     private static final class ObjectMapperContextResolver
/*     */       implements ContextResolver<ObjectMapper>
/*     */     {
/*     */       private final ObjectMapper objectMapper;
/*     */       
/*     */       private ObjectMapperContextResolver(ObjectMapper objectMapper) {
/* 236 */         this.objectMapper = objectMapper;
/*     */       }
/*     */ 
/*     */       
/*     */       public ObjectMapper getContext(Class<?> type) {
/* 241 */         return this.objectMapper;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jersey\JerseyAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
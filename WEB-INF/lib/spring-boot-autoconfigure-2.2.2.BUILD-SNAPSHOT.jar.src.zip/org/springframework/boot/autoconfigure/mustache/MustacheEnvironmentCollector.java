/*    */ package org.springframework.boot.autoconfigure.mustache;
/*    */ 
/*    */ import com.samskivert.mustache.DefaultCollector;
/*    */ import com.samskivert.mustache.Mustache;
/*    */ import org.springframework.context.EnvironmentAware;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MustacheEnvironmentCollector
/*    */   extends DefaultCollector
/*    */   implements EnvironmentAware
/*    */ {
/*    */   private ConfigurableEnvironment environment;
/* 38 */   private final Mustache.VariableFetcher propertyFetcher = new PropertyVariableFetcher();
/*    */ 
/*    */   
/*    */   public void setEnvironment(Environment environment) {
/* 42 */     this.environment = (ConfigurableEnvironment)environment;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mustache.VariableFetcher createFetcher(Object ctx, String name) {
/* 47 */     Mustache.VariableFetcher fetcher = super.createFetcher(ctx, name);
/* 48 */     if (fetcher != null) {
/* 49 */       return fetcher;
/*    */     }
/* 51 */     if (this.environment.containsProperty(name)) {
/* 52 */       return this.propertyFetcher;
/*    */     }
/* 54 */     return null;
/*    */   }
/*    */   
/*    */   private class PropertyVariableFetcher implements Mustache.VariableFetcher {
/*    */     private PropertyVariableFetcher() {}
/*    */     
/*    */     public Object get(Object ctx, String name) {
/* 61 */       return MustacheEnvironmentCollector.this.environment.getProperty(name);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mustache\MustacheEnvironmentCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
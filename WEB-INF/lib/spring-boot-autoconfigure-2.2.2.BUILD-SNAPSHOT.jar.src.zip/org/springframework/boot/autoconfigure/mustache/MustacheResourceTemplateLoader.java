/*    */ package org.springframework.boot.autoconfigure.mustache;
/*    */ 
/*    */ import com.samskivert.mustache.Mustache;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import org.springframework.context.ResourceLoaderAware;
/*    */ import org.springframework.core.io.DefaultResourceLoader;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MustacheResourceTemplateLoader
/*    */   implements Mustache.TemplateLoader, ResourceLoaderAware
/*    */ {
/* 44 */   private String prefix = "";
/*    */   
/* 46 */   private String suffix = "";
/*    */   
/* 48 */   private String charSet = "UTF-8";
/*    */   
/* 50 */   private ResourceLoader resourceLoader = (ResourceLoader)new DefaultResourceLoader();
/*    */ 
/*    */   
/*    */   public MustacheResourceTemplateLoader() {}
/*    */   
/*    */   public MustacheResourceTemplateLoader(String prefix, String suffix) {
/* 56 */     this.prefix = prefix;
/* 57 */     this.suffix = suffix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCharset(String charSet) {
/* 65 */     this.charSet = charSet;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 74 */     this.resourceLoader = resourceLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public Reader getTemplate(String name) throws Exception {
/* 79 */     return new InputStreamReader(this.resourceLoader.getResource(this.prefix + name + this.suffix).getInputStream(), this.charSet);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mustache\MustacheResourceTemplateLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.mustache;
/*    */ 
/*    */ import com.samskivert.mustache.Mustache;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.web.servlet.view.MustacheViewResolver;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ class MustacheServletWebConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   MustacheViewResolver mustacheViewResolver(Mustache.Compiler mustacheCompiler, MustacheProperties mustache) {
/* 36 */     MustacheViewResolver resolver = new MustacheViewResolver(mustacheCompiler);
/* 37 */     mustache.applyToMvcViewResolver(resolver);
/* 38 */     resolver.setCharset(mustache.getCharsetName());
/* 39 */     resolver.setOrder(2147483637);
/* 40 */     return resolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mustache\MustacheServletWebConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
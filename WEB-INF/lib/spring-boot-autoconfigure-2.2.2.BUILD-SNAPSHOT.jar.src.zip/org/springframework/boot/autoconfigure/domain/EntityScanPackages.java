/*     */ package org.springframework.boot.autoconfigure.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityScanPackages
/*     */ {
/*  51 */   private static final String BEAN = EntityScanPackages.class.getName();
/*     */   
/*  53 */   private static final EntityScanPackages NONE = new EntityScanPackages(new String[0]);
/*     */   
/*     */   private final List<String> packageNames;
/*     */   
/*     */   EntityScanPackages(String... packageNames) {
/*  58 */     List<String> packages = new ArrayList<>();
/*  59 */     for (String name : packageNames) {
/*  60 */       if (StringUtils.hasText(name)) {
/*  61 */         packages.add(name);
/*     */       }
/*     */     } 
/*  64 */     this.packageNames = Collections.unmodifiableList(packages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getPackageNames() {
/*  73 */     return this.packageNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityScanPackages get(BeanFactory beanFactory) {
/*     */     try {
/*  85 */       return (EntityScanPackages)beanFactory.getBean(BEAN, EntityScanPackages.class);
/*     */     }
/*  87 */     catch (NoSuchBeanDefinitionException ex) {
/*  88 */       return NONE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(BeanDefinitionRegistry registry, String... packageNames) {
/*  98 */     Assert.notNull(registry, "Registry must not be null");
/*  99 */     Assert.notNull(packageNames, "PackageNames must not be null");
/* 100 */     register(registry, Arrays.asList(packageNames));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(BeanDefinitionRegistry registry, Collection<String> packageNames) {
/* 109 */     Assert.notNull(registry, "Registry must not be null");
/* 110 */     Assert.notNull(packageNames, "PackageNames must not be null");
/* 111 */     if (registry.containsBeanDefinition(BEAN)) {
/* 112 */       BeanDefinition beanDefinition = registry.getBeanDefinition(BEAN);
/* 113 */       ConstructorArgumentValues constructorArguments = beanDefinition.getConstructorArgumentValues();
/* 114 */       constructorArguments.addIndexedArgumentValue(0, addPackageNames(constructorArguments, packageNames));
/*     */     } else {
/*     */       
/* 117 */       GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 118 */       beanDefinition.setBeanClass(EntityScanPackages.class);
/* 119 */       beanDefinition.getConstructorArgumentValues().addIndexedArgumentValue(0, 
/* 120 */           StringUtils.toStringArray(packageNames));
/* 121 */       beanDefinition.setRole(2);
/* 122 */       registry.registerBeanDefinition(BEAN, (BeanDefinition)beanDefinition);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String[] addPackageNames(ConstructorArgumentValues constructorArguments, Collection<String> packageNames) {
/* 128 */     String[] existing = (String[])constructorArguments.getIndexedArgumentValue(0, String[].class).getValue();
/* 129 */     Set<String> merged = new LinkedHashSet<>();
/* 130 */     merged.addAll(Arrays.asList(existing));
/* 131 */     merged.addAll(packageNames);
/* 132 */     return StringUtils.toStringArray(merged);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Registrar
/*     */     implements ImportBeanDefinitionRegistrar
/*     */   {
/*     */     public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
/* 143 */       EntityScanPackages.register(registry, getPackagesToScan(metadata));
/*     */     }
/*     */ 
/*     */     
/*     */     private Set<String> getPackagesToScan(AnnotationMetadata metadata) {
/* 148 */       AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(EntityScan.class.getName()));
/* 149 */       String[] basePackages = attributes.getStringArray("basePackages");
/* 150 */       Class<?>[] basePackageClasses = attributes.getClassArray("basePackageClasses");
/* 151 */       Set<String> packagesToScan = new LinkedHashSet<>(Arrays.asList(basePackages));
/* 152 */       for (Class<?> basePackageClass : basePackageClasses) {
/* 153 */         packagesToScan.add(ClassUtils.getPackageName(basePackageClass));
/*     */       }
/* 155 */       if (packagesToScan.isEmpty()) {
/* 156 */         String packageName = ClassUtils.getPackageName(metadata.getClassName());
/* 157 */         Assert.state(!StringUtils.isEmpty(packageName), "@EntityScan cannot be used with the default package");
/* 158 */         return Collections.singleton(packageName);
/*     */       } 
/* 160 */       return packagesToScan;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\domain\EntityScanPackages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
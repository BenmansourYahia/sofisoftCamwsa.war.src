/*    */ package org.springframework.boot.autoconfigure.domain;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*    */ import org.springframework.core.type.filter.TypeFilter;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityScanner
/*    */ {
/*    */   private final ApplicationContext context;
/*    */   
/*    */   public EntityScanner(ApplicationContext context) {
/* 50 */     Assert.notNull(context, "Context must not be null");
/* 51 */     this.context = context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SafeVarargs
/*    */   public final Set<Class<?>> scan(Class<? extends Annotation>... annotationTypes) throws ClassNotFoundException {
/* 62 */     List<String> packages = getPackages();
/* 63 */     if (packages.isEmpty()) {
/* 64 */       return Collections.emptySet();
/*    */     }
/* 66 */     ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
/* 67 */     scanner.setEnvironment(this.context.getEnvironment());
/* 68 */     scanner.setResourceLoader((ResourceLoader)this.context);
/* 69 */     for (Class<? extends Annotation> annotationType : annotationTypes) {
/* 70 */       scanner.addIncludeFilter((TypeFilter)new AnnotationTypeFilter(annotationType));
/*    */     }
/* 72 */     Set<Class<?>> entitySet = new HashSet<>();
/* 73 */     for (String basePackage : packages) {
/* 74 */       if (StringUtils.hasText(basePackage)) {
/* 75 */         for (BeanDefinition candidate : scanner.findCandidateComponents(basePackage)) {
/* 76 */           entitySet.add(ClassUtils.forName(candidate.getBeanClassName(), this.context.getClassLoader()));
/*    */         }
/*    */       }
/*    */     } 
/* 80 */     return entitySet;
/*    */   }
/*    */   
/*    */   private List<String> getPackages() {
/* 84 */     List<String> packages = EntityScanPackages.get((BeanFactory)this.context).getPackageNames();
/* 85 */     if (packages.isEmpty() && AutoConfigurationPackages.has((BeanFactory)this.context)) {
/* 86 */       packages = AutoConfigurationPackages.get((BeanFactory)this.context);
/*    */     }
/* 88 */     return packages;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\domain\EntityScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
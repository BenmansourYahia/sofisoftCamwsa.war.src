/*     */ package org.springframework.boot.autoconfigure.liquibase;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.liquibase", ignoreUnknownFields = false)
/*     */ public class LiquibaseProperties
/*     */ {
/*  39 */   private String changeLog = "classpath:/db/changelog/db.changelog-master.yaml";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String contexts;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String defaultSchema;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String liquibaseSchema;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String liquibaseTablespace;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private String databaseChangeLogTable = "DATABASECHANGELOG";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private String databaseChangeLogLockTable = "DATABASECHANGELOGLOCK";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dropFirst;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String user;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String labels;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> parameters;
/*     */ 
/*     */ 
/*     */   
/*     */   private File rollbackFile;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean testRollbackOnUpdate;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChangeLog() {
/* 118 */     return this.changeLog;
/*     */   }
/*     */   
/*     */   public void setChangeLog(String changeLog) {
/* 122 */     Assert.notNull(changeLog, "ChangeLog must not be null");
/* 123 */     this.changeLog = changeLog;
/*     */   }
/*     */   
/*     */   public String getContexts() {
/* 127 */     return this.contexts;
/*     */   }
/*     */   
/*     */   public void setContexts(String contexts) {
/* 131 */     this.contexts = contexts;
/*     */   }
/*     */   
/*     */   public String getDefaultSchema() {
/* 135 */     return this.defaultSchema;
/*     */   }
/*     */   
/*     */   public void setDefaultSchema(String defaultSchema) {
/* 139 */     this.defaultSchema = defaultSchema;
/*     */   }
/*     */   
/*     */   public String getLiquibaseSchema() {
/* 143 */     return this.liquibaseSchema;
/*     */   }
/*     */   
/*     */   public void setLiquibaseSchema(String liquibaseSchema) {
/* 147 */     this.liquibaseSchema = liquibaseSchema;
/*     */   }
/*     */   
/*     */   public String getLiquibaseTablespace() {
/* 151 */     return this.liquibaseTablespace;
/*     */   }
/*     */   
/*     */   public void setLiquibaseTablespace(String liquibaseTablespace) {
/* 155 */     this.liquibaseTablespace = liquibaseTablespace;
/*     */   }
/*     */   
/*     */   public String getDatabaseChangeLogTable() {
/* 159 */     return this.databaseChangeLogTable;
/*     */   }
/*     */   
/*     */   public void setDatabaseChangeLogTable(String databaseChangeLogTable) {
/* 163 */     this.databaseChangeLogTable = databaseChangeLogTable;
/*     */   }
/*     */   
/*     */   public String getDatabaseChangeLogLockTable() {
/* 167 */     return this.databaseChangeLogLockTable;
/*     */   }
/*     */   
/*     */   public void setDatabaseChangeLogLockTable(String databaseChangeLogLockTable) {
/* 171 */     this.databaseChangeLogLockTable = databaseChangeLogLockTable;
/*     */   }
/*     */   
/*     */   public boolean isDropFirst() {
/* 175 */     return this.dropFirst;
/*     */   }
/*     */   
/*     */   public void setDropFirst(boolean dropFirst) {
/* 179 */     this.dropFirst = dropFirst;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 183 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 187 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 191 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 195 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 199 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 203 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 207 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 211 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getLabels() {
/* 215 */     return this.labels;
/*     */   }
/*     */   
/*     */   public void setLabels(String labels) {
/* 219 */     this.labels = labels;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParameters() {
/* 223 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public void setParameters(Map<String, String> parameters) {
/* 227 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */   public File getRollbackFile() {
/* 231 */     return this.rollbackFile;
/*     */   }
/*     */   
/*     */   public void setRollbackFile(File rollbackFile) {
/* 235 */     this.rollbackFile = rollbackFile;
/*     */   }
/*     */   
/*     */   public boolean isTestRollbackOnUpdate() {
/* 239 */     return this.testRollbackOnUpdate;
/*     */   }
/*     */   
/*     */   public void setTestRollbackOnUpdate(boolean testRollbackOnUpdate) {
/* 243 */     this.testRollbackOnUpdate = testRollbackOnUpdate;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\liquibase\LiquibaseProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
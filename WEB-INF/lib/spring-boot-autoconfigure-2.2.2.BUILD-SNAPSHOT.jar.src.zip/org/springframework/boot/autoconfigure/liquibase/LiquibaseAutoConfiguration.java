/*     */ package org.springframework.boot.autoconfigure.liquibase;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import javax.sql.DataSource;
/*     */ import liquibase.change.DatabaseChange;
/*     */ import liquibase.integration.spring.SpringLiquibase;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.data.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
/*     */ import org.springframework.boot.autoconfigure.jdbc.JdbcOperationsDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.jdbc.NamedParameterJdbcOperationsDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.jdbc.core.JdbcOperations;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*     */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({SpringLiquibase.class, DatabaseChange.class})
/*     */ @ConditionalOnProperty(prefix = "spring.liquibase", name = {"enabled"}, matchIfMissing = true)
/*     */ @Conditional({LiquibaseAutoConfiguration.LiquibaseDataSourceCondition.class})
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*     */ @Import({LiquibaseAutoConfiguration.LiquibaseEntityManagerFactoryDependsOnPostProcessor.class, LiquibaseAutoConfiguration.LiquibaseJdbcOperationsDependsOnPostProcessor.class, LiquibaseAutoConfiguration.LiquibaseNamedParameterJdbcOperationsDependsOnPostProcessor.class})
/*     */ public class LiquibaseAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   public LiquibaseSchemaManagementProvider liquibaseDefaultDdlModeProvider(ObjectProvider<SpringLiquibase> liquibases) {
/*  82 */     return new LiquibaseSchemaManagementProvider(liquibases);
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({SpringLiquibase.class})
/*     */   @EnableConfigurationProperties({DataSourceProperties.class, LiquibaseProperties.class})
/*     */   public static class LiquibaseConfiguration
/*     */   {
/*     */     private final LiquibaseProperties properties;
/*     */     
/*     */     public LiquibaseConfiguration(LiquibaseProperties properties) {
/*  93 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public SpringLiquibase liquibase(DataSourceProperties dataSourceProperties, ObjectProvider<DataSource> dataSource, @LiquibaseDataSource ObjectProvider<DataSource> liquibaseDataSource) {
/* 100 */       SpringLiquibase liquibase = createSpringLiquibase((DataSource)liquibaseDataSource.getIfAvailable(), (DataSource)dataSource
/* 101 */           .getIfUnique(), dataSourceProperties);
/* 102 */       liquibase.setChangeLog(this.properties.getChangeLog());
/* 103 */       liquibase.setContexts(this.properties.getContexts());
/* 104 */       liquibase.setDefaultSchema(this.properties.getDefaultSchema());
/* 105 */       liquibase.setLiquibaseSchema(this.properties.getLiquibaseSchema());
/* 106 */       liquibase.setLiquibaseTablespace(this.properties.getLiquibaseTablespace());
/* 107 */       liquibase.setDatabaseChangeLogTable(this.properties.getDatabaseChangeLogTable());
/* 108 */       liquibase.setDatabaseChangeLogLockTable(this.properties.getDatabaseChangeLogLockTable());
/* 109 */       liquibase.setDropFirst(this.properties.isDropFirst());
/* 110 */       liquibase.setShouldRun(this.properties.isEnabled());
/* 111 */       liquibase.setLabels(this.properties.getLabels());
/* 112 */       liquibase.setChangeLogParameters(this.properties.getParameters());
/* 113 */       liquibase.setRollbackFile(this.properties.getRollbackFile());
/* 114 */       liquibase.setTestRollbackOnUpdate(this.properties.isTestRollbackOnUpdate());
/* 115 */       return liquibase;
/*     */     }
/*     */ 
/*     */     
/*     */     private SpringLiquibase createSpringLiquibase(DataSource liquibaseDatasource, DataSource dataSource, DataSourceProperties dataSourceProperties) {
/* 120 */       DataSource liquibaseDataSource = getDataSource(liquibaseDatasource, dataSource);
/* 121 */       if (liquibaseDataSource != null) {
/* 122 */         SpringLiquibase springLiquibase = new SpringLiquibase();
/* 123 */         springLiquibase.setDataSource(liquibaseDataSource);
/* 124 */         return springLiquibase;
/*     */       } 
/* 126 */       SpringLiquibase liquibase = new DataSourceClosingSpringLiquibase();
/* 127 */       liquibase.setDataSource(createNewDataSource(dataSourceProperties));
/* 128 */       return liquibase;
/*     */     }
/*     */     
/*     */     private DataSource getDataSource(DataSource liquibaseDataSource, DataSource dataSource) {
/* 132 */       if (liquibaseDataSource != null) {
/* 133 */         return liquibaseDataSource;
/*     */       }
/* 135 */       if (this.properties.getUrl() == null && this.properties.getUser() == null) {
/* 136 */         return dataSource;
/*     */       }
/* 138 */       return null;
/*     */     }
/*     */     
/*     */     private DataSource createNewDataSource(DataSourceProperties dataSourceProperties) {
/* 142 */       String url = getProperty(this.properties::getUrl, dataSourceProperties::determineUrl);
/* 143 */       String user = getProperty(this.properties::getUser, dataSourceProperties::determineUsername);
/* 144 */       String password = getProperty(this.properties::getPassword, dataSourceProperties::determinePassword);
/* 145 */       return DataSourceBuilder.create().url(url).username(user).password(password).build();
/*     */     }
/*     */     
/*     */     private String getProperty(Supplier<String> property, Supplier<String> defaultValue) {
/* 149 */       String value = property.get();
/* 150 */       return (value != null) ? value : defaultValue.get();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   static class LiquibaseEntityManagerFactoryDependsOnPostProcessor
/*     */     extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     LiquibaseEntityManagerFactoryDependsOnPostProcessor() {
/* 165 */       super(new Class[] { SpringLiquibase.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({JdbcOperations.class})
/*     */   @ConditionalOnBean({JdbcOperations.class})
/*     */   static class LiquibaseJdbcOperationsDependsOnPostProcessor
/*     */     extends JdbcOperationsDependsOnPostProcessor
/*     */   {
/*     */     LiquibaseJdbcOperationsDependsOnPostProcessor() {
/* 179 */       super(new Class[] { SpringLiquibase.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({NamedParameterJdbcOperations.class})
/*     */   @ConditionalOnBean({NamedParameterJdbcOperations.class})
/*     */   static class LiquibaseNamedParameterJdbcOperationsDependsOnPostProcessor
/*     */     extends NamedParameterJdbcOperationsDependsOnPostProcessor
/*     */   {
/*     */     LiquibaseNamedParameterJdbcOperationsDependsOnPostProcessor() {
/* 194 */       super(new Class[] { SpringLiquibase.class });
/*     */     }
/*     */   }
/*     */   
/*     */   static final class LiquibaseDataSourceCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     LiquibaseDataSourceCondition() {
/* 202 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */     
/*     */     @ConditionalOnBean({DataSource.class})
/*     */     private static final class DataSourceBeanCondition {}
/*     */     
/*     */     @ConditionalOnProperty(prefix = "spring.liquibase", name = {"url"}, matchIfMissing = false)
/*     */     private static final class LiquibaseUrlCondition {}
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\liquibase\LiquibaseAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.liquibase;
/*    */ 
/*    */ import java.util.stream.StreamSupport;
/*    */ import javax.sql.DataSource;
/*    */ import liquibase.integration.spring.SpringLiquibase;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.jdbc.SchemaManagement;
/*    */ import org.springframework.boot.jdbc.SchemaManagementProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LiquibaseSchemaManagementProvider
/*    */   implements SchemaManagementProvider
/*    */ {
/*    */   private final Iterable<SpringLiquibase> liquibaseInstances;
/*    */   
/*    */   LiquibaseSchemaManagementProvider(ObjectProvider<SpringLiquibase> liquibases) {
/* 40 */     this.liquibaseInstances = (Iterable<SpringLiquibase>)liquibases;
/*    */   }
/*    */ 
/*    */   
/*    */   public SchemaManagement getSchemaManagement(DataSource dataSource) {
/* 45 */     return StreamSupport.stream(this.liquibaseInstances.spliterator(), false).map(SpringLiquibase::getDataSource)
/* 46 */       .filter(dataSource::equals).findFirst().map(managedDataSource -> SchemaManagement.MANAGED)
/* 47 */       .orElse(SchemaManagement.UNMANAGED);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\liquibase\LiquibaseSchemaManagementProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
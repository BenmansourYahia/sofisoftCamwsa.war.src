/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.AllNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.data.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*    */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({HazelcastInstance.class, LocalContainerEntityManagerFactoryBean.class})
/*    */ @AutoConfigureAfter({HazelcastAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*    */ @Import({HazelcastJpaDependencyAutoConfiguration.HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor.class})
/*    */ public class HazelcastJpaDependencyAutoConfiguration
/*    */ {
/*    */   @Conditional({OnHazelcastAndJpaCondition.class})
/*    */   static class HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor
/*    */     extends EntityManagerFactoryDependsOnPostProcessor
/*    */   {
/*    */     HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor() {
/* 54 */       super(new String[] { "hazelcastInstance" });
/*    */     }
/*    */   }
/*    */   
/*    */   static class OnHazelcastAndJpaCondition
/*    */     extends AllNestedConditions
/*    */   {
/*    */     OnHazelcastAndJpaCondition() {
/* 62 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */     }
/*    */     
/*    */     @ConditionalOnBean(name = {"hazelcastInstance"})
/*    */     static class HasHazelcastInstance {}
/*    */     
/*    */     @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*    */     static class HasJpa {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastJpaDependencyAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
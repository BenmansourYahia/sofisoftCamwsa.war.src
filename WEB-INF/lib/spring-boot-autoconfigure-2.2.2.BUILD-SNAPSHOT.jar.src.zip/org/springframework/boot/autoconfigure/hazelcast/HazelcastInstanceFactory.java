/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.config.Config;
/*    */ import com.hazelcast.config.XmlConfigBuilder;
/*    */ import com.hazelcast.config.YamlConfigBuilder;
/*    */ import com.hazelcast.core.Hazelcast;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ResourceUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HazelcastInstanceFactory
/*    */ {
/*    */   private final Config config;
/*    */   
/*    */   public HazelcastInstanceFactory(Resource configLocation) throws IOException {
/* 50 */     Assert.notNull(configLocation, "ConfigLocation must not be null");
/* 51 */     this.config = getConfig(configLocation);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HazelcastInstanceFactory(Config config) {
/* 59 */     Assert.notNull(config, "Config must not be null");
/* 60 */     this.config = config;
/*    */   }
/*    */   
/*    */   private Config getConfig(Resource configLocation) throws IOException {
/* 64 */     URL configUrl = configLocation.getURL();
/* 65 */     Config config = createConfig(configUrl);
/* 66 */     if (ResourceUtils.isFileURL(configUrl)) {
/* 67 */       config.setConfigurationFile(configLocation.getFile());
/*    */     } else {
/*    */       
/* 70 */       config.setConfigurationUrl(configUrl);
/*    */     } 
/* 72 */     return config;
/*    */   }
/*    */   
/*    */   private static Config createConfig(URL configUrl) throws IOException {
/* 76 */     String configFileName = configUrl.getPath();
/* 77 */     if (configFileName.endsWith(".yaml")) {
/* 78 */       return (new YamlConfigBuilder(configUrl)).build();
/*    */     }
/* 80 */     return (new XmlConfigBuilder(configUrl)).build();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HazelcastInstance getHazelcastInstance() {
/* 88 */     if (StringUtils.hasText(this.config.getInstanceName())) {
/* 89 */       return Hazelcast.getOrCreateHazelcastInstance(this.config);
/*    */     }
/* 91 */     return Hazelcast.newHazelcastInstance(this.config);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastInstanceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
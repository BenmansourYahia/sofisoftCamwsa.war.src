/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.HazelcastClient;
/*    */ import com.hazelcast.client.config.ClientConfig;
/*    */ import com.hazelcast.client.config.XmlClientConfigBuilder;
/*    */ import com.hazelcast.client.config.YamlClientConfigBuilder;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HazelcastClientFactory
/*    */ {
/*    */   private final ClientConfig clientConfig;
/*    */   
/*    */   public HazelcastClientFactory(Resource clientConfigLocation) throws IOException {
/* 48 */     this.clientConfig = getClientConfig(clientConfigLocation);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HazelcastClientFactory(ClientConfig clientConfig) {
/* 56 */     Assert.notNull(clientConfig, "ClientConfig must not be null");
/* 57 */     this.clientConfig = clientConfig;
/*    */   }
/*    */   
/*    */   private ClientConfig getClientConfig(Resource clientConfigLocation) throws IOException {
/* 61 */     URL configUrl = clientConfigLocation.getURL();
/* 62 */     String configFileName = configUrl.getPath();
/* 63 */     if (configFileName.endsWith(".yaml")) {
/* 64 */       return (new YamlClientConfigBuilder(configUrl)).build();
/*    */     }
/* 66 */     return (new XmlClientConfigBuilder(configUrl)).build();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HazelcastInstance getHazelcastInstance() {
/* 74 */     if (StringUtils.hasText(this.clientConfig.getInstanceName())) {
/* 75 */       return HazelcastClient.getHazelcastClientByName(this.clientConfig.getInstanceName());
/*    */     }
/* 77 */     return HazelcastClient.newHazelcastClient(this.clientConfig);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastClientFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
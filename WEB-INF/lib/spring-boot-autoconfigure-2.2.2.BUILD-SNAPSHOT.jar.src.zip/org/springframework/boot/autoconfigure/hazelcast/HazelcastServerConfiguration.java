/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.config.Config;
/*    */ import com.hazelcast.core.Hazelcast;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnMissingBean({HazelcastInstance.class})
/*    */ class HazelcastServerConfiguration
/*    */ {
/*    */   static final String CONFIG_SYSTEM_PROPERTY = "hazelcast.config";
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({Config.class})
/*    */   @Conditional({ConfigAvailableCondition.class})
/*    */   static class HazelcastServerConfigFileConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastInstance hazelcastInstance(HazelcastProperties properties) throws IOException {
/* 51 */       Resource config = properties.resolveConfigLocation();
/* 52 */       if (config != null) {
/* 53 */         return (new HazelcastInstanceFactory(config)).getHazelcastInstance();
/*    */       }
/* 55 */       return Hazelcast.newHazelcastInstance();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnSingleCandidate(Config.class)
/*    */   static class HazelcastServerConfigConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastInstance hazelcastInstance(Config config) {
/* 66 */       return (new HazelcastInstanceFactory(config)).getHazelcastInstance();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static class ConfigAvailableCondition
/*    */     extends HazelcastConfigResourceCondition
/*    */   {
/*    */     ConfigAvailableCondition() {
/* 78 */       super("hazelcast.config", new String[] { "file:./hazelcast.xml", "classpath:/hazelcast.xml", "file:./hazelcast.yaml", "classpath:/hazelcast.yaml" });
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastServerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
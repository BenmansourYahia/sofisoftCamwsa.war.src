/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.ResourceCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HazelcastConfigResourceCondition
/*    */   extends ResourceCondition
/*    */ {
/*    */   private final String configSystemProperty;
/*    */   
/*    */   protected HazelcastConfigResourceCondition(String configSystemProperty, String... resourceLocations) {
/* 41 */     super("Hazelcast", "spring.hazelcast.config", resourceLocations);
/* 42 */     Assert.notNull(configSystemProperty, "ConfigSystemProperty must not be null");
/* 43 */     this.configSystemProperty = configSystemProperty;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ConditionOutcome getResourceOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 48 */     if (System.getProperty(this.configSystemProperty) != null) {
/* 49 */       return ConditionOutcome.match(
/* 50 */           startConditionMessage().because("System property '" + this.configSystemProperty + "' is set."));
/*    */     }
/* 52 */     return super.getResourceOutcome(context, metadata);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastConfigResourceCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
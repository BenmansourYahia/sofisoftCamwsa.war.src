/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.HazelcastClient;
/*    */ import com.hazelcast.client.config.ClientConfig;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({HazelcastClient.class})
/*    */ @ConditionalOnMissingBean({HazelcastInstance.class})
/*    */ class HazelcastClientConfiguration
/*    */ {
/*    */   static final String CONFIG_SYSTEM_PROPERTY = "hazelcast.client.config";
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({ClientConfig.class})
/*    */   @Conditional({ConfigAvailableCondition.class})
/*    */   static class HazelcastClientConfigFileConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastInstance hazelcastInstance(HazelcastProperties properties) throws IOException {
/* 53 */       Resource config = properties.resolveConfigLocation();
/* 54 */       if (config != null) {
/* 55 */         return (new HazelcastClientFactory(config)).getHazelcastInstance();
/*    */       }
/* 57 */       return HazelcastClient.newHazelcastClient();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnSingleCandidate(ClientConfig.class)
/*    */   static class HazelcastClientConfigConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastInstance hazelcastInstance(ClientConfig config) {
/* 68 */       return (new HazelcastClientFactory(config)).getHazelcastInstance();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static class ConfigAvailableCondition
/*    */     extends HazelcastConfigResourceCondition
/*    */   {
/*    */     ConfigAvailableCondition() {
/* 80 */       super("hazelcast.client.config", new String[] { "file:./hazelcast-client.xml", "classpath:/hazelcast-client.xml", "file:./hazelcast-client.yaml", "classpath:/hazelcast-client.yaml" });
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastClientConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
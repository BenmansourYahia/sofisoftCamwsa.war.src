/*    */ package org.springframework.boot.autoconfigure.hateoas;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*    */ import org.springframework.http.converter.HttpMessageConverter;
/*    */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ public class HypermediaHttpMessageConverterConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnProperty(prefix = "spring.hateoas", name = {"use-hal-as-default-json-media-type"}, matchIfMissing = true)
/*    */   public static HalMessageConverterSupportedMediaTypesCustomizer halMessageConverterSupportedMediaTypeCustomizer() {
/* 53 */     return new HalMessageConverterSupportedMediaTypesCustomizer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static class HalMessageConverterSupportedMediaTypesCustomizer
/*    */     implements BeanFactoryAware
/*    */   {
/*    */     private volatile BeanFactory beanFactory;
/*    */ 
/*    */     
/*    */     private HalMessageConverterSupportedMediaTypesCustomizer() {}
/*    */ 
/*    */     
/*    */     @PostConstruct
/*    */     void configureHttpMessageConverters() {
/* 69 */       if (this.beanFactory instanceof ListableBeanFactory) {
/* 70 */         configureHttpMessageConverters(((ListableBeanFactory)this.beanFactory)
/* 71 */             .getBeansOfType(RequestMappingHandlerAdapter.class).values());
/*    */       }
/*    */     }
/*    */     
/*    */     private void configureHttpMessageConverters(Collection<RequestMappingHandlerAdapter> handlerAdapters) {
/* 76 */       for (RequestMappingHandlerAdapter handlerAdapter : handlerAdapters) {
/* 77 */         for (HttpMessageConverter<?> messageConverter : (Iterable<HttpMessageConverter<?>>)handlerAdapter.getMessageConverters()) {
/* 78 */           configureHttpMessageConverter(messageConverter);
/*    */         }
/*    */       } 
/*    */     }
/*    */     
/*    */     private void configureHttpMessageConverter(HttpMessageConverter<?> converter) {
/* 84 */       if (converter instanceof org.springframework.hateoas.server.mvc.TypeConstrainedMappingJackson2HttpMessageConverter) {
/* 85 */         List<MediaType> supportedMediaTypes = new ArrayList<>(converter.getSupportedMediaTypes());
/* 86 */         if (!supportedMediaTypes.contains(MediaType.APPLICATION_JSON)) {
/* 87 */           supportedMediaTypes.add(MediaType.APPLICATION_JSON);
/*    */         }
/* 89 */         ((AbstractHttpMessageConverter)converter).setSupportedMediaTypes(supportedMediaTypes);
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 95 */       this.beanFactory = beanFactory;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hateoas\HypermediaHttpMessageConverterConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
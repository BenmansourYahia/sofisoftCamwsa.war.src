/*    */ package org.springframework.boot.autoconfigure.hateoas;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.hateoas")
/*    */ public class HateoasProperties
/*    */ {
/*    */   private boolean useHalAsDefaultJsonMediaType = true;
/*    */   
/*    */   public boolean getUseHalAsDefaultJsonMediaType() {
/* 38 */     return this.useHalAsDefaultJsonMediaType;
/*    */   }
/*    */   
/*    */   public void setUseHalAsDefaultJsonMediaType(boolean useHalAsDefaultJsonMediaType) {
/* 42 */     this.useHalAsDefaultJsonMediaType = useHalAsDefaultJsonMediaType;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\hateoas\HateoasProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.http;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.NoneNestedConditions;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Gson.class})
/*    */ class GsonHttpMessageConvertersConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnBean({Gson.class})
/*    */   @Conditional({PreferGsonOrJacksonAndJsonbUnavailableCondition.class})
/*    */   static class GsonHttpMessageConverterConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     GsonHttpMessageConverter gsonHttpMessageConverter(Gson gson) {
/* 51 */       GsonHttpMessageConverter converter = new GsonHttpMessageConverter();
/* 52 */       converter.setGson(gson);
/* 53 */       return converter;
/*    */     }
/*    */   }
/*    */   
/*    */   private static class PreferGsonOrJacksonAndJsonbUnavailableCondition
/*    */     extends AnyNestedCondition
/*    */   {
/*    */     PreferGsonOrJacksonAndJsonbUnavailableCondition() {
/* 61 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     @ConditionalOnProperty(name = {"spring.http.converters.preferred-json-mapper"}, havingValue = "gson")
/*    */     static class GsonPreferred {}
/*    */ 
/*    */ 
/*    */     
/*    */     @Conditional({GsonHttpMessageConvertersConfiguration.JacksonAndJsonbUnavailableCondition.class})
/*    */     static class JacksonJsonbUnavailable {}
/*    */   }
/*    */ 
/*    */   
/*    */   private static class JacksonAndJsonbUnavailableCondition
/*    */     extends NoneNestedConditions
/*    */   {
/*    */     JacksonAndJsonbUnavailableCondition() {
/* 80 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */     }
/*    */     
/*    */     @ConditionalOnBean({MappingJackson2HttpMessageConverter.class})
/*    */     static class JacksonAvailable {}
/*    */     
/*    */     @ConditionalOnProperty(name = {"spring.http.converters.preferred-json-mapper"}, havingValue = "jsonb")
/*    */     static class JsonbPreferred {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\http\GsonHttpMessageConvertersConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.http;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.http.converter.FormHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.client.RestTemplate;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpMessageConverters
/*     */   implements Iterable<HttpMessageConverter<?>>
/*     */ {
/*     */   private static final List<Class<?>> NON_REPLACING_CONVERTERS;
/*     */   private final List<HttpMessageConverter<?>> converters;
/*     */   
/*     */   static {
/*  63 */     List<Class<?>> nonReplacingConverters = new ArrayList<>();
/*  64 */     addClassIfExists(nonReplacingConverters, "org.springframework.hateoas.server.mvc.TypeConstrainedMappingJackson2HttpMessageConverter");
/*     */     
/*  66 */     NON_REPLACING_CONVERTERS = Collections.unmodifiableList(nonReplacingConverters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMessageConverters(HttpMessageConverter<?>... additionalConverters) {
/*  80 */     this(Arrays.asList(additionalConverters));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMessageConverters(Collection<HttpMessageConverter<?>> additionalConverters) {
/*  92 */     this(true, additionalConverters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMessageConverters(boolean addDefaultConverters, Collection<HttpMessageConverter<?>> converters) {
/* 104 */     List<HttpMessageConverter<?>> combined = getCombinedConverters(converters, addDefaultConverters ? 
/* 105 */         getDefaultConverters() : Collections.<HttpMessageConverter<?>>emptyList());
/* 106 */     combined = postProcessConverters(combined);
/* 107 */     this.converters = Collections.unmodifiableList(combined);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<HttpMessageConverter<?>> getCombinedConverters(Collection<HttpMessageConverter<?>> converters, List<HttpMessageConverter<?>> defaultConverters) {
/* 112 */     List<HttpMessageConverter<?>> combined = new ArrayList<>();
/* 113 */     List<HttpMessageConverter<?>> processing = new ArrayList<>(converters);
/* 114 */     for (HttpMessageConverter<?> defaultConverter : defaultConverters) {
/* 115 */       Iterator<HttpMessageConverter<?>> iterator = processing.iterator();
/* 116 */       while (iterator.hasNext()) {
/* 117 */         HttpMessageConverter<?> candidate = iterator.next();
/* 118 */         if (isReplacement(defaultConverter, candidate)) {
/* 119 */           combined.add(candidate);
/* 120 */           iterator.remove();
/*     */         } 
/*     */       } 
/* 123 */       combined.add(defaultConverter);
/* 124 */       if (defaultConverter instanceof AllEncompassingFormHttpMessageConverter) {
/* 125 */         configurePartConverters((AllEncompassingFormHttpMessageConverter)defaultConverter, converters);
/*     */       }
/*     */     } 
/* 128 */     combined.addAll(0, processing);
/* 129 */     return combined;
/*     */   }
/*     */   
/*     */   private boolean isReplacement(HttpMessageConverter<?> defaultConverter, HttpMessageConverter<?> candidate) {
/* 133 */     for (Class<?> nonReplacingConverter : NON_REPLACING_CONVERTERS) {
/* 134 */       if (nonReplacingConverter.isInstance(candidate)) {
/* 135 */         return false;
/*     */       }
/*     */     } 
/* 138 */     return ClassUtils.isAssignableValue(defaultConverter.getClass(), candidate);
/*     */   }
/*     */ 
/*     */   
/*     */   private void configurePartConverters(AllEncompassingFormHttpMessageConverter formConverter, Collection<HttpMessageConverter<?>> converters) {
/* 143 */     List<HttpMessageConverter<?>> partConverters = extractPartConverters((FormHttpMessageConverter)formConverter);
/* 144 */     List<HttpMessageConverter<?>> combinedConverters = getCombinedConverters(converters, partConverters);
/* 145 */     combinedConverters = postProcessPartConverters(combinedConverters);
/* 146 */     formConverter.setPartConverters(combinedConverters);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<HttpMessageConverter<?>> extractPartConverters(FormHttpMessageConverter formConverter) {
/* 151 */     Field field = ReflectionUtils.findField(FormHttpMessageConverter.class, "partConverters");
/* 152 */     ReflectionUtils.makeAccessible(field);
/* 153 */     return (List<HttpMessageConverter<?>>)ReflectionUtils.getField(field, formConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<HttpMessageConverter<?>> postProcessConverters(List<HttpMessageConverter<?>> converters) {
/* 163 */     return converters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<HttpMessageConverter<?>> postProcessPartConverters(List<HttpMessageConverter<?>> converters) {
/* 175 */     return converters;
/*     */   }
/*     */   
/*     */   private List<HttpMessageConverter<?>> getDefaultConverters() {
/* 179 */     List<HttpMessageConverter<?>> converters = new ArrayList<>();
/* 180 */     if (ClassUtils.isPresent("org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport", null)) {
/*     */       
/* 182 */       converters.addAll((new WebMvcConfigurationSupport()
/*     */           {
/*     */             public List<HttpMessageConverter<?>> defaultMessageConverters() {
/* 185 */               return getMessageConverters();
/*     */             }
/* 188 */           }).defaultMessageConverters());
/*     */     } else {
/*     */       
/* 191 */       converters.addAll((new RestTemplate()).getMessageConverters());
/*     */     } 
/* 193 */     reorderXmlConvertersToEnd(converters);
/* 194 */     return converters;
/*     */   }
/*     */   
/*     */   private void reorderXmlConvertersToEnd(List<HttpMessageConverter<?>> converters) {
/* 198 */     List<HttpMessageConverter<?>> xml = new ArrayList<>();
/* 199 */     for (Iterator<HttpMessageConverter<?>> iterator = converters.iterator(); iterator.hasNext(); ) {
/* 200 */       HttpMessageConverter<?> converter = iterator.next();
/* 201 */       if (converter instanceof org.springframework.http.converter.xml.AbstractXmlHttpMessageConverter || converter instanceof org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter) {
/*     */         
/* 203 */         xml.add(converter);
/* 204 */         iterator.remove();
/*     */       } 
/*     */     } 
/* 207 */     converters.addAll(xml);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<HttpMessageConverter<?>> iterator() {
/* 212 */     return getConverters().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HttpMessageConverter<?>> getConverters() {
/* 221 */     return this.converters;
/*     */   }
/*     */   
/*     */   private static void addClassIfExists(List<Class<?>> list, String className) {
/*     */     try {
/* 226 */       list.add(Class.forName(className));
/*     */     }
/* 228 */     catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\http\HttpMessageConverters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
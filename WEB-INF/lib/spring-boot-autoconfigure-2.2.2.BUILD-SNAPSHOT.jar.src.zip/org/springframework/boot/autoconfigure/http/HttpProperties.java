/*     */ package org.springframework.boot.autoconfigure.http;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.http")
/*     */ public class HttpProperties
/*     */ {
/*     */   private boolean logRequestDetails;
/*  46 */   private final Encoding encoding = new Encoding();
/*     */   
/*     */   public boolean isLogRequestDetails() {
/*  49 */     return this.logRequestDetails;
/*     */   }
/*     */   
/*     */   public void setLogRequestDetails(boolean logRequestDetails) {
/*  53 */     this.logRequestDetails = logRequestDetails;
/*     */   }
/*     */   
/*     */   public Encoding getEncoding() {
/*  57 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Encoding
/*     */   {
/*  65 */     public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     private Charset charset = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Boolean force;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Boolean forceRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Boolean forceResponse;
/*     */ 
/*     */ 
/*     */     
/*     */     private Map<Locale, Charset> mapping;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Charset getCharset() {
/*  96 */       return this.charset;
/*     */     }
/*     */     
/*     */     public void setCharset(Charset charset) {
/* 100 */       this.charset = charset;
/*     */     }
/*     */     
/*     */     public boolean isForce() {
/* 104 */       return Boolean.TRUE.equals(this.force);
/*     */     }
/*     */     
/*     */     public void setForce(boolean force) {
/* 108 */       this.force = Boolean.valueOf(force);
/*     */     }
/*     */     
/*     */     public boolean isForceRequest() {
/* 112 */       return Boolean.TRUE.equals(this.forceRequest);
/*     */     }
/*     */     
/*     */     public void setForceRequest(boolean forceRequest) {
/* 116 */       this.forceRequest = Boolean.valueOf(forceRequest);
/*     */     }
/*     */     
/*     */     public boolean isForceResponse() {
/* 120 */       return Boolean.TRUE.equals(this.forceResponse);
/*     */     }
/*     */     
/*     */     public void setForceResponse(boolean forceResponse) {
/* 124 */       this.forceResponse = Boolean.valueOf(forceResponse);
/*     */     }
/*     */     
/*     */     public Map<Locale, Charset> getMapping() {
/* 128 */       return this.mapping;
/*     */     }
/*     */     
/*     */     public void setMapping(Map<Locale, Charset> mapping) {
/* 132 */       this.mapping = mapping;
/*     */     }
/*     */     
/*     */     public boolean shouldForce(Type type) {
/* 136 */       Boolean force = (type != Type.REQUEST) ? this.forceResponse : this.forceRequest;
/* 137 */       if (force == null) {
/* 138 */         force = this.force;
/*     */       }
/* 140 */       if (force == null) {
/* 141 */         force = Boolean.valueOf((type == Type.REQUEST));
/*     */       }
/* 143 */       return force.booleanValue();
/*     */     }
/*     */     
/*     */     public enum Type
/*     */     {
/* 148 */       REQUEST, RESPONSE;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\http\HttpProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
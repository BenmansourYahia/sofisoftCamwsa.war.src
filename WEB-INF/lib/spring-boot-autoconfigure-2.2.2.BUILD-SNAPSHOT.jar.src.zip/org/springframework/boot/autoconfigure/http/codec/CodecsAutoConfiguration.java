/*    */ package org.springframework.boot.autoconfigure.http.codec;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.codec.CodecProperties;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.http.HttpProperties;
/*    */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.boot.web.codec.CodecCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.codec.Decoder;
/*    */ import org.springframework.core.codec.Encoder;
/*    */ import org.springframework.http.codec.CodecConfigurer;
/*    */ import org.springframework.http.codec.json.Jackson2JsonDecoder;
/*    */ import org.springframework.http.codec.json.Jackson2JsonEncoder;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.unit.DataSize;
/*    */ import org.springframework.web.reactive.function.client.WebClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({CodecConfigurer.class, WebClient.class})
/*    */ @AutoConfigureAfter({JacksonAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({HttpProperties.class, CodecProperties.class})
/*    */ public class CodecsAutoConfiguration
/*    */ {
/* 55 */   private static final MimeType[] EMPTY_MIME_TYPES = new MimeType[0];
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({ObjectMapper.class})
/*    */   static class JacksonCodecConfiguration
/*    */   {
/*    */     @Bean
/*    */     @Order(0)
/*    */     @ConditionalOnBean({ObjectMapper.class})
/*    */     CodecCustomizer jacksonCodecCustomizer(ObjectMapper objectMapper) {
/* 65 */       return configurer -> {
/*    */           CodecConfigurer.DefaultCodecs defaults = configurer.defaultCodecs();
/*    */           defaults.jackson2JsonDecoder((Decoder)new Jackson2JsonDecoder(objectMapper, CodecsAutoConfiguration.EMPTY_MIME_TYPES));
/*    */           defaults.jackson2JsonEncoder((Encoder)new Jackson2JsonEncoder(objectMapper, CodecsAutoConfiguration.EMPTY_MIME_TYPES));
/*    */         };
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   static class DefaultCodecsConfiguration
/*    */   {
/*    */     @Bean
/*    */     @Order(0)
/*    */     CodecCustomizer defaultCodecCustomizer(HttpProperties httpProperties, CodecProperties codecProperties) {
/* 80 */       return configurer -> {
/*    */           PropertyMapper map = PropertyMapper.get();
/*    */           CodecConfigurer.DefaultCodecs defaultCodecs = configurer.defaultCodecs();
/*    */           defaultCodecs.enableLoggingRequestDetails(httpProperties.isLogRequestDetails());
/*    */           map.from(codecProperties.getMaxInMemorySize()).whenNonNull().asInt(DataSize::toBytes).to(defaultCodecs::maxInMemorySize);
/*    */         };
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\http\codec\CodecsAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
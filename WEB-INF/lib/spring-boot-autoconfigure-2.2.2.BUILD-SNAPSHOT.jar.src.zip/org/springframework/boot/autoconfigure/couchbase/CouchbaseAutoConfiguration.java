/*    */ package org.springframework.boot.autoconfigure.couchbase;
/*    */ 
/*    */ import com.couchbase.client.java.Cluster;
/*    */ import com.couchbase.client.java.CouchbaseBucket;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.context.annotation.Import;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({CouchbaseBucket.class, Cluster.class})
/*    */ @Conditional({CouchbaseAutoConfiguration.CouchbaseCondition.class})
/*    */ @EnableConfigurationProperties({CouchbaseProperties.class})
/*    */ public class CouchbaseAutoConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean(value = {CouchbaseConfiguration.class}, type = {"org.springframework.data.couchbase.config.CouchbaseConfigurer"})
/*    */   @Import({CouchbaseConfiguration.class})
/*    */   static class DefaultCouchbaseConfiguration {}
/*    */   
/*    */   static class CouchbaseCondition
/*    */     extends AnyNestedCondition
/*    */   {
/*    */     CouchbaseCondition() {
/* 65 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */     }
/*    */     
/*    */     @Conditional({OnBootstrapHostsCondition.class})
/*    */     static class BootstrapHostsProperty {}
/*    */     
/*    */     @ConditionalOnBean(type = {"org.springframework.data.couchbase.config.CouchbaseConfigurer"})
/*    */     static class CouchbaseConfigurerAvailable {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
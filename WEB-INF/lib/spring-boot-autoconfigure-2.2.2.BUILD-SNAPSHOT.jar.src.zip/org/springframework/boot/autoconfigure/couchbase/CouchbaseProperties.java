/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.couchbase")
/*     */ public class CouchbaseProperties
/*     */ {
/*     */   private List<String> bootstrapHosts;
/*     */   private String username;
/*     */   private String password;
/*  51 */   private final Bucket bucket = new Bucket();
/*     */   
/*  53 */   private final Env env = new Env();
/*     */   
/*     */   public List<String> getBootstrapHosts() {
/*  56 */     return this.bootstrapHosts;
/*     */   }
/*     */   
/*     */   public void setBootstrapHosts(List<String> bootstrapHosts) {
/*  60 */     this.bootstrapHosts = bootstrapHosts;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  64 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  68 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  72 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  76 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Bucket getBucket() {
/*  80 */     return this.bucket;
/*     */   }
/*     */   
/*     */   public Env getEnv() {
/*  84 */     return this.env;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Bucket
/*     */   {
/*  92 */     private String name = "default";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     private String password = "";
/*     */     
/*     */     public String getName() {
/* 100 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setName(String name) {
/* 104 */       this.name = name;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 108 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 112 */       this.password = password;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Env
/*     */   {
/* 119 */     private final CouchbaseProperties.Endpoints endpoints = new CouchbaseProperties.Endpoints();
/*     */     
/* 121 */     private final CouchbaseProperties.Ssl ssl = new CouchbaseProperties.Ssl();
/*     */     
/* 123 */     private final CouchbaseProperties.Timeouts timeouts = new CouchbaseProperties.Timeouts();
/*     */     
/*     */     public CouchbaseProperties.Endpoints getEndpoints() {
/* 126 */       return this.endpoints;
/*     */     }
/*     */     
/*     */     public CouchbaseProperties.Ssl getSsl() {
/* 130 */       return this.ssl;
/*     */     }
/*     */     
/*     */     public CouchbaseProperties.Timeouts getTimeouts() {
/* 134 */       return this.timeouts;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Endpoints
/*     */   {
/* 144 */     private int keyValue = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     private final CouchbaseService queryservice = new CouchbaseService();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     private final CouchbaseService viewservice = new CouchbaseService();
/*     */     
/*     */     public int getKeyValue() {
/* 157 */       return this.keyValue;
/*     */     }
/*     */     
/*     */     public void setKeyValue(int keyValue) {
/* 161 */       this.keyValue = keyValue;
/*     */     }
/*     */     
/*     */     public CouchbaseService getQueryservice() {
/* 165 */       return this.queryservice;
/*     */     }
/*     */     
/*     */     public CouchbaseService getViewservice() {
/* 169 */       return this.viewservice;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class CouchbaseService
/*     */     {
/* 177 */       private int minEndpoints = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       private int maxEndpoints = 1;
/*     */       
/*     */       public int getMinEndpoints() {
/* 185 */         return this.minEndpoints;
/*     */       }
/*     */       
/*     */       public void setMinEndpoints(int minEndpoints) {
/* 189 */         this.minEndpoints = minEndpoints;
/*     */       }
/*     */       
/*     */       public int getMaxEndpoints() {
/* 193 */         return this.maxEndpoints;
/*     */       }
/*     */       
/*     */       public void setMaxEndpoints(int maxEndpoints) {
/* 197 */         this.maxEndpoints = maxEndpoints;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Ssl
/*     */   {
/*     */     private Boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String keyStore;
/*     */ 
/*     */ 
/*     */     
/*     */     private String keyStorePassword;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getEnabled() {
/* 223 */       return Boolean.valueOf((this.enabled != null) ? this.enabled.booleanValue() : StringUtils.hasText(this.keyStore));
/*     */     }
/*     */     
/*     */     public void setEnabled(Boolean enabled) {
/* 227 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String getKeyStore() {
/* 231 */       return this.keyStore;
/*     */     }
/*     */     
/*     */     public void setKeyStore(String keyStore) {
/* 235 */       this.keyStore = keyStore;
/*     */     }
/*     */     
/*     */     public String getKeyStorePassword() {
/* 239 */       return this.keyStorePassword;
/*     */     }
/*     */     
/*     */     public void setKeyStorePassword(String keyStorePassword) {
/* 243 */       this.keyStorePassword = keyStorePassword;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Timeouts
/*     */   {
/* 253 */     private Duration connect = Duration.ofMillis(5000L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     private Duration keyValue = Duration.ofMillis(2500L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     private Duration query = Duration.ofMillis(7500L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     private Duration socketConnect = Duration.ofMillis(1000L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     private Duration view = Duration.ofMillis(7500L);
/*     */     
/*     */     public Duration getConnect() {
/* 276 */       return this.connect;
/*     */     }
/*     */     
/*     */     public void setConnect(Duration connect) {
/* 280 */       this.connect = connect;
/*     */     }
/*     */     
/*     */     public Duration getKeyValue() {
/* 284 */       return this.keyValue;
/*     */     }
/*     */     
/*     */     public void setKeyValue(Duration keyValue) {
/* 288 */       this.keyValue = keyValue;
/*     */     }
/*     */     
/*     */     public Duration getQuery() {
/* 292 */       return this.query;
/*     */     }
/*     */     
/*     */     public void setQuery(Duration query) {
/* 296 */       this.query = query;
/*     */     }
/*     */     
/*     */     public Duration getSocketConnect() {
/* 300 */       return this.socketConnect;
/*     */     }
/*     */     
/*     */     public void setSocketConnect(Duration socketConnect) {
/* 304 */       this.socketConnect = socketConnect;
/*     */     }
/*     */     
/*     */     public Duration getView() {
/* 308 */       return this.view;
/*     */     }
/*     */     
/*     */     public void setView(Duration view) {
/* 312 */       this.view = view;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ import com.couchbase.client.core.env.KeyValueServiceConfig;
/*     */ import com.couchbase.client.core.env.QueryServiceConfig;
/*     */ import com.couchbase.client.core.env.ViewServiceConfig;
/*     */ import com.couchbase.client.java.Bucket;
/*     */ import com.couchbase.client.java.Cluster;
/*     */ import com.couchbase.client.java.CouchbaseCluster;
/*     */ import com.couchbase.client.java.cluster.ClusterInfo;
/*     */ import com.couchbase.client.java.env.CouchbaseEnvironment;
/*     */ import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;
/*     */ import java.util.List;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.DependsOn;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ public class CouchbaseConfiguration
/*     */ {
/*     */   private final CouchbaseProperties properties;
/*     */   
/*     */   public CouchbaseConfiguration(CouchbaseProperties properties) {
/*  48 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Primary
/*     */   public DefaultCouchbaseEnvironment couchbaseEnvironment() {
/*  54 */     return initializeEnvironmentBuilder(this.properties).build();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Primary
/*     */   public Cluster couchbaseCluster() {
/*  60 */     CouchbaseCluster couchbaseCluster = CouchbaseCluster.create((CouchbaseEnvironment)couchbaseEnvironment(), determineBootstrapHosts());
/*  61 */     if (isRoleBasedAccessControlEnabled()) {
/*  62 */       return (Cluster)couchbaseCluster.authenticate(this.properties.getUsername(), this.properties.getPassword());
/*     */     }
/*  64 */     return (Cluster)couchbaseCluster;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> determineBootstrapHosts() {
/*  72 */     return this.properties.getBootstrapHosts();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Primary
/*     */   @DependsOn({"couchbaseClient"})
/*     */   public ClusterInfo couchbaseClusterInfo() {
/*  79 */     return couchbaseCluster()
/*  80 */       .clusterManager(this.properties.getBucket().getName(), this.properties.getBucket().getPassword())
/*  81 */       .info();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Primary
/*     */   public Bucket couchbaseClient() {
/*  87 */     if (isRoleBasedAccessControlEnabled()) {
/*  88 */       return couchbaseCluster().openBucket(this.properties.getBucket().getName());
/*     */     }
/*  90 */     return couchbaseCluster().openBucket(this.properties.getBucket().getName(), this.properties
/*  91 */         .getBucket().getPassword());
/*     */   }
/*     */   
/*     */   private boolean isRoleBasedAccessControlEnabled() {
/*  95 */     return (this.properties.getUsername() != null && this.properties.getPassword() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultCouchbaseEnvironment.Builder initializeEnvironmentBuilder(CouchbaseProperties properties) {
/* 104 */     CouchbaseProperties.Endpoints endpoints = properties.getEnv().getEndpoints();
/* 105 */     CouchbaseProperties.Timeouts timeouts = properties.getEnv().getTimeouts();
/* 106 */     DefaultCouchbaseEnvironment.Builder builder = DefaultCouchbaseEnvironment.builder();
/* 107 */     if (timeouts.getConnect() != null) {
/* 108 */       builder = builder.connectTimeout(timeouts.getConnect().toMillis());
/*     */     }
/* 110 */     builder = (DefaultCouchbaseEnvironment.Builder)builder.keyValueServiceConfig(KeyValueServiceConfig.create(endpoints.getKeyValue()));
/* 111 */     if (timeouts.getKeyValue() != null) {
/* 112 */       builder = builder.kvTimeout(timeouts.getKeyValue().toMillis());
/*     */     }
/* 114 */     if (timeouts.getQuery() != null) {
/* 115 */       builder = builder.queryTimeout(timeouts.getQuery().toMillis());
/* 116 */       builder = (DefaultCouchbaseEnvironment.Builder)builder.queryServiceConfig(getQueryServiceConfig(endpoints));
/* 117 */       builder = (DefaultCouchbaseEnvironment.Builder)builder.viewServiceConfig(getViewServiceConfig(endpoints));
/*     */     } 
/* 119 */     if (timeouts.getSocketConnect() != null) {
/* 120 */       builder = (DefaultCouchbaseEnvironment.Builder)builder.socketConnectTimeout((int)timeouts.getSocketConnect().toMillis());
/*     */     }
/* 122 */     if (timeouts.getView() != null) {
/* 123 */       builder = builder.viewTimeout(timeouts.getView().toMillis());
/*     */     }
/* 125 */     CouchbaseProperties.Ssl ssl = properties.getEnv().getSsl();
/* 126 */     if (ssl.getEnabled().booleanValue()) {
/* 127 */       builder = (DefaultCouchbaseEnvironment.Builder)builder.sslEnabled(true);
/* 128 */       if (ssl.getKeyStore() != null) {
/* 129 */         builder = (DefaultCouchbaseEnvironment.Builder)builder.sslKeystoreFile(ssl.getKeyStore());
/*     */       }
/* 131 */       if (ssl.getKeyStorePassword() != null) {
/* 132 */         builder = (DefaultCouchbaseEnvironment.Builder)builder.sslKeystorePassword(ssl.getKeyStorePassword());
/*     */       }
/*     */     } 
/* 135 */     return builder;
/*     */   }
/*     */   
/*     */   private QueryServiceConfig getQueryServiceConfig(CouchbaseProperties.Endpoints endpoints) {
/* 139 */     return QueryServiceConfig.create(endpoints.getQueryservice().getMinEndpoints(), endpoints
/* 140 */         .getQueryservice().getMaxEndpoints());
/*     */   }
/*     */   
/*     */   private ViewServiceConfig getViewServiceConfig(CouchbaseProperties.Endpoints endpoints) {
/* 144 */     return ViewServiceConfig.create(endpoints.getViewservice().getMinEndpoints(), endpoints
/* 145 */         .getViewservice().getMaxEndpoints());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
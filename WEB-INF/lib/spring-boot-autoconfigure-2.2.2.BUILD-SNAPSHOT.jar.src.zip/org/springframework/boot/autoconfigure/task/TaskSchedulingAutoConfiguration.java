/*    */ package org.springframework.boot.autoconfigure.task;
/*    */ 
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.task.TaskSchedulerBuilder;
/*    */ import org.springframework.boot.task.TaskSchedulerCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.scheduling.TaskScheduler;
/*    */ import org.springframework.scheduling.annotation.SchedulingConfigurer;
/*    */ import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnClass({ThreadPoolTaskScheduler.class})
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @EnableConfigurationProperties({TaskSchedulingProperties.class})
/*    */ @AutoConfigureAfter({TaskExecutionAutoConfiguration.class})
/*    */ public class TaskSchedulingAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnBean(name = {"org.springframework.context.annotation.internalScheduledAnnotationProcessor"})
/*    */   @ConditionalOnMissingBean({SchedulingConfigurer.class, TaskScheduler.class, ScheduledExecutorService.class})
/*    */   public ThreadPoolTaskScheduler taskScheduler(TaskSchedulerBuilder builder) {
/* 54 */     return builder.build();
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public TaskSchedulerBuilder taskSchedulerBuilder(TaskSchedulingProperties properties, ObjectProvider<TaskSchedulerCustomizer> taskSchedulerCustomizers) {
/* 61 */     TaskSchedulerBuilder builder = new TaskSchedulerBuilder();
/* 62 */     builder = builder.poolSize(properties.getPool().getSize());
/* 63 */     TaskSchedulingProperties.Shutdown shutdown = properties.getShutdown();
/* 64 */     builder = builder.awaitTermination(shutdown.isAwaitTermination());
/* 65 */     builder = builder.awaitTerminationPeriod(shutdown.getAwaitTerminationPeriod());
/* 66 */     builder = builder.threadNamePrefix(properties.getThreadNamePrefix());
/* 67 */     builder = builder.customizers((Iterable)taskSchedulerCustomizers);
/* 68 */     return builder;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\task\TaskSchedulingAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
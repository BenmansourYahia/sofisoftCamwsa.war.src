/*    */ package org.springframework.boot.autoconfigure.task;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.task.scheduling")
/*    */ public class TaskSchedulingProperties
/*    */ {
/* 32 */   private final Pool pool = new Pool();
/*    */   
/* 34 */   private final Shutdown shutdown = new Shutdown();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   private String threadNamePrefix = "scheduling-";
/*    */   
/*    */   public Pool getPool() {
/* 42 */     return this.pool;
/*    */   }
/*    */   
/*    */   public Shutdown getShutdown() {
/* 46 */     return this.shutdown;
/*    */   }
/*    */   
/*    */   public String getThreadNamePrefix() {
/* 50 */     return this.threadNamePrefix;
/*    */   }
/*    */   
/*    */   public void setThreadNamePrefix(String threadNamePrefix) {
/* 54 */     this.threadNamePrefix = threadNamePrefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Pool
/*    */   {
/* 62 */     private int size = 1;
/*    */     
/*    */     public int getSize() {
/* 65 */       return this.size;
/*    */     }
/*    */     
/*    */     public void setSize(int size) {
/* 69 */       this.size = size;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Shutdown
/*    */   {
/*    */     private boolean awaitTermination;
/*    */ 
/*    */ 
/*    */     
/*    */     private Duration awaitTerminationPeriod;
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean isAwaitTermination() {
/* 87 */       return this.awaitTermination;
/*    */     }
/*    */     
/*    */     public void setAwaitTermination(boolean awaitTermination) {
/* 91 */       this.awaitTermination = awaitTermination;
/*    */     }
/*    */     
/*    */     public Duration getAwaitTerminationPeriod() {
/* 95 */       return this.awaitTerminationPeriod;
/*    */     }
/*    */     
/*    */     public void setAwaitTerminationPeriod(Duration awaitTerminationPeriod) {
/* 99 */       this.awaitTerminationPeriod = awaitTerminationPeriod;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\task\TaskSchedulingProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
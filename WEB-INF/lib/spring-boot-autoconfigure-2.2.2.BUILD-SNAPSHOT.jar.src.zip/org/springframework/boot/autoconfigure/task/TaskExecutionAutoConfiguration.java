/*    */ package org.springframework.boot.autoconfigure.task;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.task.TaskExecutorBuilder;
/*    */ import org.springframework.boot.task.TaskExecutorCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Lazy;
/*    */ import org.springframework.core.task.TaskDecorator;
/*    */ import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnClass({ThreadPoolTaskExecutor.class})
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @EnableConfigurationProperties({TaskExecutionProperties.class})
/*    */ public class TaskExecutionAutoConfiguration
/*    */ {
/*    */   public static final String APPLICATION_TASK_EXECUTOR_BEAN_NAME = "applicationTaskExecutor";
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public TaskExecutorBuilder taskExecutorBuilder(TaskExecutionProperties properties, ObjectProvider<TaskExecutorCustomizer> taskExecutorCustomizers, ObjectProvider<TaskDecorator> taskDecorator) {
/* 59 */     TaskExecutionProperties.Pool pool = properties.getPool();
/* 60 */     TaskExecutorBuilder builder = new TaskExecutorBuilder();
/* 61 */     builder = builder.queueCapacity(pool.getQueueCapacity());
/* 62 */     builder = builder.corePoolSize(pool.getCoreSize());
/* 63 */     builder = builder.maxPoolSize(pool.getMaxSize());
/* 64 */     builder = builder.allowCoreThreadTimeOut(pool.isAllowCoreThreadTimeout());
/* 65 */     builder = builder.keepAlive(pool.getKeepAlive());
/* 66 */     TaskExecutionProperties.Shutdown shutdown = properties.getShutdown();
/* 67 */     builder = builder.awaitTermination(shutdown.isAwaitTermination());
/* 68 */     builder = builder.awaitTerminationPeriod(shutdown.getAwaitTerminationPeriod());
/* 69 */     builder = builder.threadNamePrefix(properties.getThreadNamePrefix());
/* 70 */     builder = builder.customizers(taskExecutorCustomizers.orderedStream()::iterator);
/* 71 */     builder = builder.taskDecorator((TaskDecorator)taskDecorator.getIfUnique());
/* 72 */     return builder;
/*    */   }
/*    */ 
/*    */   
/*    */   @Lazy
/*    */   @Bean(name = {"applicationTaskExecutor", "taskExecutor"})
/*    */   @ConditionalOnMissingBean({Executor.class})
/*    */   public ThreadPoolTaskExecutor applicationTaskExecutor(TaskExecutorBuilder builder) {
/* 80 */     return builder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\task\TaskExecutionAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
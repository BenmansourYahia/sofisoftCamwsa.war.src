/*    */ package org.springframework.boot.autoconfigure.solr;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Optional;
/*    */ import org.apache.solr.client.solrj.SolrClient;
/*    */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*    */ import org.apache.solr.client.solrj.impl.HttpSolrClient;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({HttpSolrClient.class, CloudSolrClient.class})
/*    */ @EnableConfigurationProperties({SolrProperties.class})
/*    */ public class SolrAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SolrClient solrClient(SolrProperties properties) {
/* 48 */     if (StringUtils.hasText(properties.getZkHost())) {
/* 49 */       return (SolrClient)(new CloudSolrClient.Builder(Arrays.asList(new String[] { properties.getZkHost() }, ), Optional.empty())).build();
/*    */     }
/* 51 */     return (SolrClient)(new HttpSolrClient.Builder(properties.getHost())).build();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\solr\SolrAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.jackson")
/*     */ public class JacksonProperties
/*     */ {
/*     */   private String dateFormat;
/*     */   private String jodaDateTimeFormat;
/*     */   private String propertyNamingStrategy;
/*  69 */   private final Map<PropertyAccessor, JsonAutoDetect.Visibility> visibility = new EnumMap<>(PropertyAccessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private final Map<SerializationFeature, Boolean> serialization = new EnumMap<>(SerializationFeature.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private final Map<DeserializationFeature, Boolean> deserialization = new EnumMap<>(DeserializationFeature.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private final Map<MapperFeature, Boolean> mapper = new EnumMap<>(MapperFeature.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private final Map<JsonParser.Feature, Boolean> parser = new EnumMap<>(JsonParser.Feature.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private final Map<JsonGenerator.Feature, Boolean> generator = new EnumMap<>(JsonGenerator.Feature.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JsonInclude.Include defaultPropertyInclusion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   private TimeZone timeZone = null;
/*     */ 
/*     */   
/*     */   private Locale locale;
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateFormat() {
/* 114 */     return this.dateFormat;
/*     */   }
/*     */   
/*     */   public void setDateFormat(String dateFormat) {
/* 118 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(replacement = "dateFormat", reason = "Auto-configuration for Jackson's Joda-Time integration is deprecated in favor of its Java 8 Time integration")
/*     */   public String getJodaDateTimeFormat() {
/* 126 */     return this.jodaDateTimeFormat;
/*     */   }
/*     */   
/*     */   public void setJodaDateTimeFormat(String jodaDataTimeFormat) {
/* 130 */     this.jodaDateTimeFormat = jodaDataTimeFormat;
/*     */   }
/*     */   
/*     */   public String getPropertyNamingStrategy() {
/* 134 */     return this.propertyNamingStrategy;
/*     */   }
/*     */   
/*     */   public void setPropertyNamingStrategy(String propertyNamingStrategy) {
/* 138 */     this.propertyNamingStrategy = propertyNamingStrategy;
/*     */   }
/*     */   
/*     */   public Map<PropertyAccessor, JsonAutoDetect.Visibility> getVisibility() {
/* 142 */     return this.visibility;
/*     */   }
/*     */   
/*     */   public Map<SerializationFeature, Boolean> getSerialization() {
/* 146 */     return this.serialization;
/*     */   }
/*     */   
/*     */   public Map<DeserializationFeature, Boolean> getDeserialization() {
/* 150 */     return this.deserialization;
/*     */   }
/*     */   
/*     */   public Map<MapperFeature, Boolean> getMapper() {
/* 154 */     return this.mapper;
/*     */   }
/*     */   
/*     */   public Map<JsonParser.Feature, Boolean> getParser() {
/* 158 */     return this.parser;
/*     */   }
/*     */   
/*     */   public Map<JsonGenerator.Feature, Boolean> getGenerator() {
/* 162 */     return this.generator;
/*     */   }
/*     */   
/*     */   public JsonInclude.Include getDefaultPropertyInclusion() {
/* 166 */     return this.defaultPropertyInclusion;
/*     */   }
/*     */   
/*     */   public void setDefaultPropertyInclusion(JsonInclude.Include defaultPropertyInclusion) {
/* 170 */     this.defaultPropertyInclusion = defaultPropertyInclusion;
/*     */   }
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 174 */     return this.timeZone;
/*     */   }
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 178 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 182 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 186 */     this.locale = locale;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jackson\JacksonProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
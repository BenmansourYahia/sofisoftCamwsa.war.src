/*     */ package org.springframework.boot.autoconfigure.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import com.fasterxml.jackson.datatype.joda.cfg.JacksonJodaDateFormat;
/*     */ import com.fasterxml.jackson.datatype.joda.ser.DateTimeSerializer;
/*     */ import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
/*     */ import java.lang.reflect.Field;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.joda.time.DateTime;
/*     */ import org.joda.time.format.DateTimeFormat;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jackson.JsonComponentModule;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ import org.springframework.context.annotation.Scope;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({ObjectMapper.class})
/*     */ public class JacksonAutoConfiguration
/*     */ {
/*     */   private static final Map<?, Boolean> FEATURE_DEFAULTS;
/*     */   
/*     */   static {
/*  89 */     Map<Object, Boolean> featureDefaults = new HashMap<>();
/*  90 */     featureDefaults.put(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, Boolean.valueOf(false));
/*  91 */     FEATURE_DEFAULTS = Collections.unmodifiableMap(featureDefaults);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public JsonComponentModule jsonComponentModule() {
/*  96 */     return new JsonComponentModule();
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Jackson2ObjectMapperBuilder.class})
/*     */   static class JacksonObjectMapperConfiguration
/*     */   {
/*     */     @Bean
/*     */     @Primary
/*     */     @ConditionalOnMissingBean
/*     */     ObjectMapper jacksonObjectMapper(Jackson2ObjectMapperBuilder builder) {
/* 107 */       return builder.createXmlMapper(false).build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Jackson2ObjectMapperBuilder.class, DateTime.class, DateTimeSerializer.class, JacksonJodaDateFormat.class})
/*     */   static class JodaDateTimeJacksonConfiguration
/*     */   {
/* 118 */     private static final Log logger = LogFactory.getLog(JodaDateTimeJacksonConfiguration.class);
/*     */     
/*     */     @Bean
/*     */     SimpleModule jodaDateTimeSerializationModule(JacksonProperties jacksonProperties) {
/* 122 */       logger.warn("Auto-configuration of Jackson's Joda-Time integration is deprecated in favor of using java.time (JSR-310).");
/*     */       
/* 124 */       SimpleModule module = new SimpleModule();
/* 125 */       JacksonJodaDateFormat jacksonJodaFormat = getJacksonJodaDateFormat(jacksonProperties);
/* 126 */       if (jacksonJodaFormat != null) {
/* 127 */         module.addSerializer(DateTime.class, (JsonSerializer)new DateTimeSerializer(jacksonJodaFormat, 0));
/*     */       }
/* 129 */       return module;
/*     */     }
/*     */     
/*     */     private JacksonJodaDateFormat getJacksonJodaDateFormat(JacksonProperties jacksonProperties) {
/* 133 */       if (jacksonProperties.getJodaDateTimeFormat() != null) {
/* 134 */         return new JacksonJodaDateFormat(
/* 135 */             DateTimeFormat.forPattern(jacksonProperties.getJodaDateTimeFormat()).withZoneUTC());
/*     */       }
/* 137 */       if (jacksonProperties.getDateFormat() != null) {
/*     */         try {
/* 139 */           return new JacksonJodaDateFormat(
/* 140 */               DateTimeFormat.forPattern(jacksonProperties.getDateFormat()).withZoneUTC());
/*     */         }
/* 142 */         catch (IllegalArgumentException ex) {
/* 143 */           if (logger.isWarnEnabled()) {
/* 144 */             logger.warn("spring.jackson.date-format could not be used to configure formatting of Joda's DateTime. You may want to configure spring.jackson.joda-date-time-format as well.");
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 150 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({ParameterNamesModule.class})
/*     */   static class ParameterNamesModuleConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ParameterNamesModule parameterNamesModule() {
/* 162 */       return new ParameterNamesModule(JsonCreator.Mode.DEFAULT);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Jackson2ObjectMapperBuilder.class})
/*     */   static class JacksonObjectMapperBuilderConfiguration
/*     */   {
/*     */     @Bean
/*     */     @Scope("prototype")
/*     */     @ConditionalOnMissingBean
/*     */     Jackson2ObjectMapperBuilder jacksonObjectMapperBuilder(ApplicationContext applicationContext, List<Jackson2ObjectMapperBuilderCustomizer> customizers) {
/* 176 */       Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
/* 177 */       builder.applicationContext(applicationContext);
/* 178 */       customize(builder, customizers);
/* 179 */       return builder;
/*     */     }
/*     */ 
/*     */     
/*     */     private void customize(Jackson2ObjectMapperBuilder builder, List<Jackson2ObjectMapperBuilderCustomizer> customizers) {
/* 184 */       for (Jackson2ObjectMapperBuilderCustomizer customizer : customizers) {
/* 185 */         customizer.customize(builder);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Jackson2ObjectMapperBuilder.class})
/*     */   @EnableConfigurationProperties({JacksonProperties.class})
/*     */   static class Jackson2ObjectMapperBuilderCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     StandardJackson2ObjectMapperBuilderCustomizer standardJacksonObjectMapperBuilderCustomizer(ApplicationContext applicationContext, JacksonProperties jacksonProperties) {
/* 199 */       return new StandardJackson2ObjectMapperBuilderCustomizer(applicationContext, jacksonProperties);
/*     */     }
/*     */ 
/*     */     
/*     */     static final class StandardJackson2ObjectMapperBuilderCustomizer
/*     */       implements Jackson2ObjectMapperBuilderCustomizer, Ordered
/*     */     {
/*     */       private final ApplicationContext applicationContext;
/*     */       
/*     */       private final JacksonProperties jacksonProperties;
/*     */       
/*     */       StandardJackson2ObjectMapperBuilderCustomizer(ApplicationContext applicationContext, JacksonProperties jacksonProperties) {
/* 211 */         this.applicationContext = applicationContext;
/* 212 */         this.jacksonProperties = jacksonProperties;
/*     */       }
/*     */ 
/*     */       
/*     */       public int getOrder() {
/* 217 */         return 0;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void customize(Jackson2ObjectMapperBuilder builder) {
/* 223 */         if (this.jacksonProperties.getDefaultPropertyInclusion() != null) {
/* 224 */           builder.serializationInclusion(this.jacksonProperties.getDefaultPropertyInclusion());
/*     */         }
/* 226 */         if (this.jacksonProperties.getTimeZone() != null) {
/* 227 */           builder.timeZone(this.jacksonProperties.getTimeZone());
/*     */         }
/* 229 */         configureFeatures(builder, JacksonAutoConfiguration.FEATURE_DEFAULTS);
/* 230 */         configureVisibility(builder, this.jacksonProperties.getVisibility());
/* 231 */         configureFeatures(builder, this.jacksonProperties.getDeserialization());
/* 232 */         configureFeatures(builder, this.jacksonProperties.getSerialization());
/* 233 */         configureFeatures(builder, this.jacksonProperties.getMapper());
/* 234 */         configureFeatures(builder, this.jacksonProperties.getParser());
/* 235 */         configureFeatures(builder, this.jacksonProperties.getGenerator());
/* 236 */         configureDateFormat(builder);
/* 237 */         configurePropertyNamingStrategy(builder);
/* 238 */         configureModules(builder);
/* 239 */         configureLocale(builder);
/*     */       }
/*     */       
/*     */       private void configureFeatures(Jackson2ObjectMapperBuilder builder, Map<?, Boolean> features) {
/* 243 */         features.forEach((feature, value) -> {
/*     */               if (value != null) {
/*     */                 if (value.booleanValue()) {
/*     */                   builder.featuresToEnable(new Object[] { feature });
/*     */                 } else {
/*     */                   builder.featuresToDisable(new Object[] { feature });
/*     */                 } 
/*     */               }
/*     */             });
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       private void configureVisibility(Jackson2ObjectMapperBuilder builder, Map<PropertyAccessor, JsonAutoDetect.Visibility> visibilities) {
/* 257 */         visibilities.forEach(builder::visibility);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       private void configureDateFormat(Jackson2ObjectMapperBuilder builder) {
/* 263 */         String dateFormat = this.jacksonProperties.getDateFormat();
/* 264 */         if (dateFormat != null) {
/*     */           try {
/* 266 */             Class<?> dateFormatClass = ClassUtils.forName(dateFormat, null);
/* 267 */             builder.dateFormat((DateFormat)BeanUtils.instantiateClass(dateFormatClass));
/*     */           }
/* 269 */           catch (ClassNotFoundException ex) {
/* 270 */             SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
/*     */ 
/*     */ 
/*     */             
/* 274 */             TimeZone timeZone = this.jacksonProperties.getTimeZone();
/* 275 */             if (timeZone == null) {
/* 276 */               timeZone = (new ObjectMapper()).getSerializationConfig().getTimeZone();
/*     */             }
/* 278 */             simpleDateFormat.setTimeZone(timeZone);
/* 279 */             builder.dateFormat(simpleDateFormat);
/*     */           } 
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private void configurePropertyNamingStrategy(Jackson2ObjectMapperBuilder builder) {
/* 289 */         String strategy = this.jacksonProperties.getPropertyNamingStrategy();
/* 290 */         if (strategy != null) {
/*     */           try {
/* 292 */             configurePropertyNamingStrategyClass(builder, ClassUtils.forName(strategy, null));
/*     */           }
/* 294 */           catch (ClassNotFoundException ex) {
/* 295 */             configurePropertyNamingStrategyField(builder, strategy);
/*     */           } 
/*     */         }
/*     */       }
/*     */ 
/*     */       
/*     */       private void configurePropertyNamingStrategyClass(Jackson2ObjectMapperBuilder builder, Class<?> propertyNamingStrategyClass) {
/* 302 */         builder.propertyNamingStrategy(
/* 303 */             (PropertyNamingStrategy)BeanUtils.instantiateClass(propertyNamingStrategyClass));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       private void configurePropertyNamingStrategyField(Jackson2ObjectMapperBuilder builder, String fieldName) {
/* 309 */         Field field = ReflectionUtils.findField(PropertyNamingStrategy.class, fieldName, PropertyNamingStrategy.class);
/*     */         
/* 311 */         Assert.notNull(field, () -> "Constant named '" + fieldName + "' not found on " + PropertyNamingStrategy.class.getName());
/*     */         
/*     */         try {
/* 314 */           builder.propertyNamingStrategy((PropertyNamingStrategy)field.get(null));
/*     */         }
/* 316 */         catch (Exception ex) {
/* 317 */           throw new IllegalStateException(ex);
/*     */         } 
/*     */       }
/*     */       
/*     */       private void configureModules(Jackson2ObjectMapperBuilder builder) {
/* 322 */         Collection<Module> moduleBeans = getBeans((ListableBeanFactory)this.applicationContext, Module.class);
/* 323 */         builder.modulesToInstall(moduleBeans.<Module>toArray(new Module[0]));
/*     */       }
/*     */       
/*     */       private void configureLocale(Jackson2ObjectMapperBuilder builder) {
/* 327 */         Locale locale = this.jacksonProperties.getLocale();
/* 328 */         if (locale != null) {
/* 329 */           builder.locale(locale);
/*     */         }
/*     */       }
/*     */       
/*     */       private static <T> Collection<T> getBeans(ListableBeanFactory beanFactory, Class<T> type) {
/* 334 */         return BeanFactoryUtils.beansOfTypeIncludingAncestors(beanFactory, type).values();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jackson\JacksonAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
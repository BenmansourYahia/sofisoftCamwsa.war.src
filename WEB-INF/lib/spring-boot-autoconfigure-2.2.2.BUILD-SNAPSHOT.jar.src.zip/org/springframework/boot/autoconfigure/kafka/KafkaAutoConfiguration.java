/*     */ package org.springframework.boot.autoconfigure.kafka;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.kafka.core.ConsumerFactory;
/*     */ import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
/*     */ import org.springframework.kafka.core.DefaultKafkaProducerFactory;
/*     */ import org.springframework.kafka.core.KafkaAdmin;
/*     */ import org.springframework.kafka.core.KafkaTemplate;
/*     */ import org.springframework.kafka.core.ProducerFactory;
/*     */ import org.springframework.kafka.security.jaas.KafkaJaasLoginModuleInitializer;
/*     */ import org.springframework.kafka.support.LoggingProducerListener;
/*     */ import org.springframework.kafka.support.ProducerListener;
/*     */ import org.springframework.kafka.support.converter.RecordMessageConverter;
/*     */ import org.springframework.kafka.transaction.KafkaTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({KafkaTemplate.class})
/*     */ @EnableConfigurationProperties({KafkaProperties.class})
/*     */ @Import({KafkaAnnotationDrivenConfiguration.class, KafkaStreamsAnnotationDrivenConfiguration.class})
/*     */ public class KafkaAutoConfiguration
/*     */ {
/*     */   private final KafkaProperties properties;
/*     */   
/*     */   public KafkaAutoConfiguration(KafkaProperties properties) {
/*  61 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({KafkaTemplate.class})
/*     */   public KafkaTemplate<?, ?> kafkaTemplate(ProducerFactory<Object, Object> kafkaProducerFactory, ProducerListener<Object, Object> kafkaProducerListener, ObjectProvider<RecordMessageConverter> messageConverter) {
/*  69 */     KafkaTemplate<Object, Object> kafkaTemplate = new KafkaTemplate(kafkaProducerFactory);
/*  70 */     messageConverter.ifUnique(kafkaTemplate::setMessageConverter);
/*  71 */     kafkaTemplate.setProducerListener(kafkaProducerListener);
/*  72 */     kafkaTemplate.setDefaultTopic(this.properties.getTemplate().getDefaultTopic());
/*  73 */     return kafkaTemplate;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ProducerListener.class})
/*     */   public ProducerListener<Object, Object> kafkaProducerListener() {
/*  79 */     return (ProducerListener<Object, Object>)new LoggingProducerListener();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ConsumerFactory.class})
/*     */   public ConsumerFactory<?, ?> kafkaConsumerFactory() {
/*  85 */     return (ConsumerFactory<?, ?>)new DefaultKafkaConsumerFactory(this.properties.buildConsumerProperties());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ProducerFactory.class})
/*     */   public ProducerFactory<?, ?> kafkaProducerFactory() {
/*  92 */     DefaultKafkaProducerFactory<?, ?> factory = new DefaultKafkaProducerFactory(this.properties.buildProducerProperties());
/*  93 */     String transactionIdPrefix = this.properties.getProducer().getTransactionIdPrefix();
/*  94 */     if (transactionIdPrefix != null) {
/*  95 */       factory.setTransactionIdPrefix(transactionIdPrefix);
/*     */     }
/*  97 */     return (ProducerFactory<?, ?>)factory;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnProperty(name = {"spring.kafka.producer.transaction-id-prefix"})
/*     */   @ConditionalOnMissingBean
/*     */   public KafkaTransactionManager<?, ?> kafkaTransactionManager(ProducerFactory<?, ?> producerFactory) {
/* 104 */     return new KafkaTransactionManager(producerFactory);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnProperty(name = {"spring.kafka.jaas.enabled"})
/*     */   @ConditionalOnMissingBean
/*     */   public KafkaJaasLoginModuleInitializer kafkaJaasInitializer() throws IOException {
/* 111 */     KafkaJaasLoginModuleInitializer jaas = new KafkaJaasLoginModuleInitializer();
/* 112 */     KafkaProperties.Jaas jaasProperties = this.properties.getJaas();
/* 113 */     if (jaasProperties.getControlFlag() != null) {
/* 114 */       jaas.setControlFlag(jaasProperties.getControlFlag());
/*     */     }
/* 116 */     if (jaasProperties.getLoginModule() != null) {
/* 117 */       jaas.setLoginModule(jaasProperties.getLoginModule());
/*     */     }
/* 119 */     jaas.setOptions(jaasProperties.getOptions());
/* 120 */     return jaas;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public KafkaAdmin kafkaAdmin() {
/* 126 */     KafkaAdmin kafkaAdmin = new KafkaAdmin(this.properties.buildAdminProperties());
/* 127 */     kafkaAdmin.setFatalIfBrokerNotAvailable(this.properties.getAdmin().isFailFast());
/* 128 */     return kafkaAdmin;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\kafka\KafkaAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
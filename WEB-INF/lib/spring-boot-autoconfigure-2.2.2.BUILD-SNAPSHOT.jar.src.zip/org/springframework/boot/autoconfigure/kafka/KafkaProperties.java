/*      */ package org.springframework.boot.autoconfigure.kafka;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.time.Duration;
/*      */ import java.time.temporal.ChronoUnit;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import org.apache.kafka.common.requests.IsolationLevel;
/*      */ import org.apache.kafka.common.serialization.StringDeserializer;
/*      */ import org.apache.kafka.common.serialization.StringSerializer;
/*      */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*      */ import org.springframework.boot.context.properties.PropertyMapper;
/*      */ import org.springframework.boot.convert.DurationUnit;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.kafka.listener.ContainerProperties;
/*      */ import org.springframework.kafka.security.jaas.KafkaJaasLoginModuleInitializer;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.unit.DataSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @ConfigurationProperties(prefix = "spring.kafka")
/*      */ public class KafkaProperties
/*      */ {
/*   65 */   private List<String> bootstrapServers = new ArrayList<>(Collections.singletonList("localhost:9092"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String clientId;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   76 */   private final Map<String, String> properties = new HashMap<>();
/*      */   
/*   78 */   private final Consumer consumer = new Consumer();
/*      */   
/*   80 */   private final Producer producer = new Producer();
/*      */   
/*   82 */   private final Admin admin = new Admin();
/*      */   
/*   84 */   private final Streams streams = new Streams();
/*      */   
/*   86 */   private final Listener listener = new Listener();
/*      */   
/*   88 */   private final Ssl ssl = new Ssl();
/*      */   
/*   90 */   private final Jaas jaas = new Jaas();
/*      */   
/*   92 */   private final Template template = new Template();
/*      */   
/*      */   public List<String> getBootstrapServers() {
/*   95 */     return this.bootstrapServers;
/*      */   }
/*      */   
/*      */   public void setBootstrapServers(List<String> bootstrapServers) {
/*   99 */     this.bootstrapServers = bootstrapServers;
/*      */   }
/*      */   
/*      */   public String getClientId() {
/*  103 */     return this.clientId;
/*      */   }
/*      */   
/*      */   public void setClientId(String clientId) {
/*  107 */     this.clientId = clientId;
/*      */   }
/*      */   
/*      */   public Map<String, String> getProperties() {
/*  111 */     return this.properties;
/*      */   }
/*      */   
/*      */   public Consumer getConsumer() {
/*  115 */     return this.consumer;
/*      */   }
/*      */   
/*      */   public Producer getProducer() {
/*  119 */     return this.producer;
/*      */   }
/*      */   
/*      */   public Listener getListener() {
/*  123 */     return this.listener;
/*      */   }
/*      */   
/*      */   public Admin getAdmin() {
/*  127 */     return this.admin;
/*      */   }
/*      */   
/*      */   public Streams getStreams() {
/*  131 */     return this.streams;
/*      */   }
/*      */   
/*      */   public Ssl getSsl() {
/*  135 */     return this.ssl;
/*      */   }
/*      */   
/*      */   public Jaas getJaas() {
/*  139 */     return this.jaas;
/*      */   }
/*      */   
/*      */   public Template getTemplate() {
/*  143 */     return this.template;
/*      */   }
/*      */   
/*      */   private Map<String, Object> buildCommonProperties() {
/*  147 */     Map<String, Object> properties = new HashMap<>();
/*  148 */     if (this.bootstrapServers != null) {
/*  149 */       properties.put("bootstrap.servers", this.bootstrapServers);
/*      */     }
/*  151 */     if (this.clientId != null) {
/*  152 */       properties.put("client.id", this.clientId);
/*      */     }
/*  154 */     properties.putAll(this.ssl.buildProperties());
/*  155 */     if (!CollectionUtils.isEmpty(this.properties)) {
/*  156 */       properties.putAll(this.properties);
/*      */     }
/*  158 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> buildConsumerProperties() {
/*  170 */     Map<String, Object> properties = buildCommonProperties();
/*  171 */     properties.putAll(this.consumer.buildProperties());
/*  172 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> buildProducerProperties() {
/*  184 */     Map<String, Object> properties = buildCommonProperties();
/*  185 */     properties.putAll(this.producer.buildProperties());
/*  186 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> buildAdminProperties() {
/*  198 */     Map<String, Object> properties = buildCommonProperties();
/*  199 */     properties.putAll(this.admin.buildProperties());
/*  200 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> buildStreamsProperties() {
/*  211 */     Map<String, Object> properties = buildCommonProperties();
/*  212 */     properties.putAll(this.streams.buildProperties());
/*  213 */     return properties;
/*      */   }
/*      */   
/*      */   public static class Consumer
/*      */   {
/*  218 */     private final KafkaProperties.Ssl ssl = new KafkaProperties.Ssl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration autoCommitInterval;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String autoOffsetReset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private List<String> bootstrapServers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String clientId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean enableAutoCommit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration fetchMaxWait;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DataSize fetchMinSize;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String groupId;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration heartbeatInterval;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  274 */     private IsolationLevel isolationLevel = IsolationLevel.READ_UNCOMMITTED;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  279 */     private Class<?> keyDeserializer = StringDeserializer.class;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  284 */     private Class<?> valueDeserializer = StringDeserializer.class;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer maxPollRecords;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  294 */     private final Map<String, String> properties = new HashMap<>();
/*      */     
/*      */     public KafkaProperties.Ssl getSsl() {
/*  297 */       return this.ssl;
/*      */     }
/*      */     
/*      */     public Duration getAutoCommitInterval() {
/*  301 */       return this.autoCommitInterval;
/*      */     }
/*      */     
/*      */     public void setAutoCommitInterval(Duration autoCommitInterval) {
/*  305 */       this.autoCommitInterval = autoCommitInterval;
/*      */     }
/*      */     
/*      */     public String getAutoOffsetReset() {
/*  309 */       return this.autoOffsetReset;
/*      */     }
/*      */     
/*      */     public void setAutoOffsetReset(String autoOffsetReset) {
/*  313 */       this.autoOffsetReset = autoOffsetReset;
/*      */     }
/*      */     
/*      */     public List<String> getBootstrapServers() {
/*  317 */       return this.bootstrapServers;
/*      */     }
/*      */     
/*      */     public void setBootstrapServers(List<String> bootstrapServers) {
/*  321 */       this.bootstrapServers = bootstrapServers;
/*      */     }
/*      */     
/*      */     public String getClientId() {
/*  325 */       return this.clientId;
/*      */     }
/*      */     
/*      */     public void setClientId(String clientId) {
/*  329 */       this.clientId = clientId;
/*      */     }
/*      */     
/*      */     public Boolean getEnableAutoCommit() {
/*  333 */       return this.enableAutoCommit;
/*      */     }
/*      */     
/*      */     public void setEnableAutoCommit(Boolean enableAutoCommit) {
/*  337 */       this.enableAutoCommit = enableAutoCommit;
/*      */     }
/*      */     
/*      */     public Duration getFetchMaxWait() {
/*  341 */       return this.fetchMaxWait;
/*      */     }
/*      */     
/*      */     public void setFetchMaxWait(Duration fetchMaxWait) {
/*  345 */       this.fetchMaxWait = fetchMaxWait;
/*      */     }
/*      */     
/*      */     public DataSize getFetchMinSize() {
/*  349 */       return this.fetchMinSize;
/*      */     }
/*      */     
/*      */     public void setFetchMinSize(DataSize fetchMinSize) {
/*  353 */       this.fetchMinSize = fetchMinSize;
/*      */     }
/*      */     
/*      */     public String getGroupId() {
/*  357 */       return this.groupId;
/*      */     }
/*      */     
/*      */     public void setGroupId(String groupId) {
/*  361 */       this.groupId = groupId;
/*      */     }
/*      */     
/*      */     public Duration getHeartbeatInterval() {
/*  365 */       return this.heartbeatInterval;
/*      */     }
/*      */     
/*      */     public void setHeartbeatInterval(Duration heartbeatInterval) {
/*  369 */       this.heartbeatInterval = heartbeatInterval;
/*      */     }
/*      */     
/*      */     public IsolationLevel getIsolationLevel() {
/*  373 */       return this.isolationLevel;
/*      */     }
/*      */     
/*      */     public void setIsolationLevel(IsolationLevel isolationLevel) {
/*  377 */       this.isolationLevel = isolationLevel;
/*      */     }
/*      */     
/*      */     public Class<?> getKeyDeserializer() {
/*  381 */       return this.keyDeserializer;
/*      */     }
/*      */     
/*      */     public void setKeyDeserializer(Class<?> keyDeserializer) {
/*  385 */       this.keyDeserializer = keyDeserializer;
/*      */     }
/*      */     
/*      */     public Class<?> getValueDeserializer() {
/*  389 */       return this.valueDeserializer;
/*      */     }
/*      */     
/*      */     public void setValueDeserializer(Class<?> valueDeserializer) {
/*  393 */       this.valueDeserializer = valueDeserializer;
/*      */     }
/*      */     
/*      */     public Integer getMaxPollRecords() {
/*  397 */       return this.maxPollRecords;
/*      */     }
/*      */     
/*      */     public void setMaxPollRecords(Integer maxPollRecords) {
/*  401 */       this.maxPollRecords = maxPollRecords;
/*      */     }
/*      */     
/*      */     public Map<String, String> getProperties() {
/*  405 */       return this.properties;
/*      */     }
/*      */     
/*      */     public Map<String, Object> buildProperties() {
/*  409 */       KafkaProperties.Properties properties = new KafkaProperties.Properties();
/*  410 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  411 */       map.from(this::getAutoCommitInterval).asInt(Duration::toMillis)
/*  412 */         .to(properties.in("auto.commit.interval.ms"));
/*  413 */       map.from(this::getAutoOffsetReset).to(properties.in("auto.offset.reset"));
/*  414 */       map.from(this::getBootstrapServers).to(properties.in("bootstrap.servers"));
/*  415 */       map.from(this::getClientId).to(properties.in("client.id"));
/*  416 */       map.from(this::getEnableAutoCommit).to(properties.in("enable.auto.commit"));
/*  417 */       map.from(this::getFetchMaxWait).asInt(Duration::toMillis)
/*  418 */         .to(properties.in("fetch.max.wait.ms"));
/*  419 */       map.from(this::getFetchMinSize).asInt(DataSize::toBytes)
/*  420 */         .to(properties.in("fetch.min.bytes"));
/*  421 */       map.from(this::getGroupId).to(properties.in("group.id"));
/*  422 */       map.from(this::getHeartbeatInterval).asInt(Duration::toMillis)
/*  423 */         .to(properties.in("heartbeat.interval.ms"));
/*  424 */       map.from(() -> getIsolationLevel().name().toLowerCase(Locale.ROOT))
/*  425 */         .to(properties.in("isolation.level"));
/*  426 */       map.from(this::getKeyDeserializer).to(properties.in("key.deserializer"));
/*  427 */       map.from(this::getValueDeserializer).to(properties.in("value.deserializer"));
/*  428 */       map.from(this::getMaxPollRecords).to(properties.in("max.poll.records"));
/*  429 */       return properties.with(this.ssl, this.properties);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class Producer
/*      */   {
/*  436 */     private final KafkaProperties.Ssl ssl = new KafkaProperties.Ssl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String acks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DataSize batchSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private List<String> bootstrapServers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DataSize bufferMemory;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String clientId;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String compressionType;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  475 */     private Class<?> keySerializer = StringSerializer.class;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  480 */     private Class<?> valueSerializer = StringSerializer.class;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer retries;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String transactionIdPrefix;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  495 */     private final Map<String, String> properties = new HashMap<>();
/*      */     
/*      */     public KafkaProperties.Ssl getSsl() {
/*  498 */       return this.ssl;
/*      */     }
/*      */     
/*      */     public String getAcks() {
/*  502 */       return this.acks;
/*      */     }
/*      */     
/*      */     public void setAcks(String acks) {
/*  506 */       this.acks = acks;
/*      */     }
/*      */     
/*      */     public DataSize getBatchSize() {
/*  510 */       return this.batchSize;
/*      */     }
/*      */     
/*      */     public void setBatchSize(DataSize batchSize) {
/*  514 */       this.batchSize = batchSize;
/*      */     }
/*      */     
/*      */     public List<String> getBootstrapServers() {
/*  518 */       return this.bootstrapServers;
/*      */     }
/*      */     
/*      */     public void setBootstrapServers(List<String> bootstrapServers) {
/*  522 */       this.bootstrapServers = bootstrapServers;
/*      */     }
/*      */     
/*      */     public DataSize getBufferMemory() {
/*  526 */       return this.bufferMemory;
/*      */     }
/*      */     
/*      */     public void setBufferMemory(DataSize bufferMemory) {
/*  530 */       this.bufferMemory = bufferMemory;
/*      */     }
/*      */     
/*      */     public String getClientId() {
/*  534 */       return this.clientId;
/*      */     }
/*      */     
/*      */     public void setClientId(String clientId) {
/*  538 */       this.clientId = clientId;
/*      */     }
/*      */     
/*      */     public String getCompressionType() {
/*  542 */       return this.compressionType;
/*      */     }
/*      */     
/*      */     public void setCompressionType(String compressionType) {
/*  546 */       this.compressionType = compressionType;
/*      */     }
/*      */     
/*      */     public Class<?> getKeySerializer() {
/*  550 */       return this.keySerializer;
/*      */     }
/*      */     
/*      */     public void setKeySerializer(Class<?> keySerializer) {
/*  554 */       this.keySerializer = keySerializer;
/*      */     }
/*      */     
/*      */     public Class<?> getValueSerializer() {
/*  558 */       return this.valueSerializer;
/*      */     }
/*      */     
/*      */     public void setValueSerializer(Class<?> valueSerializer) {
/*  562 */       this.valueSerializer = valueSerializer;
/*      */     }
/*      */     
/*      */     public Integer getRetries() {
/*  566 */       return this.retries;
/*      */     }
/*      */     
/*      */     public void setRetries(Integer retries) {
/*  570 */       this.retries = retries;
/*      */     }
/*      */     
/*      */     public String getTransactionIdPrefix() {
/*  574 */       return this.transactionIdPrefix;
/*      */     }
/*      */     
/*      */     public void setTransactionIdPrefix(String transactionIdPrefix) {
/*  578 */       this.transactionIdPrefix = transactionIdPrefix;
/*      */     }
/*      */     
/*      */     public Map<String, String> getProperties() {
/*  582 */       return this.properties;
/*      */     }
/*      */     
/*      */     public Map<String, Object> buildProperties() {
/*  586 */       KafkaProperties.Properties properties = new KafkaProperties.Properties();
/*  587 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  588 */       map.from(this::getAcks).to(properties.in("acks"));
/*  589 */       map.from(this::getBatchSize).asInt(DataSize::toBytes).to(properties.in("batch.size"));
/*  590 */       map.from(this::getBootstrapServers).to(properties.in("bootstrap.servers"));
/*  591 */       map.from(this::getBufferMemory).as(DataSize::toBytes)
/*  592 */         .to(properties.in("buffer.memory"));
/*  593 */       map.from(this::getClientId).to(properties.in("client.id"));
/*  594 */       map.from(this::getCompressionType).to(properties.in("compression.type"));
/*  595 */       map.from(this::getKeySerializer).to(properties.in("key.serializer"));
/*  596 */       map.from(this::getRetries).to(properties.in("retries"));
/*  597 */       map.from(this::getValueSerializer).to(properties.in("value.serializer"));
/*  598 */       return properties.with(this.ssl, this.properties);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class Admin
/*      */   {
/*  605 */     private final KafkaProperties.Ssl ssl = new KafkaProperties.Ssl();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String clientId;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  615 */     private final Map<String, String> properties = new HashMap<>();
/*      */ 
/*      */     
/*      */     private boolean failFast;
/*      */ 
/*      */ 
/*      */     
/*      */     public KafkaProperties.Ssl getSsl() {
/*  623 */       return this.ssl;
/*      */     }
/*      */     
/*      */     public String getClientId() {
/*  627 */       return this.clientId;
/*      */     }
/*      */     
/*      */     public void setClientId(String clientId) {
/*  631 */       this.clientId = clientId;
/*      */     }
/*      */     
/*      */     public boolean isFailFast() {
/*  635 */       return this.failFast;
/*      */     }
/*      */     
/*      */     public void setFailFast(boolean failFast) {
/*  639 */       this.failFast = failFast;
/*      */     }
/*      */     
/*      */     public Map<String, String> getProperties() {
/*  643 */       return this.properties;
/*      */     }
/*      */     
/*      */     public Map<String, Object> buildProperties() {
/*  647 */       KafkaProperties.Properties properties = new KafkaProperties.Properties();
/*  648 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  649 */       map.from(this::getClientId).to(properties.in("client.id"));
/*  650 */       return properties.with(this.ssl, this.properties);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Streams
/*      */   {
/*  660 */     private final KafkaProperties.Ssl ssl = new KafkaProperties.Ssl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String applicationId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean autoStartup = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private List<String> bootstrapServers;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DataSize cacheMaxSizeBuffering;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String clientId;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer replicationFactor;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String stateDir;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  702 */     private final Map<String, String> properties = new HashMap<>();
/*      */     
/*      */     public KafkaProperties.Ssl getSsl() {
/*  705 */       return this.ssl;
/*      */     }
/*      */     
/*      */     public String getApplicationId() {
/*  709 */       return this.applicationId;
/*      */     }
/*      */     
/*      */     public void setApplicationId(String applicationId) {
/*  713 */       this.applicationId = applicationId;
/*      */     }
/*      */     
/*      */     public boolean isAutoStartup() {
/*  717 */       return this.autoStartup;
/*      */     }
/*      */     
/*      */     public void setAutoStartup(boolean autoStartup) {
/*  721 */       this.autoStartup = autoStartup;
/*      */     }
/*      */     
/*      */     public List<String> getBootstrapServers() {
/*  725 */       return this.bootstrapServers;
/*      */     }
/*      */     
/*      */     public void setBootstrapServers(List<String> bootstrapServers) {
/*  729 */       this.bootstrapServers = bootstrapServers;
/*      */     }
/*      */     
/*      */     public DataSize getCacheMaxSizeBuffering() {
/*  733 */       return this.cacheMaxSizeBuffering;
/*      */     }
/*      */     
/*      */     public void setCacheMaxSizeBuffering(DataSize cacheMaxSizeBuffering) {
/*  737 */       this.cacheMaxSizeBuffering = cacheMaxSizeBuffering;
/*      */     }
/*      */     
/*      */     public String getClientId() {
/*  741 */       return this.clientId;
/*      */     }
/*      */     
/*      */     public void setClientId(String clientId) {
/*  745 */       this.clientId = clientId;
/*      */     }
/*      */     
/*      */     public Integer getReplicationFactor() {
/*  749 */       return this.replicationFactor;
/*      */     }
/*      */     
/*      */     public void setReplicationFactor(Integer replicationFactor) {
/*  753 */       this.replicationFactor = replicationFactor;
/*      */     }
/*      */     
/*      */     public String getStateDir() {
/*  757 */       return this.stateDir;
/*      */     }
/*      */     
/*      */     public void setStateDir(String stateDir) {
/*  761 */       this.stateDir = stateDir;
/*      */     }
/*      */     
/*      */     public Map<String, String> getProperties() {
/*  765 */       return this.properties;
/*      */     }
/*      */     
/*      */     public Map<String, Object> buildProperties() {
/*  769 */       KafkaProperties.Properties properties = new KafkaProperties.Properties();
/*  770 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  771 */       map.from(this::getApplicationId).to(properties.in("application.id"));
/*  772 */       map.from(this::getBootstrapServers).to(properties.in("bootstrap.servers"));
/*  773 */       map.from(this::getCacheMaxSizeBuffering).asInt(DataSize::toBytes)
/*  774 */         .to(properties.in("cache.max.bytes.buffering"));
/*  775 */       map.from(this::getClientId).to(properties.in("client.id"));
/*  776 */       map.from(this::getReplicationFactor).to(properties.in("replication.factor"));
/*  777 */       map.from(this::getStateDir).to(properties.in("state.dir"));
/*  778 */       return properties.with(this.ssl, this.properties);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Template
/*      */   {
/*      */     private String defaultTopic;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getDefaultTopic() {
/*  791 */       return this.defaultTopic;
/*      */     }
/*      */     
/*      */     public void setDefaultTopic(String defaultTopic) {
/*  795 */       this.defaultTopic = defaultTopic;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Listener
/*      */   {
/*      */     public enum Type
/*      */     {
/*  807 */       SINGLE,
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  812 */       BATCH;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  819 */     private Type type = Type.SINGLE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ContainerProperties.AckMode ackMode;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String clientId;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer concurrency;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration pollTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Float noPollThreshold;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer ackCount;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration ackTime;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration idleEventInterval;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @DurationUnit(ChronoUnit.SECONDS)
/*      */     private Duration monitorInterval;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean logContainerConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean missingTopicsFatal = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Type getType() {
/*  882 */       return this.type;
/*      */     }
/*      */     
/*      */     public void setType(Type type) {
/*  886 */       this.type = type;
/*      */     }
/*      */     
/*      */     public ContainerProperties.AckMode getAckMode() {
/*  890 */       return this.ackMode;
/*      */     }
/*      */     
/*      */     public void setAckMode(ContainerProperties.AckMode ackMode) {
/*  894 */       this.ackMode = ackMode;
/*      */     }
/*      */     
/*      */     public String getClientId() {
/*  898 */       return this.clientId;
/*      */     }
/*      */     
/*      */     public void setClientId(String clientId) {
/*  902 */       this.clientId = clientId;
/*      */     }
/*      */     
/*      */     public Integer getConcurrency() {
/*  906 */       return this.concurrency;
/*      */     }
/*      */     
/*      */     public void setConcurrency(Integer concurrency) {
/*  910 */       this.concurrency = concurrency;
/*      */     }
/*      */     
/*      */     public Duration getPollTimeout() {
/*  914 */       return this.pollTimeout;
/*      */     }
/*      */     
/*      */     public void setPollTimeout(Duration pollTimeout) {
/*  918 */       this.pollTimeout = pollTimeout;
/*      */     }
/*      */     
/*      */     public Float getNoPollThreshold() {
/*  922 */       return this.noPollThreshold;
/*      */     }
/*      */     
/*      */     public void setNoPollThreshold(Float noPollThreshold) {
/*  926 */       this.noPollThreshold = noPollThreshold;
/*      */     }
/*      */     
/*      */     public Integer getAckCount() {
/*  930 */       return this.ackCount;
/*      */     }
/*      */     
/*      */     public void setAckCount(Integer ackCount) {
/*  934 */       this.ackCount = ackCount;
/*      */     }
/*      */     
/*      */     public Duration getAckTime() {
/*  938 */       return this.ackTime;
/*      */     }
/*      */     
/*      */     public void setAckTime(Duration ackTime) {
/*  942 */       this.ackTime = ackTime;
/*      */     }
/*      */     
/*      */     public Duration getIdleEventInterval() {
/*  946 */       return this.idleEventInterval;
/*      */     }
/*      */     
/*      */     public void setIdleEventInterval(Duration idleEventInterval) {
/*  950 */       this.idleEventInterval = idleEventInterval;
/*      */     }
/*      */     
/*      */     public Duration getMonitorInterval() {
/*  954 */       return this.monitorInterval;
/*      */     }
/*      */     
/*      */     public void setMonitorInterval(Duration monitorInterval) {
/*  958 */       this.monitorInterval = monitorInterval;
/*      */     }
/*      */     
/*      */     public Boolean getLogContainerConfig() {
/*  962 */       return this.logContainerConfig;
/*      */     }
/*      */     
/*      */     public void setLogContainerConfig(Boolean logContainerConfig) {
/*  966 */       this.logContainerConfig = logContainerConfig;
/*      */     }
/*      */     
/*      */     public boolean isMissingTopicsFatal() {
/*  970 */       return this.missingTopicsFatal;
/*      */     }
/*      */     
/*      */     public void setMissingTopicsFatal(boolean missingTopicsFatal) {
/*  974 */       this.missingTopicsFatal = missingTopicsFatal;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Ssl
/*      */   {
/*      */     private String keyPassword;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Resource keyStoreLocation;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String keyStorePassword;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String keyStoreType;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Resource trustStoreLocation;
/*      */ 
/*      */ 
/*      */     
/*      */     private String trustStorePassword;
/*      */ 
/*      */ 
/*      */     
/*      */     private String trustStoreType;
/*      */ 
/*      */ 
/*      */     
/*      */     private String protocol;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getKeyPassword() {
/* 1022 */       return this.keyPassword;
/*      */     }
/*      */     
/*      */     public void setKeyPassword(String keyPassword) {
/* 1026 */       this.keyPassword = keyPassword;
/*      */     }
/*      */     
/*      */     public Resource getKeyStoreLocation() {
/* 1030 */       return this.keyStoreLocation;
/*      */     }
/*      */     
/*      */     public void setKeyStoreLocation(Resource keyStoreLocation) {
/* 1034 */       this.keyStoreLocation = keyStoreLocation;
/*      */     }
/*      */     
/*      */     public String getKeyStorePassword() {
/* 1038 */       return this.keyStorePassword;
/*      */     }
/*      */     
/*      */     public void setKeyStorePassword(String keyStorePassword) {
/* 1042 */       this.keyStorePassword = keyStorePassword;
/*      */     }
/*      */     
/*      */     public String getKeyStoreType() {
/* 1046 */       return this.keyStoreType;
/*      */     }
/*      */     
/*      */     public void setKeyStoreType(String keyStoreType) {
/* 1050 */       this.keyStoreType = keyStoreType;
/*      */     }
/*      */     
/*      */     public Resource getTrustStoreLocation() {
/* 1054 */       return this.trustStoreLocation;
/*      */     }
/*      */     
/*      */     public void setTrustStoreLocation(Resource trustStoreLocation) {
/* 1058 */       this.trustStoreLocation = trustStoreLocation;
/*      */     }
/*      */     
/*      */     public String getTrustStorePassword() {
/* 1062 */       return this.trustStorePassword;
/*      */     }
/*      */     
/*      */     public void setTrustStorePassword(String trustStorePassword) {
/* 1066 */       this.trustStorePassword = trustStorePassword;
/*      */     }
/*      */     
/*      */     public String getTrustStoreType() {
/* 1070 */       return this.trustStoreType;
/*      */     }
/*      */     
/*      */     public void setTrustStoreType(String trustStoreType) {
/* 1074 */       this.trustStoreType = trustStoreType;
/*      */     }
/*      */     
/*      */     public String getProtocol() {
/* 1078 */       return this.protocol;
/*      */     }
/*      */     
/*      */     public void setProtocol(String protocol) {
/* 1082 */       this.protocol = protocol;
/*      */     }
/*      */     
/*      */     public Map<String, Object> buildProperties() {
/* 1086 */       KafkaProperties.Properties properties = new KafkaProperties.Properties();
/* 1087 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 1088 */       map.from(this::getKeyPassword).to(properties.in("ssl.key.password"));
/* 1089 */       map.from(this::getKeyStoreLocation).as(this::resourceToPath)
/* 1090 */         .to(properties.in("ssl.keystore.location"));
/* 1091 */       map.from(this::getKeyStorePassword).to(properties.in("ssl.keystore.password"));
/* 1092 */       map.from(this::getKeyStoreType).to(properties.in("ssl.keystore.type"));
/* 1093 */       map.from(this::getTrustStoreLocation).as(this::resourceToPath)
/* 1094 */         .to(properties.in("ssl.truststore.location"));
/* 1095 */       map.from(this::getTrustStorePassword).to(properties.in("ssl.truststore.password"));
/* 1096 */       map.from(this::getTrustStoreType).to(properties.in("ssl.truststore.type"));
/* 1097 */       map.from(this::getProtocol).to(properties.in("ssl.protocol"));
/* 1098 */       return properties;
/*      */     }
/*      */     
/*      */     private String resourceToPath(Resource resource) {
/*      */       try {
/* 1103 */         return resource.getFile().getAbsolutePath();
/*      */       }
/* 1105 */       catch (IOException ex) {
/* 1106 */         throw new IllegalStateException("Resource '" + resource + "' must be on a file system", ex);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Jaas
/*      */   {
/*      */     private boolean enabled;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1122 */     private String loginModule = "com.sun.security.auth.module.Krb5LoginModule";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1127 */     private KafkaJaasLoginModuleInitializer.ControlFlag controlFlag = KafkaJaasLoginModuleInitializer.ControlFlag.REQUIRED;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1132 */     private final Map<String, String> options = new HashMap<>();
/*      */     
/*      */     public boolean isEnabled() {
/* 1135 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public void setEnabled(boolean enabled) {
/* 1139 */       this.enabled = enabled;
/*      */     }
/*      */     
/*      */     public String getLoginModule() {
/* 1143 */       return this.loginModule;
/*      */     }
/*      */     
/*      */     public void setLoginModule(String loginModule) {
/* 1147 */       this.loginModule = loginModule;
/*      */     }
/*      */     
/*      */     public KafkaJaasLoginModuleInitializer.ControlFlag getControlFlag() {
/* 1151 */       return this.controlFlag;
/*      */     }
/*      */     
/*      */     public void setControlFlag(KafkaJaasLoginModuleInitializer.ControlFlag controlFlag) {
/* 1155 */       this.controlFlag = controlFlag;
/*      */     }
/*      */     
/*      */     public Map<String, String> getOptions() {
/* 1159 */       return this.options;
/*      */     }
/*      */     
/*      */     public void setOptions(Map<String, String> options) {
/* 1163 */       if (options != null)
/* 1164 */         this.options.putAll(options); 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class Properties
/*      */     extends HashMap<String, Object>
/*      */   {
/*      */     private Properties() {}
/*      */     
/*      */     <V> java.util.function.Consumer<V> in(String key) {
/* 1174 */       return value -> put(key, value);
/*      */     }
/*      */     
/*      */     Properties with(KafkaProperties.Ssl ssl, Map<String, String> properties) {
/* 1178 */       putAll(ssl.buildProperties());
/* 1179 */       putAll(properties);
/* 1180 */       return this;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\kafka\KafkaProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
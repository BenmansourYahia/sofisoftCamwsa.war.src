/*     */ package org.springframework.boot.autoconfigure.kafka;
/*     */ 
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.kafka.annotation.EnableKafka;
/*     */ import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
/*     */ import org.springframework.kafka.core.ConsumerFactory;
/*     */ import org.springframework.kafka.core.KafkaTemplate;
/*     */ import org.springframework.kafka.listener.AfterRollbackProcessor;
/*     */ import org.springframework.kafka.listener.BatchErrorHandler;
/*     */ import org.springframework.kafka.listener.ConsumerAwareRebalanceListener;
/*     */ import org.springframework.kafka.listener.ErrorHandler;
/*     */ import org.springframework.kafka.listener.RecordInterceptor;
/*     */ import org.springframework.kafka.support.converter.BatchMessageConverter;
/*     */ import org.springframework.kafka.support.converter.BatchMessagingMessageConverter;
/*     */ import org.springframework.kafka.support.converter.MessageConverter;
/*     */ import org.springframework.kafka.support.converter.RecordMessageConverter;
/*     */ import org.springframework.kafka.transaction.KafkaAwareTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({EnableKafka.class})
/*     */ class KafkaAnnotationDrivenConfiguration
/*     */ {
/*     */   private final KafkaProperties properties;
/*     */   private final RecordMessageConverter messageConverter;
/*     */   private final BatchMessageConverter batchMessageConverter;
/*     */   private final KafkaTemplate<Object, Object> kafkaTemplate;
/*     */   private final KafkaAwareTransactionManager<Object, Object> transactionManager;
/*     */   private final ConsumerAwareRebalanceListener rebalanceListener;
/*     */   private final ErrorHandler errorHandler;
/*     */   private final BatchErrorHandler batchErrorHandler;
/*     */   private final AfterRollbackProcessor<Object, Object> afterRollbackProcessor;
/*     */   private final RecordInterceptor<Object, Object> recordInterceptor;
/*     */   
/*     */   KafkaAnnotationDrivenConfiguration(KafkaProperties properties, ObjectProvider<RecordMessageConverter> messageConverter, ObjectProvider<BatchMessageConverter> batchMessageConverter, ObjectProvider<KafkaTemplate<Object, Object>> kafkaTemplate, ObjectProvider<KafkaAwareTransactionManager<Object, Object>> kafkaTransactionManager, ObjectProvider<ConsumerAwareRebalanceListener> rebalanceListener, ObjectProvider<ErrorHandler> errorHandler, ObjectProvider<BatchErrorHandler> batchErrorHandler, ObjectProvider<AfterRollbackProcessor<Object, Object>> afterRollbackProcessor, ObjectProvider<RecordInterceptor<Object, Object>> recordInterceptor) {
/*  80 */     this.properties = properties;
/*  81 */     this.messageConverter = (RecordMessageConverter)messageConverter.getIfUnique();
/*  82 */     this
/*  83 */       .batchMessageConverter = (BatchMessageConverter)batchMessageConverter.getIfUnique(() -> new BatchMessagingMessageConverter(this.messageConverter));
/*  84 */     this.kafkaTemplate = (KafkaTemplate<Object, Object>)kafkaTemplate.getIfUnique();
/*  85 */     this.transactionManager = (KafkaAwareTransactionManager<Object, Object>)kafkaTransactionManager.getIfUnique();
/*  86 */     this.rebalanceListener = (ConsumerAwareRebalanceListener)rebalanceListener.getIfUnique();
/*  87 */     this.errorHandler = (ErrorHandler)errorHandler.getIfUnique();
/*  88 */     this.batchErrorHandler = (BatchErrorHandler)batchErrorHandler.getIfUnique();
/*  89 */     this.afterRollbackProcessor = (AfterRollbackProcessor<Object, Object>)afterRollbackProcessor.getIfUnique();
/*  90 */     this.recordInterceptor = (RecordInterceptor<Object, Object>)recordInterceptor.getIfUnique();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   ConcurrentKafkaListenerContainerFactoryConfigurer kafkaListenerContainerFactoryConfigurer() {
/*  96 */     ConcurrentKafkaListenerContainerFactoryConfigurer configurer = new ConcurrentKafkaListenerContainerFactoryConfigurer();
/*  97 */     configurer.setKafkaProperties(this.properties);
/*  98 */     MessageConverter messageConverterToUse = this.properties.getListener().getType().equals(KafkaProperties.Listener.Type.BATCH) ? (MessageConverter)this.batchMessageConverter : (MessageConverter)this.messageConverter;
/*     */     
/* 100 */     configurer.setMessageConverter(messageConverterToUse);
/* 101 */     configurer.setReplyTemplate(this.kafkaTemplate);
/* 102 */     configurer.setTransactionManager(this.transactionManager);
/* 103 */     configurer.setRebalanceListener(this.rebalanceListener);
/* 104 */     configurer.setErrorHandler(this.errorHandler);
/* 105 */     configurer.setBatchErrorHandler(this.batchErrorHandler);
/* 106 */     configurer.setAfterRollbackProcessor(this.afterRollbackProcessor);
/* 107 */     configurer.setRecordInterceptor(this.recordInterceptor);
/* 108 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(name = {"kafkaListenerContainerFactory"})
/*     */   ConcurrentKafkaListenerContainerFactory<?, ?> kafkaListenerContainerFactory(ConcurrentKafkaListenerContainerFactoryConfigurer configurer, ConsumerFactory<Object, Object> kafkaConsumerFactory) {
/* 116 */     ConcurrentKafkaListenerContainerFactory<Object, Object> factory = new ConcurrentKafkaListenerContainerFactory();
/* 117 */     configurer.configure(factory, kafkaConsumerFactory);
/* 118 */     return factory;
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @EnableKafka
/*     */   @ConditionalOnMissingBean(name = {"org.springframework.kafka.config.internalKafkaListenerAnnotationProcessor"})
/*     */   static class EnableKafkaConfiguration {}
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\kafka\KafkaAnnotationDrivenConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
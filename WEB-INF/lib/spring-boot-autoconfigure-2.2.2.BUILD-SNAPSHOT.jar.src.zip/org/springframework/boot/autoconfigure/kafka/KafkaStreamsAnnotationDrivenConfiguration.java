/*    */ package org.springframework.boot.autoconfigure.kafka;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.kafka.streams.StreamsBuilder;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.beans.factory.annotation.Qualifier;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.kafka.config.KafkaStreamsConfiguration;
/*    */ import org.springframework.kafka.config.StreamsBuilderFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({StreamsBuilder.class})
/*    */ @ConditionalOnBean(name = {"defaultKafkaStreamsBuilder"})
/*    */ class KafkaStreamsAnnotationDrivenConfiguration
/*    */ {
/*    */   private final KafkaProperties properties;
/*    */   
/*    */   KafkaStreamsAnnotationDrivenConfiguration(KafkaProperties properties) {
/* 51 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @ConditionalOnMissingBean
/*    */   @Bean({"defaultKafkaStreamsConfig"})
/*    */   KafkaStreamsConfiguration defaultKafkaStreamsConfig(Environment environment) {
/* 57 */     Map<String, Object> streamsProperties = this.properties.buildStreamsProperties();
/* 58 */     if (this.properties.getStreams().getApplicationId() == null) {
/* 59 */       String applicationName = environment.getProperty("spring.application.name");
/* 60 */       if (applicationName == null) {
/* 61 */         throw new InvalidConfigurationPropertyValueException("spring.kafka.streams.application-id", null, "This property is mandatory and fallback 'spring.application.name' is not set either.");
/*    */       }
/*    */       
/* 64 */       streamsProperties.put("application.id", applicationName);
/*    */     } 
/* 66 */     return new KafkaStreamsConfiguration(streamsProperties);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   KafkaStreamsFactoryBeanConfigurer kafkaStreamsFactoryBeanConfigurer(@Qualifier("defaultKafkaStreamsBuilder") StreamsBuilderFactoryBean factoryBean) {
/* 72 */     return new KafkaStreamsFactoryBeanConfigurer(this.properties, factoryBean);
/*    */   }
/*    */ 
/*    */   
/*    */   static class KafkaStreamsFactoryBeanConfigurer
/*    */     implements InitializingBean
/*    */   {
/*    */     private final KafkaProperties properties;
/*    */     private final StreamsBuilderFactoryBean factoryBean;
/*    */     
/*    */     KafkaStreamsFactoryBeanConfigurer(KafkaProperties properties, StreamsBuilderFactoryBean factoryBean) {
/* 83 */       this.properties = properties;
/* 84 */       this.factoryBean = factoryBean;
/*    */     }
/*    */ 
/*    */     
/*    */     public void afterPropertiesSet() {
/* 89 */       this.factoryBean.setAutoStartup(this.properties.getStreams().isAutoStartup());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\kafka\KafkaStreamsAnnotationDrivenConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.kafka;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
/*     */ import org.springframework.kafka.core.ConsumerFactory;
/*     */ import org.springframework.kafka.core.KafkaTemplate;
/*     */ import org.springframework.kafka.listener.AfterRollbackProcessor;
/*     */ import org.springframework.kafka.listener.BatchErrorHandler;
/*     */ import org.springframework.kafka.listener.ConsumerAwareRebalanceListener;
/*     */ import org.springframework.kafka.listener.ContainerProperties;
/*     */ import org.springframework.kafka.listener.ErrorHandler;
/*     */ import org.springframework.kafka.listener.RecordInterceptor;
/*     */ import org.springframework.kafka.support.converter.MessageConverter;
/*     */ import org.springframework.kafka.transaction.KafkaAwareTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentKafkaListenerContainerFactoryConfigurer
/*     */ {
/*     */   private KafkaProperties properties;
/*     */   private MessageConverter messageConverter;
/*     */   private KafkaTemplate<Object, Object> replyTemplate;
/*     */   private KafkaAwareTransactionManager<Object, Object> transactionManager;
/*     */   private ConsumerAwareRebalanceListener rebalanceListener;
/*     */   private ErrorHandler errorHandler;
/*     */   private BatchErrorHandler batchErrorHandler;
/*     */   private AfterRollbackProcessor<Object, Object> afterRollbackProcessor;
/*     */   private RecordInterceptor<Object, Object> recordInterceptor;
/*     */   
/*     */   void setKafkaProperties(KafkaProperties properties) {
/*  67 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessageConverter(MessageConverter messageConverter) {
/*  75 */     this.messageConverter = messageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setReplyTemplate(KafkaTemplate<Object, Object> replyTemplate) {
/*  83 */     this.replyTemplate = replyTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTransactionManager(KafkaAwareTransactionManager<Object, Object> transactionManager) {
/*  91 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRebalanceListener(ConsumerAwareRebalanceListener rebalanceListener) {
/* 100 */     this.rebalanceListener = rebalanceListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setErrorHandler(ErrorHandler errorHandler) {
/* 108 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setBatchErrorHandler(BatchErrorHandler batchErrorHandler) {
/* 116 */     this.batchErrorHandler = batchErrorHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAfterRollbackProcessor(AfterRollbackProcessor<Object, Object> afterRollbackProcessor) {
/* 124 */     this.afterRollbackProcessor = afterRollbackProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRecordInterceptor(RecordInterceptor<Object, Object> recordInterceptor) {
/* 132 */     this.recordInterceptor = recordInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(ConcurrentKafkaListenerContainerFactory<Object, Object> listenerFactory, ConsumerFactory<Object, Object> consumerFactory) {
/* 144 */     listenerFactory.setConsumerFactory(consumerFactory);
/* 145 */     configureListenerFactory(listenerFactory);
/* 146 */     configureContainer(listenerFactory.getContainerProperties());
/*     */   }
/*     */   
/*     */   private void configureListenerFactory(ConcurrentKafkaListenerContainerFactory<Object, Object> factory) {
/* 150 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 151 */     KafkaProperties.Listener properties = this.properties.getListener();
/* 152 */     map.from(properties::getConcurrency).to(factory::setConcurrency);
/* 153 */     map.from(this.messageConverter).to(factory::setMessageConverter);
/* 154 */     map.from(this.replyTemplate).to(factory::setReplyTemplate);
/* 155 */     if (properties.getType().equals(KafkaProperties.Listener.Type.BATCH)) {
/* 156 */       factory.setBatchListener(Boolean.valueOf(true));
/* 157 */       factory.setBatchErrorHandler(this.batchErrorHandler);
/*     */     } else {
/*     */       
/* 160 */       factory.setErrorHandler(this.errorHandler);
/*     */     } 
/* 162 */     map.from(this.afterRollbackProcessor).to(factory::setAfterRollbackProcessor);
/* 163 */     map.from(this.recordInterceptor).to(factory::setRecordInterceptor);
/*     */   }
/*     */   
/*     */   private void configureContainer(ContainerProperties container) {
/* 167 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 168 */     KafkaProperties.Listener properties = this.properties.getListener();
/* 169 */     map.from(properties::getAckMode).to(container::setAckMode);
/* 170 */     map.from(properties::getClientId).to(container::setClientId);
/* 171 */     map.from(properties::getAckCount).to(container::setAckCount);
/* 172 */     map.from(properties::getAckTime).as(Duration::toMillis).to(container::setAckTime);
/* 173 */     map.from(properties::getPollTimeout).as(Duration::toMillis).to(container::setPollTimeout);
/* 174 */     map.from(properties::getNoPollThreshold).to(container::setNoPollThreshold);
/* 175 */     map.from(properties::getIdleEventInterval).as(Duration::toMillis).to(container::setIdleEventInterval);
/* 176 */     map.from(properties::getMonitorInterval).as(Duration::getSeconds).as(Number::intValue)
/* 177 */       .to(container::setMonitorInterval);
/* 178 */     map.from(properties::getLogContainerConfig).to(container::setLogContainerConfig);
/* 179 */     map.from(properties::isMissingTopicsFatal).to(container::setMissingTopicsFatal);
/* 180 */     map.from(this.transactionManager).to(container::setTransactionManager);
/* 181 */     map.from(this.rebalanceListener).to(container::setConsumerRebalanceListener);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\kafka\ConcurrentKafkaListenerContainerFactoryConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ import org.springframework.session.SessionRepository;
/*    */ import org.springframework.session.jdbc.JdbcIndexedSessionRepository;
/*    */ import org.springframework.session.jdbc.config.annotation.web.http.JdbcHttpSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({JdbcTemplate.class, JdbcIndexedSessionRepository.class})
/*    */ @ConditionalOnMissingBean({SessionRepository.class})
/*    */ @ConditionalOnBean({DataSource.class})
/*    */ @Conditional({ServletSessionCondition.class})
/*    */ @EnableConfigurationProperties({JdbcSessionProperties.class})
/*    */ class JdbcSessionConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   JdbcSessionDataSourceInitializer jdbcSessionDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader, JdbcSessionProperties properties) {
/* 56 */     return new JdbcSessionDataSourceInitializer(dataSource, resourceLoader, properties);
/*    */   }
/*    */   
/*    */   @Configuration
/*    */   static class SpringBootJdbcHttpSessionConfiguration
/*    */     extends JdbcHttpSessionConfiguration {
/*    */     @Autowired
/*    */     void customize(SessionProperties sessionProperties, JdbcSessionProperties jdbcSessionProperties) {
/* 64 */       Duration timeout = sessionProperties.getTimeout();
/* 65 */       if (timeout != null) {
/* 66 */         setMaxInactiveIntervalInSeconds(Integer.valueOf((int)timeout.getSeconds()));
/*    */       }
/* 68 */       setTableName(jdbcSessionProperties.getTableName());
/* 69 */       setCleanupCron(jdbcSessionProperties.getCleanupCron());
/* 70 */       setFlushMode(jdbcSessionProperties.getFlushMode());
/* 71 */       setSaveMode(jdbcSessionProperties.getSaveMode());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\JdbcSessionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
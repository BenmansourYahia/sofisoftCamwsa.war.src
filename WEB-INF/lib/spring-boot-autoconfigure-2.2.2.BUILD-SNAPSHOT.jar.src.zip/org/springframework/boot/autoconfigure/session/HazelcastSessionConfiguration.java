/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.time.Duration;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.session.SessionRepository;
/*    */ import org.springframework.session.hazelcast.HazelcastIndexedSessionRepository;
/*    */ import org.springframework.session.hazelcast.config.annotation.web.http.HazelcastHttpSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({HazelcastIndexedSessionRepository.class})
/*    */ @ConditionalOnMissingBean({SessionRepository.class})
/*    */ @ConditionalOnBean({HazelcastInstance.class})
/*    */ @Conditional({ServletSessionCondition.class})
/*    */ @EnableConfigurationProperties({HazelcastSessionProperties.class})
/*    */ class HazelcastSessionConfiguration
/*    */ {
/*    */   @Configuration
/*    */   public static class SpringBootHazelcastHttpSessionConfiguration
/*    */     extends HazelcastHttpSessionConfiguration
/*    */   {
/*    */     @Autowired
/*    */     public void customize(SessionProperties sessionProperties, HazelcastSessionProperties hazelcastSessionProperties) {
/* 56 */       Duration timeout = sessionProperties.getTimeout();
/* 57 */       if (timeout != null) {
/* 58 */         setMaxInactiveIntervalInSeconds((int)timeout.getSeconds());
/*    */       }
/* 60 */       setSessionMapName(hazelcastSessionProperties.getMapName());
/* 61 */       setFlushMode(hazelcastSessionProperties.getFlushMode());
/* 62 */       setSaveMode(hazelcastSessionProperties.getSaveMode());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\HazelcastSessionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ import java.util.stream.Collectors;
/*    */ import javax.servlet.DispatcherType;
/*    */ import javax.servlet.Filter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.web.servlet.DispatcherType;
/*    */ import org.springframework.boot.web.servlet.FilterRegistrationBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.session.web.http.SessionRepositoryFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnBean({SessionRepositoryFilter.class})
/*    */ @EnableConfigurationProperties({SessionProperties.class})
/*    */ class SessionRepositoryFilterConfiguration
/*    */ {
/*    */   @Bean
/*    */   FilterRegistrationBean<SessionRepositoryFilter<?>> sessionRepositoryFilterRegistration(SessionProperties sessionProperties, SessionRepositoryFilter<?> filter) {
/* 44 */     FilterRegistrationBean<SessionRepositoryFilter<?>> registration = new FilterRegistrationBean((Filter)filter, new org.springframework.boot.web.servlet.ServletRegistrationBean[0]);
/* 45 */     registration.setDispatcherTypes(getDispatcherTypes(sessionProperties));
/* 46 */     registration.setOrder(sessionProperties.getServlet().getFilterOrder());
/* 47 */     return registration;
/*    */   }
/*    */   
/*    */   private EnumSet<DispatcherType> getDispatcherTypes(SessionProperties sessionProperties) {
/* 51 */     SessionProperties.Servlet servletProperties = sessionProperties.getServlet();
/* 52 */     if (servletProperties.getFilterDispatcherTypes() == null) {
/* 53 */       return null;
/*    */     }
/* 55 */     return (EnumSet<DispatcherType>)servletProperties.getFilterDispatcherTypes().stream().map(type -> DispatcherType.valueOf(type.name()))
/* 56 */       .collect(Collectors.collectingAndThen(Collectors.toSet(), EnumSet::copyOf));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\SessionRepositoryFilterConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
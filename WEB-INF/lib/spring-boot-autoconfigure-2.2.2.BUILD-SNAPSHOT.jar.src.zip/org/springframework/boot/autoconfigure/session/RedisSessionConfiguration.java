/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*    */ import org.springframework.data.redis.core.RedisTemplate;
/*    */ import org.springframework.session.SessionRepository;
/*    */ import org.springframework.session.data.redis.RedisIndexedSessionRepository;
/*    */ import org.springframework.session.data.redis.config.ConfigureNotifyKeyspaceEventsAction;
/*    */ import org.springframework.session.data.redis.config.ConfigureRedisAction;
/*    */ import org.springframework.session.data.redis.config.annotation.web.http.RedisHttpSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({RedisTemplate.class, RedisIndexedSessionRepository.class})
/*    */ @ConditionalOnMissingBean({SessionRepository.class})
/*    */ @ConditionalOnBean({RedisConnectionFactory.class})
/*    */ @Conditional({ServletSessionCondition.class})
/*    */ @EnableConfigurationProperties({RedisSessionProperties.class})
/*    */ class RedisSessionConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   ConfigureRedisAction configureRedisAction(RedisSessionProperties redisSessionProperties) {
/* 57 */     switch (redisSessionProperties.getConfigureAction()) {
/*    */       case NOTIFY_KEYSPACE_EVENTS:
/* 59 */         return (ConfigureRedisAction)new ConfigureNotifyKeyspaceEventsAction();
/*    */       case NONE:
/* 61 */         return ConfigureRedisAction.NO_OP;
/*    */     } 
/* 63 */     throw new IllegalStateException("Unsupported redis configure action '" + redisSessionProperties
/* 64 */         .getConfigureAction() + "'.");
/*    */   }
/*    */   
/*    */   @Configuration
/*    */   public static class SpringBootRedisHttpSessionConfiguration
/*    */     extends RedisHttpSessionConfiguration {
/*    */     @Autowired
/*    */     public void customize(SessionProperties sessionProperties, RedisSessionProperties redisSessionProperties) {
/* 72 */       Duration timeout = sessionProperties.getTimeout();
/* 73 */       if (timeout != null) {
/* 74 */         setMaxInactiveIntervalInSeconds((int)timeout.getSeconds());
/*    */       }
/* 76 */       setRedisNamespace(redisSessionProperties.getNamespace());
/* 77 */       setFlushMode(redisSessionProperties.getFlushMode());
/* 78 */       setSaveMode(redisSessionProperties.getSaveMode());
/* 79 */       setCleanupCron(redisSessionProperties.getCleanupCron());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\RedisSessionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
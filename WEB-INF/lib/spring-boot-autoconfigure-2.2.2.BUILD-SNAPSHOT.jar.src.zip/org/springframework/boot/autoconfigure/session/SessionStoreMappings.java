/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.EnumMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.WebApplicationType;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SessionStoreMappings
/*    */ {
/*    */   private static final Map<StoreType, Configurations> MAPPINGS;
/*    */   
/*    */   static {
/* 38 */     Map<StoreType, Configurations> mappings = new EnumMap<>(StoreType.class);
/* 39 */     mappings.put(StoreType.REDIS, new Configurations(RedisSessionConfiguration.class, RedisReactiveSessionConfiguration.class));
/*    */     
/* 41 */     mappings.put(StoreType.MONGODB, new Configurations(MongoSessionConfiguration.class, MongoReactiveSessionConfiguration.class));
/*    */     
/* 43 */     mappings.put(StoreType.JDBC, new Configurations(JdbcSessionConfiguration.class, null));
/* 44 */     mappings.put(StoreType.HAZELCAST, new Configurations(HazelcastSessionConfiguration.class, null));
/* 45 */     mappings.put(StoreType.NONE, new Configurations(NoOpSessionConfiguration.class, NoOpReactiveSessionConfiguration.class));
/*    */     
/* 47 */     MAPPINGS = Collections.unmodifiableMap(mappings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String getConfigurationClass(WebApplicationType webApplicationType, StoreType sessionStoreType) {
/* 54 */     Configurations configurations = MAPPINGS.get(sessionStoreType);
/* 55 */     Assert.state((configurations != null), () -> "Unknown session store type " + sessionStoreType);
/* 56 */     return configurations.getConfiguration(webApplicationType);
/*    */   }
/*    */   
/*    */   static StoreType getType(WebApplicationType webApplicationType, String configurationClass) {
/* 60 */     return (StoreType)MAPPINGS.entrySet().stream()
/* 61 */       .filter(entry -> ObjectUtils.nullSafeEquals(configurationClass, ((Configurations)entry.getValue()).getConfiguration(webApplicationType)))
/*    */       
/* 63 */       .map(Map.Entry::getKey).findFirst()
/* 64 */       .orElseThrow(() -> new IllegalStateException("Unknown configuration class " + configurationClass));
/*    */   }
/*    */ 
/*    */   
/*    */   private static class Configurations
/*    */   {
/*    */     private final Class<?> servletConfiguration;
/*    */     private final Class<?> reactiveConfiguration;
/*    */     
/*    */     Configurations(Class<?> servletConfiguration, Class<?> reactiveConfiguration) {
/* 74 */       this.servletConfiguration = servletConfiguration;
/* 75 */       this.reactiveConfiguration = reactiveConfiguration;
/*    */     }
/*    */     
/*    */     String getConfiguration(WebApplicationType webApplicationType) {
/* 79 */       switch (webApplicationType) {
/*    */         case SERVLET:
/* 81 */           return getName(this.servletConfiguration);
/*    */         case REACTIVE:
/* 83 */           return getName(this.reactiveConfiguration);
/*    */       } 
/* 85 */       return null;
/*    */     }
/*    */     
/*    */     String getName(Class<?> configuration) {
/* 89 */       return (configuration != null) ? configuration.getName() : null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\SessionStoreMappings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
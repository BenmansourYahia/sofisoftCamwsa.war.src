/*     */ package org.springframework.boot.autoconfigure.session;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*     */ import org.springframework.session.FlushMode;
/*     */ import org.springframework.session.SaveMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.session.jdbc")
/*     */ public class JdbcSessionProperties
/*     */ {
/*     */   private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/session/jdbc/schema-@@platform@@.sql";
/*     */   private static final String DEFAULT_TABLE_NAME = "SPRING_SESSION";
/*     */   private static final String DEFAULT_CLEANUP_CRON = "0 * * * * *";
/*  43 */   private String schema = "classpath:org/springframework/session/jdbc/schema-@@platform@@.sql";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private String tableName = "SPRING_SESSION";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private String cleanupCron = "0 * * * * *";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private DataSourceInitializationMode initializeSchema = DataSourceInitializationMode.EMBEDDED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private FlushMode flushMode = FlushMode.ON_SAVE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private SaveMode saveMode = SaveMode.ON_SET_ATTRIBUTE;
/*     */   
/*     */   public String getSchema() {
/*  73 */     return this.schema;
/*     */   }
/*     */   
/*     */   public void setSchema(String schema) {
/*  77 */     this.schema = schema;
/*     */   }
/*     */   
/*     */   public String getTableName() {
/*  81 */     return this.tableName;
/*     */   }
/*     */   
/*     */   public void setTableName(String tableName) {
/*  85 */     this.tableName = tableName;
/*     */   }
/*     */   
/*     */   public String getCleanupCron() {
/*  89 */     return this.cleanupCron;
/*     */   }
/*     */   
/*     */   public void setCleanupCron(String cleanupCron) {
/*  93 */     this.cleanupCron = cleanupCron;
/*     */   }
/*     */   
/*     */   public DataSourceInitializationMode getInitializeSchema() {
/*  97 */     return this.initializeSchema;
/*     */   }
/*     */   
/*     */   public void setInitializeSchema(DataSourceInitializationMode initializeSchema) {
/* 101 */     this.initializeSchema = initializeSchema;
/*     */   }
/*     */   
/*     */   public FlushMode getFlushMode() {
/* 105 */     return this.flushMode;
/*     */   }
/*     */   
/*     */   public void setFlushMode(FlushMode flushMode) {
/* 109 */     this.flushMode = flushMode;
/*     */   }
/*     */   
/*     */   public SaveMode getSaveMode() {
/* 113 */     return this.saveMode;
/*     */   }
/*     */   
/*     */   public void setSaveMode(SaveMode saveMode) {
/* 117 */     this.saveMode = saveMode;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\JdbcSessionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
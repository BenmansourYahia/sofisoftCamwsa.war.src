/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.jdbc.AbstractDataSourceInitializer;
/*    */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcSessionDataSourceInitializer
/*    */   extends AbstractDataSourceInitializer
/*    */ {
/*    */   private final JdbcSessionProperties properties;
/*    */   
/*    */   public JdbcSessionDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader, JdbcSessionProperties properties) {
/* 38 */     super(dataSource, resourceLoader);
/* 39 */     Assert.notNull(properties, "JdbcSessionProperties must not be null");
/* 40 */     this.properties = properties;
/*    */   }
/*    */ 
/*    */   
/*    */   protected DataSourceInitializationMode getMode() {
/* 45 */     return this.properties.getInitializeSchema();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getSchemaLocation() {
/* 50 */     return this.properties.getSchema();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\JdbcSessionDataSourceInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
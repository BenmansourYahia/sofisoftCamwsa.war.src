/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.mongodb.core.MongoOperations;
/*    */ import org.springframework.session.SessionRepository;
/*    */ import org.springframework.session.data.mongo.MongoIndexedSessionRepository;
/*    */ import org.springframework.session.data.mongo.config.annotation.web.http.MongoHttpSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({MongoOperations.class, MongoIndexedSessionRepository.class})
/*    */ @ConditionalOnMissingBean({SessionRepository.class})
/*    */ @ConditionalOnBean({MongoOperations.class})
/*    */ @Conditional({ServletSessionCondition.class})
/*    */ @EnableConfigurationProperties({MongoSessionProperties.class})
/*    */ class MongoSessionConfiguration
/*    */ {
/*    */   @Configuration
/*    */   public static class SpringBootMongoHttpSessionConfiguration
/*    */     extends MongoHttpSessionConfiguration
/*    */   {
/*    */     @Autowired
/*    */     public void customize(SessionProperties sessionProperties, MongoSessionProperties mongoSessionProperties) {
/* 52 */       Duration timeout = sessionProperties.getTimeout();
/* 53 */       if (timeout != null) {
/* 54 */         setMaxInactiveIntervalInSeconds(Integer.valueOf((int)timeout.getSeconds()));
/*    */       }
/* 56 */       setCollectionName(mongoSessionProperties.getCollectionName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\MongoSessionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
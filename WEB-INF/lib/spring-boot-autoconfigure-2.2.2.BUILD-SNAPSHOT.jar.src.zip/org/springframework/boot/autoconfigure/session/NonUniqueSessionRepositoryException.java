/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonUniqueSessionRepositoryException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final List<Class<?>> availableCandidates;
/*    */   
/*    */   public NonUniqueSessionRepositoryException(List<Class<?>> availableCandidates) {
/* 37 */     super("Multiple session repository candidates are available, set the 'spring.session.store-type' property accordingly");
/*    */     
/* 39 */     this
/* 40 */       .availableCandidates = !ObjectUtils.isEmpty(availableCandidates) ? availableCandidates : Collections.<Class<?>>emptyList();
/*    */   }
/*    */   
/*    */   public List<Class<?>> getAvailableCandidates() {
/* 44 */     return this.availableCandidates;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\NonUniqueSessionRepositoryException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.session;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.annotation.PostConstruct;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.WebApplicationType;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.data.mongo.MongoReactiveDataAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.data.redis.RedisReactiveAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.hazelcast.HazelcastAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.autoconfigure.web.reactive.HttpHandlerAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.web.servlet.server.Session;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportSelector;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.session.ReactiveSessionRepository;
/*     */ import org.springframework.session.Session;
/*     */ import org.springframework.session.SessionRepository;
/*     */ import org.springframework.session.security.web.authentication.SpringSessionRememberMeServices;
/*     */ import org.springframework.session.web.http.CookieHttpSessionIdResolver;
/*     */ import org.springframework.session.web.http.CookieSerializer;
/*     */ import org.springframework.session.web.http.DefaultCookieSerializer;
/*     */ import org.springframework.session.web.http.HttpSessionIdResolver;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({Session.class})
/*     */ @ConditionalOnWebApplication
/*     */ @EnableConfigurationProperties({ServerProperties.class, SessionProperties.class})
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, HazelcastAutoConfiguration.class, JdbcTemplateAutoConfiguration.class, MongoDataAutoConfiguration.class, MongoReactiveDataAutoConfiguration.class, RedisAutoConfiguration.class, RedisReactiveAutoConfiguration.class})
/*     */ @AutoConfigureBefore({HttpHandlerAutoConfiguration.class})
/*     */ public class SessionAutoConfiguration
/*     */ {
/*     */   private static final String REMEMBER_ME_SERVICES_CLASS = "org.springframework.security.web.authentication.RememberMeServices";
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */   @Import({ServletSessionRepositoryValidator.class, SessionRepositoryFilterConfiguration.class})
/*     */   static class ServletSessionConfiguration
/*     */   {
/*     */     @Bean
/*     */     @Conditional({SessionAutoConfiguration.DefaultCookieSerializerCondition.class})
/*     */     DefaultCookieSerializer cookieSerializer(ServerProperties serverProperties) {
/*  96 */       Session.Cookie cookie = serverProperties.getServlet().getSession().getCookie();
/*  97 */       DefaultCookieSerializer cookieSerializer = new DefaultCookieSerializer();
/*  98 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  99 */       map.from(cookie::getName).to(cookieSerializer::setCookieName);
/* 100 */       map.from(cookie::getDomain).to(cookieSerializer::setDomainName);
/* 101 */       map.from(cookie::getPath).to(cookieSerializer::setCookiePath);
/* 102 */       map.from(cookie::getHttpOnly).to(cookieSerializer::setUseHttpOnlyCookie);
/* 103 */       map.from(cookie::getSecure).to(cookieSerializer::setUseSecureCookie);
/* 104 */       map.from(cookie::getMaxAge).to(maxAge -> cookieSerializer.setCookieMaxAge((int)maxAge.getSeconds()));
/* 105 */       if (ClassUtils.isPresent("org.springframework.security.web.authentication.RememberMeServices", getClass().getClassLoader())) {
/* 106 */         (new SessionAutoConfiguration.RememberMeServicesCookieSerializerCustomizer()).apply(cookieSerializer);
/*     */       }
/* 108 */       return cookieSerializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     @ConditionalOnMissingBean({SessionRepository.class})
/*     */     @Import({SessionAutoConfiguration.ServletSessionRepositoryImplementationValidator.class, SessionAutoConfiguration.ServletSessionConfigurationImportSelector.class})
/*     */     static class ServletSessionRepositoryConfiguration {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*     */   @Import({ReactiveSessionRepositoryValidator.class})
/*     */   static class ReactiveSessionConfiguration
/*     */   {
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     @ConditionalOnMissingBean({ReactiveSessionRepository.class})
/*     */     @Import({SessionAutoConfiguration.ReactiveSessionRepositoryImplementationValidator.class, SessionAutoConfiguration.ReactiveSessionConfigurationImportSelector.class})
/*     */     static class ReactiveSessionRepositoryConfiguration {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class RememberMeServicesCookieSerializerCustomizer
/*     */   {
/*     */     void apply(DefaultCookieSerializer cookieSerializer) {
/* 143 */       cookieSerializer.setRememberMeRequestAttribute(SpringSessionRememberMeServices.REMEMBER_ME_LOGIN_ATTR);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultCookieSerializerCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     DefaultCookieSerializerCondition() {
/* 157 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @ConditionalOnMissingBean({HttpSessionIdResolver.class, CookieSerializer.class})
/*     */     static class NoComponentsAvailable {}
/*     */ 
/*     */ 
/*     */     
/*     */     @ConditionalOnBean({CookieHttpSessionIdResolver.class})
/*     */     @ConditionalOnMissingBean({CookieSerializer.class})
/*     */     static class CookieHttpSessionIdResolverAvailable {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class SessionConfigurationImportSelector
/*     */     implements ImportSelector
/*     */   {
/*     */     protected final String[] selectImports(WebApplicationType webApplicationType) {
/* 179 */       return (String[])Arrays.<StoreType>stream(StoreType.values())
/* 180 */         .map(type -> SessionStoreMappings.getConfigurationClass(webApplicationType, type))
/* 181 */         .toArray(x$0 -> new String[x$0]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ReactiveSessionConfigurationImportSelector
/*     */     extends SessionConfigurationImportSelector
/*     */   {
/*     */     public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 194 */       return selectImports(WebApplicationType.REACTIVE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ServletSessionConfigurationImportSelector
/*     */     extends SessionConfigurationImportSelector
/*     */   {
/*     */     public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 207 */       return selectImports(WebApplicationType.SERVLET);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class AbstractSessionRepositoryImplementationValidator
/*     */   {
/*     */     private final List<String> candidates;
/*     */ 
/*     */     
/*     */     private final ClassLoader classLoader;
/*     */ 
/*     */     
/*     */     private final SessionProperties sessionProperties;
/*     */ 
/*     */ 
/*     */     
/*     */     AbstractSessionRepositoryImplementationValidator(ApplicationContext applicationContext, SessionProperties sessionProperties, List<String> candidates) {
/* 226 */       this.classLoader = applicationContext.getClassLoader();
/* 227 */       this.sessionProperties = sessionProperties;
/* 228 */       this.candidates = candidates;
/*     */     }
/*     */     
/*     */     @PostConstruct
/*     */     void checkAvailableImplementations() {
/* 233 */       List<Class<?>> availableCandidates = new ArrayList<>();
/* 234 */       for (String candidate : this.candidates) {
/* 235 */         addCandidateIfAvailable(availableCandidates, candidate);
/*     */       }
/* 237 */       StoreType storeType = this.sessionProperties.getStoreType();
/* 238 */       if (availableCandidates.size() > 1 && storeType == null) {
/* 239 */         throw new NonUniqueSessionRepositoryException(availableCandidates);
/*     */       }
/*     */     }
/*     */     
/*     */     private void addCandidateIfAvailable(List<Class<?>> candidates, String type) {
/*     */       try {
/* 245 */         Class<?> candidate = this.classLoader.loadClass(type);
/* 246 */         if (candidate != null) {
/* 247 */           candidates.add(candidate);
/*     */         }
/*     */       }
/* 250 */       catch (Throwable throwable) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ServletSessionRepositoryImplementationValidator
/*     */     extends AbstractSessionRepositoryImplementationValidator
/*     */   {
/*     */     ServletSessionRepositoryImplementationValidator(ApplicationContext applicationContext, SessionProperties sessionProperties) {
/* 266 */       super(applicationContext, sessionProperties, 
/* 267 */           Arrays.asList(new String[] { "org.springframework.session.hazelcast.HazelcastIndexedSessionRepository", "org.springframework.session.jdbc.JdbcIndexedSessionRepository", "org.springframework.session.data.mongo.MongoIndexedSessionRepository", "org.springframework.session.data.redis.RedisIndexedSessionRepository" }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ReactiveSessionRepositoryImplementationValidator
/*     */     extends AbstractSessionRepositoryImplementationValidator
/*     */   {
/*     */     ReactiveSessionRepositoryImplementationValidator(ApplicationContext applicationContext, SessionProperties sessionProperties) {
/* 284 */       super(applicationContext, sessionProperties, 
/* 285 */           Arrays.asList(new String[] { "org.springframework.session.data.redis.ReactiveRedisSessionRepository", "org.springframework.session.data.mongo.ReactiveMongoSessionRepository" }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class AbstractSessionRepositoryValidator
/*     */   {
/*     */     private final SessionProperties sessionProperties;
/*     */ 
/*     */     
/*     */     private final ObjectProvider<?> sessionRepositoryProvider;
/*     */ 
/*     */ 
/*     */     
/*     */     protected AbstractSessionRepositoryValidator(SessionProperties sessionProperties, ObjectProvider<?> sessionRepositoryProvider) {
/* 302 */       this.sessionProperties = sessionProperties;
/* 303 */       this.sessionRepositoryProvider = sessionRepositoryProvider;
/*     */     }
/*     */     
/*     */     @PostConstruct
/*     */     void checkSessionRepository() {
/* 308 */       StoreType storeType = this.sessionProperties.getStoreType();
/* 309 */       if (storeType != StoreType.NONE && this.sessionRepositoryProvider.getIfAvailable() == null && storeType != null)
/*     */       {
/* 311 */         throw new SessionRepositoryUnavailableException("No session repository could be auto-configured, check your configuration (session store type is '" + storeType
/*     */ 
/*     */             
/* 314 */             .name().toLowerCase(Locale.ENGLISH) + "')", storeType);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ServletSessionRepositoryValidator
/*     */     extends AbstractSessionRepositoryValidator
/*     */   {
/*     */     ServletSessionRepositoryValidator(SessionProperties sessionProperties, ObjectProvider<SessionRepository<?>> sessionRepositoryProvider) {
/* 329 */       super(sessionProperties, sessionRepositoryProvider);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ReactiveSessionRepositoryValidator
/*     */     extends AbstractSessionRepositoryValidator
/*     */   {
/*     */     ReactiveSessionRepositoryValidator(SessionProperties sessionProperties, ObjectProvider<ReactiveSessionRepository<?>> sessionRepositoryProvider) {
/* 342 */       super(sessionProperties, sessionRepositoryProvider);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\SessionAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
/*    */ import org.springframework.session.ReactiveSessionRepository;
/*    */ import org.springframework.session.data.redis.ReactiveRedisSessionRepository;
/*    */ import org.springframework.session.data.redis.config.annotation.web.server.RedisWebSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({ReactiveRedisConnectionFactory.class, ReactiveRedisSessionRepository.class})
/*    */ @ConditionalOnMissingBean({ReactiveSessionRepository.class})
/*    */ @ConditionalOnBean({ReactiveRedisConnectionFactory.class})
/*    */ @Conditional({ReactiveSessionCondition.class})
/*    */ @EnableConfigurationProperties({RedisSessionProperties.class})
/*    */ class RedisReactiveSessionConfiguration
/*    */ {
/*    */   @Configuration
/*    */   static class SpringBootRedisWebSessionConfiguration
/*    */     extends RedisWebSessionConfiguration
/*    */   {
/*    */     @Autowired
/*    */     void customize(SessionProperties sessionProperties, RedisSessionProperties redisSessionProperties) {
/* 51 */       Duration timeout = sessionProperties.getTimeout();
/* 52 */       if (timeout != null) {
/* 53 */         setMaxInactiveIntervalInSeconds((int)timeout.getSeconds());
/*    */       }
/* 55 */       setRedisNamespace(redisSessionProperties.getNamespace());
/* 56 */       setSaveMode(redisSessionProperties.getSaveMode());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\RedisReactiveSessionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
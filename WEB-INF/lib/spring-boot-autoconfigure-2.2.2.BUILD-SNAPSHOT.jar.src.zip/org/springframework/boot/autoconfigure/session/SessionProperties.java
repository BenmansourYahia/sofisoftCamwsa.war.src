/*     */ package org.springframework.boot.autoconfigure.session;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.annotation.PostConstruct;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ import org.springframework.boot.web.servlet.DispatcherType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.session")
/*     */ public class SessionProperties
/*     */ {
/*     */   private StoreType storeType;
/*     */   @DurationUnit(ChronoUnit.SECONDS)
/*     */   private Duration timeout;
/*  58 */   private Servlet servlet = new Servlet();
/*     */   
/*     */   private ServerProperties serverProperties;
/*     */   
/*     */   @Autowired
/*     */   void setServerProperties(ObjectProvider<ServerProperties> serverProperties) {
/*  64 */     this.serverProperties = (ServerProperties)serverProperties.getIfUnique();
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void checkSessionTimeout() {
/*  69 */     if (this.timeout == null && this.serverProperties != null) {
/*  70 */       this.timeout = this.serverProperties.getServlet().getSession().getTimeout();
/*     */     }
/*     */   }
/*     */   
/*     */   public StoreType getStoreType() {
/*  75 */     return this.storeType;
/*     */   }
/*     */   
/*     */   public void setStoreType(StoreType storeType) {
/*  79 */     this.storeType = storeType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration getTimeout() {
/*  88 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public void setTimeout(Duration timeout) {
/*  92 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public Servlet getServlet() {
/*  96 */     return this.servlet;
/*     */   }
/*     */   
/*     */   public void setServlet(Servlet servlet) {
/* 100 */     this.servlet = servlet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Servlet
/*     */   {
/* 111 */     private int filterOrder = -2147483598;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     private Set<DispatcherType> filterDispatcherTypes = new HashSet<>(
/* 117 */         Arrays.asList(new DispatcherType[] { DispatcherType.ASYNC, DispatcherType.ERROR, DispatcherType.REQUEST }));
/*     */     
/*     */     public int getFilterOrder() {
/* 120 */       return this.filterOrder;
/*     */     }
/*     */     
/*     */     public void setFilterOrder(int filterOrder) {
/* 124 */       this.filterOrder = filterOrder;
/*     */     }
/*     */     
/*     */     public Set<DispatcherType> getFilterDispatcherTypes() {
/* 128 */       return this.filterDispatcherTypes;
/*     */     }
/*     */     
/*     */     public void setFilterDispatcherTypes(Set<DispatcherType> filterDispatcherTypes) {
/* 132 */       this.filterDispatcherTypes = filterDispatcherTypes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\SessionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import org.springframework.boot.WebApplicationType;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.context.properties.bind.BindException;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractSessionCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private final WebApplicationType webApplicationType;
/*    */   
/*    */   protected AbstractSessionCondition(WebApplicationType webApplicationType) {
/* 43 */     this.webApplicationType = webApplicationType;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 48 */     ConditionMessage.Builder message = ConditionMessage.forCondition("Session Condition", new Object[0]);
/* 49 */     Environment environment = context.getEnvironment();
/* 50 */     StoreType required = SessionStoreMappings.getType(this.webApplicationType, ((AnnotationMetadata)metadata)
/* 51 */         .getClassName());
/* 52 */     if (!environment.containsProperty("spring.session.store-type")) {
/* 53 */       return ConditionOutcome.match(message.didNotFind("property", "properties")
/* 54 */           .items(ConditionMessage.Style.QUOTE, new Object[] { "spring.session.store-type" }));
/*    */     }
/*    */     try {
/* 57 */       Binder binder = Binder.get(environment);
/* 58 */       return (ConditionOutcome)binder.bind("spring.session.store-type", StoreType.class)
/* 59 */         .map(t -> new ConditionOutcome((t == required), message.found("spring.session.store-type property").items(new Object[] { t
/*    */               
/* 61 */               }))).orElse(ConditionOutcome.noMatch(message.didNotFind("spring.session.store-type property").atAll()));
/*    */     }
/* 63 */     catch (BindException ex) {
/* 64 */       return ConditionOutcome.noMatch(message.found("invalid spring.session.store-type property").atAll());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\AbstractSessionCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
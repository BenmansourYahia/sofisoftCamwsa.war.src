/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.session.FlushMode;
/*    */ import org.springframework.session.SaveMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.session.hazelcast")
/*    */ public class HazelcastSessionProperties
/*    */ {
/* 35 */   private String mapName = "spring:session:sessions";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   private FlushMode flushMode = FlushMode.ON_SAVE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   private SaveMode saveMode = SaveMode.ON_SET_ATTRIBUTE;
/*    */   
/*    */   public String getMapName() {
/* 50 */     return this.mapName;
/*    */   }
/*    */   
/*    */   public void setMapName(String mapName) {
/* 54 */     this.mapName = mapName;
/*    */   }
/*    */   
/*    */   public FlushMode getFlushMode() {
/* 58 */     return this.flushMode;
/*    */   }
/*    */   
/*    */   public void setFlushMode(FlushMode flushMode) {
/* 62 */     this.flushMode = flushMode;
/*    */   }
/*    */   
/*    */   public SaveMode getSaveMode() {
/* 66 */     return this.saveMode;
/*    */   }
/*    */   
/*    */   public void setSaveMode(SaveMode saveMode) {
/* 70 */     this.saveMode = saveMode;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\session\HazelcastSessionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
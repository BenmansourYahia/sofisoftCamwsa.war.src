/*     */ package org.springframework.boot.autoconfigure.mongo;
/*     */ 
/*     */ import com.mongodb.MongoClient;
/*     */ import com.mongodb.MongoClientOptions;
/*     */ import com.mongodb.MongoClientURI;
/*     */ import com.mongodb.MongoCredential;
/*     */ import com.mongodb.ServerAddress;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.core.env.Environment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MongoClientFactory
/*     */ {
/*     */   private final MongoProperties properties;
/*     */   private final Environment environment;
/*     */   
/*     */   public MongoClientFactory(MongoProperties properties, Environment environment) {
/*  51 */     this.properties = properties;
/*  52 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MongoClient createMongoClient(MongoClientOptions options) {
/*  63 */     Integer embeddedPort = getEmbeddedPort();
/*  64 */     if (embeddedPort != null) {
/*  65 */       return createEmbeddedMongoClient(options, embeddedPort.intValue());
/*     */     }
/*  67 */     return createNetworkMongoClient(options);
/*     */   }
/*     */   
/*     */   private Integer getEmbeddedPort() {
/*  71 */     if (this.environment != null) {
/*  72 */       String localPort = this.environment.getProperty("local.mongo.port");
/*  73 */       if (localPort != null) {
/*  74 */         return Integer.valueOf(localPort);
/*     */       }
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */   
/*     */   private MongoClient createEmbeddedMongoClient(MongoClientOptions options, int port) {
/*  81 */     if (options == null) {
/*  82 */       options = MongoClientOptions.builder().build();
/*     */     }
/*  84 */     String host = (this.properties.getHost() != null) ? this.properties.getHost() : "localhost";
/*  85 */     return new MongoClient(Collections.singletonList(new ServerAddress(host, port)), options);
/*     */   }
/*     */   
/*     */   private MongoClient createNetworkMongoClient(MongoClientOptions options) {
/*  89 */     MongoProperties properties = this.properties;
/*  90 */     if (properties.getUri() != null) {
/*  91 */       return createMongoClient(properties.getUri(), options);
/*     */     }
/*  93 */     if (hasCustomAddress() || hasCustomCredentials()) {
/*  94 */       if (options == null) {
/*  95 */         options = MongoClientOptions.builder().build();
/*     */       }
/*  97 */       MongoCredential credentials = getCredentials(properties);
/*  98 */       String host = getValue(properties.getHost(), "localhost");
/*  99 */       int port = ((Integer)getValue(properties.getPort(), Integer.valueOf(27017))).intValue();
/* 100 */       List<ServerAddress> seeds = Collections.singletonList(new ServerAddress(host, port));
/* 101 */       return (credentials != null) ? new MongoClient(seeds, credentials, options) : new MongoClient(seeds, options);
/*     */     } 
/*     */     
/* 104 */     return createMongoClient("mongodb://localhost/test", options);
/*     */   }
/*     */   
/*     */   private MongoClient createMongoClient(String uri, MongoClientOptions options) {
/* 108 */     return new MongoClient(new MongoClientURI(uri, builder(options)));
/*     */   }
/*     */   
/*     */   private <T> T getValue(T value, T fallback) {
/* 112 */     return (value != null) ? value : fallback;
/*     */   }
/*     */   
/*     */   private boolean hasCustomAddress() {
/* 116 */     return (this.properties.getHost() != null || this.properties.getPort() != null);
/*     */   }
/*     */   
/*     */   private MongoCredential getCredentials(MongoProperties properties) {
/* 120 */     if (!hasCustomCredentials()) {
/* 121 */       return null;
/*     */     }
/* 123 */     String username = properties.getUsername();
/* 124 */     String database = getValue(properties.getAuthenticationDatabase(), properties.getMongoClientDatabase());
/* 125 */     char[] password = properties.getPassword();
/* 126 */     return MongoCredential.createCredential(username, database, password);
/*     */   }
/*     */   
/*     */   private boolean hasCustomCredentials() {
/* 130 */     return (this.properties.getUsername() != null && this.properties.getPassword() != null);
/*     */   }
/*     */   
/*     */   private MongoClientOptions.Builder builder(MongoClientOptions options) {
/* 134 */     if (options != null) {
/* 135 */       return MongoClientOptions.builder(options);
/*     */     }
/* 137 */     return MongoClientOptions.builder();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mongo\MongoClientFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.mongo;
/*     */ 
/*     */ import com.mongodb.MongoClientURI;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.data.mongodb")
/*     */ public class MongoProperties
/*     */ {
/*     */   public static final int DEFAULT_PORT = 27017;
/*     */   public static final String DEFAULT_URI = "mongodb://localhost/test";
/*     */   private String host;
/*  58 */   private Integer port = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String uri;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String database;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String authenticationDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String gridFsDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String username;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] password;
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> fieldNamingStrategy;
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean autoIndexCreation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() {
/* 102 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/* 106 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getDatabase() {
/* 110 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(String database) {
/* 114 */     this.database = database;
/*     */   }
/*     */   
/*     */   public String getAuthenticationDatabase() {
/* 118 */     return this.authenticationDatabase;
/*     */   }
/*     */   
/*     */   public void setAuthenticationDatabase(String authenticationDatabase) {
/* 122 */     this.authenticationDatabase = authenticationDatabase;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 126 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 130 */     this.username = username;
/*     */   }
/*     */   
/*     */   public char[] getPassword() {
/* 134 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(char[] password) {
/* 138 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Class<?> getFieldNamingStrategy() {
/* 142 */     return this.fieldNamingStrategy;
/*     */   }
/*     */   
/*     */   public void setFieldNamingStrategy(Class<?> fieldNamingStrategy) {
/* 146 */     this.fieldNamingStrategy = fieldNamingStrategy;
/*     */   }
/*     */   
/*     */   public String getUri() {
/* 150 */     return this.uri;
/*     */   }
/*     */   
/*     */   public String determineUri() {
/* 154 */     return (this.uri != null) ? this.uri : "mongodb://localhost/test";
/*     */   }
/*     */   
/*     */   public void setUri(String uri) {
/* 158 */     this.uri = uri;
/*     */   }
/*     */   
/*     */   public Integer getPort() {
/* 162 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(Integer port) {
/* 166 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getGridFsDatabase() {
/* 170 */     return this.gridFsDatabase;
/*     */   }
/*     */   
/*     */   public void setGridFsDatabase(String gridFsDatabase) {
/* 174 */     this.gridFsDatabase = gridFsDatabase;
/*     */   }
/*     */   
/*     */   public String getMongoClientDatabase() {
/* 178 */     if (this.database != null) {
/* 179 */       return this.database;
/*     */     }
/* 181 */     return (new MongoClientURI(determineUri())).getDatabase();
/*     */   }
/*     */   
/*     */   public Boolean isAutoIndexCreation() {
/* 185 */     return this.autoIndexCreation;
/*     */   }
/*     */   
/*     */   public void setAutoIndexCreation(Boolean autoIndexCreation) {
/* 189 */     this.autoIndexCreation = autoIndexCreation;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mongo\MongoProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
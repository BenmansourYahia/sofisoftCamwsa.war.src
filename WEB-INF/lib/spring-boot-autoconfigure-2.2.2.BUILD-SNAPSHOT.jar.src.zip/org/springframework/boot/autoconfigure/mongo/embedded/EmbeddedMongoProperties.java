/*     */ package org.springframework.boot.autoconfigure.mongo.embedded;
/*     */ 
/*     */ import de.flapdoodle.embed.mongo.distribution.Feature;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.convert.DataSizeUnit;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ import org.springframework.util.unit.DataUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.mongodb.embedded")
/*     */ public class EmbeddedMongoProperties
/*     */ {
/*  41 */   private String version = "3.5.5";
/*     */   
/*  43 */   private final Storage storage = new Storage();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private Set<Feature> features = null;
/*     */   
/*     */   public String getVersion() {
/*  52 */     return this.version;
/*     */   }
/*     */   
/*     */   public void setVersion(String version) {
/*  56 */     this.version = version;
/*     */   }
/*     */   
/*     */   public Set<Feature> getFeatures() {
/*  60 */     return this.features;
/*     */   }
/*     */   
/*     */   public void setFeatures(Set<Feature> features) {
/*  64 */     this.features = features;
/*     */   }
/*     */   
/*     */   public Storage getStorage() {
/*  68 */     return this.storage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Storage
/*     */   {
/*     */     @DataSizeUnit(DataUnit.MEGABYTES)
/*     */     private DataSize oplogSize;
/*     */ 
/*     */ 
/*     */     
/*     */     private String replSetName;
/*     */ 
/*     */ 
/*     */     
/*     */     private String databaseDir;
/*     */ 
/*     */ 
/*     */     
/*     */     public DataSize getOplogSize() {
/*  90 */       return this.oplogSize;
/*     */     }
/*     */     
/*     */     public void setOplogSize(DataSize oplogSize) {
/*  94 */       this.oplogSize = oplogSize;
/*     */     }
/*     */     
/*     */     public String getReplSetName() {
/*  98 */       return this.replSetName;
/*     */     }
/*     */     
/*     */     public void setReplSetName(String replSetName) {
/* 102 */       this.replSetName = replSetName;
/*     */     }
/*     */     
/*     */     public String getDatabaseDir() {
/* 106 */       return this.databaseDir;
/*     */     }
/*     */     
/*     */     public void setDatabaseDir(String databaseDir) {
/* 110 */       this.databaseDir = databaseDir;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mongo\embedded\EmbeddedMongoProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
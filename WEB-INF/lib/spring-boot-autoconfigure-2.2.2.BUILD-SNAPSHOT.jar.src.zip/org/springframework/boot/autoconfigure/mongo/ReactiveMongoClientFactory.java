/*     */ package org.springframework.boot.autoconfigure.mongo;
/*     */ 
/*     */ import com.mongodb.ConnectionString;
/*     */ import com.mongodb.MongoClientSettings;
/*     */ import com.mongodb.MongoCredential;
/*     */ import com.mongodb.ServerAddress;
/*     */ import com.mongodb.connection.ClusterSettings;
/*     */ import com.mongodb.reactivestreams.client.MongoClient;
/*     */ import com.mongodb.reactivestreams.client.MongoClients;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactiveMongoClientFactory
/*     */ {
/*     */   private final MongoProperties properties;
/*     */   private final Environment environment;
/*     */   private final List<MongoClientSettingsBuilderCustomizer> builderCustomizers;
/*     */   
/*     */   public ReactiveMongoClientFactory(MongoProperties properties, Environment environment, List<MongoClientSettingsBuilderCustomizer> builderCustomizers) {
/*  50 */     this.properties = properties;
/*  51 */     this.environment = environment;
/*  52 */     this.builderCustomizers = (builderCustomizers != null) ? builderCustomizers : Collections.<MongoClientSettingsBuilderCustomizer>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MongoClient createMongoClient(MongoClientSettings settings) {
/*  63 */     Integer embeddedPort = getEmbeddedPort();
/*  64 */     if (embeddedPort != null) {
/*  65 */       return createEmbeddedMongoClient(settings, embeddedPort.intValue());
/*     */     }
/*  67 */     return createNetworkMongoClient(settings);
/*     */   }
/*     */   
/*     */   private Integer getEmbeddedPort() {
/*  71 */     if (this.environment != null) {
/*  72 */       String localPort = this.environment.getProperty("local.mongo.port");
/*  73 */       if (localPort != null) {
/*  74 */         return Integer.valueOf(localPort);
/*     */       }
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */   
/*     */   private MongoClient createEmbeddedMongoClient(MongoClientSettings settings, int port) {
/*  81 */     MongoClientSettings.Builder builder = builder(settings);
/*  82 */     String host = (this.properties.getHost() != null) ? this.properties.getHost() : "localhost";
/*  83 */     builder.applyToClusterSettings(cluster -> cluster.hosts(Collections.singletonList(new ServerAddress(host, port))));
/*     */     
/*  85 */     return createMongoClient(builder);
/*     */   }
/*     */   
/*     */   private MongoClient createNetworkMongoClient(MongoClientSettings settings) {
/*  89 */     if (hasCustomAddress() || hasCustomCredentials()) {
/*  90 */       return createCredentialNetworkMongoClient(settings);
/*     */     }
/*  92 */     ConnectionString connectionString = new ConnectionString(this.properties.determineUri());
/*  93 */     return createMongoClient(createBuilder(settings, connectionString));
/*     */   }
/*     */   
/*     */   private MongoClient createCredentialNetworkMongoClient(MongoClientSettings settings) {
/*  97 */     Assert.state((this.properties.getUri() == null), "Invalid mongo configuration, either uri or host/port/credentials must be specified");
/*     */     
/*  99 */     MongoClientSettings.Builder builder = builder(settings);
/* 100 */     if (hasCustomCredentials()) {
/* 101 */       applyCredentials(builder);
/*     */     }
/* 103 */     String host = getOrDefault(this.properties.getHost(), "localhost");
/* 104 */     int port = ((Integer)getOrDefault(this.properties.getPort(), Integer.valueOf(27017))).intValue();
/* 105 */     ServerAddress serverAddress = new ServerAddress(host, port);
/* 106 */     builder.applyToClusterSettings(cluster -> cluster.hosts(Collections.singletonList(serverAddress)));
/* 107 */     return createMongoClient(builder);
/*     */   }
/*     */ 
/*     */   
/*     */   private void applyCredentials(MongoClientSettings.Builder builder) {
/* 112 */     String database = (this.properties.getAuthenticationDatabase() != null) ? this.properties.getAuthenticationDatabase() : this.properties.getMongoClientDatabase();
/* 113 */     builder.credential(MongoCredential.createCredential(this.properties.getUsername(), database, this.properties
/* 114 */           .getPassword()));
/*     */   }
/*     */   
/*     */   private <T> T getOrDefault(T value, T defaultValue) {
/* 118 */     return (value != null) ? value : defaultValue;
/*     */   }
/*     */   
/*     */   private MongoClient createMongoClient(MongoClientSettings.Builder builder) {
/* 122 */     customize(builder);
/* 123 */     return MongoClients.create(builder.build());
/*     */   }
/*     */   
/*     */   private MongoClientSettings.Builder createBuilder(MongoClientSettings settings, ConnectionString connection) {
/* 127 */     return builder(settings).applyConnectionString(connection);
/*     */   }
/*     */   
/*     */   private void customize(MongoClientSettings.Builder builder) {
/* 131 */     for (MongoClientSettingsBuilderCustomizer customizer : this.builderCustomizers) {
/* 132 */       customizer.customize(builder);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean hasCustomAddress() {
/* 137 */     return (this.properties.getHost() != null || this.properties.getPort() != null);
/*     */   }
/*     */   
/*     */   private boolean hasCustomCredentials() {
/* 141 */     return (this.properties.getUsername() != null && this.properties.getPassword() != null);
/*     */   }
/*     */   
/*     */   private MongoClientSettings.Builder builder(MongoClientSettings settings) {
/* 145 */     if (settings == null) {
/* 146 */       return MongoClientSettings.builder();
/*     */     }
/* 148 */     return MongoClientSettings.builder(settings);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mongo\ReactiveMongoClientFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
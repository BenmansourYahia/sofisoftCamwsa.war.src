/*     */ package org.springframework.boot.autoconfigure.mongo.embedded;
/*     */ 
/*     */ import com.mongodb.MongoClient;
/*     */ import com.mongodb.reactivestreams.client.MongoClient;
/*     */ import de.flapdoodle.embed.mongo.Command;
/*     */ import de.flapdoodle.embed.mongo.MongodExecutable;
/*     */ import de.flapdoodle.embed.mongo.MongodStarter;
/*     */ import de.flapdoodle.embed.mongo.config.DownloadConfigBuilder;
/*     */ import de.flapdoodle.embed.mongo.config.ExtractedArtifactStoreBuilder;
/*     */ import de.flapdoodle.embed.mongo.config.IMongodConfig;
/*     */ import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
/*     */ import de.flapdoodle.embed.mongo.config.Net;
/*     */ import de.flapdoodle.embed.mongo.config.RuntimeConfigBuilder;
/*     */ import de.flapdoodle.embed.mongo.config.Storage;
/*     */ import de.flapdoodle.embed.mongo.distribution.Feature;
/*     */ import de.flapdoodle.embed.mongo.distribution.IFeatureAwareVersion;
/*     */ import de.flapdoodle.embed.mongo.distribution.Version;
/*     */ import de.flapdoodle.embed.mongo.distribution.Versions;
/*     */ import de.flapdoodle.embed.process.builder.AbstractBuilder;
/*     */ import de.flapdoodle.embed.process.config.IExecutableProcessConfig;
/*     */ import de.flapdoodle.embed.process.config.IRuntimeConfig;
/*     */ import de.flapdoodle.embed.process.config.io.ProcessOutput;
/*     */ import de.flapdoodle.embed.process.config.store.IDownloadConfig;
/*     */ import de.flapdoodle.embed.process.distribution.GenericVersion;
/*     */ import de.flapdoodle.embed.process.distribution.IVersion;
/*     */ import de.flapdoodle.embed.process.io.Processors;
/*     */ import de.flapdoodle.embed.process.io.Slf4jLevel;
/*     */ import de.flapdoodle.embed.process.io.progress.IProgressListener;
/*     */ import de.flapdoodle.embed.process.io.progress.Slf4jProgressListener;
/*     */ import de.flapdoodle.embed.process.runtime.Network;
/*     */ import de.flapdoodle.embed.process.store.ArtifactStoreBuilder;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.data.mongo.MongoClientDependsOnBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.data.mongo.ReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.data.mongodb.core.MongoClientFactoryBean;
/*     */ import org.springframework.data.mongodb.core.ReactiveMongoClientFactoryBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({MongoProperties.class, EmbeddedMongoProperties.class})
/*     */ @AutoConfigureBefore({MongoAutoConfiguration.class})
/*     */ @ConditionalOnClass({MongoClient.class, MongodStarter.class})
/*     */ @Import({EmbeddedMongoAutoConfiguration.EmbeddedMongoClientDependsOnBeanFactoryPostProcessor.class, EmbeddedMongoAutoConfiguration.EmbeddedReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor.class})
/*     */ public class EmbeddedMongoAutoConfiguration
/*     */ {
/*  94 */   private static final byte[] IP4_LOOPBACK_ADDRESS = new byte[] { Byte.MAX_VALUE, 0, 0, 1 };
/*     */   
/*  96 */   private static final byte[] IP6_LOOPBACK_ADDRESS = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
/*     */   
/*     */   private final MongoProperties properties;
/*     */   
/*     */   public EmbeddedMongoAutoConfiguration(MongoProperties properties, EmbeddedMongoProperties embeddedProperties) {
/* 101 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean(initMethod = "start", destroyMethod = "stop")
/*     */   @ConditionalOnMissingBean
/*     */   public MongodExecutable embeddedMongoServer(IMongodConfig mongodConfig, IRuntimeConfig runtimeConfig, ApplicationContext context) throws IOException {
/* 108 */     Integer configuredPort = this.properties.getPort();
/* 109 */     if (configuredPort == null || configuredPort.intValue() == 0) {
/* 110 */       setEmbeddedPort(context, mongodConfig.net().getPort());
/*     */     }
/* 112 */     MongodStarter mongodStarter = getMongodStarter(runtimeConfig);
/* 113 */     return (MongodExecutable)mongodStarter.prepare((IExecutableProcessConfig)mongodConfig);
/*     */   }
/*     */   
/*     */   private MongodStarter getMongodStarter(IRuntimeConfig runtimeConfig) {
/* 117 */     if (runtimeConfig == null) {
/* 118 */       return MongodStarter.getDefaultInstance();
/*     */     }
/* 120 */     return MongodStarter.getInstance(runtimeConfig);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public IMongodConfig embeddedMongoConfiguration(EmbeddedMongoProperties embeddedProperties) throws IOException {
/* 126 */     MongodConfigBuilder builder = (new MongodConfigBuilder()).version(determineVersion(embeddedProperties));
/* 127 */     EmbeddedMongoProperties.Storage storage = embeddedProperties.getStorage();
/* 128 */     if (storage != null) {
/* 129 */       String databaseDir = storage.getDatabaseDir();
/* 130 */       String replSetName = storage.getReplSetName();
/* 131 */       int oplogSize = (storage.getOplogSize() != null) ? (int)storage.getOplogSize().toMegabytes() : 0;
/* 132 */       builder.replication(new Storage(databaseDir, replSetName, oplogSize));
/*     */     } 
/* 134 */     Integer configuredPort = this.properties.getPort();
/* 135 */     if (configuredPort != null && configuredPort.intValue() > 0) {
/* 136 */       builder.net(new Net(getHost().getHostAddress(), configuredPort.intValue(), Network.localhostIsIPv6()));
/*     */     } else {
/*     */       
/* 139 */       builder.net(new Net(getHost().getHostAddress(), Network.getFreeServerPort(getHost()), 
/* 140 */             Network.localhostIsIPv6()));
/*     */     } 
/* 142 */     return builder.build();
/*     */   }
/*     */   
/*     */   private IFeatureAwareVersion determineVersion(EmbeddedMongoProperties embeddedProperties) {
/* 146 */     if (embeddedProperties.getFeatures() == null) {
/* 147 */       for (Version version : Version.values()) {
/* 148 */         if (version.asInDownloadPath().equals(embeddedProperties.getVersion())) {
/* 149 */           return (IFeatureAwareVersion)version;
/*     */         }
/*     */       } 
/* 152 */       return Versions.withFeatures((IVersion)new GenericVersion(embeddedProperties.getVersion()), new Feature[0]);
/*     */     } 
/* 154 */     return Versions.withFeatures((IVersion)new GenericVersion(embeddedProperties.getVersion()), embeddedProperties
/* 155 */         .getFeatures().<Feature>toArray(new Feature[0]));
/*     */   }
/*     */   
/*     */   private InetAddress getHost() throws UnknownHostException {
/* 159 */     if (this.properties.getHost() == null) {
/* 160 */       return InetAddress.getByAddress(Network.localhostIsIPv6() ? IP6_LOOPBACK_ADDRESS : IP4_LOOPBACK_ADDRESS);
/*     */     }
/* 162 */     return InetAddress.getByName(this.properties.getHost());
/*     */   }
/*     */   
/*     */   private void setEmbeddedPort(ApplicationContext context, int port) {
/* 166 */     setPortProperty(context, port);
/*     */   }
/*     */   
/*     */   private void setPortProperty(ApplicationContext currentContext, int port) {
/* 170 */     if (currentContext instanceof ConfigurableApplicationContext) {
/*     */       
/* 172 */       MutablePropertySources sources = ((ConfigurableApplicationContext)currentContext).getEnvironment().getPropertySources();
/* 173 */       getMongoPorts(sources).put("local.mongo.port", Integer.valueOf(port));
/*     */     } 
/* 175 */     if (currentContext.getParent() != null) {
/* 176 */       setPortProperty(currentContext.getParent(), port);
/*     */     }
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMongoPorts(MutablePropertySources sources) {
/*     */     MapPropertySource mapPropertySource;
/* 182 */     PropertySource<?> propertySource = sources.get("mongo.ports");
/* 183 */     if (propertySource == null) {
/* 184 */       mapPropertySource = new MapPropertySource("mongo.ports", new HashMap<>());
/* 185 */       sources.addFirst((PropertySource)mapPropertySource);
/*     */     } 
/* 187 */     return (Map<String, Object>)mapPropertySource.getSource();
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Logger.class})
/*     */   @ConditionalOnMissingBean({IRuntimeConfig.class})
/*     */   static class RuntimeConfigConfiguration
/*     */   {
/*     */     @Bean
/*     */     IRuntimeConfig embeddedMongoRuntimeConfig(ObjectProvider<DownloadConfigBuilderCustomizer> downloadConfigBuilderCustomizers) {
/* 198 */       Logger logger = LoggerFactory.getLogger(getClass().getPackage().getName() + ".EmbeddedMongo");
/*     */ 
/*     */       
/* 201 */       ProcessOutput processOutput = new ProcessOutput(Processors.logTo(logger, Slf4jLevel.INFO), Processors.logTo(logger, Slf4jLevel.ERROR), Processors.named("[console>]", Processors.logTo(logger, Slf4jLevel.DEBUG)));
/* 202 */       return (new RuntimeConfigBuilder()).defaultsWithLogger(Command.MongoD, logger).processOutput(processOutput)
/* 203 */         .artifactStore((AbstractBuilder)getArtifactStore(logger, downloadConfigBuilderCustomizers.orderedStream()))
/* 204 */         .daemonProcess(false).build();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private ArtifactStoreBuilder getArtifactStore(Logger logger, Stream<DownloadConfigBuilderCustomizer> downloadConfigBuilderCustomizers) {
/* 210 */       DownloadConfigBuilder downloadConfigBuilder = (new DownloadConfigBuilder()).defaultsForCommand(Command.MongoD);
/* 211 */       downloadConfigBuilder.progressListener((IProgressListener)new Slf4jProgressListener(logger));
/* 212 */       downloadConfigBuilderCustomizers.forEach(customizer -> customizer.customize(downloadConfigBuilder));
/* 213 */       IDownloadConfig downloadConfig = downloadConfigBuilder.build();
/* 214 */       return (ArtifactStoreBuilder)(new ExtractedArtifactStoreBuilder()).defaults(Command.MongoD).download(downloadConfig);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({MongoClient.class, MongoClientFactoryBean.class})
/*     */   static class EmbeddedMongoClientDependsOnBeanFactoryPostProcessor
/*     */     extends MongoClientDependsOnBeanFactoryPostProcessor
/*     */   {
/*     */     EmbeddedMongoClientDependsOnBeanFactoryPostProcessor() {
/* 228 */       super(new Class[] { MongodExecutable.class });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass({MongoClient.class, ReactiveMongoClientFactoryBean.class})
/*     */   static class EmbeddedReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor
/*     */     extends ReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor
/*     */   {
/*     */     EmbeddedReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor() {
/* 243 */       super(new Class[] { MongodExecutable.class });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mongo\embedded\EmbeddedMongoAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.mongo;
/*     */ 
/*     */ import com.mongodb.MongoClientSettings;
/*     */ import com.mongodb.connection.StreamFactoryFactory;
/*     */ import com.mongodb.connection.netty.NettyStreamFactoryFactory;
/*     */ import com.mongodb.reactivestreams.client.MongoClient;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.nio.NioEventLoopGroup;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.env.Environment;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({MongoClient.class, Flux.class})
/*     */ @EnableConfigurationProperties({MongoProperties.class})
/*     */ public class MongoReactiveAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public MongoClient reactiveStreamsMongoClient(MongoProperties properties, Environment environment, ObjectProvider<MongoClientSettingsBuilderCustomizer> builderCustomizers, ObjectProvider<MongoClientSettings> settings) {
/*  60 */     ReactiveMongoClientFactory factory = new ReactiveMongoClientFactory(properties, environment, (List<MongoClientSettingsBuilderCustomizer>)builderCustomizers.orderedStream().collect(Collectors.toList()));
/*  61 */     return factory.createMongoClient((MongoClientSettings)settings.getIfAvailable());
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({SocketChannel.class, NioEventLoopGroup.class})
/*     */   static class NettyDriverConfiguration
/*     */   {
/*     */     @Bean
/*     */     @Order(-2147483648)
/*     */     MongoReactiveAutoConfiguration.NettyDriverMongoClientSettingsBuilderCustomizer nettyDriverCustomizer(ObjectProvider<MongoClientSettings> settings) {
/*  72 */       return new MongoReactiveAutoConfiguration.NettyDriverMongoClientSettingsBuilderCustomizer(settings);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class NettyDriverMongoClientSettingsBuilderCustomizer
/*     */     implements MongoClientSettingsBuilderCustomizer, DisposableBean
/*     */   {
/*     */     private final ObjectProvider<MongoClientSettings> settings;
/*     */ 
/*     */     
/*     */     private volatile EventLoopGroup eventLoopGroup;
/*     */ 
/*     */     
/*     */     private NettyDriverMongoClientSettingsBuilderCustomizer(ObjectProvider<MongoClientSettings> settings) {
/*  88 */       this.settings = settings;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(MongoClientSettings.Builder builder) {
/*  93 */       if (!isStreamFactoryFactoryDefined((MongoClientSettings)this.settings.getIfAvailable())) {
/*  94 */         NioEventLoopGroup eventLoopGroup = new NioEventLoopGroup();
/*  95 */         this.eventLoopGroup = (EventLoopGroup)eventLoopGroup;
/*  96 */         builder.streamFactoryFactory(
/*  97 */             (StreamFactoryFactory)NettyStreamFactoryFactory.builder().eventLoopGroup((EventLoopGroup)eventLoopGroup).build());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void destroy() {
/* 103 */       EventLoopGroup eventLoopGroup = this.eventLoopGroup;
/* 104 */       if (eventLoopGroup != null) {
/* 105 */         eventLoopGroup.shutdownGracefully().awaitUninterruptibly();
/* 106 */         this.eventLoopGroup = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isStreamFactoryFactoryDefined(MongoClientSettings settings) {
/* 111 */       return (settings != null && settings.getStreamFactoryFactory() != null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mongo\MongoReactiveAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
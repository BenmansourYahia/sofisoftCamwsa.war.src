package org.springframework.boot.autoconfigure.mongo.embedded;

import de.flapdoodle.embed.mongo.config.DownloadConfigBuilder;

@FunctionalInterface
public interface DownloadConfigBuilderCustomizer {
  void customize(DownloadConfigBuilder paramDownloadConfigBuilder);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mongo\embedded\DownloadConfigBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
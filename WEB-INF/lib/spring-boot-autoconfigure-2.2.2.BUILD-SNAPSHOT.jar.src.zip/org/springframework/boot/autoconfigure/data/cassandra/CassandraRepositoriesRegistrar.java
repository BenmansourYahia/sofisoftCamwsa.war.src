/*    */ package org.springframework.boot.autoconfigure.data.cassandra;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.data.cassandra.repository.config.CassandraRepositoryConfigurationExtension;
/*    */ import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CassandraRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation() {
/* 37 */     return (Class)EnableCassandraRepositories.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> getConfiguration() {
/* 42 */     return EnableCassandraRepositoriesConfiguration.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension() {
/* 47 */     return (RepositoryConfigurationExtension)new CassandraRepositoryConfigurationExtension();
/*    */   }
/*    */   
/*    */   @EnableCassandraRepositories
/*    */   private static class EnableCassandraRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\cassandra\CassandraRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.data;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnRepositoryTypeCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 39 */     Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalOnRepositoryType.class.getName(), true);
/*    */     
/* 41 */     RepositoryType configuredType = getTypeProperty(context.getEnvironment(), (String)attributes.get("store"));
/* 42 */     RepositoryType requiredType = (RepositoryType)attributes.get("type");
/* 43 */     ConditionMessage.Builder message = ConditionMessage.forCondition(ConditionalOnRepositoryType.class, new Object[0]);
/* 44 */     if (configuredType == requiredType || configuredType == RepositoryType.AUTO) {
/* 45 */       return 
/* 46 */         ConditionOutcome.match(message.because("configured type of '" + configuredType.name() + "' matched required type"));
/*    */     }
/* 48 */     return ConditionOutcome.noMatch(message.because("configured type (" + configuredType.name() + ") did not match required type (" + requiredType
/* 49 */           .name() + ")"));
/*    */   }
/*    */   
/*    */   private RepositoryType getTypeProperty(Environment environment, String store) {
/* 53 */     return 
/* 54 */       RepositoryType.valueOf(environment.getProperty(String.format("spring.data.%s.repositories.type", new Object[] { store }), "auto")
/* 55 */         .toUpperCase(Locale.ENGLISH));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\OnRepositoryTypeCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.annotation.Persistent;
/*    */ import org.springframework.data.mapping.model.FieldNamingStrategy;
/*    */ import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
/*    */ import org.springframework.data.mongodb.core.mapping.Document;
/*    */ import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class MongoDataConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   MongoMappingContext mongoMappingContext(ApplicationContext applicationContext, MongoProperties properties, MongoCustomConversions conversions) throws ClassNotFoundException {
/* 47 */     PropertyMapper mapper = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 48 */     MongoMappingContext context = new MongoMappingContext();
/* 49 */     mapper.from(properties.isAutoIndexCreation()).to(context::setAutoIndexCreation);
/* 50 */     context.setInitialEntitySet((new EntityScanner(applicationContext)).scan(new Class[] { Document.class, Persistent.class }));
/* 51 */     Class<?> strategyClass = properties.getFieldNamingStrategy();
/* 52 */     if (strategyClass != null) {
/* 53 */       context.setFieldNamingStrategy((FieldNamingStrategy)BeanUtils.instantiateClass(strategyClass));
/*    */     }
/* 55 */     context.setSimpleTypeHolder(conversions.getSimpleTypeHolder());
/* 56 */     return context;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   MongoCustomConversions mongoCustomConversions() {
/* 62 */     return new MongoCustomConversions(Collections.emptyList());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDataConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
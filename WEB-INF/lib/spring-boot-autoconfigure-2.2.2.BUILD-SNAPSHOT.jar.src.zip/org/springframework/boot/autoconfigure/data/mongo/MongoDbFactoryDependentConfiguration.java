/*     */ package org.springframework.boot.autoconfigure.data.mongo;
/*     */ 
/*     */ import com.mongodb.ClientSessionOptions;
/*     */ import com.mongodb.DB;
/*     */ import com.mongodb.client.ClientSession;
/*     */ import com.mongodb.client.MongoDatabase;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.data.convert.CustomConversions;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.mongodb.MongoDbFactory;
/*     */ import org.springframework.data.mongodb.core.MongoOperations;
/*     */ import org.springframework.data.mongodb.core.MongoTemplate;
/*     */ import org.springframework.data.mongodb.core.convert.DbRefResolver;
/*     */ import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
/*     */ import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
/*     */ import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
/*     */ import org.springframework.data.mongodb.gridfs.GridFsOperations;
/*     */ import org.springframework.data.mongodb.gridfs.GridFsTemplate;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnBean({MongoDbFactory.class})
/*     */ class MongoDbFactoryDependentConfiguration
/*     */ {
/*     */   private final MongoProperties properties;
/*     */   
/*     */   MongoDbFactoryDependentConfiguration(MongoProperties properties) {
/*  57 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({MongoOperations.class})
/*     */   MongoTemplate mongoTemplate(MongoDbFactory mongoDbFactory, MongoConverter converter) {
/*  63 */     return new MongoTemplate(mongoDbFactory, converter);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({MongoConverter.class})
/*     */   MappingMongoConverter mappingMongoConverter(MongoDbFactory factory, MongoMappingContext context, MongoCustomConversions conversions) {
/*  70 */     DefaultDbRefResolver defaultDbRefResolver = new DefaultDbRefResolver(factory);
/*  71 */     MappingMongoConverter mappingConverter = new MappingMongoConverter((DbRefResolver)defaultDbRefResolver, (MappingContext)context);
/*  72 */     mappingConverter.setCustomConversions((CustomConversions)conversions);
/*  73 */     return mappingConverter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({GridFsOperations.class})
/*     */   GridFsTemplate gridFsTemplate(MongoDbFactory mongoDbFactory, MongoTemplate mongoTemplate) {
/*  79 */     return new GridFsTemplate(new GridFsMongoDbFactory(mongoDbFactory, this.properties), mongoTemplate
/*  80 */         .getConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class GridFsMongoDbFactory
/*     */     implements MongoDbFactory
/*     */   {
/*     */     private final MongoDbFactory mongoDbFactory;
/*     */     
/*     */     private final MongoProperties properties;
/*     */ 
/*     */     
/*     */     GridFsMongoDbFactory(MongoDbFactory mongoDbFactory, MongoProperties properties) {
/*  94 */       Assert.notNull(mongoDbFactory, "MongoDbFactory must not be null");
/*  95 */       Assert.notNull(properties, "Properties must not be null");
/*  96 */       this.mongoDbFactory = mongoDbFactory;
/*  97 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     public MongoDatabase getDb() throws DataAccessException {
/* 102 */       String gridFsDatabase = this.properties.getGridFsDatabase();
/* 103 */       if (StringUtils.hasText(gridFsDatabase)) {
/* 104 */         return this.mongoDbFactory.getDb(gridFsDatabase);
/*     */       }
/* 106 */       return this.mongoDbFactory.getDb();
/*     */     }
/*     */ 
/*     */     
/*     */     public MongoDatabase getDb(String dbName) throws DataAccessException {
/* 111 */       return this.mongoDbFactory.getDb(dbName);
/*     */     }
/*     */ 
/*     */     
/*     */     public PersistenceExceptionTranslator getExceptionTranslator() {
/* 116 */       return this.mongoDbFactory.getExceptionTranslator();
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public DB getLegacyDb() {
/* 122 */       return this.mongoDbFactory.getLegacyDb();
/*     */     }
/*     */ 
/*     */     
/*     */     public ClientSession getSession(ClientSessionOptions options) {
/* 127 */       return this.mongoDbFactory.getSession(options);
/*     */     }
/*     */ 
/*     */     
/*     */     public MongoDbFactory withSession(ClientSession session) {
/* 132 */       return this.mongoDbFactory.withSession(session);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDbFactoryDependentConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
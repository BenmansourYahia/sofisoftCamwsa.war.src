/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
/*    */ import org.springframework.data.redis.core.ReactiveRedisTemplate;
/*    */ import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
/*    */ import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
/*    */ import org.springframework.data.redis.serializer.RedisSerializationContext;
/*    */ import org.springframework.data.redis.serializer.RedisSerializer;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({ReactiveRedisConnectionFactory.class, ReactiveRedisTemplate.class, Flux.class})
/*    */ @AutoConfigureAfter({RedisAutoConfiguration.class})
/*    */ public class RedisReactiveAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"reactiveRedisTemplate"})
/*    */   @ConditionalOnBean({ReactiveRedisConnectionFactory.class})
/*    */   public ReactiveRedisTemplate<Object, Object> reactiveRedisTemplate(ReactiveRedisConnectionFactory reactiveRedisConnectionFactory, ResourceLoader resourceLoader) {
/* 54 */     JdkSerializationRedisSerializer jdkSerializer = new JdkSerializationRedisSerializer(resourceLoader.getClassLoader());
/*    */ 
/*    */     
/* 57 */     RedisSerializationContext<Object, Object> serializationContext = RedisSerializationContext.newSerializationContext().key((RedisSerializer)jdkSerializer).value((RedisSerializer)jdkSerializer).hashKey((RedisSerializer)jdkSerializer).hashValue((RedisSerializer)jdkSerializer).build();
/* 58 */     return new ReactiveRedisTemplate(reactiveRedisConnectionFactory, serializationContext);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"reactiveStringRedisTemplate"})
/*    */   @ConditionalOnBean({ReactiveRedisConnectionFactory.class})
/*    */   public ReactiveStringRedisTemplate reactiveStringRedisTemplate(ReactiveRedisConnectionFactory reactiveRedisConnectionFactory) {
/* 66 */     return new ReactiveStringRedisTemplate(reactiveRedisConnectionFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\redis\RedisReactiveAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
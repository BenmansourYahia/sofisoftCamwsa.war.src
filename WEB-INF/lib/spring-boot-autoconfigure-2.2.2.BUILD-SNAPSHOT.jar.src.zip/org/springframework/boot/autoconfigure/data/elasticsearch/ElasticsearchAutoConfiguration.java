/*    */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.elasticsearch.client.Client;
/*    */ import org.elasticsearch.client.transport.TransportClient;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.elasticsearch.client.TransportClientFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Client.class, TransportClientFactoryBean.class})
/*    */ @ConditionalOnProperty(prefix = "spring.data.elasticsearch", name = {"cluster-nodes"}, matchIfMissing = false)
/*    */ @EnableConfigurationProperties({ElasticsearchProperties.class})
/*    */ public class ElasticsearchAutoConfiguration
/*    */ {
/*    */   private final ElasticsearchProperties properties;
/*    */   
/*    */   public ElasticsearchAutoConfiguration(ElasticsearchProperties properties) {
/* 50 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public TransportClient elasticsearchClient() throws Exception {
/* 56 */     TransportClientFactoryBean factory = new TransportClientFactoryBean();
/* 57 */     factory.setClusterNodes(this.properties.getClusterNodes());
/* 58 */     factory.setProperties(createProperties());
/* 59 */     factory.afterPropertiesSet();
/* 60 */     return factory.getObject();
/*    */   }
/*    */   
/*    */   private Properties createProperties() {
/* 64 */     Properties properties = new Properties();
/* 65 */     properties.put("cluster.name", this.properties.getClusterName());
/* 66 */     properties.putAll(this.properties.getProperties());
/* 67 */     return properties;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
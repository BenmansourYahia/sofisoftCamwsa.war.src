/*    */ package org.springframework.boot.autoconfigure.data.jpa;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Locale;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
/*    */ import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;
/*    */ import org.springframework.data.repository.config.BootstrapMode;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JpaRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/* 40 */   private BootstrapMode bootstrapMode = null;
/*    */ 
/*    */   
/*    */   protected Class<? extends Annotation> getAnnotation() {
/* 44 */     return (Class)EnableJpaRepositories.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> getConfiguration() {
/* 49 */     return EnableJpaRepositoriesConfiguration.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension() {
/* 54 */     return (RepositoryConfigurationExtension)new JpaRepositoryConfigExtension();
/*    */   }
/*    */ 
/*    */   
/*    */   protected BootstrapMode getBootstrapMode() {
/* 59 */     return (this.bootstrapMode == null) ? super.getBootstrapMode() : this.bootstrapMode;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEnvironment(Environment environment) {
/* 64 */     super.setEnvironment(environment);
/* 65 */     configureBootstrapMode(environment);
/*    */   }
/*    */   
/*    */   private void configureBootstrapMode(Environment environment) {
/* 69 */     String property = environment.getProperty("spring.data.jpa.repositories.bootstrap-mode");
/* 70 */     if (StringUtils.hasText(property))
/* 71 */       this.bootstrapMode = BootstrapMode.valueOf(property.toUpperCase(Locale.ENGLISH)); 
/*    */   }
/*    */   
/*    */   @EnableJpaRepositories
/*    */   private static class EnableJpaRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\jpa\JpaRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
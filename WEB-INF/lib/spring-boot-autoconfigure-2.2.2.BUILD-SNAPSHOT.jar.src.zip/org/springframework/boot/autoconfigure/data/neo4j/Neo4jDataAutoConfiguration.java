/*     */ package org.springframework.boot.autoconfigure.data.neo4j;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.neo4j.ogm.config.Configuration;
/*     */ import org.neo4j.ogm.session.SessionFactory;
/*     */ import org.neo4j.ogm.session.event.EventListener;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.data.neo4j.transaction.Neo4jTransactionManager;
/*     */ import org.springframework.data.neo4j.web.support.OpenSessionInViewInterceptor;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({SessionFactory.class, Neo4jTransactionManager.class, PlatformTransactionManager.class})
/*     */ @EnableConfigurationProperties({Neo4jProperties.class})
/*     */ @Import({Neo4jBookmarkManagementConfiguration.class})
/*     */ public class Neo4jDataAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*     */   public Neo4jTransactionManager transactionManager(SessionFactory sessionFactory, ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
/*  69 */     Neo4jTransactionManager transactionManager = new Neo4jTransactionManager(sessionFactory);
/*  70 */     transactionManagerCustomizers.ifAvailable(customizers -> customizers.customize((PlatformTransactionManager)transactionManager));
/*  71 */     return transactionManager;
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({SessionFactory.class})
/*     */   static class Neo4jOgmSessionFactoryConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     Configuration configuration(Neo4jProperties properties) {
/*  81 */       return properties.createConfiguration();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     SessionFactory sessionFactory(Configuration configuration, BeanFactory beanFactory, ObjectProvider<EventListener> eventListeners) {
/*  87 */       SessionFactory sessionFactory = new SessionFactory(configuration, getPackagesToScan(beanFactory));
/*  88 */       eventListeners.orderedStream().forEach(sessionFactory::register);
/*  89 */       return sessionFactory;
/*     */     }
/*     */     
/*     */     private String[] getPackagesToScan(BeanFactory beanFactory) {
/*  93 */       List<String> packages = EntityScanPackages.get(beanFactory).getPackageNames();
/*  94 */       if (packages.isEmpty() && AutoConfigurationPackages.has(beanFactory)) {
/*  95 */         packages = AutoConfigurationPackages.get(beanFactory);
/*     */       }
/*  97 */       return StringUtils.toStringArray(packages);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */   @ConditionalOnClass({WebMvcConfigurer.class, OpenSessionInViewInterceptor.class})
/*     */   @ConditionalOnMissingBean({OpenSessionInViewInterceptor.class})
/*     */   @ConditionalOnProperty(prefix = "spring.data.neo4j", name = {"open-in-view"}, havingValue = "true", matchIfMissing = true)
/*     */   static class Neo4jWebConfiguration
/*     */   {
/* 110 */     private static final Log logger = LogFactory.getLog(Neo4jWebConfiguration.class);
/*     */     
/*     */     @Bean
/*     */     OpenSessionInViewInterceptor neo4jOpenSessionInViewInterceptor(Neo4jProperties properties) {
/* 114 */       if (properties.getOpenInView() == null) {
/* 115 */         logger.warn("spring.data.neo4j.open-in-view is enabled by default.Therefore, database queries may be performed during view rendering. Explicitly configure spring.data.neo4j.open-in-view to disable this warning");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 120 */       return new OpenSessionInViewInterceptor();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     WebMvcConfigurer neo4jOpenSessionInViewInterceptorConfigurer(final OpenSessionInViewInterceptor interceptor) {
/* 125 */       return new WebMvcConfigurer()
/*     */         {
/*     */           public void addInterceptors(InterceptorRegistry registry)
/*     */           {
/* 129 */             registry.addWebRequestInterceptor((WebRequestInterceptor)interceptor);
/*     */           }
/*     */         };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jDataAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
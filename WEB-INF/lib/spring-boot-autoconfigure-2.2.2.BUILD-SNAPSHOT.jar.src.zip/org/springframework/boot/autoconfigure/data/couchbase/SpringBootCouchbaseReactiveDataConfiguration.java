/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.couchbase.config.AbstractReactiveCouchbaseDataConfiguration;
/*    */ import org.springframework.data.couchbase.config.CouchbaseConfigurer;
/*    */ import org.springframework.data.couchbase.core.RxJavaCouchbaseTemplate;
/*    */ import org.springframework.data.couchbase.core.query.Consistency;
/*    */ import org.springframework.data.couchbase.repository.config.ReactiveRepositoryOperationsMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnMissingBean({AbstractReactiveCouchbaseDataConfiguration.class})
/*    */ @ConditionalOnBean({CouchbaseConfigurer.class})
/*    */ class SpringBootCouchbaseReactiveDataConfiguration
/*    */   extends AbstractReactiveCouchbaseDataConfiguration
/*    */ {
/*    */   private final CouchbaseDataProperties properties;
/*    */   private final CouchbaseConfigurer couchbaseConfigurer;
/*    */   
/*    */   SpringBootCouchbaseReactiveDataConfiguration(CouchbaseDataProperties properties, CouchbaseConfigurer couchbaseConfigurer) {
/* 46 */     this.properties = properties;
/* 47 */     this.couchbaseConfigurer = couchbaseConfigurer;
/*    */   }
/*    */ 
/*    */   
/*    */   protected CouchbaseConfigurer couchbaseConfigurer() {
/* 52 */     return this.couchbaseConfigurer;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Consistency getDefaultConsistency() {
/* 57 */     return this.properties.getConsistency();
/*    */   }
/*    */ 
/*    */   
/*    */   @ConditionalOnMissingBean(name = {"rxjava1CouchbaseTemplate"})
/*    */   @Bean(name = {"rxjava1CouchbaseTemplate"})
/*    */   public RxJavaCouchbaseTemplate reactiveCouchbaseTemplate() throws Exception {
/* 64 */     return super.reactiveCouchbaseTemplate();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @ConditionalOnMissingBean(name = {"reactiveCouchbaseRepositoryOperationsMapping"})
/*    */   @Bean(name = {"reactiveCouchbaseRepositoryOperationsMapping"})
/*    */   public ReactiveRepositoryOperationsMapping reactiveRepositoryOperationsMapping(RxJavaCouchbaseTemplate reactiveCouchbaseTemplate) throws Exception {
/* 72 */     return super.reactiveRepositoryOperationsMapping(reactiveCouchbaseTemplate);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\couchbase\SpringBootCouchbaseReactiveDataConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
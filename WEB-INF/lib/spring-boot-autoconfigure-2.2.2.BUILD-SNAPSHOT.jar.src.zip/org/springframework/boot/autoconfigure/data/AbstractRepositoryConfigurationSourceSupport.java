/*     */ package org.springframework.boot.autoconfigure.data;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.data.repository.config.AnnotationRepositoryConfigurationSource;
/*     */ import org.springframework.data.repository.config.BootstrapMode;
/*     */ import org.springframework.data.repository.config.RepositoryConfigurationDelegate;
/*     */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*     */ import org.springframework.data.repository.config.RepositoryConfigurationSource;
/*     */ import org.springframework.data.util.Streamable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRepositoryConfigurationSourceSupport
/*     */   implements ImportBeanDefinitionRegistrar, BeanFactoryAware, ResourceLoaderAware, EnvironmentAware
/*     */ {
/*     */   private ResourceLoader resourceLoader;
/*     */   private BeanFactory beanFactory;
/*     */   private Environment environment;
/*     */   
/*     */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry, BeanNameGenerator importBeanNameGenerator) {
/*  61 */     RepositoryConfigurationDelegate delegate = new RepositoryConfigurationDelegate((RepositoryConfigurationSource)getConfigurationSource(registry, importBeanNameGenerator), this.resourceLoader, this.environment);
/*  62 */     delegate.registerRepositoriesIn(registry, getRepositoryConfigurationExtension());
/*     */   }
/*     */ 
/*     */   
/*     */   private AnnotationRepositoryConfigurationSource getConfigurationSource(BeanDefinitionRegistry registry, BeanNameGenerator importBeanNameGenerator) {
/*  67 */     AnnotationMetadata metadata = AnnotationMetadata.introspect(getConfiguration());
/*  68 */     return new AutoConfiguredAnnotationRepositoryConfigurationSource(metadata, getAnnotation(), this.resourceLoader, this.environment, registry, importBeanNameGenerator) {
/*     */       
/*     */       };
/*     */   }
/*     */   
/*     */   protected Streamable<String> getBasePackages() {
/*  74 */     return Streamable.of(AutoConfigurationPackages.get(this.beanFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Class<? extends Annotation> getAnnotation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Class<?> getConfiguration();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract RepositoryConfigurationExtension getRepositoryConfigurationExtension();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BootstrapMode getBootstrapMode() {
/* 101 */     return BootstrapMode.DEFAULT;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 106 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 111 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 116 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class AutoConfiguredAnnotationRepositoryConfigurationSource
/*     */     extends AnnotationRepositoryConfigurationSource
/*     */   {
/*     */     AutoConfiguredAnnotationRepositoryConfigurationSource(AnnotationMetadata metadata, Class<? extends Annotation> annotation, ResourceLoader resourceLoader, Environment environment, BeanDefinitionRegistry registry, BeanNameGenerator generator) {
/* 128 */       super(metadata, annotation, resourceLoader, environment, registry, generator);
/*     */     }
/*     */ 
/*     */     
/*     */     public Streamable<String> getBasePackages() {
/* 133 */       return AbstractRepositoryConfigurationSourceSupport.this.getBasePackages();
/*     */     }
/*     */ 
/*     */     
/*     */     public BootstrapMode getBootstrapMode() {
/* 138 */       return AbstractRepositoryConfigurationSourceSupport.this.getBootstrapMode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\AbstractRepositoryConfigurationSourceSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.data.cassandra;
/*     */ 
/*     */ import com.datastax.driver.core.Cluster;
/*     */ import com.datastax.driver.core.Session;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.cassandra.CassandraProperties;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.data.cassandra.config.CassandraEntityClassScanner;
/*     */ import org.springframework.data.cassandra.config.CassandraSessionFactoryBean;
/*     */ import org.springframework.data.cassandra.config.SchemaAction;
/*     */ import org.springframework.data.cassandra.core.CassandraAdminOperations;
/*     */ import org.springframework.data.cassandra.core.CassandraOperations;
/*     */ import org.springframework.data.cassandra.core.CassandraTemplate;
/*     */ import org.springframework.data.cassandra.core.convert.CassandraConverter;
/*     */ import org.springframework.data.cassandra.core.convert.CassandraCustomConversions;
/*     */ import org.springframework.data.cassandra.core.convert.MappingCassandraConverter;
/*     */ import org.springframework.data.cassandra.core.mapping.CassandraMappingContext;
/*     */ import org.springframework.data.cassandra.core.mapping.SimpleUserTypeResolver;
/*     */ import org.springframework.data.convert.CustomConversions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({Cluster.class, CassandraAdminOperations.class})
/*     */ @ConditionalOnBean({Cluster.class})
/*     */ @EnableConfigurationProperties({CassandraProperties.class})
/*     */ @AutoConfigureAfter({CassandraAutoConfiguration.class})
/*     */ public class CassandraDataAutoConfiguration
/*     */ {
/*     */   private final CassandraProperties properties;
/*     */   private final Cluster cluster;
/*     */   
/*     */   public CassandraDataAutoConfiguration(CassandraProperties properties, Cluster cluster) {
/*  74 */     this.properties = properties;
/*  75 */     this.cluster = cluster;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraMappingContext cassandraMapping(BeanFactory beanFactory, CassandraCustomConversions conversions) throws ClassNotFoundException {
/*  82 */     CassandraMappingContext context = new CassandraMappingContext();
/*  83 */     List<String> packages = EntityScanPackages.get(beanFactory).getPackageNames();
/*  84 */     if (packages.isEmpty() && AutoConfigurationPackages.has(beanFactory)) {
/*  85 */       packages = AutoConfigurationPackages.get(beanFactory);
/*     */     }
/*  87 */     if (!packages.isEmpty()) {
/*  88 */       context.setInitialEntitySet(CassandraEntityClassScanner.scan(packages));
/*     */     }
/*  90 */     PropertyMapper.get().from(this.properties::getKeyspaceName).whenHasText().as(this::createSimpleUserTypeResolver)
/*  91 */       .to(context::setUserTypeResolver);
/*  92 */     context.setCustomConversions((CustomConversions)conversions);
/*  93 */     return context;
/*     */   }
/*     */   
/*     */   private SimpleUserTypeResolver createSimpleUserTypeResolver(String keyspaceName) {
/*  97 */     return new SimpleUserTypeResolver(this.cluster, keyspaceName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraConverter cassandraConverter(CassandraMappingContext mapping, CassandraCustomConversions conversions) {
/* 104 */     MappingCassandraConverter converter = new MappingCassandraConverter(mapping);
/* 105 */     converter.setCustomConversions((CustomConversions)conversions);
/* 106 */     return (CassandraConverter)converter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({Session.class})
/*     */   public CassandraSessionFactoryBean cassandraSession(Environment environment, CassandraConverter converter) {
/* 112 */     CassandraSessionFactoryBean session = new CassandraSessionFactoryBean();
/* 113 */     session.setCluster(this.cluster);
/* 114 */     session.setConverter(converter);
/* 115 */     session.setKeyspaceName(this.properties.getKeyspaceName());
/* 116 */     Binder binder = Binder.get(environment);
/* 117 */     binder.bind("spring.data.cassandra.schema-action", SchemaAction.class).ifBound(session::setSchemaAction);
/* 118 */     return session;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({CassandraOperations.class})
/*     */   public CassandraTemplate cassandraTemplate(Session session, CassandraConverter converter) {
/* 124 */     return new CassandraTemplate(session, converter);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraCustomConversions cassandraCustomConversions() {
/* 130 */     return new CassandraCustomConversions(Collections.emptyList());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\cassandra\CassandraDataAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
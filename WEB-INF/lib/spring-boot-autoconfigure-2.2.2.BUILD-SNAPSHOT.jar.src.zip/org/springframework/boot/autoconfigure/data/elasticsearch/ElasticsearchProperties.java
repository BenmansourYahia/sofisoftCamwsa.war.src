/*    */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.data.elasticsearch")
/*    */ public class ElasticsearchProperties
/*    */ {
/* 37 */   private String clusterName = "elasticsearch";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String clusterNodes;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   private Map<String, String> properties = new HashMap<>();
/*    */   
/*    */   public String getClusterName() {
/* 50 */     return this.clusterName;
/*    */   }
/*    */   
/*    */   public void setClusterName(String clusterName) {
/* 54 */     this.clusterName = clusterName;
/*    */   }
/*    */   
/*    */   public String getClusterNodes() {
/* 58 */     return this.clusterNodes;
/*    */   }
/*    */   
/*    */   public void setClusterNodes(String clusterNodes) {
/* 62 */     this.clusterNodes = clusterNodes;
/*    */   }
/*    */   
/*    */   public Map<String, String> getProperties() {
/* 66 */     return this.properties;
/*    */   }
/*    */   
/*    */   public void setProperties(Map<String, String> properties) {
/* 70 */     this.properties = properties;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
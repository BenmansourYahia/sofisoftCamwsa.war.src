/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ import java.net.UnknownHostException;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*    */ import org.springframework.data.redis.core.RedisOperations;
/*    */ import org.springframework.data.redis.core.RedisTemplate;
/*    */ import org.springframework.data.redis.core.StringRedisTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({RedisOperations.class})
/*    */ @EnableConfigurationProperties({RedisProperties.class})
/*    */ @Import({LettuceConnectionConfiguration.class, JedisConnectionConfiguration.class})
/*    */ public class RedisAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"redisTemplate"})
/*    */   public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) throws UnknownHostException {
/* 57 */     RedisTemplate<Object, Object> template = new RedisTemplate();
/* 58 */     template.setConnectionFactory(redisConnectionFactory);
/* 59 */     return template;
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public StringRedisTemplate stringRedisTemplate(RedisConnectionFactory redisConnectionFactory) throws UnknownHostException {
/* 66 */     StringRedisTemplate template = new StringRedisTemplate();
/* 67 */     template.setConnectionFactory(redisConnectionFactory);
/* 68 */     return template;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\redis\RedisAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.redis")
/*     */ public class RedisProperties
/*     */ {
/*  41 */   private int database = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private String host = "localhost";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private int port = 6379;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ssl;
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration timeout;
/*     */ 
/*     */ 
/*     */   
/*     */   private String clientName;
/*     */ 
/*     */   
/*     */   private Sentinel sentinel;
/*     */ 
/*     */   
/*     */   private Cluster cluster;
/*     */ 
/*     */   
/*  83 */   private final Jedis jedis = new Jedis();
/*     */   
/*  85 */   private final Lettuce lettuce = new Lettuce();
/*     */   
/*     */   public int getDatabase() {
/*  88 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(int database) {
/*  92 */     this.database = database;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/*  96 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 100 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getHost() {
/* 104 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/* 108 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 112 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 116 */     this.password = password;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 120 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 124 */     this.port = port;
/*     */   }
/*     */   
/*     */   public boolean isSsl() {
/* 128 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSsl(boolean ssl) {
/* 132 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */   public void setTimeout(Duration timeout) {
/* 136 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public Duration getTimeout() {
/* 140 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public String getClientName() {
/* 144 */     return this.clientName;
/*     */   }
/*     */   
/*     */   public void setClientName(String clientName) {
/* 148 */     this.clientName = clientName;
/*     */   }
/*     */   
/*     */   public Sentinel getSentinel() {
/* 152 */     return this.sentinel;
/*     */   }
/*     */   
/*     */   public void setSentinel(Sentinel sentinel) {
/* 156 */     this.sentinel = sentinel;
/*     */   }
/*     */   
/*     */   public Cluster getCluster() {
/* 160 */     return this.cluster;
/*     */   }
/*     */   
/*     */   public void setCluster(Cluster cluster) {
/* 164 */     this.cluster = cluster;
/*     */   }
/*     */   
/*     */   public Jedis getJedis() {
/* 168 */     return this.jedis;
/*     */   }
/*     */   
/*     */   public Lettuce getLettuce() {
/* 172 */     return this.lettuce;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pool
/*     */   {
/* 184 */     private int maxIdle = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     private int minIdle = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     private int maxActive = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     private Duration maxWait = Duration.ofMillis(-1L);
/*     */ 
/*     */ 
/*     */     
/*     */     private Duration timeBetweenEvictionRuns;
/*     */ 
/*     */ 
/*     */     
/*     */     public int getMaxIdle() {
/* 213 */       return this.maxIdle;
/*     */     }
/*     */     
/*     */     public void setMaxIdle(int maxIdle) {
/* 217 */       this.maxIdle = maxIdle;
/*     */     }
/*     */     
/*     */     public int getMinIdle() {
/* 221 */       return this.minIdle;
/*     */     }
/*     */     
/*     */     public void setMinIdle(int minIdle) {
/* 225 */       this.minIdle = minIdle;
/*     */     }
/*     */     
/*     */     public int getMaxActive() {
/* 229 */       return this.maxActive;
/*     */     }
/*     */     
/*     */     public void setMaxActive(int maxActive) {
/* 233 */       this.maxActive = maxActive;
/*     */     }
/*     */     
/*     */     public Duration getMaxWait() {
/* 237 */       return this.maxWait;
/*     */     }
/*     */     
/*     */     public void setMaxWait(Duration maxWait) {
/* 241 */       this.maxWait = maxWait;
/*     */     }
/*     */     
/*     */     public Duration getTimeBetweenEvictionRuns() {
/* 245 */       return this.timeBetweenEvictionRuns;
/*     */     }
/*     */     
/*     */     public void setTimeBetweenEvictionRuns(Duration timeBetweenEvictionRuns) {
/* 249 */       this.timeBetweenEvictionRuns = timeBetweenEvictionRuns;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Cluster
/*     */   {
/*     */     private List<String> nodes;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer maxRedirects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> getNodes() {
/* 272 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(List<String> nodes) {
/* 276 */       this.nodes = nodes;
/*     */     }
/*     */     
/*     */     public Integer getMaxRedirects() {
/* 280 */       return this.maxRedirects;
/*     */     }
/*     */     
/*     */     public void setMaxRedirects(Integer maxRedirects) {
/* 284 */       this.maxRedirects = maxRedirects;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Sentinel
/*     */   {
/*     */     private String master;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<String> nodes;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getMaster() {
/* 305 */       return this.master;
/*     */     }
/*     */     
/*     */     public void setMaster(String master) {
/* 309 */       this.master = master;
/*     */     }
/*     */     
/*     */     public List<String> getNodes() {
/* 313 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(List<String> nodes) {
/* 317 */       this.nodes = nodes;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Jedis
/*     */   {
/*     */     private RedisProperties.Pool pool;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RedisProperties.Pool getPool() {
/* 333 */       return this.pool;
/*     */     }
/*     */     
/*     */     public void setPool(RedisProperties.Pool pool) {
/* 337 */       this.pool = pool;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Lettuce
/*     */   {
/* 350 */     private Duration shutdownTimeout = Duration.ofMillis(100L);
/*     */ 
/*     */     
/*     */     private RedisProperties.Pool pool;
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getShutdownTimeout() {
/* 358 */       return this.shutdownTimeout;
/*     */     }
/*     */     
/*     */     public void setShutdownTimeout(Duration shutdownTimeout) {
/* 362 */       this.shutdownTimeout = shutdownTimeout;
/*     */     }
/*     */     
/*     */     public RedisProperties.Pool getPool() {
/* 366 */       return this.pool;
/*     */     }
/*     */     
/*     */     public void setPool(RedisProperties.Pool pool) {
/* 370 */       this.pool = pool;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\redis\RedisProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
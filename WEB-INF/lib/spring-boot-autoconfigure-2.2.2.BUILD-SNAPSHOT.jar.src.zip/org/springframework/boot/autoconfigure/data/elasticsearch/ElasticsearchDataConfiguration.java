/*     */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*     */ 
/*     */ import org.elasticsearch.action.support.IndicesOptions;
/*     */ import org.elasticsearch.action.support.WriteRequest;
/*     */ import org.elasticsearch.client.Client;
/*     */ import org.elasticsearch.client.RestHighLevelClient;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.data.elasticsearch.client.reactive.ReactiveElasticsearchClient;
/*     */ import org.springframework.data.elasticsearch.core.DefaultEntityMapper;
/*     */ import org.springframework.data.elasticsearch.core.DefaultResultMapper;
/*     */ import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
/*     */ import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
/*     */ import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
/*     */ import org.springframework.data.elasticsearch.core.EntityMapper;
/*     */ import org.springframework.data.elasticsearch.core.ReactiveElasticsearchOperations;
/*     */ import org.springframework.data.elasticsearch.core.ReactiveElasticsearchTemplate;
/*     */ import org.springframework.data.elasticsearch.core.ResultsMapper;
/*     */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchConverter;
/*     */ import org.springframework.data.elasticsearch.core.convert.MappingElasticsearchConverter;
/*     */ import org.springframework.data.elasticsearch.core.mapping.SimpleElasticsearchMappingContext;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.web.reactive.function.client.WebClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ElasticsearchDataConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class BaseConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ElasticsearchConverter elasticsearchConverter(SimpleElasticsearchMappingContext mappingContext) {
/*  60 */       return (ElasticsearchConverter)new MappingElasticsearchConverter((MappingContext)mappingContext);
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     SimpleElasticsearchMappingContext mappingContext() {
/*  66 */       return new SimpleElasticsearchMappingContext();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     EntityMapper entityMapper(SimpleElasticsearchMappingContext mappingContext) {
/*  72 */       return (EntityMapper)new DefaultEntityMapper((MappingContext)mappingContext);
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ResultsMapper resultsMapper(SimpleElasticsearchMappingContext mappingContext, EntityMapper entityMapper) {
/*  78 */       return (ResultsMapper)new DefaultResultMapper((MappingContext)mappingContext, entityMapper);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({RestHighLevelClient.class})
/*     */   static class RestClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(value = {ElasticsearchOperations.class}, name = {"elasticsearchTemplate"})
/*     */     @ConditionalOnBean({RestHighLevelClient.class})
/*     */     ElasticsearchRestTemplate elasticsearchTemplate(RestHighLevelClient client, ElasticsearchConverter converter, ResultsMapper resultsMapper) {
/*  92 */       return new ElasticsearchRestTemplate(client, converter, resultsMapper);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Client.class})
/*     */   static class TransportClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(value = {ElasticsearchOperations.class}, name = {"elasticsearchTemplate"})
/*     */     @ConditionalOnBean({Client.class})
/*     */     ElasticsearchTemplate elasticsearchTemplate(Client client, ElasticsearchConverter converter, ResultsMapper resultsMapper) {
/*     */       try {
/* 107 */         return new ElasticsearchTemplate(client, converter, resultsMapper);
/*     */       }
/* 109 */       catch (Exception ex) {
/* 110 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({WebClient.class, ReactiveElasticsearchOperations.class})
/*     */   static class ReactiveRestClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(value = {ReactiveElasticsearchOperations.class}, name = {"reactiveElasticsearchTemplate"})
/*     */     @ConditionalOnBean({ReactiveElasticsearchClient.class})
/*     */     ReactiveElasticsearchTemplate reactiveElasticsearchTemplate(ReactiveElasticsearchClient client, ElasticsearchConverter converter, ResultsMapper resultsMapper) {
/* 125 */       ReactiveElasticsearchTemplate template = new ReactiveElasticsearchTemplate(client, converter, resultsMapper);
/*     */       
/* 127 */       template.setIndicesOptions(IndicesOptions.strictExpandOpenAndForbidClosed());
/* 128 */       template.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
/* 129 */       return template;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchDataConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
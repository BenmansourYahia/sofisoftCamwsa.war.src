/*    */ package org.springframework.boot.autoconfigure.data.cassandra;
/*    */ 
/*    */ import com.datastax.driver.core.Cluster;
/*    */ import com.datastax.driver.core.Session;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.cassandra.ReactiveSession;
/*    */ import org.springframework.data.cassandra.ReactiveSessionFactory;
/*    */ import org.springframework.data.cassandra.core.ReactiveCassandraOperations;
/*    */ import org.springframework.data.cassandra.core.ReactiveCassandraTemplate;
/*    */ import org.springframework.data.cassandra.core.convert.CassandraConverter;
/*    */ import org.springframework.data.cassandra.core.cql.session.DefaultBridgedReactiveSession;
/*    */ import org.springframework.data.cassandra.core.cql.session.DefaultReactiveSessionFactory;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Cluster.class, ReactiveCassandraTemplate.class, Flux.class})
/*    */ @ConditionalOnBean({Session.class})
/*    */ @AutoConfigureAfter({CassandraDataAutoConfiguration.class})
/*    */ public class CassandraReactiveDataAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ReactiveSession reactiveCassandraSession(Session session) {
/* 55 */     return (ReactiveSession)new DefaultBridgedReactiveSession(session);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   public ReactiveSessionFactory reactiveCassandraSessionFactory(ReactiveSession reactiveCassandraSession) {
/* 60 */     return (ReactiveSessionFactory)new DefaultReactiveSessionFactory(reactiveCassandraSession);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({ReactiveCassandraOperations.class})
/*    */   public ReactiveCassandraTemplate reactiveCassandraTemplate(ReactiveSession reactiveCassandraSession, CassandraConverter converter) {
/* 67 */     return new ReactiveCassandraTemplate(reactiveCassandraSession, converter);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\cassandra\CassandraReactiveDataAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.data.mongo;
/*     */ 
/*     */ import com.mongodb.reactivestreams.client.MongoClient;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoReactiveAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.data.convert.CustomConversions;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.mongodb.ReactiveMongoDatabaseFactory;
/*     */ import org.springframework.data.mongodb.core.ReactiveMongoOperations;
/*     */ import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
/*     */ import org.springframework.data.mongodb.core.SimpleReactiveMongoDatabaseFactory;
/*     */ import org.springframework.data.mongodb.core.convert.DbRefResolver;
/*     */ import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
/*     */ import org.springframework.data.mongodb.core.convert.NoOpDbRefResolver;
/*     */ import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
/*     */ import org.springframework.data.mongodb.gridfs.ReactiveGridFsOperations;
/*     */ import org.springframework.data.mongodb.gridfs.ReactiveGridFsTemplate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({MongoClient.class, ReactiveMongoTemplate.class})
/*     */ @ConditionalOnBean({MongoClient.class})
/*     */ @EnableConfigurationProperties({MongoProperties.class})
/*     */ @Import({MongoDataConfiguration.class})
/*     */ @AutoConfigureAfter({MongoReactiveAutoConfiguration.class})
/*     */ public class MongoReactiveDataAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveMongoDatabaseFactory.class})
/*     */   public SimpleReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory(MongoProperties properties, MongoClient mongo) {
/*  72 */     String database = properties.getMongoClientDatabase();
/*  73 */     return new SimpleReactiveMongoDatabaseFactory(mongo, database);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveMongoOperations.class})
/*     */   public ReactiveMongoTemplate reactiveMongoTemplate(ReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory, MongoConverter converter) {
/*  80 */     return new ReactiveMongoTemplate(reactiveMongoDatabaseFactory, converter);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({MongoConverter.class})
/*     */   public MappingMongoConverter mappingMongoConverter(MongoMappingContext context, MongoCustomConversions conversions) {
/*  87 */     MappingMongoConverter mappingConverter = new MappingMongoConverter((DbRefResolver)NoOpDbRefResolver.INSTANCE, (MappingContext)context);
/*  88 */     mappingConverter.setCustomConversions((CustomConversions)conversions);
/*  89 */     return mappingConverter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({DataBufferFactory.class})
/*     */   public DefaultDataBufferFactory dataBufferFactory() {
/*  95 */     return new DefaultDataBufferFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveGridFsOperations.class})
/*     */   public ReactiveGridFsTemplate reactiveGridFsTemplate(ReactiveMongoDatabaseFactory reactiveMongoDbFactory, MappingMongoConverter mappingMongoConverter, DataBufferFactory dataBufferFactory) {
/* 102 */     return new ReactiveGridFsTemplate(dataBufferFactory, reactiveMongoDbFactory, (MongoConverter)mappingMongoConverter, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoReactiveDataAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
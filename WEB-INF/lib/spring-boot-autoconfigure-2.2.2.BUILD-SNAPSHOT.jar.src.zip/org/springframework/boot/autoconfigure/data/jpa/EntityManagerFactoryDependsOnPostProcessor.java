/*    */ package org.springframework.boot.autoconfigure.data.jpa;
/*    */ 
/*    */ import javax.persistence.EntityManagerFactory;
/*    */ import org.springframework.boot.autoconfigure.AbstractDependsOnBeanFactoryPostProcessor;
/*    */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityManagerFactoryDependsOnPostProcessor
/*    */   extends AbstractDependsOnBeanFactoryPostProcessor
/*    */ {
/*    */   public EntityManagerFactoryDependsOnPostProcessor(String... dependsOn) {
/* 46 */     super(EntityManagerFactory.class, AbstractEntityManagerFactoryBean.class, dependsOn);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityManagerFactoryDependsOnPostProcessor(Class<?>... dependsOn) {
/* 56 */     super(EntityManagerFactory.class, AbstractEntityManagerFactoryBean.class, dependsOn);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\jpa\EntityManagerFactoryDependsOnPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
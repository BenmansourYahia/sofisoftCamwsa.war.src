/*    */ package org.springframework.boot.autoconfigure.data.jdbc;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
/*    */ import org.springframework.data.jdbc.repository.config.JdbcRepositoryConfigExtension;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JdbcRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation() {
/* 37 */     return (Class)EnableJdbcRepositories.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> getConfiguration() {
/* 42 */     return EnableJdbcRepositoriesConfiguration.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension() {
/* 47 */     return (RepositoryConfigurationExtension)new JdbcRepositoryConfigExtension();
/*    */   }
/*    */   
/*    */   @EnableJdbcRepositories
/*    */   private static class EnableJdbcRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\jdbc\JdbcRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
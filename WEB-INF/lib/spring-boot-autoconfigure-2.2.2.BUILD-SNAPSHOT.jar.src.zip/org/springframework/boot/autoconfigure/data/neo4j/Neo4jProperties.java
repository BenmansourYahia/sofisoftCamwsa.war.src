/*     */ package org.springframework.boot.autoconfigure.data.neo4j;
/*     */ 
/*     */ import org.neo4j.ogm.config.AutoIndexMode;
/*     */ import org.neo4j.ogm.config.Configuration;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.data.neo4j")
/*     */ public class Neo4jProperties
/*     */   implements ApplicationContextAware
/*     */ {
/*     */   static final String EMBEDDED_DRIVER = "org.neo4j.ogm.drivers.embedded.driver.EmbeddedDriver";
/*     */   static final String HTTP_DRIVER = "org.neo4j.ogm.drivers.http.driver.HttpDriver";
/*     */   static final String DEFAULT_BOLT_URI = "bolt://localhost:7687";
/*     */   static final String BOLT_DRIVER = "org.neo4j.ogm.drivers.bolt.driver.BoltDriver";
/*     */   private String uri;
/*     */   private String username;
/*     */   private String password;
/*  68 */   private AutoIndexMode autoIndex = AutoIndexMode.NONE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean openInView;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useNativeTypes = false;
/*     */ 
/*     */ 
/*     */   
/*  81 */   private final Embedded embedded = new Embedded();
/*     */   
/*  83 */   private ClassLoader classLoader = Neo4jProperties.class.getClassLoader();
/*     */   
/*     */   public String getUri() {
/*  86 */     return this.uri;
/*     */   }
/*     */   
/*     */   public void setUri(String uri) {
/*  90 */     this.uri = uri;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  94 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  98 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 102 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 106 */     this.password = password;
/*     */   }
/*     */   
/*     */   public AutoIndexMode getAutoIndex() {
/* 110 */     return this.autoIndex;
/*     */   }
/*     */   
/*     */   public void setAutoIndex(AutoIndexMode autoIndex) {
/* 114 */     this.autoIndex = autoIndex;
/*     */   }
/*     */   
/*     */   public Boolean getOpenInView() {
/* 118 */     return this.openInView;
/*     */   }
/*     */   
/*     */   public void setOpenInView(Boolean openInView) {
/* 122 */     this.openInView = openInView;
/*     */   }
/*     */   
/*     */   public boolean isUseNativeTypes() {
/* 126 */     return this.useNativeTypes;
/*     */   }
/*     */   
/*     */   public void setUseNativeTypes(boolean useNativeTypes) {
/* 130 */     this.useNativeTypes = useNativeTypes;
/*     */   }
/*     */   
/*     */   public Embedded getEmbedded() {
/* 134 */     return this.embedded;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext ctx) throws BeansException {
/* 139 */     this.classLoader = ctx.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Configuration createConfiguration() {
/* 147 */     Configuration.Builder builder = new Configuration.Builder();
/* 148 */     configure(builder);
/* 149 */     return builder.build();
/*     */   }
/*     */   
/*     */   private void configure(Configuration.Builder builder) {
/* 153 */     if (this.uri != null) {
/* 154 */       builder.uri(this.uri);
/*     */     } else {
/*     */       
/* 157 */       configureUriWithDefaults(builder);
/*     */     } 
/* 159 */     if (this.username != null && this.password != null) {
/* 160 */       builder.credentials(this.username, this.password);
/*     */     }
/* 162 */     builder.autoIndex(getAutoIndex().getName());
/* 163 */     if (this.useNativeTypes) {
/* 164 */       builder.useNativeTypes();
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureUriWithDefaults(Configuration.Builder builder) {
/* 169 */     if (!getEmbedded().isEnabled() || !ClassUtils.isPresent("org.neo4j.ogm.drivers.embedded.driver.EmbeddedDriver", this.classLoader)) {
/* 170 */       builder.uri("bolt://localhost:7687");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Embedded
/*     */   {
/*     */     private boolean enabled = true;
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 182 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 186 */       this.enabled = enabled;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
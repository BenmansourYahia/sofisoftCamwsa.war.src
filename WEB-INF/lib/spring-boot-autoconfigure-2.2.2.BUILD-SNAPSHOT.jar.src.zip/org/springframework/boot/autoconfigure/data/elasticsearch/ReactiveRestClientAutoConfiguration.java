/*    */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.elasticsearch.client.ClientConfiguration;
/*    */ import org.springframework.data.elasticsearch.client.reactive.ReactiveElasticsearchClient;
/*    */ import org.springframework.data.elasticsearch.client.reactive.ReactiveRestClients;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.web.reactive.function.client.WebClient;
/*    */ import reactor.netty.http.client.HttpClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({ReactiveRestClients.class, WebClient.class, HttpClient.class})
/*    */ @EnableConfigurationProperties({ReactiveRestClientProperties.class})
/*    */ public class ReactiveRestClientAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ClientConfiguration clientConfiguration(ReactiveRestClientProperties properties) {
/* 50 */     ClientConfiguration.MaybeSecureClientConfigurationBuilder builder = ClientConfiguration.builder().connectedTo(properties.getEndpoints().<String>toArray(new String[0]));
/* 51 */     if (properties.isUseSsl()) {
/* 52 */       builder.usingSsl();
/*    */     }
/* 54 */     configureTimeouts((ClientConfiguration.TerminalClientConfigurationBuilder)builder, properties);
/* 55 */     return builder.build();
/*    */   }
/*    */ 
/*    */   
/*    */   private void configureTimeouts(ClientConfiguration.TerminalClientConfigurationBuilder builder, ReactiveRestClientProperties properties) {
/* 60 */     PropertyMapper map = PropertyMapper.get();
/* 61 */     map.from(properties.getConnectionTimeout()).whenNonNull().to(builder::withConnectTimeout);
/* 62 */     map.from(properties.getSocketTimeout()).whenNonNull().to(builder::withSocketTimeout);
/* 63 */     map.from(properties.getUsername()).whenHasText().to(username -> {
/*    */           HttpHeaders headers = new HttpHeaders();
/*    */           headers.setBasicAuth(username, properties.getPassword());
/*    */           builder.withDefaultHeaders(headers);
/*    */         });
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ReactiveElasticsearchClient reactiveElasticsearchClient(ClientConfiguration clientConfiguration) {
/* 73 */     return ReactiveRestClients.create(clientConfiguration);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ReactiveRestClientAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
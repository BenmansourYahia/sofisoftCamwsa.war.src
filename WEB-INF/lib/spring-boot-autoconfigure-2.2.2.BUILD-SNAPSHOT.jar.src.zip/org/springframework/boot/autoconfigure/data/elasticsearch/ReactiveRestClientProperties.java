/*     */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.data.elasticsearch.client.reactive")
/*     */ public class ReactiveRestClientProperties
/*     */ {
/*  38 */   private List<String> endpoints = new ArrayList<>(Collections.singletonList("localhost:9200"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useSsl = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String username;
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration connectionTimeout;
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration socketTimeout;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getEndpoints() {
/*  66 */     return this.endpoints;
/*     */   }
/*     */   
/*     */   public void setEndpoints(List<String> endpoints) {
/*  70 */     this.endpoints = endpoints;
/*     */   }
/*     */   
/*     */   public boolean isUseSsl() {
/*  74 */     return this.useSsl;
/*     */   }
/*     */   
/*     */   public void setUseSsl(boolean useSsl) {
/*  78 */     this.useSsl = useSsl;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  82 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  86 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  90 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  94 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Duration getConnectionTimeout() {
/*  98 */     return this.connectionTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(Duration connectionTimeout) {
/* 102 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */   public Duration getSocketTimeout() {
/* 106 */     return this.socketTimeout;
/*     */   }
/*     */   
/*     */   public void setSocketTimeout(Duration socketTimeout) {
/* 110 */     this.socketTimeout = socketTimeout;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ReactiveRestClientProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
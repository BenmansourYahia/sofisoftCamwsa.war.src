/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisNode;
/*     */ import org.springframework.data.redis.connection.RedisPassword;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class RedisConnectionConfiguration
/*     */ {
/*     */   private final RedisProperties properties;
/*     */   private final RedisSentinelConfiguration sentinelConfiguration;
/*     */   private final RedisClusterConfiguration clusterConfiguration;
/*     */   
/*     */   protected RedisConnectionConfiguration(RedisProperties properties, ObjectProvider<RedisSentinelConfiguration> sentinelConfigurationProvider, ObjectProvider<RedisClusterConfiguration> clusterConfigurationProvider) {
/*  51 */     this.properties = properties;
/*  52 */     this.sentinelConfiguration = (RedisSentinelConfiguration)sentinelConfigurationProvider.getIfAvailable();
/*  53 */     this.clusterConfiguration = (RedisClusterConfiguration)clusterConfigurationProvider.getIfAvailable();
/*     */   }
/*     */   
/*     */   protected final RedisStandaloneConfiguration getStandaloneConfig() {
/*  57 */     RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
/*  58 */     if (StringUtils.hasText(this.properties.getUrl())) {
/*  59 */       ConnectionInfo connectionInfo = parseUrl(this.properties.getUrl());
/*  60 */       config.setHostName(connectionInfo.getHostName());
/*  61 */       config.setPort(connectionInfo.getPort());
/*  62 */       config.setPassword(RedisPassword.of(connectionInfo.getPassword()));
/*     */     } else {
/*     */       
/*  65 */       config.setHostName(this.properties.getHost());
/*  66 */       config.setPort(this.properties.getPort());
/*  67 */       config.setPassword(RedisPassword.of(this.properties.getPassword()));
/*     */     } 
/*  69 */     config.setDatabase(this.properties.getDatabase());
/*  70 */     return config;
/*     */   }
/*     */   
/*     */   protected final RedisSentinelConfiguration getSentinelConfig() {
/*  74 */     if (this.sentinelConfiguration != null) {
/*  75 */       return this.sentinelConfiguration;
/*     */     }
/*  77 */     RedisProperties.Sentinel sentinelProperties = this.properties.getSentinel();
/*  78 */     if (sentinelProperties != null) {
/*  79 */       RedisSentinelConfiguration config = new RedisSentinelConfiguration();
/*  80 */       config.master(sentinelProperties.getMaster());
/*  81 */       config.setSentinels(createSentinels(sentinelProperties));
/*  82 */       if (this.properties.getPassword() != null) {
/*  83 */         config.setPassword(RedisPassword.of(this.properties.getPassword()));
/*     */       }
/*  85 */       config.setDatabase(this.properties.getDatabase());
/*  86 */       return config;
/*     */     } 
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final RedisClusterConfiguration getClusterConfiguration() {
/*  96 */     if (this.clusterConfiguration != null) {
/*  97 */       return this.clusterConfiguration;
/*     */     }
/*  99 */     if (this.properties.getCluster() == null) {
/* 100 */       return null;
/*     */     }
/* 102 */     RedisProperties.Cluster clusterProperties = this.properties.getCluster();
/* 103 */     RedisClusterConfiguration config = new RedisClusterConfiguration(clusterProperties.getNodes());
/* 104 */     if (clusterProperties.getMaxRedirects() != null) {
/* 105 */       config.setMaxRedirects(clusterProperties.getMaxRedirects().intValue());
/*     */     }
/* 107 */     if (this.properties.getPassword() != null) {
/* 108 */       config.setPassword(RedisPassword.of(this.properties.getPassword()));
/*     */     }
/* 110 */     return config;
/*     */   }
/*     */   
/*     */   protected final RedisProperties getProperties() {
/* 114 */     return this.properties;
/*     */   }
/*     */   
/*     */   private List<RedisNode> createSentinels(RedisProperties.Sentinel sentinel) {
/* 118 */     List<RedisNode> nodes = new ArrayList<>();
/* 119 */     for (String node : sentinel.getNodes()) {
/*     */       try {
/* 121 */         String[] parts = StringUtils.split(node, ":");
/* 122 */         Assert.state((parts.length == 2), "Must be defined as 'host:port'");
/* 123 */         nodes.add(new RedisNode(parts[0], Integer.valueOf(parts[1]).intValue()));
/*     */       }
/* 125 */       catch (RuntimeException ex) {
/* 126 */         throw new IllegalStateException("Invalid redis sentinel property '" + node + "'", ex);
/*     */       } 
/*     */     } 
/* 129 */     return nodes;
/*     */   }
/*     */   
/*     */   protected ConnectionInfo parseUrl(String url) {
/*     */     try {
/* 134 */       URI uri = new URI(url);
/* 135 */       boolean useSsl = url.startsWith("rediss://");
/* 136 */       String password = null;
/* 137 */       if (uri.getUserInfo() != null) {
/* 138 */         password = uri.getUserInfo();
/* 139 */         int index = password.indexOf(':');
/* 140 */         if (index >= 0) {
/* 141 */           password = password.substring(index + 1);
/*     */         }
/*     */       } 
/* 144 */       return new ConnectionInfo(uri, useSsl, password);
/*     */     }
/* 146 */     catch (URISyntaxException ex) {
/* 147 */       throw new IllegalArgumentException("Malformed url '" + url + "'", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static class ConnectionInfo
/*     */   {
/*     */     private final URI uri;
/*     */     
/*     */     private final boolean useSsl;
/*     */     private final String password;
/*     */     
/*     */     ConnectionInfo(URI uri, boolean useSsl, String password) {
/* 160 */       this.uri = uri;
/* 161 */       this.useSsl = useSsl;
/* 162 */       this.password = password;
/*     */     }
/*     */     
/*     */     boolean isUseSsl() {
/* 166 */       return this.useSsl;
/*     */     }
/*     */     
/*     */     String getHostName() {
/* 170 */       return this.uri.getHost();
/*     */     }
/*     */     
/*     */     int getPort() {
/* 174 */       return this.uri.getPort();
/*     */     }
/*     */     
/*     */     String getPassword() {
/* 178 */       return this.password;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\redis\RedisConnectionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
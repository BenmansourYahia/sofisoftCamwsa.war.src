/*     */ package org.springframework.boot.autoconfigure.data.rest;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
/*     */ import org.springframework.data.rest.core.mapping.RepositoryDetectionStrategy;
/*     */ import org.springframework.http.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.data.rest")
/*     */ public class RepositoryRestProperties
/*     */ {
/*     */   private String basePath;
/*     */   private Integer defaultPageSize;
/*     */   private Integer maxPageSize;
/*     */   private String pageParamName;
/*     */   private String limitParamName;
/*     */   private String sortParamName;
/*  69 */   private RepositoryDetectionStrategy.RepositoryDetectionStrategies detectionStrategy = RepositoryDetectionStrategy.RepositoryDetectionStrategies.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MediaType defaultMediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean returnBodyOnCreate;
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean returnBodyOnUpdate;
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean enableEnumTranslation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBasePath() {
/*  93 */     return this.basePath;
/*     */   }
/*     */   
/*     */   public void setBasePath(String basePath) {
/*  97 */     this.basePath = basePath;
/*     */   }
/*     */   
/*     */   public Integer getDefaultPageSize() {
/* 101 */     return this.defaultPageSize;
/*     */   }
/*     */   
/*     */   public void setDefaultPageSize(Integer defaultPageSize) {
/* 105 */     this.defaultPageSize = defaultPageSize;
/*     */   }
/*     */   
/*     */   public Integer getMaxPageSize() {
/* 109 */     return this.maxPageSize;
/*     */   }
/*     */   
/*     */   public void setMaxPageSize(Integer maxPageSize) {
/* 113 */     this.maxPageSize = maxPageSize;
/*     */   }
/*     */   
/*     */   public String getPageParamName() {
/* 117 */     return this.pageParamName;
/*     */   }
/*     */   
/*     */   public void setPageParamName(String pageParamName) {
/* 121 */     this.pageParamName = pageParamName;
/*     */   }
/*     */   
/*     */   public String getLimitParamName() {
/* 125 */     return this.limitParamName;
/*     */   }
/*     */   
/*     */   public void setLimitParamName(String limitParamName) {
/* 129 */     this.limitParamName = limitParamName;
/*     */   }
/*     */   
/*     */   public String getSortParamName() {
/* 133 */     return this.sortParamName;
/*     */   }
/*     */   
/*     */   public void setSortParamName(String sortParamName) {
/* 137 */     this.sortParamName = sortParamName;
/*     */   }
/*     */   
/*     */   public RepositoryDetectionStrategy.RepositoryDetectionStrategies getDetectionStrategy() {
/* 141 */     return this.detectionStrategy;
/*     */   }
/*     */   
/*     */   public void setDetectionStrategy(RepositoryDetectionStrategy.RepositoryDetectionStrategies detectionStrategy) {
/* 145 */     this.detectionStrategy = detectionStrategy;
/*     */   }
/*     */   
/*     */   public MediaType getDefaultMediaType() {
/* 149 */     return this.defaultMediaType;
/*     */   }
/*     */   
/*     */   public void setDefaultMediaType(MediaType defaultMediaType) {
/* 153 */     this.defaultMediaType = defaultMediaType;
/*     */   }
/*     */   
/*     */   public Boolean getReturnBodyOnCreate() {
/* 157 */     return this.returnBodyOnCreate;
/*     */   }
/*     */   
/*     */   public void setReturnBodyOnCreate(Boolean returnBodyOnCreate) {
/* 161 */     this.returnBodyOnCreate = returnBodyOnCreate;
/*     */   }
/*     */   
/*     */   public Boolean getReturnBodyOnUpdate() {
/* 165 */     return this.returnBodyOnUpdate;
/*     */   }
/*     */   
/*     */   public void setReturnBodyOnUpdate(Boolean returnBodyOnUpdate) {
/* 169 */     this.returnBodyOnUpdate = returnBodyOnUpdate;
/*     */   }
/*     */   
/*     */   public Boolean getEnableEnumTranslation() {
/* 173 */     return this.enableEnumTranslation;
/*     */   }
/*     */   
/*     */   public void setEnableEnumTranslation(Boolean enableEnumTranslation) {
/* 177 */     this.enableEnumTranslation = enableEnumTranslation;
/*     */   }
/*     */   
/*     */   public void applyTo(RepositoryRestConfiguration rest) {
/* 181 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 182 */     map.from(this::getBasePath).to(rest::setBasePath);
/* 183 */     map.from(this::getDefaultPageSize).to(rest::setDefaultPageSize);
/* 184 */     map.from(this::getMaxPageSize).to(rest::setMaxPageSize);
/* 185 */     map.from(this::getPageParamName).to(rest::setPageParamName);
/* 186 */     map.from(this::getLimitParamName).to(rest::setLimitParamName);
/* 187 */     map.from(this::getSortParamName).to(rest::setSortParamName);
/* 188 */     map.from(this::getDetectionStrategy).to(rest::setRepositoryDetectionStrategy);
/* 189 */     map.from(this::getDefaultMediaType).to(rest::setDefaultMediaType);
/* 190 */     map.from(this::getReturnBodyOnCreate).to(rest::setReturnBodyOnCreate);
/* 191 */     map.from(this::getReturnBodyOnUpdate).to(rest::setReturnBodyOnUpdate);
/* 192 */     map.from(this::getEnableEnumTranslation).to(rest::setEnableEnumTranslation);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\rest\RepositoryRestProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
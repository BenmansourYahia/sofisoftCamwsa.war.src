/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import com.mongodb.MongoClient;
/*    */ import com.mongodb.client.MongoClient;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.data.mongodb.MongoDbFactory;
/*    */ import org.springframework.data.mongodb.core.MongoDbFactorySupport;
/*    */ import org.springframework.data.mongodb.core.SimpleMongoClientDbFactory;
/*    */ import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnMissingBean({MongoDbFactory.class})
/*    */ @Conditional({MongoDbFactoryConfiguration.AnyMongoClientAvailable.class})
/*    */ class MongoDbFactoryConfiguration
/*    */ {
/*    */   @Bean
/*    */   MongoDbFactorySupport<?> mongoDbFactory(ObjectProvider<MongoClient> mongo, ObjectProvider<MongoClient> mongoClient, MongoProperties properties) {
/* 48 */     MongoClient preferredClient = (MongoClient)mongo.getIfAvailable();
/* 49 */     if (preferredClient != null) {
/* 50 */       return (MongoDbFactorySupport<?>)new SimpleMongoDbFactory(preferredClient, properties.getMongoClientDatabase());
/*    */     }
/* 52 */     MongoClient fallbackClient = (MongoClient)mongoClient.getIfAvailable();
/* 53 */     if (fallbackClient != null) {
/* 54 */       return (MongoDbFactorySupport<?>)new SimpleMongoClientDbFactory(fallbackClient, properties.getMongoClientDatabase());
/*    */     }
/* 56 */     throw new IllegalStateException("Expected to find at least one MongoDB client.");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static class AnyMongoClientAvailable
/*    */     extends AnyNestedCondition
/*    */   {
/*    */     AnyMongoClientAvailable() {
/* 67 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */     }
/*    */     
/*    */     @ConditionalOnBean({MongoClient.class})
/*    */     static class PreferredClientAvailable {}
/*    */     
/*    */     @ConditionalOnBean({MongoClient.class})
/*    */     static class FallbackClientAvailable {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDbFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
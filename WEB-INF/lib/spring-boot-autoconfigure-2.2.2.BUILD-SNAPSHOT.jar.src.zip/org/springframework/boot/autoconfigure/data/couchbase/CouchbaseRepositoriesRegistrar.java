/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.data.couchbase.repository.config.CouchbaseRepositoryConfigurationExtension;
/*    */ import org.springframework.data.couchbase.repository.config.EnableCouchbaseRepositories;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CouchbaseRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation() {
/* 37 */     return (Class)EnableCouchbaseRepositories.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> getConfiguration() {
/* 42 */     return EnableCouchbaseRepositoriesConfiguration.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension() {
/* 47 */     return (RepositoryConfigurationExtension)new CouchbaseRepositoryConfigurationExtension();
/*    */   }
/*    */   
/*    */   @EnableCouchbaseRepositories
/*    */   private static class EnableCouchbaseRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
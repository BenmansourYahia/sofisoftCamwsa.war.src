/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import com.mongodb.MongoClient;
/*    */ import org.springframework.boot.autoconfigure.AbstractDependsOnBeanFactoryPostProcessor;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.data.mongodb.core.MongoClientFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147483647)
/*    */ public class MongoClientDependsOnBeanFactoryPostProcessor
/*    */   extends AbstractDependsOnBeanFactoryPostProcessor
/*    */ {
/*    */   @Deprecated
/*    */   public MongoClientDependsOnBeanFactoryPostProcessor(String... dependsOn) {
/* 48 */     super(MongoClient.class, MongoClientFactoryBean.class, dependsOn);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MongoClientDependsOnBeanFactoryPostProcessor(Class<?>... dependsOn) {
/* 57 */     super(MongoClient.class, MongoClientFactoryBean.class, dependsOn);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoClientDependsOnBeanFactoryPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
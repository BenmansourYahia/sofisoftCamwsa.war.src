/*    */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.data.elasticsearch.repository.config.ElasticsearchRepositoryConfigExtension;
/*    */ import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ElasticsearchRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation() {
/* 38 */     return (Class)EnableElasticsearchRepositories.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> getConfiguration() {
/* 43 */     return EnableElasticsearchRepositoriesConfiguration.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension() {
/* 48 */     return (RepositoryConfigurationExtension)new ElasticsearchRepositoryConfigExtension();
/*    */   }
/*    */   
/*    */   @EnableElasticsearchRepositories
/*    */   private static class EnableElasticsearchRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.data.jpa;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryBuilderCustomizer;
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
/*    */ import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.core.task.AsyncTaskExecutor;
/*    */ import org.springframework.data.jpa.repository.JpaRepository;
/*    */ import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;
/*    */ import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnBean({DataSource.class})
/*    */ @ConditionalOnClass({JpaRepository.class})
/*    */ @ConditionalOnMissingBean({JpaRepositoryFactoryBean.class, JpaRepositoryConfigExtension.class})
/*    */ @ConditionalOnProperty(prefix = "spring.data.jpa.repositories", name = {"enabled"}, havingValue = "true", matchIfMissing = true)
/*    */ @Import({JpaRepositoriesRegistrar.class})
/*    */ @AutoConfigureAfter({HibernateJpaAutoConfiguration.class, TaskExecutionAutoConfiguration.class})
/*    */ public class JpaRepositoriesAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Conditional({BootstrapExecutorCondition.class})
/*    */   public EntityManagerFactoryBuilderCustomizer entityManagerFactoryBootstrapExecutorCustomizer(Map<String, AsyncTaskExecutor> taskExecutors) {
/* 76 */     return builder -> {
/*    */         AsyncTaskExecutor bootstrapExecutor = determineBootstrapExecutor(taskExecutors);
/*    */         if (bootstrapExecutor != null) {
/*    */           builder.setBootstrapExecutor(bootstrapExecutor);
/*    */         }
/*    */       };
/*    */   }
/*    */   
/*    */   private AsyncTaskExecutor determineBootstrapExecutor(Map<String, AsyncTaskExecutor> taskExecutors) {
/* 85 */     if (taskExecutors.size() == 1) {
/* 86 */       return taskExecutors.values().iterator().next();
/*    */     }
/* 88 */     return taskExecutors.get("applicationTaskExecutor");
/*    */   }
/*    */   
/*    */   private static final class BootstrapExecutorCondition
/*    */     extends AnyNestedCondition {
/*    */     BootstrapExecutorCondition() {
/* 94 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */     }
/*    */     
/*    */     @ConditionalOnProperty(prefix = "spring.data.jpa.repositories", name = {"bootstrap-mode"}, havingValue = "deferred", matchIfMissing = false)
/*    */     static class DeferredBootstrapMode {}
/*    */     
/*    */     @ConditionalOnProperty(prefix = "spring.data.jpa.repositories", name = {"bootstrap-mode"}, havingValue = "lazy", matchIfMissing = false)
/*    */     static class LazyBootstrapMode {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\jpa\JpaRepositoriesAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
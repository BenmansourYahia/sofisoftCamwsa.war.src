/*    */ package org.springframework.boot.autoconfigure.data.solr;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ import org.springframework.data.solr.repository.config.EnableSolrRepositories;
/*    */ import org.springframework.data.solr.repository.config.SolrRepositoryConfigExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SolrRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation() {
/* 37 */     return (Class)EnableSolrRepositories.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> getConfiguration() {
/* 42 */     return EnableSolrRepositoriesConfiguration.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension() {
/* 47 */     return (RepositoryConfigurationExtension)new SolrRepositoryConfigExtension();
/*    */   }
/*    */   
/*    */   @EnableSolrRepositories
/*    */   private static class EnableSolrRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\solr\SolrRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
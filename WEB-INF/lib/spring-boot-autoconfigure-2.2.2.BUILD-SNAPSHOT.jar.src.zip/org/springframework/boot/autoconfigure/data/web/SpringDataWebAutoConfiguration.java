/*    */ package org.springframework.boot.autoconfigure.data.web;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.domain.PageRequest;
/*    */ import org.springframework.data.domain.Pageable;
/*    */ import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
/*    */ import org.springframework.data.web.SortHandlerMethodArgumentResolver;
/*    */ import org.springframework.data.web.config.EnableSpringDataWebSupport;
/*    */ import org.springframework.data.web.config.PageableHandlerMethodArgumentResolverCustomizer;
/*    */ import org.springframework.data.web.config.SortHandlerMethodArgumentResolverCustomizer;
/*    */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @EnableSpringDataWebSupport
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnClass({PageableHandlerMethodArgumentResolver.class, WebMvcConfigurer.class})
/*    */ @ConditionalOnMissingBean({PageableHandlerMethodArgumentResolver.class})
/*    */ @EnableConfigurationProperties({SpringDataWebProperties.class})
/*    */ @AutoConfigureAfter({RepositoryRestMvcAutoConfiguration.class})
/*    */ public class SpringDataWebAutoConfiguration
/*    */ {
/*    */   private final SpringDataWebProperties properties;
/*    */   
/*    */   public SpringDataWebAutoConfiguration(SpringDataWebProperties properties) {
/* 60 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public PageableHandlerMethodArgumentResolverCustomizer pageableCustomizer() {
/* 66 */     return resolver -> {
/*    */         SpringDataWebProperties.Pageable pageable = this.properties.getPageable();
/*    */         resolver.setPageParameterName(pageable.getPageParameter());
/*    */         resolver.setSizeParameterName(pageable.getSizeParameter());
/*    */         resolver.setOneIndexedParameters(pageable.isOneIndexedParameters());
/*    */         resolver.setPrefix(pageable.getPrefix());
/*    */         resolver.setQualifierDelimiter(pageable.getQualifierDelimiter());
/*    */         resolver.setFallbackPageable((Pageable)PageRequest.of(0, pageable.getDefaultPageSize()));
/*    */         resolver.setMaxPageSize(pageable.getMaxPageSize());
/*    */       };
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SortHandlerMethodArgumentResolverCustomizer sortCustomizer() {
/* 81 */     return resolver -> resolver.setSortParameter(this.properties.getSort().getSortParameter());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\web\SpringDataWebAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
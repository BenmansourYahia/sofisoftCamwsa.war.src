/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import io.lettuce.core.RedisClient;
/*     */ import io.lettuce.core.resource.ClientResources;
/*     */ import io.lettuce.core.resource.DefaultClientResources;
/*     */ import java.net.UnknownHostException;
/*     */ import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
/*     */ import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
/*     */ import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({RedisClient.class})
/*     */ class LettuceConnectionConfiguration
/*     */   extends RedisConnectionConfiguration
/*     */ {
/*     */   LettuceConnectionConfiguration(RedisProperties properties, ObjectProvider<RedisSentinelConfiguration> sentinelConfigurationProvider, ObjectProvider<RedisClusterConfiguration> clusterConfigurationProvider) {
/*  54 */     super(properties, sentinelConfigurationProvider, clusterConfigurationProvider);
/*     */   }
/*     */   
/*     */   @Bean(destroyMethod = "shutdown")
/*     */   @ConditionalOnMissingBean({ClientResources.class})
/*     */   DefaultClientResources lettuceClientResources() {
/*  60 */     return DefaultClientResources.create();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({RedisConnectionFactory.class})
/*     */   LettuceConnectionFactory redisConnectionFactory(ObjectProvider<LettuceClientConfigurationBuilderCustomizer> builderCustomizers, ClientResources clientResources) throws UnknownHostException {
/*  68 */     LettuceClientConfiguration clientConfig = getLettuceClientConfiguration(builderCustomizers, clientResources, 
/*  69 */         getProperties().getLettuce().getPool());
/*  70 */     return createLettuceConnectionFactory(clientConfig);
/*     */   }
/*     */   
/*     */   private LettuceConnectionFactory createLettuceConnectionFactory(LettuceClientConfiguration clientConfiguration) {
/*  74 */     if (getSentinelConfig() != null) {
/*  75 */       return new LettuceConnectionFactory(getSentinelConfig(), clientConfiguration);
/*     */     }
/*  77 */     if (getClusterConfiguration() != null) {
/*  78 */       return new LettuceConnectionFactory(getClusterConfiguration(), clientConfiguration);
/*     */     }
/*  80 */     return new LettuceConnectionFactory(getStandaloneConfig(), clientConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private LettuceClientConfiguration getLettuceClientConfiguration(ObjectProvider<LettuceClientConfigurationBuilderCustomizer> builderCustomizers, ClientResources clientResources, RedisProperties.Pool pool) {
/*  86 */     LettuceClientConfiguration.LettuceClientConfigurationBuilder builder = createBuilder(pool);
/*  87 */     applyProperties(builder);
/*  88 */     if (StringUtils.hasText(getProperties().getUrl())) {
/*  89 */       customizeConfigurationFromUrl(builder);
/*     */     }
/*  91 */     builder.clientResources(clientResources);
/*  92 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/*  93 */     return builder.build();
/*     */   }
/*     */   
/*     */   private LettuceClientConfiguration.LettuceClientConfigurationBuilder createBuilder(RedisProperties.Pool pool) {
/*  97 */     if (pool == null) {
/*  98 */       return LettuceClientConfiguration.builder();
/*     */     }
/* 100 */     return (new PoolBuilderFactory()).createBuilder(pool);
/*     */   }
/*     */ 
/*     */   
/*     */   private LettuceClientConfiguration.LettuceClientConfigurationBuilder applyProperties(LettuceClientConfiguration.LettuceClientConfigurationBuilder builder) {
/* 105 */     if (getProperties().isSsl()) {
/* 106 */       builder.useSsl();
/*     */     }
/* 108 */     if (getProperties().getTimeout() != null) {
/* 109 */       builder.commandTimeout(getProperties().getTimeout());
/*     */     }
/* 111 */     if (getProperties().getLettuce() != null) {
/* 112 */       RedisProperties.Lettuce lettuce = getProperties().getLettuce();
/* 113 */       if (lettuce.getShutdownTimeout() != null && !lettuce.getShutdownTimeout().isZero()) {
/* 114 */         builder.shutdownTimeout(getProperties().getLettuce().getShutdownTimeout());
/*     */       }
/*     */     } 
/* 117 */     if (StringUtils.hasText(getProperties().getClientName())) {
/* 118 */       builder.clientName(getProperties().getClientName());
/*     */     }
/* 120 */     return builder;
/*     */   }
/*     */   
/*     */   private void customizeConfigurationFromUrl(LettuceClientConfiguration.LettuceClientConfigurationBuilder builder) {
/* 124 */     RedisConnectionConfiguration.ConnectionInfo connectionInfo = parseUrl(getProperties().getUrl());
/* 125 */     if (connectionInfo.isUseSsl()) {
/* 126 */       builder.useSsl();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PoolBuilderFactory
/*     */   {
/*     */     private PoolBuilderFactory() {}
/*     */     
/*     */     LettuceClientConfiguration.LettuceClientConfigurationBuilder createBuilder(RedisProperties.Pool properties) {
/* 136 */       return (LettuceClientConfiguration.LettuceClientConfigurationBuilder)LettucePoolingClientConfiguration.builder().poolConfig(getPoolConfig(properties));
/*     */     }
/*     */     
/*     */     private GenericObjectPoolConfig<?> getPoolConfig(RedisProperties.Pool properties) {
/* 140 */       GenericObjectPoolConfig<?> config = new GenericObjectPoolConfig();
/* 141 */       config.setMaxTotal(properties.getMaxActive());
/* 142 */       config.setMaxIdle(properties.getMaxIdle());
/* 143 */       config.setMinIdle(properties.getMinIdle());
/* 144 */       if (properties.getTimeBetweenEvictionRuns() != null) {
/* 145 */         config.setTimeBetweenEvictionRunsMillis(properties.getTimeBetweenEvictionRuns().toMillis());
/*     */       }
/* 147 */       if (properties.getMaxWait() != null) {
/* 148 */         config.setMaxWaitMillis(properties.getMaxWait().toMillis());
/*     */       }
/* 150 */       return config;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\redis\LettuceConnectionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
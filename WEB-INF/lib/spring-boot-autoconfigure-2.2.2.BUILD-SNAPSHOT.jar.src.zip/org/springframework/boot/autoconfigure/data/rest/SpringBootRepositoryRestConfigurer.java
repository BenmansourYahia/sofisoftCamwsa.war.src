/*    */ package org.springframework.boot.autoconfigure.data.rest;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
/*    */ import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(0)
/*    */ class SpringBootRepositoryRestConfigurer
/*    */   implements RepositoryRestConfigurer
/*    */ {
/*    */   @Autowired(required = false)
/*    */   private Jackson2ObjectMapperBuilder objectMapperBuilder;
/*    */   @Autowired
/*    */   private RepositoryRestProperties properties;
/*    */   
/*    */   public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config) {
/* 47 */     this.properties.applyTo(config);
/*    */   }
/*    */ 
/*    */   
/*    */   public void configureJacksonObjectMapper(ObjectMapper objectMapper) {
/* 52 */     if (this.objectMapperBuilder != null)
/* 53 */       this.objectMapperBuilder.configure(objectMapper); 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\rest\SpringBootRepositoryRestConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.data.neo4j;
/*    */ 
/*    */ import com.github.benmanes.caffeine.cache.Caffeine;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnNotWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.cache.caffeine.CaffeineCacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Scope;
/*    */ import org.springframework.context.annotation.ScopedProxyMode;
/*    */ import org.springframework.data.neo4j.bookmark.BeanFactoryBookmarkOperationAdvisor;
/*    */ import org.springframework.data.neo4j.bookmark.BookmarkInterceptor;
/*    */ import org.springframework.data.neo4j.bookmark.BookmarkManager;
/*    */ import org.springframework.data.neo4j.bookmark.CaffeineBookmarkManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Caffeine.class, CaffeineCacheManager.class})
/*    */ @ConditionalOnMissingBean({BookmarkManager.class})
/*    */ @ConditionalOnBean({BeanFactoryBookmarkOperationAdvisor.class, BookmarkInterceptor.class})
/*    */ class Neo4jBookmarkManagementConfiguration
/*    */ {
/*    */   private static final String BOOKMARK_MANAGER_BEAN_NAME = "bookmarkManager";
/*    */   
/*    */   @Bean({"bookmarkManager"})
/*    */   @ConditionalOnWebApplication
/*    */   @Scope(value = "request", proxyMode = ScopedProxyMode.INTERFACES)
/*    */   BookmarkManager requestScopedBookmarkManager() {
/* 56 */     return (BookmarkManager)new CaffeineBookmarkManager();
/*    */   }
/*    */   
/*    */   @Bean({"bookmarkManager"})
/*    */   @ConditionalOnNotWebApplication
/*    */   BookmarkManager singletonScopedBookmarkManager() {
/* 62 */     return (BookmarkManager)new CaffeineBookmarkManager();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jBookmarkManagementConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.net.UnknownHostException;
/*     */ import java.time.Duration;
/*     */ import org.apache.commons.pool2.impl.GenericObjectPool;
/*     */ import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
/*     */ import org.springframework.data.redis.connection.jedis.JedisConnection;
/*     */ import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ import redis.clients.jedis.Jedis;
/*     */ import redis.clients.jedis.JedisPoolConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({GenericObjectPool.class, JedisConnection.class, Jedis.class})
/*     */ class JedisConnectionConfiguration
/*     */   extends RedisConnectionConfiguration
/*     */ {
/*     */   JedisConnectionConfiguration(RedisProperties properties, ObjectProvider<RedisSentinelConfiguration> sentinelConfiguration, ObjectProvider<RedisClusterConfiguration> clusterConfiguration) {
/*  53 */     super(properties, sentinelConfiguration, clusterConfiguration);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({RedisConnectionFactory.class})
/*     */   JedisConnectionFactory redisConnectionFactory(ObjectProvider<JedisClientConfigurationBuilderCustomizer> builderCustomizers) throws UnknownHostException {
/*  60 */     return createJedisConnectionFactory(builderCustomizers);
/*     */   }
/*     */ 
/*     */   
/*     */   private JedisConnectionFactory createJedisConnectionFactory(ObjectProvider<JedisClientConfigurationBuilderCustomizer> builderCustomizers) {
/*  65 */     JedisClientConfiguration clientConfiguration = getJedisClientConfiguration(builderCustomizers);
/*  66 */     if (getSentinelConfig() != null) {
/*  67 */       return new JedisConnectionFactory(getSentinelConfig(), clientConfiguration);
/*     */     }
/*  69 */     if (getClusterConfiguration() != null) {
/*  70 */       return new JedisConnectionFactory(getClusterConfiguration(), clientConfiguration);
/*     */     }
/*  72 */     return new JedisConnectionFactory(getStandaloneConfig(), clientConfiguration);
/*     */   }
/*     */ 
/*     */   
/*     */   private JedisClientConfiguration getJedisClientConfiguration(ObjectProvider<JedisClientConfigurationBuilderCustomizer> builderCustomizers) {
/*  77 */     JedisClientConfiguration.JedisClientConfigurationBuilder builder = applyProperties(JedisClientConfiguration.builder());
/*  78 */     RedisProperties.Pool pool = getProperties().getJedis().getPool();
/*  79 */     if (pool != null) {
/*  80 */       applyPooling(pool, builder);
/*     */     }
/*  82 */     if (StringUtils.hasText(getProperties().getUrl())) {
/*  83 */       customizeConfigurationFromUrl(builder);
/*     */     }
/*  85 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/*  86 */     return builder.build();
/*     */   }
/*     */   
/*     */   private JedisClientConfiguration.JedisClientConfigurationBuilder applyProperties(JedisClientConfiguration.JedisClientConfigurationBuilder builder) {
/*  90 */     if (getProperties().isSsl()) {
/*  91 */       builder.useSsl();
/*     */     }
/*  93 */     if (getProperties().getTimeout() != null) {
/*  94 */       Duration timeout = getProperties().getTimeout();
/*  95 */       builder.readTimeout(timeout).connectTimeout(timeout);
/*     */     } 
/*  97 */     if (StringUtils.hasText(getProperties().getClientName())) {
/*  98 */       builder.clientName(getProperties().getClientName());
/*     */     }
/* 100 */     return builder;
/*     */   }
/*     */ 
/*     */   
/*     */   private void applyPooling(RedisProperties.Pool pool, JedisClientConfiguration.JedisClientConfigurationBuilder builder) {
/* 105 */     builder.usePooling().poolConfig((GenericObjectPoolConfig)jedisPoolConfig(pool));
/*     */   }
/*     */   
/*     */   private JedisPoolConfig jedisPoolConfig(RedisProperties.Pool pool) {
/* 109 */     JedisPoolConfig config = new JedisPoolConfig();
/* 110 */     config.setMaxTotal(pool.getMaxActive());
/* 111 */     config.setMaxIdle(pool.getMaxIdle());
/* 112 */     config.setMinIdle(pool.getMinIdle());
/* 113 */     if (pool.getTimeBetweenEvictionRuns() != null) {
/* 114 */       config.setTimeBetweenEvictionRunsMillis(pool.getTimeBetweenEvictionRuns().toMillis());
/*     */     }
/* 116 */     if (pool.getMaxWait() != null) {
/* 117 */       config.setMaxWaitMillis(pool.getMaxWait().toMillis());
/*     */     }
/* 119 */     return config;
/*     */   }
/*     */   
/*     */   private void customizeConfigurationFromUrl(JedisClientConfiguration.JedisClientConfigurationBuilder builder) {
/* 123 */     RedisConnectionConfiguration.ConnectionInfo connectionInfo = parseUrl(getProperties().getUrl());
/* 124 */     if (connectionInfo.isUseSsl())
/* 125 */       builder.useSsl(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\redis\JedisConnectionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import com.couchbase.client.java.env.CouchbaseEnvironment;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.couchbase.CouchbaseConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.couchbase.config.CouchbaseConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({CouchbaseConfigurer.class})
/*    */ @ConditionalOnBean({CouchbaseConfiguration.class})
/*    */ class CouchbaseConfigurerAdapterConfiguration
/*    */ {
/*    */   private final CouchbaseConfiguration configuration;
/*    */   
/*    */   CouchbaseConfigurerAdapterConfiguration(CouchbaseConfiguration configuration) {
/* 41 */     this.configuration = configuration;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   CouchbaseConfigurer springBootCouchbaseConfigurer() throws Exception {
/* 47 */     return new SpringBootCouchbaseConfigurer((CouchbaseEnvironment)this.configuration.couchbaseEnvironment(), this.configuration
/* 48 */         .couchbaseCluster(), this.configuration.couchbaseClusterInfo(), this.configuration
/* 49 */         .couchbaseClient());
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseConfigurerAdapterConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
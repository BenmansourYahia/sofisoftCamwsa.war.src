/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Import({DataSourceInitializerInvoker.class, DataSourceInitializationConfiguration.Registrar.class})
/*    */ class DataSourceInitializationConfiguration
/*    */ {
/*    */   static class Registrar
/*    */     implements ImportBeanDefinitionRegistrar
/*    */   {
/*    */     private static final String BEAN_NAME = "dataSourceInitializerPostProcessor";
/*    */     
/*    */     public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 48 */       if (!registry.containsBeanDefinition("dataSourceInitializerPostProcessor")) {
/* 49 */         GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 50 */         beanDefinition.setBeanClass(DataSourceInitializerPostProcessor.class);
/* 51 */         beanDefinition.setRole(2);
/*    */ 
/*    */         
/* 54 */         beanDefinition.setSynthetic(true);
/* 55 */         registry.registerBeanDefinition("dataSourceInitializerPostProcessor", (BeanDefinition)beanDefinition);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceInitializationConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
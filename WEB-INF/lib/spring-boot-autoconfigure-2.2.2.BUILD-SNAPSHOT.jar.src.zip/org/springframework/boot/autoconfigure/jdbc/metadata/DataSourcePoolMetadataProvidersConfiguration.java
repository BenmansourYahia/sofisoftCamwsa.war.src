/*    */ package org.springframework.boot.autoconfigure.jdbc.metadata;
/*    */ 
/*    */ import com.zaxxer.hikari.HikariDataSource;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.dbcp2.BasicDataSource;
/*    */ import org.apache.tomcat.jdbc.pool.DataSource;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.jdbc.DataSourceUnwrapper;
/*    */ import org.springframework.boot.jdbc.metadata.CommonsDbcp2DataSourcePoolMetadata;
/*    */ import org.springframework.boot.jdbc.metadata.DataSourcePoolMetadata;
/*    */ import org.springframework.boot.jdbc.metadata.DataSourcePoolMetadataProvider;
/*    */ import org.springframework.boot.jdbc.metadata.HikariDataSourcePoolMetadata;
/*    */ import org.springframework.boot.jdbc.metadata.TomcatDataSourcePoolMetadata;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ public class DataSourcePoolMetadataProvidersConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({DataSource.class})
/*    */   static class TomcatDataSourcePoolMetadataProviderConfiguration
/*    */   {
/*    */     @Bean
/*    */     DataSourcePoolMetadataProvider tomcatPoolDataSourceMetadataProvider() {
/* 47 */       return dataSource -> {
/*    */           DataSource tomcatDataSource = (DataSource)DataSourceUnwrapper.unwrap(dataSource, DataSource.class);
/*    */           return (DataSourcePoolMetadata)((tomcatDataSource != null) ? new TomcatDataSourcePoolMetadata(tomcatDataSource) : null);
/*    */         };
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({HikariDataSource.class})
/*    */   static class HikariPoolDataSourceMetadataProviderConfiguration
/*    */   {
/*    */     @Bean
/*    */     DataSourcePoolMetadataProvider hikariPoolDataSourceMetadataProvider() {
/* 65 */       return dataSource -> {
/*    */           HikariDataSource hikariDataSource = (HikariDataSource)DataSourceUnwrapper.unwrap(dataSource, HikariDataSource.class);
/*    */           return (DataSourcePoolMetadata)((hikariDataSource != null) ? new HikariDataSourcePoolMetadata(hikariDataSource) : null);
/*    */         };
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({BasicDataSource.class})
/*    */   static class CommonsDbcp2PoolDataSourceMetadataProviderConfiguration
/*    */   {
/*    */     @Bean
/*    */     DataSourcePoolMetadataProvider commonsDbcp2PoolDataSourceMetadataProvider() {
/* 82 */       return dataSource -> {
/*    */           BasicDataSource dbcpDataSource = (BasicDataSource)DataSourceUnwrapper.unwrap(dataSource, BasicDataSource.class);
/*    */           return (DataSourcePoolMetadata)((dbcpDataSource != null) ? new CommonsDbcp2DataSourcePoolMetadata(dbcpDataSource) : null);
/*    */         };
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\metadata\DataSourcePoolMetadataProvidersConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
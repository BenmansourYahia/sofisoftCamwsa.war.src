/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import com.zaxxer.hikari.HikariDataSource;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.dbcp2.BasicDataSource;
/*     */ import org.apache.tomcat.jdbc.pool.DataSource;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DataSourceConfiguration
/*     */ {
/*     */   protected static <T> T createDataSource(DataSourceProperties properties, Class<? extends DataSource> type) {
/*  43 */     return (T)properties.initializeDataSourceBuilder().type(type).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({DataSource.class})
/*     */   @ConditionalOnMissingBean({DataSource.class})
/*     */   @ConditionalOnProperty(name = {"spring.datasource.type"}, havingValue = "org.apache.tomcat.jdbc.pool.DataSource", matchIfMissing = true)
/*     */   static class Tomcat
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix = "spring.datasource.tomcat")
/*     */     DataSource dataSource(DataSourceProperties properties) {
/*  59 */       DataSource dataSource = DataSourceConfiguration.<DataSource>createDataSource(properties, (Class)DataSource.class);
/*     */       
/*  61 */       DatabaseDriver databaseDriver = DatabaseDriver.fromJdbcUrl(properties.determineUrl());
/*  62 */       String validationQuery = databaseDriver.getValidationQuery();
/*  63 */       if (validationQuery != null) {
/*  64 */         dataSource.setTestOnBorrow(true);
/*  65 */         dataSource.setValidationQuery(validationQuery);
/*     */       } 
/*  67 */       return dataSource;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({HikariDataSource.class})
/*     */   @ConditionalOnMissingBean({DataSource.class})
/*     */   @ConditionalOnProperty(name = {"spring.datasource.type"}, havingValue = "com.zaxxer.hikari.HikariDataSource", matchIfMissing = true)
/*     */   static class Hikari
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix = "spring.datasource.hikari")
/*     */     HikariDataSource dataSource(DataSourceProperties properties) {
/*  85 */       HikariDataSource dataSource = DataSourceConfiguration.<HikariDataSource>createDataSource(properties, (Class)HikariDataSource.class);
/*  86 */       if (StringUtils.hasText(properties.getName())) {
/*  87 */         dataSource.setPoolName(properties.getName());
/*     */       }
/*  89 */       return dataSource;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({BasicDataSource.class})
/*     */   @ConditionalOnMissingBean({DataSource.class})
/*     */   @ConditionalOnProperty(name = {"spring.datasource.type"}, havingValue = "org.apache.commons.dbcp2.BasicDataSource", matchIfMissing = true)
/*     */   static class Dbcp2
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix = "spring.datasource.dbcp2")
/*     */     BasicDataSource dataSource(DataSourceProperties properties) {
/* 107 */       return DataSourceConfiguration.<BasicDataSource>createDataSource(properties, (Class)BasicDataSource.class);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({DataSource.class})
/*     */   @ConditionalOnProperty(name = {"spring.datasource.type"})
/*     */   static class Generic
/*     */   {
/*     */     @Bean
/*     */     DataSource dataSource(DataSourceProperties properties) {
/* 122 */       return properties.initializeDataSourceBuilder().build();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
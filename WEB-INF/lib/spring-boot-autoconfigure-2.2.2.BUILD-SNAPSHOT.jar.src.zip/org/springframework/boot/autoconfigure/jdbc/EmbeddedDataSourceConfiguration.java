/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
/*    */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @EnableConfigurationProperties({DataSourceProperties.class})
/*    */ public class EmbeddedDataSourceConfiguration
/*    */   implements BeanClassLoaderAware
/*    */ {
/*    */   private ClassLoader classLoader;
/*    */   
/*    */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 43 */     this.classLoader = classLoader;
/*    */   }
/*    */   
/*    */   @Bean(destroyMethod = "shutdown")
/*    */   public EmbeddedDatabase dataSource(DataSourceProperties properties) {
/* 48 */     return (new EmbeddedDatabaseBuilder()).setType(EmbeddedDatabaseConnection.get(this.classLoader).getType())
/* 49 */       .setName(properties.determineDatabaseName()).build();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\EmbeddedDataSourceConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataSourceInitializerInvoker
/*     */   implements ApplicationListener<DataSourceSchemaCreatedEvent>, InitializingBean
/*     */ {
/*  40 */   private static final Log logger = LogFactory.getLog(DataSourceInitializerInvoker.class);
/*     */   
/*     */   private final ObjectProvider<DataSource> dataSource;
/*     */   
/*     */   private final DataSourceProperties properties;
/*     */   
/*     */   private final ApplicationContext applicationContext;
/*     */   
/*     */   private DataSourceInitializer dataSourceInitializer;
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */   
/*     */   DataSourceInitializerInvoker(ObjectProvider<DataSource> dataSource, DataSourceProperties properties, ApplicationContext applicationContext) {
/*  54 */     this.dataSource = dataSource;
/*  55 */     this.properties = properties;
/*  56 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  61 */     DataSourceInitializer initializer = getDataSourceInitializer();
/*  62 */     if (initializer != null) {
/*  63 */       boolean schemaCreated = this.dataSourceInitializer.createSchema();
/*  64 */       if (schemaCreated) {
/*  65 */         initialize(initializer);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initialize(DataSourceInitializer initializer) {
/*     */     try {
/*  72 */       this.applicationContext.publishEvent(new DataSourceSchemaCreatedEvent(initializer.getDataSource()));
/*     */       
/*  74 */       if (!this.initialized) {
/*  75 */         this.dataSourceInitializer.initSchema();
/*  76 */         this.initialized = true;
/*     */       }
/*     */     
/*  79 */     } catch (IllegalStateException ex) {
/*  80 */       logger.warn(LogMessage.format("Could not send event to complete DataSource initialization (%s)", ex
/*  81 */             .getMessage()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(DataSourceSchemaCreatedEvent event) {
/*  89 */     DataSourceInitializer initializer = getDataSourceInitializer();
/*  90 */     if (!this.initialized && initializer != null) {
/*  91 */       initializer.initSchema();
/*  92 */       this.initialized = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private DataSourceInitializer getDataSourceInitializer() {
/*  97 */     if (this.dataSourceInitializer == null) {
/*  98 */       DataSource ds = (DataSource)this.dataSource.getIfUnique();
/*  99 */       if (ds != null) {
/* 100 */         this.dataSourceInitializer = new DataSourceInitializer(ds, this.properties, (ResourceLoader)this.applicationContext);
/*     */       }
/*     */     } 
/* 103 */     return this.dataSourceInitializer;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceInitializerInvoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
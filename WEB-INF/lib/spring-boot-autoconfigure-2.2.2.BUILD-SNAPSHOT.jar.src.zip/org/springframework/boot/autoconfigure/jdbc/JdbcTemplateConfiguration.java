/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Primary;
/*    */ import org.springframework.jdbc.core.JdbcOperations;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnMissingBean({JdbcOperations.class})
/*    */ class JdbcTemplateConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Primary
/*    */   JdbcTemplate jdbcTemplate(DataSource dataSource, JdbcProperties properties) {
/* 40 */     JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
/* 41 */     JdbcProperties.Template template = properties.getTemplate();
/* 42 */     jdbcTemplate.setFetchSize(template.getFetchSize());
/* 43 */     jdbcTemplate.setMaxRows(template.getMaxRows());
/* 44 */     if (template.getQueryTimeout() != null) {
/* 45 */       jdbcTemplate.setQueryTimeout((int)template.getQueryTimeout().getSeconds());
/*    */     }
/* 47 */     return jdbcTemplate;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\JdbcTemplateConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.XADataSource;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.jdbc.metadata.DataSourcePoolMetadataProvidersConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({DataSource.class, EmbeddedDatabaseType.class})
/*     */ @EnableConfigurationProperties({DataSourceProperties.class})
/*     */ @Import({DataSourcePoolMetadataProvidersConfiguration.class, DataSourceInitializationConfiguration.class})
/*     */ public class DataSourceAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Conditional({EmbeddedDatabaseCondition.class})
/*     */   @ConditionalOnMissingBean({DataSource.class, XADataSource.class})
/*     */   @Import({EmbeddedDataSourceConfiguration.class})
/*     */   protected static class EmbeddedDatabaseConfiguration {}
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Conditional({PooledDataSourceCondition.class})
/*     */   @ConditionalOnMissingBean({DataSource.class, XADataSource.class})
/*     */   @Import({DataSourceConfiguration.Hikari.class, DataSourceConfiguration.Tomcat.class, DataSourceConfiguration.Dbcp2.class, DataSourceConfiguration.Generic.class, DataSourceJmxConfiguration.class})
/*     */   protected static class PooledDataSourceConfiguration {}
/*     */   
/*     */   static class PooledDataSourceCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     PooledDataSourceCondition() {
/*  82 */       super(ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @ConditionalOnProperty(prefix = "spring.datasource", name = {"type"})
/*     */     static class ExplicitType {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Conditional({DataSourceAutoConfiguration.PooledDataSourceAvailableCondition.class})
/*     */     static class PooledDataSourceAvailable {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class PooledDataSourceAvailableCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 104 */       ConditionMessage.Builder message = ConditionMessage.forCondition("PooledDataSource", new Object[0]);
/* 105 */       if (DataSourceBuilder.findType(context.getClassLoader()) != null) {
/* 106 */         return ConditionOutcome.match(message.foundExactly("supported DataSource"));
/*     */       }
/* 108 */       return ConditionOutcome.noMatch(message.didNotFind("supported DataSource").atAll());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class EmbeddedDatabaseCondition
/*     */     extends SpringBootCondition
/*     */   {
/* 120 */     private final SpringBootCondition pooledCondition = (SpringBootCondition)new DataSourceAutoConfiguration.PooledDataSourceCondition();
/*     */ 
/*     */     
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 124 */       ConditionMessage.Builder message = ConditionMessage.forCondition("EmbeddedDataSource", new Object[0]);
/* 125 */       if (anyMatches(context, metadata, new Condition[] { (Condition)this.pooledCondition })) {
/* 126 */         return ConditionOutcome.noMatch(message.foundExactly("supported pooled data source"));
/*     */       }
/* 128 */       EmbeddedDatabaseType type = EmbeddedDatabaseConnection.get(context.getClassLoader()).getType();
/* 129 */       if (type == null) {
/* 130 */         return ConditionOutcome.noMatch(message.didNotFind("embedded database").atAll());
/*     */       }
/* 132 */       return ConditionOutcome.match(message.found("embedded database").items(new Object[] { type }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.XADataSource;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyNameAliases;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.MapConfigurationPropertySource;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.boot.jdbc.XADataSourceWrapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @AutoConfigureBefore({DataSourceAutoConfiguration.class})
/*     */ @EnableConfigurationProperties({DataSourceProperties.class})
/*     */ @ConditionalOnClass({DataSource.class, TransactionManager.class, EmbeddedDatabaseType.class})
/*     */ @ConditionalOnBean({XADataSourceWrapper.class})
/*     */ @ConditionalOnMissingBean({DataSource.class})
/*     */ public class XADataSourceAutoConfiguration
/*     */   implements BeanClassLoaderAware
/*     */ {
/*     */   private ClassLoader classLoader;
/*     */   
/*     */   @Bean
/*     */   public DataSource dataSource(XADataSourceWrapper wrapper, DataSourceProperties properties, ObjectProvider<XADataSource> xaDataSource) throws Exception {
/*  68 */     return wrapper.wrapDataSource((XADataSource)xaDataSource.getIfAvailable(() -> createXaDataSource(properties)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  73 */     this.classLoader = classLoader;
/*     */   }
/*     */   
/*     */   private XADataSource createXaDataSource(DataSourceProperties properties) {
/*  77 */     String className = properties.getXa().getDataSourceClassName();
/*  78 */     if (!StringUtils.hasLength(className)) {
/*  79 */       className = DatabaseDriver.fromJdbcUrl(properties.determineUrl()).getXaDataSourceClassName();
/*     */     }
/*  81 */     Assert.state(StringUtils.hasLength(className), "No XA DataSource class name specified");
/*  82 */     XADataSource dataSource = createXaDataSourceInstance(className);
/*  83 */     bindXaProperties(dataSource, properties);
/*  84 */     return dataSource;
/*     */   }
/*     */   
/*     */   private XADataSource createXaDataSourceInstance(String className) {
/*     */     try {
/*  89 */       Class<?> dataSourceClass = ClassUtils.forName(className, this.classLoader);
/*  90 */       Object instance = BeanUtils.instantiateClass(dataSourceClass);
/*  91 */       Assert.isInstanceOf(XADataSource.class, instance);
/*  92 */       return (XADataSource)instance;
/*     */     }
/*  94 */     catch (Exception ex) {
/*  95 */       throw new IllegalStateException("Unable to create XADataSource instance from '" + className + "'");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void bindXaProperties(XADataSource target, DataSourceProperties dataSourceProperties) {
/* 100 */     Binder binder = new Binder(new ConfigurationPropertySource[] { getBinderSource(dataSourceProperties) });
/* 101 */     binder.bind(ConfigurationPropertyName.EMPTY, Bindable.ofInstance(target));
/*     */   }
/*     */   
/*     */   private ConfigurationPropertySource getBinderSource(DataSourceProperties dataSourceProperties) {
/* 105 */     MapConfigurationPropertySource source = new MapConfigurationPropertySource();
/* 106 */     source.put("user", dataSourceProperties.determineUsername());
/* 107 */     source.put("password", dataSourceProperties.determinePassword());
/* 108 */     source.put("url", dataSourceProperties.determineUrl());
/* 109 */     source.putAll(dataSourceProperties.getXa().getProperties());
/* 110 */     ConfigurationPropertyNameAliases aliases = new ConfigurationPropertyNameAliases();
/* 111 */     aliases.addAliases("user", new String[] { "username" });
/* 112 */     return (ConfigurationPropertySource)source.withAliases(aliases);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\XADataSourceAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
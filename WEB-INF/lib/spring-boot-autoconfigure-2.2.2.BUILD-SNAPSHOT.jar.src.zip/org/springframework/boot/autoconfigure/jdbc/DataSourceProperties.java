/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.datasource")
/*     */ public class DataSourceProperties
/*     */   implements BeanClassLoaderAware, InitializingBean
/*     */ {
/*     */   private ClassLoader classLoader;
/*     */   private String name;
/*     */   private boolean generateUniqueName;
/*     */   private Class<? extends DataSource> type;
/*     */   private String driverClassName;
/*     */   private String url;
/*     */   private String username;
/*     */   private String password;
/*     */   private String jndiName;
/*  99 */   private DataSourceInitializationMode initializationMode = DataSourceInitializationMode.EMBEDDED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private String platform = "all";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> schema;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String schemaUsername;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String schemaPassword;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> data;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String dataUsername;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String dataPassword;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean continueOnError = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   private String separator = ";";
/*     */ 
/*     */ 
/*     */   
/*     */   private Charset sqlScriptEncoding;
/*     */ 
/*     */   
/* 152 */   private EmbeddedDatabaseConnection embeddedDatabaseConnection = EmbeddedDatabaseConnection.NONE;
/*     */   
/* 154 */   private Xa xa = new Xa();
/*     */   
/*     */   private String uniqueName;
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 160 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 165 */     this.embeddedDatabaseConnection = EmbeddedDatabaseConnection.get(this.classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSourceBuilder<?> initializeDataSourceBuilder() {
/* 174 */     return DataSourceBuilder.create(getClassLoader()).type(getType()).driverClassName(determineDriverClassName())
/* 175 */       .url(determineUrl()).username(determineUsername()).password(determinePassword());
/*     */   }
/*     */   
/*     */   public String getName() {
/* 179 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 183 */     this.name = name;
/*     */   }
/*     */   
/*     */   public boolean isGenerateUniqueName() {
/* 187 */     return this.generateUniqueName;
/*     */   }
/*     */   
/*     */   public void setGenerateUniqueName(boolean generateUniqueName) {
/* 191 */     this.generateUniqueName = generateUniqueName;
/*     */   }
/*     */   
/*     */   public Class<? extends DataSource> getType() {
/* 195 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(Class<? extends DataSource> type) {
/* 199 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDriverClassName() {
/* 208 */     return this.driverClassName;
/*     */   }
/*     */   
/*     */   public void setDriverClassName(String driverClassName) {
/* 212 */     this.driverClassName = driverClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String determineDriverClassName() {
/* 221 */     if (StringUtils.hasText(this.driverClassName)) {
/* 222 */       Assert.state(driverClassIsLoadable(), () -> "Cannot load driver class: " + this.driverClassName);
/* 223 */       return this.driverClassName;
/*     */     } 
/* 225 */     String driverClassName = null;
/* 226 */     if (StringUtils.hasText(this.url)) {
/* 227 */       driverClassName = DatabaseDriver.fromJdbcUrl(this.url).getDriverClassName();
/*     */     }
/* 229 */     if (!StringUtils.hasText(driverClassName)) {
/* 230 */       driverClassName = this.embeddedDatabaseConnection.getDriverClassName();
/*     */     }
/* 232 */     if (!StringUtils.hasText(driverClassName)) {
/* 233 */       throw new DataSourceBeanCreationException("Failed to determine a suitable driver class", this, this.embeddedDatabaseConnection);
/*     */     }
/*     */     
/* 236 */     return driverClassName;
/*     */   }
/*     */   
/*     */   private boolean driverClassIsLoadable() {
/*     */     try {
/* 241 */       ClassUtils.forName(this.driverClassName, null);
/* 242 */       return true;
/*     */     }
/* 244 */     catch (UnsupportedClassVersionError ex) {
/*     */       
/* 246 */       throw ex;
/*     */     }
/* 248 */     catch (Throwable ex) {
/* 249 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/* 259 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 263 */     this.url = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String determineUrl() {
/* 272 */     if (StringUtils.hasText(this.url)) {
/* 273 */       return this.url;
/*     */     }
/* 275 */     String databaseName = determineDatabaseName();
/* 276 */     String url = (databaseName != null) ? this.embeddedDatabaseConnection.getUrl(databaseName) : null;
/* 277 */     if (!StringUtils.hasText(url)) {
/* 278 */       throw new DataSourceBeanCreationException("Failed to determine suitable jdbc url", this, this.embeddedDatabaseConnection);
/*     */     }
/*     */     
/* 281 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String determineDatabaseName() {
/* 290 */     if (this.generateUniqueName) {
/* 291 */       if (this.uniqueName == null) {
/* 292 */         this.uniqueName = UUID.randomUUID().toString();
/*     */       }
/* 294 */       return this.uniqueName;
/*     */     } 
/* 296 */     if (StringUtils.hasLength(this.name)) {
/* 297 */       return this.name;
/*     */     }
/* 299 */     if (this.embeddedDatabaseConnection != EmbeddedDatabaseConnection.NONE) {
/* 300 */       return "testdb";
/*     */     }
/* 302 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUsername() {
/* 311 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 315 */     this.username = username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String determineUsername() {
/* 324 */     if (StringUtils.hasText(this.username)) {
/* 325 */       return this.username;
/*     */     }
/* 327 */     if (EmbeddedDatabaseConnection.isEmbedded(determineDriverClassName())) {
/* 328 */       return "sa";
/*     */     }
/* 330 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 339 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 343 */     this.password = password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String determinePassword() {
/* 352 */     if (StringUtils.hasText(this.password)) {
/* 353 */       return this.password;
/*     */     }
/* 355 */     if (EmbeddedDatabaseConnection.isEmbedded(determineDriverClassName())) {
/* 356 */       return "";
/*     */     }
/* 358 */     return null;
/*     */   }
/*     */   
/*     */   public String getJndiName() {
/* 362 */     return this.jndiName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJndiName(String jndiName) {
/* 372 */     this.jndiName = jndiName;
/*     */   }
/*     */   
/*     */   public DataSourceInitializationMode getInitializationMode() {
/* 376 */     return this.initializationMode;
/*     */   }
/*     */   
/*     */   public void setInitializationMode(DataSourceInitializationMode initializationMode) {
/* 380 */     this.initializationMode = initializationMode;
/*     */   }
/*     */   
/*     */   public String getPlatform() {
/* 384 */     return this.platform;
/*     */   }
/*     */   
/*     */   public void setPlatform(String platform) {
/* 388 */     this.platform = platform;
/*     */   }
/*     */   
/*     */   public List<String> getSchema() {
/* 392 */     return this.schema;
/*     */   }
/*     */   
/*     */   public void setSchema(List<String> schema) {
/* 396 */     this.schema = schema;
/*     */   }
/*     */   
/*     */   public String getSchemaUsername() {
/* 400 */     return this.schemaUsername;
/*     */   }
/*     */   
/*     */   public void setSchemaUsername(String schemaUsername) {
/* 404 */     this.schemaUsername = schemaUsername;
/*     */   }
/*     */   
/*     */   public String getSchemaPassword() {
/* 408 */     return this.schemaPassword;
/*     */   }
/*     */   
/*     */   public void setSchemaPassword(String schemaPassword) {
/* 412 */     this.schemaPassword = schemaPassword;
/*     */   }
/*     */   
/*     */   public List<String> getData() {
/* 416 */     return this.data;
/*     */   }
/*     */   
/*     */   public void setData(List<String> data) {
/* 420 */     this.data = data;
/*     */   }
/*     */   
/*     */   public String getDataUsername() {
/* 424 */     return this.dataUsername;
/*     */   }
/*     */   
/*     */   public void setDataUsername(String dataUsername) {
/* 428 */     this.dataUsername = dataUsername;
/*     */   }
/*     */   
/*     */   public String getDataPassword() {
/* 432 */     return this.dataPassword;
/*     */   }
/*     */   
/*     */   public void setDataPassword(String dataPassword) {
/* 436 */     this.dataPassword = dataPassword;
/*     */   }
/*     */   
/*     */   public boolean isContinueOnError() {
/* 440 */     return this.continueOnError;
/*     */   }
/*     */   
/*     */   public void setContinueOnError(boolean continueOnError) {
/* 444 */     this.continueOnError = continueOnError;
/*     */   }
/*     */   
/*     */   public String getSeparator() {
/* 448 */     return this.separator;
/*     */   }
/*     */   
/*     */   public void setSeparator(String separator) {
/* 452 */     this.separator = separator;
/*     */   }
/*     */   
/*     */   public Charset getSqlScriptEncoding() {
/* 456 */     return this.sqlScriptEncoding;
/*     */   }
/*     */   
/*     */   public void setSqlScriptEncoding(Charset sqlScriptEncoding) {
/* 460 */     this.sqlScriptEncoding = sqlScriptEncoding;
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 464 */     return this.classLoader;
/*     */   }
/*     */   
/*     */   public Xa getXa() {
/* 468 */     return this.xa;
/*     */   }
/*     */   
/*     */   public void setXa(Xa xa) {
/* 472 */     this.xa = xa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Xa
/*     */   {
/*     */     private String dataSourceClassName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 488 */     private Map<String, String> properties = new LinkedHashMap<>();
/*     */     
/*     */     public String getDataSourceClassName() {
/* 491 */       return this.dataSourceClassName;
/*     */     }
/*     */     
/*     */     public void setDataSourceClassName(String dataSourceClassName) {
/* 495 */       this.dataSourceClassName = dataSourceClassName;
/*     */     }
/*     */     
/*     */     public Map<String, String> getProperties() {
/* 499 */       return this.properties;
/*     */     }
/*     */     
/*     */     public void setProperties(Map<String, String> properties) {
/* 503 */       this.properties = properties;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class DataSourceBeanCreationException
/*     */     extends BeanCreationException
/*     */   {
/*     */     private final DataSourceProperties properties;
/*     */     
/*     */     private final EmbeddedDatabaseConnection connection;
/*     */     
/*     */     DataSourceBeanCreationException(String message, DataSourceProperties properties, EmbeddedDatabaseConnection connection) {
/* 516 */       super(message);
/* 517 */       this.properties = properties;
/* 518 */       this.connection = connection;
/*     */     }
/*     */     
/*     */     DataSourceProperties getProperties() {
/* 522 */       return this.properties;
/*     */     }
/*     */     
/*     */     EmbeddedDatabaseConnection getConnection() {
/* 526 */       return this.connection;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
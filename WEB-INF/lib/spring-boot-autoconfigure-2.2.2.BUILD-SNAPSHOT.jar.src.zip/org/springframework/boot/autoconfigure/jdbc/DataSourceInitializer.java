/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*     */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.jdbc.config.SortedResourcesFactoryBean;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*     */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataSourceInitializer
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(DataSourceInitializer.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final DataSource dataSource;
/*     */ 
/*     */ 
/*     */   
/*     */   private final DataSourceProperties properties;
/*     */ 
/*     */   
/*     */   private final ResourceLoader resourceLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   DataSourceInitializer(DataSource dataSource, DataSourceProperties properties, ResourceLoader resourceLoader) {
/*  68 */     this.dataSource = dataSource;
/*  69 */     this.properties = properties;
/*  70 */     this.resourceLoader = (resourceLoader != null) ? resourceLoader : (ResourceLoader)new DefaultResourceLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataSourceInitializer(DataSource dataSource, DataSourceProperties properties) {
/*  80 */     this(dataSource, properties, null);
/*     */   }
/*     */   
/*     */   DataSource getDataSource() {
/*  84 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean createSchema() {
/*  93 */     List<Resource> scripts = getScripts("spring.datasource.schema", this.properties.getSchema(), "schema");
/*  94 */     if (!scripts.isEmpty()) {
/*  95 */       if (!isEnabled()) {
/*  96 */         logger.debug("Initialization disabled (not running DDL scripts)");
/*  97 */         return false;
/*     */       } 
/*  99 */       String username = this.properties.getSchemaUsername();
/* 100 */       String password = this.properties.getSchemaPassword();
/* 101 */       runScripts(scripts, username, password);
/*     */     } 
/* 103 */     return !scripts.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initSchema() {
/* 111 */     List<Resource> scripts = getScripts("spring.datasource.data", this.properties.getData(), "data");
/* 112 */     if (!scripts.isEmpty()) {
/* 113 */       if (!isEnabled()) {
/* 114 */         logger.debug("Initialization disabled (not running data scripts)");
/*     */         return;
/*     */       } 
/* 117 */       String username = this.properties.getDataUsername();
/* 118 */       String password = this.properties.getDataPassword();
/* 119 */       runScripts(scripts, username, password);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isEnabled() {
/* 124 */     DataSourceInitializationMode mode = this.properties.getInitializationMode();
/* 125 */     if (mode == DataSourceInitializationMode.NEVER) {
/* 126 */       return false;
/*     */     }
/* 128 */     if (mode == DataSourceInitializationMode.EMBEDDED && !isEmbedded()) {
/* 129 */       return false;
/*     */     }
/* 131 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isEmbedded() {
/*     */     try {
/* 136 */       return EmbeddedDatabaseConnection.isEmbedded(this.dataSource);
/*     */     }
/* 138 */     catch (Exception ex) {
/* 139 */       logger.debug("Could not determine if datasource is embedded", ex);
/* 140 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<Resource> getScripts(String propertyName, List<String> resources, String fallback) {
/* 145 */     if (resources != null) {
/* 146 */       return getResources(propertyName, resources, true);
/*     */     }
/* 148 */     String platform = this.properties.getPlatform();
/* 149 */     List<String> fallbackResources = new ArrayList<>();
/* 150 */     fallbackResources.add("classpath*:" + fallback + "-" + platform + ".sql");
/* 151 */     fallbackResources.add("classpath*:" + fallback + ".sql");
/* 152 */     return getResources(propertyName, fallbackResources, false);
/*     */   }
/*     */   
/*     */   private List<Resource> getResources(String propertyName, List<String> locations, boolean validate) {
/* 156 */     List<Resource> resources = new ArrayList<>();
/* 157 */     for (String location : locations) {
/* 158 */       for (Resource resource : doGetResources(location)) {
/* 159 */         if (resource.exists()) {
/* 160 */           resources.add(resource);
/*     */         }
/* 162 */         else if (validate) {
/* 163 */           throw new InvalidConfigurationPropertyValueException(propertyName, resource, "The specified resource does not exist.");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 168 */     return resources;
/*     */   }
/*     */ 
/*     */   
/*     */   private Resource[] doGetResources(String location) {
/*     */     try {
/* 174 */       SortedResourcesFactoryBean factory = new SortedResourcesFactoryBean(this.resourceLoader, Collections.singletonList(location));
/* 175 */       factory.afterPropertiesSet();
/* 176 */       return (Resource[])factory.getObject();
/*     */     }
/* 178 */     catch (Exception ex) {
/* 179 */       throw new IllegalStateException("Unable to load resources from " + location, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void runScripts(List<Resource> resources, String username, String password) {
/* 184 */     if (resources.isEmpty()) {
/*     */       return;
/*     */     }
/* 187 */     ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 188 */     populator.setContinueOnError(this.properties.isContinueOnError());
/* 189 */     populator.setSeparator(this.properties.getSeparator());
/* 190 */     if (this.properties.getSqlScriptEncoding() != null) {
/* 191 */       populator.setSqlScriptEncoding(this.properties.getSqlScriptEncoding().name());
/*     */     }
/* 193 */     for (Resource resource : resources) {
/* 194 */       populator.addScript(resource);
/*     */     }
/* 196 */     DataSource dataSource = this.dataSource;
/* 197 */     if (StringUtils.hasText(username) && StringUtils.hasText(password))
/*     */     {
/*     */       
/* 200 */       dataSource = DataSourceBuilder.create(this.properties.getClassLoader()).driverClassName(this.properties.determineDriverClassName()).url(this.properties.determineUrl()).username(username).password(password).build();
/*     */     }
/* 202 */     DatabasePopulatorUtils.execute((DatabasePopulator)populator, dataSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import com.zaxxer.hikari.HikariDataSource;
/*    */ import java.sql.SQLException;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.tomcat.jdbc.pool.DataSourceProxy;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.jdbc.DataSourceUnwrapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jmx.export.MBeanExporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnProperty(prefix = "spring.jmx", name = {"enabled"}, havingValue = "true", matchIfMissing = true)
/*    */ class DataSourceJmxConfiguration
/*    */ {
/* 48 */   private static final Log logger = LogFactory.getLog(DataSourceJmxConfiguration.class);
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({HikariDataSource.class})
/*    */   @ConditionalOnSingleCandidate(DataSource.class)
/*    */   static class Hikari
/*    */   {
/*    */     private final DataSource dataSource;
/*    */     private final ObjectProvider<MBeanExporter> mBeanExporter;
/*    */     
/*    */     Hikari(DataSource dataSource, ObjectProvider<MBeanExporter> mBeanExporter) {
/* 60 */       this.dataSource = dataSource;
/* 61 */       this.mBeanExporter = mBeanExporter;
/*    */     }
/*    */     
/*    */     @PostConstruct
/*    */     void validateMBeans() {
/* 66 */       HikariDataSource hikariDataSource = (HikariDataSource)DataSourceUnwrapper.unwrap(this.dataSource, HikariDataSource.class);
/* 67 */       if (hikariDataSource != null && hikariDataSource.isRegisterMbeans()) {
/* 68 */         this.mBeanExporter.ifUnique(exporter -> exporter.addExcludedBean("dataSource"));
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnProperty(prefix = "spring.datasource.tomcat", name = {"jmx-enabled"})
/*    */   @ConditionalOnClass({DataSourceProxy.class})
/*    */   @ConditionalOnSingleCandidate(DataSource.class)
/*    */   static class TomcatDataSourceJmxConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean(name = {"dataSourceMBean"})
/*    */     Object dataSourceMBean(DataSource dataSource) {
/* 83 */       DataSourceProxy dataSourceProxy = (DataSourceProxy)DataSourceUnwrapper.unwrap(dataSource, DataSourceProxy.class);
/* 84 */       if (dataSourceProxy != null) {
/*    */         try {
/* 86 */           return dataSourceProxy.createPool().getJmxPool();
/*    */         }
/* 88 */         catch (SQLException ex) {
/* 89 */           DataSourceJmxConfiguration.logger.warn("Cannot expose DataSource to JMX (could not connect)");
/*    */         } 
/*    */       }
/* 92 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceJmxConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.transaction.jta;
/*     */ 
/*     */ import bitronix.tm.BitronixTransactionManager;
/*     */ import bitronix.tm.Configuration;
/*     */ import bitronix.tm.TransactionManagerServices;
/*     */ import bitronix.tm.jndi.BitronixContext;
/*     */ import java.io.File;
/*     */ import javax.jms.Message;
/*     */ import javax.transaction.TransactionManager;
/*     */ import javax.transaction.UserTransaction;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.XADataSourceWrapper;
/*     */ import org.springframework.boot.jms.XAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.bitronix.BitronixDependentBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.jta.bitronix.BitronixXAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.bitronix.BitronixXADataSourceWrapper;
/*     */ import org.springframework.boot.system.ApplicationHome;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({JtaProperties.class})
/*     */ @ConditionalOnClass({JtaTransactionManager.class, BitronixContext.class})
/*     */ @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*     */ class BitronixJtaConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConfigurationProperties(prefix = "spring.jta.bitronix.properties")
/*     */   Configuration bitronixConfiguration(JtaProperties jtaProperties) {
/*  65 */     Configuration config = TransactionManagerServices.getConfiguration();
/*  66 */     if (StringUtils.hasText(jtaProperties.getTransactionManagerId())) {
/*  67 */       config.setServerId(jtaProperties.getTransactionManagerId());
/*     */     }
/*  69 */     File logBaseDir = getLogBaseDir(jtaProperties);
/*  70 */     config.setLogPart1Filename((new File(logBaseDir, "part1.btm")).getAbsolutePath());
/*  71 */     config.setLogPart2Filename((new File(logBaseDir, "part2.btm")).getAbsolutePath());
/*  72 */     config.setDisableJmx(true);
/*  73 */     return config;
/*     */   }
/*     */   
/*     */   private File getLogBaseDir(JtaProperties jtaProperties) {
/*  77 */     if (StringUtils.hasLength(jtaProperties.getLogDir())) {
/*  78 */       return new File(jtaProperties.getLogDir());
/*     */     }
/*  80 */     File home = (new ApplicationHome()).getDir();
/*  81 */     return new File(home, "transaction-logs");
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({TransactionManager.class})
/*     */   BitronixTransactionManager bitronixTransactionManager(Configuration configuration) {
/*  88 */     return TransactionManagerServices.getTransactionManager();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({XADataSourceWrapper.class})
/*     */   BitronixXADataSourceWrapper xaDataSourceWrapper() {
/*  94 */     return new BitronixXADataSourceWrapper();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   static BitronixDependentBeanFactoryPostProcessor bitronixDependentBeanFactoryPostProcessor() {
/* 100 */     return new BitronixDependentBeanFactoryPostProcessor();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   JtaTransactionManager transactionManager(UserTransaction userTransaction, TransactionManager transactionManager, ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
/* 106 */     JtaTransactionManager jtaTransactionManager = new JtaTransactionManager(userTransaction, transactionManager);
/* 107 */     transactionManagerCustomizers.ifAvailable(customizers -> customizers.customize((PlatformTransactionManager)jtaTransactionManager));
/* 108 */     return jtaTransactionManager;
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Message.class})
/*     */   static class BitronixJtaJmsConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({XAConnectionFactoryWrapper.class})
/*     */     BitronixXAConnectionFactoryWrapper xaConnectionFactoryWrapper() {
/* 118 */       return new BitronixXAConnectionFactoryWrapper();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\transaction\jta\BitronixJtaConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
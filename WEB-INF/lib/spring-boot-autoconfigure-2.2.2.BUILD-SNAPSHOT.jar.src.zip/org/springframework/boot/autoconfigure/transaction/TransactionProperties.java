/*    */ package org.springframework.boot.autoconfigure.transaction;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.boot.convert.DurationUnit;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.transaction")
/*    */ public class TransactionProperties
/*    */   implements PlatformTransactionManagerCustomizer<AbstractPlatformTransactionManager>
/*    */ {
/*    */   @DurationUnit(ChronoUnit.SECONDS)
/*    */   private Duration defaultTimeout;
/*    */   private Boolean rollbackOnCommitFailure;
/*    */   
/*    */   public Duration getDefaultTimeout() {
/* 50 */     return this.defaultTimeout;
/*    */   }
/*    */   
/*    */   public void setDefaultTimeout(Duration defaultTimeout) {
/* 54 */     this.defaultTimeout = defaultTimeout;
/*    */   }
/*    */   
/*    */   public Boolean getRollbackOnCommitFailure() {
/* 58 */     return this.rollbackOnCommitFailure;
/*    */   }
/*    */   
/*    */   public void setRollbackOnCommitFailure(Boolean rollbackOnCommitFailure) {
/* 62 */     this.rollbackOnCommitFailure = rollbackOnCommitFailure;
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(AbstractPlatformTransactionManager transactionManager) {
/* 67 */     if (this.defaultTimeout != null) {
/* 68 */       transactionManager.setDefaultTimeout((int)this.defaultTimeout.getSeconds());
/*    */     }
/* 70 */     if (this.rollbackOnCommitFailure != null)
/* 71 */       transactionManager.setRollbackOnCommitFailure(this.rollbackOnCommitFailure.booleanValue()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\transaction\TransactionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.transaction;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.util.LambdaSafe;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionManagerCustomizers
/*    */ {
/*    */   private final List<PlatformTransactionManagerCustomizer<?>> customizers;
/*    */   
/*    */   public TransactionManagerCustomizers(Collection<? extends PlatformTransactionManagerCustomizer<?>> customizers) {
/* 38 */     this.customizers = (customizers != null) ? new ArrayList<>(customizers) : Collections.<PlatformTransactionManagerCustomizer<?>>emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   public void customize(PlatformTransactionManager transactionManager) {
/* 43 */     ((LambdaSafe.Callbacks)LambdaSafe.callbacks(PlatformTransactionManagerCustomizer.class, this.customizers, transactionManager, new Object[0])
/* 44 */       .withLogger(TransactionManagerCustomizers.class))
/* 45 */       .invoke(customizer -> customizer.customize(transactionManager));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\transaction\TransactionManagerCustomizers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
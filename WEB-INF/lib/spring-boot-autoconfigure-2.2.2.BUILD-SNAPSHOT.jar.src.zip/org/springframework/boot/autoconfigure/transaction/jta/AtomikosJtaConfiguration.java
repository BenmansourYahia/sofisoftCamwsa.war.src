/*     */ package org.springframework.boot.autoconfigure.transaction.jta;
/*     */ 
/*     */ import com.atomikos.icatch.config.UserTransactionService;
/*     */ import com.atomikos.icatch.config.UserTransactionServiceImp;
/*     */ import com.atomikos.icatch.jta.UserTransactionManager;
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ import javax.jms.Message;
/*     */ import javax.transaction.TransactionManager;
/*     */ import javax.transaction.UserTransaction;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.XADataSourceWrapper;
/*     */ import org.springframework.boot.jms.XAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosDependsOnBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosProperties;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosXAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosXADataSourceWrapper;
/*     */ import org.springframework.boot.system.ApplicationHome;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @EnableConfigurationProperties({AtomikosProperties.class, JtaProperties.class})
/*     */ @ConditionalOnClass({JtaTransactionManager.class, UserTransactionManager.class})
/*     */ @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*     */ class AtomikosJtaConfiguration
/*     */ {
/*     */   @Bean(initMethod = "init", destroyMethod = "shutdownWait")
/*     */   @ConditionalOnMissingBean({UserTransactionService.class})
/*     */   UserTransactionServiceImp userTransactionService(AtomikosProperties atomikosProperties, JtaProperties jtaProperties) {
/*  67 */     Properties properties = new Properties();
/*  68 */     if (StringUtils.hasText(jtaProperties.getTransactionManagerId())) {
/*  69 */       properties.setProperty("com.atomikos.icatch.tm_unique_name", jtaProperties.getTransactionManagerId());
/*     */     }
/*  71 */     properties.setProperty("com.atomikos.icatch.log_base_dir", getLogBaseDir(jtaProperties));
/*  72 */     properties.putAll(atomikosProperties.asProperties());
/*  73 */     return new UserTransactionServiceImp(properties);
/*     */   }
/*     */   
/*     */   private String getLogBaseDir(JtaProperties jtaProperties) {
/*  77 */     if (StringUtils.hasLength(jtaProperties.getLogDir())) {
/*  78 */       return jtaProperties.getLogDir();
/*     */     }
/*  80 */     File home = (new ApplicationHome()).getDir();
/*  81 */     return (new File(home, "transaction-logs")).getAbsolutePath();
/*     */   }
/*     */   
/*     */   @Bean(initMethod = "init", destroyMethod = "close")
/*     */   @ConditionalOnMissingBean({TransactionManager.class})
/*     */   UserTransactionManager atomikosTransactionManager(UserTransactionService userTransactionService) throws Exception {
/*  87 */     UserTransactionManager manager = new UserTransactionManager();
/*  88 */     manager.setStartupTransactionService(false);
/*  89 */     manager.setForceShutdown(true);
/*  90 */     return manager;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({XADataSourceWrapper.class})
/*     */   AtomikosXADataSourceWrapper xaDataSourceWrapper() {
/*  96 */     return new AtomikosXADataSourceWrapper();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   static AtomikosDependsOnBeanFactoryPostProcessor atomikosDependsOnBeanFactoryPostProcessor() {
/* 102 */     return new AtomikosDependsOnBeanFactoryPostProcessor();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   JtaTransactionManager transactionManager(UserTransaction userTransaction, TransactionManager transactionManager, ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
/* 108 */     JtaTransactionManager jtaTransactionManager = new JtaTransactionManager(userTransaction, transactionManager);
/* 109 */     transactionManagerCustomizers.ifAvailable(customizers -> customizers.customize((PlatformTransactionManager)jtaTransactionManager));
/* 110 */     return jtaTransactionManager;
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Message.class})
/*     */   static class AtomikosJtaJmsConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({XAConnectionFactoryWrapper.class})
/*     */     AtomikosXAConnectionFactoryWrapper xaConnectionFactoryWrapper() {
/* 120 */       return new AtomikosXAConnectionFactoryWrapper();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\transaction\jta\AtomikosJtaConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
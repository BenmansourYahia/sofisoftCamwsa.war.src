/*    */ package org.springframework.boot.autoconfigure.transaction.jta;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.jta", ignoreUnknownFields = true)
/*    */ public class JtaProperties
/*    */ {
/*    */   private String logDir;
/*    */   private String transactionManagerId;
/*    */   
/*    */   public void setLogDir(String logDir) {
/* 46 */     this.logDir = logDir;
/*    */   }
/*    */   
/*    */   public String getLogDir() {
/* 50 */     return this.logDir;
/*    */   }
/*    */   
/*    */   public String getTransactionManagerId() {
/* 54 */     return this.transactionManagerId;
/*    */   }
/*    */   
/*    */   public void setTransactionManagerId(String transactionManagerId) {
/* 58 */     this.transactionManagerId = transactionManagerId;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\transaction\jta\JtaProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.transaction;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.autoconfigure.data.neo4j.Neo4jDataAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.transaction.jta.JtaAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ import org.springframework.transaction.ReactiveTransactionManager;
/*    */ import org.springframework.transaction.TransactionManager;
/*    */ import org.springframework.transaction.annotation.AbstractTransactionManagementConfiguration;
/*    */ import org.springframework.transaction.annotation.EnableTransactionManagement;
/*    */ import org.springframework.transaction.reactive.TransactionalOperator;
/*    */ import org.springframework.transaction.support.TransactionOperations;
/*    */ import org.springframework.transaction.support.TransactionTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({PlatformTransactionManager.class})
/*    */ @AutoConfigureAfter({JtaAutoConfiguration.class, HibernateJpaAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, Neo4jDataAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({TransactionProperties.class})
/*    */ public class TransactionAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public TransactionManagerCustomizers platformTransactionManagerCustomizers(ObjectProvider<PlatformTransactionManagerCustomizer<?>> customizers) {
/* 62 */     return new TransactionManagerCustomizers((Collection<? extends PlatformTransactionManagerCustomizer<?>>)customizers.orderedStream().collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   @ConditionalOnSingleCandidate(ReactiveTransactionManager.class)
/*    */   public TransactionalOperator transactionalOperator(ReactiveTransactionManager transactionManager) {
/* 69 */     return TransactionalOperator.create(transactionManager);
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnSingleCandidate(PlatformTransactionManager.class)
/*    */   public static class TransactionTemplateConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean({TransactionOperations.class})
/*    */     public TransactionTemplate transactionTemplate(PlatformTransactionManager transactionManager) {
/* 79 */       return new TransactionTemplate(transactionManager);
/*    */     }
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnBean({TransactionManager.class})
/*    */   @ConditionalOnMissingBean({AbstractTransactionManagementConfiguration.class})
/*    */   public static class EnableTransactionManagementConfiguration {
/*    */     @Configuration(proxyBeanMethods = false)
/*    */     @EnableTransactionManagement(proxyTargetClass = false)
/*    */     @ConditionalOnProperty(prefix = "spring.aop", name = {"proxy-target-class"}, havingValue = "false", matchIfMissing = false)
/*    */     public static class JdkDynamicAutoProxyConfiguration {}
/*    */     
/*    */     @Configuration(proxyBeanMethods = false)
/*    */     @EnableTransactionManagement(proxyTargetClass = true)
/*    */     @ConditionalOnProperty(prefix = "spring.aop", name = {"proxy-target-class"}, havingValue = "true", matchIfMissing = true)
/*    */     public static class CglibAutoProxyConfiguration {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\transaction\TransactionAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
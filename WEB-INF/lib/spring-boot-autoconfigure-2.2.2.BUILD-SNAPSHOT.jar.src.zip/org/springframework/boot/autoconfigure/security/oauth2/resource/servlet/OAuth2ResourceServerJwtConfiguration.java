/*     */ package org.springframework.boot.autoconfigure.security.oauth2.resource.servlet;
/*     */ 
/*     */ import java.security.KeyFactory;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Base64;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.security.oauth2.resource.IssuerUriCondition;
/*     */ import org.springframework.boot.autoconfigure.security.oauth2.resource.KeyValueCondition;
/*     */ import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*     */ import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;
/*     */ import org.springframework.security.oauth2.jwt.JwtDecoder;
/*     */ import org.springframework.security.oauth2.jwt.JwtDecoders;
/*     */ import org.springframework.security.oauth2.jwt.JwtValidators;
/*     */ import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class OAuth2ResourceServerJwtConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({JwtDecoder.class})
/*     */   static class JwtDecoderConfiguration
/*     */   {
/*     */     private final OAuth2ResourceServerProperties.Jwt properties;
/*     */     
/*     */     JwtDecoderConfiguration(OAuth2ResourceServerProperties properties) {
/*  61 */       this.properties = properties.getJwt();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnProperty(name = {"spring.security.oauth2.resourceserver.jwt.jwk-set-uri"})
/*     */     JwtDecoder jwtDecoderByJwkKeySetUri() {
/*  68 */       NimbusJwtDecoder nimbusJwtDecoder = NimbusJwtDecoder.withJwkSetUri(this.properties.getJwkSetUri()).jwsAlgorithm(SignatureAlgorithm.from(this.properties.getJwsAlgorithm())).build();
/*  69 */       String issuerUri = this.properties.getIssuerUri();
/*  70 */       if (issuerUri != null) {
/*  71 */         nimbusJwtDecoder.setJwtValidator(JwtValidators.createDefaultWithIssuer(issuerUri));
/*     */       }
/*  73 */       return (JwtDecoder)nimbusJwtDecoder;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @Conditional({KeyValueCondition.class})
/*     */     JwtDecoder jwtDecoderByPublicKeyValue() throws Exception {
/*  80 */       RSAPublicKey publicKey = (RSAPublicKey)KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(getKeySpec(this.properties.readPublicKey())));
/*  81 */       return (JwtDecoder)NimbusJwtDecoder.withPublicKey(publicKey).build();
/*     */     }
/*     */     
/*     */     private byte[] getKeySpec(String keyValue) {
/*  85 */       keyValue = keyValue.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "");
/*  86 */       return Base64.getMimeDecoder().decode(keyValue);
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @Conditional({IssuerUriCondition.class})
/*     */     JwtDecoder jwtDecoderByIssuerUri() {
/*  92 */       return JwtDecoders.fromIssuerLocation(this.properties.getIssuerUri());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({WebSecurityConfigurerAdapter.class})
/*     */   static class OAuth2WebSecurityConfigurerAdapter
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnBean({JwtDecoder.class})
/*     */     WebSecurityConfigurerAdapter jwtDecoderWebSecurityConfigurerAdapter() {
/* 104 */       return new WebSecurityConfigurerAdapter()
/*     */         {
/*     */           protected void configure(HttpSecurity http) throws Exception
/*     */           {
/* 108 */             http.authorizeRequests(requests -> ((ExpressionUrlAuthorizationConfigurer.AuthorizedUrl)requests.anyRequest()).authenticated());
/* 109 */             http.oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt);
/*     */           }
/*     */         };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\servlet\OAuth2ResourceServerJwtConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
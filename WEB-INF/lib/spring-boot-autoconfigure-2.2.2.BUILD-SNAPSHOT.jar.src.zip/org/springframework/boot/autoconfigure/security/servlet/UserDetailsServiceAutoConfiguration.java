/*    */ package org.springframework.boot.autoconfigure.security.servlet;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.security.SecurityProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Lazy;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*    */ import org.springframework.security.core.userdetails.User;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.crypto.password.PasswordEncoder;
/*    */ import org.springframework.security.provisioning.InMemoryUserDetailsManager;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({AuthenticationManager.class})
/*    */ @ConditionalOnBean({ObjectPostProcessor.class})
/*    */ @ConditionalOnMissingBean(value = {AuthenticationManager.class, AuthenticationProvider.class, UserDetailsService.class}, type = {"org.springframework.security.oauth2.jwt.JwtDecoder", "org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector"})
/*    */ public class UserDetailsServiceAutoConfiguration
/*    */ {
/*    */   private static final String NOOP_PASSWORD_PREFIX = "{noop}";
/* 66 */   private static final Pattern PASSWORD_ALGORITHM_PATTERN = Pattern.compile("^\\{.+}.*$");
/*    */   
/* 68 */   private static final Log logger = LogFactory.getLog(UserDetailsServiceAutoConfiguration.class);
/*    */ 
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(type = {"org.springframework.security.oauth2.client.registration.ClientRegistrationRepository"})
/*    */   @Lazy
/*    */   public InMemoryUserDetailsManager inMemoryUserDetailsManager(SecurityProperties properties, ObjectProvider<PasswordEncoder> passwordEncoder) {
/* 76 */     SecurityProperties.User user = properties.getUser();
/* 77 */     List<String> roles = user.getRoles();
/* 78 */     return new InMemoryUserDetailsManager(new UserDetails[] {
/* 79 */           User.withUsername(user.getName()).password(getOrDeducePassword(user, (PasswordEncoder)passwordEncoder.getIfAvailable()))
/* 80 */           .roles(StringUtils.toStringArray(roles)).build() });
/*    */   }
/*    */   
/*    */   private String getOrDeducePassword(SecurityProperties.User user, PasswordEncoder encoder) {
/* 84 */     String password = user.getPassword();
/* 85 */     if (user.isPasswordGenerated()) {
/* 86 */       logger.info(String.format("%n%nUsing generated security password: %s%n", new Object[] { user.getPassword() }));
/*    */     }
/* 88 */     if (encoder != null || PASSWORD_ALGORITHM_PATTERN.matcher(password).matches()) {
/* 89 */       return password;
/*    */     }
/* 91 */     return "{noop}" + password;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\servlet\UserDetailsServiceAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
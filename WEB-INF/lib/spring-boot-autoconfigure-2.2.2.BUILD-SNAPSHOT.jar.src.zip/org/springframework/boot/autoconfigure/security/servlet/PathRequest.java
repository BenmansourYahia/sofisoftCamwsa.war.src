/*    */ package org.springframework.boot.autoconfigure.security.servlet;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.boot.autoconfigure.h2.H2ConsoleProperties;
/*    */ import org.springframework.boot.security.servlet.ApplicationContextRequestMatcher;
/*    */ import org.springframework.boot.web.context.WebServerApplicationContext;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PathRequest
/*    */ {
/*    */   public static StaticResourceRequest toStaticResources() {
/* 49 */     return StaticResourceRequest.INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static H2ConsoleRequestMatcher toH2Console() {
/* 60 */     return new H2ConsoleRequestMatcher();
/*    */   }
/*    */ 
/*    */   
/*    */   public static final class H2ConsoleRequestMatcher
/*    */     extends ApplicationContextRequestMatcher<H2ConsoleProperties>
/*    */   {
/*    */     private volatile RequestMatcher delegate;
/*    */ 
/*    */     
/*    */     private H2ConsoleRequestMatcher() {
/* 71 */       super(H2ConsoleProperties.class);
/*    */     }
/*    */ 
/*    */     
/*    */     protected boolean ignoreApplicationContext(WebApplicationContext applicationContext) {
/* 76 */       return WebServerApplicationContext.hasServerNamespace((ApplicationContext)applicationContext, "management");
/*    */     }
/*    */ 
/*    */     
/*    */     protected void initialized(Supplier<H2ConsoleProperties> h2ConsoleProperties) {
/* 81 */       this.delegate = (RequestMatcher)new AntPathRequestMatcher(((H2ConsoleProperties)h2ConsoleProperties.get()).getPath() + "/**");
/*    */     }
/*    */ 
/*    */     
/*    */     protected boolean matches(HttpServletRequest request, Supplier<H2ConsoleProperties> context) {
/* 86 */       return this.delegate.matches(request);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\servlet\PathRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
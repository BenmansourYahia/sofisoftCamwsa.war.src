/*    */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IssuerUriCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 37 */     ConditionMessage.Builder message = ConditionMessage.forCondition("OpenID Connect Issuer URI Condition", new Object[0]);
/* 38 */     Environment environment = context.getEnvironment();
/* 39 */     String issuerUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.issuer-uri");
/* 40 */     String jwkSetUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.jwk-set-uri");
/* 41 */     if (!StringUtils.hasText(issuerUri)) {
/* 42 */       return ConditionOutcome.noMatch(message.didNotFind("issuer-uri property").atAll());
/*    */     }
/* 44 */     if (StringUtils.hasText(jwkSetUri)) {
/* 45 */       return ConditionOutcome.noMatch(message.found("jwk-set-uri property").items(new Object[] { jwkSetUri }));
/*    */     }
/* 47 */     return ConditionOutcome.match(message.foundExactly("issuer-uri property"));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\IssuerUriCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.security.oauth2.client;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrations;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OAuth2ClientPropertiesRegistrationAdapter
/*     */ {
/*     */   public static Map<String, ClientRegistration> getClientRegistrations(OAuth2ClientProperties properties) {
/*  51 */     Map<String, ClientRegistration> clientRegistrations = new HashMap<>();
/*  52 */     properties.getRegistration().forEach((key, value) -> (ClientRegistration)clientRegistrations.put(key, getClientRegistration(key, value, properties.getProvider())));
/*     */     
/*  54 */     return clientRegistrations;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClientRegistration getClientRegistration(String registrationId, OAuth2ClientProperties.Registration properties, Map<String, OAuth2ClientProperties.Provider> providers) {
/*  59 */     ClientRegistration.Builder builder = getBuilderFromIssuerIfPossible(registrationId, properties.getProvider(), providers);
/*  60 */     if (builder == null) {
/*  61 */       builder = getBuilder(registrationId, properties.getProvider(), providers);
/*     */     }
/*  63 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  64 */     map.from(properties::getClientId).to(builder::clientId);
/*  65 */     map.from(properties::getClientSecret).to(builder::clientSecret);
/*  66 */     map.from(properties::getClientAuthenticationMethod).as(org.springframework.security.oauth2.core.ClientAuthenticationMethod::new)
/*  67 */       .to(builder::clientAuthenticationMethod);
/*  68 */     map.from(properties::getAuthorizationGrantType).as(org.springframework.security.oauth2.core.AuthorizationGrantType::new)
/*  69 */       .to(builder::authorizationGrantType);
/*  70 */     map.from(properties::getRedirectUri).to(builder::redirectUriTemplate);
/*  71 */     map.from(properties::getScope).as(StringUtils::toStringArray).to(builder::scope);
/*  72 */     map.from(properties::getClientName).to(builder::clientName);
/*  73 */     return builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClientRegistration.Builder getBuilderFromIssuerIfPossible(String registrationId, String configuredProviderId, Map<String, OAuth2ClientProperties.Provider> providers) {
/*  78 */     String providerId = (configuredProviderId != null) ? configuredProviderId : registrationId;
/*  79 */     if (providers.containsKey(providerId)) {
/*  80 */       OAuth2ClientProperties.Provider provider = providers.get(providerId);
/*  81 */       String issuer = provider.getIssuerUri();
/*  82 */       if (issuer != null) {
/*  83 */         ClientRegistration.Builder builder = ClientRegistrations.fromIssuerLocation(issuer).registrationId(registrationId);
/*  84 */         return getBuilder(builder, provider);
/*     */       } 
/*     */     } 
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClientRegistration.Builder getBuilder(String registrationId, String configuredProviderId, Map<String, OAuth2ClientProperties.Provider> providers) {
/*  92 */     String providerId = (configuredProviderId != null) ? configuredProviderId : registrationId;
/*  93 */     CommonOAuth2Provider provider = getCommonProvider(providerId);
/*  94 */     if (provider == null && !providers.containsKey(providerId)) {
/*  95 */       throw new IllegalStateException(getErrorMessage(configuredProviderId, registrationId));
/*     */     }
/*     */     
/*  98 */     ClientRegistration.Builder builder = (provider != null) ? provider.getBuilder(registrationId) : ClientRegistration.withRegistrationId(registrationId);
/*  99 */     if (providers.containsKey(providerId)) {
/* 100 */       return getBuilder(builder, providers.get(providerId));
/*     */     }
/* 102 */     return builder;
/*     */   }
/*     */   
/*     */   private static String getErrorMessage(String configuredProviderId, String registrationId) {
/* 106 */     return (configuredProviderId != null) ? ("Unknown provider ID '" + configuredProviderId + "'") : ("Provider ID must be specified for client registration '" + registrationId + "'");
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClientRegistration.Builder getBuilder(ClientRegistration.Builder builder, OAuth2ClientProperties.Provider provider) {
/* 111 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 112 */     map.from(provider::getAuthorizationUri).to(builder::authorizationUri);
/* 113 */     map.from(provider::getTokenUri).to(builder::tokenUri);
/* 114 */     map.from(provider::getUserInfoUri).to(builder::userInfoUri);
/* 115 */     map.from(provider::getUserInfoAuthenticationMethod).as(org.springframework.security.oauth2.core.AuthenticationMethod::new)
/* 116 */       .to(builder::userInfoAuthenticationMethod);
/* 117 */     map.from(provider::getJwkSetUri).to(builder::jwkSetUri);
/* 118 */     map.from(provider::getUserNameAttribute).to(builder::userNameAttributeName);
/* 119 */     return builder;
/*     */   }
/*     */   
/*     */   private static CommonOAuth2Provider getCommonProvider(String providerId) {
/*     */     try {
/* 124 */       return (CommonOAuth2Provider)ApplicationConversionService.getSharedInstance().convert(providerId, CommonOAuth2Provider.class);
/*     */     }
/* 126 */     catch (ConversionException ex) {
/* 127 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\OAuth2ClientPropertiesRegistrationAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.security.servlet;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.web.servlet.JerseyApplicationPath;
/*    */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class JerseyRequestMatcherProvider
/*    */   implements RequestMatcherProvider
/*    */ {
/*    */   private final JerseyApplicationPath jerseyApplicationPath;
/*    */   
/*    */   public JerseyRequestMatcherProvider(JerseyApplicationPath jerseyApplicationPath) {
/* 36 */     this.jerseyApplicationPath = jerseyApplicationPath;
/*    */   }
/*    */ 
/*    */   
/*    */   public RequestMatcher getRequestMatcher(String pattern) {
/* 41 */     return (RequestMatcher)new AntPathRequestMatcher(this.jerseyApplicationPath.getRelativePath(pattern));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\servlet\JerseyRequestMatcherProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.security.oauth2.client.reactive;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.client.ClientsConfiguredCondition;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.client.OAuth2ClientProperties;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.client.OAuth2ClientPropertiesRegistrationAdapter;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.web.server.ServerHttpSecurity;
/*    */ import org.springframework.security.oauth2.client.InMemoryReactiveOAuth2AuthorizedClientService;
/*    */ import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientService;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*    */ import org.springframework.security.oauth2.client.registration.InMemoryReactiveClientRegistrationRepository;
/*    */ import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
/*    */ import org.springframework.security.oauth2.client.web.server.AuthenticatedPrincipalServerOAuth2AuthorizedClientRepository;
/*    */ import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository;
/*    */ import org.springframework.security.web.server.SecurityWebFilterChain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveOAuth2ClientConfigurations
/*    */ {
/*    */   @Configuration
/*    */   @Conditional({ClientsConfiguredCondition.class})
/*    */   @ConditionalOnMissingBean({ReactiveClientRegistrationRepository.class})
/*    */   static class ReactiveClientRegistrationRepositoryConfiguration
/*    */   {
/*    */     @Bean
/*    */     InMemoryReactiveClientRegistrationRepository clientRegistrationRepository(OAuth2ClientProperties properties) {
/* 56 */       List<ClientRegistration> registrations = new ArrayList<>(OAuth2ClientPropertiesRegistrationAdapter.getClientRegistrations(properties).values());
/* 57 */       return new InMemoryReactiveClientRegistrationRepository(registrations);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Configuration
/*    */   @ConditionalOnBean({ReactiveClientRegistrationRepository.class})
/*    */   static class ReactiveOAuth2ClientConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     ReactiveOAuth2AuthorizedClientService authorizedClientService(ReactiveClientRegistrationRepository clientRegistrationRepository) {
/* 70 */       return (ReactiveOAuth2AuthorizedClientService)new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrationRepository);
/*    */     }
/*    */ 
/*    */     
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     ServerOAuth2AuthorizedClientRepository authorizedClientRepository(ReactiveOAuth2AuthorizedClientService authorizedClientService) {
/* 77 */       return (ServerOAuth2AuthorizedClientRepository)new AuthenticatedPrincipalServerOAuth2AuthorizedClientRepository(authorizedClientService);
/*    */     }
/*    */     
/*    */     @Configuration
/*    */     @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*    */     static class SecurityWebFilterChainConfiguration
/*    */     {
/*    */       @Bean
/*    */       @ConditionalOnMissingBean
/*    */       SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
/* 87 */         http.authorizeExchange().anyExchange().authenticated();
/* 88 */         http.oauth2Login();
/* 89 */         http.oauth2Client();
/* 90 */         return http.build();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\reactive\ReactiveOAuth2ClientConfigurations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
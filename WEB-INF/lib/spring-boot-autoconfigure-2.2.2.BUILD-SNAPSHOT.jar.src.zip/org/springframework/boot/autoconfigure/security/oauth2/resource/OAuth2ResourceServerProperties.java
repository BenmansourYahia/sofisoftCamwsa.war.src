/*     */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import javax.annotation.PostConstruct;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.security.oauth2.resourceserver")
/*     */ public class OAuth2ResourceServerProperties
/*     */ {
/*  40 */   private final Jwt jwt = new Jwt();
/*     */   
/*     */   public Jwt getJwt() {
/*  43 */     return this.jwt;
/*     */   }
/*     */   
/*  46 */   private final Opaquetoken opaqueToken = new Opaquetoken();
/*     */   
/*     */   public Opaquetoken getOpaquetoken() {
/*  49 */     return this.opaqueToken;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void validate() {
/*  54 */     if (getOpaquetoken().getIntrospectionUri() != null) {
/*  55 */       if (getJwt().getJwkSetUri() != null) {
/*  56 */         handleError("jwt.jwk-set-uri");
/*     */       }
/*  58 */       if (getJwt().getIssuerUri() != null) {
/*  59 */         handleError("jwt.issuer-uri");
/*     */       }
/*  61 */       if (getJwt().getPublicKeyLocation() != null) {
/*  62 */         handleError("jwt.public-key-location");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleError(String property) {
/*  68 */     throw new IllegalStateException("Only one of " + property + " and opaquetoken.introspection-uri should be configured.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Jwt
/*     */   {
/*     */     private String jwkSetUri;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     private String jwsAlgorithm = "RS256";
/*     */ 
/*     */ 
/*     */     
/*     */     private String issuerUri;
/*     */ 
/*     */ 
/*     */     
/*     */     private Resource publicKeyLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getJwkSetUri() {
/*  96 */       return this.jwkSetUri;
/*     */     }
/*     */     
/*     */     public void setJwkSetUri(String jwkSetUri) {
/* 100 */       this.jwkSetUri = jwkSetUri;
/*     */     }
/*     */     
/*     */     public String getJwsAlgorithm() {
/* 104 */       return this.jwsAlgorithm;
/*     */     }
/*     */     
/*     */     public void setJwsAlgorithm(String jwsAlgorithm) {
/* 108 */       this.jwsAlgorithm = jwsAlgorithm;
/*     */     }
/*     */     
/*     */     public String getIssuerUri() {
/* 112 */       return this.issuerUri;
/*     */     }
/*     */     
/*     */     public void setIssuerUri(String issuerUri) {
/* 116 */       this.issuerUri = issuerUri;
/*     */     }
/*     */     
/*     */     public Resource getPublicKeyLocation() {
/* 120 */       return this.publicKeyLocation;
/*     */     }
/*     */     
/*     */     public void setPublicKeyLocation(Resource publicKeyLocation) {
/* 124 */       this.publicKeyLocation = publicKeyLocation;
/*     */     }
/*     */     
/*     */     public String readPublicKey() throws IOException {
/* 128 */       String key = "spring.security.oauth2.resourceserver.public-key-location";
/* 129 */       Assert.notNull(this.publicKeyLocation, "PublicKeyLocation must not be null");
/* 130 */       if (!this.publicKeyLocation.exists()) {
/* 131 */         throw new InvalidConfigurationPropertyValueException(key, this.publicKeyLocation, "Public key location does not exist");
/*     */       }
/*     */       
/* 134 */       try (InputStream inputStream = this.publicKeyLocation.getInputStream()) {
/* 135 */         return StreamUtils.copyToString(inputStream, StandardCharsets.UTF_8);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Opaquetoken
/*     */   {
/*     */     private String clientId;
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientSecret;
/*     */ 
/*     */ 
/*     */     
/*     */     private String introspectionUri;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getClientId() {
/* 159 */       return this.clientId;
/*     */     }
/*     */     
/*     */     public void setClientId(String clientId) {
/* 163 */       this.clientId = clientId;
/*     */     }
/*     */     
/*     */     public String getClientSecret() {
/* 167 */       return this.clientSecret;
/*     */     }
/*     */     
/*     */     public void setClientSecret(String clientSecret) {
/* 171 */       this.clientSecret = clientSecret;
/*     */     }
/*     */     
/*     */     public String getIntrospectionUri() {
/* 175 */       return this.introspectionUri;
/*     */     }
/*     */     
/*     */     public void setIntrospectionUri(String introspectionUri) {
/* 179 */       this.introspectionUri = introspectionUri;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\OAuth2ResourceServerProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.security.oauth2.client.servlet;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.Customizer;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
/*    */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
/*    */ import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
/*    */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*    */ import org.springframework.security.oauth2.client.web.AuthenticatedPrincipalOAuth2AuthorizedClientRepository;
/*    */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnBean({ClientRegistrationRepository.class})
/*    */ class OAuth2WebSecurityConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   OAuth2AuthorizedClientService authorizedClientService(ClientRegistrationRepository clientRegistrationRepository) {
/* 45 */     return (OAuth2AuthorizedClientService)new InMemoryOAuth2AuthorizedClientService(clientRegistrationRepository);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   OAuth2AuthorizedClientRepository authorizedClientRepository(OAuth2AuthorizedClientService authorizedClientService) {
/* 51 */     return (OAuth2AuthorizedClientRepository)new AuthenticatedPrincipalOAuth2AuthorizedClientRepository(authorizedClientService);
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({WebSecurityConfigurerAdapter.class})
/*    */   static class OAuth2WebSecurityConfigurerAdapter
/*    */     extends WebSecurityConfigurerAdapter
/*    */   {
/*    */     protected void configure(HttpSecurity http) throws Exception {
/* 60 */       http.authorizeRequests(requests -> ((ExpressionUrlAuthorizationConfigurer.AuthorizedUrl)requests.anyRequest()).authenticated());
/* 61 */       http.oauth2Login(Customizer.withDefaults());
/* 62 */       http.oauth2Client();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\servlet\OAuth2WebSecurityConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
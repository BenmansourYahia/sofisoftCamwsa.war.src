/*     */ package org.springframework.boot.autoconfigure.security.saml2;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.security.converter.RsaKeyConverters;
/*     */ import org.springframework.security.saml2.credentials.Saml2X509Credential;
/*     */ import org.springframework.security.saml2.provider.service.registration.InMemoryRelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistration;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @Conditional({RegistrationConfiguredCondition.class})
/*     */ @ConditionalOnMissingBean({RelyingPartyRegistrationRepository.class})
/*     */ class Saml2RelyingPartyRegistrationConfiguration
/*     */ {
/*     */   @Bean
/*     */   RelyingPartyRegistrationRepository relyingPartyRegistrationRepository(Saml2RelyingPartyProperties properties) {
/*  60 */     List<RelyingPartyRegistration> registrations = (List<RelyingPartyRegistration>)properties.getRegistration().entrySet().stream().map(this::asRegistration).collect(Collectors.toList());
/*  61 */     return (RelyingPartyRegistrationRepository)new InMemoryRelyingPartyRegistrationRepository(registrations);
/*     */   }
/*     */   
/*     */   private RelyingPartyRegistration asRegistration(Map.Entry<String, Saml2RelyingPartyProperties.Registration> entry) {
/*  65 */     return asRegistration(entry.getKey(), entry.getValue());
/*     */   }
/*     */   
/*     */   private RelyingPartyRegistration asRegistration(String id, Saml2RelyingPartyProperties.Registration properties) {
/*  69 */     RelyingPartyRegistration.Builder builder = RelyingPartyRegistration.withRegistrationId(id);
/*  70 */     builder.assertionConsumerServiceUrlTemplate("{baseUrl}/login/saml2/sso/{registrationId}");
/*     */     
/*  72 */     builder.idpWebSsoUrl(properties.getIdentityprovider().getSsoUrl());
/*  73 */     builder.remoteIdpEntityId(properties.getIdentityprovider().getEntityId());
/*  74 */     builder.credentials(credentials -> credentials.addAll(asCredentials(properties)));
/*  75 */     return builder.build();
/*     */   }
/*     */   
/*     */   private List<Saml2X509Credential> asCredentials(Saml2RelyingPartyProperties.Registration properties) {
/*  79 */     List<Saml2X509Credential> credentials = new ArrayList<>();
/*  80 */     properties.getSigning().getCredentials().stream().map(this::asSigningCredential).forEach(credentials::add);
/*  81 */     properties.getIdentityprovider().getVerification().getCredentials().stream().map(this::asVerificationCredential)
/*  82 */       .forEach(credentials::add);
/*  83 */     return credentials;
/*     */   }
/*     */   
/*     */   private Saml2X509Credential asSigningCredential(Saml2RelyingPartyProperties.Registration.Signing.Credential properties) {
/*  87 */     RSAPrivateKey privateKey = readPrivateKey(properties.getPrivateKeyLocation());
/*  88 */     X509Certificate certificate = readCertificate(properties.getCertificateLocation());
/*  89 */     return new Saml2X509Credential(privateKey, certificate, new Saml2X509Credential.Saml2X509CredentialType[] { Saml2X509Credential.Saml2X509CredentialType.SIGNING, Saml2X509Credential.Saml2X509CredentialType.DECRYPTION });
/*     */   }
/*     */ 
/*     */   
/*     */   private Saml2X509Credential asVerificationCredential(Saml2RelyingPartyProperties.Identityprovider.Verification.Credential properties) {
/*  94 */     X509Certificate certificate = readCertificate(properties.getCertificateLocation());
/*  95 */     return new Saml2X509Credential(certificate, new Saml2X509Credential.Saml2X509CredentialType[] { Saml2X509Credential.Saml2X509CredentialType.ENCRYPTION, Saml2X509Credential.Saml2X509CredentialType.VERIFICATION });
/*     */   }
/*     */ 
/*     */   
/*     */   private RSAPrivateKey readPrivateKey(Resource location) {
/* 100 */     Assert.state((location != null), "No private key location specified");
/* 101 */     Assert.state(location.exists(), "Private key location '" + location + "' does not exist");
/* 102 */     try (InputStream inputStream = location.getInputStream()) {
/* 103 */       return (RSAPrivateKey)RsaKeyConverters.pkcs8().convert(inputStream);
/*     */     }
/* 105 */     catch (Exception ex) {
/* 106 */       throw new IllegalArgumentException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private X509Certificate readCertificate(Resource location) {
/* 111 */     Assert.state((location != null), "No certificate location specified");
/* 112 */     Assert.state(location.exists(), "Certificate  location '" + location + "' does not exist");
/* 113 */     try (InputStream inputStream = location.getInputStream()) {
/* 114 */       return (X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate(inputStream);
/*     */     }
/* 116 */     catch (Exception ex) {
/* 117 */       throw new IllegalArgumentException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\saml2\Saml2RelyingPartyRegistrationConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
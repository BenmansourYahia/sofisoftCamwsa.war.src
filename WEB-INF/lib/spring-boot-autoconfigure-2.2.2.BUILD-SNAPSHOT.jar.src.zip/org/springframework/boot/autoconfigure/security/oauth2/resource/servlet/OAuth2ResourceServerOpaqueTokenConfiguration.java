/*    */ package org.springframework.boot.autoconfigure.security.oauth2.resource.servlet;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
/*    */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.NimbusOpaqueTokenIntrospector;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class OAuth2ResourceServerOpaqueTokenConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({OpaqueTokenIntrospector.class})
/*    */   static class OpaqueTokenIntrospectionClientConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnProperty(name = {"spring.security.oauth2.resourceserver.opaquetoken.introspection-uri"})
/*    */     NimbusOpaqueTokenIntrospector opaqueTokenIntrospector(OAuth2ResourceServerProperties properties) {
/* 47 */       OAuth2ResourceServerProperties.Opaquetoken opaqueToken = properties.getOpaquetoken();
/* 48 */       return new NimbusOpaqueTokenIntrospector(opaqueToken.getIntrospectionUri(), opaqueToken.getClientId(), opaqueToken
/* 49 */           .getClientSecret());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({WebSecurityConfigurerAdapter.class})
/*    */   static class OAuth2WebSecurityConfigurerAdapter
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnBean({OpaqueTokenIntrospector.class})
/*    */     WebSecurityConfigurerAdapter opaqueTokenWebSecurityConfigurerAdapter() {
/* 61 */       return new WebSecurityConfigurerAdapter()
/*    */         {
/*    */           protected void configure(HttpSecurity http) throws Exception
/*    */           {
/* 65 */             http.authorizeRequests(requests -> ((ExpressionUrlAuthorizationConfigurer.AuthorizedUrl)requests.anyRequest()).authenticated());
/* 66 */             http.oauth2ResourceServer(OAuth2ResourceServerConfigurer::opaqueToken);
/*    */           }
/*    */         };
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\servlet\OAuth2ResourceServerOpaqueTokenConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
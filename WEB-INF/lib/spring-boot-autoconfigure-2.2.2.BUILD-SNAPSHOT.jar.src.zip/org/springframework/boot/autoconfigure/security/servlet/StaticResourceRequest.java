/*     */ package org.springframework.boot.autoconfigure.security.servlet;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.boot.autoconfigure.security.StaticResourceLocation;
/*     */ import org.springframework.boot.autoconfigure.web.servlet.DispatcherServletPath;
/*     */ import org.springframework.boot.security.servlet.ApplicationContextRequestMatcher;
/*     */ import org.springframework.boot.web.context.WebServerApplicationContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StaticResourceRequest
/*     */ {
/*  50 */   static final StaticResourceRequest INSTANCE = new StaticResourceRequest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticResourceRequestMatcher atCommonLocations() {
/*  66 */     return at(EnumSet.allOf(StaticResourceLocation.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticResourceRequestMatcher at(StaticResourceLocation first, StaticResourceLocation... rest) {
/*  79 */     return at(EnumSet.of(first, rest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticResourceRequestMatcher at(Set<StaticResourceLocation> locations) {
/*  91 */     Assert.notNull(locations, "Locations must not be null");
/*  92 */     return new StaticResourceRequestMatcher(new LinkedHashSet<>(locations));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class StaticResourceRequestMatcher
/*     */     extends ApplicationContextRequestMatcher<DispatcherServletPath>
/*     */   {
/*     */     private final Set<StaticResourceLocation> locations;
/*     */ 
/*     */     
/*     */     private volatile RequestMatcher delegate;
/*     */ 
/*     */     
/*     */     private StaticResourceRequestMatcher(Set<StaticResourceLocation> locations) {
/* 107 */       super(DispatcherServletPath.class);
/* 108 */       this.locations = locations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StaticResourceRequestMatcher excluding(StaticResourceLocation first, StaticResourceLocation... rest) {
/* 119 */       return excluding(EnumSet.of(first, rest));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StaticResourceRequestMatcher excluding(Set<StaticResourceLocation> locations) {
/* 129 */       Assert.notNull(locations, "Locations must not be null");
/* 130 */       Set<StaticResourceLocation> subset = new LinkedHashSet<>(this.locations);
/* 131 */       subset.removeAll(locations);
/* 132 */       return new StaticResourceRequestMatcher(subset);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initialized(Supplier<DispatcherServletPath> dispatcherServletPath) {
/* 137 */       this.delegate = (RequestMatcher)new OrRequestMatcher(getDelegateMatchers(dispatcherServletPath.get()));
/*     */     }
/*     */     
/*     */     private List<RequestMatcher> getDelegateMatchers(DispatcherServletPath dispatcherServletPath) {
/* 141 */       return (List<RequestMatcher>)getPatterns(dispatcherServletPath).map(org.springframework.security.web.util.matcher.AntPathRequestMatcher::new).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private Stream<String> getPatterns(DispatcherServletPath dispatcherServletPath) {
/* 145 */       return this.locations.stream().flatMap(StaticResourceLocation::getPatterns)
/* 146 */         .map(dispatcherServletPath::getRelativePath);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean ignoreApplicationContext(WebApplicationContext applicationContext) {
/* 151 */       return WebServerApplicationContext.hasServerNamespace((ApplicationContext)applicationContext, "management");
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matches(HttpServletRequest request, Supplier<DispatcherServletPath> context) {
/* 156 */       return this.delegate.matches(request);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\servlet\StaticResourceRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.security.oauth2.resource.reactive;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.web.server.ServerHttpSecurity;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.NimbusReactiveOpaqueTokenIntrospector;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.ReactiveOpaqueTokenIntrospector;
/*    */ import org.springframework.security.web.server.SecurityWebFilterChain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveOAuth2ResourceServerOpaqueTokenConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({ReactiveOpaqueTokenIntrospector.class})
/*    */   static class OpaqueTokenIntrospectionClientConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnProperty(name = {"spring.security.oauth2.resourceserver.opaquetoken.introspection-uri"})
/*    */     NimbusReactiveOpaqueTokenIntrospector opaqueTokenIntrospector(OAuth2ResourceServerProperties properties) {
/* 47 */       OAuth2ResourceServerProperties.Opaquetoken opaqueToken = properties.getOpaquetoken();
/* 48 */       return new NimbusReactiveOpaqueTokenIntrospector(opaqueToken.getIntrospectionUri(), opaqueToken
/* 49 */           .getClientId(), opaqueToken.getClientSecret());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({SecurityWebFilterChain.class})
/*    */   static class WebSecurityConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnBean({ReactiveOpaqueTokenIntrospector.class})
/*    */     SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
/* 61 */       http.authorizeExchange(exchanges -> exchanges.anyExchange().authenticated());
/* 62 */       http.oauth2ResourceServer(ServerHttpSecurity.OAuth2ResourceServerSpec::opaqueToken);
/* 63 */       return http.build();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\reactive\ReactiveOAuth2ResourceServerOpaqueTokenConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
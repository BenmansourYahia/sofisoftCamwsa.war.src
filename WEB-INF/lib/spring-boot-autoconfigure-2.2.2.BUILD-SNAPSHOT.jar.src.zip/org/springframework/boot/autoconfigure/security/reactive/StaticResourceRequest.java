/*     */ package org.springframework.boot.autoconfigure.security.reactive;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.autoconfigure.security.StaticResourceLocation;
/*     */ import org.springframework.security.web.server.util.matcher.OrServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StaticResourceRequest
/*     */ {
/*  45 */   static final StaticResourceRequest INSTANCE = new StaticResourceRequest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticResourceServerWebExchange atCommonLocations() {
/*  61 */     return at(EnumSet.allOf(StaticResourceLocation.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticResourceServerWebExchange at(StaticResourceLocation first, StaticResourceLocation... rest) {
/*  74 */     return at(EnumSet.of(first, rest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticResourceServerWebExchange at(Set<StaticResourceLocation> locations) {
/*  86 */     Assert.notNull(locations, "Locations must not be null");
/*  87 */     return new StaticResourceServerWebExchange(new LinkedHashSet<>(locations));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class StaticResourceServerWebExchange
/*     */     implements ServerWebExchangeMatcher
/*     */   {
/*     */     private final Set<StaticResourceLocation> locations;
/*     */ 
/*     */     
/*     */     private StaticResourceServerWebExchange(Set<StaticResourceLocation> locations) {
/*  99 */       this.locations = locations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StaticResourceServerWebExchange excluding(StaticResourceLocation first, StaticResourceLocation... rest) {
/* 110 */       return excluding(EnumSet.of(first, rest));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StaticResourceServerWebExchange excluding(Set<StaticResourceLocation> locations) {
/* 120 */       Assert.notNull(locations, "Locations must not be null");
/* 121 */       Set<StaticResourceLocation> subset = new LinkedHashSet<>(this.locations);
/* 122 */       subset.removeAll(locations);
/* 123 */       return new StaticResourceServerWebExchange(subset);
/*     */     }
/*     */     
/*     */     private List<ServerWebExchangeMatcher> getDelegateMatchers() {
/* 127 */       return (List<ServerWebExchangeMatcher>)getPatterns().map(org.springframework.security.web.server.util.matcher.PathPatternParserServerWebExchangeMatcher::new).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private Stream<String> getPatterns() {
/* 131 */       return this.locations.stream().flatMap(StaticResourceLocation::getPatterns);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 136 */       OrServerWebExchangeMatcher matcher = new OrServerWebExchangeMatcher(getDelegateMatchers());
/* 137 */       return matcher.matches(exchange);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\reactive\StaticResourceRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
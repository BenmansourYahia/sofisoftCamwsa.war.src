/*     */ package org.springframework.boot.autoconfigure.security.saml2;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.security.saml2.relyingparty")
/*     */ public class Saml2RelyingPartyProperties
/*     */ {
/*  40 */   private Map<String, Registration> registration = new LinkedHashMap<>();
/*     */   
/*     */   public Map<String, Registration> getRegistration() {
/*  43 */     return this.registration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Registration
/*     */   {
/*  51 */     private final Signing signing = new Signing();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     private Saml2RelyingPartyProperties.Identityprovider identityprovider = new Saml2RelyingPartyProperties.Identityprovider();
/*     */     
/*     */     public Signing getSigning() {
/*  59 */       return this.signing;
/*     */     }
/*     */     
/*     */     Saml2RelyingPartyProperties.Identityprovider getIdentityprovider() {
/*  63 */       return this.identityprovider;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Signing
/*     */     {
/*  72 */       private List<Credential> credentials = new ArrayList<>();
/*     */       
/*     */       public List<Credential> getCredentials() {
/*  75 */         return this.credentials;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public static class Credential
/*     */       {
/*     */         private Resource privateKeyLocation;
/*     */ 
/*     */         
/*     */         private Resource certificateLocation;
/*     */ 
/*     */ 
/*     */         
/*     */         public Resource getPrivateKeyLocation() {
/*  91 */           return this.privateKeyLocation;
/*     */         }
/*     */         
/*     */         public void setPrivateKeyLocation(Resource privateKey) {
/*  95 */           this.privateKeyLocation = privateKey;
/*     */         }
/*     */         
/*     */         public Resource getCertificateLocation() {
/*  99 */           return this.certificateLocation;
/*     */         }
/*     */         
/*     */         public void setCertificateLocation(Resource certificate) {
/* 103 */           this.certificateLocation = certificate;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Identityprovider
/*     */   {
/*     */     private String entityId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String ssoUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     private Verification verification = new Verification();
/*     */     
/*     */     public String getEntityId() {
/* 130 */       return this.entityId;
/*     */     }
/*     */     
/*     */     public void setEntityId(String entityId) {
/* 134 */       this.entityId = entityId;
/*     */     }
/*     */     
/*     */     public String getSsoUrl() {
/* 138 */       return this.ssoUrl;
/*     */     }
/*     */     
/*     */     public void setSsoUrl(String ssoUrl) {
/* 142 */       this.ssoUrl = ssoUrl;
/*     */     }
/*     */     
/*     */     public Verification getVerification() {
/* 146 */       return this.verification;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Verification
/*     */     {
/* 154 */       private List<Credential> credentials = new ArrayList<>();
/*     */       
/*     */       public List<Credential> getCredentials() {
/* 157 */         return this.credentials;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public static class Credential
/*     */       {
/*     */         private Resource certificate;
/*     */ 
/*     */ 
/*     */         
/*     */         public Resource getCertificateLocation() {
/* 169 */           return this.certificate;
/*     */         }
/*     */         
/*     */         public void setCertificateLocation(Resource certificate) {
/* 173 */           this.certificate = certificate;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\saml2\Saml2RelyingPartyProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
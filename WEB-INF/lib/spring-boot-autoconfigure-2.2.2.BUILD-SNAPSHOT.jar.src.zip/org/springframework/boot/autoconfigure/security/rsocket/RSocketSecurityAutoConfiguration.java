/*    */ package org.springframework.boot.autoconfigure.security.rsocket;
/*    */ 
/*    */ import io.rsocket.RSocketFactory;
/*    */ import io.rsocket.plugins.SocketAcceptorInterceptor;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.rsocket.server.ServerRSocketFactoryProcessor;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.annotation.rsocket.EnableRSocketSecurity;
/*    */ import org.springframework.security.rsocket.core.SecuritySocketAcceptorInterceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @EnableRSocketSecurity
/*    */ @ConditionalOnClass({SecuritySocketAcceptorInterceptor.class})
/*    */ public class RSocketSecurityAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   ServerRSocketFactoryProcessor springSecurityRSocketSecurity(SecuritySocketAcceptorInterceptor interceptor) {
/* 41 */     return factory -> factory.addSocketAcceptorPlugin((SocketAcceptorInterceptor)interceptor);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\rsocket\RSocketSecurityAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
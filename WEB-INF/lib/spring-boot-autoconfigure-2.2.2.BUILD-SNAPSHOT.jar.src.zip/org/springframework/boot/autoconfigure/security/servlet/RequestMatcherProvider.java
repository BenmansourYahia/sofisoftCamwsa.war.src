package org.springframework.boot.autoconfigure.security.servlet;

import org.springframework.security.web.util.matcher.RequestMatcher;

@FunctionalInterface
public interface RequestMatcherProvider {
  RequestMatcher getRequestMatcher(String paramString);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\servlet\RequestMatcherProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
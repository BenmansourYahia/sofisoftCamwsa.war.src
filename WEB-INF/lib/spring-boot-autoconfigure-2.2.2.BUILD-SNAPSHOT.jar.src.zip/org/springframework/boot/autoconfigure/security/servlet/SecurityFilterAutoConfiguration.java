/*    */ package org.springframework.boot.autoconfigure.security.servlet;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ import java.util.stream.Collectors;
/*    */ import javax.servlet.DispatcherType;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.security.SecurityProperties;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.web.servlet.DelegatingFilterProxyRegistrationBean;
/*    */ import org.springframework.boot.web.servlet.DispatcherType;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.http.SessionCreationPolicy;
/*    */ import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @EnableConfigurationProperties({SecurityProperties.class})
/*    */ @ConditionalOnClass({AbstractSecurityWebApplicationInitializer.class, SessionCreationPolicy.class})
/*    */ @AutoConfigureAfter({SecurityAutoConfiguration.class})
/*    */ public class SecurityFilterAutoConfiguration
/*    */ {
/*    */   private static final String DEFAULT_FILTER_NAME = "springSecurityFilterChain";
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnBean(name = {"springSecurityFilterChain"})
/*    */   public DelegatingFilterProxyRegistrationBean securityFilterChainRegistration(SecurityProperties securityProperties) {
/* 63 */     DelegatingFilterProxyRegistrationBean registration = new DelegatingFilterProxyRegistrationBean("springSecurityFilterChain", new org.springframework.boot.web.servlet.ServletRegistrationBean[0]);
/*    */     
/* 65 */     registration.setOrder(securityProperties.getFilter().getOrder());
/* 66 */     registration.setDispatcherTypes(getDispatcherTypes(securityProperties));
/* 67 */     return registration;
/*    */   }
/*    */   
/*    */   private EnumSet<DispatcherType> getDispatcherTypes(SecurityProperties securityProperties) {
/* 71 */     if (securityProperties.getFilter().getDispatcherTypes() == null) {
/* 72 */       return null;
/*    */     }
/* 74 */     return (EnumSet<DispatcherType>)securityProperties.getFilter().getDispatcherTypes().stream()
/* 75 */       .map(type -> DispatcherType.valueOf(type.name()))
/* 76 */       .collect(Collectors.collectingAndThen(Collectors.toSet(), EnumSet::copyOf));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\servlet\SecurityFilterAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
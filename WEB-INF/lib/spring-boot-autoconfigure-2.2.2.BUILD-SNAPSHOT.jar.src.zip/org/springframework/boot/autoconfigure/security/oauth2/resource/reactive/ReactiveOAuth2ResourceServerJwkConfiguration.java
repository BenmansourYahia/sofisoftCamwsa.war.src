/*     */ package org.springframework.boot.autoconfigure.security.oauth2.resource.reactive;
/*     */ 
/*     */ import java.security.KeyFactory;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Base64;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.security.oauth2.resource.IssuerUriCondition;
/*     */ import org.springframework.boot.autoconfigure.security.oauth2.resource.KeyValueCondition;
/*     */ import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.security.config.web.server.ServerHttpSecurity;
/*     */ import org.springframework.security.oauth2.jwt.JwtValidators;
/*     */ import org.springframework.security.oauth2.jwt.NimbusReactiveJwtDecoder;
/*     */ import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
/*     */ import org.springframework.security.oauth2.jwt.ReactiveJwtDecoders;
/*     */ import org.springframework.security.web.server.SecurityWebFilterChain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class ReactiveOAuth2ResourceServerJwkConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({ReactiveJwtDecoder.class})
/*     */   static class JwtConfiguration
/*     */   {
/*     */     private final OAuth2ResourceServerProperties.Jwt properties;
/*     */     
/*     */     JwtConfiguration(OAuth2ResourceServerProperties properties) {
/*  59 */       this.properties = properties.getJwt();
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnProperty(name = {"spring.security.oauth2.resourceserver.jwt.jwk-set-uri"})
/*     */     ReactiveJwtDecoder jwtDecoder() {
/*  66 */       NimbusReactiveJwtDecoder nimbusReactiveJwtDecoder = new NimbusReactiveJwtDecoder(this.properties.getJwkSetUri());
/*  67 */       String issuerUri = this.properties.getIssuerUri();
/*  68 */       if (issuerUri != null) {
/*  69 */         nimbusReactiveJwtDecoder.setJwtValidator(JwtValidators.createDefaultWithIssuer(issuerUri));
/*     */       }
/*  71 */       return (ReactiveJwtDecoder)nimbusReactiveJwtDecoder;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @Conditional({KeyValueCondition.class})
/*     */     NimbusReactiveJwtDecoder jwtDecoderByPublicKeyValue() throws Exception {
/*  78 */       RSAPublicKey publicKey = (RSAPublicKey)KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(getKeySpec(this.properties.readPublicKey())));
/*  79 */       return NimbusReactiveJwtDecoder.withPublicKey(publicKey).build();
/*     */     }
/*     */     
/*     */     private byte[] getKeySpec(String keyValue) {
/*  83 */       keyValue = keyValue.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "");
/*  84 */       return Base64.getMimeDecoder().decode(keyValue);
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @Conditional({IssuerUriCondition.class})
/*     */     ReactiveJwtDecoder jwtDecoderByIssuerUri() {
/*  90 */       return ReactiveJwtDecoders.fromIssuerLocation(this.properties.getIssuerUri());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({SecurityWebFilterChain.class})
/*     */   static class WebSecurityConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnBean({ReactiveJwtDecoder.class})
/*     */     SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http, ReactiveJwtDecoder jwtDecoder) {
/* 102 */       http.authorizeExchange(exchanges -> exchanges.anyExchange().authenticated());
/* 103 */       http.oauth2ResourceServer(server -> customDecoder(server, jwtDecoder));
/* 104 */       return http.build();
/*     */     }
/*     */     
/*     */     private void customDecoder(ServerHttpSecurity.OAuth2ResourceServerSpec server, ReactiveJwtDecoder decoder) {
/* 108 */       server.jwt(jwt -> jwt.jwtDecoder(decoder));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\reactive\ReactiveOAuth2ResourceServerJwkConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
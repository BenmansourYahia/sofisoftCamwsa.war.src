/*    */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyValueCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 37 */     ConditionMessage.Builder message = ConditionMessage.forCondition("Public Key Value Condition", new Object[0]);
/* 38 */     Environment environment = context.getEnvironment();
/*    */     
/* 40 */     String publicKeyLocation = environment.getProperty("spring.security.oauth2.resourceserver.jwt.public-key-location");
/* 41 */     if (!StringUtils.hasText(publicKeyLocation)) {
/* 42 */       return ConditionOutcome.noMatch(message.didNotFind("public-key-location property").atAll());
/*    */     }
/* 44 */     String issuerUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.issuer-uri");
/* 45 */     String jwkSetUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.jwk-set-uri");
/* 46 */     if (StringUtils.hasText(jwkSetUri)) {
/* 47 */       return ConditionOutcome.noMatch(message.found("jwk-set-uri property").items(new Object[] { jwkSetUri }));
/*    */     }
/* 49 */     if (StringUtils.hasText(issuerUri)) {
/* 50 */       return ConditionOutcome.noMatch(message.found("issuer-uri property").items(new Object[] { issuerUri }));
/*    */     }
/* 52 */     return ConditionOutcome.match(message.foundExactly("public key location property"));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\KeyValueCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
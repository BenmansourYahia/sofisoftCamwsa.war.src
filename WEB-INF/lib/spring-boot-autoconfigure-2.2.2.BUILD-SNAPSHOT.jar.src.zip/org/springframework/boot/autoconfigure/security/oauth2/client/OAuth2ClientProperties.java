/*     */ package org.springframework.boot.autoconfigure.security.oauth2.client;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.annotation.PostConstruct;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.security.oauth2.client")
/*     */ public class OAuth2ClientProperties
/*     */ {
/*  43 */   private final Map<String, Provider> provider = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private final Map<String, Registration> registration = new HashMap<>();
/*     */   
/*     */   public Map<String, Provider> getProvider() {
/*  51 */     return this.provider;
/*     */   }
/*     */   
/*     */   public Map<String, Registration> getRegistration() {
/*  55 */     return this.registration;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void validate() {
/*  60 */     getRegistration().values().forEach(this::validateRegistration);
/*     */   }
/*     */   
/*     */   private void validateRegistration(Registration registration) {
/*  64 */     if (!StringUtils.hasText(registration.getClientId())) {
/*  65 */       throw new IllegalStateException("Client id must not be empty.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Registration
/*     */   {
/*     */     private String provider;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientId;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientSecret;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientAuthenticationMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String authorizationGrantType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String redirectUri;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Set<String> scope;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProvider() {
/* 118 */       return this.provider;
/*     */     }
/*     */     
/*     */     public void setProvider(String provider) {
/* 122 */       this.provider = provider;
/*     */     }
/*     */     
/*     */     public String getClientId() {
/* 126 */       return this.clientId;
/*     */     }
/*     */     
/*     */     public void setClientId(String clientId) {
/* 130 */       this.clientId = clientId;
/*     */     }
/*     */     
/*     */     public String getClientSecret() {
/* 134 */       return this.clientSecret;
/*     */     }
/*     */     
/*     */     public void setClientSecret(String clientSecret) {
/* 138 */       this.clientSecret = clientSecret;
/*     */     }
/*     */     
/*     */     public String getClientAuthenticationMethod() {
/* 142 */       return this.clientAuthenticationMethod;
/*     */     }
/*     */     
/*     */     public void setClientAuthenticationMethod(String clientAuthenticationMethod) {
/* 146 */       this.clientAuthenticationMethod = clientAuthenticationMethod;
/*     */     }
/*     */     
/*     */     public String getAuthorizationGrantType() {
/* 150 */       return this.authorizationGrantType;
/*     */     }
/*     */     
/*     */     public void setAuthorizationGrantType(String authorizationGrantType) {
/* 154 */       this.authorizationGrantType = authorizationGrantType;
/*     */     }
/*     */     
/*     */     public String getRedirectUri() {
/* 158 */       return this.redirectUri;
/*     */     }
/*     */     
/*     */     public void setRedirectUri(String redirectUri) {
/* 162 */       this.redirectUri = redirectUri;
/*     */     }
/*     */     
/*     */     public Set<String> getScope() {
/* 166 */       return this.scope;
/*     */     }
/*     */     
/*     */     public void setScope(Set<String> scope) {
/* 170 */       this.scope = scope;
/*     */     }
/*     */     
/*     */     public String getClientName() {
/* 174 */       return this.clientName;
/*     */     }
/*     */     
/*     */     public void setClientName(String clientName) {
/* 178 */       this.clientName = clientName;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Provider
/*     */   {
/*     */     private String authorizationUri;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String tokenUri;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String userInfoUri;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String userInfoAuthenticationMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String userNameAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String jwkSetUri;
/*     */ 
/*     */ 
/*     */     
/*     */     private String issuerUri;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getAuthorizationUri() {
/* 223 */       return this.authorizationUri;
/*     */     }
/*     */     
/*     */     public void setAuthorizationUri(String authorizationUri) {
/* 227 */       this.authorizationUri = authorizationUri;
/*     */     }
/*     */     
/*     */     public String getTokenUri() {
/* 231 */       return this.tokenUri;
/*     */     }
/*     */     
/*     */     public void setTokenUri(String tokenUri) {
/* 235 */       this.tokenUri = tokenUri;
/*     */     }
/*     */     
/*     */     public String getUserInfoUri() {
/* 239 */       return this.userInfoUri;
/*     */     }
/*     */     
/*     */     public void setUserInfoUri(String userInfoUri) {
/* 243 */       this.userInfoUri = userInfoUri;
/*     */     }
/*     */     
/*     */     public String getUserInfoAuthenticationMethod() {
/* 247 */       return this.userInfoAuthenticationMethod;
/*     */     }
/*     */     
/*     */     public void setUserInfoAuthenticationMethod(String userInfoAuthenticationMethod) {
/* 251 */       this.userInfoAuthenticationMethod = userInfoAuthenticationMethod;
/*     */     }
/*     */     
/*     */     public String getUserNameAttribute() {
/* 255 */       return this.userNameAttribute;
/*     */     }
/*     */     
/*     */     public void setUserNameAttribute(String userNameAttribute) {
/* 259 */       this.userNameAttribute = userNameAttribute;
/*     */     }
/*     */     
/*     */     public String getJwkSetUri() {
/* 263 */       return this.jwkSetUri;
/*     */     }
/*     */     
/*     */     public void setJwkSetUri(String jwkSetUri) {
/* 267 */       this.jwkSetUri = jwkSetUri;
/*     */     }
/*     */     
/*     */     public String getIssuerUri() {
/* 271 */       return this.issuerUri;
/*     */     }
/*     */     
/*     */     public void setIssuerUri(String issuerUri) {
/* 275 */       this.issuerUri = issuerUri;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\OAuth2ClientProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.security;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum StaticResourceLocation
/*    */ {
/* 33 */   CSS(new String[] { "/css/**"
/*    */ 
/*    */ 
/*    */     
/*    */     }),
/* 38 */   JAVA_SCRIPT(new String[] { "/js/**"
/*    */ 
/*    */ 
/*    */     
/*    */     }),
/* 43 */   IMAGES(new String[] { "/images/**"
/*    */ 
/*    */ 
/*    */     
/*    */     }),
/* 48 */   WEB_JARS(new String[] { "/webjars/**"
/*    */ 
/*    */ 
/*    */     
/*    */     }),
/* 53 */   FAVICON(new String[] { "/**/favicon.ico" });
/*    */   
/*    */   private final String[] patterns;
/*    */   
/*    */   StaticResourceLocation(String... patterns) {
/* 58 */     this.patterns = patterns;
/*    */   }
/*    */   
/*    */   public Stream<String> getPatterns() {
/* 62 */     return Arrays.stream(this.patterns);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\security\StaticResourceLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package org.springframework.boot.autoconfigure.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionEvaluationReportMessage
/*     */ {
/*     */   private StringBuilder message;
/*     */   
/*     */   public ConditionEvaluationReportMessage(ConditionEvaluationReport report) {
/*  48 */     this(report, "CONDITIONS EVALUATION REPORT");
/*     */   }
/*     */   
/*     */   public ConditionEvaluationReportMessage(ConditionEvaluationReport report, String title) {
/*  52 */     this.message = getLogMessage(report, title);
/*     */   }
/*     */   
/*     */   private StringBuilder getLogMessage(ConditionEvaluationReport report, String title) {
/*  56 */     StringBuilder message = new StringBuilder();
/*  57 */     message.append(String.format("%n%n%n", new Object[0]));
/*  58 */     StringBuilder separator = new StringBuilder();
/*  59 */     for (int i = 0; i < title.length(); i++) {
/*  60 */       separator.append("=");
/*     */     }
/*  62 */     message.append(String.format("%s%n", new Object[] { separator }));
/*  63 */     message.append(String.format("%s%n", new Object[] { title }));
/*  64 */     message.append(String.format("%s%n%n%n", new Object[] { separator }));
/*  65 */     Map<String, ConditionEvaluationReport.ConditionAndOutcomes> shortOutcomes = orderByName(report.getConditionAndOutcomesBySource());
/*  66 */     logPositiveMatches(message, shortOutcomes);
/*  67 */     logNegativeMatches(message, shortOutcomes);
/*  68 */     logExclusions(report, message);
/*  69 */     logUnconditionalClasses(report, message);
/*  70 */     message.append(String.format("%n%n", new Object[0]));
/*  71 */     return message;
/*     */   }
/*     */   
/*     */   private void logPositiveMatches(StringBuilder message, Map<String, ConditionEvaluationReport.ConditionAndOutcomes> shortOutcomes) {
/*  75 */     message.append(String.format("Positive matches:%n", new Object[0]));
/*  76 */     message.append(String.format("-----------------%n", new Object[0]));
/*     */     
/*  78 */     List<Map.Entry<String, ConditionEvaluationReport.ConditionAndOutcomes>> matched = (List<Map.Entry<String, ConditionEvaluationReport.ConditionAndOutcomes>>)shortOutcomes.entrySet().stream().filter(entry -> ((ConditionEvaluationReport.ConditionAndOutcomes)entry.getValue()).isFullMatch()).collect(Collectors.toList());
/*  79 */     if (matched.isEmpty()) {
/*  80 */       message.append(String.format("%n    None%n", new Object[0]));
/*     */     } else {
/*     */       
/*  83 */       matched.forEach(entry -> addMatchLogMessage(message, (String)entry.getKey(), (ConditionEvaluationReport.ConditionAndOutcomes)entry.getValue()));
/*     */     } 
/*  85 */     message.append(String.format("%n%n", new Object[0]));
/*     */   }
/*     */   
/*     */   private void logNegativeMatches(StringBuilder message, Map<String, ConditionEvaluationReport.ConditionAndOutcomes> shortOutcomes) {
/*  89 */     message.append(String.format("Negative matches:%n", new Object[0]));
/*  90 */     message.append(String.format("-----------------%n", new Object[0]));
/*     */     
/*  92 */     List<Map.Entry<String, ConditionEvaluationReport.ConditionAndOutcomes>> nonMatched = (List<Map.Entry<String, ConditionEvaluationReport.ConditionAndOutcomes>>)shortOutcomes.entrySet().stream().filter(entry -> !((ConditionEvaluationReport.ConditionAndOutcomes)entry.getValue()).isFullMatch()).collect(Collectors.toList());
/*  93 */     if (nonMatched.isEmpty()) {
/*  94 */       message.append(String.format("%n    None%n", new Object[0]));
/*     */     } else {
/*     */       
/*  97 */       nonMatched.forEach(entry -> addNonMatchLogMessage(message, (String)entry.getKey(), (ConditionEvaluationReport.ConditionAndOutcomes)entry.getValue()));
/*     */     } 
/*  99 */     message.append(String.format("%n%n", new Object[0]));
/*     */   }
/*     */   
/*     */   private void logExclusions(ConditionEvaluationReport report, StringBuilder message) {
/* 103 */     message.append(String.format("Exclusions:%n", new Object[0]));
/* 104 */     message.append(String.format("-----------%n", new Object[0]));
/* 105 */     if (report.getExclusions().isEmpty()) {
/* 106 */       message.append(String.format("%n    None%n", new Object[0]));
/*     */     } else {
/*     */       
/* 109 */       for (String exclusion : report.getExclusions()) {
/* 110 */         message.append(String.format("%n    %s%n", new Object[] { exclusion }));
/*     */       } 
/*     */     } 
/* 113 */     message.append(String.format("%n%n", new Object[0]));
/*     */   }
/*     */   
/*     */   private void logUnconditionalClasses(ConditionEvaluationReport report, StringBuilder message) {
/* 117 */     message.append(String.format("Unconditional classes:%n", new Object[0]));
/* 118 */     message.append(String.format("----------------------%n", new Object[0]));
/* 119 */     if (report.getUnconditionalClasses().isEmpty()) {
/* 120 */       message.append(String.format("%n    None%n", new Object[0]));
/*     */     } else {
/*     */       
/* 123 */       for (String unconditionalClass : report.getUnconditionalClasses()) {
/* 124 */         message.append(String.format("%n    %s%n", new Object[] { unconditionalClass }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<String, ConditionEvaluationReport.ConditionAndOutcomes> orderByName(Map<String, ConditionEvaluationReport.ConditionAndOutcomes> outcomes) {
/* 130 */     MultiValueMap<String, String> map = mapToFullyQualifiedNames(outcomes.keySet());
/* 131 */     List<String> shortNames = new ArrayList<>(map.keySet());
/* 132 */     Collections.sort(shortNames);
/* 133 */     Map<String, ConditionEvaluationReport.ConditionAndOutcomes> result = new LinkedHashMap<>();
/* 134 */     for (String shortName : shortNames) {
/* 135 */       List<String> fullyQualifiedNames = (List<String>)map.get(shortName);
/* 136 */       if (fullyQualifiedNames.size() > 1) {
/* 137 */         fullyQualifiedNames.forEach(fullyQualifiedName -> (ConditionEvaluationReport.ConditionAndOutcomes)result.put(fullyQualifiedName, (ConditionEvaluationReport.ConditionAndOutcomes)outcomes.get(fullyQualifiedName)));
/*     */         
/*     */         continue;
/*     */       } 
/* 141 */       result.put(shortName, outcomes.get(fullyQualifiedNames.get(0)));
/*     */     } 
/*     */     
/* 144 */     return result;
/*     */   }
/*     */   
/*     */   private MultiValueMap<String, String> mapToFullyQualifiedNames(Set<String> keySet) {
/* 148 */     LinkedMultiValueMap<String, String> map = new LinkedMultiValueMap();
/* 149 */     keySet.forEach(fullyQualifiedName -> map.add(ClassUtils.getShortName(fullyQualifiedName), fullyQualifiedName));
/*     */     
/* 151 */     return (MultiValueMap<String, String>)map;
/*     */   }
/*     */   
/*     */   private void addMatchLogMessage(StringBuilder message, String source, ConditionEvaluationReport.ConditionAndOutcomes matches) {
/* 155 */     message.append(String.format("%n   %s matched:%n", new Object[] { source }));
/* 156 */     for (ConditionEvaluationReport.ConditionAndOutcome match : matches) {
/* 157 */       logConditionAndOutcome(message, "      ", match);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addNonMatchLogMessage(StringBuilder message, String source, ConditionEvaluationReport.ConditionAndOutcomes conditionAndOutcomes) {
/* 163 */     message.append(String.format("%n   %s:%n", new Object[] { source }));
/* 164 */     List<ConditionEvaluationReport.ConditionAndOutcome> matches = new ArrayList<>();
/* 165 */     List<ConditionEvaluationReport.ConditionAndOutcome> nonMatches = new ArrayList<>();
/* 166 */     for (ConditionEvaluationReport.ConditionAndOutcome conditionAndOutcome : conditionAndOutcomes) {
/* 167 */       if (conditionAndOutcome.getOutcome().isMatch()) {
/* 168 */         matches.add(conditionAndOutcome);
/*     */         continue;
/*     */       } 
/* 171 */       nonMatches.add(conditionAndOutcome);
/*     */     } 
/*     */     
/* 174 */     message.append(String.format("      Did not match:%n", new Object[0]));
/* 175 */     for (ConditionEvaluationReport.ConditionAndOutcome nonMatch : nonMatches) {
/* 176 */       logConditionAndOutcome(message, "         ", nonMatch);
/*     */     }
/* 178 */     if (!matches.isEmpty()) {
/* 179 */       message.append(String.format("      Matched:%n", new Object[0]));
/* 180 */       for (ConditionEvaluationReport.ConditionAndOutcome match : matches) {
/* 181 */         logConditionAndOutcome(message, "         ", match);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logConditionAndOutcome(StringBuilder message, String indent, ConditionEvaluationReport.ConditionAndOutcome conditionAndOutcome) {
/* 187 */     message.append(String.format("%s- ", new Object[] { indent }));
/* 188 */     String outcomeMessage = conditionAndOutcome.getOutcome().getMessage();
/* 189 */     if (StringUtils.hasLength(outcomeMessage)) {
/* 190 */       message.append(outcomeMessage);
/*     */     } else {
/*     */       
/* 193 */       message.append(conditionAndOutcome.getOutcome().isMatch() ? "matched" : "did not match");
/*     */     } 
/* 195 */     message.append(" (");
/* 196 */     message.append(ClassUtils.getShortName(conditionAndOutcome.getCondition().getClass()));
/* 197 */     message.append(String.format(")%n", new Object[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return this.message.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\logging\ConditionEvaluationReportMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
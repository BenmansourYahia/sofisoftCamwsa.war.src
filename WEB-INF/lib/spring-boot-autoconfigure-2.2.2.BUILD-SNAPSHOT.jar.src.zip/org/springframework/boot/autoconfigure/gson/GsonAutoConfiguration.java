/*    */ package org.springframework.boot.autoconfigure.gson;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Gson.class})
/*    */ @EnableConfigurationProperties({GsonProperties.class})
/*    */ public class GsonAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public GsonBuilder gsonBuilder(List<GsonBuilderCustomizer> customizers) {
/* 48 */     GsonBuilder builder = new GsonBuilder();
/* 49 */     customizers.forEach(c -> c.customize(builder));
/* 50 */     return builder;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public Gson gson(GsonBuilder gsonBuilder) {
/* 56 */     return gsonBuilder.create();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   public StandardGsonBuilderCustomizer standardGsonBuilderCustomizer(GsonProperties gsonProperties) {
/* 61 */     return new StandardGsonBuilderCustomizer(gsonProperties);
/*    */   }
/*    */   
/*    */   static final class StandardGsonBuilderCustomizer
/*    */     implements GsonBuilderCustomizer, Ordered {
/*    */     private final GsonProperties properties;
/*    */     
/*    */     StandardGsonBuilderCustomizer(GsonProperties properties) {
/* 69 */       this.properties = properties;
/*    */     }
/*    */ 
/*    */     
/*    */     public int getOrder() {
/* 74 */       return 0;
/*    */     }
/*    */ 
/*    */     
/*    */     public void customize(GsonBuilder builder) {
/* 79 */       GsonProperties properties = this.properties;
/* 80 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 81 */       map.from(properties::getGenerateNonExecutableJson).toCall(builder::generateNonExecutableJson);
/* 82 */       map.from(properties::getExcludeFieldsWithoutExposeAnnotation)
/* 83 */         .toCall(builder::excludeFieldsWithoutExposeAnnotation);
/* 84 */       map.from(properties::getSerializeNulls).whenTrue().toCall(builder::serializeNulls);
/* 85 */       map.from(properties::getEnableComplexMapKeySerialization).toCall(builder::enableComplexMapKeySerialization);
/* 86 */       map.from(properties::getDisableInnerClassSerialization).toCall(builder::disableInnerClassSerialization);
/* 87 */       map.from(properties::getLongSerializationPolicy).to(builder::setLongSerializationPolicy);
/* 88 */       map.from(properties::getFieldNamingPolicy).to(builder::setFieldNamingPolicy);
/* 89 */       map.from(properties::getPrettyPrinting).toCall(builder::setPrettyPrinting);
/* 90 */       map.from(properties::getLenient).toCall(builder::setLenient);
/* 91 */       map.from(properties::getDisableHtmlEscaping).toCall(builder::disableHtmlEscaping);
/* 92 */       map.from(properties::getDateFormat).to(builder::setDateFormat);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\gson\GsonAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
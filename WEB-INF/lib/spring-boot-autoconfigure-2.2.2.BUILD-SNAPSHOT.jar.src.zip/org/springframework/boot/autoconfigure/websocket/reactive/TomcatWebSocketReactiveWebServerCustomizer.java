/*    */ package org.springframework.boot.autoconfigure.websocket.reactive;
/*    */ 
/*    */ import org.apache.catalina.Context;
/*    */ import org.apache.tomcat.websocket.server.WsContextListener;
/*    */ import org.springframework.boot.web.embedded.tomcat.TomcatContextCustomizer;
/*    */ import org.springframework.boot.web.embedded.tomcat.TomcatReactiveWebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TomcatWebSocketReactiveWebServerCustomizer
/*    */   implements WebServerFactoryCustomizer<TomcatReactiveWebServerFactory>, Ordered
/*    */ {
/*    */   public void customize(TomcatReactiveWebServerFactory factory) {
/* 36 */     factory.addContextCustomizers(new TomcatContextCustomizer[] { context -> context.addApplicationListener(WsContextListener.class.getName()) });
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 41 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\websocket\reactive\TomcatWebSocketReactiveWebServerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
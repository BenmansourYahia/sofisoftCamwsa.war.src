/*    */ package org.springframework.boot.autoconfigure.websocket.servlet;
/*    */ 
/*    */ import org.eclipse.jetty.servlet.ServletContextHandler;
/*    */ import org.eclipse.jetty.util.component.LifeCycle;
/*    */ import org.eclipse.jetty.util.thread.ShutdownThread;
/*    */ import org.eclipse.jetty.webapp.AbstractConfiguration;
/*    */ import org.eclipse.jetty.webapp.Configuration;
/*    */ import org.eclipse.jetty.webapp.WebAppContext;
/*    */ import org.eclipse.jetty.websocket.jsr356.server.ServerContainer;
/*    */ import org.eclipse.jetty.websocket.jsr356.server.deploy.WebSocketServerContainerInitializer;
/*    */ import org.springframework.boot.web.embedded.jetty.JettyServletWebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactory;
/*    */ import org.springframework.boot.web.server.WebServerFactoryCustomizer;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JettyWebSocketServletWebServerCustomizer
/*    */   implements WebServerFactoryCustomizer<JettyServletWebServerFactory>, Ordered
/*    */ {
/*    */   public void customize(JettyServletWebServerFactory factory) {
/* 42 */     factory.addConfigurations(new Configuration[] { (Configuration)new AbstractConfiguration()
/*    */           {
/*    */             public void configure(WebAppContext context) throws Exception
/*    */             {
/* 46 */               ServerContainer serverContainer = WebSocketServerContainerInitializer.configureContext((ServletContextHandler)context);
/* 47 */               ShutdownThread.deregister((LifeCycle)serverContainer);
/*    */             }
/*    */           } });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 55 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\websocket\servlet\JettyWebSocketServletWebServerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.mail;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.mail.javamail.JavaMailSender;
/*    */ import org.springframework.mail.javamail.JavaMailSenderImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnProperty(prefix = "spring.mail", name = {"host"})
/*    */ class MailSenderPropertiesConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({JavaMailSender.class})
/*    */   JavaMailSenderImpl mailSender(MailProperties properties) {
/* 44 */     JavaMailSenderImpl sender = new JavaMailSenderImpl();
/* 45 */     applyProperties(properties, sender);
/* 46 */     return sender;
/*    */   }
/*    */   
/*    */   private void applyProperties(MailProperties properties, JavaMailSenderImpl sender) {
/* 50 */     sender.setHost(properties.getHost());
/* 51 */     if (properties.getPort() != null) {
/* 52 */       sender.setPort(properties.getPort().intValue());
/*    */     }
/* 54 */     sender.setUsername(properties.getUsername());
/* 55 */     sender.setPassword(properties.getPassword());
/* 56 */     sender.setProtocol(properties.getProtocol());
/* 57 */     if (properties.getDefaultEncoding() != null) {
/* 58 */       sender.setDefaultEncoding(properties.getDefaultEncoding().name());
/*    */     }
/* 60 */     if (!properties.getProperties().isEmpty()) {
/* 61 */       sender.setJavaMailProperties(asProperties(properties.getProperties()));
/*    */     }
/*    */   }
/*    */   
/*    */   private Properties asProperties(Map<String, String> source) {
/* 66 */     Properties properties = new Properties();
/* 67 */     properties.putAll(source);
/* 68 */     return properties;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mail\MailSenderPropertiesConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package org.springframework.boot.autoconfigure.mail;
/*    */ 
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.mail.MessagingException;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.mail.javamail.JavaMailSenderImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @AutoConfigureAfter({MailSenderAutoConfiguration.class})
/*    */ @ConditionalOnProperty(prefix = "spring.mail", value = {"test-connection"})
/*    */ @ConditionalOnSingleCandidate(JavaMailSenderImpl.class)
/*    */ public class MailSenderValidatorAutoConfiguration
/*    */ {
/*    */   private final JavaMailSenderImpl mailSender;
/*    */   
/*    */   public MailSenderValidatorAutoConfiguration(JavaMailSenderImpl mailSender) {
/* 46 */     this.mailSender = mailSender;
/*    */   }
/*    */   
/*    */   @PostConstruct
/*    */   public void validateConnection() {
/*    */     try {
/* 52 */       this.mailSender.testConnection();
/*    */     }
/* 54 */     catch (MessagingException ex) {
/* 55 */       throw new IllegalStateException("Mail server is not available", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mail\MailSenderValidatorAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
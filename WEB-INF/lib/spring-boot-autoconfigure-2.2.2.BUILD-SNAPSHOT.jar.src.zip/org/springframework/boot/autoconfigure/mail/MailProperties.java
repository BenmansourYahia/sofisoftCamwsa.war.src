/*     */ package org.springframework.boot.autoconfigure.mail;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix = "spring.mail")
/*     */ public class MailProperties
/*     */ {
/*  37 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String host;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer port;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String username;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private String protocol = "smtp";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private Charset defaultEncoding = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private Map<String, String> properties = new HashMap<>();
/*     */ 
/*     */   
/*     */   private String jndiName;
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() {
/*  80 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/*  84 */     this.host = host;
/*     */   }
/*     */   
/*     */   public Integer getPort() {
/*  88 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(Integer port) {
/*  92 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  96 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 100 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 104 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 108 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getProtocol() {
/* 112 */     return this.protocol;
/*     */   }
/*     */   
/*     */   public void setProtocol(String protocol) {
/* 116 */     this.protocol = protocol;
/*     */   }
/*     */   
/*     */   public Charset getDefaultEncoding() {
/* 120 */     return this.defaultEncoding;
/*     */   }
/*     */   
/*     */   public void setDefaultEncoding(Charset defaultEncoding) {
/* 124 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 128 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setJndiName(String jndiName) {
/* 132 */     this.jndiName = jndiName;
/*     */   }
/*     */   
/*     */   public String getJndiName() {
/* 136 */     return this.jndiName;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mail\MailProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
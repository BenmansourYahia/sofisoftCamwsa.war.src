/*    */ package org.springframework.boot.autoconfigure.mail;
/*    */ 
/*    */ import javax.activation.MimeType;
/*    */ import javax.mail.internet.MimeMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.mail.MailSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({MimeMessage.class, MimeType.class, MailSender.class})
/*    */ @ConditionalOnMissingBean({MailSender.class})
/*    */ @Conditional({MailSenderAutoConfiguration.MailSenderCondition.class})
/*    */ @EnableConfigurationProperties({MailProperties.class})
/*    */ @Import({MailSenderJndiConfiguration.class, MailSenderPropertiesConfiguration.class})
/*    */ public class MailSenderAutoConfiguration
/*    */ {
/*    */   static class MailSenderCondition
/*    */     extends AnyNestedCondition
/*    */   {
/*    */     MailSenderCondition() {
/* 57 */       super(ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION);
/*    */     }
/*    */     
/*    */     @ConditionalOnProperty(prefix = "spring.mail", name = {"host"})
/*    */     static class HostProperty {}
/*    */     
/*    */     @ConditionalOnProperty(prefix = "spring.mail", name = {"jndi-name"})
/*    */     static class JndiNameProperty {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\mail\MailSenderAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
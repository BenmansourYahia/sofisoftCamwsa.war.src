/*    */ package org.springframework.boot.autoconfigure.validation;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.BeanFactoryUtils;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.validation.Validator;
/*    */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrimaryDefaultValidatorPostProcessor
/*    */   implements ImportBeanDefinitionRegistrar, BeanFactoryAware
/*    */ {
/*    */   private static final String VALIDATOR_BEAN_NAME = "defaultValidator";
/*    */   private ConfigurableListableBeanFactory beanFactory;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 52 */     if (beanFactory instanceof ConfigurableListableBeanFactory) {
/* 53 */       this.beanFactory = (ConfigurableListableBeanFactory)beanFactory;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 59 */     BeanDefinition definition = getAutoConfiguredValidator(registry);
/* 60 */     if (definition != null) {
/* 61 */       definition.setPrimary(!hasPrimarySpringValidator(registry));
/*    */     }
/*    */   }
/*    */   
/*    */   private BeanDefinition getAutoConfiguredValidator(BeanDefinitionRegistry registry) {
/* 66 */     if (registry.containsBeanDefinition("defaultValidator")) {
/* 67 */       BeanDefinition definition = registry.getBeanDefinition("defaultValidator");
/* 68 */       if (definition.getRole() == 2 && 
/* 69 */         isTypeMatch("defaultValidator", LocalValidatorFactoryBean.class)) {
/* 70 */         return definition;
/*    */       }
/*    */     } 
/* 73 */     return null;
/*    */   }
/*    */   
/*    */   private boolean isTypeMatch(String name, Class<?> type) {
/* 77 */     return (this.beanFactory != null && this.beanFactory.isTypeMatch(name, type));
/*    */   }
/*    */   
/*    */   private boolean hasPrimarySpringValidator(BeanDefinitionRegistry registry) {
/* 81 */     String[] validatorBeans = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.beanFactory, Validator.class, false, false);
/*    */     
/* 83 */     for (String validatorBean : validatorBeans) {
/* 84 */       BeanDefinition definition = registry.getBeanDefinition(validatorBean);
/* 85 */       if (definition != null && definition.isPrimary()) {
/* 86 */         return true;
/*    */       }
/*    */     } 
/* 89 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\validation\PrimaryDefaultValidatorPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
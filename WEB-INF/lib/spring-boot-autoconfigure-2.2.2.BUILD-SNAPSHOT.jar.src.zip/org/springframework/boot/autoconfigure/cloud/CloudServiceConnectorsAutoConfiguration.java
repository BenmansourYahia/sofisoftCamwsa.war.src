/*    */ package org.springframework.boot.autoconfigure.cloud;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.cloud.Cloud;
/*    */ import org.springframework.cloud.config.java.CloudScanConfiguration;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.context.annotation.Profile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Profile({"cloud"})
/*    */ @AutoConfigureOrder(-2147483628)
/*    */ @ConditionalOnClass({CloudScanConfiguration.class})
/*    */ @ConditionalOnMissingBean({Cloud.class})
/*    */ @Import({CloudScanConfiguration.class})
/*    */ public class CloudServiceConnectorsAutoConfiguration
/*    */ {
/*    */   public static final int ORDER = -2147483628;
/* 60 */   private static final Log logger = LogFactory.getLog(CloudServiceConnectorsAutoConfiguration.class);
/*    */   
/*    */   public CloudServiceConnectorsAutoConfiguration() {
/* 63 */     logger.warn("Support for Spring Cloud Connectors has been deprecated in favor of Java CFEnv");
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\cloud\CloudServiceConnectorsAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
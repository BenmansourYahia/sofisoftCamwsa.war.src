/*    */ package org.springframework.boot.autoconfigure.jooq;
/*    */ 
/*    */ import org.jooq.TransactionContext;
/*    */ import org.jooq.TransactionProvider;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ import org.springframework.transaction.TransactionDefinition;
/*    */ import org.springframework.transaction.TransactionStatus;
/*    */ import org.springframework.transaction.support.DefaultTransactionDefinition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringTransactionProvider
/*    */   implements TransactionProvider
/*    */ {
/*    */   private final PlatformTransactionManager transactionManager;
/*    */   
/*    */   public SpringTransactionProvider(PlatformTransactionManager transactionManager) {
/* 42 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public void begin(TransactionContext context) {
/* 47 */     DefaultTransactionDefinition defaultTransactionDefinition = new DefaultTransactionDefinition(6);
/* 48 */     TransactionStatus status = this.transactionManager.getTransaction((TransactionDefinition)defaultTransactionDefinition);
/* 49 */     context.transaction(new SpringTransaction(status));
/*    */   }
/*    */ 
/*    */   
/*    */   public void commit(TransactionContext ctx) {
/* 54 */     this.transactionManager.commit(getTransactionStatus(ctx));
/*    */   }
/*    */ 
/*    */   
/*    */   public void rollback(TransactionContext ctx) {
/* 59 */     this.transactionManager.rollback(getTransactionStatus(ctx));
/*    */   }
/*    */   
/*    */   private TransactionStatus getTransactionStatus(TransactionContext ctx) {
/* 63 */     SpringTransaction transaction = (SpringTransaction)ctx.transaction();
/* 64 */     return transaction.getTxStatus();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jooq\SpringTransactionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
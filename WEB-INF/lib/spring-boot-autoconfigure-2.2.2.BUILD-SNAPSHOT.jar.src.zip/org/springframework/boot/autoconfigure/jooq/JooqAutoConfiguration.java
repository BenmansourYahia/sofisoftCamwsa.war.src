/*     */ package org.springframework.boot.autoconfigure.jooq;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.jooq.Configuration;
/*     */ import org.jooq.ConnectionProvider;
/*     */ import org.jooq.DSLContext;
/*     */ import org.jooq.ExecuteListener;
/*     */ import org.jooq.ExecuteListenerProvider;
/*     */ import org.jooq.ExecutorProvider;
/*     */ import org.jooq.RecordListenerProvider;
/*     */ import org.jooq.RecordMapperProvider;
/*     */ import org.jooq.RecordUnmapperProvider;
/*     */ import org.jooq.TransactionListenerProvider;
/*     */ import org.jooq.TransactionProvider;
/*     */ import org.jooq.VisitListenerProvider;
/*     */ import org.jooq.conf.Settings;
/*     */ import org.jooq.impl.DataSourceConnectionProvider;
/*     */ import org.jooq.impl.DefaultConfiguration;
/*     */ import org.jooq.impl.DefaultDSLContext;
/*     */ import org.jooq.impl.DefaultExecuteListenerProvider;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({DSLContext.class})
/*     */ @ConditionalOnBean({DataSource.class})
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, TransactionAutoConfiguration.class})
/*     */ public class JooqAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ConnectionProvider.class})
/*     */   public DataSourceConnectionProvider dataSourceConnectionProvider(DataSource dataSource) {
/*  69 */     return new DataSourceConnectionProvider((DataSource)new TransactionAwareDataSourceProxy(dataSource));
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnBean({PlatformTransactionManager.class})
/*     */   public SpringTransactionProvider transactionProvider(PlatformTransactionManager txManager) {
/*  75 */     return new SpringTransactionProvider(txManager);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Order(0)
/*     */   public DefaultExecuteListenerProvider jooqExceptionTranslatorExecuteListenerProvider() {
/*  81 */     return new DefaultExecuteListenerProvider((ExecuteListener)new JooqExceptionTranslator());
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({DSLContext.class})
/*     */   @EnableConfigurationProperties({JooqProperties.class})
/*     */   public static class DslContextConfiguration
/*     */   {
/*     */     @Bean
/*     */     public DefaultDSLContext dslContext(Configuration configuration) {
/*  91 */       return new DefaultDSLContext(configuration);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({Configuration.class})
/*     */     public DefaultConfiguration jooqConfiguration(JooqProperties properties, ConnectionProvider connectionProvider, DataSource dataSource, ObjectProvider<TransactionProvider> transactionProvider, ObjectProvider<RecordMapperProvider> recordMapperProvider, ObjectProvider<RecordUnmapperProvider> recordUnmapperProvider, ObjectProvider<Settings> settings, ObjectProvider<RecordListenerProvider> recordListenerProviders, ObjectProvider<ExecuteListenerProvider> executeListenerProviders, ObjectProvider<VisitListenerProvider> visitListenerProviders, ObjectProvider<TransactionListenerProvider> transactionListenerProviders, ObjectProvider<ExecutorProvider> executorProvider) {
/* 105 */       DefaultConfiguration configuration = new DefaultConfiguration();
/* 106 */       configuration.set(properties.determineSqlDialect(dataSource));
/* 107 */       configuration.set(connectionProvider);
/* 108 */       transactionProvider.ifAvailable(configuration::set);
/* 109 */       recordMapperProvider.ifAvailable(configuration::set);
/* 110 */       recordUnmapperProvider.ifAvailable(configuration::set);
/* 111 */       settings.ifAvailable(configuration::set);
/* 112 */       executorProvider.ifAvailable(configuration::set);
/* 113 */       configuration.set((RecordListenerProvider[])recordListenerProviders.orderedStream().toArray(x$0 -> new RecordListenerProvider[x$0]));
/* 114 */       configuration.set((ExecuteListenerProvider[])executeListenerProviders.orderedStream().toArray(x$0 -> new ExecuteListenerProvider[x$0]));
/* 115 */       configuration.set((VisitListenerProvider[])visitListenerProviders.orderedStream().toArray(x$0 -> new VisitListenerProvider[x$0]));
/* 116 */       configuration.setTransactionListenerProvider((TransactionListenerProvider[])transactionListenerProviders
/* 117 */           .orderedStream().toArray(x$0 -> new TransactionListenerProvider[x$0]));
/* 118 */       return configuration;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jooq\JooqAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
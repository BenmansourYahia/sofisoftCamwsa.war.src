/*    */ package org.springframework.boot.autoconfigure.jooq;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.jooq.SQLDialect;
/*    */ import org.jooq.tools.jdbc.JDBCUtils;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SqlDialectLookup
/*    */ {
/* 37 */   private static final Log logger = LogFactory.getLog(SqlDialectLookup.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static SQLDialect getDialect(DataSource dataSource) {
/* 48 */     if (dataSource == null) {
/* 49 */       return SQLDialect.DEFAULT;
/*    */     }
/*    */     try {
/* 52 */       String url = (String)JdbcUtils.extractDatabaseMetaData(dataSource, "getURL");
/* 53 */       SQLDialect sqlDialect = JDBCUtils.dialect(url);
/* 54 */       if (sqlDialect != null) {
/* 55 */         return sqlDialect;
/*    */       }
/*    */     }
/* 58 */     catch (MetaDataAccessException ex) {
/* 59 */       logger.warn("Unable to determine jdbc url from datasource", (Throwable)ex);
/*    */     } 
/* 61 */     return SQLDialect.DEFAULT;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jooq\SqlDialectLookup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
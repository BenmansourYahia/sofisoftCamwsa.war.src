/*    */ package org.springframework.boot.autoconfigure.jooq;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.jooq.SQLDialect;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix = "spring.jooq")
/*    */ public class JooqProperties
/*    */ {
/*    */   private SQLDialect sqlDialect;
/*    */   
/*    */   public SQLDialect getSqlDialect() {
/* 41 */     return this.sqlDialect;
/*    */   }
/*    */   
/*    */   public void setSqlDialect(SQLDialect sqlDialect) {
/* 45 */     this.sqlDialect = sqlDialect;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SQLDialect determineSqlDialect(DataSource dataSource) {
/* 55 */     if (this.sqlDialect != null) {
/* 56 */       return this.sqlDialect;
/*    */     }
/* 58 */     return SqlDialectLookup.getDialect(dataSource);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\spring-boot-autoconfigure-2.2.2.BUILD-SNAPSHOT.jar!\org\springframework\boot\autoconfigure\jooq\JooqProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
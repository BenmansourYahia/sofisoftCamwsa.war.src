/**
 * Support utilities for hypermedia handling.
 */
@NonNullApi
package org.springframework.hateoas.support;

import org.springframework.lang.NonNullApi;
/**
 * UBER media type objects.
 */
@NonNullApi
package org.springframework.hateoas.mediatype.uber;

import org.springframework.lang.NonNullApi;
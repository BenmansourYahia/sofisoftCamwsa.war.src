/**
 * Vnd.Error media type.
 */
@NonNullApi
package org.springframework.hateoas.mediatype.vnderrors;

import org.springframework.lang.NonNullApi;
/**
 * Spring container configuration support.
 */
@org.springframework.lang.NonNullApi
package org.springframework.hateoas.mediatype;

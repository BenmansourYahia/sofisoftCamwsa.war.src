/**
 * HAL-FORMS extension media type.
 */
@NonNullApi
package org.springframework.hateoas.mediatype.hal.forms;

import org.springframework.lang.NonNullApi;
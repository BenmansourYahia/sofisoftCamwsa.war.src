/**
 * HAL-specific extensions, SPIs and Jackson customizations.
 *
 * @see http://stateless.co/hal_specification.html
 */
@org.springframework.lang.NonNullApi
package org.springframework.hateoas.mediatype.hal;

/**
 * Value objects to build ALPS metadata.
 *
 * @see https://alps.io
 */
@org.springframework.lang.NonNullApi
package org.springframework.hateoas.mediatype.alps;

/**
 * Value objects to build Collection+JSON representations.
 */
@org.springframework.lang.NonNullApi
package org.springframework.hateoas.mediatype.collectionjson;

/**
 * Server-side components for hypermedia handling.
 */
@NonNullApi
package org.springframework.hateoas.server;

import org.springframework.lang.NonNullApi;
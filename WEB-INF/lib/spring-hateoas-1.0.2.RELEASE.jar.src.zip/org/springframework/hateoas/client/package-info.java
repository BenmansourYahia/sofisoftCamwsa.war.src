/**
 * Client side support.
 */
@org.springframework.lang.NonNullApi
package org.springframework.hateoas.client;

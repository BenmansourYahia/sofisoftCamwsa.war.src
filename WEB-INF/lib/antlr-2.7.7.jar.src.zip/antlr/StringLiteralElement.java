/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringLiteralElement
/*    */   extends GrammarAtom
/*    */ {
/*    */   protected String processedAtomText;
/*    */   
/*    */   public StringLiteralElement(Grammar paramGrammar, Token paramToken, int paramInt) {
/* 16 */     super(paramGrammar, paramToken, paramInt);
/* 17 */     if (!(paramGrammar instanceof LexerGrammar)) {
/*    */       
/* 19 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(this.atomText);
/* 20 */       if (tokenSymbol == null) {
/* 21 */         paramGrammar.antlrTool.error("Undefined literal: " + this.atomText, this.grammar.getFilename(), paramToken.getLine(), paramToken.getColumn());
/*    */       } else {
/*    */         
/* 24 */         this.tokenType = tokenSymbol.getTokenType();
/*    */       } 
/*    */     } 
/* 27 */     this.line = paramToken.getLine();
/*    */ 
/*    */ 
/*    */     
/* 31 */     this.processedAtomText = new String();
/* 32 */     for (byte b = 1; b < this.atomText.length() - 1; b++) {
/* 33 */       char c = this.atomText.charAt(b);
/* 34 */       if (c == '\\' && 
/* 35 */         b + 1 < this.atomText.length() - 1) {
/* 36 */         b++;
/* 37 */         c = this.atomText.charAt(b);
/* 38 */         switch (c) {
/*    */           case 'n':
/* 40 */             c = '\n';
/*    */             break;
/*    */           case 'r':
/* 43 */             c = '\r';
/*    */             break;
/*    */           case 't':
/* 46 */             c = '\t';
/*    */             break;
/*    */         } 
/*    */       
/*    */       } 
/* 51 */       if (paramGrammar instanceof LexerGrammar) {
/* 52 */         ((LexerGrammar)paramGrammar).charVocabulary.add(c);
/*    */       }
/* 54 */       this.processedAtomText += c;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void generate() {
/* 59 */     this.grammar.generator.gen(this);
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 63 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\StringLiteralElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
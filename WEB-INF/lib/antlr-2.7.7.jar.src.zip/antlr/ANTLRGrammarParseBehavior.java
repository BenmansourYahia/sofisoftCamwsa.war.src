package antlr;

import antlr.collections.impl.BitSet;

public interface ANTLRGrammarParseBehavior {
  void abortGrammar();
  
  void beginAlt(boolean paramBoolean);
  
  void beginChildList();
  
  void beginExceptionGroup();
  
  void beginExceptionSpec(Token paramToken);
  
  void beginSubRule(Token paramToken1, Token paramToken2, boolean paramBoolean);
  
  void beginTree(Token paramToken) throws SemanticException;
  
  void defineRuleName(Token paramToken, String paramString1, boolean paramBoolean, String paramString2) throws SemanticException;
  
  void defineToken(Token paramToken1, Token paramToken2);
  
  void endAlt();
  
  void endChildList();
  
  void endExceptionGroup();
  
  void endExceptionSpec();
  
  void endGrammar();
  
  void endOptions();
  
  void endRule(String paramString);
  
  void endSubRule();
  
  void endTree();
  
  void hasError();
  
  void noASTSubRule();
  
  void oneOrMoreSubRule();
  
  void optionalSubRule();
  
  void refAction(Token paramToken);
  
  void refArgAction(Token paramToken);
  
  void setUserExceptions(String paramString);
  
  void refCharLiteral(Token paramToken1, Token paramToken2, boolean paramBoolean1, int paramInt, boolean paramBoolean2);
  
  void refCharRange(Token paramToken1, Token paramToken2, Token paramToken3, int paramInt, boolean paramBoolean);
  
  void refElementOption(Token paramToken1, Token paramToken2);
  
  void refTokensSpecElementOption(Token paramToken1, Token paramToken2, Token paramToken3);
  
  void refExceptionHandler(Token paramToken1, Token paramToken2);
  
  void refHeaderAction(Token paramToken1, Token paramToken2);
  
  void refInitAction(Token paramToken);
  
  void refMemberAction(Token paramToken);
  
  void refPreambleAction(Token paramToken);
  
  void refReturnAction(Token paramToken);
  
  void refRule(Token paramToken1, Token paramToken2, Token paramToken3, Token paramToken4, int paramInt);
  
  void refSemPred(Token paramToken);
  
  void refStringLiteral(Token paramToken1, Token paramToken2, int paramInt, boolean paramBoolean);
  
  void refToken(Token paramToken1, Token paramToken2, Token paramToken3, Token paramToken4, boolean paramBoolean1, int paramInt, boolean paramBoolean2);
  
  void refTokenRange(Token paramToken1, Token paramToken2, Token paramToken3, int paramInt, boolean paramBoolean);
  
  void refTreeSpecifier(Token paramToken);
  
  void refWildcard(Token paramToken1, Token paramToken2, int paramInt);
  
  void setArgOfRuleRef(Token paramToken);
  
  void setCharVocabulary(BitSet paramBitSet);
  
  void setFileOption(Token paramToken1, Token paramToken2, String paramString);
  
  void setGrammarOption(Token paramToken1, Token paramToken2);
  
  void setRuleOption(Token paramToken1, Token paramToken2);
  
  void setSubruleOption(Token paramToken1, Token paramToken2);
  
  void startLexer(String paramString1, Token paramToken, String paramString2, String paramString3);
  
  void startParser(String paramString1, Token paramToken, String paramString2, String paramString3);
  
  void startTreeWalker(String paramString1, Token paramToken, String paramString2, String paramString3);
  
  void synPred();
  
  void zeroOrMoreSubRule();
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\ANTLRGrammarParseBehavior.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
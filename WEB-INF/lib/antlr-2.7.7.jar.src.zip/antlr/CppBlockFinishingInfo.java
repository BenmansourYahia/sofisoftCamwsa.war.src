/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CppBlockFinishingInfo
/*    */ {
/*    */   String postscript;
/*    */   boolean generatedSwitch;
/*    */   boolean generatedAnIf;
/*    */   boolean needAnErrorClause;
/*    */   
/*    */   public CppBlockFinishingInfo() {
/* 25 */     this.postscript = null;
/* 26 */     this.generatedSwitch = false;
/* 27 */     this.needAnErrorClause = true;
/*    */   }
/*    */   public CppBlockFinishingInfo(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 30 */     this.postscript = paramString;
/* 31 */     this.generatedSwitch = paramBoolean1;
/* 32 */     this.generatedAnIf = paramBoolean2;
/* 33 */     this.needAnErrorClause = paramBoolean3;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\CppBlockFinishingInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
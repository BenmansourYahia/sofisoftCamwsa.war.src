package antlr;

public interface LLkGrammarAnalyzer extends GrammarAnalyzer {
  boolean deterministic(AlternativeBlock paramAlternativeBlock);
  
  boolean deterministic(OneOrMoreBlock paramOneOrMoreBlock);
  
  boolean deterministic(ZeroOrMoreBlock paramZeroOrMoreBlock);
  
  Lookahead FOLLOW(int paramInt, RuleEndElement paramRuleEndElement);
  
  Lookahead look(int paramInt, ActionElement paramActionElement);
  
  Lookahead look(int paramInt, AlternativeBlock paramAlternativeBlock);
  
  Lookahead look(int paramInt, BlockEndElement paramBlockEndElement);
  
  Lookahead look(int paramInt, CharLiteralElement paramCharLiteralElement);
  
  Lookahead look(int paramInt, CharRangeElement paramCharRangeElement);
  
  Lookahead look(int paramInt, GrammarAtom paramGrammarAtom);
  
  Lookahead look(int paramInt, OneOrMoreBlock paramOneOrMoreBlock);
  
  Lookahead look(int paramInt, RuleBlock paramRuleBlock);
  
  Lookahead look(int paramInt, RuleEndElement paramRuleEndElement);
  
  Lookahead look(int paramInt, RuleRefElement paramRuleRefElement);
  
  Lookahead look(int paramInt, StringLiteralElement paramStringLiteralElement);
  
  Lookahead look(int paramInt, SynPredBlock paramSynPredBlock);
  
  Lookahead look(int paramInt, TokenRangeElement paramTokenRangeElement);
  
  Lookahead look(int paramInt, TreeElement paramTreeElement);
  
  Lookahead look(int paramInt, WildcardElement paramWildcardElement);
  
  Lookahead look(int paramInt, ZeroOrMoreBlock paramZeroOrMoreBlock);
  
  Lookahead look(int paramInt, String paramString);
  
  void setGrammar(Grammar paramGrammar);
  
  boolean subruleCanBeInverted(AlternativeBlock paramAlternativeBlock, boolean paramBoolean);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\LLkGrammarAnalyzer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
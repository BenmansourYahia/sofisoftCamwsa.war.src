/*    */ package antlr;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharBuffer
/*    */   extends InputBuffer
/*    */ {
/*    */   public transient Reader input;
/*    */   
/*    */   public CharBuffer(Reader paramReader) {
/* 36 */     this.input = paramReader;
/*    */   }
/*    */ 
/*    */   
/*    */   public void fill(int paramInt) throws CharStreamException {
/*    */     try {
/* 42 */       syncConsume();
/*    */       
/* 44 */       while (this.queue.nbrEntries < paramInt + this.markerOffset)
/*    */       {
/* 46 */         this.queue.append((char)this.input.read());
/*    */       }
/*    */     }
/* 49 */     catch (IOException iOException) {
/* 50 */       throw new CharStreamIOException(iOException);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\CharBuffer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package antlr.collections.impl;
/*     */ 
/*     */ import antlr.CharFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitSet
/*     */   implements Cloneable
/*     */ {
/*     */   protected static final int BITS = 64;
/*     */   protected static final int NIBBLE = 4;
/*     */   protected static final int LOG_BITS = 6;
/*     */   protected static final int MOD_MASK = 63;
/*     */   protected long[] bits;
/*     */   
/*     */   public BitSet() {
/*  44 */     this(64);
/*     */   }
/*     */ 
/*     */   
/*     */   public BitSet(long[] paramArrayOflong) {
/*  49 */     this.bits = paramArrayOflong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BitSet(int paramInt) {
/*  56 */     this.bits = new long[(paramInt - 1 >> 6) + 1];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int paramInt) {
/*  62 */     int i = wordNumber(paramInt);
/*     */ 
/*     */     
/*  65 */     if (i >= this.bits.length) {
/*  66 */       growToInclude(paramInt);
/*     */     }
/*  68 */     this.bits[i] = this.bits[i] | bitMask(paramInt);
/*     */   }
/*     */   
/*     */   public BitSet and(BitSet paramBitSet) {
/*  72 */     BitSet bitSet = (BitSet)clone();
/*  73 */     bitSet.andInPlace(paramBitSet);
/*  74 */     return bitSet;
/*     */   }
/*     */   
/*     */   public void andInPlace(BitSet paramBitSet) {
/*  78 */     int i = Math.min(this.bits.length, paramBitSet.bits.length); int j;
/*  79 */     for (j = i - 1; j >= 0; j--) {
/*  80 */       this.bits[j] = this.bits[j] & paramBitSet.bits[j];
/*     */     }
/*     */     
/*  83 */     for (j = i; j < this.bits.length; j++) {
/*  84 */       this.bits[j] = 0L;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final long bitMask(int paramInt) {
/*  89 */     int i = paramInt & 0x3F;
/*  90 */     return 1L << i;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  94 */     for (int i = this.bits.length - 1; i >= 0; i--) {
/*  95 */       this.bits[i] = 0L;
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear(int paramInt) {
/* 100 */     int i = wordNumber(paramInt);
/* 101 */     if (i >= this.bits.length) {
/* 102 */       growToInclude(paramInt);
/*     */     }
/* 104 */     this.bits[i] = this.bits[i] & (bitMask(paramInt) ^ 0xFFFFFFFFFFFFFFFFL);
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     BitSet bitSet;
/*     */     try {
/* 110 */       bitSet = (BitSet)super.clone();
/* 111 */       bitSet.bits = new long[this.bits.length];
/* 112 */       System.arraycopy(this.bits, 0, bitSet.bits, 0, this.bits.length);
/*     */     }
/* 114 */     catch (CloneNotSupportedException cloneNotSupportedException) {
/* 115 */       throw new InternalError();
/*     */     } 
/* 117 */     return bitSet;
/*     */   }
/*     */   
/*     */   public int degree() {
/* 121 */     byte b = 0;
/* 122 */     for (int i = this.bits.length - 1; i >= 0; i--) {
/* 123 */       long l = this.bits[i];
/* 124 */       if (l != 0L) {
/* 125 */         for (byte b1 = 63; b1 >= 0; b1--) {
/* 126 */           if ((l & 1L << b1) != 0L) {
/* 127 */             b++;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 132 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 137 */     if (paramObject != null && paramObject instanceof BitSet) {
/* 138 */       BitSet bitSet = (BitSet)paramObject;
/*     */       
/* 140 */       int i = Math.min(this.bits.length, bitSet.bits.length); int j;
/* 141 */       for (j = i; j-- > 0;) {
/* 142 */         if (this.bits[j] != bitSet.bits[j]) {
/* 143 */           return false;
/*     */         }
/*     */       } 
/* 146 */       if (this.bits.length > i) {
/* 147 */         for (j = this.bits.length; j-- > i;) {
/* 148 */           if (this.bits[j] != 0L) {
/* 149 */             return false;
/*     */           }
/*     */         }
/*     */       
/* 153 */       } else if (bitSet.bits.length > i) {
/* 154 */         for (j = bitSet.bits.length; j-- > i;) {
/* 155 */           if (bitSet.bits[j] != 0L) {
/* 156 */             return false;
/*     */           }
/*     */         } 
/*     */       } 
/* 160 */       return true;
/*     */     } 
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector getRanges(int[] paramArrayOfint) {
/* 170 */     if (paramArrayOfint.length == 0) {
/* 171 */       return null;
/*     */     }
/* 173 */     int i = paramArrayOfint[0];
/* 174 */     int j = paramArrayOfint[paramArrayOfint.length - 1];
/* 175 */     if (paramArrayOfint.length <= 2)
/*     */     {
/* 177 */       return null;
/*     */     }
/*     */     
/* 180 */     Vector vector = new Vector(5);
/*     */     
/* 182 */     for (byte b = 0; b < paramArrayOfint.length - 2; b++) {
/*     */       
/* 184 */       int k = paramArrayOfint.length - 1;
/* 185 */       for (int m = b + 1; m < paramArrayOfint.length; m++) {
/* 186 */         if (paramArrayOfint[m] != paramArrayOfint[m - 1] + 1) {
/* 187 */           k = m - 1;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 192 */       if (k - b > 2) {
/* 193 */         vector.appendElement(new IntRange(paramArrayOfint[b], paramArrayOfint[k]));
/*     */       }
/*     */     } 
/* 196 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void growToInclude(int paramInt) {
/* 204 */     int i = Math.max(this.bits.length << 1, numWordsToHold(paramInt));
/* 205 */     long[] arrayOfLong = new long[i];
/* 206 */     System.arraycopy(this.bits, 0, arrayOfLong, 0, this.bits.length);
/* 207 */     this.bits = arrayOfLong;
/*     */   }
/*     */   
/*     */   public boolean member(int paramInt) {
/* 211 */     int i = wordNumber(paramInt);
/* 212 */     if (i >= this.bits.length) return false; 
/* 213 */     return ((this.bits[i] & bitMask(paramInt)) != 0L);
/*     */   }
/*     */   
/*     */   public boolean nil() {
/* 217 */     for (int i = this.bits.length - 1; i >= 0; i--) {
/* 218 */       if (this.bits[i] != 0L) return false; 
/*     */     } 
/* 220 */     return true;
/*     */   }
/*     */   
/*     */   public BitSet not() {
/* 224 */     BitSet bitSet = (BitSet)clone();
/* 225 */     bitSet.notInPlace();
/* 226 */     return bitSet;
/*     */   }
/*     */   
/*     */   public void notInPlace() {
/* 230 */     for (int i = this.bits.length - 1; i >= 0; i--) {
/* 231 */       this.bits[i] = this.bits[i] ^ 0xFFFFFFFFFFFFFFFFL;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void notInPlace(int paramInt) {
/* 237 */     notInPlace(0, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notInPlace(int paramInt1, int paramInt2) {
/* 243 */     growToInclude(paramInt2);
/* 244 */     for (int i = paramInt1; i <= paramInt2; i++) {
/* 245 */       int j = wordNumber(i);
/* 246 */       this.bits[j] = this.bits[j] ^ bitMask(i);
/*     */     } 
/*     */   }
/*     */   
/*     */   private final int numWordsToHold(int paramInt) {
/* 251 */     return (paramInt >> 6) + 1;
/*     */   }
/*     */   
/*     */   public static BitSet of(int paramInt) {
/* 255 */     BitSet bitSet = new BitSet(paramInt + 1);
/* 256 */     bitSet.add(paramInt);
/* 257 */     return bitSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public BitSet or(BitSet paramBitSet) {
/* 262 */     BitSet bitSet = (BitSet)clone();
/* 263 */     bitSet.orInPlace(paramBitSet);
/* 264 */     return bitSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public void orInPlace(BitSet paramBitSet) {
/* 269 */     if (paramBitSet.bits.length > this.bits.length) {
/* 270 */       setSize(paramBitSet.bits.length);
/*     */     }
/* 272 */     int i = Math.min(this.bits.length, paramBitSet.bits.length);
/* 273 */     for (int j = i - 1; j >= 0; j--) {
/* 274 */       this.bits[j] = this.bits[j] | paramBitSet.bits[j];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int paramInt) {
/* 280 */     int i = wordNumber(paramInt);
/* 281 */     if (i >= this.bits.length) {
/* 282 */       growToInclude(paramInt);
/*     */     }
/* 284 */     this.bits[i] = this.bits[i] & (bitMask(paramInt) ^ 0xFFFFFFFFFFFFFFFFL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSize(int paramInt) {
/* 292 */     long[] arrayOfLong = new long[paramInt];
/* 293 */     int i = Math.min(paramInt, this.bits.length);
/* 294 */     System.arraycopy(this.bits, 0, arrayOfLong, 0, i);
/* 295 */     this.bits = arrayOfLong;
/*     */   }
/*     */   
/*     */   public int size() {
/* 299 */     return this.bits.length << 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lengthInLongWords() {
/* 306 */     return this.bits.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean subset(BitSet paramBitSet) {
/* 311 */     if (paramBitSet == null || !(paramBitSet instanceof BitSet)) return false; 
/* 312 */     return and(paramBitSet).equals(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subtractInPlace(BitSet paramBitSet) {
/* 319 */     if (paramBitSet == null)
/*     */       return; 
/* 321 */     for (byte b = 0; b < this.bits.length && b < paramBitSet.bits.length; b++) {
/* 322 */       this.bits[b] = this.bits[b] & (paramBitSet.bits[b] ^ 0xFFFFFFFFFFFFFFFFL);
/*     */     }
/*     */   }
/*     */   
/*     */   public int[] toArray() {
/* 327 */     int[] arrayOfInt = new int[degree()];
/* 328 */     byte b1 = 0;
/* 329 */     for (byte b2 = 0; b2 < this.bits.length << 6; b2++) {
/* 330 */       if (member(b2)) {
/* 331 */         arrayOfInt[b1++] = b2;
/*     */       }
/*     */     } 
/* 334 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   public long[] toPackedArray() {
/* 338 */     return this.bits;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 342 */     return toString(",");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(String paramString) {
/* 350 */     String str = "";
/* 351 */     for (byte b = 0; b < this.bits.length << 6; b++) {
/* 352 */       if (member(b)) {
/* 353 */         if (str.length() > 0) {
/* 354 */           str = str + paramString;
/*     */         }
/* 356 */         str = str + b;
/*     */       } 
/*     */     } 
/* 359 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(String paramString, CharFormatter paramCharFormatter) {
/* 368 */     String str = "";
/*     */     
/* 370 */     for (byte b = 0; b < this.bits.length << 6; b++) {
/* 371 */       if (member(b)) {
/* 372 */         if (str.length() > 0) {
/* 373 */           str = str + paramString;
/*     */         }
/* 375 */         str = str + paramCharFormatter.literalChar(b);
/*     */       } 
/*     */     } 
/* 378 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(String paramString, Vector paramVector) {
/* 388 */     if (paramVector == null) {
/* 389 */       return toString(paramString);
/*     */     }
/* 391 */     String str = "";
/* 392 */     for (byte b = 0; b < this.bits.length << 6; b++) {
/* 393 */       if (member(b)) {
/* 394 */         if (str.length() > 0) {
/* 395 */           str = str + paramString;
/*     */         }
/* 397 */         if (b >= paramVector.size()) {
/* 398 */           str = str + "<bad element " + b + ">";
/*     */         }
/* 400 */         else if (paramVector.elementAt(b) == null) {
/* 401 */           str = str + "<" + b + ">";
/*     */         } else {
/*     */           
/* 404 */           str = str + (String)paramVector.elementAt(b);
/*     */         } 
/*     */       } 
/*     */     } 
/* 408 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringOfHalfWords() {
/* 417 */     String str = new String();
/* 418 */     for (byte b = 0; b < this.bits.length; b++) {
/* 419 */       if (b != 0) str = str + ", "; 
/* 420 */       long l = this.bits[b];
/* 421 */       l &= 0xFFFFFFFFL;
/* 422 */       str = str + l + "UL";
/* 423 */       str = str + ", ";
/* 424 */       l = this.bits[b] >>> 32L;
/* 425 */       l &= 0xFFFFFFFFL;
/* 426 */       str = str + l + "UL";
/*     */     } 
/* 428 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringOfWords() {
/* 436 */     String str = new String();
/* 437 */     for (byte b = 0; b < this.bits.length; b++) {
/* 438 */       if (b != 0) str = str + ", "; 
/* 439 */       str = str + this.bits[b] + "L";
/*     */     } 
/* 441 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringWithRanges(String paramString, CharFormatter paramCharFormatter) {
/* 446 */     String str = "";
/* 447 */     int[] arrayOfInt = toArray();
/* 448 */     if (arrayOfInt.length == 0) {
/* 449 */       return "";
/*     */     }
/*     */     
/* 452 */     int i = 0;
/* 453 */     while (i < arrayOfInt.length) {
/*     */       
/* 455 */       int j = 0;
/* 456 */       for (int k = i + 1; k < arrayOfInt.length && 
/* 457 */         arrayOfInt[k] == arrayOfInt[k - 1] + 1; k++)
/*     */       {
/*     */         
/* 460 */         j = k;
/*     */       }
/*     */       
/* 463 */       if (str.length() > 0) {
/* 464 */         str = str + paramString;
/*     */       }
/* 466 */       if (j - i >= 2) {
/* 467 */         str = str + paramCharFormatter.literalChar(arrayOfInt[i]);
/* 468 */         str = str + "..";
/* 469 */         str = str + paramCharFormatter.literalChar(arrayOfInt[j]);
/* 470 */         i = j;
/*     */       } else {
/*     */         
/* 473 */         str = str + paramCharFormatter.literalChar(arrayOfInt[i]);
/*     */       } 
/* 475 */       i++;
/*     */     } 
/* 477 */     return str;
/*     */   }
/*     */   
/*     */   private static final int wordNumber(int paramInt) {
/* 481 */     return paramInt >> 6;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\BitSet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
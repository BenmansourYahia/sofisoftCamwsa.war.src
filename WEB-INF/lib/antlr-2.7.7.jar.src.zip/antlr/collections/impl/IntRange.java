/*    */ package antlr.collections.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntRange
/*    */ {
/*    */   int begin;
/*    */   int end;
/*    */   
/*    */   public IntRange(int paramInt1, int paramInt2) {
/* 15 */     this.begin = paramInt1;
/* 16 */     this.end = paramInt2;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 20 */     return this.begin + ".." + this.end;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\IntRange.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
package antlr.collections;

import antlr.Token;

public interface AST {
  void addChild(AST paramAST);
  
  boolean equals(AST paramAST);
  
  boolean equalsList(AST paramAST);
  
  boolean equalsListPartial(AST paramAST);
  
  boolean equalsTree(AST paramAST);
  
  boolean equalsTreePartial(AST paramAST);
  
  ASTEnumeration findAll(AST paramAST);
  
  ASTEnumeration findAllPartial(AST paramAST);
  
  AST getFirstChild();
  
  AST getNextSibling();
  
  String getText();
  
  int getType();
  
  int getLine();
  
  int getColumn();
  
  int getNumberOfChildren();
  
  void initialize(int paramInt, String paramString);
  
  void initialize(AST paramAST);
  
  void initialize(Token paramToken);
  
  void setFirstChild(AST paramAST);
  
  void setNextSibling(AST paramAST);
  
  void setText(String paramString);
  
  void setType(int paramInt);
  
  String toString();
  
  String toStringList();
  
  String toStringTree();
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\collections\AST.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
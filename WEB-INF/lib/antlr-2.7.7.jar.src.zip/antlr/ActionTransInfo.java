/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionTransInfo
/*    */ {
/*    */   public boolean assignToRoot = false;
/* 16 */   public String refRuleRoot = null;
/* 17 */   public String followSetName = null;
/*    */   
/*    */   public String toString() {
/* 20 */     return "assignToRoot:" + this.assignToRoot + ", refRuleRoot:" + this.refRuleRoot + ", FOLLOW Set:" + this.followSetName;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\ActionTransInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TokenRefElement
/*    */   extends GrammarAtom
/*    */ {
/*    */   public TokenRefElement(Grammar paramGrammar, Token paramToken, boolean paramBoolean, int paramInt) {
/* 16 */     super(paramGrammar, paramToken, paramInt);
/* 17 */     this.not = paramBoolean;
/* 18 */     TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(this.atomText);
/* 19 */     if (tokenSymbol == null) {
/* 20 */       paramGrammar.antlrTool.error("Undefined token symbol: " + this.atomText, this.grammar.getFilename(), paramToken.getLine(), paramToken.getColumn());
/*    */     }
/*    */     else {
/*    */       
/* 24 */       this.tokenType = tokenSymbol.getTokenType();
/*    */ 
/*    */ 
/*    */       
/* 28 */       setASTNodeType(tokenSymbol.getASTNodeType());
/*    */     } 
/* 30 */     this.line = paramToken.getLine();
/*    */   }
/*    */   
/*    */   public void generate() {
/* 34 */     this.grammar.generator.gen(this);
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 38 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\TokenRefElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
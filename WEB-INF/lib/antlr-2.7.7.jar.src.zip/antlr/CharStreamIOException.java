/*    */ package antlr;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharStreamIOException
/*    */   extends CharStreamException
/*    */ {
/*    */   public IOException io;
/*    */   
/*    */   public CharStreamIOException(IOException paramIOException) {
/* 19 */     super(paramIOException.getMessage());
/* 20 */     this.io = paramIOException;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\CharStreamIOException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
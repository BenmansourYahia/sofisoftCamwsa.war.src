/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharStreamException
/*    */   extends ANTLRException
/*    */ {
/*    */   public CharStreamException(String paramString) {
/* 19 */     super(paramString);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\CharStreamException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
package antlr.debug;

public interface NewLineListener extends ListenerBase {
  void hitNewLine(NewLineEvent paramNewLineEvent);
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\NewLineListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
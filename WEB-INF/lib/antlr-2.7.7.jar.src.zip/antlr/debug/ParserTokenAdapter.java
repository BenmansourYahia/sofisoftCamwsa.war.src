package antlr.debug;

public class ParserTokenAdapter implements ParserTokenListener {
  public void doneParsing(TraceEvent paramTraceEvent) {}
  
  public void parserConsume(ParserTokenEvent paramParserTokenEvent) {}
  
  public void parserLA(ParserTokenEvent paramParserTokenEvent) {}
  
  public void refresh() {}
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\ParserTokenAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
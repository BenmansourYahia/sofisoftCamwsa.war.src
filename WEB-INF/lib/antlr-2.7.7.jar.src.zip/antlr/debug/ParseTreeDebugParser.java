/*     */ package antlr.debug;
/*     */ 
/*     */ import antlr.CommonToken;
/*     */ import antlr.LLkParser;
/*     */ import antlr.MismatchedTokenException;
/*     */ import antlr.ParseTree;
/*     */ import antlr.ParseTreeRule;
/*     */ import antlr.ParseTreeToken;
/*     */ import antlr.ParserSharedInputState;
/*     */ import antlr.Token;
/*     */ import antlr.TokenBuffer;
/*     */ import antlr.TokenStream;
/*     */ import antlr.TokenStreamException;
/*     */ import antlr.collections.AST;
/*     */ import antlr.collections.impl.BitSet;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTreeDebugParser
/*     */   extends LLkParser
/*     */ {
/*  23 */   protected Stack currentParseTreeRoot = new Stack();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  28 */   protected ParseTreeRule mostRecentParseTreeRoot = null;
/*     */ 
/*     */   
/*  31 */   protected int numberOfDerivationSteps = 1;
/*     */   
/*     */   public ParseTreeDebugParser(int paramInt) {
/*  34 */     super(paramInt);
/*     */   }
/*     */   
/*     */   public ParseTreeDebugParser(ParserSharedInputState paramParserSharedInputState, int paramInt) {
/*  38 */     super(paramParserSharedInputState, paramInt);
/*     */   }
/*     */   
/*     */   public ParseTreeDebugParser(TokenBuffer paramTokenBuffer, int paramInt) {
/*  42 */     super(paramTokenBuffer, paramInt);
/*     */   }
/*     */   
/*     */   public ParseTreeDebugParser(TokenStream paramTokenStream, int paramInt) {
/*  46 */     super(paramTokenStream, paramInt);
/*     */   }
/*     */   
/*     */   public ParseTree getParseTree() {
/*  50 */     return (ParseTree)this.mostRecentParseTreeRoot;
/*     */   }
/*     */   
/*     */   public int getNumberOfDerivationSteps() {
/*  54 */     return this.numberOfDerivationSteps;
/*     */   }
/*     */   
/*     */   public void match(int paramInt) throws MismatchedTokenException, TokenStreamException {
/*  58 */     addCurrentTokenToParseTree();
/*  59 */     super.match(paramInt);
/*     */   }
/*     */   
/*     */   public void match(BitSet paramBitSet) throws MismatchedTokenException, TokenStreamException {
/*  63 */     addCurrentTokenToParseTree();
/*  64 */     super.match(paramBitSet);
/*     */   }
/*     */   
/*     */   public void matchNot(int paramInt) throws MismatchedTokenException, TokenStreamException {
/*  68 */     addCurrentTokenToParseTree();
/*  69 */     super.matchNot(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addCurrentTokenToParseTree() throws TokenStreamException {
/*  80 */     if (this.inputState.guessing > 0) {
/*     */       return;
/*     */     }
/*  83 */     ParseTreeRule parseTreeRule = this.currentParseTreeRoot.peek();
/*  84 */     ParseTreeToken parseTreeToken = null;
/*  85 */     if (LA(1) == 1) {
/*  86 */       parseTreeToken = new ParseTreeToken((Token)new CommonToken("EOF"));
/*     */     } else {
/*     */       
/*  89 */       parseTreeToken = new ParseTreeToken(LT(1));
/*     */     } 
/*  91 */     parseTreeRule.addChild((AST)parseTreeToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traceIn(String paramString) throws TokenStreamException {
/*  96 */     if (this.inputState.guessing > 0) {
/*     */       return;
/*     */     }
/*  99 */     ParseTreeRule parseTreeRule = new ParseTreeRule(paramString);
/* 100 */     if (this.currentParseTreeRoot.size() > 0) {
/* 101 */       ParseTreeRule parseTreeRule1 = this.currentParseTreeRoot.peek();
/* 102 */       parseTreeRule1.addChild((AST)parseTreeRule);
/*     */     } 
/* 104 */     this.currentParseTreeRoot.push(parseTreeRule);
/* 105 */     this.numberOfDerivationSteps++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traceOut(String paramString) throws TokenStreamException {
/* 110 */     if (this.inputState.guessing > 0) {
/*     */       return;
/*     */     }
/* 113 */     this.mostRecentParseTreeRoot = this.currentParseTreeRoot.pop();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\ParseTreeDebugParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
package antlr.debug;

public class SyntacticPredicateAdapter implements SyntacticPredicateListener {
  public void doneParsing(TraceEvent paramTraceEvent) {}
  
  public void refresh() {}
  
  public void syntacticPredicateFailed(SyntacticPredicateEvent paramSyntacticPredicateEvent) {}
  
  public void syntacticPredicateStarted(SyntacticPredicateEvent paramSyntacticPredicateEvent) {}
  
  public void syntacticPredicateSucceeded(SyntacticPredicateEvent paramSyntacticPredicateEvent) {}
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\SyntacticPredicateAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
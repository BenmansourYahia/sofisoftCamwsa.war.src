/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BlockContext
/*    */ {
/*    */   AlternativeBlock block;
/*    */   int altNum;
/*    */   BlockEndElement blockEnd;
/*    */   
/*    */   public void addAlternativeElement(AlternativeElement paramAlternativeElement) {
/* 22 */     currentAlt().addElement(paramAlternativeElement);
/*    */   }
/*    */   
/*    */   public Alternative currentAlt() {
/* 26 */     return (Alternative)this.block.alternatives.elementAt(this.altNum);
/*    */   }
/*    */   
/*    */   public AlternativeElement currentElement() {
/* 30 */     return (currentAlt()).tail;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\BlockContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package antlr;
/*    */ 
/*    */ import antlr.ASdebug.ASDebugStream;
/*    */ import antlr.ASdebug.IASDebugStream;
/*    */ import antlr.ASdebug.TokenOffsetInfo;
/*    */ import antlr.collections.impl.BitSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TokenStreamBasicFilter
/*    */   implements TokenStream, IASDebugStream
/*    */ {
/*    */   protected BitSet discardMask;
/*    */   protected TokenStream input;
/*    */   
/*    */   public TokenStreamBasicFilter(TokenStream paramTokenStream) {
/* 27 */     this.input = paramTokenStream;
/* 28 */     this.discardMask = new BitSet();
/*    */   }
/*    */   
/*    */   public void discard(int paramInt) {
/* 32 */     this.discardMask.add(paramInt);
/*    */   }
/*    */   
/*    */   public void discard(BitSet paramBitSet) {
/* 36 */     this.discardMask = paramBitSet;
/*    */   }
/*    */   
/*    */   public Token nextToken() throws TokenStreamException {
/* 40 */     Token token = this.input.nextToken();
/* 41 */     while (token != null && this.discardMask.member(token.getType())) {
/* 42 */       token = this.input.nextToken();
/*    */     }
/* 44 */     return token;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getEntireText() {
/* 49 */     return ASDebugStream.getEntireText(this.input);
/*    */   }
/*    */ 
/*    */   
/*    */   public TokenOffsetInfo getOffsetInfo(Token paramToken) {
/* 54 */     return ASDebugStream.getOffsetInfo(this.input, paramToken);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\TokenStreamBasicFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
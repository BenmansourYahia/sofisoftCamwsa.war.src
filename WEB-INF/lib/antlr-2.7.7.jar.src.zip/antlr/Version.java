package antlr;

public class Version {
  public static final String version = "2";
  
  public static final String subversion = "7";
  
  public static final String patchlevel = "7";
  
  public static final String datestamp = "20060906";
  
  public static final String project_version = "2.7.7 (20060906)";
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\Version.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
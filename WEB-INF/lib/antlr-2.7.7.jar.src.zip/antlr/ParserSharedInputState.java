/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParserSharedInputState
/*    */ {
/*    */   protected TokenBuffer input;
/* 20 */   public int guessing = 0;
/*    */   
/*    */   protected String filename;
/*    */ 
/*    */   
/*    */   public void reset() {
/* 26 */     this.guessing = 0;
/* 27 */     this.filename = null;
/* 28 */     this.input.reset();
/*    */   }
/*    */   
/*    */   public String getFilename() {
/* 32 */     return this.filename;
/*    */   }
/*    */   
/*    */   public TokenBuffer getInput() {
/* 36 */     return this.input;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\ParserSharedInputState.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
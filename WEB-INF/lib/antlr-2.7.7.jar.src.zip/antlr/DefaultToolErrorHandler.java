/*     */ package antlr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultToolErrorHandler
/*     */   implements ToolErrorHandler
/*     */ {
/*     */   private final Tool antlrTool;
/*     */   CharFormatter javaCharFormatter;
/*     */   
/*     */   DefaultToolErrorHandler(Tool paramTool) {
/*  18 */     this.javaCharFormatter = new JavaCharFormatter();
/*     */     this.antlrTool = paramTool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void dumpSets(String[] paramArrayOfString, int paramInt1, Grammar paramGrammar, boolean paramBoolean, int paramInt2, Lookahead[] paramArrayOfLookahead) {
/*  36 */     StringBuffer stringBuffer = new StringBuffer(100);
/*  37 */     for (byte b = 1; b <= paramInt2; b++) {
/*  38 */       stringBuffer.append("k==").append(b).append(':');
/*  39 */       if (paramBoolean) {
/*  40 */         String str = (paramArrayOfLookahead[b]).fset.toStringWithRanges(",", this.javaCharFormatter);
/*  41 */         if (paramArrayOfLookahead[b].containsEpsilon()) {
/*  42 */           stringBuffer.append("<end-of-token>");
/*  43 */           if (str.length() > 0) {
/*  44 */             stringBuffer.append(',');
/*     */           }
/*     */         } 
/*  47 */         stringBuffer.append(str);
/*     */       } else {
/*  49 */         stringBuffer.append((paramArrayOfLookahead[b]).fset.toString(",", paramGrammar.tokenManager.getVocabulary()));
/*     */       } 
/*  51 */       paramArrayOfString[paramInt1++] = stringBuffer.toString();
/*  52 */       stringBuffer.setLength(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warnAltAmbiguity(Grammar paramGrammar, AlternativeBlock paramAlternativeBlock, boolean paramBoolean, int paramInt1, Lookahead[] paramArrayOfLookahead, int paramInt2, int paramInt3) {
/*  72 */     StringBuffer stringBuffer = new StringBuffer(100);
/*  73 */     if (paramAlternativeBlock instanceof RuleBlock && ((RuleBlock)paramAlternativeBlock).isLexerAutoGenRule()) {
/*  74 */       Alternative alternative1 = paramAlternativeBlock.getAlternativeAt(paramInt2);
/*  75 */       Alternative alternative2 = paramAlternativeBlock.getAlternativeAt(paramInt3);
/*  76 */       RuleRefElement ruleRefElement1 = (RuleRefElement)alternative1.head;
/*  77 */       RuleRefElement ruleRefElement2 = (RuleRefElement)alternative2.head;
/*  78 */       String str1 = CodeGenerator.reverseLexerRuleName(ruleRefElement1.targetRule);
/*  79 */       String str2 = CodeGenerator.reverseLexerRuleName(ruleRefElement2.targetRule);
/*  80 */       stringBuffer.append("lexical nondeterminism between rules ");
/*  81 */       stringBuffer.append(str1).append(" and ").append(str2).append(" upon");
/*     */     } else {
/*     */       
/*  84 */       if (paramBoolean) {
/*  85 */         stringBuffer.append("lexical ");
/*     */       }
/*  87 */       stringBuffer.append("nondeterminism between alts ");
/*  88 */       stringBuffer.append(paramInt2 + 1).append(" and ");
/*  89 */       stringBuffer.append(paramInt3 + 1).append(" of block upon");
/*     */     } 
/*  91 */     String[] arrayOfString = new String[paramInt1 + 1];
/*  92 */     arrayOfString[0] = stringBuffer.toString();
/*  93 */     dumpSets(arrayOfString, 1, paramGrammar, paramBoolean, paramInt1, paramArrayOfLookahead);
/*  94 */     this.antlrTool.warning(arrayOfString, paramGrammar.getFilename(), paramAlternativeBlock.getLine(), paramAlternativeBlock.getColumn());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warnAltExitAmbiguity(Grammar paramGrammar, BlockWithImpliedExitPath paramBlockWithImpliedExitPath, boolean paramBoolean, int paramInt1, Lookahead[] paramArrayOfLookahead, int paramInt2) {
/* 113 */     String[] arrayOfString = new String[paramInt1 + 2];
/* 114 */     arrayOfString[0] = (paramBoolean ? "lexical " : "") + "nondeterminism upon";
/* 115 */     dumpSets(arrayOfString, 1, paramGrammar, paramBoolean, paramInt1, paramArrayOfLookahead);
/* 116 */     arrayOfString[paramInt1 + 1] = "between alt " + (paramInt2 + 1) + " and exit branch of block";
/* 117 */     this.antlrTool.warning(arrayOfString, paramGrammar.getFilename(), paramBlockWithImpliedExitPath.getLine(), paramBlockWithImpliedExitPath.getColumn());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\DefaultToolErrorHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
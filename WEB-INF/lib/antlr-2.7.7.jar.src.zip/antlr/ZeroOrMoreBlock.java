/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ZeroOrMoreBlock
/*    */   extends BlockWithImpliedExitPath
/*    */ {
/*    */   public ZeroOrMoreBlock(Grammar paramGrammar) {
/* 13 */     super(paramGrammar);
/*    */   }
/*    */   
/*    */   public ZeroOrMoreBlock(Grammar paramGrammar, Token paramToken) {
/* 17 */     super(paramGrammar, paramToken);
/*    */   }
/*    */   
/*    */   public void generate() {
/* 21 */     this.grammar.generator.gen(this);
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 25 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 29 */     return super.toString() + "*";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\ZeroOrMoreBlock.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
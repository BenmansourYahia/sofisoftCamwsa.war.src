/*    */ package antlr;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTIterator
/*    */ {
/* 13 */   protected AST cursor = null;
/* 14 */   protected AST original = null;
/*    */ 
/*    */   
/*    */   public ASTIterator(AST paramAST) {
/* 18 */     this.original = this.cursor = paramAST;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSubtree(AST paramAST1, AST paramAST2) {
/* 26 */     if (paramAST2 == null) {
/* 27 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 31 */     if (paramAST1 == null) {
/* 32 */       if (paramAST2 != null) return false; 
/* 33 */       return true;
/*    */     } 
/*    */ 
/*    */     
/* 37 */     AST aST = paramAST1;
/* 38 */     for (; aST != null && paramAST2 != null; 
/* 39 */       aST = aST.getNextSibling(), paramAST2 = paramAST2.getNextSibling()) {
/*    */       
/* 41 */       if (aST.getType() != paramAST2.getType()) return false;
/*    */       
/* 43 */       if (aST.getFirstChild() != null && 
/* 44 */         !isSubtree(aST.getFirstChild(), paramAST2.getFirstChild())) return false;
/*    */     
/*    */     } 
/* 47 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AST next(AST paramAST) {
/* 54 */     AST aST = null;
/* 55 */     Object object = null;
/*    */     
/* 57 */     if (this.cursor == null) {
/* 58 */       return null;
/*    */     }
/*    */ 
/*    */     
/* 62 */     for (; this.cursor != null; this.cursor = this.cursor.getNextSibling()) {
/*    */       
/* 64 */       if (this.cursor.getType() == paramAST.getType())
/*    */       {
/* 66 */         if (this.cursor.getFirstChild() != null && 
/* 67 */           isSubtree(this.cursor.getFirstChild(), paramAST.getFirstChild())) {
/* 68 */           return this.cursor;
/*    */         }
/*    */       }
/*    */     } 
/*    */     
/* 73 */     return aST;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\ASTIterator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*      */ package antlr.actions.python;
/*      */ 
/*      */ import antlr.ActionTransInfo;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.CodeGenerator;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.RuleBlock;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.Tool;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ActionLexer
/*      */   extends CharScanner
/*      */   implements ActionLexerTokenTypes, TokenStream
/*      */ {
/*      */   protected RuleBlock currentRule;
/*      */   protected CodeGenerator generator;
/*   63 */   protected int lineOffset = 0;
/*      */ 
/*      */   
/*      */   private Tool antlrTool;
/*      */ 
/*      */   
/*      */   ActionTransInfo transInfo;
/*      */ 
/*      */   
/*      */   public ActionLexer(String paramString, RuleBlock paramRuleBlock, CodeGenerator paramCodeGenerator, ActionTransInfo paramActionTransInfo) {
/*   73 */     this(new StringReader(paramString));
/*   74 */     this.currentRule = paramRuleBlock;
/*   75 */     this.generator = paramCodeGenerator;
/*   76 */     this.transInfo = paramActionTransInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLineOffset(int paramInt) {
/*   81 */     setLine(paramInt);
/*      */   }
/*      */   
/*      */   public void setTool(Tool paramTool) {
/*   85 */     this.antlrTool = paramTool;
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportError(RecognitionException paramRecognitionException) {
/*   90 */     this.antlrTool.error("Syntax error in action: " + paramRecognitionException, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportError(String paramString) {
/*   97 */     this.antlrTool.error(paramString, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportWarning(String paramString) {
/*  102 */     if (getFilename() == null) {
/*  103 */       this.antlrTool.warning(paramString);
/*      */     } else {
/*      */       
/*  106 */       this.antlrTool.warning(paramString, getFilename(), getLine(), getColumn());
/*      */     } 
/*      */   }
/*      */   public ActionLexer(InputStream paramInputStream) {
/*  110 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public ActionLexer(Reader paramReader) {
/*  113 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public ActionLexer(InputBuffer paramInputBuffer) {
/*  116 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public ActionLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  119 */     super(paramLexerSharedInputState);
/*  120 */     this.caseSensitiveLiterals = true;
/*  121 */     setCaseSensitive(true);
/*  122 */     this.literals = new Hashtable();
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  126 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  129 */       Object object = null;
/*  130 */       int i = 0;
/*  131 */       resetText();
/*      */       
/*      */       try {
/*  134 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ')
/*  135 */         { mACTION(true);
/*  136 */           token = this._returnToken;
/*      */            }
/*      */         
/*  139 */         else if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); }
/*  140 */         else { throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */         
/*  143 */         if (this._returnToken == null)
/*  144 */           continue;  i = this._returnToken.getType();
/*  145 */         this._returnToken.setType(i);
/*  146 */         return this._returnToken;
/*      */       }
/*  148 */       catch (RecognitionException recognitionException) {
/*  149 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  152 */       catch (CharStreamException charStreamException) {
/*  153 */         if (charStreamException instanceof CharStreamIOException) {
/*  154 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  157 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void mACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  164 */     Token token = null; int i = this.text.length();
/*  165 */     byte b1 = 4;
/*      */ 
/*      */ 
/*      */     
/*  169 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  172 */       switch (LA(1)) {
/*      */         
/*      */         case '#':
/*  175 */           mAST_ITEM(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '$':
/*  180 */           mTEXT_ITEM(false);
/*      */           break;
/*      */         
/*      */         default:
/*  184 */           if (_tokenSet_0.member(LA(1))) {
/*  185 */             mSTUFF(false);
/*      */             break;
/*      */           } 
/*  188 */           if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  191 */       b2++;
/*      */     } 
/*      */     
/*  194 */     if (paramBoolean && token == null && b1 != -1) {
/*  195 */       token = makeToken(b1);
/*  196 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  198 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSTUFF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  202 */     Token token = null; int i = this.text.length();
/*  203 */     byte b = 5;
/*      */ 
/*      */     
/*  206 */     switch (LA(1)) {
/*      */       
/*      */       case '"':
/*  209 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/*  214 */         mCHAR(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\n':
/*  219 */         match('\n');
/*  220 */         newline();
/*      */         break;
/*      */       
/*      */       default:
/*  224 */         if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/*  225 */           mCOMMENT(false); break;
/*      */         } 
/*  227 */         if (LA(1) == '\r' && LA(2) == '\n') {
/*  228 */           match("\r\n");
/*  229 */           newline(); break;
/*      */         } 
/*  231 */         if (LA(1) == '/' && _tokenSet_1.member(LA(2))) {
/*  232 */           match('/');
/*      */           
/*  234 */           match(_tokenSet_1);
/*      */           break;
/*      */         } 
/*  237 */         if (LA(1) == '\r') {
/*  238 */           match('\r');
/*  239 */           newline(); break;
/*      */         } 
/*  241 */         if (_tokenSet_2.member(LA(1))) {
/*      */           
/*  243 */           match(_tokenSet_2);
/*      */           
/*      */           break;
/*      */         } 
/*  247 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  250 */     if (paramBoolean && token == null && b != -1) {
/*  251 */       token = makeToken(b);
/*  252 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  254 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  258 */     Token token1 = null; int i = this.text.length();
/*  259 */     byte b = 6;
/*      */     
/*  261 */     Token token2 = null;
/*  262 */     Token token3 = null;
/*  263 */     Token token4 = null;
/*      */     
/*  265 */     if (LA(1) == '#' && LA(2) == '(') {
/*  266 */       int j = this.text.length();
/*  267 */       match('#');
/*  268 */       this.text.setLength(j);
/*  269 */       mTREE(true);
/*  270 */       token2 = this._returnToken;
/*      */     }
/*  272 */     else if (LA(1) == '#' && _tokenSet_3.member(LA(2))) {
/*  273 */       int j = this.text.length();
/*  274 */       match('#');
/*  275 */       this.text.setLength(j);
/*  276 */       mID(true);
/*  277 */       token3 = this._returnToken;
/*      */       
/*  279 */       String str1 = token3.getText();
/*  280 */       String str2 = this.generator.mapTreeId(str1, this.transInfo);
/*  281 */       if (str2 != null) {
/*  282 */         this.text.setLength(i); this.text.append(str2);
/*      */       } 
/*      */ 
/*      */       
/*  286 */       if (_tokenSet_4.member(LA(1))) {
/*  287 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  294 */       if (LA(1) == '=') {
/*  295 */         mVAR_ASSIGN(false);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  302 */     else if (LA(1) == '#' && LA(2) == '[') {
/*  303 */       int j = this.text.length();
/*  304 */       match('#');
/*  305 */       this.text.setLength(j);
/*  306 */       mAST_CONSTRUCTOR(true);
/*  307 */       token4 = this._returnToken;
/*      */     }
/*  309 */     else if (LA(1) == '#' && LA(2) == '#') {
/*  310 */       match("##");
/*      */       
/*  312 */       String str = this.currentRule.getRuleName() + "_AST"; this.text.setLength(i); this.text.append(str);
/*  313 */       if (this.transInfo != null) {
/*  314 */         this.transInfo.refRuleRoot = str;
/*      */       }
/*      */ 
/*      */       
/*  318 */       if (_tokenSet_4.member(LA(1))) {
/*  319 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  326 */       if (LA(1) == '=') {
/*  327 */         mVAR_ASSIGN(false);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  335 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  338 */     if (paramBoolean && token1 == null && b != -1) {
/*  339 */       token1 = makeToken(b);
/*  340 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  342 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  346 */     Token token1 = null; int i = this.text.length();
/*  347 */     byte b = 7;
/*      */     
/*  349 */     Token token2 = null;
/*  350 */     Token token3 = null;
/*  351 */     Token token4 = null;
/*  352 */     Token token5 = null;
/*  353 */     Token token6 = null;
/*  354 */     Token token7 = null;
/*      */     
/*  356 */     if (LA(1) == '$' && LA(2) == 's' && LA(3) == 'e') {
/*  357 */       match("$set");
/*      */       
/*  359 */       if (LA(1) == 'T' && LA(2) == 'e') {
/*  360 */         match("Text");
/*      */         
/*  362 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  365 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  374 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  378 */         match('(');
/*  379 */         mTEXT_ARG(true);
/*  380 */         token3 = this._returnToken;
/*  381 */         match(')');
/*      */ 
/*      */         
/*  384 */         String str = "self.text.setLength(_begin) ; self.text.append(" + token3.getText() + ")";
/*  385 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  388 */       else if (LA(1) == 'T' && LA(2) == 'o') {
/*  389 */         match("Token");
/*      */         
/*  391 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  394 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  403 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  407 */         match('(');
/*  408 */         mTEXT_ARG(true);
/*  409 */         token4 = this._returnToken;
/*  410 */         match(')');
/*      */         
/*  412 */         String str = "_token = " + token4.getText();
/*  413 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  416 */       else if (LA(1) == 'T' && LA(2) == 'y') {
/*  417 */         match("Type");
/*      */         
/*  419 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  422 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  431 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  435 */         match('(');
/*  436 */         mTEXT_ARG(true);
/*  437 */         token5 = this._returnToken;
/*  438 */         match(')');
/*      */         
/*  440 */         String str = "_ttype = " + token5.getText();
/*  441 */         this.text.setLength(i); this.text.append(str);
/*      */       }
/*      */       else {
/*      */         
/*  445 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  450 */     else if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'O') {
/*  451 */       match("$FOLLOW");
/*      */       
/*  453 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  455 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  458 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  467 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  471 */         match('(');
/*  472 */         mTEXT_ARG(true);
/*  473 */         token6 = this._returnToken;
/*  474 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  481 */       String str1 = this.currentRule.getRuleName();
/*  482 */       if (token6 != null) {
/*  483 */         str1 = token6.getText();
/*      */       }
/*  485 */       String str2 = this.generator.getFOLLOWBitSet(str1, 1);
/*  486 */       if (str2 == null) {
/*  487 */         reportError("$FOLLOW(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  491 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  495 */     else if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'I') {
/*  496 */       match("$FIRST");
/*      */       
/*  498 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  500 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  503 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  512 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  516 */         match('(');
/*  517 */         mTEXT_ARG(true);
/*  518 */         token7 = this._returnToken;
/*  519 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  526 */       String str1 = this.currentRule.getRuleName();
/*  527 */       if (token7 != null) {
/*  528 */         str1 = token7.getText();
/*      */       }
/*  530 */       String str2 = this.generator.getFIRSTBitSet(str1, 1);
/*  531 */       if (str2 == null) {
/*  532 */         reportError("$FIRST(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  536 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  540 */     else if (LA(1) == '$' && LA(2) == 's' && LA(3) == 'k') {
/*  541 */       match("$skip");
/*      */       
/*  543 */       this.text.setLength(i); this.text.append("_ttype = SKIP");
/*      */     
/*      */     }
/*  546 */     else if (LA(1) == '$' && LA(2) == 'a') {
/*  547 */       match("$append");
/*      */       
/*  549 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  552 */           mWS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '(':
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  561 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  565 */       match('(');
/*  566 */       mTEXT_ARG(true);
/*  567 */       token2 = this._returnToken;
/*  568 */       match(')');
/*      */       
/*  570 */       String str = "self.text.append(" + token2.getText() + ")";
/*  571 */       this.text.setLength(i); this.text.append(str);
/*      */     
/*      */     }
/*  574 */     else if (LA(1) == '$' && LA(2) == 'g') {
/*  575 */       match("$getText");
/*      */       
/*  577 */       this.text.setLength(i); this.text.append("self.text.getString(_begin)");
/*      */     
/*      */     }
/*  580 */     else if (LA(1) == '$' && LA(2) == 'n') {
/*      */       
/*  582 */       if (LA(1) == '$' && LA(2) == 'n' && LA(3) == 'l') {
/*  583 */         match("$nl");
/*      */       }
/*  585 */       else if (LA(1) == '$' && LA(2) == 'n' && LA(3) == 'e') {
/*  586 */         match("$newline");
/*      */       } else {
/*      */         
/*  589 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  594 */       this.text.setLength(i); this.text.append("self.newline()");
/*      */     }
/*      */     else {
/*      */       
/*  598 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  601 */     if (paramBoolean && token1 == null && b != -1) {
/*  602 */       token1 = makeToken(b);
/*  603 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  605 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mCOMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  609 */     Token token = null; int i = this.text.length();
/*  610 */     byte b = 19;
/*      */ 
/*      */ 
/*      */     
/*  614 */     if (LA(1) == '/' && LA(2) == '/') {
/*  615 */       mSL_COMMENT(false);
/*      */     }
/*  617 */     else if (LA(1) == '/' && LA(2) == '*') {
/*  618 */       mML_COMMENT(false);
/*      */     } else {
/*      */       
/*  621 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  627 */     if (paramBoolean && token == null && b != -1) {
/*  628 */       token = makeToken(b);
/*  629 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  631 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSTRING(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  635 */     Token token = null; int i = this.text.length();
/*  636 */     byte b = 24;
/*      */ 
/*      */     
/*  639 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/*  643 */       while (LA(1) == '\\') {
/*  644 */         mESC(false);
/*      */       }
/*  646 */       if (_tokenSet_7.member(LA(1))) {
/*  647 */         matchNot('"');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  655 */     match('"');
/*  656 */     if (paramBoolean && token == null && b != -1) {
/*  657 */       token = makeToken(b);
/*  658 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  660 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mCHAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  664 */     Token token = null; int i = this.text.length();
/*  665 */     byte b = 23;
/*      */ 
/*      */     
/*  668 */     match('\'');
/*      */     
/*  670 */     if (LA(1) == '\\') {
/*  671 */       mESC(false);
/*      */     }
/*  673 */     else if (_tokenSet_8.member(LA(1))) {
/*  674 */       matchNot('\'');
/*      */     } else {
/*      */       
/*  677 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  681 */     match('\'');
/*  682 */     if (paramBoolean && token == null && b != -1) {
/*  683 */       token = makeToken(b);
/*  684 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  686 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  690 */     Token token1 = null; int i = this.text.length();
/*  691 */     byte b = 8;
/*      */     
/*  693 */     Token token2 = null;
/*  694 */     Token token3 = null;
/*      */     
/*  696 */     StringBuffer stringBuffer = new StringBuffer();
/*  697 */     boolean bool = false;
/*  698 */     Vector vector = new Vector(10);
/*      */ 
/*      */     
/*  701 */     int j = this.text.length();
/*  702 */     match('(');
/*  703 */     this.text.setLength(j);
/*      */     
/*  705 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  708 */         j = this.text.length();
/*  709 */         mWS(false);
/*  710 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/*  733 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/*  737 */     j = this.text.length();
/*  738 */     mTREE_ELEMENT(true);
/*  739 */     this.text.setLength(j);
/*  740 */     token2 = this._returnToken;
/*  741 */     vector.appendElement(token2.getText());
/*      */     
/*  743 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  746 */         j = this.text.length();
/*  747 */         mWS(false);
/*  748 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ')':
/*      */       case ',':
/*      */         break;
/*      */       
/*      */       default:
/*  757 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  764 */     while (LA(1) == ',') {
/*  765 */       j = this.text.length();
/*  766 */       match(',');
/*  767 */       this.text.setLength(j);
/*      */       
/*  769 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  772 */           j = this.text.length();
/*  773 */           mWS(false);
/*  774 */           this.text.setLength(j); break;
/*      */         case '"': case '#': case '(': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/*  797 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  801 */       j = this.text.length();
/*  802 */       mTREE_ELEMENT(true);
/*  803 */       this.text.setLength(j);
/*  804 */       token3 = this._returnToken;
/*  805 */       vector.appendElement(token3.getText());
/*      */       
/*  807 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  810 */           j = this.text.length();
/*  811 */           mWS(false);
/*  812 */           this.text.setLength(j);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case ')':
/*      */         case ',':
/*      */           continue; }
/*      */ 
/*      */       
/*  821 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  832 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(vector));
/*  833 */     j = this.text.length();
/*  834 */     match(')');
/*  835 */     this.text.setLength(j);
/*  836 */     if (paramBoolean && token1 == null && b != -1) {
/*  837 */       token1 = makeToken(b);
/*  838 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  840 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  844 */     Token token = null; int i = this.text.length();
/*  845 */     byte b = 17;
/*      */ 
/*      */ 
/*      */     
/*  849 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*  858 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/*  869 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/*  874 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  879 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  886 */     while (_tokenSet_9.member(LA(1))) {
/*      */       
/*  888 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*  897 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/*  908 */           matchRange('A', 'Z'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/*  915 */           matchRange('0', '9');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/*  920 */           match('_');
/*      */           continue; }
/*      */ 
/*      */ 
/*      */       
/*  925 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  936 */     if (paramBoolean && token == null && b != -1) {
/*  937 */       token = makeToken(b);
/*  938 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  940 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  944 */     Token token = null; int i = this.text.length();
/*  945 */     byte b1 = 29;
/*      */ 
/*      */ 
/*      */     
/*  949 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  952 */       if (LA(1) == '\r' && LA(2) == '\n') {
/*  953 */         match('\r');
/*  954 */         match('\n');
/*  955 */         newline();
/*      */       }
/*  957 */       else if (LA(1) == ' ') {
/*  958 */         match(' ');
/*      */       }
/*  960 */       else if (LA(1) == '\t') {
/*  961 */         match('\t');
/*      */       }
/*  963 */       else if (LA(1) == '\r') {
/*  964 */         match('\r');
/*  965 */         newline();
/*      */       }
/*  967 */       else if (LA(1) == '\n') {
/*  968 */         match('\n');
/*  969 */         newline();
/*      */       } else {
/*      */         
/*  972 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  975 */       b2++;
/*      */     } 
/*      */     
/*  978 */     if (paramBoolean && token == null && b1 != -1) {
/*  979 */       token = makeToken(b1);
/*  980 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  982 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mVAR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  986 */     Token token = null; int i = this.text.length();
/*  987 */     byte b = 18;
/*      */ 
/*      */     
/*  990 */     match('=');
/*      */ 
/*      */ 
/*      */     
/*  994 */     if (LA(1) != '=' && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/*  995 */       this.transInfo.assignToRoot = true;
/*      */     }
/*      */     
/*  998 */     if (paramBoolean && token == null && b != -1) {
/*  999 */       token = makeToken(b);
/* 1000 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1002 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_CONSTRUCTOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1006 */     Token token1 = null; int i = this.text.length();
/* 1007 */     byte b = 10;
/*      */     
/* 1009 */     Token token2 = null;
/* 1010 */     Token token3 = null;
/* 1011 */     Token token4 = null;
/*      */     
/* 1013 */     int j = this.text.length();
/* 1014 */     match('[');
/* 1015 */     this.text.setLength(j);
/*      */     
/* 1017 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1020 */         j = this.text.length();
/* 1021 */         mWS(false);
/* 1022 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1047 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/* 1051 */     j = this.text.length();
/* 1052 */     mAST_CTOR_ELEMENT(true);
/* 1053 */     this.text.setLength(j);
/* 1054 */     token2 = this._returnToken;
/*      */     
/* 1056 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1059 */         j = this.text.length();
/* 1060 */         mWS(false);
/* 1061 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ',':
/*      */       case ']':
/*      */         break;
/*      */       
/*      */       default:
/* 1070 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1075 */     if (LA(1) == ',' && _tokenSet_10.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1076 */       j = this.text.length();
/* 1077 */       match(',');
/* 1078 */       this.text.setLength(j);
/*      */       
/* 1080 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1083 */           j = this.text.length();
/* 1084 */           mWS(false);
/* 1085 */           this.text.setLength(j); break;
/*      */         case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */         case 'f':
/*      */         case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/* 1110 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/* 1114 */       j = this.text.length();
/* 1115 */       mAST_CTOR_ELEMENT(true);
/* 1116 */       this.text.setLength(j);
/* 1117 */       token3 = this._returnToken;
/*      */       
/* 1119 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1122 */           j = this.text.length();
/* 1123 */           mWS(false);
/* 1124 */           this.text.setLength(j);
/*      */           break;
/*      */ 
/*      */         
/*      */         case ',':
/*      */         case ']':
/*      */           break;
/*      */         
/*      */         default:
/* 1133 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1138 */     } else if (LA(1) != ',' && LA(1) != ']') {
/*      */ 
/*      */       
/* 1141 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1146 */     switch (LA(1)) {
/*      */       
/*      */       case ',':
/* 1149 */         j = this.text.length();
/* 1150 */         match(',');
/* 1151 */         this.text.setLength(j);
/*      */         
/* 1153 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1156 */             j = this.text.length();
/* 1157 */             mWS(false);
/* 1158 */             this.text.setLength(j); break;
/*      */           case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */           case 'f':
/*      */           case 'g':
/*      */           case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*      */             break;
/*      */           default:
/* 1183 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1187 */         j = this.text.length();
/* 1188 */         mAST_CTOR_ELEMENT(true);
/* 1189 */         this.text.setLength(j);
/* 1190 */         token4 = this._returnToken;
/*      */         
/* 1192 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1195 */             j = this.text.length();
/* 1196 */             mWS(false);
/* 1197 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ']':
/*      */             break; }
/*      */ 
/*      */ 
/*      */         
/* 1206 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case ']':
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1218 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1222 */     j = this.text.length();
/* 1223 */     match(']');
/* 1224 */     this.text.setLength(j);
/*      */     
/* 1226 */     String str = token2.getText();
/* 1227 */     if (token3 != null) {
/* 1228 */       str = str + "," + token3.getText();
/*      */     }
/* 1230 */     if (token4 != null) {
/* 1231 */       str = str + "," + token4.getText();
/*      */     }
/* 1233 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(null, str));
/*      */     
/* 1235 */     if (paramBoolean && token1 == null && b != -1) {
/* 1236 */       token1 = makeToken(b);
/* 1237 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1239 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1243 */     Token token = null; int i = this.text.length();
/* 1244 */     byte b1 = 13;
/*      */ 
/*      */ 
/*      */     
/* 1248 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1251 */         mWS(false); break;
/*      */       case '"': case '$': case '\'': case '+': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1276 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1281 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1284 */       if (_tokenSet_11.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1285 */         mTEXT_ARG_ELEMENT(false);
/*      */         
/* 1287 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_12.member(LA(2))) {
/* 1288 */           mWS(false);
/*      */         }
/* 1290 */         else if (!_tokenSet_12.member(LA(1))) {
/*      */ 
/*      */           
/* 1293 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1299 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1302 */       b2++;
/*      */     } 
/*      */     
/* 1305 */     if (paramBoolean && token == null && b1 != -1) {
/* 1306 */       token = makeToken(b1);
/* 1307 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1309 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1313 */     Token token1 = null; int i = this.text.length();
/* 1314 */     byte b = 9;
/*      */     
/* 1316 */     Token token2 = null;
/*      */ 
/*      */     
/* 1319 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1322 */         mTREE(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '[':
/* 1327 */         mAST_CONSTRUCTOR(false); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1345 */         mID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1350 */         mSTRING(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1354 */         if (LA(1) == '#' && LA(2) == '(') {
/* 1355 */           int j = this.text.length();
/* 1356 */           match('#');
/* 1357 */           this.text.setLength(j);
/* 1358 */           mTREE(false); break;
/*      */         } 
/* 1360 */         if (LA(1) == '#' && LA(2) == '[') {
/* 1361 */           int j = this.text.length();
/* 1362 */           match('#');
/* 1363 */           this.text.setLength(j);
/* 1364 */           mAST_CONSTRUCTOR(false); break;
/*      */         } 
/* 1366 */         if (LA(1) == '#' && _tokenSet_3.member(LA(2))) {
/* 1367 */           int j = this.text.length();
/* 1368 */           match('#');
/* 1369 */           this.text.setLength(j);
/* 1370 */           boolean bool = mID_ELEMENT(true);
/* 1371 */           token2 = this._returnToken;
/*      */           
/* 1373 */           if (!bool) {
/*      */             
/* 1375 */             String str = this.generator.mapTreeId(token2.getText(), null);
/* 1376 */             this.text.setLength(i); this.text.append(str);
/*      */           } 
/*      */           break;
/*      */         } 
/* 1380 */         if (LA(1) == '#' && LA(2) == '#') {
/* 1381 */           match("##");
/* 1382 */           String str = this.currentRule.getRuleName() + "_AST"; this.text.setLength(i); this.text.append(str);
/*      */           break;
/*      */         } 
/* 1385 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1388 */     if (paramBoolean && token1 == null && b != -1) {
/* 1389 */       token1 = makeToken(b);
/* 1390 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1392 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final boolean mID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/*      */     String str;
/* 1399 */     boolean bool = false;
/* 1400 */     Token token1 = null; int i = this.text.length();
/* 1401 */     byte b1 = 12;
/*      */     
/* 1403 */     Token token2 = null;
/*      */     
/* 1405 */     mID(true);
/* 1406 */     token2 = this._returnToken;
/*      */     
/* 1408 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_13.member(LA(2))) {
/* 1409 */       int k = this.text.length();
/* 1410 */       mWS(false);
/* 1411 */       this.text.setLength(k);
/*      */     }
/* 1413 */     else if (!_tokenSet_13.member(LA(1))) {
/*      */ 
/*      */       
/* 1416 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1421 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1424 */         match('(');
/*      */         
/* 1426 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_14.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1427 */           int k = this.text.length();
/* 1428 */           mWS(false);
/* 1429 */           this.text.setLength(k);
/*      */         }
/* 1431 */         else if (!_tokenSet_14.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 1434 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1439 */         switch (LA(1)) { case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/* 1458 */             mARG(false);
/*      */ 
/*      */ 
/*      */             
/* 1462 */             while (LA(1) == ',') {
/* 1463 */               int k; match(',');
/*      */               
/* 1465 */               switch (LA(1)) { case '\t': case '\n':
/*      */                 case '\r':
/*      */                 case ' ':
/* 1468 */                   k = this.text.length();
/* 1469 */                   mWS(false);
/* 1470 */                   this.text.setLength(k); break;
/*      */                 case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */                 case 'f':
/*      */                 case 'g':
/*      */                 case 'h':
/*      */                 case 'i':
/*      */                 case 'j':
/*      */                 case 'k':
/*      */                 case 'l':
/*      */                 case 'm':
/*      */                 case 'n':
/*      */                 case 'o':
/*      */                 case 'p':
/*      */                 case 'q':
/*      */                 case 'r':
/*      */                 case 's':
/*      */                 case 't':
/*      */                 case 'u':
/*      */                 case 'v':
/*      */                 case 'w':
/*      */                 case 'x':
/*      */                 case 'y':
/*      */                 case 'z':
/*      */                   break;
/*      */                 default:
/* 1495 */                   throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */               
/* 1499 */               mARG(false);
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 1516 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1521 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1524 */             j = this.text.length();
/* 1525 */             mWS(false);
/* 1526 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1535 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1539 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 1545 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 1548 */           if (LA(1) == '[') {
/* 1549 */             match('[');
/*      */             
/* 1551 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1554 */                 j = this.text.length();
/* 1555 */                 mWS(false);
/* 1556 */                 this.text.setLength(j); break;
/*      */               case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */               case 'f':
/*      */               case 'g':
/*      */               case 'h':
/*      */               case 'i':
/*      */               case 'j':
/*      */               case 'k':
/*      */               case 'l':
/*      */               case 'm':
/*      */               case 'n':
/*      */               case 'o':
/*      */               case 'p':
/*      */               case 'q':
/*      */               case 'r':
/*      */               case 's':
/*      */               case 't':
/*      */               case 'u':
/*      */               case 'v':
/*      */               case 'w':
/*      */               case 'x':
/*      */               case 'y':
/*      */               case 'z':
/*      */                 break;
/*      */               default:
/* 1581 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1585 */             mARG(false);
/*      */             
/* 1587 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1590 */                 j = this.text.length();
/* 1591 */                 mWS(false);
/* 1592 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1601 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1605 */             match(']');
/*      */           } else {
/*      */             
/* 1608 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 1611 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 1618 */         match('.');
/* 1619 */         mID_ELEMENT(false); break;
/*      */       case '\t': case '\n': case '\r': case ' ': case ')': case '*':
/*      */       case '+':
/*      */       case ',':
/*      */       case '-':
/*      */       case '/':
/*      */       case '=':
/*      */       case ']':
/* 1627 */         bool = true;
/* 1628 */         str = this.generator.mapTreeId(token2.getText(), this.transInfo);
/* 1629 */         this.text.setLength(i); this.text.append(str);
/*      */ 
/*      */         
/* 1632 */         if (_tokenSet_15.member(LA(1)) && _tokenSet_16.member(LA(2)) && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/*      */           
/* 1634 */           switch (LA(1)) { case '\t': case '\n':
/*      */             case '\r':
/*      */             case ' ':
/* 1637 */               mWS(false);
/*      */               break;
/*      */ 
/*      */             
/*      */             case '=':
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1646 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */           
/* 1650 */           mVAR_ASSIGN(false); break;
/*      */         } 
/* 1652 */         if (_tokenSet_17.member(LA(1))) {
/*      */           break;
/*      */         }
/* 1655 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1663 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1667 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 1668 */       token1 = makeToken(b1);
/* 1669 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1671 */     this._returnToken = token1;
/* 1672 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void mAST_CTOR_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1679 */     Token token = null; int i = this.text.length();
/* 1680 */     byte b = 11;
/*      */ 
/*      */     
/* 1683 */     if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1684 */       mSTRING(false);
/*      */     }
/* 1686 */     else if (_tokenSet_18.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1687 */       mTREE_ELEMENT(false);
/*      */     }
/* 1689 */     else if (LA(1) >= '0' && LA(1) <= '9') {
/* 1690 */       mINT(false);
/*      */     } else {
/*      */       
/* 1693 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1696 */     if (paramBoolean && token == null && b != -1) {
/* 1697 */       token = makeToken(b);
/* 1698 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1700 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mINT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1704 */     Token token = null; int i = this.text.length();
/* 1705 */     byte b1 = 27;
/*      */ 
/*      */ 
/*      */     
/* 1709 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1712 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1713 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 1716 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1719 */       b2++;
/*      */     } 
/*      */     
/* 1722 */     if (paramBoolean && token == null && b1 != -1) {
/* 1723 */       token = makeToken(b1);
/* 1724 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1726 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1730 */     Token token = null; int i = this.text.length();
/* 1731 */     byte b = 16;
/*      */ 
/*      */ 
/*      */     
/* 1735 */     switch (LA(1)) {
/*      */       
/*      */       case '\'':
/* 1738 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1745 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1749 */         if (_tokenSet_18.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1750 */           mTREE_ELEMENT(false); break;
/*      */         } 
/* 1752 */         if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1753 */           mSTRING(false);
/*      */           break;
/*      */         } 
/* 1756 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1763 */     while (_tokenSet_19.member(LA(1)) && _tokenSet_20.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */       
/* 1765 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1768 */           mWS(false);
/*      */           break;
/*      */         
/*      */         case '*':
/*      */         case '+':
/*      */         case '-':
/*      */         case '/':
/*      */           break;
/*      */         default:
/* 1777 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1782 */       switch (LA(1)) {
/*      */         
/*      */         case '+':
/* 1785 */           match('+');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '-':
/* 1790 */           match('-');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '*':
/* 1795 */           match('*');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '/':
/* 1800 */           match('/');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1805 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1810 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1813 */           mWS(false); break;
/*      */         case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */         case 'f':
/*      */         case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/* 1838 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/* 1842 */       mARG(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1850 */     if (paramBoolean && token == null && b != -1) {
/* 1851 */       token = makeToken(b);
/* 1852 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1854 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1858 */     Token token = null; int i = this.text.length();
/* 1859 */     byte b = 14;
/*      */ 
/*      */     
/* 1862 */     switch (LA(1)) { case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1878 */         mTEXT_ARG_ID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1883 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 1888 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1895 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '$':
/* 1900 */         mTEXT_ITEM(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '+':
/* 1905 */         match('+');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1910 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */     
/* 1913 */     if (paramBoolean && token == null && b != -1) {
/* 1914 */       token = makeToken(b);
/* 1915 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1917 */     this._returnToken = token;
/*      */   } protected final void mTEXT_ARG_ID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/* 1921 */     Token token1 = null; int i = this.text.length();
/* 1922 */     byte b1 = 15;
/*      */     
/* 1924 */     Token token2 = null;
/*      */     
/* 1926 */     mID(true);
/* 1927 */     token2 = this._returnToken;
/*      */     
/* 1929 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_21.member(LA(2))) {
/* 1930 */       int k = this.text.length();
/* 1931 */       mWS(false);
/* 1932 */       this.text.setLength(k);
/*      */     }
/* 1934 */     else if (!_tokenSet_21.member(LA(1))) {
/*      */ 
/*      */       
/* 1937 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1942 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1945 */         match('(');
/*      */         
/* 1947 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_22.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1948 */           int k = this.text.length();
/* 1949 */           mWS(false);
/* 1950 */           this.text.setLength(k);
/*      */         }
/* 1952 */         else if (!_tokenSet_22.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 1955 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1962 */         while (_tokenSet_23.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1963 */           mTEXT_ARG(false);
/*      */ 
/*      */ 
/*      */           
/* 1967 */           while (LA(1) == ',') {
/* 1968 */             match(',');
/* 1969 */             mTEXT_ARG(false);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1985 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1988 */             j = this.text.length();
/* 1989 */             mWS(false);
/* 1990 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1999 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 2003 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 2009 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 2012 */           if (LA(1) == '[') {
/* 2013 */             match('[');
/*      */             
/* 2015 */             if (_tokenSet_4.member(LA(1)) && _tokenSet_23.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2016 */               j = this.text.length();
/* 2017 */               mWS(false);
/* 2018 */               this.text.setLength(j);
/*      */             }
/* 2020 */             else if (!_tokenSet_23.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ' || LA(3) < '\003' || LA(3) > 'ÿ') {
/*      */ 
/*      */               
/* 2023 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */ 
/*      */             
/* 2027 */             mTEXT_ARG(false);
/*      */             
/* 2029 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 2032 */                 j = this.text.length();
/* 2033 */                 mWS(false);
/* 2034 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2043 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 2047 */             match(']');
/*      */           } else {
/*      */             
/* 2050 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 2053 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 2060 */         match('.');
/* 2061 */         mTEXT_ARG_ID_ELEMENT(false); break;
/*      */       case '\t': case '\n': case '\r': case ' ': case '"': case '$': case '\'': case ')': case '+': case ',': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case ']': case '_': case 'a': case 'b': case 'c':
/*      */       case 'd':
/*      */       case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 2088 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2092 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 2093 */       token1 = makeToken(b1);
/* 2094 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2096 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mINT_OR_FLOAT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2100 */     Token token = null; int i = this.text.length();
/* 2101 */     byte b1 = 28;
/*      */ 
/*      */ 
/*      */     
/* 2105 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 2108 */       if (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_24.member(LA(2))) {
/* 2109 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 2112 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2115 */       b2++;
/*      */     } 
/*      */ 
/*      */     
/* 2119 */     if (LA(1) == 'L' && _tokenSet_25.member(LA(2))) {
/* 2120 */       match('L');
/*      */     }
/* 2122 */     else if (LA(1) == 'l' && _tokenSet_25.member(LA(2))) {
/* 2123 */       match('l');
/*      */     }
/* 2125 */     else if (LA(1) == '.') {
/* 2126 */       match('.');
/*      */ 
/*      */ 
/*      */       
/* 2130 */       while (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_25.member(LA(2))) {
/* 2131 */         mDIGIT(false);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2140 */     else if (!_tokenSet_25.member(LA(1))) {
/*      */ 
/*      */       
/* 2143 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2147 */     if (paramBoolean && token == null && b1 != -1) {
/* 2148 */       token = makeToken(b1);
/* 2149 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2151 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2155 */     Token token = null; int i = this.text.length();
/* 2156 */     byte b = 20;
/*      */ 
/*      */     
/* 2159 */     match("//");
/*      */ 
/*      */     
/* 2162 */     this.text.setLength(i); this.text.append("#");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2168 */     while (LA(1) != '\n' && LA(1) != '\r' && 
/* 2169 */       LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2170 */       matchNot('￿');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2182 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 2183 */       match("\r\n");
/*      */     }
/* 2185 */     else if (LA(1) == '\n') {
/* 2186 */       match('\n');
/*      */     }
/* 2188 */     else if (LA(1) == '\r') {
/* 2189 */       match('\r');
/*      */     } else {
/*      */       
/* 2192 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2197 */     newline();
/*      */     
/* 2199 */     if (paramBoolean && token == null && b != -1) {
/* 2200 */       token = makeToken(b);
/* 2201 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2203 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2207 */     Token token = null; int i = this.text.length();
/* 2208 */     byte b = 22;
/*      */ 
/*      */     
/* 2211 */     match("/*");
/*      */ 
/*      */     
/* 2214 */     this.text.setLength(i); this.text.append("#");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2220 */     while (LA(1) != '*' || LA(2) != '/') {
/* 2221 */       if (LA(1) == '\r' && LA(2) == '\n' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2222 */         match('\r');
/* 2223 */         match('\n');
/* 2224 */         int k = this.text.length();
/* 2225 */         mIGNWS(false);
/* 2226 */         this.text.setLength(k);
/*      */         
/* 2228 */         newline();
/* 2229 */         this.text.append("# ");
/*      */         continue;
/*      */       } 
/* 2232 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2233 */         match('\r');
/* 2234 */         int k = this.text.length();
/* 2235 */         mIGNWS(false);
/* 2236 */         this.text.setLength(k);
/*      */         
/* 2238 */         newline();
/* 2239 */         this.text.append("# ");
/*      */         continue;
/*      */       } 
/* 2242 */       if (LA(1) == '\n' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2243 */         match('\n');
/* 2244 */         int k = this.text.length();
/* 2245 */         mIGNWS(false);
/* 2246 */         this.text.setLength(k);
/*      */         
/* 2248 */         newline();
/* 2249 */         this.text.append("# ");
/*      */         continue;
/*      */       } 
/* 2252 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2253 */         matchNot('￿');
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/*      */ 
/*      */     
/* 2264 */     this.text.append("\n");
/*      */     
/* 2266 */     int j = this.text.length();
/* 2267 */     match("*/");
/* 2268 */     this.text.setLength(j);
/* 2269 */     if (paramBoolean && token == null && b != -1) {
/* 2270 */       token = makeToken(b);
/* 2271 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2273 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIGNWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2277 */     Token token = null; int i = this.text.length();
/* 2278 */     byte b = 21;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2284 */       if (LA(1) == ' ' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2285 */         match(' '); continue;
/*      */       } 
/* 2287 */       if (LA(1) == '\t' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2288 */         match('\t');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 2296 */     if (paramBoolean && token == null && b != -1) {
/* 2297 */       token = makeToken(b);
/* 2298 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2300 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2304 */     Token token = null; int i = this.text.length();
/* 2305 */     byte b = 25;
/*      */ 
/*      */     
/* 2308 */     match('\\');
/*      */     
/* 2310 */     switch (LA(1)) {
/*      */       
/*      */       case 'n':
/* 2313 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/* 2318 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/* 2323 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/* 2328 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/* 2333 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 2338 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 2343 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/* 2348 */         match('\\');
/*      */         break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/* 2354 */         matchRange('0', '3');
/*      */ 
/*      */         
/* 2357 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2358 */           mDIGIT(false);
/*      */           
/* 2360 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2361 */             mDIGIT(false); break;
/*      */           } 
/* 2363 */           if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */             break;
/*      */           }
/* 2366 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2371 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2374 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/* 2383 */         matchRange('4', '7');
/*      */ 
/*      */         
/* 2386 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2387 */           mDIGIT(false); break;
/*      */         } 
/* 2389 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2392 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2400 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2404 */     if (paramBoolean && token == null && b != -1) {
/* 2405 */       token = makeToken(b);
/* 2406 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2408 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2412 */     Token token = null; int i = this.text.length();
/* 2413 */     byte b = 26;
/*      */ 
/*      */     
/* 2416 */     matchRange('0', '9');
/* 2417 */     if (paramBoolean && token == null && b != -1) {
/* 2418 */       token = makeToken(b);
/* 2419 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2421 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 2426 */     long[] arrayOfLong = new long[8];
/* 2427 */     arrayOfLong[0] = -103079215112L;
/* 2428 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2429 */      return arrayOfLong;
/*      */   }
/* 2431 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 2433 */     long[] arrayOfLong = new long[8];
/* 2434 */     arrayOfLong[0] = -145135534866440L;
/* 2435 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2436 */      return arrayOfLong;
/*      */   }
/* 2438 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 2440 */     long[] arrayOfLong = new long[8];
/* 2441 */     arrayOfLong[0] = -141407503262728L;
/* 2442 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2443 */      return arrayOfLong;
/*      */   }
/* 2445 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 2447 */     return new long[] { 0L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2450 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 2452 */     return new long[] { 4294977024L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2455 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 2457 */     return new long[] { 1103806604800L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2460 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 2462 */     return new long[] { 287959436729787904L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2465 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 2467 */     long[] arrayOfLong = new long[8];
/* 2468 */     arrayOfLong[0] = -17179869192L;
/* 2469 */     arrayOfLong[1] = -268435457L;
/* 2470 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2471 */      return arrayOfLong;
/*      */   }
/* 2473 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 2475 */     long[] arrayOfLong = new long[8];
/* 2476 */     arrayOfLong[0] = -549755813896L;
/* 2477 */     arrayOfLong[1] = -268435457L;
/* 2478 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2479 */      return arrayOfLong;
/*      */   }
/* 2481 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 2483 */     return new long[] { 287948901175001088L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2486 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 2488 */     return new long[] { 287950056521213440L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2491 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 2493 */     return new long[] { 287958332923183104L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2496 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 2498 */     return new long[] { 287978128427460096L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2501 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 2503 */     return new long[] { 2306123388973753856L, 671088640L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2506 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 2508 */     return new long[] { 287952805300282880L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2511 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 2513 */     return new long[] { 2305843013508670976L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2516 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 2518 */     return new long[] { 2306051920717948416L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2521 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 2523 */     return new long[] { 208911504254464L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2526 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 2528 */     return new long[] { 1151051235328L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2531 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 2533 */     return new long[] { 189120294954496L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2536 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 2538 */     return new long[] { 288139722277004800L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2541 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 2543 */     return new long[] { 288049596683265536L, 576460746666278910L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2546 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 2548 */     return new long[] { 287960536241415680L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2551 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   private static final long[] mk_tokenSet_23() {
/* 2553 */     return new long[] { 287958337218160128L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2556 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   private static final long[] mk_tokenSet_24() {
/* 2558 */     return new long[] { 288228817078593024L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2561 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   private static final long[] mk_tokenSet_25() {
/* 2563 */     return new long[] { 288158448334415360L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2566 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\actions\python\ActionLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
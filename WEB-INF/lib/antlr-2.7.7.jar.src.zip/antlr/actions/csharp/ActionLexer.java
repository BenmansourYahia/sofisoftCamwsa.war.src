/*      */ package antlr.actions.csharp;
/*      */ 
/*      */ import antlr.ActionTransInfo;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.CodeGenerator;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.RuleBlock;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.Tool;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ActionLexer
/*      */   extends CharScanner
/*      */   implements ActionLexerTokenTypes, TokenStream
/*      */ {
/*      */   protected RuleBlock currentRule;
/*      */   protected CodeGenerator generator;
/*   59 */   protected int lineOffset = 0;
/*      */   
/*      */   private Tool antlrTool;
/*      */   
/*      */   ActionTransInfo transInfo;
/*      */ 
/*      */   
/*      */   public ActionLexer(String paramString, RuleBlock paramRuleBlock, CodeGenerator paramCodeGenerator, ActionTransInfo paramActionTransInfo) {
/*   67 */     this(new StringReader(paramString));
/*   68 */     this.currentRule = paramRuleBlock;
/*   69 */     this.generator = paramCodeGenerator;
/*   70 */     this.transInfo = paramActionTransInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLineOffset(int paramInt) {
/*   75 */     setLine(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTool(Tool paramTool) {
/*   80 */     this.antlrTool = paramTool;
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportError(RecognitionException paramRecognitionException) {
/*   85 */     this.antlrTool.error("Syntax error in action: " + paramRecognitionException, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportError(String paramString) {
/*   90 */     this.antlrTool.error(paramString, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportWarning(String paramString) {
/*   95 */     if (getFilename() == null) {
/*   96 */       this.antlrTool.warning(paramString);
/*      */     } else {
/*   98 */       this.antlrTool.warning(paramString, getFilename(), getLine(), getColumn());
/*      */     } 
/*      */   } public ActionLexer(InputStream paramInputStream) {
/*  101 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public ActionLexer(Reader paramReader) {
/*  104 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public ActionLexer(InputBuffer paramInputBuffer) {
/*  107 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public ActionLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  110 */     super(paramLexerSharedInputState);
/*  111 */     this.caseSensitiveLiterals = true;
/*  112 */     setCaseSensitive(true);
/*  113 */     this.literals = new Hashtable();
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  117 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  120 */       Object object = null;
/*  121 */       int i = 0;
/*  122 */       resetText();
/*      */       
/*      */       try {
/*  125 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ')
/*  126 */         { mACTION(true);
/*  127 */           token = this._returnToken;
/*      */            }
/*      */         
/*  130 */         else if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); }
/*  131 */         else { throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */         
/*  134 */         if (this._returnToken == null)
/*  135 */           continue;  i = this._returnToken.getType();
/*  136 */         this._returnToken.setType(i);
/*  137 */         return this._returnToken;
/*      */       }
/*  139 */       catch (RecognitionException recognitionException) {
/*  140 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  143 */       catch (CharStreamException charStreamException) {
/*  144 */         if (charStreamException instanceof CharStreamIOException) {
/*  145 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  148 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void mACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  155 */     Token token = null; int i = this.text.length();
/*  156 */     byte b1 = 4;
/*      */ 
/*      */ 
/*      */     
/*  160 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  163 */       switch (LA(1)) {
/*      */         
/*      */         case '#':
/*  166 */           mAST_ITEM(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '$':
/*  171 */           mTEXT_ITEM(false);
/*      */           break;
/*      */         
/*      */         default:
/*  175 */           if (_tokenSet_0.member(LA(1))) {
/*  176 */             mSTUFF(false);
/*      */             break;
/*      */           } 
/*  179 */           if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  182 */       b2++;
/*      */     } 
/*      */     
/*  185 */     if (paramBoolean && token == null && b1 != -1) {
/*  186 */       token = makeToken(b1);
/*  187 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  189 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void mSTUFF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  196 */     Token token = null; int i = this.text.length();
/*  197 */     byte b = 5;
/*      */ 
/*      */     
/*  200 */     switch (LA(1)) {
/*      */       
/*      */       case '"':
/*  203 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/*  208 */         mCHAR(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\n':
/*  213 */         match('\n');
/*  214 */         newline();
/*      */         break;
/*      */       
/*      */       default:
/*  218 */         if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/*  219 */           mCOMMENT(false); break;
/*      */         } 
/*  221 */         if (LA(1) == '\r' && LA(2) == '\n') {
/*  222 */           match("\r\n");
/*  223 */           newline(); break;
/*      */         } 
/*  225 */         if (LA(1) == '\\' && LA(2) == '#') {
/*  226 */           match('\\');
/*  227 */           match('#');
/*  228 */           this.text.setLength(i); this.text.append("#"); break;
/*      */         } 
/*  230 */         if (LA(1) == '/' && _tokenSet_1.member(LA(2))) {
/*  231 */           match('/');
/*      */           
/*  233 */           match(_tokenSet_1);
/*      */           break;
/*      */         } 
/*  236 */         if (LA(1) == '\r') {
/*  237 */           match('\r');
/*  238 */           newline(); break;
/*      */         } 
/*  240 */         if (_tokenSet_2.member(LA(1))) {
/*      */           
/*  242 */           match(_tokenSet_2);
/*      */           
/*      */           break;
/*      */         } 
/*  246 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  249 */     if (paramBoolean && token == null && b != -1) {
/*  250 */       token = makeToken(b);
/*  251 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  253 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  257 */     Token token1 = null; int i = this.text.length();
/*  258 */     byte b = 6;
/*      */     
/*  260 */     Token token2 = null;
/*  261 */     Token token3 = null;
/*  262 */     Token token4 = null;
/*      */     
/*  264 */     if (LA(1) == '#' && LA(2) == '(') {
/*  265 */       int j = this.text.length();
/*  266 */       match('#');
/*  267 */       this.text.setLength(j);
/*  268 */       mTREE(true);
/*  269 */       token2 = this._returnToken;
/*      */     }
/*  271 */     else if (LA(1) == '#' && _tokenSet_3.member(LA(2))) {
/*  272 */       int j = this.text.length();
/*  273 */       match('#');
/*  274 */       this.text.setLength(j);
/*      */       
/*  276 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  279 */           mWS(false); break;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/*  301 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  305 */       mID(true);
/*  306 */       token3 = this._returnToken;
/*      */       
/*  308 */       String str1 = token3.getText();
/*  309 */       String str2 = this.generator.mapTreeId(token3.getText(), this.transInfo);
/*      */ 
/*      */       
/*  312 */       if (str2 != null && !str1.equals(str2)) {
/*      */         
/*  314 */         this.text.setLength(i); this.text.append(str2);
/*      */ 
/*      */       
/*      */       }
/*  318 */       else if (str1.equals("define") || str1.equals("undef") || str1.equals("if") || str1.equals("elif") || str1.equals("else") || str1.equals("endif") || str1.equals("line") || str1.equals("error") || str1.equals("warning") || str1.equals("region") || str1.equals("endregion")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  330 */         this.text.setLength(i); this.text.append("#" + str1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  335 */       if (_tokenSet_4.member(LA(1))) {
/*  336 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  343 */       if (LA(1) == '=') {
/*  344 */         mVAR_ASSIGN(false);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  351 */     else if (LA(1) == '#' && LA(2) == '[') {
/*  352 */       int j = this.text.length();
/*  353 */       match('#');
/*  354 */       this.text.setLength(j);
/*  355 */       mAST_CONSTRUCTOR(true);
/*  356 */       token4 = this._returnToken;
/*      */     }
/*  358 */     else if (LA(1) == '#' && LA(2) == '#') {
/*  359 */       match("##");
/*      */       
/*  361 */       if (this.currentRule != null) {
/*      */         
/*  363 */         String str = this.currentRule.getRuleName() + "_AST";
/*  364 */         this.text.setLength(i); this.text.append(str);
/*      */         
/*  366 */         if (this.transInfo != null) {
/*  367 */           this.transInfo.refRuleRoot = str;
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  372 */         reportWarning("\"##\" not valid in this context");
/*  373 */         this.text.setLength(i); this.text.append("##");
/*      */       } 
/*      */ 
/*      */       
/*  377 */       if (_tokenSet_4.member(LA(1))) {
/*  378 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  385 */       if (LA(1) == '=') {
/*  386 */         mVAR_ASSIGN(false);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  394 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  397 */     if (paramBoolean && token1 == null && b != -1) {
/*  398 */       token1 = makeToken(b);
/*  399 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  401 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  405 */     Token token1 = null; int i = this.text.length();
/*  406 */     byte b = 7;
/*      */     
/*  408 */     Token token2 = null;
/*  409 */     Token token3 = null;
/*  410 */     Token token4 = null;
/*  411 */     Token token5 = null;
/*  412 */     Token token6 = null;
/*  413 */     Token token7 = null;
/*      */     
/*  415 */     if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'O') {
/*  416 */       match("$FOLLOW");
/*      */       
/*  418 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  420 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  423 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  432 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  436 */         match('(');
/*  437 */         mTEXT_ARG(true);
/*  438 */         token6 = this._returnToken;
/*  439 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  446 */       String str1 = this.currentRule.getRuleName();
/*  447 */       if (token6 != null) {
/*  448 */         str1 = token6.getText();
/*      */       }
/*  450 */       String str2 = this.generator.getFOLLOWBitSet(str1, 1);
/*      */       
/*  452 */       if (str2 == null) {
/*  453 */         reportError("$FOLLOW(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  457 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  461 */     else if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'I') {
/*  462 */       match("$FIRST");
/*      */       
/*  464 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  466 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  469 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  478 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  482 */         match('(');
/*  483 */         mTEXT_ARG(true);
/*  484 */         token7 = this._returnToken;
/*  485 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  492 */       String str1 = this.currentRule.getRuleName();
/*  493 */       if (token7 != null) {
/*  494 */         str1 = token7.getText();
/*      */       }
/*  496 */       String str2 = this.generator.getFIRSTBitSet(str1, 1);
/*      */       
/*  498 */       if (str2 == null) {
/*  499 */         reportError("$FIRST(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  503 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  507 */     else if (LA(1) == '$' && LA(2) == 'a') {
/*  508 */       match("$append");
/*      */       
/*  510 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  513 */           mWS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '(':
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  522 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  526 */       match('(');
/*  527 */       mTEXT_ARG(true);
/*  528 */       token2 = this._returnToken;
/*  529 */       match(')');
/*      */       
/*  531 */       String str = "text.Append(" + token2.getText() + ")";
/*  532 */       this.text.setLength(i); this.text.append(str);
/*      */     
/*      */     }
/*  535 */     else if (LA(1) == '$' && LA(2) == 's') {
/*  536 */       match("$set");
/*      */       
/*  538 */       if (LA(1) == 'T' && LA(2) == 'e') {
/*  539 */         match("Text");
/*      */         
/*  541 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  544 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  553 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  557 */         match('(');
/*  558 */         mTEXT_ARG(true);
/*  559 */         token3 = this._returnToken;
/*  560 */         match(')');
/*      */ 
/*      */         
/*  563 */         String str = "text.Length = _begin; text.Append(" + token3.getText() + ")";
/*  564 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  567 */       else if (LA(1) == 'T' && LA(2) == 'o') {
/*  568 */         match("Token");
/*      */         
/*  570 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  573 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  582 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  586 */         match('(');
/*  587 */         mTEXT_ARG(true);
/*  588 */         token4 = this._returnToken;
/*  589 */         match(')');
/*      */         
/*  591 */         String str = "_token = " + token4.getText();
/*  592 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  595 */       else if (LA(1) == 'T' && LA(2) == 'y') {
/*  596 */         match("Type");
/*      */         
/*  598 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  601 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  610 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  614 */         match('(');
/*  615 */         mTEXT_ARG(true);
/*  616 */         token5 = this._returnToken;
/*  617 */         match(')');
/*      */         
/*  619 */         String str = "_ttype = " + token5.getText();
/*  620 */         this.text.setLength(i); this.text.append(str);
/*      */       }
/*      */       else {
/*      */         
/*  624 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  629 */     else if (LA(1) == '$' && LA(2) == 'g') {
/*  630 */       match("$getText");
/*      */       
/*  632 */       this.text.setLength(i); this.text.append("text.ToString(_begin, text.Length-_begin)");
/*      */     }
/*      */     else {
/*      */       
/*  636 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  639 */     if (paramBoolean && token1 == null && b != -1) {
/*  640 */       token1 = makeToken(b);
/*  641 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  643 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mCOMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  647 */     Token token = null; int i = this.text.length();
/*  648 */     byte b = 19;
/*      */ 
/*      */     
/*  651 */     if (LA(1) == '/' && LA(2) == '/') {
/*  652 */       mSL_COMMENT(false);
/*      */     }
/*  654 */     else if (LA(1) == '/' && LA(2) == '*') {
/*  655 */       mML_COMMENT(false);
/*      */     } else {
/*      */       
/*  658 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  661 */     if (paramBoolean && token == null && b != -1) {
/*  662 */       token = makeToken(b);
/*  663 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  665 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSTRING(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  669 */     Token token = null; int i = this.text.length();
/*  670 */     byte b = 23;
/*      */ 
/*      */     
/*  673 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/*  677 */       while (LA(1) == '\\') {
/*  678 */         mESC(false);
/*      */       }
/*  680 */       if (_tokenSet_7.member(LA(1))) {
/*  681 */         matchNot('"');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  689 */     match('"');
/*  690 */     if (paramBoolean && token == null && b != -1) {
/*  691 */       token = makeToken(b);
/*  692 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  694 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mCHAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  698 */     Token token = null; int i = this.text.length();
/*  699 */     byte b = 22;
/*      */ 
/*      */     
/*  702 */     match('\'');
/*      */     
/*  704 */     if (LA(1) == '\\') {
/*  705 */       mESC(false);
/*      */     }
/*  707 */     else if (_tokenSet_8.member(LA(1))) {
/*  708 */       matchNot('\'');
/*      */     } else {
/*      */       
/*  711 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  715 */     match('\'');
/*  716 */     if (paramBoolean && token == null && b != -1) {
/*  717 */       token = makeToken(b);
/*  718 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  720 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  724 */     Token token1 = null; int i = this.text.length();
/*  725 */     byte b = 8;
/*      */     
/*  727 */     Token token2 = null;
/*  728 */     Token token3 = null;
/*      */     
/*  730 */     StringBuffer stringBuffer = new StringBuffer();
/*  731 */     boolean bool = false;
/*  732 */     Vector vector = new Vector(10);
/*      */ 
/*      */     
/*  735 */     int j = this.text.length();
/*  736 */     match('(');
/*  737 */     this.text.setLength(j);
/*      */     
/*  739 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  742 */         j = this.text.length();
/*  743 */         mWS(false);
/*  744 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/*  767 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/*  771 */     j = this.text.length();
/*  772 */     mTREE_ELEMENT(true);
/*  773 */     this.text.setLength(j);
/*  774 */     token2 = this._returnToken;
/*      */     
/*  776 */     vector.appendElement(this.generator.processStringForASTConstructor(token2.getText()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  781 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  784 */         j = this.text.length();
/*  785 */         mWS(false);
/*  786 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ')':
/*      */       case ',':
/*      */         break;
/*      */       
/*      */       default:
/*  795 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  802 */     while (LA(1) == ',') {
/*  803 */       j = this.text.length();
/*  804 */       match(',');
/*  805 */       this.text.setLength(j);
/*      */       
/*  807 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  810 */           j = this.text.length();
/*  811 */           mWS(false);
/*  812 */           this.text.setLength(j); break;
/*      */         case '"': case '#': case '(': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/*  835 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  839 */       j = this.text.length();
/*  840 */       mTREE_ELEMENT(true);
/*  841 */       this.text.setLength(j);
/*  842 */       token3 = this._returnToken;
/*      */       
/*  844 */       vector.appendElement(this.generator.processStringForASTConstructor(token3.getText()));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  849 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  852 */           j = this.text.length();
/*  853 */           mWS(false);
/*  854 */           this.text.setLength(j);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case ')':
/*      */         case ',':
/*      */           continue; }
/*      */ 
/*      */       
/*  863 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  874 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(vector));
/*  875 */     j = this.text.length();
/*  876 */     match(')');
/*  877 */     this.text.setLength(j);
/*  878 */     if (paramBoolean && token1 == null && b != -1) {
/*  879 */       token1 = makeToken(b);
/*  880 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  882 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  886 */     Token token = null; int i = this.text.length();
/*  887 */     byte b1 = 28;
/*      */ 
/*      */ 
/*      */     
/*  891 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  894 */       if (LA(1) == '\r' && LA(2) == '\n') {
/*  895 */         match('\r');
/*  896 */         match('\n');
/*  897 */         newline();
/*      */       }
/*  899 */       else if (LA(1) == ' ') {
/*  900 */         match(' ');
/*      */       }
/*  902 */       else if (LA(1) == '\t') {
/*  903 */         match('\t');
/*      */       }
/*  905 */       else if (LA(1) == '\r') {
/*  906 */         match('\r');
/*  907 */         newline();
/*      */       }
/*  909 */       else if (LA(1) == '\n') {
/*  910 */         match('\n');
/*  911 */         newline();
/*      */       } else {
/*      */         
/*  914 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  917 */       b2++;
/*      */     } 
/*      */     
/*  920 */     if (paramBoolean && token == null && b1 != -1) {
/*  921 */       token = makeToken(b1);
/*  922 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  924 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  928 */     Token token = null; int i = this.text.length();
/*  929 */     byte b = 17;
/*      */ 
/*      */ 
/*      */     
/*  933 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*  942 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/*  953 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/*  958 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  963 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  970 */     while (_tokenSet_9.member(LA(1))) {
/*      */       
/*  972 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*  981 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/*  992 */           matchRange('A', 'Z'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/*  999 */           matchRange('0', '9');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/* 1004 */           match('_');
/*      */           continue; }
/*      */ 
/*      */ 
/*      */       
/* 1009 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1020 */     if (paramBoolean && token == null && b != -1) {
/* 1021 */       token = makeToken(b);
/* 1022 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1024 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mVAR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1028 */     Token token = null; int i = this.text.length();
/* 1029 */     byte b = 18;
/*      */ 
/*      */     
/* 1032 */     match('=');
/*      */ 
/*      */ 
/*      */     
/* 1036 */     if (LA(1) != '=' && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/* 1037 */       this.transInfo.assignToRoot = true;
/*      */     }
/*      */     
/* 1040 */     if (paramBoolean && token == null && b != -1) {
/* 1041 */       token = makeToken(b);
/* 1042 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1044 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_CONSTRUCTOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1048 */     Token token1 = null; int i = this.text.length();
/* 1049 */     byte b = 10;
/*      */     
/* 1051 */     Token token2 = null;
/* 1052 */     Token token3 = null;
/* 1053 */     Token token4 = null;
/*      */     
/* 1055 */     int j = this.text.length();
/* 1056 */     match('[');
/* 1057 */     this.text.setLength(j);
/*      */     
/* 1059 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1062 */         j = this.text.length();
/* 1063 */         mWS(false);
/* 1064 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1089 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/* 1093 */     j = this.text.length();
/* 1094 */     mAST_CTOR_ELEMENT(true);
/* 1095 */     this.text.setLength(j);
/* 1096 */     token2 = this._returnToken;
/*      */     
/* 1098 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1101 */         j = this.text.length();
/* 1102 */         mWS(false);
/* 1103 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ',':
/*      */       case ']':
/*      */         break;
/*      */       
/*      */       default:
/* 1112 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1117 */     if (LA(1) == ',' && _tokenSet_10.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1118 */       j = this.text.length();
/* 1119 */       match(',');
/* 1120 */       this.text.setLength(j);
/*      */       
/* 1122 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1125 */           j = this.text.length();
/* 1126 */           mWS(false);
/* 1127 */           this.text.setLength(j); break;
/*      */         case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */         case 'f':
/*      */         case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/* 1152 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/* 1156 */       j = this.text.length();
/* 1157 */       mAST_CTOR_ELEMENT(true);
/* 1158 */       this.text.setLength(j);
/* 1159 */       token3 = this._returnToken;
/*      */       
/* 1161 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1164 */           j = this.text.length();
/* 1165 */           mWS(false);
/* 1166 */           this.text.setLength(j);
/*      */           break;
/*      */ 
/*      */         
/*      */         case ',':
/*      */         case ']':
/*      */           break;
/*      */         
/*      */         default:
/* 1175 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1180 */     } else if (LA(1) != ',' && LA(1) != ']') {
/*      */ 
/*      */       
/* 1183 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1188 */     switch (LA(1)) {
/*      */       
/*      */       case ',':
/* 1191 */         j = this.text.length();
/* 1192 */         match(',');
/* 1193 */         this.text.setLength(j);
/*      */         
/* 1195 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1198 */             j = this.text.length();
/* 1199 */             mWS(false);
/* 1200 */             this.text.setLength(j); break;
/*      */           case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */           case 'f':
/*      */           case 'g':
/*      */           case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*      */             break;
/*      */           default:
/* 1225 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1229 */         j = this.text.length();
/* 1230 */         mAST_CTOR_ELEMENT(true);
/* 1231 */         this.text.setLength(j);
/* 1232 */         token4 = this._returnToken;
/*      */         
/* 1234 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1237 */             j = this.text.length();
/* 1238 */             mWS(false);
/* 1239 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ']':
/*      */             break; }
/*      */ 
/*      */ 
/*      */         
/* 1248 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case ']':
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1260 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1264 */     j = this.text.length();
/* 1265 */     match(']');
/* 1266 */     this.text.setLength(j);
/*      */     
/* 1268 */     String str = this.generator.processStringForASTConstructor(token2.getText());
/*      */ 
/*      */ 
/*      */     
/* 1272 */     if (token3 != null)
/* 1273 */       str = str + "," + token3.getText(); 
/* 1274 */     if (token4 != null) {
/* 1275 */       str = str + "," + token4.getText();
/*      */     }
/* 1277 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(null, str));
/*      */     
/* 1279 */     if (paramBoolean && token1 == null && b != -1) {
/* 1280 */       token1 = makeToken(b);
/* 1281 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1283 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1287 */     Token token = null; int i = this.text.length();
/* 1288 */     byte b1 = 13;
/*      */ 
/*      */ 
/*      */     
/* 1292 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1295 */         mWS(false); break;
/*      */       case '"': case '$': case '\'': case '+': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1320 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1325 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1328 */       if (_tokenSet_11.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1329 */         mTEXT_ARG_ELEMENT(false);
/*      */         
/* 1331 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_12.member(LA(2))) {
/* 1332 */           mWS(false);
/*      */         }
/* 1334 */         else if (!_tokenSet_12.member(LA(1))) {
/*      */ 
/*      */           
/* 1337 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1343 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1346 */       b2++;
/*      */     } 
/*      */     
/* 1349 */     if (paramBoolean && token == null && b1 != -1) {
/* 1350 */       token = makeToken(b1);
/* 1351 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1353 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1357 */     Token token1 = null; int i = this.text.length();
/* 1358 */     byte b = 9;
/*      */     
/* 1360 */     Token token2 = null;
/*      */ 
/*      */     
/* 1363 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1366 */         mTREE(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '[':
/* 1371 */         mAST_CONSTRUCTOR(false); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1389 */         mID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1394 */         mSTRING(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1398 */         if (LA(1) == '#' && LA(2) == '(') {
/* 1399 */           int j = this.text.length();
/* 1400 */           match('#');
/* 1401 */           this.text.setLength(j);
/* 1402 */           mTREE(false); break;
/*      */         } 
/* 1404 */         if (LA(1) == '#' && LA(2) == '[') {
/* 1405 */           int j = this.text.length();
/* 1406 */           match('#');
/* 1407 */           this.text.setLength(j);
/* 1408 */           mAST_CONSTRUCTOR(false); break;
/*      */         } 
/* 1410 */         if (LA(1) == '#' && _tokenSet_13.member(LA(2))) {
/* 1411 */           int j = this.text.length();
/* 1412 */           match('#');
/* 1413 */           this.text.setLength(j);
/* 1414 */           boolean bool = mID_ELEMENT(true);
/* 1415 */           token2 = this._returnToken;
/*      */           
/* 1417 */           if (!bool) {
/*      */             
/* 1419 */             String str = this.generator.mapTreeId(token2.getText(), null);
/* 1420 */             if (str != null) {
/* 1421 */               this.text.setLength(i); this.text.append(str);
/*      */             } 
/*      */           } 
/*      */           break;
/*      */         } 
/* 1426 */         if (LA(1) == '#' && LA(2) == '#') {
/* 1427 */           match("##");
/*      */           
/* 1429 */           if (this.currentRule != null) {
/*      */             
/* 1431 */             String str = this.currentRule.getRuleName() + "_AST";
/* 1432 */             this.text.setLength(i); this.text.append(str);
/*      */             
/*      */             break;
/*      */           } 
/* 1436 */           reportError("\"##\" not valid in this context");
/* 1437 */           this.text.setLength(i); this.text.append("##");
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 1442 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1445 */     if (paramBoolean && token1 == null && b != -1) {
/* 1446 */       token1 = makeToken(b);
/* 1447 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1449 */     this._returnToken = token1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final boolean mID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/* 1456 */     boolean bool = false;
/* 1457 */     Token token1 = null; int i = this.text.length();
/* 1458 */     byte b1 = 12;
/*      */     
/* 1460 */     Token token2 = null;
/*      */     
/* 1462 */     mID(true);
/* 1463 */     token2 = this._returnToken;
/*      */     
/* 1465 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/* 1466 */       int k = this.text.length();
/* 1467 */       mWS(false);
/* 1468 */       this.text.setLength(k);
/*      */     }
/* 1470 */     else if (!_tokenSet_14.member(LA(1))) {
/*      */ 
/*      */       
/* 1473 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1478 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1481 */         match('(');
/*      */         
/* 1483 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_15.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1484 */           int k = this.text.length();
/* 1485 */           mWS(false);
/* 1486 */           this.text.setLength(k);
/*      */         }
/* 1488 */         else if (!_tokenSet_15.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 1491 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1496 */         switch (LA(1)) { case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/* 1515 */             mARG(false);
/*      */ 
/*      */ 
/*      */             
/* 1519 */             while (LA(1) == ',') {
/* 1520 */               int k; match(',');
/*      */               
/* 1522 */               switch (LA(1)) { case '\t': case '\n':
/*      */                 case '\r':
/*      */                 case ' ':
/* 1525 */                   k = this.text.length();
/* 1526 */                   mWS(false);
/* 1527 */                   this.text.setLength(k); break;
/*      */                 case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */                 case 'f':
/*      */                 case 'g':
/*      */                 case 'h':
/*      */                 case 'i':
/*      */                 case 'j':
/*      */                 case 'k':
/*      */                 case 'l':
/*      */                 case 'm':
/*      */                 case 'n':
/*      */                 case 'o':
/*      */                 case 'p':
/*      */                 case 'q':
/*      */                 case 'r':
/*      */                 case 's':
/*      */                 case 't':
/*      */                 case 'u':
/*      */                 case 'v':
/*      */                 case 'w':
/*      */                 case 'x':
/*      */                 case 'y':
/*      */                 case 'z':
/*      */                   break;
/*      */                 default:
/* 1552 */                   throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */               
/* 1556 */               mARG(false);
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 1573 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1578 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1581 */             j = this.text.length();
/* 1582 */             mWS(false);
/* 1583 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1592 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1596 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 1602 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 1605 */           if (LA(1) == '[') {
/* 1606 */             match('[');
/*      */             
/* 1608 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1611 */                 j = this.text.length();
/* 1612 */                 mWS(false);
/* 1613 */                 this.text.setLength(j); break;
/*      */               case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */               case 'f':
/*      */               case 'g':
/*      */               case 'h':
/*      */               case 'i':
/*      */               case 'j':
/*      */               case 'k':
/*      */               case 'l':
/*      */               case 'm':
/*      */               case 'n':
/*      */               case 'o':
/*      */               case 'p':
/*      */               case 'q':
/*      */               case 'r':
/*      */               case 's':
/*      */               case 't':
/*      */               case 'u':
/*      */               case 'v':
/*      */               case 'w':
/*      */               case 'x':
/*      */               case 'y':
/*      */               case 'z':
/*      */                 break;
/*      */               default:
/* 1638 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1642 */             mARG(false);
/*      */             
/* 1644 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1647 */                 j = this.text.length();
/* 1648 */                 mWS(false);
/* 1649 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1658 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1662 */             match(']');
/*      */           } else {
/*      */             
/* 1665 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 1668 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 1675 */         match('.');
/* 1676 */         mID_ELEMENT(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1680 */         if (LA(1) == '-' && LA(2) == '>' && _tokenSet_13.member(LA(3))) {
/* 1681 */           match("->");
/* 1682 */           mID_ELEMENT(false); break;
/*      */         } 
/* 1684 */         if (_tokenSet_16.member(LA(1))) {
/*      */           
/* 1686 */           bool = true;
/* 1687 */           String str = this.generator.mapTreeId(token2.getText(), this.transInfo);
/*      */           
/* 1689 */           if (str != null) {
/* 1690 */             this.text.setLength(i); this.text.append(str);
/*      */           } 
/*      */ 
/*      */           
/* 1694 */           if (_tokenSet_17.member(LA(1)) && _tokenSet_16.member(LA(2)) && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/*      */             
/* 1696 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1699 */                 mWS(false);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '=':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1708 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1712 */             mVAR_ASSIGN(false); break;
/*      */           } 
/* 1714 */           if (_tokenSet_18.member(LA(1))) {
/*      */             break;
/*      */           }
/* 1717 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1723 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1727 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 1728 */       token1 = makeToken(b1);
/* 1729 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1731 */     this._returnToken = token1;
/* 1732 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void mAST_CTOR_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1739 */     Token token = null; int i = this.text.length();
/* 1740 */     byte b = 11;
/*      */ 
/*      */     
/* 1743 */     if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1744 */       mSTRING(false);
/*      */     }
/* 1746 */     else if (_tokenSet_19.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1747 */       mTREE_ELEMENT(false);
/*      */     }
/* 1749 */     else if (LA(1) >= '0' && LA(1) <= '9') {
/* 1750 */       mINT(false);
/*      */     } else {
/*      */       
/* 1753 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1756 */     if (paramBoolean && token == null && b != -1) {
/* 1757 */       token = makeToken(b);
/* 1758 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1760 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mINT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1764 */     Token token = null; int i = this.text.length();
/* 1765 */     byte b1 = 26;
/*      */ 
/*      */ 
/*      */     
/* 1769 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1772 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1773 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 1776 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1779 */       b2++;
/*      */     } 
/*      */     
/* 1782 */     if (paramBoolean && token == null && b1 != -1) {
/* 1783 */       token = makeToken(b1);
/* 1784 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1786 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1790 */     Token token = null; int i = this.text.length();
/* 1791 */     byte b = 16;
/*      */ 
/*      */ 
/*      */     
/* 1795 */     switch (LA(1)) {
/*      */       
/*      */       case '\'':
/* 1798 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1805 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1809 */         if (_tokenSet_19.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1810 */           mTREE_ELEMENT(false); break;
/*      */         } 
/* 1812 */         if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1813 */           mSTRING(false);
/*      */           break;
/*      */         } 
/* 1816 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1823 */     while (_tokenSet_20.member(LA(1)) && _tokenSet_21.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */       
/* 1825 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1828 */           mWS(false);
/*      */           break;
/*      */         
/*      */         case '*':
/*      */         case '+':
/*      */         case '-':
/*      */         case '/':
/*      */           break;
/*      */         default:
/* 1837 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1842 */       switch (LA(1)) {
/*      */         
/*      */         case '+':
/* 1845 */           match('+');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '-':
/* 1850 */           match('-');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '*':
/* 1855 */           match('*');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '/':
/* 1860 */           match('/');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1865 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1870 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1873 */           mWS(false); break;
/*      */         case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */         case 'f':
/*      */         case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/* 1898 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/* 1902 */       mARG(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1910 */     if (paramBoolean && token == null && b != -1) {
/* 1911 */       token = makeToken(b);
/* 1912 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1914 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1918 */     Token token = null; int i = this.text.length();
/* 1919 */     byte b = 14;
/*      */ 
/*      */     
/* 1922 */     switch (LA(1)) { case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1938 */         mTEXT_ARG_ID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1943 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 1948 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1955 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '$':
/* 1960 */         mTEXT_ITEM(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '+':
/* 1965 */         match('+');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1970 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */     
/* 1973 */     if (paramBoolean && token == null && b != -1) {
/* 1974 */       token = makeToken(b);
/* 1975 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1977 */     this._returnToken = token;
/*      */   } protected final void mTEXT_ARG_ID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/* 1981 */     Token token1 = null; int i = this.text.length();
/* 1982 */     byte b1 = 15;
/*      */     
/* 1984 */     Token token2 = null;
/*      */     
/* 1986 */     mID(true);
/* 1987 */     token2 = this._returnToken;
/*      */     
/* 1989 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_22.member(LA(2))) {
/* 1990 */       int k = this.text.length();
/* 1991 */       mWS(false);
/* 1992 */       this.text.setLength(k);
/*      */     }
/* 1994 */     else if (!_tokenSet_22.member(LA(1))) {
/*      */ 
/*      */       
/* 1997 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2002 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 2005 */         match('(');
/*      */         
/* 2007 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_23.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2008 */           int k = this.text.length();
/* 2009 */           mWS(false);
/* 2010 */           this.text.setLength(k);
/*      */         }
/* 2012 */         else if (!_tokenSet_23.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 2015 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2022 */         while (_tokenSet_24.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2023 */           mTEXT_ARG(false);
/*      */ 
/*      */ 
/*      */           
/* 2027 */           while (LA(1) == ',') {
/* 2028 */             match(',');
/* 2029 */             mTEXT_ARG(false);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2045 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 2048 */             j = this.text.length();
/* 2049 */             mWS(false);
/* 2050 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2059 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 2063 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 2069 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 2072 */           if (LA(1) == '[') {
/* 2073 */             match('[');
/*      */             
/* 2075 */             if (_tokenSet_4.member(LA(1)) && _tokenSet_24.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2076 */               j = this.text.length();
/* 2077 */               mWS(false);
/* 2078 */               this.text.setLength(j);
/*      */             }
/* 2080 */             else if (!_tokenSet_24.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ' || LA(3) < '\003' || LA(3) > 'ÿ') {
/*      */ 
/*      */               
/* 2083 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */ 
/*      */             
/* 2087 */             mTEXT_ARG(false);
/*      */             
/* 2089 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 2092 */                 j = this.text.length();
/* 2093 */                 mWS(false);
/* 2094 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2103 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 2107 */             match(']');
/*      */           } else {
/*      */             
/* 2110 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 2113 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 2120 */         match('.');
/* 2121 */         mTEXT_ARG_ID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '-':
/* 2126 */         match("->");
/* 2127 */         mTEXT_ARG_ID_ELEMENT(false); break;
/*      */       case '\t': case '\n': case '\r': case ' ': case '"': case '$': case '\'': case ')': case '+': case ',': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case ']': case '_': case 'a': case 'b': case 'c':
/*      */       case 'd':
/*      */       case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 2154 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2158 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 2159 */       token1 = makeToken(b1);
/* 2160 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2162 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mINT_OR_FLOAT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2166 */     Token token = null; int i = this.text.length();
/* 2167 */     byte b1 = 27;
/*      */ 
/*      */ 
/*      */     
/* 2171 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 2174 */       if (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_25.member(LA(2))) {
/* 2175 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 2178 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2181 */       b2++;
/*      */     } 
/*      */ 
/*      */     
/* 2185 */     if (LA(1) == 'L' && _tokenSet_26.member(LA(2))) {
/* 2186 */       match('L');
/*      */     }
/* 2188 */     else if (LA(1) == 'l' && _tokenSet_26.member(LA(2))) {
/* 2189 */       match('l');
/*      */     }
/* 2191 */     else if (LA(1) == '.') {
/* 2192 */       match('.');
/*      */ 
/*      */ 
/*      */       
/* 2196 */       while (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_26.member(LA(2))) {
/* 2197 */         mDIGIT(false);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2206 */     else if (!_tokenSet_26.member(LA(1))) {
/*      */ 
/*      */       
/* 2209 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2213 */     if (paramBoolean && token == null && b1 != -1) {
/* 2214 */       token = makeToken(b1);
/* 2215 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2217 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2221 */     Token token = null; int i = this.text.length();
/* 2222 */     byte b = 20;
/*      */ 
/*      */     
/* 2225 */     match("//");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2230 */     while (LA(1) != '\n' && LA(1) != '\r' && 
/* 2231 */       LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2232 */       matchNot('￿');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2241 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 2242 */       match("\r\n");
/*      */     }
/* 2244 */     else if (LA(1) == '\n') {
/* 2245 */       match('\n');
/*      */     }
/* 2247 */     else if (LA(1) == '\r') {
/* 2248 */       match('\r');
/*      */     } else {
/*      */       
/* 2251 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2255 */     newline();
/* 2256 */     if (paramBoolean && token == null && b != -1) {
/* 2257 */       token = makeToken(b);
/* 2258 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2260 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2264 */     Token token = null; int i = this.text.length();
/* 2265 */     byte b = 21;
/*      */ 
/*      */     
/* 2268 */     match("/*");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2273 */     while (LA(1) != '*' || LA(2) != '/') {
/* 2274 */       if (LA(1) == '\r' && LA(2) == '\n' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2275 */         match('\r');
/* 2276 */         match('\n');
/* 2277 */         newline(); continue;
/*      */       } 
/* 2279 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2280 */         match('\r');
/* 2281 */         newline(); continue;
/*      */       } 
/* 2283 */       if (LA(1) == '\n' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2284 */         match('\n');
/* 2285 */         newline(); continue;
/*      */       } 
/* 2287 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2288 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 2296 */     match("*/");
/* 2297 */     if (paramBoolean && token == null && b != -1) {
/* 2298 */       token = makeToken(b);
/* 2299 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2301 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2305 */     Token token = null; int i = this.text.length();
/* 2306 */     byte b = 24;
/*      */ 
/*      */     
/* 2309 */     match('\\');
/*      */     
/* 2311 */     switch (LA(1)) {
/*      */       
/*      */       case 'n':
/* 2314 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/* 2319 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/* 2324 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/* 2329 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/* 2334 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 2339 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 2344 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/* 2349 */         match('\\');
/*      */         break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/* 2355 */         matchRange('0', '3');
/*      */ 
/*      */         
/* 2358 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2359 */           mDIGIT(false);
/*      */           
/* 2361 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2362 */             mDIGIT(false); break;
/*      */           } 
/* 2364 */           if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */             break;
/*      */           }
/* 2367 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2372 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2375 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/* 2384 */         matchRange('4', '7');
/*      */ 
/*      */         
/* 2387 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2388 */           mDIGIT(false); break;
/*      */         } 
/* 2390 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2393 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2401 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2405 */     if (paramBoolean && token == null && b != -1) {
/* 2406 */       token = makeToken(b);
/* 2407 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2409 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2413 */     Token token = null; int i = this.text.length();
/* 2414 */     byte b = 25;
/*      */ 
/*      */     
/* 2417 */     matchRange('0', '9');
/* 2418 */     if (paramBoolean && token == null && b != -1) {
/* 2419 */       token = makeToken(b);
/* 2420 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2422 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 2427 */     long[] arrayOfLong = new long[8];
/* 2428 */     arrayOfLong[0] = -103079215112L;
/* 2429 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2430 */      return arrayOfLong;
/*      */   }
/* 2432 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 2434 */     long[] arrayOfLong = new long[8];
/* 2435 */     arrayOfLong[0] = -145135534866440L;
/* 2436 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2437 */      return arrayOfLong;
/*      */   }
/* 2439 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 2441 */     long[] arrayOfLong = new long[8];
/* 2442 */     arrayOfLong[0] = -141407503262728L;
/* 2443 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2444 */      return arrayOfLong;
/*      */   }
/* 2446 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 2448 */     return new long[] { 4294977024L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2451 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 2453 */     return new long[] { 4294977024L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2456 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 2458 */     return new long[] { 1103806604800L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2461 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 2463 */     return new long[] { 287959436729787904L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2466 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 2468 */     long[] arrayOfLong = new long[8];
/* 2469 */     arrayOfLong[0] = -17179869192L;
/* 2470 */     arrayOfLong[1] = -268435457L;
/* 2471 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2472 */      return arrayOfLong;
/*      */   }
/* 2474 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 2476 */     long[] arrayOfLong = new long[8];
/* 2477 */     arrayOfLong[0] = -549755813896L;
/* 2478 */     arrayOfLong[1] = -268435457L;
/* 2479 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2480 */      return arrayOfLong;
/*      */   }
/* 2482 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 2484 */     return new long[] { 287948901175001088L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2487 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 2489 */     return new long[] { 287950056521213440L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2492 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 2494 */     return new long[] { 287958332923183104L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2497 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 2499 */     return new long[] { 287978128427460096L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2502 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 2504 */     return new long[] { 0L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2507 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 2509 */     return new long[] { 2306123388973753856L, 671088640L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2512 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 2514 */     return new long[] { 287952805300282880L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2517 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 2519 */     return new long[] { 2306051920717948416L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2522 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 2524 */     return new long[] { 2305843013508670976L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2527 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 2529 */     return new long[] { 208911504254464L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2532 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 2534 */     return new long[] { 1151051235328L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2537 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 2539 */     return new long[] { 189120294954496L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2542 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 2544 */     return new long[] { 288139722277004800L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2547 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 2549 */     return new long[] { 288084781055354368L, 576460746666278910L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2552 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   private static final long[] mk_tokenSet_23() {
/* 2554 */     return new long[] { 287960536241415680L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2557 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   private static final long[] mk_tokenSet_24() {
/* 2559 */     return new long[] { 287958337218160128L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2562 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   private static final long[] mk_tokenSet_25() {
/* 2564 */     return new long[] { 288228817078593024L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2567 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */   private static final long[] mk_tokenSet_26() {
/* 2569 */     return new long[] { 288158448334415360L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2572 */   public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
/*      */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\actions\csharp\ActionLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
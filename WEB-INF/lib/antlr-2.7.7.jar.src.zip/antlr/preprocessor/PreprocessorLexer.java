/*      */ package antlr.preprocessor;
/*      */ 
/*      */ import antlr.ANTLRHashString;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PreprocessorLexer
/*      */   extends CharScanner
/*      */   implements PreprocessorTokenTypes, TokenStream
/*      */ {
/*      */   public PreprocessorLexer(InputStream paramInputStream) {
/*   32 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public PreprocessorLexer(Reader paramReader) {
/*   35 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public PreprocessorLexer(InputBuffer paramInputBuffer) {
/*   38 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public PreprocessorLexer(LexerSharedInputState paramLexerSharedInputState) {
/*   41 */     super(paramLexerSharedInputState);
/*   42 */     this.caseSensitiveLiterals = true;
/*   43 */     setCaseSensitive(true);
/*   44 */     this.literals = new Hashtable();
/*   45 */     this.literals.put(new ANTLRHashString("public", this), new Integer(18));
/*   46 */     this.literals.put(new ANTLRHashString("class", this), new Integer(8));
/*   47 */     this.literals.put(new ANTLRHashString("throws", this), new Integer(23));
/*   48 */     this.literals.put(new ANTLRHashString("catch", this), new Integer(26));
/*   49 */     this.literals.put(new ANTLRHashString("private", this), new Integer(17));
/*   50 */     this.literals.put(new ANTLRHashString("extends", this), new Integer(10));
/*   51 */     this.literals.put(new ANTLRHashString("protected", this), new Integer(16));
/*   52 */     this.literals.put(new ANTLRHashString("returns", this), new Integer(21));
/*   53 */     this.literals.put(new ANTLRHashString("tokens", this), new Integer(4));
/*   54 */     this.literals.put(new ANTLRHashString("exception", this), new Integer(25));
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*   58 */     Token token = null;
/*      */     
/*      */     while (true) {
/*   61 */       Object object = null;
/*   62 */       int i = 0;
/*   63 */       resetText();
/*      */       
/*      */       try {
/*   66 */         switch (LA(1)) {
/*      */           
/*      */           case ':':
/*   69 */             mRULE_BLOCK(true);
/*   70 */             token = this._returnToken; break;
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*   75 */             mWS(true);
/*   76 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '/':
/*   81 */             mCOMMENT(true);
/*   82 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '{':
/*   87 */             mACTION(true);
/*   88 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '"':
/*   93 */             mSTRING_LITERAL(true);
/*   94 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\'':
/*   99 */             mCHAR_LITERAL(true);
/*  100 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '!':
/*  105 */             mBANG(true);
/*  106 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ';':
/*  111 */             mSEMI(true);
/*  112 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ',':
/*  117 */             mCOMMA(true);
/*  118 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '}':
/*  123 */             mRCURLY(true);
/*  124 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*  129 */             mRPAREN(true);
/*  130 */             token = this._returnToken; break;
/*      */           case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*  148 */             mID_OR_KEYWORD(true);
/*  149 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '=':
/*  154 */             mASSIGN_RHS(true);
/*  155 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '[':
/*  160 */             mARG_ACTION(true);
/*  161 */             token = this._returnToken;
/*      */             break;
/*      */           
/*      */           default:
/*  165 */             if (LA(1) == '(' && _tokenSet_0.member(LA(2))) {
/*  166 */               mSUBRULE_BLOCK(true);
/*  167 */               token = this._returnToken; break;
/*      */             } 
/*  169 */             if (LA(1) == '(') {
/*  170 */               mLPAREN(true);
/*  171 */               token = this._returnToken;
/*      */               break;
/*      */             } 
/*  174 */             if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); break; }
/*  175 */              throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */         
/*  178 */         if (this._returnToken == null)
/*  179 */           continue;  i = this._returnToken.getType();
/*  180 */         i = testLiteralsTable(i);
/*  181 */         this._returnToken.setType(i);
/*  182 */         return this._returnToken;
/*      */       }
/*  184 */       catch (RecognitionException recognitionException) {
/*  185 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  188 */       catch (CharStreamException charStreamException) {
/*  189 */         if (charStreamException instanceof CharStreamIOException) {
/*  190 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  193 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void mRULE_BLOCK(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*  200 */     Token token = null; int i = this.text.length();
/*  201 */     byte b = 22;
/*      */ 
/*      */     
/*  204 */     match(':');
/*      */     
/*  206 */     if (_tokenSet_1.member(LA(1)) && _tokenSet_2.member(LA(2))) {
/*  207 */       int k = this.text.length();
/*  208 */       mWS(false);
/*  209 */       this.text.setLength(k);
/*      */     }
/*  211 */     else if (!_tokenSet_2.member(LA(1))) {
/*      */ 
/*      */       
/*  214 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  218 */     mALT(false);
/*      */     
/*  220 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  223 */         j = this.text.length();
/*  224 */         mWS(false);
/*  225 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ';':
/*      */       case '|':
/*      */         break;
/*      */       
/*      */       default:
/*  234 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  241 */     while (LA(1) == '|') {
/*  242 */       match('|');
/*      */       
/*  244 */       if (_tokenSet_1.member(LA(1)) && _tokenSet_2.member(LA(2))) {
/*  245 */         j = this.text.length();
/*  246 */         mWS(false);
/*  247 */         this.text.setLength(j);
/*      */       }
/*  249 */       else if (!_tokenSet_2.member(LA(1))) {
/*      */ 
/*      */         
/*  252 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */       
/*  256 */       mALT(false);
/*      */       
/*  258 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  261 */           j = this.text.length();
/*  262 */           mWS(false);
/*  263 */           this.text.setLength(j);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case ';':
/*      */         case '|':
/*      */           continue; }
/*      */ 
/*      */       
/*  272 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  283 */     match(';');
/*  284 */     if (paramBoolean && token == null && b != -1) {
/*  285 */       token = makeToken(b);
/*  286 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  288 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  292 */     Token token = null; int i = this.text.length();
/*  293 */     byte b = 33;
/*      */ 
/*      */ 
/*      */     
/*  297 */     byte b1 = 0;
/*      */     
/*      */     while (true) {
/*  300 */       if (LA(1) == ' ') {
/*  301 */         match(' ');
/*      */       }
/*  303 */       else if (LA(1) == '\t') {
/*  304 */         match('\t');
/*      */       }
/*  306 */       else if (LA(1) == '\n' || LA(1) == '\r') {
/*  307 */         mNEWLINE(false);
/*      */       } else {
/*      */         
/*  310 */         if (b1 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  313 */       b1++;
/*      */     } 
/*      */     
/*  316 */     b = -1;
/*  317 */     if (paramBoolean && token == null && b != -1) {
/*  318 */       token = makeToken(b);
/*  319 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  321 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mALT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  325 */     Token token = null; int i = this.text.length();
/*  326 */     byte b = 27;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  332 */     while (_tokenSet_3.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  333 */       mELEMENT(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  341 */     if (paramBoolean && token == null && b != -1) {
/*  342 */       token = makeToken(b);
/*  343 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  345 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSUBRULE_BLOCK(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  349 */     Token token = null; int i = this.text.length();
/*  350 */     byte b = 6;
/*      */ 
/*      */     
/*  353 */     match('(');
/*      */     
/*  355 */     if (_tokenSet_1.member(LA(1)) && _tokenSet_0.member(LA(2))) {
/*  356 */       mWS(false);
/*      */     }
/*  358 */     else if (!_tokenSet_0.member(LA(1))) {
/*      */ 
/*      */       
/*  361 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  365 */     mALT(false);
/*      */ 
/*      */ 
/*      */     
/*  369 */     while (_tokenSet_4.member(LA(1)) && _tokenSet_0.member(LA(2))) {
/*      */       
/*  371 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  374 */           mWS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '|':
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  383 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  387 */       match('|');
/*      */       
/*  389 */       if (_tokenSet_1.member(LA(1)) && _tokenSet_0.member(LA(2))) {
/*  390 */         mWS(false);
/*      */       }
/*  392 */       else if (!_tokenSet_0.member(LA(1))) {
/*      */ 
/*      */         
/*  395 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */       
/*  399 */       mALT(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  408 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  411 */         mWS(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ')':
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  420 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/*  424 */     match(')');
/*      */     
/*  426 */     if (LA(1) == '=' && LA(2) == '>') {
/*  427 */       match("=>");
/*      */     }
/*  429 */     else if (LA(1) == '*') {
/*  430 */       match('*');
/*      */     }
/*  432 */     else if (LA(1) == '+') {
/*  433 */       match('+');
/*      */     }
/*  435 */     else if (LA(1) == '?') {
/*  436 */       match('?');
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  442 */     if (paramBoolean && token == null && b != -1) {
/*  443 */       token = makeToken(b);
/*  444 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  446 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  450 */     Token token = null; int i = this.text.length();
/*  451 */     byte b = 28;
/*      */ 
/*      */     
/*  454 */     switch (LA(1)) {
/*      */       
/*      */       case '/':
/*  457 */         mCOMMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '{':
/*  462 */         mACTION(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/*  467 */         mSTRING_LITERAL(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/*  472 */         mCHAR_LITERAL(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '(':
/*  477 */         mSUBRULE_BLOCK(false);
/*      */         break;
/*      */       
/*      */       case '\n':
/*      */       case '\r':
/*  482 */         mNEWLINE(false);
/*      */         break;
/*      */       
/*      */       default:
/*  486 */         if (_tokenSet_5.member(LA(1))) {
/*      */           
/*  488 */           match(_tokenSet_5);
/*      */           
/*      */           break;
/*      */         } 
/*  492 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  495 */     if (paramBoolean && token == null && b != -1) {
/*  496 */       token = makeToken(b);
/*  497 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  499 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  503 */     Token token = null; int i = this.text.length();
/*  504 */     byte b = 35;
/*      */ 
/*      */ 
/*      */     
/*  508 */     if (LA(1) == '/' && LA(2) == '/') {
/*  509 */       mSL_COMMENT(false);
/*      */     }
/*  511 */     else if (LA(1) == '/' && LA(2) == '*') {
/*  512 */       mML_COMMENT(false);
/*      */     } else {
/*      */       
/*  515 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  519 */     b = -1;
/*  520 */     if (paramBoolean && token == null && b != -1) {
/*  521 */       token = makeToken(b);
/*  522 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  524 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  528 */     Token token = null; int i = this.text.length();
/*  529 */     byte b = 7;
/*      */ 
/*      */     
/*  532 */     match('{');
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  537 */     while (LA(1) != '}') {
/*  538 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  539 */         mNEWLINE(false); continue;
/*      */       } 
/*  541 */       if (LA(1) == '{' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  542 */         mACTION(false); continue;
/*      */       } 
/*  544 */       if (LA(1) == '\'' && _tokenSet_6.member(LA(2))) {
/*  545 */         mCHAR_LITERAL(false); continue;
/*      */       } 
/*  547 */       if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/*  548 */         mCOMMENT(false); continue;
/*      */       } 
/*  550 */       if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  551 */         mSTRING_LITERAL(false); continue;
/*      */       } 
/*  553 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  554 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  562 */     match('}');
/*  563 */     if (paramBoolean && token == null && b != -1) {
/*  564 */       token = makeToken(b);
/*  565 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  567 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTRING_LITERAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  571 */     Token token = null; int i = this.text.length();
/*  572 */     byte b = 39;
/*      */ 
/*      */     
/*  575 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/*  579 */       while (LA(1) == '\\') {
/*  580 */         mESC(false);
/*      */       }
/*  582 */       if (_tokenSet_7.member(LA(1))) {
/*  583 */         matchNot('"');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  591 */     match('"');
/*  592 */     if (paramBoolean && token == null && b != -1) {
/*  593 */       token = makeToken(b);
/*  594 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  596 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCHAR_LITERAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  600 */     Token token = null; int i = this.text.length();
/*  601 */     byte b = 38;
/*      */ 
/*      */     
/*  604 */     match('\'');
/*      */     
/*  606 */     if (LA(1) == '\\') {
/*  607 */       mESC(false);
/*      */     }
/*  609 */     else if (_tokenSet_8.member(LA(1))) {
/*  610 */       matchNot('\'');
/*      */     } else {
/*      */       
/*  613 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  617 */     match('\'');
/*  618 */     if (paramBoolean && token == null && b != -1) {
/*  619 */       token = makeToken(b);
/*  620 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  622 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mNEWLINE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  626 */     Token token = null; int i = this.text.length();
/*  627 */     byte b = 34;
/*      */ 
/*      */ 
/*      */     
/*  631 */     if (LA(1) == '\r' && LA(2) == '\n') {
/*  632 */       match('\r');
/*  633 */       match('\n');
/*  634 */       newline();
/*      */     }
/*  636 */     else if (LA(1) == '\r') {
/*  637 */       match('\r');
/*  638 */       newline();
/*      */     }
/*  640 */     else if (LA(1) == '\n') {
/*  641 */       match('\n');
/*  642 */       newline();
/*      */     } else {
/*      */       
/*  645 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  649 */     if (paramBoolean && token == null && b != -1) {
/*  650 */       token = makeToken(b);
/*  651 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  653 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBANG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  657 */     Token token = null; int i = this.text.length();
/*  658 */     byte b = 19;
/*      */ 
/*      */     
/*  661 */     match('!');
/*  662 */     if (paramBoolean && token == null && b != -1) {
/*  663 */       token = makeToken(b);
/*  664 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  666 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSEMI(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  670 */     Token token = null; int i = this.text.length();
/*  671 */     byte b = 11;
/*      */ 
/*      */     
/*  674 */     match(';');
/*  675 */     if (paramBoolean && token == null && b != -1) {
/*  676 */       token = makeToken(b);
/*  677 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  679 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOMMA(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  683 */     Token token = null; int i = this.text.length();
/*  684 */     byte b = 24;
/*      */ 
/*      */     
/*  687 */     match(',');
/*  688 */     if (paramBoolean && token == null && b != -1) {
/*  689 */       token = makeToken(b);
/*  690 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  692 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  696 */     Token token = null; int i = this.text.length();
/*  697 */     byte b = 15;
/*      */ 
/*      */     
/*  700 */     match('}');
/*  701 */     if (paramBoolean && token == null && b != -1) {
/*  702 */       token = makeToken(b);
/*  703 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  705 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  709 */     Token token = null; int i = this.text.length();
/*  710 */     byte b = 29;
/*      */ 
/*      */     
/*  713 */     match('(');
/*  714 */     if (paramBoolean && token == null && b != -1) {
/*  715 */       token = makeToken(b);
/*  716 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  718 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  722 */     Token token = null; int i = this.text.length();
/*  723 */     byte b = 30;
/*      */ 
/*      */     
/*  726 */     match(')');
/*  727 */     if (paramBoolean && token == null && b != -1) {
/*  728 */       token = makeToken(b);
/*  729 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  731 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void mID_OR_KEYWORD(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  742 */     Token token1 = null; int j = this.text.length();
/*  743 */     int i = 31;
/*      */     
/*  745 */     Token token2 = null;
/*      */     
/*  747 */     mID(true);
/*  748 */     token2 = this._returnToken;
/*  749 */     i = token2.getType();
/*      */     
/*  751 */     if (_tokenSet_9.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && token2.getText().equals("header")) {
/*      */       
/*  753 */       if (_tokenSet_1.member(LA(1)) && _tokenSet_9.member(LA(2))) {
/*  754 */         mWS(false);
/*      */       }
/*  756 */       else if (!_tokenSet_9.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */         
/*  759 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  764 */       switch (LA(1)) {
/*      */         
/*      */         case '"':
/*  767 */           mSTRING_LITERAL(false);
/*      */           break;
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*      */         case '/':
/*      */         case '{':
/*      */           break;
/*      */         default:
/*  777 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*  784 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  787 */             mWS(false);
/*      */             continue;
/*      */ 
/*      */           
/*      */           case '/':
/*  792 */             mCOMMENT(false);
/*      */             continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  802 */       mACTION(false);
/*  803 */       i = 5;
/*      */     }
/*  805 */     else if (_tokenSet_10.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && token2.getText().equals("tokens")) {
/*      */       
/*      */       while (true) {
/*      */         
/*  809 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  812 */             mWS(false);
/*      */             continue;
/*      */ 
/*      */           
/*      */           case '/':
/*  817 */             mCOMMENT(false);
/*      */             continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  827 */       mCURLY_BLOCK_SCARF(false);
/*  828 */       i = 12;
/*      */     }
/*  830 */     else if (_tokenSet_10.member(LA(1)) && token2.getText().equals("options")) {
/*      */       
/*      */       while (true) {
/*      */         
/*  834 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  837 */             mWS(false);
/*      */             continue;
/*      */ 
/*      */           
/*      */           case '/':
/*  842 */             mCOMMENT(false);
/*      */             continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  852 */       match('{');
/*  853 */       i = 13;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  859 */     if (paramBoolean && token1 == null && i != -1) {
/*  860 */       token1 = makeToken(i);
/*  861 */       token1.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/*  863 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  867 */     Token token = null; int j = this.text.length();
/*  868 */     int i = 9;
/*      */ 
/*      */ 
/*      */     
/*  872 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*  881 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/*  892 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/*  897 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  902 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  909 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*  918 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/*  929 */           matchRange('A', 'Z');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/*  934 */           match('_'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/*  941 */           matchRange('0', '9');
/*      */           continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/*  951 */     i = testLiteralsTable(new String(this.text.getBuffer(), j, this.text.length() - j), i);
/*  952 */     if (paramBoolean && token == null && i != -1) {
/*  953 */       token = makeToken(i);
/*  954 */       token.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/*  956 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mCURLY_BLOCK_SCARF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  960 */     Token token = null; int i = this.text.length();
/*  961 */     byte b = 32;
/*      */ 
/*      */     
/*  964 */     match('{');
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  969 */     while (LA(1) != '}') {
/*  970 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  971 */         mNEWLINE(false); continue;
/*      */       } 
/*  973 */       if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  974 */         mSTRING_LITERAL(false); continue;
/*      */       } 
/*  976 */       if (LA(1) == '\'' && _tokenSet_6.member(LA(2))) {
/*  977 */         mCHAR_LITERAL(false); continue;
/*      */       } 
/*  979 */       if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/*  980 */         mCOMMENT(false); continue;
/*      */       } 
/*  982 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  983 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  991 */     match('}');
/*  992 */     if (paramBoolean && token == null && b != -1) {
/*  993 */       token = makeToken(b);
/*  994 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  996 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mASSIGN_RHS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1000 */     Token token = null; int i = this.text.length();
/* 1001 */     byte b = 14;
/*      */ 
/*      */     
/* 1004 */     int j = this.text.length();
/* 1005 */     match('=');
/* 1006 */     this.text.setLength(j);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1011 */     while (LA(1) != ';') {
/* 1012 */       if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1013 */         mSTRING_LITERAL(false); continue;
/*      */       } 
/* 1015 */       if (LA(1) == '\'' && _tokenSet_6.member(LA(2))) {
/* 1016 */         mCHAR_LITERAL(false); continue;
/*      */       } 
/* 1018 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1019 */         mNEWLINE(false); continue;
/*      */       } 
/* 1021 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1022 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1030 */     match(';');
/* 1031 */     if (paramBoolean && token == null && b != -1) {
/* 1032 */       token = makeToken(b);
/* 1033 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1035 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1039 */     Token token = null; int i = this.text.length();
/* 1040 */     byte b = 36;
/*      */ 
/*      */     
/* 1043 */     match("//");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1048 */     while (LA(1) != '\n' && LA(1) != '\r' && 
/* 1049 */       LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1050 */       matchNot('￿');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1058 */     mNEWLINE(false);
/* 1059 */     if (paramBoolean && token == null && b != -1) {
/* 1060 */       token = makeToken(b);
/* 1061 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1063 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1067 */     Token token = null; int i = this.text.length();
/* 1068 */     byte b = 37;
/*      */ 
/*      */     
/* 1071 */     match("/*");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1076 */     while (LA(1) != '*' || LA(2) != '/') {
/* 1077 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1078 */         mNEWLINE(false); continue;
/*      */       } 
/* 1080 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1081 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1089 */     match("*/");
/* 1090 */     if (paramBoolean && token == null && b != -1) {
/* 1091 */       token = makeToken(b);
/* 1092 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1094 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1098 */     Token token = null; int i = this.text.length();
/* 1099 */     byte b = 40;
/*      */ 
/*      */     
/* 1102 */     match('\\');
/*      */     
/* 1104 */     switch (LA(1)) {
/*      */       
/*      */       case 'n':
/* 1107 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/* 1112 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/* 1117 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/* 1122 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/* 1127 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'w':
/* 1132 */         match('w');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'a':
/* 1137 */         match('a');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1142 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 1147 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/* 1152 */         match('\\');
/*      */         break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/* 1158 */         matchRange('0', '3');
/*      */ 
/*      */         
/* 1161 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1162 */           mDIGIT(false);
/*      */           
/* 1164 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1165 */             mDIGIT(false); break;
/*      */           } 
/* 1167 */           if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */             break;
/*      */           }
/* 1170 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1175 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 1178 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/* 1187 */         matchRange('4', '7');
/*      */ 
/*      */         
/* 1190 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1191 */           mDIGIT(false); break;
/*      */         } 
/* 1193 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 1196 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 'u':
/* 1204 */         match('u');
/* 1205 */         mXDIGIT(false);
/* 1206 */         mXDIGIT(false);
/* 1207 */         mXDIGIT(false);
/* 1208 */         mXDIGIT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1213 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1217 */     if (paramBoolean && token == null && b != -1) {
/* 1218 */       token = makeToken(b);
/* 1219 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1221 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1225 */     Token token = null; int i = this.text.length();
/* 1226 */     byte b = 41;
/*      */ 
/*      */     
/* 1229 */     matchRange('0', '9');
/* 1230 */     if (paramBoolean && token == null && b != -1) {
/* 1231 */       token = makeToken(b);
/* 1232 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1234 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mXDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1238 */     Token token = null; int i = this.text.length();
/* 1239 */     byte b = 42;
/*      */ 
/*      */     
/* 1242 */     switch (LA(1)) { case '0': case '1': case '2': case '3': case '4': case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1247 */         matchRange('0', '9'); break;
/*      */       case 'a': case 'b':
/*      */       case 'c':
/*      */       case 'd':
/*      */       case 'e':
/*      */       case 'f':
/* 1253 */         matchRange('a', 'f'); break;
/*      */       case 'A': case 'B':
/*      */       case 'C':
/*      */       case 'D':
/*      */       case 'E':
/*      */       case 'F':
/* 1259 */         matchRange('A', 'F');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1264 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */     
/* 1267 */     if (paramBoolean && token == null && b != -1) {
/* 1268 */       token = makeToken(b);
/* 1269 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1271 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mARG_ACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1275 */     Token token = null; int i = this.text.length();
/* 1276 */     byte b = 20;
/*      */ 
/*      */     
/* 1279 */     match('[');
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1284 */     while (LA(1) != ']') {
/* 1285 */       if (LA(1) == '[' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1286 */         mARG_ACTION(false); continue;
/*      */       } 
/* 1288 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1289 */         mNEWLINE(false); continue;
/*      */       } 
/* 1291 */       if (LA(1) == '\'' && _tokenSet_6.member(LA(2))) {
/* 1292 */         mCHAR_LITERAL(false); continue;
/*      */       } 
/* 1294 */       if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1295 */         mSTRING_LITERAL(false); continue;
/*      */       } 
/* 1297 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1298 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1306 */     match(']');
/* 1307 */     if (paramBoolean && token == null && b != -1) {
/* 1308 */       token = makeToken(b);
/* 1309 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1311 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 1316 */     long[] arrayOfLong = new long[8];
/* 1317 */     arrayOfLong[0] = -576460752303423496L;
/* 1318 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1319 */      return arrayOfLong;
/*      */   }
/* 1321 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 1323 */     return new long[] { 4294977024L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 1326 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 1328 */     long[] arrayOfLong = new long[8];
/* 1329 */     arrayOfLong[0] = -2199023255560L;
/* 1330 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1331 */      return arrayOfLong;
/*      */   }
/* 1333 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 1335 */     long[] arrayOfLong = new long[8];
/* 1336 */     arrayOfLong[0] = -576462951326679048L;
/* 1337 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1338 */      return arrayOfLong;
/*      */   }
/* 1340 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 1342 */     return new long[] { 4294977024L, 1152921504606846976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 1345 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 1347 */     long[] arrayOfLong = new long[8];
/* 1348 */     arrayOfLong[0] = -576605355262354440L;
/* 1349 */     arrayOfLong[1] = -576460752303423489L;
/* 1350 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1351 */      return arrayOfLong;
/*      */   }
/* 1353 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 1355 */     long[] arrayOfLong = new long[8];
/* 1356 */     arrayOfLong[0] = -549755813896L;
/* 1357 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1358 */      return arrayOfLong;
/*      */   }
/* 1360 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 1362 */     long[] arrayOfLong = new long[8];
/* 1363 */     arrayOfLong[0] = -17179869192L;
/* 1364 */     arrayOfLong[1] = -268435457L;
/* 1365 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1366 */      return arrayOfLong;
/*      */   }
/* 1368 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 1370 */     long[] arrayOfLong = new long[8];
/* 1371 */     arrayOfLong[0] = -549755813896L;
/* 1372 */     arrayOfLong[1] = -268435457L;
/* 1373 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1374 */      return arrayOfLong;
/*      */   }
/* 1376 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 1378 */     return new long[] { 140758963201536L, 576460752303423488L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 1381 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 1383 */     return new long[] { 140741783332352L, 576460752303423488L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 1386 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\preprocessor\PreprocessorLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
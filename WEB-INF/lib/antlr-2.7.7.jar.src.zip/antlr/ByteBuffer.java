/*    */ package antlr;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteBuffer
/*    */   extends InputBuffer
/*    */ {
/*    */   public transient InputStream input;
/*    */   
/*    */   public ByteBuffer(InputStream paramInputStream) {
/* 36 */     this.input = paramInputStream;
/*    */   }
/*    */ 
/*    */   
/*    */   public void fill(int paramInt) throws CharStreamException {
/*    */     try {
/* 42 */       syncConsume();
/*    */       
/* 44 */       while (this.queue.nbrEntries < paramInt + this.markerOffset)
/*    */       {
/* 46 */         this.queue.append((char)this.input.read());
/*    */       }
/*    */     }
/* 49 */     catch (IOException iOException) {
/* 50 */       throw new CharStreamIOException(iOException);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\ByteBuffer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
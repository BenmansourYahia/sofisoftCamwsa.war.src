package antlr;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

public interface JavaCodeGeneratorPrintWriterManager {
  PrintWriter setupOutput(Tool paramTool, Grammar paramGrammar) throws IOException;
  
  PrintWriter setupOutput(Tool paramTool, String paramString) throws IOException;
  
  void startMapping(int paramInt);
  
  void startSingleSourceLineMapping(int paramInt);
  
  void endMapping();
  
  void finishOutput() throws IOException;
  
  Map getSourceMaps();
}


/* Location:              C:\Users\HP EliteBook 840 G8\Desktop\sofisoftCamwsa.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\JavaCodeGeneratorPrintWriterManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */